"""The manager's page of the founders' offer («عرض المؤسسين»): the box on his page «العروض», and the page that box opens with every
detail and figure of the offer in one place, with the switch that starts and pauses it. The rules and the counting are in founders.py.
It is NOT one of the discounts of «عروضي»: it has its own table, and an owner's page of offers never shows it."""
from __future__ import annotations

from datetime import date

from . import founders, ui, util
from .app import Ctx, html_page
from .server import redirect
from .ui import e, num
from .views_admin import tag


def box(db, today: date) -> str:
    """The separate box at the top of the manager's «العروض»: the offer's name, whether it runs, the seats, and a way in."""
    s = founders.summary(db, today)
    state = tag("ok", "نشط") if s["on"] else tag("warn", "متوقف")
    return (f'<a class="founders-card" href="/admin/offers/founders"><span class="fc-top"><b>🏆 {e(founders.NAME)}</b>{state}</span>'
            f'<span class="fc-title">أول {founders.CAP} استراحة بدون عمولة لمدة سنة كاملة</span>'
            f'<span class="fc-nums"><span><b>{num(s["taken"])}</b> استفادت</span><span><b>{num(s["left"])}</b> المقاعد المتبقية</span>'
            f'<span><b>{s["cap"]}</b> الحد الأقصى</span></span><span class="fc-go">فتح التفاصيل والإحصاءات</span></a>')


def register(app) -> None:
    db = app.db

    def page(ctx: Ctx, title: str, body: str, status: int = 200):
        return html_page(ctx, title, body, status, noindex=True, admin=True, extra_class="admin")

    def tile(label: str, value, sub: str = "") -> str:
        return f'<div class="stat"><b>{value}</b><span>{e(label)}</span>' + (f"<small>{e(sub)}</small>" if sub else "") + "</div>"

    @app.route("GET", "/admin/offers/founders", "admin")
    async def founders_page(ctx: Ctx):
        today = ctx.today()
        s = founders.summary(db, today)
        state = tag("ok", "نشط") if s["on"] else tag("warn", "متوقف")

        # ---- the switch -------------------------------------------------------------------------------------
        if s["on"] and s["left"]:
            about = "الاستراحة التي يُعتمد إعلانها وينشر من الآن تأخذ مقعدًا وسنة بدون عمولة تلقائيًا، والإعلان ظاهر في الصفحة الرئيسية."
        elif s["on"]:
            about = f"اكتملت المقاعد ({s['cap']} من {s['cap']}): لا يُمنح إعفاء جديد، ويختفي الإعلان من الرئيسية."
        else:
            about = "لا تُمنح مقاعد جديدة ولا يظهر الإعلان في الرئيسية. الإعفاءات التي أُعطيت تستمر حتى تواريخ نهايتها."
        to, button = ("off", '<button class="btn ghost big" type="submit">إيقاف العرض</button>') if s["on"] else ("on", '<button class="btn sun big" type="submit">تفعيل العرض</button>')
        control = (f'<section class="panel"><h2>حالة العرض: {state}</h2><p>{e(about)}</p>'
                   f'<form method="post" action="/admin/offers/founders/toggle">{ui.csrf_input(ctx.csrf)}<input type="hidden" name="to" value="{to}">{button}</form></section>')

        # ---- the figures ------------------------------------------------------------------------------------
        ended = "منتهية: " + num(s["ended"])
        of_cap = f"من أصل {s['cap']} استراحة"
        stats = (f'<div class="stats">{ui.founders_countdown(s["left"])}{tile("استفادت من العرض", num(s["taken"]), of_cap)}'
                 f'{tile("إعفاءات سارية", num(s["active"]), ended)}</div>')
        waived = ""
        if s["waived_rentals"]:
            waived = (f'<p class="muted">عمليات تأجير معفاة داخل فترات الإعفاء: <b>{num(s["waived_rentals"])}</b>، والعمولة التي أُعفيت منها '
                      f'<b>{util.money(s["waived_halalas"])}</b> ر.س (لا تدخل في الأرباح).</p>')

        # ---- the adverts that got their year ---------------------------------------------------------------------
        today_iso = today.isoformat()
        cards = []
        for seat, r in enumerate(founders.beneficiaries(db), start=1):
            st = founders.state_of(r, today_iso)
            left = founders.days_text(r["ends_on"], today)
            cards.append(
                f'<li><a class="com-item" href="/admin/listing/{r["listing_id"]}"><span class="com-main"><span class="com-top"><b>مقعد {seat} · {e(r["title"])}</b>'
                f'{tag(founders.STATE_KIND[st], founders.STATE_LABELS[st])}</span><small>المالك: {e(r["owner_name"])} · {e(r["city"])}</small>'
                f'<small>بداية الإعفاء: {e(ui.day_text(r["starts_on"]))}</small>'
                f'<small>نهاية الإعفاء: {e(ui.day_text(r["ends_on"]))}{" · " + e(left) if left else ""}</small></span></a></li>')
        listing = (f'<ul class="com-list">{"".join(cards)}</ul>' if cards
                   else '<p class="muted">لا توجد استراحات مستفيدة بعد. تظهر هنا بأسمائها وتواريخ إعفائها حين يُعتمد أول إعلان والعرض نشط.</p>')

        # ---- the terms, the way it works, and the advert as visitors see it ---------------------------------------------
        terms = "".join(f"<li>{e(t)}</li>" for t in founders.TERMS_ADMIN)
        how = "".join(f"<li>{e(t)}</li>" for t in founders.HOW_ADMIN)
        preview = (f'<details class="more"><summary>معاينة الإعلان كما يراه الزوار</summary>{ui.founders_banner(s["taken"], s["left"])}'
                   '<p class="hint">يظهر في أعلى الصفحة الرئيسية بعد صندوق البحث، ويختفي وحده حين يتوقف العرض أو تكتمل المقاعد. '
                   'الأرقام فيه من السجلات الفعلية في كل زيارة.</p></details>')
        body = (f'{ui.notice("ok", ctx.flash())}<p><a href="/admin/offers">العروض والخصومات</a></p>'
                f'<div class="head"><h1>🏆 {e(founders.NAME)}</h1>{state}</div><p class="lead">{e(founders.TITLE)}</p><p class="muted">{e(founders.DESCRIPTION)}</p>'
                f'{control}{stats}{waived}<h2>الاستراحات المستفيدة</h2>{listing}{preview}'
                f'<details class="more"><summary>شروط العرض وآلية عمله</summary><ul class="how">{terms}</ul><h3>كيف يظهر في العمليات والأرباح</h3><ul class="how">{how}</ul></details>')
        return page(ctx, founders.NAME, body)

    @app.route("POST", "/admin/offers/founders/toggle", "admin")
    async def founders_toggle(ctx: Ctx):
        want = ctx.request.field("to")
        if want not in ("on", "off"):
            return redirect("/admin/offers/founders?msg=اختيار غير صحيح")
        if founders.is_on(db) == (want == "on"):
            return redirect("/admin/offers/founders?msg=" + ("العرض نشط أصلًا" if want == "on" else "العرض متوقف أصلًا"))
        founders.set_on(db, want == "on")
        db.audit(ctx.admin["id"], "founders_on" if want == "on" else "founders_off", f"المقاعد المتبقية {founders.left(db)} من {founders.CAP}")
        if want == "off":
            return redirect("/admin/offers/founders?msg=أوقفنا العرض: لا مقاعد جديدة ولا إعلان في الرئيسية، والإعفاءات القائمة تستمر")
        if not founders.left(db):
            return redirect("/admin/offers/founders?msg=فعّلنا العرض لكن المقاعد مكتملة، فلا يُمنح إعفاء جديد ولا يظهر الإعلان")
        return redirect("/admin/offers/founders?msg=فعّلنا العرض: كل استراحة يُعتمد إعلانها من الآن تنال سنة بدون عمولة، ويظهر الإعلان في الرئيسية")
