"""Paying the commission: the manager's bank details, an owner's report that he has transferred, and the earnings figures.

Money is whole halalas everywhere. Nothing here talks to a bank or to any payment service: the owner transfers from his own
banking app, tells the site he did, and the manager (who sees his own bank statement) confirms or refuses."""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta

from . import founders, util
from .db import Database

# what a rental's commission is right now. "reported" = the owner says he paid and the manager has not confirmed yet.
STATES = ("paid", "reported", "due", "late", "disputed", "waived")
STATE_LABELS = {"paid": "مدفوعة", "reported": "بانتظار تأكيد الإدارة", "due": "مستحقة", "late": "متأخرة", "disputed": "متنازع عليها", "waived": "معفاة"}
STATE_KIND = {"paid": "ok", "reported": "warn", "due": "warn", "late": "bad", "disputed": "bad", "waived": "muted"}
REPORT_LABELS = {"pending": "بانتظار التأكيد", "confirmed": "مؤكد", "rejected": "مرفوض", "withdrawn": "ملغى"}
REPORT_KIND = {"pending": "warn", "confirmed": "ok", "rejected": "bad", "withdrawn": "muted"}
MAX_PENDING_REPORTS = 5            # open reports one owner may have at the same time
MAX_ITEMS = 60                     # rentals in one report
MAX_REFERENCE = 80
MAX_REASON = 200
# what an owner may do when he writes a rental down himself (the manager has no such limits: he can write any rental, of any date)
OWNER_BACK_DAYS = 14               # he may date a rental up to this many days back; an older one is written down by the manager
OWNER_AHEAD_DAYS = 365             # ... and up to a year ahead (a booking made now for a later date)
OWNER_MAX_RENT = 1_000_000         # a rent above this is a slip of the finger, not a rest house
OWNER_PER_DAY = 20                 # rentals one owner may write down in a day
DOUBLE_TAP_SECONDS = 120           # the same rental written twice inside this time is one tap that was sent twice

PAY_KEYS = ("pay_holder", "pay_bank", "pay_iban", "pay_note", "pay_contact")


# ---- the manager's bank details (kept in the database settings, typed by him; never in the code) ---------------------------
def clean_iban(text: str) -> str | None:
    """A Saudi IBAN (SA and 22 digits) whose check digits are right, without spaces; None otherwise. A wrong digit would send an
    owner's money to a stranger, so the check number is verified, not only the length."""
    compact = re.sub(r"[\s\-]", "", util.clean_text(text)).upper()
    if not re.fullmatch(r"SA[0-9]{22}", compact):
        return None
    moved = compact[4:] + compact[:4]
    number = "".join(str(int(ch, 36)) for ch in moved)           # letters become 10..35
    return compact if int(number) % 97 == 1 else None


def show_iban(iban: str) -> str:
    return " ".join(iban[i:i + 4] for i in range(0, len(iban), 4))


def mask_iban(iban: str) -> str:
    return f"SA…{iban[-4:]}" if len(iban) >= 8 else ""


def pay_details(db: Database) -> dict:
    """{holder, bank, iban, note, contact}; an empty string for what the manager has not entered."""
    rows = {r["key"]: r["value"] for r in db.all(f"SELECT key, value FROM settings WHERE key IN ({','.join('?' * len(PAY_KEYS))})", PAY_KEYS)}
    return {key[4:]: rows.get(key, "") for key in PAY_KEYS}


def has_bank(details: dict) -> bool:
    return bool(details["holder"] and details["bank"] and details["iban"])


def save_pay_details(db: Database, values: dict) -> None:
    with db.transaction():
        for key in PAY_KEYS:
            db.put_setting(key, values.get(key[4:], ""))


# ---- the state of one rental --------------------------------------------------------------------------------------------
def reported_ids(db: Database) -> set[int]:
    """Rentals that are inside a report the manager has not decided yet."""
    return {r["rental_id"] for r in db.all(
        "SELECT i.rental_id FROM payment_report_items i JOIN payment_reports p ON p.id = i.report_id WHERE p.status = 'pending'")}


def state_of(row, today_iso: str, reported: set[int]) -> str | None:
    """paid / reported / due / late / disputed / waived, or None for a cancelled rental (it owes nothing)."""
    if row["status"] == "cancelled":
        return None
    pay = row["pay_status"]
    if pay in ("paid", "waived", "disputed"):
        return pay
    if row["id"] in reported:
        return "reported"
    return "late" if row["due_date"] < today_iso else "due"


# ---- earnings (the manager) ---------------------------------------------------------------------------------------------
def earnings(db: Database, today: date) -> dict:
    """What the manager earns, from the rentals he registered. `commission` leaves out the waived ones (never expected);
    `collected` is what is paid; `open` is the rest (due, late, reported and disputed)."""
    today_iso = today.isoformat()
    reported = reported_ids(db)
    totals = {s: 0 for s in STATES}
    counts = {s: 0 for s in STATES}
    months: dict[str, dict] = {}
    owners: dict[int, dict] = {}
    collected_now = 0
    for r in db.all("""SELECT r.id, r.owner_id, r.rent, r.commission_halalas, r.rental_date, r.status, r.pay_status, r.due_date, r.paid_at,
                              u.name AS owner_name FROM rentals r JOIN users u ON u.id = r.owner_id"""):
        state = state_of(r, today_iso, reported)
        if state is None:
            continue
        halalas = r["commission_halalas"]
        totals[state] += halalas
        counts[state] += 1
        if state == "paid" and r["paid_at"]:
            paid_day = datetime.fromtimestamp(r["paid_at"], util.SAUDI_TZ).date()
            if (paid_day.year, paid_day.month) == (today.year, today.month):
                collected_now += halalas
        for bucket, key in ((months, r["rental_date"][:7]), (owners, r["owner_id"])):
            row = bucket.setdefault(key, {"key": key, "name": r["owner_name"], "n": 0, "rent": 0, "commission": 0, "collected": 0, "late": 0})
            row["n"] += 1
            row["rent"] += r["rent"]
            if state == "waived":
                continue
            row["commission"] += halalas
            if state == "paid":
                row["collected"] += halalas
            elif state == "late":
                row["late"] += halalas
    for row in [*months.values(), *owners.values()]:
        row["open"] = row["commission"] - row["collected"]
    return {
        "totals": totals, "counts": counts, "collected_now": collected_now,
        "open": totals["due"] + totals["late"] + totals["reported"] + totals["disputed"],
        "months": sorted(months.values(), key=lambda m: m["key"], reverse=True),
        "owners": sorted(owners.values(), key=lambda o: (-o["open"], o["name"])),
    }


# ---- what an owner sees -------------------------------------------------------------------------------------------------
def owner_rentals(db: Database, owner_id: int) -> list:
    """The owner's own rentals that carry a commission (a cancelled one owes nothing and a zero commission has nothing to pay)."""
    return db.all("""SELECT r.*, l.title FROM rentals r JOIN listings l ON l.id = r.listing_id
                     WHERE r.owner_id = ? AND r.status != 'cancelled' AND r.commission_halalas > 0
                     ORDER BY r.rental_date DESC, r.id DESC LIMIT 500""", (owner_id,))


def owner_summary(db: Database, owner_id: int, today_iso: str) -> dict:
    """{state: halalas, ..., "count": rentals}: the figures of the card on the owner's front page."""
    reported = reported_ids(db)
    out = {s: 0 for s in STATES}
    out["count"] = 0
    for r in owner_rentals(db, owner_id):
        out[state_of(r, today_iso, reported)] += r["commission_halalas"]
        out["count"] += 1
    return out


# ---- a rental written down: by the manager, or by the owner himself -----------------------------------------------------------
def record_rental(db: Database, listing, rent: int, when: date, *, author_id: int, now: float, status: str = "confirmed", customer: str = "",
                  note: str = "", by_owner: bool = False) -> dict:
    """Writes one rental of an advert with the rate of ITS agreement as it is now (a later change of the general rate never touches it).
    A rental dated inside the advert's free year of the founders' offer owes nothing: it is recorded as waived, keeping the rate and the amount
    it would have had, like a commission the manager waives by hand. The manager's form and the owner's form both end here, so a rental is
    written the same way whoever writes it; `created_by` says who. Returns {id, halalas, free, basis_points, due_date}."""
    consent = db.one("SELECT * FROM consents WHERE id = ?", (listing["consent_id"],))
    halalas = util.to_halalas(util.commission(rent, consent["basis_points"]))
    due = when + timedelta(days=db.due_days())
    with db.transaction():
        free = founders.covering(db, listing["id"], when.isoformat())
        rid = db.run("""INSERT INTO rentals(listing_id, owner_id, consent_id, basis_points, rent, commission_halalas, rental_date, status, pay_status, due_date, created_at, created_by, customer)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""", (listing["id"], listing["owner_id"], consent["id"], consent["basis_points"], rent, halalas, when.isoformat(),
                                                                status, "waived" if free else "due", due.isoformat(), now, author_id, customer.strip()[:80]))
        lines = (["سجّلها المالك بنفسه"] if by_owner else []) \
            + ([f"معفاة من العمولة بعرض المؤسسين (من {free['starts_on']} إلى {free['ends_on']})"] if free else []) + ([note.strip()[:500]] if note.strip() else [])
        for text in lines:
            db.run("INSERT INTO rental_notes(rental_id, author_id, kind, body, created_at) VALUES (?, ?, 'note', ?, ?)", (rid, author_id, text, now))
        detail = f"رقم {rid} · إيجار {rent} · عمولة {util.percent_text(consent['basis_points'])}%" + (" · معفاة بعرض المؤسسين" if free else "")
        if by_owner:
            db.audit(author_id, "owner_rental_new", detail)
        else:
            db.audit(author_id, "rental_new", detail)
    return {"id": rid, "halalas": halalas, "free": free, "basis_points": consent["basis_points"], "due_date": due.isoformat()}


def by_owner(row) -> bool:
    """A rental the owner wrote down himself (the manager's own are created by an admin account)."""
    return row["created_by"] == row["owner_id"]


def owner_rental_problem(db: Database, owner_id: int, listing, rent: int | None, when: date | None, today: date, now: float) -> str:
    """Why this owner may not write this rental down, in words for him; "" when he may. The advert must be his own and published; the date
    must be a real one near today (so a rental cannot be moved into, or out of, a free year after the fact); and a flood of rentals is
    refused. The manager's own form has none of these limits."""
    if not listing or listing["owner_id"] != owner_id or listing["review"] != "approved":
        return "اختر استراحة من استراحاتك المنشورة"
    if rent is None:
        return f"اكتب قيمة الإيجار بالريال أرقامًا فقط، ولا تزيد على {OWNER_MAX_RENT:,}"
    if when is None:
        return "اكتب تاريخ الإيجار"
    if when < today - timedelta(days=OWNER_BACK_DAYS):
        return f"التاريخ أقدم من {OWNER_BACK_DAYS} يومًا. لتسجيل عملية أقدم تواصل مع الإدارة"
    if when > today + timedelta(days=OWNER_AHEAD_DAYS):
        return "التاريخ بعيد جدًا. اكتب تاريخ الإيجار الفعلي"
    if db.one("SELECT COUNT(*) AS n FROM rentals WHERE created_by = ? AND owner_id = ? AND created_at > ?", (owner_id, owner_id, now - 86400))["n"] >= OWNER_PER_DAY:
        return f"وصلت للحد اليومي لتسجيل العمليات ({OWNER_PER_DAY}). إذا عندك أكثر تواصل مع الإدارة"
    return ""


def just_recorded(db: Database, owner_id: int, listing_id: int, rent: int, when: date, now: float) -> int | None:
    """The number of the rental this owner wrote down moments ago with the same advert, rent and date, if any: one tap sent twice (a slow
    phone, a double press) must not be a second rental, and must not be a second commission."""
    row = db.one("""SELECT id FROM rentals WHERE listing_id = ? AND created_by = ? AND rental_date = ? AND rent = ? AND created_at > ?
                    ORDER BY id DESC LIMIT 1""", (listing_id, owner_id, when.isoformat(), rent, now - DOUBLE_TAP_SECONDS))
    return row["id"] if row else None


def same_day_rental(db: Database, listing_id: int, when: date):
    """A rental of this advert on this date that still stands (not cancelled), whoever wrote it, or None. One advert can be rented twice in a
    day (a morning and an evening period), so this never refuses: it makes the owner say so, and so a rental the manager already wrote down is
    not written a second time by the owner (two commissions for one rental)."""
    return db.one("SELECT id, rent FROM rentals WHERE listing_id = ? AND rental_date = ? AND status != 'cancelled' ORDER BY id LIMIT 1", (listing_id, when.isoformat()))


def reports_of(db: Database, owner_id: int, limit: int = 30) -> list:
    return db.all("SELECT * FROM payment_reports WHERE owner_id = ? ORDER BY id DESC LIMIT ?", (owner_id, limit))


# ---- reports: the owner says he transferred; the manager decides ------------------------------------------------------------
def create_report(db: Database, owner_id: int, rental_ids: list[int], paid_on: date | None, reference: str, today: date, now: float) -> tuple[int | None, str]:
    """(report id, "") or (None, what to tell the owner). The amount is added up here from the rentals; it is never taken from the form."""
    ids = sorted(set(rental_ids))
    if not ids:
        return None, "اختر عملية واحدة على الأقل"
    if len(ids) > MAX_ITEMS:
        return None, f"الحد الأعلى {MAX_ITEMS} عملية في البلاغ الواحد"
    if paid_on is None or paid_on > today or paid_on < today - timedelta(days=365):
        return None, "اكتب تاريخ التحويل الصحيح، ولا يكون بعد اليوم"
    reference = util.clean_text(reference)
    if len(reference) > MAX_REFERENCE:
        return None, f"رقم العملية أو الاسم طويل (الحد {MAX_REFERENCE} حرفًا)"
    with db.transaction():
        if db.one("SELECT COUNT(*) AS n FROM payment_reports WHERE owner_id = ? AND status = 'pending'", (owner_id,))["n"] >= MAX_PENDING_REPORTS:
            return None, "عندك بلاغات كثيرة بانتظار التأكيد. انتظر قرار الإدارة أو ألغِ بلاغًا قديمًا"
        marks = ",".join("?" * len(ids))
        rows = db.all(f"SELECT * FROM rentals WHERE owner_id = ? AND id IN ({marks})", (owner_id, *ids))
        reported = reported_ids(db)
        if len(rows) != len(ids) or any(r["pay_status"] != "due" or r["status"] == "cancelled" or r["commission_halalas"] <= 0 or r["id"] in reported for r in rows):
            return None, "بعض العمليات المختارة لم تعد متاحة للإبلاغ (سُدّدت أو أُبلغ عنها). حدّث الصفحة وأعد الاختيار"
        amount = sum(r["commission_halalas"] for r in rows)
        rid = db.run("INSERT INTO payment_reports(owner_id, amount_halalas, paid_on, reference, created_at) VALUES (?, ?, ?, ?, ?)",
                     (owner_id, amount, paid_on.isoformat(), reference, now))
        for rental_id in ids:
            db.run("INSERT INTO payment_report_items(report_id, rental_id) VALUES (?, ?)", (rid, rental_id))
        db.audit(owner_id, "payment_report", f"بلاغ {rid} · {util.money(amount)} ر.س")
    return rid, ""


def withdraw_report(db: Database, report_id: int, owner_id: int, now: float) -> bool:
    """The owner takes back a report that is still waiting (a wrong date, a wrong choice). True when it was his and still pending."""
    with db.transaction():
        row = db.one("SELECT * FROM payment_reports WHERE id = ? AND owner_id = ? AND status = 'pending'", (report_id, owner_id))
        if not row:
            return False
        db.run("UPDATE payment_reports SET status = 'withdrawn', decided_at = ? WHERE id = ?", (now, report_id))
        db.audit(owner_id, "payment_withdraw", f"بلاغ {report_id}")
    return True


def report_items(db: Database, report_id: int) -> list:
    return db.all("""SELECT r.*, l.title FROM payment_report_items i JOIN rentals r ON r.id = i.rental_id JOIN listings l ON l.id = r.listing_id
                     WHERE i.report_id = ? ORDER BY r.rental_date, r.id""", (report_id,))


def confirm_report(db: Database, report_id: int, admin_id: int, now: float) -> tuple[bool, int, int]:
    """The manager saw the money. Every rental of the report that is still unpaid becomes paid. (done, rentals marked paid, rentals that
    were already settled by hand meanwhile and were left as they are.)"""
    with db.transaction():
        report = db.one("SELECT * FROM payment_reports WHERE id = ? AND status = 'pending'", (report_id,))
        if not report:
            return False, 0, 0
        marked = settled = 0
        why = f"سداد مؤكد من بلاغ رقم {report_id} (تحويل بتاريخ {report['paid_on']}" + (f"، المرجع: {report['reference']}" if report["reference"] else "") + ")"
        for r in report_items(db, report_id):
            if r["pay_status"] in ("due", "disputed") and r["status"] != "cancelled":
                db.run("UPDATE rentals SET pay_status = 'paid', paid_at = ? WHERE id = ?", (now, r["id"]))
                db.run("INSERT INTO rental_notes(rental_id, author_id, kind, body, created_at) VALUES (?, ?, 'payment', ?, ?)", (r["id"], admin_id, why[:500], now))
                marked += 1
            else:
                settled += 1
        db.run("UPDATE payment_reports SET status = 'confirmed', decided_at = ?, decided_by = ? WHERE id = ?", (now, admin_id, report_id))
        db.audit(admin_id, "payment_confirm", f"بلاغ {report_id} · {util.money(report['amount_halalas'])} ر.س")
    return True, marked, settled


def reject_report(db: Database, report_id: int, admin_id: int, reason: str, now: float) -> bool:
    """The money did not arrive (or not all of it). The rentals go back to being due, and the owner reads the reason."""
    with db.transaction():
        report = db.one("SELECT * FROM payment_reports WHERE id = ? AND status = 'pending'", (report_id,))
        if not report:
            return False
        db.run("UPDATE payment_reports SET status = 'rejected', decided_at = ?, decided_by = ?, decision_note = ? WHERE id = ?",
               (now, admin_id, reason[:MAX_REASON], report_id))
        db.audit(admin_id, "payment_reject", f"بلاغ {report_id}")
    return True
