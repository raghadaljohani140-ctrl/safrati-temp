"""The founders' offer («عرض المؤسسين»): the first 100 adverts pay no commission for one full year, counted from the real records,
shown to the manager in his page «العروض» and to visitors on the home page, and kept apart from the discounts of «عروضي»."""
import re
import sqlite3
import tempfile
import threading
import unittest
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from istiraha import db as dbmod
from istiraha import founders, payments, util
from istiraha.db import Database

from .helpers import NOW, Case, Client, fake_jpeg

HEADLINE = "🎁 سجّل استراحتك الآن واحصل على سنة كاملة بدون عمولة — لأول 100 استراحة فقط!"       # the sentence of the offer, word for word
TITLE = "عرض المؤسسين — أول 100 استراحة بدون عمولة لمدة سنة كاملة!"
TODAY = date(2026, 10, 26)                   # the day of the test clock, in Riyadh
LAST = date(2027, 10, 25)                    # the last day of a year that starts on TODAY
ADD_ROW = "INSERT INTO founder_exemptions(listing_id, starts_on, ends_on, granted_at) VALUES (?, '2026-10-26', '2027-10-25', 1)"


def add_listings(db, n, review="approved", start=0):
    """`n` adverts straight into the database, each with its own agreement (what the pages would have made). Returns their ids."""
    owner = db.one("SELECT id FROM users WHERE login = 'bulk-owner'")
    uid = owner["id"] if owner else db.run("INSERT INTO users(role, login, name, pass_hash, created_at) VALUES ('owner', 'bulk-owner', 'مالك', 'x', 1)")
    ids = []
    for i in range(n):
        cid = db.run("INSERT INTO consents(owner_id, pledge_version, pledge_text, basis_points, accepted_at) VALUES (?, 1, 'x', 1000, 1)", (uid,))
        lid = db.run("""INSERT INTO listings(owner_id, consent_id, title, city_id, category_id, price, whatsapp, review, created_at, updated_at)
                        VALUES (?, ?, ?, 1, 1, 500, '966551234567', ?, 1, 1)""", (uid, cid, f"استراحة جماعية {start + i + 1}", review))
        db.run("UPDATE consents SET listing_id = ? WHERE id = ?", (lid, cid))
        ids.append(lid)
    return ids


class YearTests(unittest.TestCase):
    def test_a_year_ends_the_day_before_its_anniversary(self):
        cases = {date(2026, 10, 28): date(2027, 10, 27), date(2026, 10, 26): date(2027, 10, 25), date(2026, 1, 1): date(2026, 12, 31),
                 date(2026, 12, 31): date(2027, 12, 30), date(2027, 3, 1): date(2028, 2, 29), date(2027, 2, 28): date(2028, 2, 27),
                 date(2028, 2, 28): date(2029, 2, 27), date(2028, 2, 29): date(2029, 2, 28)}
        for start, end in cases.items():
            self.assertEqual(founders.last_day(start), end, start)

    def test_a_year_is_never_shorter_than_a_year_whatever_the_day_it_starts(self):
        day = date(2026, 1, 1)
        while day < date(2032, 1, 1):                            # six years: leap days, the last day of every month, 29 February
            length = (founders.last_day(day) - day).days + 1       # both the first and the last day count
            self.assertIn(length, (365, 366), day)
            day += timedelta(days=1)

    def test_the_year_is_still_running_on_its_last_day_and_over_the_day_after(self):
        row = {"ends_on": "2027-10-25"}
        self.assertEqual(founders.state_of(row, "2026-10-26"), "active")
        self.assertEqual(founders.state_of(row, "2027-10-25"), "active")
        self.assertEqual(founders.state_of(row, "2027-10-26"), "ended")
        self.assertEqual((founders.STATE_LABELS["active"], founders.STATE_LABELS["ended"]), ("ساري", "منتهٍ"))

    def test_what_is_left_of_the_year_in_words(self):
        today = date(2027, 10, 20)
        self.assertEqual(founders.days_text("2027-10-25", today), "متبقي 5 أيام")
        self.assertEqual(founders.days_text("2027-10-22", today), "متبقي يومان")
        self.assertEqual(founders.days_text("2027-10-21", today), "ينتهي غدًا")
        self.assertEqual(founders.days_text("2027-10-20", today), "ينتهي اليوم")
        self.assertEqual(founders.days_text("2027-10-19", today), "")
        self.assertEqual(founders.days_text("2028-10-19", today), "متبقي 365 يومًا")

    def test_the_words_of_the_offer_are_the_ones_that_were_asked_for(self):
        self.assertEqual(founders.HEADLINE, HEADLINE)
        self.assertEqual(founders.TITLE, TITLE)
        self.assertEqual(len(founders.TERMS_ADMIN), 7)                       # the seven rules of the offer
        self.assertEqual(founders.CAP, 100)


class CapTests(unittest.TestCase):
    def setUp(self):
        self.db = Database(":memory:")
        self.addCleanup(self.db.close)

    def test_a_hundred_adverts_get_their_year_and_the_next_one_does_not(self):
        ids = add_listings(self.db, 101)
        results = [founders.grant(self.db, i, TODAY, NOW) for i in ids]
        self.assertEqual(results, [True] * 100 + [False])
        self.assertEqual((founders.taken(self.db), founders.left(self.db)), (100, 0))
        self.assertIsNone(founders.exemption_of(self.db, ids[100]))
        founders.set_on(self.db, True)
        self.assertFalse(founders.running(self.db))                         # switched on, but no seat is free: nothing to advertise

    def test_the_database_itself_refuses_a_hundred_and_first_row(self):
        ids = add_listings(self.db, 101)
        for lid in ids[:100]:
            self.db.run(ADD_ROW, (lid,))
        with self.assertRaises(sqlite3.IntegrityError) as caught:           # not through founders.grant: straight into the table
            self.db.run(ADD_ROW, (ids[100],))
        self.assertIn("full", str(caught.exception))
        self.assertEqual(founders.taken(self.db), 100)

    def test_the_number_in_the_database_and_the_number_in_the_code_are_the_same(self):
        self.assertIn(f"(SELECT COUNT(*) FROM founder_exemptions) >= {founders.CAP} BEGIN", dbmod.MIGRATION_V4)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM sqlite_master WHERE name = 'founder_exemptions_cap'")["n"], 1)

    def test_one_advert_gets_one_year_only(self):
        lid = add_listings(self.db, 1)[0]
        self.assertTrue(founders.grant(self.db, lid, TODAY, NOW))
        self.assertFalse(founders.grant(self.db, lid, TODAY + timedelta(days=30), NOW))       # asking again changes nothing
        row = founders.exemption_of(self.db, lid)
        self.assertEqual((row["starts_on"], row["ends_on"]), ("2026-10-26", "2027-10-25"))
        self.assertEqual(founders.taken(self.db), 1)
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.run(ADD_ROW, (lid,))

    def test_only_an_approved_advert_can_get_a_year(self):
        pending, rejected, stopped = (add_listings(self.db, 1, review=r, start=i)[0] for i, r in enumerate(("pending", "rejected", "stopped")))
        for lid in (pending, rejected, stopped, 99999):
            self.assertFalse(founders.grant(self.db, lid, TODAY, NOW), lid)
        self.assertEqual(founders.taken(self.db), 0)

    def test_a_year_cannot_end_before_it_starts(self):
        lid = add_listings(self.db, 1)[0]
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.run("INSERT INTO founder_exemptions(listing_id, starts_on, ends_on, granted_at) VALUES (?, '2026-10-26', '2026-10-25', 1)", (lid,))

    def test_the_figures_are_counted_from_the_rows(self):
        ids = add_listings(self.db, 3)
        founders.grant(self.db, ids[0], date(2026, 1, 10), NOW)
        founders.grant(self.db, ids[1], date(2026, 6, 1), NOW)
        founders.grant(self.db, ids[2], TODAY, NOW)
        s = founders.summary(self.db, TODAY)
        self.assertEqual((s["taken"], s["left"], s["active"], s["ended"], s["cap"]), (3, 97, 3, 0, 100))
        s = founders.summary(self.db, date(2027, 1, 11))                        # the first year ended on 2027-01-09
        self.assertEqual((s["taken"], s["left"], s["active"], s["ended"]), (3, 97, 2, 1))

    def test_two_connections_racing_for_the_last_seats_never_give_out_more_than_a_hundred(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        path = Path(tmp.name) / "race.db"
        first = Database(path)
        self.addCleanup(first.close)
        ids = add_listings(first, 112)
        for lid in ids[:95]:
            first.run(ADD_ROW, (lid,))
        candidates = ids[95:]                                                   # 17 adverts for 5 seats
        wins, barrier = [], threading.Barrier(4)

        def work(mine):
            conn = Database(path)
            try:
                barrier.wait()
                for lid in mine:
                    if founders.grant(conn, lid, TODAY, NOW):
                        wins.append(lid)
            finally:
                conn.close()

        threads = [threading.Thread(target=work, args=(candidates[i::4],)) for i in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(30)
        self.assertEqual(len(wins), 5)
        self.assertEqual(founders.taken(first), 100)


class FoundersCase(Case):
    async def login_admin(self, login="manager", password="Str0ng-pass!"):
        client = Client(self.app, "198.51.100.9")
        await client.get("/admin/login")
        r = await client.post("/admin/login", {"login": login, "password": password})
        self.assertEqual(r.status, 303)
        return client

    async def login_owner(self, phone="0551234567", password="Owner-pass-1", ip="203.0.113.50"):
        client = Client(self.app, ip)
        await client.get("/owner/login")
        r = await client.post("/owner/login", {"phone": phone, "password": password})
        self.assertEqual(r.status, 303, client.text[:300])
        return client

    async def publish(self, owner, title="استراحة النخيل", **kw):
        """An advert that goes live by itself, the way a real one does: added, then its first picture."""
        lid = await self.add_listing(owner, title=title, **kw)
        r = await owner.post(f"/owner/listing/{lid}/photo", files=[("photo", "x.jpg", fake_jpeg())], page=f"/owner/listing/{lid}")
        self.assertEqual(r.status, 303)
        return lid

    async def second_owner(self, title="مزرعة الواحة"):
        owner = await self.make_owner(phone="0559876543", name="أبو خالد", ip="203.0.113.51")
        return owner, await self.publish(owner, title=title, whatsapp="0559876543")

    async def rent(self, admin, lid, day, rent=500):
        r = await admin.post("/admin/rental/new", {"listing": str(lid), "rent": str(rent), "date": day, "status": "confirmed"}, page="/admin/rental/new")
        self.assertEqual(r.status, 303, admin.text[:300])
        return self.db.one("SELECT MAX(id) AS i FROM rentals")["i"]

    def rental(self, rid):
        return self.db.one("SELECT * FROM rentals WHERE id = ?", (rid,))

    def exemption(self, lid):
        return founders.exemption_of(self.db, lid)

    def review(self, lid):
        return self.db.one("SELECT review FROM listings WHERE id = ?", (lid,))["review"]


class SwitchTests(FoundersCase):
    async def test_it_starts_switched_off_and_nothing_shows_and_nothing_is_given(self):
        admin = await self.make_admin()
        owner = await self.make_owner()
        self.assertFalse(founders.is_on(self.db))
        lid = await self.publish(owner)
        self.assertEqual(self.review(lid), "approved")
        self.assertIsNone(self.exemption(lid))
        await self.visitor.get("/")
        self.assertNotIn("founders", self.visitor.text)
        self.assertNotIn("عرض المؤسسين", self.visitor.text)
        await admin.get("/admin/listing/" + str(lid))
        self.assertNotIn("عرض المؤسسين", admin.text)                       # an offer never used leaves the pages as they were
        await admin.get("/admin/offers/founders")
        self.assertIn("متوقف", admin.text)

    async def test_the_manager_switches_it_on_and_off_and_the_advert_follows(self):
        admin = await self.make_admin()
        r = await admin.post("/admin/offers/founders/toggle", {"to": "on"}, page="/admin/offers/founders")
        self.assertEqual(r.status, 303)
        self.assertIn("فعّلنا العرض", await admin.message())
        self.assertTrue(founders.is_on(self.db))
        await self.visitor.get("/")
        self.assertIn(HEADLINE, self.visitor.text)
        await admin.post("/admin/offers/founders/toggle", {"to": "off"}, page="/admin/offers/founders")
        self.assertIn("أوقفنا العرض", await admin.message())
        self.assertFalse(founders.is_on(self.db))
        await self.visitor.get("/")
        self.assertNotIn(HEADLINE, self.visitor.text)
        actions = [a["action"] for a in self.db.all("SELECT action FROM audit")]
        self.assertEqual((actions.count("founders_on"), actions.count("founders_off")), (1, 1))

    async def test_asking_for_the_state_it_already_has_changes_nothing_and_a_wrong_value_is_refused(self):
        admin = await self.make_admin()
        await admin.post("/admin/offers/founders/toggle", {"to": "on"}, page="/admin/offers/founders")
        await admin.post("/admin/offers/founders/toggle", {"to": "on"}, page="/admin/offers/founders")        # a second tap on a slow phone
        self.assertIn("نشط أصلًا", await admin.message())
        await admin.post("/admin/offers/founders/toggle", {"to": "maybe"}, page="/admin/offers/founders")
        self.assertIn("اختيار غير صحيح", await admin.message())
        await admin.post("/admin/offers/founders/toggle", {}, page="/admin/offers/founders")
        self.assertTrue(founders.is_on(self.db))
        self.assertEqual([a["action"] for a in self.db.all("SELECT action FROM audit")].count("founders_on"), 1)

    async def test_only_the_manager_can_open_or_change_it(self):
        owner = await self.make_owner()
        for client in (self.visitor, owner):
            r = await client.get("/admin/offers/founders")
            self.assertEqual((r.status, r.headers["Location"]), (303, "/admin/login"))
            r = await client.go("POST", "/admin/offers/founders/toggle", {"to": "on"})
            self.assertEqual(r.status, 303)
            r = await client.go("POST", "/admin/listing/1/founders", {})
            self.assertEqual(r.status, 303)
        self.assertFalse(founders.is_on(self.db))
        admin = await self.make_admin()
        await admin.get("/admin/offers/founders")
        r = await admin.go("POST", "/admin/offers/founders/toggle", {"to": "on", "_csrf": "not-the-token"})
        self.assertEqual(r.status, 403)
        r = await admin.go("POST", "/admin/offers/founders/toggle", {"to": "on"})
        self.assertEqual(r.status, 403)
        self.assertFalse(founders.is_on(self.db))

    async def test_the_box_on_the_managers_offers_page_leads_to_the_page_and_shows_the_figures(self):
        admin = await self.make_admin()
        await admin.get("/admin/offers")
        self.assertIn('<a class="founders-card" href="/admin/offers/founders">', admin.text)
        self.assertIn("🏆 عرض المؤسسين", admin.text)
        self.assertIn('<span class="tag warn">متوقف</span>', admin.text)
        self.assertIn("<b>0</b> استفادت", admin.text)
        self.assertIn("<b>100</b> المقاعد المتبقية", admin.text)
        founders.set_on(self.db, True)
        owner = await self.make_owner()
        await self.publish(owner)
        await admin.get("/admin/offers")
        self.assertIn('<span class="tag ok">نشط</span>', admin.text)
        self.assertIn("<b>1</b> استفادت", admin.text)
        self.assertIn("<b>99</b> المقاعد المتبقية", admin.text)
        self.assertLess(admin.text.index("founders-card"), admin.text.index("خصومات الاستراحات"))        # a box of its own, above the discounts


class GrantTests(FoundersCase):
    async def test_an_advert_that_goes_live_while_it_is_on_gets_a_year_starting_that_day(self):
        admin = await self.make_admin()
        founders.set_on(self.db, True)
        owner = await self.make_owner()
        lid = await self.publish(owner)
        row = self.exemption(lid)
        self.assertEqual((row["starts_on"], row["ends_on"], row["granted_at"], row["granted_by"]), ("2026-10-26", "2027-10-25", NOW, None))
        entry = self.db.one("SELECT * FROM audit WHERE action = 'founders_grant'")
        self.assertIn("استراحة النخيل", entry["detail"])
        self.assertIn("مقعد 1 من 100", entry["detail"])
        self.assertIn("2026-10-26", entry["detail"])
        await admin.get("/admin")
        self.assertIn("منح إعفاء المؤسسين", admin.text)                       # in Arabic in the latest operations

    async def test_an_advert_that_was_already_live_is_not_given_a_year_by_itself(self):
        owner = await self.make_owner()
        lid = await self.publish(owner)                                          # live before the offer started
        founders.set_on(self.db, True)
        await owner.post(f"/owner/listing/{lid}/photo", files=[("photo", "y.jpg", fake_jpeg())], page=f"/owner/listing/{lid}")
        self.assertIsNone(self.exemption(lid))
        self.assertEqual(founders.taken(self.db), 0)

    async def test_the_manager_can_give_such_an_advert_its_year_by_hand_once(self):
        admin = await self.make_admin()
        owner = await self.make_owner()
        lid = await self.publish(owner)
        r = await admin.post(f"/admin/listing/{lid}/founders", page=f"/admin/listing/{lid}")           # the offer is off: refused
        self.assertIn("العرض متوقف", await admin.message())
        self.assertIsNone(self.exemption(lid))
        founders.set_on(self.db, True)
        await admin.get(f"/admin/listing/{lid}")
        self.assertIn("منح الإعفاء لهذا الإعلان", admin.text)
        self.assertIn("المقاعد المتبقية: <b>100</b>", admin.text)
        r = await admin.post(f"/admin/listing/{lid}/founders", page=f"/admin/listing/{lid}")
        self.assertEqual(r.status, 303)
        self.assertIn("منحنا الإعلان إعفاء المؤسسين: من 26 أكتوبر 2026 إلى 25 أكتوبر 2027", await admin.message())
        row = self.exemption(lid)
        self.assertEqual((row["starts_on"], row["ends_on"], row["granted_by"]), ("2026-10-26", "2027-10-25", self.db.one("SELECT id FROM users WHERE role = 'admin'")["id"]))
        await admin.get(f"/admin/listing/{lid}")
        self.assertNotIn("منح الإعفاء لهذا الإعلان", admin.text)
        self.assertIn("بداية الإعفاء", admin.text)
        self.assertIn("25 أكتوبر 2027", admin.text)
        self.assertIn('<span class="tag ok">ساري</span>', admin.text)
        await admin.post(f"/admin/listing/{lid}/founders", page=f"/admin/listing/{lid}")                # a second time: nothing new
        self.assertIn("نال إعفاءه من قبل", await admin.message())
        self.assertEqual(founders.taken(self.db), 1)

    async def test_an_advert_that_is_not_approved_has_to_wait_for_its_approval(self):
        admin = await self.make_admin()
        founders.set_on(self.db, True)
        owner = await self.make_owner()
        lid = await self.add_listing(owner)                                       # no picture yet: pending
        await admin.get(f"/admin/listing/{lid}")
        self.assertIn("الإعلان غير معتمد بعد", admin.text)
        self.assertNotIn("منح الإعفاء لهذا الإعلان", admin.text)
        await admin.post(f"/admin/listing/{lid}/founders", page=f"/admin/listing/{lid}")
        self.assertIn("غير معتمد بعد", await admin.message())
        self.assertIsNone(self.exemption(lid))
        r = await admin.post("/admin/listing/99999/founders", page=f"/admin/listing/{lid}")
        self.assertEqual(r.status, 404)

    async def test_when_the_manager_reviews_every_advert_the_year_comes_with_his_approval(self):
        admin = await self.make_admin()
        self.db.set_auto_publish(False)
        founders.set_on(self.db, True)
        owner = await self.make_owner()
        lid = await self.publish(owner)                                          # a picture alone publishes nothing now
        self.assertEqual(self.review(lid), "pending")
        self.assertIsNone(self.exemption(lid))
        await admin.post(f"/admin/listing/{lid}/approve", page=f"/admin/listing/{lid}")
        self.assertIn("ونال الإعلان إعفاء المؤسسين حتى 25 أكتوبر 2027", await admin.message())
        row = self.exemption(lid)
        self.assertEqual((row["starts_on"], row["ends_on"]), ("2026-10-26", "2027-10-25"))
        self.assertEqual(row["granted_by"], self.db.one("SELECT id FROM users WHERE role = 'admin'")["id"])
        await admin.post(f"/admin/listing/{lid}/approve", page=f"/admin/listing/{lid}")                 # approving it again changes nothing
        self.assertEqual(founders.taken(self.db), 1)

    async def test_approving_an_advert_that_was_already_live_does_not_use_a_seat(self):
        admin = await self.make_admin()
        owner = await self.make_owner()
        lid = await self.publish(owner)                                          # live while the offer was off
        founders.set_on(self.db, True)
        await admin.post(f"/admin/listing/{lid}/approve", page=f"/admin/listing/{lid}")
        self.assertEqual(await admin.message(), "تم")
        self.assertIsNone(self.exemption(lid))

    async def test_a_stopped_or_rejected_advert_gets_its_year_when_it_is_approved_again_not_before(self):
        admin = await self.make_admin()
        owner = await self.make_owner()
        stopped = await self.publish(owner, title="استراحة موقوفة")
        rejected = await self.publish(owner, title="استراحة مرفوضة")
        await admin.post(f"/admin/listing/{stopped}/stop", {"note": "مخالفة"}, page=f"/admin/listing/{stopped}")
        await admin.post(f"/admin/listing/{rejected}/reject", {"note": "ناقص"}, page=f"/admin/listing/{rejected}")
        founders.set_on(self.db, True)
        self.assertEqual((founders.taken(self.db), self.exemption(stopped), self.exemption(rejected)), (0, None, None))
        for lid in (stopped, rejected):
            await admin.post(f"/admin/listing/{lid}/approve", page=f"/admin/listing/{lid}")
            self.assertIsNotNone(self.exemption(lid))
        self.assertEqual(founders.taken(self.db), 2)

    async def test_an_advert_edited_and_approved_again_keeps_its_year_and_takes_no_second_seat(self):
        admin = await self.make_admin()
        self.db.set_auto_publish(False)
        founders.set_on(self.db, True)
        owner = await self.make_owner()
        lid = await self.publish(owner)
        await admin.post(f"/admin/listing/{lid}/approve", page=f"/admin/listing/{lid}")
        first = dict(self.exemption(lid))
        self.clock.t = NOW + 20 * 86400                                           # twenty days later the owner changes the title
        owner = await self.login_owner()
        form = {"title": "استراحة النخيل الجديدة", "city": "1", "category": "1", "price": "800", "unit": "night", "whatsapp": "0551234567",
                "district": "حي الياسمين", "description": "استراحة هادئة مع مسبح كبير.", "amenities": ["1", "2"]}
        await owner.post(f"/owner/listing/{lid}/edit", form, page=f"/owner/listing/{lid}/edit")
        self.assertEqual(self.review(lid), "pending")                             # back to the manager, as before the offer existed
        admin = await self.login_admin()
        await admin.post(f"/admin/listing/{lid}/approve", page=f"/admin/listing/{lid}")
        self.assertEqual(await admin.message(), "تم")                              # nothing new was given
        self.assertEqual(dict(self.exemption(lid)), first)
        self.assertEqual(founders.taken(self.db), 1)

    async def test_stopping_and_restoring_an_advert_does_not_move_its_year(self):
        admin = await self.make_admin()
        founders.set_on(self.db, True)
        owner = await self.make_owner()
        lid = await self.publish(owner)
        first = dict(self.exemption(lid))
        await admin.post(f"/admin/listing/{lid}/stop", {"note": "مراجعة"}, page=f"/admin/listing/{lid}")
        self.clock.t = NOW + 20 * 86400
        admin = await self.login_admin()
        await admin.post(f"/admin/listing/{lid}/approve", page=f"/admin/listing/{lid}")
        self.assertEqual(self.review(lid), "approved")
        self.assertEqual(dict(self.exemption(lid)), first)                         # still 2026-10-26 to 2027-10-25: the year runs on the calendar
        self.assertEqual(founders.taken(self.db), 1)
        await admin.get(f"/admin/listing/{lid}")
        self.assertIn("26 أكتوبر 2026", admin.text)
        self.assertIn("25 أكتوبر 2027", admin.text)

    async def test_switching_to_automatic_publishing_gives_the_waiting_adverts_their_years_in_order(self):
        admin = await self.make_admin()
        self.db.set_auto_publish(False)
        founders.set_on(self.db, True)
        owner = await self.make_owner()
        first, second = await self.publish(owner, title="الأولى"), await self.publish(owner, title="الثانية")
        self.assertEqual((founders.taken(self.db), self.review(first), self.review(second)), (0, "pending", "pending"))
        await admin.post("/admin/publishing", {"mode": "auto"}, page="/admin/settings")
        self.assertIn("نشرنا 2 إعلانًا", await admin.message())
        self.assertEqual([r["listing_id"] for r in self.db.all("SELECT listing_id FROM founder_exemptions ORDER BY id")], [first, second])
        self.assertEqual(self.exemption(first)["granted_by"], None)

    async def test_every_advert_has_its_own_dates(self):
        await self.make_admin()
        founders.set_on(self.db, True)
        owner = await self.make_owner()
        first = await self.publish(owner, title="الاستراحة الأولى")
        self.clock.t = NOW + 10 * 86400 + 3600                                    # ten days later
        second = await self.publish(await self.login_owner(), title="الاستراحة الثانية")
        a, b = self.exemption(first), self.exemption(second)
        self.assertEqual((a["starts_on"], a["ends_on"]), ("2026-10-26", "2027-10-25"))
        self.assertEqual((b["starts_on"], b["ends_on"]), ("2026-11-05", "2027-11-04"))      # a year from ITS day, not from the day the offer started
        admin = await self.login_admin()
        await admin.get("/admin/offers/founders")
        self.assertIn("مقعد 1 · الاستراحة الأولى", admin.text)
        self.assertIn("مقعد 2 · الاستراحة الثانية", admin.text)
        self.assertLess(admin.text.index("الاستراحة الأولى"), admin.text.index("الاستراحة الثانية"))

    async def test_the_day_is_the_day_in_riyadh(self):
        founders.set_on(self.db, True)
        owner = await self.make_owner()
        self.clock.t = datetime(2026, 11, 10, 22, 30, tzinfo=timezone.utc).timestamp()          # 01:30 on the 11th in Riyadh
        lid = await self.publish(await self.login_owner())
        self.assertEqual((self.exemption(lid)["starts_on"], self.exemption(lid)["ends_on"]), ("2026-11-11", "2027-11-10"))

    async def test_a_year_running_and_a_year_over_are_told_apart_by_the_day(self):
        await self.make_admin()                                                    # (a year later the sessions are gone: both sign in again)
        founders.set_on(self.db, True)
        owner = await self.make_owner()
        lid = await self.publish(owner)
        self.clock.t = NOW + 364 * 86400                                          # 2027-10-25, the last day of the year
        admin = await self.login_admin()
        await admin.get("/admin/offers/founders")
        self.assertIn('<span class="tag ok">ساري</span>', admin.text)
        self.assertIn("ينتهي اليوم", admin.text)
        self.assertIn("إعفاءات سارية</span><small>منتهية: 0</small>", admin.text)
        self.clock.t = NOW + 365 * 86400                                          # 2027-10-26, the day after
        admin = await self.login_admin()
        await admin.get("/admin/offers/founders")
        self.assertIn('<span class="tag muted">منتهٍ</span>', admin.text)
        self.assertNotIn('<span class="tag ok">ساري</span>', admin.text)
        self.assertIn("<b>0</b><span>إعفاءات سارية</span><small>منتهية: 1</small>", admin.text)
        s = founders.summary(self.db, util.today(self.clock))
        self.assertEqual((s["taken"], s["active"], s["ended"]), (1, 0, 1))        # the seat stays used: the offer is for the first hundred, once
        owner = await self.login_owner()
        await owner.get("/owner")
        self.assertIn("انتهت سنة الإعفاء", owner.text)
        self.assertIn("انتهى إعفاؤها في 25 أكتوبر 2027، وتُحسب العمولة المتفق عليها", owner.text)

    async def test_pausing_the_offer_keeps_the_years_already_given_and_gives_no_new_ones(self):
        admin = await self.make_admin()
        founders.set_on(self.db, True)
        owner = await self.make_owner()
        lid = await self.publish(owner)
        await admin.post("/admin/offers/founders/toggle", {"to": "off"}, page="/admin/offers/founders")
        later = await self.publish(owner, title="استراحة بعد الإيقاف")
        self.assertIsNone(self.exemption(later))
        self.assertIsNotNone(self.exemption(lid))
        rid = await self.rent(admin, lid, "2026-11-02")
        self.assertEqual(self.rental(rid)["pay_status"], "waived")               # his year goes on while the offer is paused
        await self.visitor.get("/")
        self.assertNotIn("founders", self.visitor.text)
        await admin.post("/admin/offers/founders/toggle", {"to": "on"}, page="/admin/offers/founders")
        self.assertIsNone(self.exemption(later))                                   # switching it on again is not retroactive either
        self.assertEqual(founders.taken(self.db), 1)

    async def test_granting_touches_nothing_else_of_the_advert_or_the_agreement(self):
        founders.set_on(self.db, True)
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        before_listing = dict(self.db.one("SELECT * FROM listings WHERE id = ?", (lid,)))
        consent = dict(self.db.one("SELECT * FROM consents"))
        users = [dict(r) for r in self.db.all("SELECT * FROM users ORDER BY id")]
        await owner.post(f"/owner/listing/{lid}/photo", files=[("photo", "x.jpg", fake_jpeg())], page=f"/owner/listing/{lid}")
        after_listing = dict(self.db.one("SELECT * FROM listings WHERE id = ?", (lid,)))
        changed = {k for k in before_listing if before_listing[k] != after_listing[k]}
        self.assertEqual(changed - {"updated_at"}, {"review", "approved_at"})      # exactly what publishing always did: nothing of the advert itself
        self.assertEqual(dict(self.db.one("SELECT * FROM consents")), consent)
        self.assertEqual([dict(r) for r in self.db.all("SELECT * FROM users ORDER BY id")], users)
        self.assertEqual((self.db.commission_bp(), consent["basis_points"]), (1000, 1000))


class SeatsTests(FoundersCase):
    async def fill(self, n, start=0):
        for lid in add_listings(self.db, n, start=start):
            self.assertTrue(founders.grant(self.db, lid, TODAY, NOW))

    async def test_the_hundredth_advert_gets_the_last_seat_and_the_next_one_gets_none(self):
        admin = await self.make_admin()
        founders.set_on(self.db, True)
        await self.fill(98)
        owner = await self.make_owner()
        last = await self.publish(owner, title="الاستراحة رقم 99")
        one_more = await self.publish(owner, title="الاستراحة رقم 100")
        beyond = await self.publish(owner, title="الاستراحة رقم 101")
        self.assertIsNotNone(self.exemption(last))
        self.assertIsNotNone(self.exemption(one_more))
        self.assertIsNone(self.exemption(beyond))                                  # the 101st is published like any advert, without a free year
        self.assertEqual(self.review(beyond), "approved")
        self.assertEqual((founders.taken(self.db), founders.left(self.db)), (100, 0))
        # the manager cannot give it one by hand either
        r = await admin.post(f"/admin/listing/{beyond}/founders", page=f"/admin/listing/{beyond}")
        self.assertIn("اكتملت المقاعد", await admin.message())
        self.assertIsNone(self.exemption(beyond))
        await admin.get(f"/admin/listing/{beyond}")
        self.assertIn("اكتملت المقاعد (100 من 100)", admin.text)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM founder_exemptions")["n"], 100)

    async def test_the_advert_disappears_from_the_home_page_when_the_seats_are_full(self):
        admin = await self.make_admin()
        founders.set_on(self.db, True)
        await self.fill(99)
        await self.visitor.get("/")
        self.assertIn(HEADLINE, self.visitor.text)
        self.assertIn('<p class="fd-left"><b>1</b><span>المقاعد المتبقية من 100</span></p>', self.visitor.text)
        await self.fill(1, start=500)
        await self.visitor.get("/")
        self.assertNotIn(HEADLINE, self.visitor.text)
        self.assertNotIn("founders", self.visitor.text)
        await admin.get("/admin/offers/founders")
        self.assertIn("اكتملت المقاعد (100 من 100)", admin.text)
        self.assertIn("<b>100</b><span>استفادت من العرض</span>", admin.text)
        self.assertIn("<b>0</b><span>المقاعد المتبقية من 100</span>", admin.text)             # the big number has reached zero
        self.assertIn('<progress class="meter" max="100" value="0" ', admin.text)               # and the bar is empty
        self.assertIn("مقعد 100 · ", admin.text)
        await admin.get("/admin/offers")
        self.assertIn("<b>0</b> المقاعد المتبقية", admin.text)

    async def test_the_number_on_the_home_page_is_counted_at_each_visit_from_the_real_records(self):
        founders.set_on(self.db, True)
        owner = await self.make_owner()
        for n in range(0, 4):
            await self.visitor.get("/")
            html = self.visitor.text
            self.assertIn(f'<p class="fd-left"><b>{100 - n}</b><span>المقاعد المتبقية من 100</span></p>', html)
            self.assertIn(f'<progress class="meter" max="100" value="{100 - n}" aria-label="المقاعد المتبقية {100 - n} من 100">', html)     # the bar drains with the number
            self.assertNotIn("<i class=on>", html)                                  # no grid of squares: the number and one bar
            self.assertIn("كن أول من ينال هذا العرض" if n == 0 else f"استفادت {n} استراحة حتى الآن", html)
            await self.publish(owner, title=f"استراحة {n}")
        await self.visitor.get("/?left=5&taken=95")                               # nothing in the address changes the number
        self.assertIn('<b>96</b><span>المقاعد المتبقية من 100</span>', self.visitor.text)

    async def test_a_hundred_cards_are_listed_to_the_manager_in_the_order_of_the_seats(self):
        admin = await self.make_admin()
        founders.set_on(self.db, True)
        await self.fill(100)
        await admin.get("/admin/offers/founders")
        seats = [int(n) for n in re.findall(r"مقعد (\d+) · استراحة جماعية", admin.text)]
        self.assertEqual(seats, list(range(1, 101)))


CSS = (Path(__file__).resolve().parent.parent / "istiraha" / "static" / "app.css").read_text(encoding="utf-8")


class CountdownTests(FoundersCase):
    """The seats left are one big number that goes down by one with every advert that takes a seat, over a single thin bar:
    the manager's page and the advert show the same number, and nothing draws the hundred little squares any more."""

    HERO = '<div class="stat big countdown"><b>{n}</b><span>المقاعد المتبقية من 100</span><progress class="meter" max="100" value="{n}" '

    async def test_the_manager_sees_one_big_number_that_goes_down_with_every_seat(self):
        admin = await self.make_admin()
        founders.set_on(self.db, True)
        owner = await self.make_owner()
        for taken in range(0, 4):
            await admin.get("/admin/offers/founders")
            html = admin.text
            self.assertIn(self.HERO.format(n=100 - taken), html)
            self.assertEqual(html.count('class="stat big countdown"'), 1)           # one number, not two
            self.assertIn(f"<b>{taken}</b><span>استفادت من العرض</span><small>من أصل 100 استراحة</small>", html)
            self.assertNotIn(f"<b>{100 - taken}</b><span>المقاعد المتبقية</span>", html)       # the old tile that said the same thing is gone
            self.assertLess(html.index('class="stat big countdown"'), html.index("استفادت من العرض"))     # the number comes first
            await self.publish(owner, title=f"استراحة {taken}")

    async def test_no_grid_of_squares_is_left_anywhere(self):
        admin = await self.make_admin()
        founders.set_on(self.db, True)
        for lid in add_listings(self.db, 37):
            self.assertTrue(founders.grant(self.db, lid, TODAY, NOW))
        pages = [(admin, "/admin/offers/founders"), (admin, "/admin/offers"), (self.visitor, "/")]
        for client, path in pages:
            await client.get(path)
            self.assertEqual(client.last.status, 200, path)
            for gone in ("<i class=on>", "<i></i>", 'class="seats', 'class="legend', "محجوز <i>"):
                self.assertNotIn(gone, client.text, f"{path}: {gone}")
            self.assertNotRegex(client.text, r"\sstyle=", path)                    # the page forbids inline styles: the bar is drawn from two numbers
        self.assertNotRegex(CSS, r"\.seats\b|\.legend\b")                           # and the stylesheet has no rules for them

    async def test_the_number_is_the_same_while_the_offer_is_paused_and_comes_from_the_records(self):
        admin = await self.make_admin()
        founders.set_on(self.db, True)
        for lid in add_listings(self.db, 12):
            self.assertTrue(founders.grant(self.db, lid, TODAY, NOW))
        founders.set_on(self.db, False)
        await admin.get("/admin/offers/founders?left=5&taken=95")                   # nothing in the address changes it
        self.assertIn(self.HERO.format(n=88), admin.text)
        self.assertIn('<span class="tag warn">متوقف</span>', admin.text)

    async def test_the_number_and_the_bar_agree_with_the_banner_on_the_home_page(self):
        admin = await self.make_admin()
        founders.set_on(self.db, True)
        for lid in add_listings(self.db, 41):
            self.assertTrue(founders.grant(self.db, lid, TODAY, NOW))
        await admin.get("/admin/offers/founders")
        await self.visitor.get("/")
        for html in (admin.text, self.visitor.text):
            self.assertIn('<progress class="meter" max="100" value="59" aria-label="المقاعد المتبقية 59 من 100">', html)
        self.assertIn("<b>59</b>", self.visitor.text)

    def test_the_bar_never_goes_below_empty_or_above_full_and_is_read_aloud_as_words(self):
        from istiraha import ui
        self.assertIn('max="100" value="0" aria-label="المقاعد المتبقية 0 من 100"', ui.founders_meter(-5))
        self.assertIn('max="100" value="100" aria-label="المقاعد المتبقية 100 من 100"', ui.founders_meter(500))
        self.assertIn('value="63" aria-label="المقاعد المتبقية 63 من 100">63 من 100</progress>', ui.founders_meter(63))
        self.assertTrue(ui.founders_countdown(63).startswith(self.HERO.format(n=63)))                       # the tile the manager's page is built from

    def test_the_stylesheet_draws_the_bar_in_every_browser_and_keeps_it_readable_on_both_backgrounds(self):
        for rule in map(re.escape, ("::-webkit-progress-bar", "::-webkit-progress-value", "::-moz-progress-bar")):
            # one rule for each engine (Safari and Chrome, Firefox): a rule with a selector the browser does not know is dropped whole, so they are not merged
            self.assertRegex(CSS, rf"(?m)^\.meter{rule}\{{", rule)                                                        # on the light page
            self.assertRegex(CSS, rf"(?m)^\.founders \.meter{rule},\.stat\.big \.meter{rule}\{{", rule)                   # on the dark blue
        self.assertRegex(CSS, r"\.meter\{[^}]*appearance:none")
        self.assertRegex(CSS, r"\.founders \.meter,\.stat\.big \.meter\{[^}]*border-color:rgba\(255,255,255,\.65\)")       # an outline on the dark blue
        self.assertRegex(CSS, r"\.founders \.meter::-webkit-progress-value,\.stat\.big \.meter::-webkit-progress-value\{background:var\(--sun\)\}")
        self.assertRegex(CSS, r"@media \(min-width:640px\)\{\.stat\.big\.countdown\{grid-column:span 2\}\}")


class AdvertTests(FoundersCase):
    async def test_the_advert_has_the_sentence_the_button_the_counter_and_the_terms(self):
        founders.set_on(self.db, True)
        await self.visitor.get("/")
        html = self.visitor.text
        self.assertIn(f"<h2>{HEADLINE}</h2>", html)
        self.assertIn('<a class="btn sun big" href="/owner/new">أضف استراحتك</a>', html)
        self.assertIn("🏆 عرض المؤسسين", html)
        for term in founders.TERMS_PUBLIC:
            self.assertIn(term, html)
        self.assertIn("سنة كاملة", html)
        self.assertLess(html.index('class="hero"'), html.index('class="founders"'))              # after the search box, before the shelves
        self.assertNotRegex(html, r"\sstyle=")                                    # the page forbids inline styles: the picture is made of classes

    async def test_the_button_leads_a_visitor_to_the_sign_in_and_an_owner_to_the_form(self):
        founders.set_on(self.db, True)
        r = await self.visitor.get("/owner/new")
        self.assertEqual((r.status, r.headers["Location"]), (303, "/owner/login?next=/owner/new"))
        owner = await self.make_owner()
        self.assertEqual((await owner.get("/owner/new")).status, 200)

    async def test_the_pledge_page_tells_a_new_owner_about_the_year_only_while_it_runs_and_there_is_a_seat(self):
        owner = await self.make_owner()
        await owner.get("/owner/new")
        self.assertNotIn("عرض المؤسسين", owner.text)
        founders.set_on(self.db, True)
        await owner.get("/owner/new")
        self.assertIn("🎁 عرض المؤسسين", owner.text)
        self.assertIn("المقاعد المتبقية الآن: <b>100</b>", owner.text)
        self.assertIn("نسبة العمولة الحالية", owner.text)                          # the agreement itself is as it was
        lid = await self.publish(owner)
        await owner.get(f"/owner/listing/{lid}/reconsent")
        self.assertNotIn("عرض المؤسسين", owner.text)                              # not on the page of a new agreement for an advert that exists
        for other in add_listings(self.db, 99, start=100):
            self.assertTrue(founders.grant(self.db, other, TODAY, NOW))
        self.assertEqual(founders.taken(self.db), 100)                              # his own advert took one seat, the others the other 99
        await owner.get("/owner/new")
        self.assertNotIn("عرض المؤسسين", owner.text)                              # no seat left: nothing to promise a new owner

    async def test_the_preview_in_the_managers_page_is_the_same_advert_even_when_the_offer_is_off(self):
        admin = await self.make_admin()
        await admin.get("/admin/offers/founders")
        self.assertIn("معاينة الإعلان كما يراه الزوار", admin.text)
        self.assertIn(HEADLINE, admin.text)
        await self.visitor.get("/")
        self.assertNotIn(HEADLINE, self.visitor.text)                              # only the preview shows it


class RentalTests(FoundersCase):
    async def world(self):
        admin = await self.make_admin()
        founders.set_on(self.db, True)
        owner = await self.make_owner()
        lid = await self.publish(owner)
        return admin, owner, lid

    async def test_a_rental_inside_the_year_owes_nothing_and_one_outside_owes_the_agreed_commission(self):
        admin, owner, lid = await self.world()
        first, last = await self.rent(admin, lid, "2026-10-26"), await self.rent(admin, lid, "2027-10-25")       # the first and the last day count
        before, after = await self.rent(admin, lid, "2026-10-25"), await self.rent(admin, lid, "2027-10-26")
        middle = await self.rent(admin, lid, "2027-03-15")
        for rid in (first, last, middle):
            self.assertEqual(self.rental(rid)["pay_status"], "waived", rid)
        for rid in (before, after):
            self.assertEqual(self.rental(rid)["pay_status"], "due", rid)
        r = self.rental(first)
        self.assertEqual((r["basis_points"], r["commission_halalas"]), (1000, 5000))        # it keeps the agreed rate and what the commission would have been
        self.assertEqual((self.rental(after)["basis_points"], self.rental(after)["commission_halalas"]), (1000, 5000))
        note = self.db.one("SELECT body FROM rental_notes WHERE rental_id = ?", (first,))["body"]
        self.assertEqual(note, "معفاة من العمولة بعرض المؤسسين (من 2026-10-26 إلى 2027-10-25)")
        entry = self.db.one("SELECT detail FROM audit WHERE action = 'rental_new' ORDER BY id LIMIT 1")["detail"]
        self.assertIn("معفاة بعرض المؤسسين", entry)

    async def test_the_manager_is_told_when_the_rental_he_wrote_down_is_free(self):
        admin, owner, lid = await self.world()
        await admin.post("/admin/rental/new", {"listing": str(lid), "rent": "500", "date": "2026-11-01", "status": "confirmed"}, page="/admin/rental/new")
        self.assertEqual(await admin.message(), "سجلنا العملية، وهي معفاة من العمولة بعرض المؤسسين")
        await admin.post("/admin/rental/new", {"listing": str(lid), "rent": "500", "date": "2028-01-01", "status": "confirmed"}, page="/admin/rental/new")
        self.assertEqual(await admin.message(), "سجلنا العملية، العمولة 50 ريال")                    # as before, outside the year

    async def test_a_waived_rental_is_not_part_of_the_earnings_or_the_total_and_the_owner_reads_why(self):
        admin, owner, lid = await self.world()
        free = await self.rent(admin, lid, "2026-11-01", 500)
        due = await self.rent(admin, lid, "2027-11-01", 800)
        t = payments.earnings(self.db, TODAY)
        self.assertEqual((t["totals"]["waived"], t["totals"]["due"], t["open"]), (5000, 8000, 8000))
        self.assertEqual(t["owners"][0]["commission"], 8000)                      # only the rental that owes something
        await admin.get("/admin/rentals")
        self.assertIn("إجمالي العمولات في هذه القائمة (بدون الملغي): <b>80</b> ر.س", admin.text)
        self.assertIn("لا يدخل في هذا الإجمالي 1 عملية معفاة من العمولة", admin.text)
        await admin.get("/admin/rentals?pay=waived")
        self.assertIn(f"#{free}", admin.text)
        self.assertNotIn(f'href="/admin/rental/{due}"', admin.text)
        await admin.get("/admin/earnings")
        self.assertIn("معفاة من العمولة: 50 ر.س (1 عملية)", admin.text)
        await owner.get("/owner/commissions")
        self.assertIn("🎁 عرض المؤسسين", owner.text)
        self.assertIn("معفاة من العمولة سنة كاملة", owner.text)
        self.assertIn("استراحة النخيل: من 26 أكتوبر 2026 حتى 25 أكتوبر 2027", owner.text)
        self.assertIn('<span class="tag muted">معفاة</span>', owner.text)
        summary = payments.owner_summary(self.db, self.db.one("SELECT id FROM users WHERE role = 'owner'")["id"], "2026-10-26")
        self.assertEqual((summary["waived"], summary["due"]), (5000, 8000))

    async def test_editing_a_waived_rental_keeps_it_waived_and_the_agreed_rate(self):
        admin, owner, lid = await self.world()
        rid = await self.rent(admin, lid, "2026-11-01", 500)
        await admin.post(f"/admin/rental/{rid}/update", {"rent": "1000", "status": "confirmed", "pay_status": "waived"}, page=f"/admin/rental/{rid}")
        r = self.rental(rid)
        self.assertEqual((r["pay_status"], r["rent"], r["basis_points"], r["commission_halalas"]), ("waived", 1000, 1000, 10000))
        await admin.post(f"/admin/rental/{rid}/update", {"rent": "1000", "status": "confirmed", "pay_status": "due"}, page=f"/admin/rental/{rid}")
        self.assertEqual(self.rental(rid)["pay_status"], "due")                    # the manager can still decide otherwise by hand

    async def test_a_rental_written_down_before_the_year_began_is_left_as_it_was(self):
        admin = await self.make_admin()
        owner = await self.make_owner()
        lid = await self.publish(owner)
        early = await self.rent(admin, lid, "2026-11-10")                          # recorded while the offer did not exist for this advert
        founders.set_on(self.db, True)
        await admin.post(f"/admin/listing/{lid}/founders", page=f"/admin/listing/{lid}")
        self.assertEqual(self.rental(early)["pay_status"], "due")                   # nothing already written is rewritten
        late = await self.rent(admin, lid, "2026-11-10")
        self.assertEqual(self.rental(late)["pay_status"], "waived")

    async def test_an_advert_with_no_year_and_an_offer_that_never_ran_change_nothing_about_rentals(self):
        admin = await self.make_admin()
        owner = await self.make_owner()
        lid = await self.publish(owner)
        rid = await self.rent(admin, lid, "2026-11-01")
        r = self.rental(rid)
        self.assertEqual((r["pay_status"], r["commission_halalas"], r["basis_points"]), ("due", 5000, 1000))
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM rental_notes")["n"], 0)
        await admin.get("/admin/rentals")
        self.assertNotIn("معفاة من العمولة", admin.text.replace("pay=waived", ""))

    async def test_each_advert_has_its_own_year_and_another_owners_rentals_are_not_free(self):
        admin, owner, lid = await self.world()
        founders.set_on(self.db, False)
        other, other_lid = await self.second_owner()                               # published while the offer was off: no year
        self.assertIsNone(self.exemption(other_lid))
        mine = await self.rent(admin, lid, "2026-11-01")
        theirs = await self.rent(admin, other_lid, "2026-11-01")
        self.assertEqual((self.rental(mine)["pay_status"], self.rental(theirs)["pay_status"]), ("waived", "due"))
        await other.get("/owner/commissions")
        self.assertNotIn("عرض المؤسسين", other.text)
        await other.get("/owner")
        self.assertNotIn("عرض المؤسسين", other.text)


class OwnerSideTests(FoundersCase):
    async def test_an_owner_sees_his_own_years_and_nobody_elses(self):
        founders.set_on(self.db, True)
        owner = await self.make_owner()
        mine = await self.publish(owner, title="استراحة النخيل")
        other, theirs = await self.second_owner("مزرعة الواحة")
        await owner.get("/owner")
        self.assertIn("🎁 عرض المؤسسين: معفاة من العمولة سنة كاملة", owner.text)
        self.assertIn("استراحة النخيل: من 26 أكتوبر 2026 حتى 25 أكتوبر 2027", owner.text)
        self.assertNotIn("مزرعة الواحة: من", owner.text)
        await owner.get(f"/owner/listing/{mine}")
        self.assertIn("<b>🎁 عرض المؤسسين</b>معفاة من العمولة من 26 أكتوبر 2026 إلى 25 أكتوبر 2027 (ساري)", owner.text)
        await other.get(f"/owner/listing/{theirs}")
        self.assertIn("معفاة من العمولة من 26 أكتوبر 2026 إلى 25 أكتوبر 2027 (ساري)", other.text)
        r = await owner.get(f"/owner/listing/{theirs}")
        self.assertEqual(r.status, 404)

    async def test_an_advert_without_a_year_shows_nothing_about_it(self):
        owner = await self.make_owner()
        lid = await self.publish(owner)
        for path in ("/owner", f"/owner/listing/{lid}", "/owner/commissions"):
            await owner.get(path)
            self.assertNotIn("عرض المؤسسين", owner.text, path)

    async def test_what_the_manager_cannot_change_stays_fixed_for_the_owner_too(self):
        founders.set_on(self.db, True)
        owner = await self.make_owner()
        lid = await self.publish(owner)
        for path in ("/admin/offers/founders/toggle", f"/admin/listing/{lid}/founders"):
            r = await owner.go("POST", path, {"to": "off"})
            self.assertEqual(r.status, 303)
        self.assertTrue(founders.is_on(self.db))
        self.assertEqual(founders.taken(self.db), 1)


class EscapingTests(FoundersCase):
    async def test_what_an_owner_typed_is_escaped_where_the_manager_and_the_owner_read_it(self):
        admin = await self.make_admin()
        founders.set_on(self.db, True)
        owner = await self.make_owner(name="<i>أبو سعد</i>")
        lid = await self.publish(owner, title="<script>alert(1)</script>استراحة")
        for client, path in ((admin, "/admin/offers/founders"), (owner, "/owner"), (admin, f"/admin/listing/{lid}")):
            await client.get(path)
            self.assertNotIn("<script>alert(1)", client.text, path)
            self.assertNotIn("<i>أبو سعد", client.text, path)
        await admin.get("/admin/offers/founders")
        self.assertIn("&lt;script&gt;alert(1)&lt;/script&gt;استراحة", admin.text)
        self.assertIn("&lt;i&gt;أبو سعد&lt;/i&gt;", admin.text)


class NotMixedWithTheOwnersOffersTests(FoundersCase):
    async def test_the_owners_page_of_offers_and_the_public_offers_never_show_it(self):
        admin = await self.make_admin()
        founders.set_on(self.db, True)
        owner = await self.make_owner()
        await self.publish(owner)
        await owner.get("/owner/offers")
        self.assertEqual(owner.last.status, 200)
        self.assertNotIn("المؤسسين", owner.text)
        self.assertNotIn("founders", owner.text)
        await self.visitor.get("/offers")
        self.assertNotIn("المؤسسين", self.visitor.text)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM offers")["n"], 0)         # it is not a discount: nothing was added to the table of offers
        await admin.get("/admin/offers")
        self.assertIn("المؤسسين", admin.text)

    async def test_the_discounts_work_as_before_beside_it(self):
        admin = await self.make_admin()
        founders.set_on(self.db, True)
        owner = await self.make_owner()
        lid = await self.publish(owner)
        await admin.post("/admin/offers", {"title": "خصم الخريف", "percent": "20", "city": "", "category": "", "listing": "", "starts": "2026-10-01", "ends": "2026-12-31"},
                         page="/admin/offers")
        await owner.post("/owner/offers", {"title": "خصم المالك", "percent": "30", "listing": "", "starts": "2026-10-26", "ends": "2026-12-31"}, page="/owner/offers")
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM offers")["n"], 2)
        await admin.get("/admin/offers")
        self.assertIn("خصم الخريف", admin.text)
        self.assertIn("خصم المالك", admin.text)
        await self.visitor.get(f"/r/{lid}")
        self.assertIn("خصم 30%", self.visitor.text)
        self.assertEqual(founders.taken(self.db), 1)

    async def test_the_commission_the_site_charges_is_not_changed_by_the_offer(self):
        admin = await self.make_admin()
        await admin.post("/admin/commission", {"percent": "12"}, page="/admin/commission")
        founders.set_on(self.db, True)
        owner = await self.make_owner()
        lid = await self.publish(owner)
        self.assertEqual(self.db.commission_bp(), 1200)
        self.assertEqual(self.db.one("SELECT basis_points FROM consents")["basis_points"], 1200)
        rid = await self.rent(admin, lid, "2028-06-01", 1000)                       # after the year: the agreed 12 percent
        r = self.rental(rid)
        self.assertEqual((r["pay_status"], r["basis_points"], r["commission_halalas"]), ("due", 1200, 12000))
        await admin.get("/admin/commission")
        self.assertIn("12%", admin.text)


if __name__ == "__main__":
    unittest.main()
