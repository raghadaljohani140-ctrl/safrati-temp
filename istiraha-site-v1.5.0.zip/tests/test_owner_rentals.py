"""The owner writes his own rentals down («سجّل تأجيرًا»). Before, only the manager could record a rental, so an owner who rented his rest house
a second time had no new commission to pay. Now the owner records it himself, the commission appears in «عمولاتي» at the rate of his agreement,
and he pays and reports it as before. These tests keep the form honest (whose adverts, which dates, which amounts, no double taps, no double
rentals), keep the founders' free year working for it, and check what the manager sees."""
import re
import unittest
from datetime import date
from pathlib import Path

from istiraha import payments, repo

from .helpers import NOW, Case

SHOWN = "SA03 8000 0000 6080 1016 7519"           # the example in the public IBAN registry, not anybody's account
PASSWORD = "Str0ng-pass!"
ADD_ROW = "INSERT INTO founder_exemptions(listing_id, starts_on, ends_on, granted_at) VALUES (?, '2026-10-26', '2027-10-25', 1)"
TODAY = date(2026, 10, 26)                         # the day of the test clock, in Riyadh


class RentalCase(Case):
    async def world(self):
        admin = await self.make_admin()
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        self.approve(lid)
        return admin, owner, lid

    async def other_owner(self, title="مزرعة الواحة"):
        owner = await self.make_owner(phone="0559876543", name="أبو خالد", ip="203.0.113.51")
        lid = await self.add_listing(owner, title=title, whatsapp="0559876543")
        self.approve(lid)
        return owner, lid

    async def record(self, owner, lid, rent=300, day="2026-10-26", customer="", **extra):
        form = {"listing": str(lid), "rent": str(rent), "date": day, "customer": customer, **extra}
        return await owner.post("/owner/rental/new", form, page="/owner/rental/new")

    async def manager_rents(self, admin, lid, rent=300, day="2026-10-20", status="confirmed"):
        r = await admin.post("/admin/rental/new", {"listing": str(lid), "rent": str(rent), "date": day, "status": status}, page="/admin/rental/new")
        self.assertEqual(r.status, 303, admin.text[:300])
        return self.db.one("SELECT MAX(id) AS i FROM rentals")["i"]

    async def set_bank(self, admin):
        form = {"holder": "شركة استراحتي", "bank": "مصرف الراجحي", "iban": SHOWN, "contact": "", "note": "", "password": PASSWORD}
        r = await admin.post("/admin/pay-details", form, page="/admin/pay-details")
        self.assertEqual(r.status, 303, admin.text[:300])

    def rentals(self):
        return self.db.all("SELECT * FROM rentals ORDER BY id")

    def owner_id(self, phone="966551234567"):
        return self.db.one("SELECT id FROM users WHERE login = ?", (phone,))["id"]


class SecondRentalTests(RentalCase):
    async def test_an_owner_who_rents_again_gets_the_new_commission_and_can_pay_it(self):
        """The case that was reported: the first commission was paid, the owner rented a second time and had nothing to pay."""
        admin, owner, lid = await self.world()
        await self.set_bank(admin)
        first = await self.manager_rents(admin, lid, 300, "2026-10-20")
        await owner.post("/owner/commissions/report", {"rental": [str(first)], "paid_on": "2026-10-26", "reference": ""}, page="/owner/commissions")
        await admin.post("/admin/payment/1/confirm", {"received": "1"}, page="/admin/payment/1")
        await owner.get("/owner/commissions")
        self.assertIn("لا توجد عمولات مستحقة عليك الآن", owner.text)                 # everything is paid: nothing he could pay now
        self.assertNotIn('name="rental"', owner.text)

        await owner.get("/owner")
        self.assertIn('href="/owner/rental/new"', owner.text)                      # the way to write the second rental down is on his front page
        r = await self.record(owner, lid, 400, "2026-10-26", "عميل الجمعة")
        self.assertEqual((r.status, r.headers["Location"].split("?")[0]), (303, "/owner/commissions"))
        message = await owner.message()
        self.assertIn("سجلنا التأجير", message)
        self.assertIn("عمولته 40 ر.س", message)

        new = self.rentals()[-1]
        me = self.owner_id()
        self.assertEqual((new["listing_id"], new["owner_id"], new["created_by"], new["rent"], new["basis_points"], new["commission_halalas"]), (lid, me, me, 400, 1000, 4000))
        self.assertEqual((new["rental_date"], new["status"], new["pay_status"], new["due_date"], new["customer"]), ("2026-10-26", "confirmed", "due", "2026-11-02", "عميل الجمعة"))
        self.assertEqual(len(self.rentals()), 2)
        self.assertEqual(payments.owner_summary(self.db, me, "2026-10-26")["due"], 4000)

        # the commission is there, with the way to pay it and the form to report the payment
        self.assertIn("مستحقة عليك", owner.text)
        self.assertIn(f'name="rental" value="{new["id"]}"', owner.text)
        self.assertIn(SHOWN, owner.text)
        self.assertEqual(owner.text.count('name="rental"'), 1)                     # only the new one: the first is paid
        r = await owner.post("/owner/commissions/report", {"rental": [str(new["id"])], "paid_on": "2026-10-26", "reference": "تحويل الجمعة"}, page="/owner/commissions")
        self.assertEqual(r.status, 303, owner.text[:300])
        await admin.get("/admin/payment/2")
        self.assertIn("40", admin.text)
        await admin.post("/admin/payment/2/confirm", {"received": "1"}, page="/admin/payment/2")
        self.assertEqual(self.db.one("SELECT pay_status FROM rentals WHERE id = ?", (new["id"],))["pay_status"], "paid")
        await owner.get("/owner/commissions")
        self.assertIn("لا توجد عمولات مستحقة عليك الآن", owner.text)

    async def test_the_commission_follows_the_agreement_of_the_advert_not_the_rate_of_today(self):
        admin, owner, lid = await self.world()                                  # signed at 10%
        await admin.post("/admin/commission", {"percent": "12.5", "note": "تحديث"}, page="/admin/commission")
        self.assertEqual(self.db.commission_bp(), 1250)
        await self.record(owner, lid, 400)
        row = self.rentals()[-1]
        self.assertEqual((row["basis_points"], row["commission_halalas"]), (1000, 4000))
        newer = await self.add_listing(owner, title="استراحة الشتاء")           # signed after the change: 12.5%
        self.approve(newer)
        await self.record(owner, newer, 400)
        row = self.rentals()[-1]
        self.assertEqual((row["listing_id"], row["basis_points"], row["commission_halalas"]), (newer, 1250, 5000))

    async def test_the_audit_log_says_the_owner_did_it(self):
        admin, owner, lid = await self.world()
        await self.record(owner, lid, 400)
        entry = self.db.one("SELECT * FROM audit WHERE action = 'owner_rental_new'")
        self.assertEqual(entry["user_id"], self.owner_id())
        self.assertIn("إيجار 400", entry["detail"])
        self.assertIn("عمولة 10%", entry["detail"])
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM audit WHERE action = 'rental_new'")["n"], 0)
        await admin.get("/admin")
        self.assertIn("تسجيل عملية من مالك", admin.text)
        self.assertNotIn("owner_rental_new", admin.text)


class WhoseAdvertTests(RentalCase):
    async def test_the_form_lists_only_his_own_published_adverts_with_their_rate(self):
        admin, owner, lid = await self.world()
        await self.add_listing(owner, title="استراحة قيد المراجعة")              # his, but still waiting
        await self.other_owner()
        await owner.get("/owner/rental/new")
        self.assertIn("استراحة النخيل — عمولة 10%", owner.text)
        self.assertNotIn("قيد المراجعة", owner.text)
        self.assertNotIn("مزرعة الواحة", owner.text)
        self.assertIn(f'<option value="{lid}" selected>', owner.text)             # one advert only: it is already chosen

    async def test_with_several_adverts_none_is_chosen_for_him_unless_he_came_from_one(self):
        admin, owner, lid = await self.world()
        second = await self.add_listing(owner, title="استراحة الشتاء")
        self.approve(second)
        await owner.get("/owner/rental/new")
        self.assertNotIn(" selected>", owner.text)
        await owner.get("/owner/rental/new", listing=str(second))
        self.assertIn(f'<option value="{second}" selected>', owner.text)

    async def test_someone_elses_advert_and_adverts_that_are_not_published_are_refused(self):
        admin, owner, lid = await self.world()
        waiting = await self.add_listing(owner, title="استراحة قيد المراجعة")
        stopped = await self.add_listing(owner, title="استراحة موقوفة")
        self.db.run("UPDATE listings SET review = 'stopped' WHERE id = ?", (stopped,))
        rejected = await self.add_listing(owner, title="استراحة مرفوضة")
        self.db.run("UPDATE listings SET review = 'rejected' WHERE id = ?", (rejected,))
        other, other_lid = await self.other_owner()
        for value in (other_lid, waiting, stopped, rejected, "", "abc", "0", "-1", "99999", "1 OR 1=1"):
            r = await self.record(owner, value)
            self.assertEqual(r.status, 400, value)
            self.assertIn("اختر استراحة من استراحاتك المنشورة", owner.text, value)
        self.assertEqual(self.rentals(), [])
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM audit WHERE action = 'owner_rental_new'")["n"], 0)

    async def test_a_paused_advert_can_still_have_its_rental_written_down(self):
        admin, owner, lid = await self.world()
        self.db.run("UPDATE listings SET owner_active = 0 WHERE id = ?", (lid,))      # he paused it after a rental
        r = await self.record(owner, lid, 400)
        self.assertEqual(r.status, 303, owner.text[:300])
        self.assertEqual(len(self.rentals()), 1)

    async def test_a_rental_written_by_one_owner_is_never_seen_by_another(self):
        admin, owner, lid = await self.world()
        other, other_lid = await self.other_owner()
        await self.record(owner, lid, 400)
        await other.get("/owner/commissions")
        self.assertIn("لا توجد عمولات حتى الآن", other.text)
        self.assertNotIn("استراحة النخيل", other.text)
        await self.record(other, other_lid, 700)
        await owner.get("/owner/commissions")
        self.assertNotIn("مزرعة الواحة", owner.text)
        self.assertEqual({r["owner_id"] for r in self.rentals()}, {self.owner_id(), self.owner_id("966559876543")})

    async def test_an_owner_with_no_published_advert_is_told_why_and_cannot_record(self):
        admin = await self.make_admin()
        owner = await self.make_owner()
        await self.add_listing(owner)                                                # waiting for the manager
        await owner.get("/owner/rental/new")
        self.assertIn("التسجيل يكون لاستراحة منشورة", owner.text)
        self.assertNotIn('name="rent"', owner.text)
        await owner.get("/owner")
        self.assertNotIn("rent-card", owner.text)                                    # no card to write a rental on the front page either
        r = await owner.post("/owner/rental/new", {"listing": "1", "rent": "300", "date": "2026-10-26"}, page="/owner/password")
        self.assertEqual(r.status, 400)
        self.assertEqual(self.rentals(), [])


class AmountAndDateTests(RentalCase):
    async def test_a_bad_amount_is_refused_and_what_he_typed_stays_in_the_form(self):
        admin, owner, lid = await self.world()
        for rent in ("", "0", "-5", "abc", "3 آلاف", "300.5", "300,00", "1,5000", "1000001", "99999999999", "٣٠٠٠٠٠٠"):
            r = await self.record(owner, lid, rent, "2026-10-26", "عميل الجمعة")
            self.assertEqual(r.status, 400, rent)
            self.assertIn("اكتب قيمة الإيجار بالريال أرقامًا فقط", owner.text, rent)
            self.assertIn('value="عميل الجمعة"', owner.text, rent)
            self.assertIn('value="2026-10-26"', owner.text, rent)
        self.assertEqual(self.rentals(), [])

    async def test_amounts_are_read_the_way_people_write_them(self):
        admin, owner, lid = await self.world()
        cases = (("300", 300), ("٤٠٠", 400), ("500 ريال", 500), ("1,500", 1500), ("600.00", 600), ("1 200", 1200), ("1000000", 1_000_000))
        for day, (typed, expected) in enumerate(cases, start=1):                       # one day each: the same day twice would ask him first
            r = await self.record(owner, lid, typed, f"2026-11-{day:02d}")
            self.assertEqual(r.status, 303, typed)
            self.assertEqual(self.rentals()[-1]["rent"], expected, typed)

    async def test_the_date_must_be_a_real_one_near_today(self):
        admin, owner, lid = await self.world()
        for day, words in (("", "اكتب تاريخ الإيجار"), ("abc", "اكتب تاريخ الإيجار"), ("2026-02-30", "اكتب تاريخ الإيجار"), ("26/10/2026", "اكتب تاريخ الإيجار"),
                           ("2026-10-11", "أقدم من 14 يومًا"), ("2025-10-26", "أقدم من 14 يومًا"),
                           ("2027-10-27", "بعيد جدًا"), ("2099-01-01", "بعيد جدًا")):
            r = await self.record(owner, lid, 300, day)
            self.assertEqual(r.status, 400, day)
            self.assertIn(words, owner.text, day)
        self.assertEqual(self.rentals(), [])

    async def test_the_first_and_the_last_day_allowed_are_accepted(self):
        admin, owner, lid = await self.world()
        for rent, day in ((301, "2026-10-12"), (302, "2026-10-26"), (303, "2027-10-26")):    # 14 days back, today, 365 days ahead
            r = await self.record(owner, lid, rent, day)
            self.assertEqual(r.status, 303, day)
        self.assertEqual([x["rental_date"] for x in self.rentals()], ["2026-10-12", "2026-10-26", "2027-10-26"])

    async def test_the_form_itself_stops_the_picker_at_the_same_dates(self):
        admin, owner, lid = await self.world()
        await owner.get("/owner/rental/new")
        self.assertIn('min="2026-10-12"', owner.text)
        self.assertIn('max="2027-10-26"', owner.text)
        self.assertIn('value="2026-10-26"', owner.text)                                # today is already filled in

    async def test_an_older_rental_is_late_at_once_and_a_coming_one_is_not_due_yet(self):
        admin, owner, lid = await self.world()
        await self.record(owner, lid, 301, "2026-10-12")                                # due 7 days later: already over
        await self.record(owner, lid, 302, "2026-11-15")                                # a booking for next month
        self.assertEqual([r["due_date"] for r in self.rentals()], ["2026-10-19", "2026-11-22"])
        await owner.get("/owner/commissions")
        self.assertEqual(len(re.findall(r">متأخرة<", owner.text)), 1)
        self.assertEqual(len(re.findall(r">مستحقة<", owner.text)), 1)
        await owner.get("/owner")
        self.assertIn("com-card bad", owner.text)

    async def test_what_he_types_for_the_customer_is_cut_and_escaped(self):
        admin, owner, lid = await self.world()
        await self.record(owner, lid, 300, customer="<script>alert(1)</script>" + "ن" * 100)
        row = self.rentals()[0]
        self.assertEqual(len(row["customer"]), 80)
        await admin.get(f"/admin/rental/{row['id']}")
        self.assertNotIn("<script>alert(1)", admin.text)
        self.assertIn("&lt;script&gt;", admin.text)

    async def test_the_title_of_an_advert_is_escaped_in_the_list(self):
        admin = await self.make_admin()
        owner = await self.make_owner()
        lid = await self.add_listing(owner, title="<i>استراحة</i>")
        self.approve(lid)
        await owner.get("/owner/rental/new")
        self.assertNotIn("<i>استراحة", owner.text)
        self.assertIn("&lt;i&gt;استراحة", owner.text)


class TwiceTests(RentalCase):
    async def test_the_same_tap_sent_twice_is_one_rental(self):
        admin, owner, lid = await self.world()
        first = await self.record(owner, lid, 300, "2026-10-26")
        second = await self.record(owner, lid, 300, "2026-10-26")
        self.assertEqual((first.status, second.status), (303, 303))
        self.assertEqual(len(self.rentals()), 1)
        self.assertIn("قبل لحظات", await owner.message())
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM audit WHERE action = 'owner_rental_new'")["n"], 1)

    async def test_the_same_figures_two_minutes_later_are_a_new_rental_after_the_question(self):
        admin, owner, lid = await self.world()
        await self.record(owner, lid, 300, "2026-10-26")
        self.clock.t += payments.DOUBLE_TAP_SECONDS + 1
        again = await self.record(owner, lid, 300, "2026-10-26")                      # no longer a double tap, but the same day: he is asked first
        self.assertEqual(again.status, 400)
        self.assertEqual(len(self.rentals()), 1)
        done = await self.record(owner, lid, 300, "2026-10-26", again="1")
        self.assertEqual(done.status, 303)
        self.assertEqual(len(self.rentals()), 2)

    async def test_the_rental_the_manager_already_wrote_is_not_written_again_without_a_question(self):
        admin, owner, lid = await self.world()
        seen = await self.manager_rents(admin, lid, 300, "2026-10-25")
        r = await self.record(owner, lid, 300, "2026-10-25")
        self.assertEqual(r.status, 400)
        self.assertIn(f"عملية #{seen}", owner.text)
        self.assertIn('name="again"', owner.text)                                      # the box that says "this is another rental"
        self.assertIn('value="300"', owner.text)                                       # and what he typed is still there
        self.assertEqual(len(self.rentals()), 1)
        r = await self.record(owner, lid, 300, "2026-10-25", again="1")
        self.assertEqual(r.status, 303)
        self.assertEqual(len(self.rentals()), 2)

    async def test_the_question_is_only_asked_when_there_is_something_to_ask(self):
        admin, owner, lid = await self.world()
        second = await self.add_listing(owner, title="استراحة الشتاء")
        self.approve(second)
        gone = await self.manager_rents(admin, lid, 300, "2026-10-25", status="cancelled")      # a cancelled rental stands for nothing
        await self.manager_rents(admin, second, 300, "2026-10-25")                              # another advert
        await self.manager_rents(admin, lid, 300, "2026-10-24")                                 # another day
        r = await self.record(owner, lid, 300, "2026-10-25")
        self.assertEqual(r.status, 303, owner.text[:400])
        await owner.get("/owner/rental/new")
        self.assertNotIn('name="again"', owner.text)
        self.assertEqual(self.db.one("SELECT status FROM rentals WHERE id = ?", (gone,))["status"], "cancelled")

    async def test_at_most_twenty_a_day_and_the_manager_is_not_counted(self):
        admin, owner, lid = await self.world()
        for i in range(25):
            await self.manager_rents(admin, lid, 100 + i, "2026-10-20")                          # the manager's own work is not the owner's quota
        for i in range(payments.OWNER_PER_DAY):
            r = await self.record(owner, lid, 500 + i, f"2026-11-{(i % 20) + 1:02d}")
            self.assertEqual(r.status, 303, i)
        r = await self.record(owner, lid, 999, "2026-12-01")
        self.assertEqual(r.status, 400)
        self.assertIn("وصلت للحد اليومي", owner.text)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM rentals WHERE created_by = owner_id")["n"], payments.OWNER_PER_DAY)
        self.clock.t += 86400 + 1                                                               # the next day he may write again
        r = await self.record(owner, lid, 999, "2026-12-01")
        self.assertEqual(r.status, 303)

    async def test_one_owners_quota_does_not_use_up_another_owners(self):
        admin, owner, lid = await self.world()
        other, other_lid = await self.other_owner()
        for i in range(payments.OWNER_PER_DAY):
            await self.record(owner, lid, 500 + i, f"2026-11-{(i % 20) + 1:02d}")
        r = await self.record(other, other_lid, 700)
        self.assertEqual(r.status, 303)


class FreeYearTests(RentalCase):
    async def test_a_rental_inside_the_free_year_is_recorded_as_waived_with_its_note(self):
        admin, owner, lid = await self.world()
        self.db.run(ADD_ROW, (lid,))                                                    # the founders' offer: 2026-10-26 to 2027-10-25
        r = await self.record(owner, lid, 400, "2026-10-27")
        self.assertEqual(r.status, 303)
        self.assertIn("معفى من العمولة بعرض المؤسسين", await owner.message())
        row = self.rentals()[0]
        self.assertEqual((row["pay_status"], row["commission_halalas"], row["basis_points"]), ("waived", 4000, 1000))     # what it would have been is kept
        notes = [n["body"] for n in self.db.all("SELECT body FROM rental_notes WHERE rental_id = ? ORDER BY id", (row["id"],))]
        self.assertEqual(len(notes), 2)
        self.assertEqual(notes[0], "سجّلها المالك بنفسه")
        self.assertIn("معفاة من العمولة بعرض المؤسسين (من 2026-10-26 إلى 2027-10-25)", notes[1])
        self.assertIn("معفاة بعرض المؤسسين", self.db.one("SELECT detail FROM audit WHERE action = 'owner_rental_new'")["detail"])
        await owner.get("/owner/commissions")
        self.assertIn(">معفاة<", owner.text)
        self.assertNotIn('name="rental"', owner.text)                                   # nothing to pay
        self.assertEqual(payments.owner_summary(self.db, self.owner_id(), "2026-10-26")["due"], 0)

    async def test_the_last_day_of_the_year_is_free_and_the_day_after_is_not(self):
        admin, owner, lid = await self.world()
        self.db.run(ADD_ROW, (lid,))
        await self.record(owner, lid, 301, "2027-10-25")
        await self.record(owner, lid, 302, "2027-10-26")
        self.assertEqual([(r["rental_date"], r["pay_status"]) for r in self.rentals()], [("2027-10-25", "waived"), ("2027-10-26", "due")])

    async def test_only_the_advert_with_the_free_year_is_free(self):
        admin, owner, lid = await self.world()
        second = await self.add_listing(owner, title="استراحة الشتاء")
        self.approve(second)
        self.db.run(ADD_ROW, (lid,))
        await self.record(owner, lid, 301, "2026-10-27")
        await self.record(owner, second, 302, "2026-10-27")
        self.assertEqual([(r["listing_id"], r["pay_status"]) for r in self.rentals()], [(lid, "waived"), (second, "due")])

    async def test_the_manager_and_the_owner_write_the_same_rental_the_same_way(self):
        admin, owner, lid = await self.world()
        self.db.run(ADD_ROW, (lid,))
        await self.manager_rents(admin, lid, 400, "2026-10-27")
        await self.record(owner, lid, 400, "2026-10-27", again="1")
        a, b = self.rentals()
        keep = ("listing_id", "owner_id", "consent_id", "basis_points", "rent", "commission_halalas", "rental_date", "status", "pay_status", "due_date")
        self.assertEqual({k: a[k] for k in keep}, {k: b[k] for k in keep})
        self.assertNotEqual(a["created_by"], b["created_by"])


class ManagerSideTests(RentalCase):
    async def test_the_manager_sees_which_rentals_the_owner_wrote_himself(self):
        admin, owner, lid = await self.world()
        mine = await self.manager_rents(admin, lid, 300, "2026-10-20")
        await self.record(owner, lid, 400, "2026-10-26", "عميل الجمعة")
        theirs = self.rentals()[-1]["id"]
        await admin.get("/admin/rentals")
        self.assertEqual(admin.text.count("سجّلها المالك<"), 1)                         # the tag, on one row only
        self.assertIn("سجّلها الملاك", admin.text)                                       # and the tab that filters them
        await admin.get("/admin/rentals?by=owner")
        self.assertIn(f"#{theirs}<", admin.text)
        self.assertNotIn(f"#{mine}<", admin.text)
        await admin.get(f"/admin/rental/{theirs}")
        self.assertIn("<b>سجّلها</b>المالك بنفسه", admin.text)
        self.assertIn("سجّلها المالك بنفسه", admin.text)                                  # also in the log of the rental
        self.assertIn("عميل الجمعة", admin.text)
        await admin.get(f"/admin/rental/{mine}")
        self.assertIn("<b>سجّلها</b>الإدارة", admin.text)

    async def test_the_manager_can_correct_or_cancel_a_rental_the_owner_wrote(self):
        admin, owner, lid = await self.world()
        await self.record(owner, lid, 3000, "2026-10-26")                                 # a slip: it was 300
        rid = self.rentals()[0]["id"]
        await owner.get("/owner/commissions")
        self.assertIn('data-h="30000"', owner.text)
        await admin.post(f"/admin/rental/{rid}/update", {"rent": "300", "status": "confirmed", "pay_status": "due"}, page=f"/admin/rental/{rid}")
        self.assertEqual(self.db.one("SELECT commission_halalas FROM rentals WHERE id = ?", (rid,))["commission_halalas"], 3000)
        await owner.get("/owner/commissions")
        self.assertIn('data-h="3000"', owner.text)
        await admin.post(f"/admin/rental/{rid}/update", {"rent": "300", "status": "cancelled", "pay_status": "due"}, page=f"/admin/rental/{rid}")
        await owner.get("/owner/commissions")
        self.assertNotIn('name="rental"', owner.text)

    async def test_the_manager_still_writes_rentals_for_any_date_and_any_amount(self):
        admin, owner, lid = await self.world()
        await self.manager_rents(admin, lid, 2_500_000, "2025-01-05")                      # the owner's limits do not apply to him
        await self.manager_rents(admin, lid, 400, "2031-03-01")
        self.assertEqual([(r["rent"], r["created_by"] == r["owner_id"]) for r in self.rentals()], [(2_500_000, False), (400, False)])

    async def test_the_managers_form_still_cuts_a_long_customer_and_note_and_keeps_his_note(self):
        admin, owner, lid = await self.world()
        r = await admin.post("/admin/rental/new", {"listing": str(lid), "rent": "300", "date": "2026-10-20", "status": "confirmed",
                                                   "customer": "  " + "ع" * 120, "note": "ن" * 600}, page="/admin/rental/new")
        self.assertEqual(r.status, 303, admin.text[:300])
        row = self.rentals()[0]
        self.assertEqual(row["customer"], "ع" * 80)
        notes = [n["body"] for n in self.db.all("SELECT body FROM rental_notes WHERE rental_id = ? ORDER BY id", (row["id"],))]
        self.assertEqual(notes, ["ن" * 500])                                            # his note only: nothing says the owner wrote it
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM audit WHERE action = 'rental_new'")["n"], 1)

    async def test_the_earnings_count_an_owner_written_rental_like_any_other(self):
        admin, owner, lid = await self.world()
        await self.manager_rents(admin, lid, 300, "2026-10-20")
        await self.record(owner, lid, 400, "2026-10-26")
        data = payments.earnings(self.db, TODAY)
        self.assertEqual((data["totals"]["due"], data["counts"]["due"], data["open"]), (7000, 2, 7000))


class AccessTests(RentalCase):
    async def test_the_page_and_the_post_need_an_owner_sign_in(self):
        admin, owner, lid = await self.world()
        for who in (self.visitor, admin):
            r = await who.get("/owner/rental/new")
            self.assertEqual((r.status, r.headers["Location"].split("?")[0]), (303, "/owner/login"))
            r = await who.go("POST", "/owner/rental/new", {"listing": str(lid), "rent": "300", "date": "2026-10-26"})
            self.assertEqual((r.status, r.headers["Location"].split("?")[0]), (303, "/owner/login"))
        self.assertEqual(self.rentals(), [])

    async def test_the_owner_cannot_use_the_managers_form(self):
        admin, owner, lid = await self.world()
        r = await owner.get("/admin/rental/new")
        self.assertEqual((r.status, r.headers["Location"]), (303, "/admin/login"))
        r = await owner.go("POST", "/admin/rental/new", {"listing": str(lid), "rent": "300", "date": "2026-10-26", "status": "confirmed"})
        self.assertEqual((r.status, r.headers["Location"]), (303, "/admin/login"))
        self.assertEqual(self.rentals(), [])

    async def test_a_post_without_the_form_token_is_refused(self):
        admin, owner, lid = await self.world()
        await owner.get("/owner/rental/new")
        r = await owner.go("POST", "/owner/rental/new", {"listing": str(lid), "rent": "300", "date": "2026-10-26"})
        self.assertEqual(r.status, 403)
        r = await owner.go("POST", "/owner/rental/new", {"listing": str(lid), "rent": "300", "date": "2026-10-26", "_csrf": "wrong"})
        self.assertEqual(r.status, 403)
        self.assertEqual(self.rentals(), [])

    async def test_a_blocked_owner_loses_the_form(self):
        admin, owner, lid = await self.world()
        await owner.get("/owner/rental/new")
        token = owner.csrf()
        await admin.post(f"/admin/owner/{self.owner_id()}/block", {}, page=f"/admin/owner/{self.owner_id()}")
        r = await owner.get("/owner/rental/new")
        self.assertEqual(r.status, 303)
        r = await owner.go("POST", "/owner/rental/new", {"listing": str(lid), "rent": "300", "date": "2026-10-26", "_csrf": token})
        self.assertEqual(r.status, 303)
        self.assertEqual(self.rentals(), [])


class ButtonsTests(RentalCase):
    async def test_the_front_page_card_and_the_buttons(self):
        admin, owner, lid = await self.world()
        await owner.get("/owner")
        self.assertIn("rent-card", owner.text)
        self.assertIn('href="/owner/rental/new"', owner.text)
        self.assertNotIn("com-card", owner.text)                                          # the commission card still waits for a first rental
        await owner.get("/owner/commissions")
        self.assertIn('href="/owner/rental/new"', owner.text)                             # the button in the head of «عمولاتي»
        self.assertIn("سجّله هنا لتظهر عمولته", owner.text)                                # and the empty page tells him what to do
        await self.visitor.get("/")
        self.assertNotIn("/owner/rental/new", self.visitor.text)

    async def test_the_page_says_how_the_commission_is_worked_out_and_who_corrects_it(self):
        admin, owner, lid = await self.world()
        await owner.get("/owner/rental/new")
        self.assertIn("نحسب العمولة بالنسبة التي وافقت عليها في تعهدك", owner.text)
        self.assertIn("تتولاه الإدارة", owner.text)
        self.assertIn('href="/owner/commissions"', owner.text)
        self.assertNotIn("<script", owner.text.replace('<script src=', ""))                  # no inline script is needed

    def test_the_new_classes_have_their_rules_in_the_stylesheet(self):
        css = (Path(__file__).resolve().parent.parent / "istiraha" / "static" / "app.css").read_text(encoding="utf-8")
        self.assertRegex(css, r"(?m)^\.com-card,\.offer-card,\.rent-card\{display:flex;")          # the front-page card looks like its neighbours
        self.assertRegex(css, r"(?m)^\.one-form\{max-width:640px\}")                                # and the form does not stretch over a wide screen

    async def test_the_owner_page_is_not_indexed_and_has_no_inline_style(self):
        admin, owner, lid = await self.world()
        await owner.get("/owner/rental/new")
        self.assertIn("noindex", owner.text)
        self.assertNotIn(' style="', owner.text)


class UnitTests(RentalCase):
    async def test_the_checks_and_their_order(self):
        admin, owner, lid = await self.world()
        listing = repo.any_listing(self.db, lid)
        me = self.owner_id()

        def ask(**over):
            args = {"listing": listing, "rent": 300, "when": TODAY, "owner": me, **over}
            return payments.owner_rental_problem(self.db, args["owner"], args["listing"], args["rent"], args["when"], TODAY, NOW)

        self.assertEqual(ask(), "")
        for bad in (None, {**listing, "owner_id": me + 1}, {**listing, "review": "pending"}, {**listing, "review": "rejected"}):
            self.assertIn("استراحاتك المنشورة", ask(listing=bad))
        self.assertIn("استراحاتك المنشورة", ask(owner=me + 1))                           # the advert is not that owner's
        self.assertIn("قيمة الإيجار", ask(rent=None))
        self.assertIn("تاريخ الإيجار", ask(when=None))
        self.assertIn("أقدم", ask(when=date(2026, 10, 11)))
        self.assertEqual(ask(when=date(2026, 10, 12)), "")
        self.assertIn("بعيد", ask(when=date(2027, 10, 27)))
        self.assertEqual(ask(when=date(2027, 10, 26)), "")
        self.assertIn("استراحاتك المنشورة", ask(listing=None, rent=None, when=None))      # the advert is asked about first
        self.assertIn("قيمة الإيجار", ask(rent=None, when=None))                          # then the amount, then the date

    async def test_a_double_tap_is_only_the_same_owner_the_same_figures_within_two_minutes(self):
        admin, owner, lid = await self.world()
        me = self.owner_id()
        await self.record(owner, lid, 300, "2026-10-26")
        found = lambda **over: payments.just_recorded(self.db, **{"owner_id": me, "listing_id": lid, "rent": 300, "when": TODAY, "now": NOW, **over})
        rid = self.rentals()[0]["id"]
        self.assertEqual(found(), rid)
        self.assertIsNone(found(owner_id=me + 1))
        self.assertIsNone(found(listing_id=lid + 1))
        self.assertIsNone(found(rent=301))
        self.assertIsNone(found(when=date(2026, 10, 27)))
        self.assertEqual(found(now=NOW + payments.DOUBLE_TAP_SECONDS - 1), rid)
        self.assertIsNone(found(now=NOW + payments.DOUBLE_TAP_SECONDS + 1))

    async def test_the_manager_rental_is_not_a_double_tap_of_the_owner(self):
        admin, owner, lid = await self.world()
        await self.manager_rents(admin, lid, 300, "2026-10-26")
        self.assertIsNone(payments.just_recorded(self.db, self.owner_id(), lid, 300, TODAY, NOW))
        self.assertEqual(payments.same_day_rental(self.db, lid, TODAY)["rent"], 300)                # but it is a rental of that day

    async def test_who_wrote_a_rental(self):
        admin, owner, lid = await self.world()
        await self.manager_rents(admin, lid, 300, "2026-10-20")
        await self.record(owner, lid, 400, "2026-10-26")
        mine, theirs = self.rentals()
        self.assertFalse(payments.by_owner(mine))
        self.assertTrue(payments.by_owner(theirs))


if __name__ == "__main__":
    unittest.main()
