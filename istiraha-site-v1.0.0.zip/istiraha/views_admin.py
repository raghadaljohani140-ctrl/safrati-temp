"""The manager's side: sign-in, commission, owners and their pledges, adverts, rentals, offers, lists."""
from __future__ import annotations

import asyncio
import re
import secrets
from datetime import timedelta

from . import repo, security, ui, util
from .app import Ctx, html_page, not_found, verify_login
from .server import redirect
from .ui import e, num


def table(headers: list[str], rows: list[list[str]], empty: str = "لا توجد بيانات") -> str:
    if not rows:
        return f'<p class="muted">{e(empty)}</p>'
    head = "".join(f"<th>{e(h)}</th>" for h in headers)
    body = "".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in rows)
    return f'<div class="tbl"><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>'


def tag(kind: str, text: str) -> str:
    return f'<span class="tag {e(kind)}">{e(text)}</span>'


def register(app) -> None:
    db = app.db

    def page(ctx: Ctx, title: str, body: str, status: int = 200):
        return html_page(ctx, title, body, status, noindex=True, admin=True, extra_class="admin")

    def msg(ctx: Ctx) -> str:
        return ui.notice("ok", ctx.flash())

    def late(row, today_iso: str) -> bool:
        return row["pay_status"] == "due" and row["status"] != "cancelled" and row["due_date"] < today_iso

    # ---- sign-in ----------------------------------------------------------------------------------
    @app.route("GET", "/admin/login", "open")
    async def login_page(ctx: Ctx, error: str = ""):
        if ctx.admin:
            return redirect("/admin")
        body = f"""<section class="auth"><h1>لوحة الإدارة</h1>{ui.notice("bad", error)}
<form method="post" action="/admin/login">{ui.csrf_input(ctx.csrf)}
{ui.field("اسم المستخدم", "login", required=True, autocomplete="username", attrs='autocapitalize="none"')}
{ui.field("كلمة المرور", "password", type="password", required=True, autocomplete="current-password")}
<button class="btn big" type="submit">دخول</button></form></section>"""
        return page(ctx, "دخول الإدارة", body)

    @app.route("POST", "/admin/login", "open")
    async def login(ctx: Ctx):
        user, problem = await verify_login(ctx, "admin", ctx.request.field("login").strip().lower()[:40], ctx.request.field("password"))
        if not user:
            return await login_page(ctx, problem)
        db.audit(user["id"], "admin_login")
        return redirect("/admin", ctx.start_session(user["id"], "admin"))

    @app.route("POST", "/admin/logout", "open")
    async def logout(ctx: Ctx):
        return redirect("/admin/login", ctx.end_session("admin"))

    # ---- overview ---------------------------------------------------------------------------------
    @app.route("GET", "/admin", "admin")
    async def dashboard(ctx: Ctx):
        today = ctx.today().isoformat()
        by = {r["review"]: r["n"] for r in db.all("SELECT review, COUNT(*) AS n FROM listings GROUP BY review")}
        owners = db.one("SELECT COUNT(*) AS n FROM users WHERE role = 'owner'")["n"]
        totals = db.one("SELECT COALESCE(SUM(views),0) AS v, COALESCE(SUM(clicks),0) AS c FROM listings")
        rentals = db.all("SELECT * FROM rentals WHERE status != 'cancelled'")
        sums = {"due": 0, "paid": 0, "late": 0, "disputed": 0}
        for r in rentals:
            if late(r, today):
                sums["late"] += r["commission_halalas"]
            elif r["pay_status"] in sums:
                sums[r["pay_status"]] += r["commission_halalas"]
        stat = lambda label, value, href="": (f'<a class="stat" href="{href}"><b>{value}</b><span>{e(label)}</span></a>' if href else f'<div class="stat"><b>{value}</b><span>{e(label)}</span></div>')
        grid = "".join([
            stat("بانتظار المراجعة", num(by.get("pending", 0)), "/admin/listings?status=pending"),
            stat("إعلانات معتمدة", num(by.get("approved", 0)), "/admin/listings?status=approved"),
            stat("مرفوضة أو موقوفة", num(by.get("rejected", 0) + by.get("stopped", 0)), "/admin/listings?status=rejected"),
            stat("أصحاب الاستراحات", num(owners), "/admin/owners"),
            stat("المشاهدات", num(totals["v"])), stat("ضغطات واتساب", num(totals["c"])),
            stat("العمولة الحالية", f"{util.percent_text(db.commission_bp())}%", "/admin/commission"),
            stat("عمليات التأجير", num(len(rentals)), "/admin/rentals"),
        ])
        money = "".join([
            stat("عمولات مستحقة (ر.س)", util.money(sums["due"]), "/admin/rentals?pay=due"), stat("مدفوعة", util.money(sums["paid"]), "/admin/rentals?pay=paid"),
            stat("متأخرة", util.money(sums["late"]), "/admin/rentals?pay=late"), stat("متنازع عليها", util.money(sums["disputed"]), "/admin/rentals?pay=disputed")])
        log = db.all("SELECT a.*, u.name FROM audit a LEFT JOIN users u ON u.id = a.user_id ORDER BY a.id DESC LIMIT 12")
        recent = table(["الوقت", "المستخدم", "العملية", "التفاصيل"], [[e(ui.stamp(a["at"])), e(a["name"] or "—"), e(repo.AUDIT_LABELS.get(a["action"], a["action"])), e(a["detail"])] for a in log])
        body = f'{msg(ctx)}<h1>اللوحة</h1><div class="stats">{grid}</div><h2>العمولات</h2><div class="stats">{money}</div><h2>آخر العمليات</h2>{recent}'
        return page(ctx, "اللوحة", body)

    # ---- commission and pledge --------------------------------------------------------------------------
    @app.route("GET", "/admin/commission", "admin")
    async def commission_page(ctx: Ctx, error: str = ""):
        bp = db.commission_bp()
        history = db.all("SELECT h.*, u.name FROM commission_history h LEFT JOIN users u ON u.id = h.changed_by ORDER BY h.id DESC LIMIT 100")
        rows = [[e(ui.stamp(h["changed_at"])), f'{util.percent_text(h["basis_points"])}%', e(h["name"] or "—"), e(h["note"])] for h in history]
        pledge = db.pledge()
        versions = db.all("SELECT version, created_at FROM pledge_versions ORDER BY version DESC")
        body = f"""{msg(ctx)}{ui.notice("bad", error)}<h1>العمولة والتعهد</h1>
<section class="panel"><h2>النسبة الحالية: <b>{util.percent_text(bp)}%</b></h2>
<p>تسري النسبة الجديدة على الإعلانات الجديدة فقط. الإعلانات السابقة تبقى على النسبة التي وافق عليها أصحابها، ولا تتغير إلا بموافقتهم الجديدة.</p>
<form method="post" action="/admin/commission" class="row2 inline-form">{ui.csrf_input(ctx.csrf)}
{ui.field("النسبة الجديدة %", "percent", util.percent_text(bp), required=True, attrs='inputmode="decimal"', hint="مثل 5 أو 10 أو 7.5")}
{ui.field("سبب التغيير (اختياري)", "note", attrs='maxlength="120"')}<button class="btn" type="submit">حفظ النسبة</button></form></section>
<section class="panel"><h2>سجل النسب</h2>{table(["التاريخ", "النسبة", "بواسطة", "ملاحظة"], rows)}</section>
<section class="panel"><h2>نص التعهد (النسخة {pledge["version"]})</h2><p class="muted">أي تعديل ينشئ نسخة جديدة تظهر للإعلانات الجديدة، والنسخ القديمة محفوظة كما وافق عليها أصحابها. راجع النص قانونيًا قبل الإطلاق.</p>
<form method="post" action="/admin/pledge" class="stack">{ui.csrf_input(ctx.csrf)}{ui.textarea("النص", "body", pledge["body"], rows=8)}
<button class="btn" type="submit">حفظ كنسخة جديدة</button></form><p class="muted">النسخ: {" ، ".join(str(v["version"]) for v in versions)}</p></section>"""
        return page(ctx, "العمولة", body)

    @app.route("POST", "/admin/commission", "admin")
    async def commission_save(ctx: Ctx):
        bp = util.parse_percent(ctx.request.field("percent"))
        if bp is None:
            return await commission_page(ctx, "اكتب نسبة صحيحة بين 0 و100")
        note = ctx.request.field("note").strip()[:120]
        if bp != db.commission_bp():
            with db.transaction():
                db.run("INSERT INTO commission_history(basis_points, changed_at, changed_by, note) VALUES (?, ?, ?, ?)", (bp, app.clock(), ctx.admin["id"], note))
                db.audit(ctx.admin["id"], "commission", f"{util.percent_text(bp)}%")
        return redirect("/admin/commission?msg=تم حفظ النسبة، وتسري على الإعلانات الجديدة")

    @app.route("POST", "/admin/pledge", "admin")
    async def pledge_save(ctx: Ctx):
        body = ctx.request.field("body").strip()
        if len(body) < 60 or len(body) > 4000:
            return await commission_page(ctx, "نص التعهد يجب أن يكون بين 60 و4000 حرف")
        current = db.pledge()
        if body != current["body"]:
            with db.transaction():
                db.run("INSERT INTO pledge_versions(version, body, created_at, created_by) VALUES (?, ?, ?, ?)", (current["version"] + 1, body, app.clock(), ctx.admin["id"]))
                db.audit(ctx.admin["id"], "pledge", f"نسخة {current['version'] + 1}")
        return redirect("/admin/commission?msg=حفظنا نسخة جديدة من التعهد")

    # ---- owners and their agreements ---------------------------------------------------------------------
    @app.route("GET", "/admin/owners", "admin")
    async def owners(ctx: Ctx):
        rows = db.all("""SELECT u.*, (SELECT COUNT(*) FROM listings WHERE owner_id = u.id) AS ads,
                         (SELECT COUNT(*) FROM consents WHERE owner_id = u.id) AS agreed FROM users u WHERE role = 'owner' ORDER BY u.id DESC LIMIT 500""")
        table_rows = [[f'<a href="/admin/owner/{r["id"]}">{e(r["name"])}</a>', e(util.show_phone(r["login"])), num(r["ads"]), num(r["agreed"]),
                       e(ui.stamp(r["created_at"])), tag("ok" if r["status"] == "active" else "bad", "نشط" if r["status"] == "active" else "موقوف")] for r in rows]
        return page(ctx, "الملاك", f'{msg(ctx)}<h1>أصحاب الاستراحات</h1>{table(["الاسم", "الجوال", "الإعلانات", "الموافقات", "التسجيل", "الحالة"], table_rows)}')

    @app.route("GET", r"/admin/owner/(\d{1,9})", "admin")
    async def owner_detail(ctx: Ctx, raw: str, temp: str = ""):
        u = db.one("SELECT * FROM users WHERE id = ? AND role = 'owner'", (int(raw),))
        if not u:
            return not_found(ctx)
        ads = db.all("SELECT id, title, review FROM listings WHERE owner_id = ? ORDER BY id DESC", (u["id"],))
        agreements = db.all("""SELECT c.*, l.title FROM consents c LEFT JOIN listings l ON l.id = c.listing_id WHERE c.owner_id = ? ORDER BY c.id DESC""", (u["id"],))
        agree_rows = [[e(ui.stamp(c["accepted_at"])), e(c["title"] or "لم يكتمل الإعلان"), f'{util.percent_text(c["basis_points"])}%', f'نسخة {c["pledge_version"]}',
                       f'<details><summary>النص</summary><p>{e(c["pledge_text"])}</p><small>بصمة العنوان: {e(c["ip_fingerprint"])}</small></details>'] for c in agreements]
        state = "block" if u["status"] == "active" else "unblock"
        notice = ui.notice("ok", f"كلمة المرور المؤقتة (تظهر مرة واحدة): {temp}") if temp else ""
        body = f"""{msg(ctx)}{notice}<h1>{e(u["name"])}</h1><p>الجوال: {e(util.show_phone(u["login"]))} · آخر دخول: {e(ui.stamp(u["last_login"]))}</p>
<div class="actions"><form method="post" action="/admin/owner/{u["id"]}/{state}">{ui.csrf_input(ctx.csrf)}<button class="btn ghost" type="submit">{"إيقاف الحساب" if state == "block" else "إعادة تفعيل الحساب"}</button></form>
<form method="post" action="/admin/owner/{u["id"]}/reset">{ui.csrf_input(ctx.csrf)}<button class="btn ghost" type="submit">كلمة مرور مؤقتة جديدة</button></form></div>
<h2>الإعلانات</h2>{table(["الإعلان", "الحالة"], [[f'<a href="/admin/listing/{a["id"]}">{e(a["title"])}</a>', e(repo.REVIEW_LABELS[a["review"]])] for a in ads])}
<h2>الموافقات على التعهد</h2>{table(["التاريخ", "الإعلان", "العمولة", "النص", "التفاصيل"], agree_rows)}"""
        return page(ctx, u["name"], body)

    @app.route("POST", r"/admin/owner/(\d{1,9})/(block|unblock)", "admin")
    async def owner_state(ctx: Ctx, raw: str, action: str):
        u = db.one("SELECT * FROM users WHERE id = ? AND role = 'owner'", (int(raw),))
        if not u:
            return not_found(ctx)
        db.run("UPDATE users SET status = ? WHERE id = ?", ("blocked" if action == "block" else "active", u["id"]))
        if action == "block":
            db.run("DELETE FROM sessions WHERE user_id = ?", (u["id"],))
        db.audit(ctx.admin["id"], action + "_owner", str(u["id"]))
        return redirect(f"/admin/owner/{u['id']}?msg=تم")

    @app.route("POST", r"/admin/owner/(\d{1,9})/reset", "admin")
    async def owner_reset(ctx: Ctx, raw: str):
        u = db.one("SELECT * FROM users WHERE id = ? AND role = 'owner'", (int(raw),))
        if not u:
            return not_found(ctx)
        temp = secrets.token_urlsafe(9)
        hashed = await asyncio.to_thread(security.hash_password, temp)
        db.run("UPDATE users SET pass_hash = ?, failed = 0, locked_until = 0 WHERE id = ?", (hashed, u["id"]))
        db.run("DELETE FROM sessions WHERE user_id = ?", (u["id"],))
        db.audit(ctx.admin["id"], "reset_password", str(u["id"]))
        return await owner_detail(ctx, raw, temp)

    # ---- adverts -------------------------------------------------------------------------------------------
    @app.route("GET", "/admin/listings", "admin")
    async def listings(ctx: Ctx):
        status = ctx.request.query.get("status", "")
        where, args = ("WHERE l.review = ?", (status,)) if status in repo.REVIEW_LABELS else ("", ())
        rows = db.all(f"""SELECT l.*, c.name AS city, u.name AS owner FROM listings l JOIN cities c ON c.id = l.city_id JOIN users u ON u.id = l.owner_id
                          {where} ORDER BY (l.review = 'pending') DESC, l.id DESC LIMIT 300""", args)
        tabs = '<div class="tabs"><a href="/admin/listings">الكل</a>' + "".join(f'<a href="/admin/listings?status={k}"{" class=on" if k == status else ""}>{e(v)}</a>' for k, v in repo.REVIEW_LABELS.items()) + "</div>"
        table_rows = [[f'<a href="/admin/listing/{r["id"]}">{e(r["title"])}</a>', e(r["city"]), e(r["owner"]), f'{num(r["price"])} / {e(repo.UNIT_SHORT[r["unit"]])}',
                       tag({"approved": "ok", "pending": "warn"}.get(r["review"], "bad"), repo.REVIEW_LABELS[r["review"]]) + ("" if r["owner_active"] else tag("muted", "موقوف من المالك")),
                       "⭐" if r["featured"] else ""] for r in rows]
        return page(ctx, "الإعلانات", f'{msg(ctx)}<h1>الإعلانات</h1>{tabs}{table(["الإعلان", "المدينة", "المالك", "السعر", "الحالة", ""], table_rows)}')

    @app.route("GET", r"/admin/listing/(\d{1,9})", "admin")
    async def listing_detail(ctx: Ctx, raw: str):
        row = repo.any_listing(db, int(raw))
        if not row:
            return not_found(ctx)
        owner = db.one("SELECT * FROM users WHERE id = ?", (row["owner_id"],))
        consent = db.one("SELECT * FROM consents WHERE id = ?", (row["consent_id"],))
        photos = repo.photos_of(db, row["id"])
        pics = "".join(f'<img src="/media/{e(p["filename"])}" alt="" width="160" height="120" loading="lazy">' for p in photos)
        form = lambda action, label, cls="ghost", note=False: (
            f'<form method="post" action="/admin/listing/{row["id"]}/{action}" class="inline-form">{ui.csrf_input(ctx.csrf)}'
            + (f'<input name="note" placeholder="السبب (يظهر للمالك)" maxlength="200">' if note else "") + f'<button class="btn {cls}" type="submit">{e(label)}</button></form>')
        body = f"""{msg(ctx)}<h1>{e(row["title"])}</h1>
<p>{tag({"approved": "ok", "pending": "warn"}.get(row["review"], "bad"), repo.REVIEW_LABELS[row["review"]])} المالك: <a href="/admin/owner/{owner["id"]}">{e(owner["name"])}</a> ({e(util.show_phone(owner["login"]))}) · {e(row["city_name"])} {e(row["district"])} · {e(row["category_name"])}</p>
<p>السعر {num(row["price"])} ر.س / {e(repo.UNITS[row["unit"]])} · واتساب {e(util.show_phone(row["whatsapp"]))} · مشاهدات {num(row["views"])} · ضغطات {num(row["clicks"])} · عمولة متفق عليها {util.percent_text(consent["basis_points"])}%</p>
<div class="pics-row">{pics}</div>{f'<p>{e(row["description"])}</p>' if row["description"] else ""}
{f'<p class="note bad">آخر ملاحظة: {e(row["review_note"])}</p>' if row["review_note"] else ""}
<div class="actions"><a class="btn ghost" href="/r/{row["id"]}">معاينة</a>{form("approve", "اعتماد ونشر", "")}{form("reject", "رفض", "ghost", True)}{form("stop", "إيقاف", "ghost", True)}
{form("feature", "إلغاء التمييز" if row["featured"] else "تمييز الإعلان")}</div>
<p><a class="btn sun" href="/admin/rental/new?listing={row["id"]}">تسجيل عملية تأجير</a></p>"""
        return page(ctx, row["title"], body)

    @app.route("POST", r"/admin/listing/(\d{1,9})/(approve|reject|stop|feature)", "admin")
    async def listing_action(ctx: Ctx, raw: str, action: str):
        row = repo.any_listing(db, int(raw))
        if not row:
            return not_found(ctx)
        note = ctx.request.field("note").strip()[:200]
        now = app.clock()
        if action == "approve":
            db.run("UPDATE listings SET review='approved', review_note='', approved_at=?, updated_at=? WHERE id=?", (now, now, row["id"]))
        elif action in ("reject", "stop"):
            if not note:
                return redirect(f"/admin/listing/{row['id']}?msg=اكتب السبب ليراه المالك")
            db.run("UPDATE listings SET review=?, review_note=?, updated_at=? WHERE id=?", ("rejected" if action == "reject" else "stopped", note, now, row["id"]))
        else:
            db.run("UPDATE listings SET featured = 1 - featured WHERE id = ?", (row["id"],))
        db.audit(ctx.admin["id"], f"listing_{action}", str(row["id"]))
        return redirect(f"/admin/listing/{row['id']}?msg=تم")

    # ---- rentals and commissions ----------------------------------------------------------------------------
    def _rental_row(r, today_iso: str) -> list[str]:
        is_late = late(r, today_iso)
        pay = tag("bad", "متأخرة") if is_late else tag({"paid": "ok", "due": "warn", "disputed": "bad", "waived": "muted"}[r["pay_status"]], repo.PAY_STATUS[r["pay_status"]])
        return [f'<a href="/admin/rental/{r["id"]}">#{r["id"]}</a>', e(ui.day_text(r["rental_date"])), e(r["title"]), e(r["owner_name"]), num(r["rent"]),
                f'{util.percent_text(r["basis_points"])}%', util.money(r["commission_halalas"]), e(repo.RENTAL_STATUS[r["status"]]), pay]

    @app.route("GET", "/admin/rentals", "admin")
    async def rentals(ctx: Ctx):
        pay = ctx.request.query.get("pay", "")
        today = ctx.today().isoformat()
        rows = db.all("""SELECT r.*, l.title, u.name AS owner_name FROM rentals r JOIN listings l ON l.id = r.listing_id JOIN users u ON u.id = r.owner_id
                         ORDER BY r.rental_date DESC, r.id DESC LIMIT 500""")
        if pay == "late":
            rows = [r for r in rows if late(r, today)]
        elif pay in repo.PAY_STATUS:
            rows = [r for r in rows if r["pay_status"] == pay and r["status"] != "cancelled" and not late(r, today)]
        tabs = ('<div class="tabs"><a href="/admin/rentals">الكل</a>' + "".join(f'<a href="/admin/rentals?pay={k}"{" class=on" if k == pay else ""}>{e(v)}</a>' for k, v in repo.PAY_STATUS.items())
                + f'<a href="/admin/rentals?pay=late"{" class=on" if pay == "late" else ""}>متأخرة</a></div>')
        total = sum(r["commission_halalas"] for r in rows if r["status"] != "cancelled")
        body = (f'{msg(ctx)}<div class="head"><h1>عمليات التأجير والعمولات</h1><a class="btn sun" href="/admin/rental/new">تسجيل عملية</a></div>{tabs}'
                f'<p>إجمالي العمولات في هذه القائمة (بدون الملغي): <b>{util.money(total)}</b> ر.س</p>'
                + table(["#", "التاريخ", "الإعلان", "المالك", "الإيجار", "النسبة", "العمولة", "الحالة", "السداد"], [_rental_row(r, today) for r in rows]))
        return page(ctx, "التأجير", body)

    def _rental_form(ctx: Ctx, v: dict, error: str = "") -> str:
        ads = db.all("SELECT l.id, l.title, u.name FROM listings l JOIN users u ON u.id = l.owner_id WHERE l.review = 'approved' ORDER BY l.id DESC")
        return f"""<form method="post" action="/admin/rental/new" class="stack">{ui.csrf_input(ctx.csrf)}{ui.notice("bad", error)}
{ui.select("الإعلان", "listing", [(a["id"], f'#{a["id"]} {a["title"]} — {a["name"]}') for a in ads], v.get("listing", ""), blank="اختر الإعلان")}
<div class="row2">{ui.field("قيمة الإيجار (ر.س)", "rent", v.get("rent", ""), required=True, attrs='inputmode="numeric"')}
{ui.field("تاريخ الإيجار", "date", v.get("date", ctx.today().isoformat()), type="date", required=True)}</div>
{ui.select("حالة العملية", "status", list(repo.RENTAL_STATUS.items()), v.get("status", "confirmed"))}
{ui.field("اسم العميل أو رقمه (اختياري)", "customer", v.get("customer", ""), attrs='maxlength="80"')}
{ui.textarea("ملاحظة", "note", v.get("note", ""), rows=3)}
<button class="btn sun big" type="submit">تسجيل العملية وحساب العمولة</button></form>"""

    @app.route("GET", "/admin/rental/new", "admin")
    async def rental_new(ctx: Ctx):
        return page(ctx, "تسجيل عملية", f'<h1>تسجيل عملية تأجير</h1>{_rental_form(ctx, {"listing": ctx.request.query.get("listing", "")})}')

    @app.route("POST", "/admin/rental/new", "admin")
    async def rental_create(ctx: Ctx):
        r = ctx.request
        v = {k: r.field(k) for k in ("listing", "rent", "date", "status", "customer", "note")}
        listing = repo.any_listing(db, util.parse_int(v["listing"], 1, 10**9) or 0)
        rent, when = util.parse_int(v["rent"], 1, 10_000_000), util.parse_date(v["date"])
        if not listing or not rent or not when or v["status"] not in repo.RENTAL_STATUS:
            return page(ctx, "تسجيل عملية", f'<h1>تسجيل عملية تأجير</h1>{_rental_form(ctx, v, "اختر الإعلان واكتب القيمة والتاريخ")}', 400)
        consent = db.one("SELECT * FROM consents WHERE id = ?", (listing["consent_id"],))
        halalas = util.to_halalas(util.commission(rent, consent["basis_points"]))
        with db.transaction():
            rid = db.run("""INSERT INTO rentals(listing_id, owner_id, consent_id, basis_points, rent, commission_halalas, rental_date, status, due_date, created_at, created_by, customer)
                            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""", (listing["id"], listing["owner_id"], consent["id"], consent["basis_points"], rent, halalas, when.isoformat(),
                                                                  v["status"], (when + timedelta(days=db.due_days())).isoformat(), app.clock(), ctx.admin["id"], v["customer"].strip()[:80]))
            if v["note"].strip():
                db.run("INSERT INTO rental_notes(rental_id, author_id, kind, body, created_at) VALUES (?, ?, 'note', ?, ?)", (rid, ctx.admin["id"], v["note"].strip()[:500], app.clock()))
            db.audit(ctx.admin["id"], "rental_new", f"رقم {rid} · إيجار {rent} · عمولة {util.percent_text(consent['basis_points'])}%")
        return redirect(f"/admin/rental/{rid}?msg=سجلنا العملية، العمولة {util.money(halalas)} ريال")

    @app.route("GET", r"/admin/rental/(\d{1,9})", "admin")
    async def rental_detail(ctx: Ctx, raw: str):
        r = db.one("""SELECT r.*, l.title, u.name AS owner_name, u.login AS owner_login FROM rentals r JOIN listings l ON l.id = r.listing_id
                      JOIN users u ON u.id = r.owner_id WHERE r.id = ?""", (int(raw),))
        if not r:
            return not_found(ctx)
        notes = db.all("SELECT n.*, u.name FROM rental_notes n LEFT JOIN users u ON u.id = n.author_id WHERE n.rental_id = ? ORDER BY n.id", (r["id"],))
        kinds = {"note": "ملاحظة", "objection": "اعتراض", "payment": "سداد"}
        log = "".join(f'<li class="{e(n["kind"])}"><b>{e(kinds[n["kind"]])}</b> <small>{e(ui.stamp(n["created_at"]))} · {e(n["name"] or "—")}</small><p>{e(n["body"])}</p></li>' for n in notes)
        today = ctx.today().isoformat()
        body = f"""{msg(ctx)}<h1>عملية #{r["id"]}</h1>
<ul class="facts"><li><b>الإعلان</b><a href="/admin/listing/{r["listing_id"]}">{e(r["title"])}</a></li><li><b>المالك</b><a href="/admin/owner/{r["owner_id"]}">{e(r["owner_name"])}</a> {e(util.show_phone(r["owner_login"]))}</li>
<li><b>التاريخ</b>{e(ui.day_text(r["rental_date"]))}</li><li><b>الإيجار</b>{num(r["rent"])} ر.س</li><li><b>النسبة المتفق عليها</b>{util.percent_text(r["basis_points"])}% (موافقة رقم {r["consent_id"]})</li>
<li><b>العمولة المستحقة</b><b>{util.money(r["commission_halalas"])} ر.س</b></li><li><b>آخر موعد للسداد</b>{e(ui.day_text(r["due_date"]))}{" " + tag("bad", "متأخرة") if late(r, today) else ""}</li>
<li><b>العميل</b>{e(r["customer"] or "—")}</li></ul>
<form method="post" action="/admin/rental/{r["id"]}/update" class="stack panel"><h2>تحديث العملية</h2>{ui.csrf_input(ctx.csrf)}
<div class="row3">{ui.field("قيمة الإيجار", "rent", r["rent"], attrs='inputmode="numeric"', hint="تغييرها يعيد حساب العمولة بنفس النسبة")}
{ui.select("حالة العملية", "status", list(repo.RENTAL_STATUS.items()), r["status"])}{ui.select("حالة السداد", "pay_status", list(repo.PAY_STATUS.items()), r["pay_status"])}</div>
<button class="btn" type="submit">حفظ</button></form>
<form method="post" action="/admin/rental/{r["id"]}/note" class="stack panel"><h2>سجل الملاحظات والاعتراضات</h2>{ui.csrf_input(ctx.csrf)}
<ul class="log">{log or '<li class="muted">لا توجد ملاحظات</li>'}</ul>
<div class="row2">{ui.select("النوع", "kind", list(kinds.items()), "note")}{ui.field("النص", "body", required=True, attrs='maxlength="500"')}</div><button class="btn" type="submit">إضافة للسجل</button></form>"""
        return page(ctx, f"عملية {r['id']}", body)

    @app.route("POST", r"/admin/rental/(\d{1,9})/update", "admin")
    async def rental_update(ctx: Ctx, raw: str):
        r = db.one("SELECT * FROM rentals WHERE id = ?", (int(raw),))
        if not r:
            return not_found(ctx)
        f = ctx.request
        rent = util.parse_int(f.field("rent"), 1, 10_000_000)
        status, pay = f.field("status"), f.field("pay_status")
        if not rent or status not in repo.RENTAL_STATUS or pay not in repo.PAY_STATUS:
            return redirect(f"/admin/rental/{r['id']}?msg=قيم غير صحيحة")
        halalas = util.to_halalas(util.commission(rent, r["basis_points"]))
        paid_at = r["paid_at"] if pay == "paid" and r["paid_at"] else (app.clock() if pay == "paid" else None)
        db.run("UPDATE rentals SET rent=?, commission_halalas=?, status=?, pay_status=?, paid_at=? WHERE id=?", (rent, halalas, status, pay, paid_at, r["id"]))
        for what, old, new in (("rent", r["rent"], rent), ("status", r["status"], status), ("pay", r["pay_status"], pay)):
            if old != new:
                db.run("INSERT INTO rental_notes(rental_id, author_id, kind, body, created_at) VALUES (?, ?, ?, ?, ?)",
                       (r["id"], ctx.admin["id"], "payment" if what == "pay" else "note", f"تغيير {what}: {old} ← {new}", app.clock()))
        db.audit(ctx.admin["id"], "rental_update", f"رقم {r['id']}")
        return redirect(f"/admin/rental/{r['id']}?msg=تم الحفظ")

    @app.route("POST", r"/admin/rental/(\d{1,9})/note", "admin")
    async def rental_note(ctx: Ctx, raw: str):
        r = db.one("SELECT id FROM rentals WHERE id = ?", (int(raw),))
        kind, body = ctx.request.field("kind"), ctx.request.field("body").strip()[:500]
        if not r or kind not in ("note", "objection", "payment") or not body:
            return redirect(f"/admin/rental/{raw}?msg=اكتب النص")
        db.run("INSERT INTO rental_notes(rental_id, author_id, kind, body, created_at) VALUES (?, ?, ?, ?, ?)", (r["id"], ctx.admin["id"], kind, body, app.clock()))
        return redirect(f"/admin/rental/{r['id']}?msg=أضفنا للسجل")

    # ---- cities, types, facilities, offers, settings -------------------------------------------------------
    KINDS = {"cities": ("المدن", "cities"), "categories": ("أنواع الاستراحات", "categories"), "amenities": ("المرافق", "amenities")}

    @app.route("GET", "/admin/settings", "admin")
    async def settings_page(ctx: Ctx):
        blocks = ""
        add_field = ui.field("إضافة", "name", attrs='maxlength="40"')
        for key, (title, tbl) in KINDS.items():
            rows = db.all(f"SELECT * FROM {tbl} ORDER BY sort, id")
            items = "".join(
                f'<li>{e(r["name"])} {"" if r["active"] else tag("muted", "مخفي")}'
                f'<form method="post" action="/admin/lookup/{key}/{r["id"]}/toggle" class="inline">{ui.csrf_input(ctx.csrf)}<button class="link" type="submit">{"إخفاء" if r["active"] else "إظهار"}</button></form></li>' for r in rows)
            blocks += (f'<section class="panel"><h2>{e(title)}</h2><ul class="lookup">{items}</ul>'
                       f'<form method="post" action="/admin/lookup/{key}" class="row2 inline-form">{ui.csrf_input(ctx.csrf)}{add_field}<button class="btn" type="submit">إضافة</button></form></section>')
        body = f"""{msg(ctx)}<h1>الإعدادات</h1>{blocks}
<section class="panel"><h2>موعد سداد العمولة</h2><form method="post" action="/admin/due" class="row2 inline-form">{ui.csrf_input(ctx.csrf)}
{ui.field("عدد الأيام بعد تاريخ الإيجار", "days", db.due_days(), attrs='inputmode="numeric"')}<button class="btn" type="submit">حفظ</button></form></section>
<section class="panel"><h2>تغيير كلمة مرور الإدارة</h2><form method="post" action="/admin/password" class="stack">{ui.csrf_input(ctx.csrf)}
{ui.field("كلمة المرور الحالية", "current", type="password", autocomplete="current-password")}{ui.field("كلمة المرور الجديدة", "new", type="password", autocomplete="new-password")}
<button class="btn" type="submit">تغيير</button></form></section>"""
        return page(ctx, "الإعدادات", body)

    @app.route("POST", r"/admin/lookup/(cities|categories|amenities)", "admin")
    async def lookup_add(ctx: Ctx, key: str):
        name = re.sub(r"\s+", " ", ctx.request.field("name")).strip()[:40]
        table_name = KINDS[key][1]
        if len(name) < 2:
            return redirect("/admin/settings?msg=اكتب الاسم")
        if db.one(f"SELECT 1 FROM {table_name} WHERE name = ?", (name,)):
            return redirect("/admin/settings?msg=الاسم موجود")
        db.run(f"INSERT INTO {table_name}(name, sort) VALUES (?, (SELECT COALESCE(MAX(sort), 0) + 1 FROM {table_name}))", (name,))
        db.audit(ctx.admin["id"], f"add_{key}", name)
        return redirect("/admin/settings?msg=تمت الإضافة")

    @app.route("POST", r"/admin/lookup/(cities|categories|amenities)/(\d{1,9})/toggle", "admin")
    async def lookup_toggle(ctx: Ctx, key: str, raw: str):
        db.run(f"UPDATE {KINDS[key][1]} SET active = 1 - active WHERE id = ?", (int(raw),))
        return redirect("/admin/settings?msg=تم")

    @app.route("POST", "/admin/due", "admin")
    async def due_save(ctx: Ctx):
        days = util.parse_int(ctx.request.field("days"), 0, 365)
        if days is None:
            return redirect("/admin/settings?msg=رقم غير صحيح")
        db.run("INSERT INTO settings(key, value) VALUES ('due_days', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value", (str(days),))
        return redirect("/admin/settings?msg=تم الحفظ")

    @app.route("POST", "/admin/password", "admin")
    async def password_change(ctx: Ctx):
        f = ctx.request
        if not await asyncio.to_thread(security.check_password, f.field("current"), ctx.admin["pass_hash"]):
            return redirect("/admin/settings?msg=كلمة المرور الحالية غير صحيحة")
        problem = security.password_problem(f.field("new"))
        if problem:
            return redirect(f"/admin/settings?msg={problem}")
        hashed = await asyncio.to_thread(security.hash_password, f.field("new"))
        db.run("UPDATE users SET pass_hash = ? WHERE id = ?", (hashed, ctx.admin["id"]))
        db.audit(ctx.admin["id"], "admin_password")
        return redirect("/admin/settings?msg=تم تغيير كلمة المرور")

    @app.route("GET", "/admin/offers", "admin")
    async def offers_page(ctx: Ctx, error: str = ""):
        today = ctx.today().isoformat()
        rows = db.all("""SELECT o.*, c.name AS city, g.name AS category, l.title AS listing FROM offers o LEFT JOIN cities c ON c.id = o.city_id
                         LEFT JOIN categories g ON g.id = o.category_id LEFT JOIN listings l ON l.id = o.listing_id ORDER BY o.id DESC""")
        trs = []
        for o in rows:
            scope = o["listing"] or " · ".join(x for x in (o["city"], o["category"]) if x) or "كل الإعلانات"
            live = o["active"] and o["starts_on"] <= today <= o["ends_on"]
            trs.append([e(o["title"]), f'{o["percent"]}%', e(scope), f'{e(ui.day_text(o["starts_on"]))} — {e(ui.day_text(o["ends_on"]))}', tag("ok" if live else "muted", "جارٍ" if live else "غير جارٍ"),
                        f'<form method="post" action="/admin/offer/{o["id"]}/toggle" class="inline">{ui.csrf_input(ctx.csrf)}<button class="link" type="submit">{"إيقاف" if o["active"] else "تفعيل"}</button></form>'
                        f'<form method="post" action="/admin/offer/{o["id"]}/delete" class="inline">{ui.csrf_input(ctx.csrf)}<button class="link bad" type="submit">حذف</button></form>'])
        cities = [(c["id"], c["name"]) for c in db.all("SELECT * FROM cities WHERE active = 1 ORDER BY sort, id")]
        cats = [(c["id"], c["name"]) for c in db.all("SELECT * FROM categories WHERE active = 1 ORDER BY sort, id")]
        body = f"""{msg(ctx)}{ui.notice("bad", error)}<h1>العروض والخصومات</h1>{table(["العرض", "الخصم", "ينطبق على", "المدة", "الحالة", ""], trs)}
<form method="post" action="/admin/offers" class="stack panel"><h2>عرض جديد</h2>{ui.csrf_input(ctx.csrf)}
<div class="row2">{ui.field("عنوان العرض", "title", required=True, attrs='maxlength="60"')}{ui.field("نسبة الخصم %", "percent", required=True, attrs='inputmode="numeric"')}</div>
<div class="row3">{ui.select("المدينة (اختياري)", "city", cities, blank="كل المدن")}{ui.select("النوع (اختياري)", "category", cats, blank="كل الأنواع")}{ui.field("رقم إعلان محدد (اختياري)", "listing", attrs='inputmode="numeric"')}</div>
<div class="row2">{ui.field("من", "starts", ctx.today().isoformat(), type="date", required=True)}{ui.field("إلى", "ends", type="date", required=True)}</div>
<button class="btn" type="submit">إضافة العرض</button></form>"""
        return page(ctx, "العروض", body)

    @app.route("POST", "/admin/offers", "admin")
    async def offer_add(ctx: Ctx):
        f = ctx.request
        title, pct = f.field("title").strip()[:60], util.parse_int(f.field("percent"), 1, 90)
        start, end = util.parse_date(f.field("starts")), util.parse_date(f.field("ends"))
        city, cat = util.parse_int(f.field("city"), 1, 10**9), util.parse_int(f.field("category"), 1, 10**9)
        lid = util.parse_int(f.field("listing"), 1, 10**9) if f.field("listing").strip() else None
        if len(title) < 3 or not pct or not start or not end or end < start:
            return await offers_page(ctx, "اكتب عنوانًا ونسبة بين 1 و90 وتاريخين صحيحين")
        if lid and not repo.any_listing(db, lid):
            return await offers_page(ctx, "رقم الإعلان غير موجود")
        db.run("INSERT INTO offers(title, percent, city_id, category_id, listing_id, starts_on, ends_on) VALUES (?,?,?,?,?,?,?)",
               (title, pct, city, cat, lid, start.isoformat(), end.isoformat()))
        db.audit(ctx.admin["id"], "offer_new", f"{title} {pct}%")
        return redirect("/admin/offers?msg=أضفنا العرض")

    @app.route("POST", r"/admin/offer/(\d{1,9})/(toggle|delete)", "admin")
    async def offer_edit(ctx: Ctx, raw: str, action: str):
        if action == "toggle":
            db.run("UPDATE offers SET active = 1 - active WHERE id = ?", (int(raw),))
        else:
            db.run("DELETE FROM offers WHERE id = ?", (int(raw),))
        return redirect("/admin/offers?msg=تم")
