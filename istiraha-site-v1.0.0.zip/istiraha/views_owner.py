"""The owner's side: account, the commission pledge, adverts, photos, dates."""
from __future__ import annotations

import asyncio
import re
import secrets

from . import images, repo, security, ui, util
from .app import OWNER_COOKIE, Ctx, forbidden, html_page, not_found, verify_login
from .server import Response, redirect, text_response
from .ui import e, num


def _upload_note(ctx: Ctx) -> str:
    """The photo page's own message after the phone has uploaded the pictures one by one (only numbers travel in the address)."""
    done, bad = ctx.request.query.get("up", ""), ctx.request.query.get("bad", "")
    if done.isdigit() and len(done) < 4:
        return f"تم رفع {int(done)} صورة" + (" وتعذّر رفع بعض الصور (تأكد أنها JPG أو PNG أو WebP وأقل من الحد المسموح)" if bad == "1" else "")
    return ""


def register(app) -> None:
    db = app.db

    def _next(ctx: Ctx) -> str:
        n = ctx.request.field("next") if ctx.request.method == "POST" else ctx.request.query.get("next", "")
        return n if re.fullmatch(r"/owner[A-Za-z0-9_/-]{0,100}", n or "") else "/owner"

    # ---- account ------------------------------------------------------------------------------
    @app.route("GET", "/owner/login", "open")
    async def login_page(ctx: Ctx, error: str = ""):
        if ctx.owner:
            return redirect("/owner")
        nxt = ctx.request.query.get("next", "")
        body = f"""<section class="auth"><h1>دخول أصحاب الاستراحات</h1>{ui.notice("bad", error)}
<form method="post" action="/owner/login">{ui.csrf_input(ctx.csrf)}<input type="hidden" name="next" value="{e(nxt)}">
{ui.field("رقم الجوال", "phone", type="tel", required=True, autocomplete="username", attrs='inputmode="tel" placeholder="05XXXXXXXX"')}
{ui.field("كلمة المرور", "password", type="password", required=True, autocomplete="current-password")}
<button class="btn big" type="submit">دخول</button></form>
<p class="alt">ما عندك حساب؟ <a href="/owner/register">أنشئ حسابًا</a></p></section>"""
        return html_page(ctx, "دخول الملاك", body, noindex=True)

    @app.route("POST", "/owner/login", "open")
    async def login(ctx: Ctx):
        phone = util.normalize_phone(ctx.request.field("phone")) or ""
        user, problem = await verify_login(ctx, "owner", phone, ctx.request.field("password"))
        if not user:
            return await login_page(ctx, problem)
        cookies = ctx.start_session(user["id"], "owner")
        return redirect(_next(ctx), cookies)

    @app.route("GET", "/owner/register", "open")
    async def register_page(ctx: Ctx, errors: dict | None = None, values: dict | None = None):
        errors, values = errors or {}, values or {}
        body = f"""<section class="auth"><h1>حساب جديد لصاحب استراحة</h1>{ui.notice("bad", errors.get("form", ""))}
<form method="post" action="/owner/register">{ui.csrf_input(ctx.csrf)}
{ui.field("الاسم", "name", values.get("name", ""), required=True, error=errors.get("name", ""), autocomplete="name", attrs='maxlength="60"')}
{ui.field("رقم الجوال", "phone", values.get("phone", ""), type="tel", required=True, error=errors.get("phone", ""), autocomplete="username", hint="يُستخدم لتسجيل الدخول", attrs='inputmode="tel" placeholder="05XXXXXXXX"')}
{ui.field("كلمة المرور", "password", type="password", required=True, error=errors.get("password", ""), autocomplete="new-password", hint="8 خانات على الأقل")}
<div class="hp" aria-hidden="true"><label>لا تملأ هذا الحقل<input name="website" tabindex="-1" autocomplete="off"></label></div>
<button class="btn big" type="submit">إنشاء الحساب</button></form>
<p class="alt">عندك حساب؟ <a href="/owner/login">سجّل دخولك</a></p></section>"""
        return html_page(ctx, "حساب جديد", body, noindex=True)

    @app.route("POST", "/owner/register", "open")
    async def register_post(ctx: Ctx):
        r = ctx.request
        if r.field("website"):
            return redirect("/")                                   # a robot filled the hidden field
        if not app.register_limit.allow(r.ip):
            return await register_page(ctx, {"form": "محاولات كثيرة، جرّب بعد ساعة"})
        values = {"name": r.field("name").strip()[:60], "phone": r.field("phone").strip()[:20]}
        errors: dict[str, str] = {}
        if len(values["name"]) < 3:
            errors["name"] = "اكتب اسمك"
        phone = util.normalize_phone(values["phone"])
        if not phone:
            errors["phone"] = "اكتب رقم جوال سعودي صحيح، مثل 0551234567"
        problem = security.password_problem(r.field("password"))
        if problem:
            errors["password"] = problem
        if phone and db.one("SELECT 1 FROM users WHERE login = ?", (phone,)):
            errors["phone"] = "هذا الرقم مسجل من قبل، سجّل دخولك"
        if errors:
            return await register_page(ctx, errors, values)
        hashed = await asyncio.to_thread(security.hash_password, r.field("password"))
        uid = db.run("INSERT INTO users(role, login, name, pass_hash, created_at) VALUES ('owner', ?, ?, ?, ?)", (phone, values["name"], hashed, app.clock()))
        return redirect("/owner/new", ctx.start_session(uid, "owner"))

    @app.route("POST", "/owner/logout", "open")
    async def logout(ctx: Ctx):
        return redirect("/", ctx.end_session("owner"))

    @app.route("GET", "/owner/password", "owner")
    async def password_page(ctx: Ctx, error: str = ""):
        body = f"""<section class="auth"><h1>تغيير كلمة المرور</h1>{ui.notice("bad", error)}
<form method="post" action="/owner/password">{ui.csrf_input(ctx.csrf)}
{ui.field("كلمة المرور الحالية", "current", type="password", required=True, autocomplete="current-password")}
{ui.field("كلمة المرور الجديدة", "new", type="password", required=True, autocomplete="new-password", hint="8 خانات على الأقل")}
{ui.field("أعد كتابتها", "again", type="password", required=True, autocomplete="new-password")}
<button class="btn big" type="submit">حفظ كلمة المرور</button></form>
<p class="alt"><a href="/owner">رجوع</a></p></section>"""
        return html_page(ctx, "تغيير كلمة المرور", body, noindex=True)

    @app.route("POST", "/owner/password", "owner")
    async def password_post(ctx: Ctx):
        f = ctx.request
        new = f.field("new")
        if new != f.field("again"):
            return await password_page(ctx, "الكلمتان غير متطابقتين")
        problem = security.password_problem(new)
        if problem:
            return await password_page(ctx, problem)
        # the same slow, rate-limited, lock-after-five-failures check as the login page
        user, problem = await verify_login(ctx, "owner", ctx.owner["login"], f.field("current"))
        if not user:
            return await password_page(ctx, "كلمة المرور الحالية غير صحيحة" if problem == "بيانات الدخول غير صحيحة" else problem)
        hashed = await asyncio.to_thread(security.hash_password, new)
        db.run("UPDATE users SET pass_hash = ? WHERE id = ?", (hashed, user["id"]))
        db.run("DELETE FROM sessions WHERE user_id = ? AND token_hash != ?", (user["id"], security.token_hash(f.cookies.get(OWNER_COOKIE, ""))))
        db.audit(user["id"], "owner_password")
        return redirect("/owner?msg=تم تغيير كلمة المرور، وأُنهيت جلساتك على الأجهزة الأخرى")

    # ---- dashboard ----------------------------------------------------------------------------
    @app.route("GET", "/owner", "owner")
    async def dashboard(ctx: Ctx):
        uid = ctx.owner["id"]
        rows = db.all("""SELECT l.*, c.name AS city_name,
          (SELECT filename FROM photos p WHERE p.listing_id = l.id ORDER BY p.position, p.id LIMIT 1) AS cover
          FROM listings l JOIN cities c ON c.id = l.city_id WHERE l.owner_id = ? ORDER BY l.id DESC""", (uid,))
        items = ""
        for r in rows:
            state = repo.REVIEW_LABELS[r["review"]] if r["review"] != "approved" else ("منشور" if r["owner_active"] else "موقوف من طرفك")
            kind = {"approved": "ok", "pending": "warn", "rejected": "bad", "stopped": "bad"}[r["review"]] if r["owner_active"] or r["review"] != "approved" else "muted"
            thumb = f'<img src="/media/{e(r["cover"])}" alt="" width="96" height="72">' if r["cover"] else '<span class="noimg small" aria-hidden="true"></span>'
            items += (f'<a class="row-item" href="/owner/listing/{r["id"]}">{thumb}<span class="grow"><b>{e(r["title"])}</b>'
                      f'<small>{e(r["city_name"])} · {num(r["price"])} ر.س / {e(repo.UNIT_SHORT[r["unit"]])} · {num(r["views"])} مشاهدة · {num(r["clicks"])} ضغطة واتساب</small></span>'
                      f'<span class="tag {kind}">{e(state)}</span></a>')
        body = f"""<div class="head"><h1>إعلاناتي</h1><a class="btn sun" href="/owner/new">أضف استراحة</a></div>
{ui.notice("ok", ctx.flash())}
{('<div class="list">' + items + "</div>") if items else '<section class="empty"><h2>ما أضفت أي استراحة بعد</h2><p>ابدأ بإضافة أول استراحة، وتظهر بعد مراجعة الإدارة.</p><a class="btn sun" href="/owner/new">أضف استراحتك</a></section>'}
<p class="alt"><a href="/owner/password">تغيير كلمة المرور</a></p>"""
        return html_page(ctx, "إعلاناتي", body, noindex=True)

    # ---- the pledge, then the form ---------------------------------------------------------------
    @app.route("GET", "/owner/new", "owner")
    async def pledge_page(ctx: Ctx):
        bp = db.commission_bp()
        pledge = db.pledge()
        return html_page(ctx, "التعهد بالعمولة", _pledge_html(ctx, bp, pledge, "/owner/new", "أتعهد وأوافق وأضيف استراحتي"), noindex=True)

    def _pledge_html(ctx: Ctx, bp: int, pledge, action: str, button: str, note: str = "") -> str:
        pct = util.percent_text(bp)
        example_rent = 500
        example = util.money(util.to_halalas(util.commission(example_rent, bp)))
        return f"""<section class="pledge"><h1>التعهد بالعمولة</h1>{ui.notice("note", note)}
<p class="lead">قبل نشر استراحتك، اقرأ شروط العمولة ووافق عليها. لا ننتقل إلى نموذج الإضافة إلا بعد موافقتك.</p>
<div class="rate"><span>نسبة العمولة الحالية</span><b>{pct}%</b></div>
<p>تُحسب العمولة من قيمة الإيجار الفعلية عن كل عملية تأجير تتم عبر المنصة. مثال: إذا كانت العمولة {pct}% وقيمة الإيجار {example_rent} ريال، فالعمولة المستحقة {example} ريال.</p>
<p>تُحفظ موافقتك إلكترونيًا مع تاريخها ونص التعهد ورقم نسخته ونسبة العمولة. إذا غيّرت الإدارة النسبة مستقبلًا فلا تتغير النسبة المتفق عليها لإعلانك بدون موافقتك الجديدة.</p>
<h2>نص التعهد (النسخة {pledge["version"]})</h2><blockquote>{e(pledge["body"])}</blockquote>
<form method="post" action="{e(action)}">{ui.csrf_input(ctx.csrf)}<input type="hidden" name="version" value="{pledge["version"]}"><input type="hidden" name="bp" value="{bp}">
<label class="chk big"><input type="checkbox" name="agree" value="1" required><span>قرأت التعهد ونسبة العمولة {pct}% وأوافق عليهما</span></label>
<button class="btn sun big" type="submit">{e(button)}</button></form></section>"""

    def _record_consent(ctx: Ctx):
        """Saves the owner's agreement exactly as shown on the page. Refuses when the page is out of date."""
        r = ctx.request
        pledge, bp = db.pledge(), db.commission_bp()
        if r.field("agree") != "1":
            return None, "لازم تحدد الموافقة على التعهد"
        if r.field("version") != str(pledge["version"]) or r.field("bp") != str(bp):
            return None, "تغيّرت نسبة العمولة أو نص التعهد أثناء وجودك في الصفحة، راجعها ووافق من جديد"
        cid = db.run(
            "INSERT INTO consents(owner_id, pledge_version, pledge_text, basis_points, accepted_at, ip_fingerprint, user_agent) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (ctx.owner["id"], pledge["version"], pledge["body"], bp, app.clock(), security.ip_hash(r.ip), r.headers.get("user-agent", "")[:200]))
        return cid, ""

    @app.route("POST", "/owner/new", "owner")
    async def pledge_accept(ctx: Ctx):
        cid, problem = _record_consent(ctx)
        if cid is None:
            bp, pledge = db.commission_bp(), db.pledge()
            return html_page(ctx, "التعهد بالعمولة", _pledge_html(ctx, bp, pledge, "/owner/new", "أتعهد وأوافق وأضيف استراحتي", problem), 400, noindex=True)
        return redirect(f"/owner/consent/{cid}")

    def _own_consent(ctx: Ctx, cid: int):
        row = db.one("SELECT * FROM consents WHERE id = ? AND owner_id = ?", (cid, ctx.owner["id"]))
        return row if row and row["listing_id"] is None else None

    def _form_values(ctx: Ctx) -> dict:
        form = {k: v[0] for k, v in ctx.request.form()[0].items() if k != "amenities"}
        form["amenities"] = ctx.request.form()[0].get("amenities", [])
        return form

    def _listing_form(ctx: Ctx, action: str, v: dict, errors: dict, button: str, *, new: bool) -> str:
        cities = [(c["id"], c["name"]) for c in db.all("SELECT * FROM cities WHERE active = 1 ORDER BY sort, id")]
        cats = [(c["id"], c["name"]) for c in db.all("SELECT * FROM categories WHERE active = 1 ORDER BY sort, id")]
        amen = [(a["id"], a["name"]) for a in db.all("SELECT * FROM amenities WHERE active = 1 ORDER BY sort, id")]
        chosen = {int(x) for x in v.get("amenities", []) if str(x).isdigit()}
        wa_raw = str(v.get("whatsapp", ""))
        wa_value = util.show_phone(wa_raw) if re.fullmatch(r"966[0-9]{9}", wa_raw) else wa_raw
        return f"""<form class="stack" method="post" action="{e(action)}">{ui.csrf_input(ctx.csrf)}
{ui.notice("bad", "راجع الحقول المظللة" if errors else "")}
{ui.field("اسم الاستراحة", "title", v.get("title", ""), required=True, error=errors.get("title", ""), attrs='maxlength="80"')}
<div class="row2">{ui.select("المدينة", "city", cities, v.get("city_id") or v.get("city", ""), blank="اختر", error=errors.get("city", ""))}
{ui.select("نوع الاستراحة", "category", cats, v.get("category_id") or v.get("category", ""), blank="اختر", error=errors.get("category", ""))}</div>
{ui.field("الحي", "district", v.get("district", ""), error=errors.get("district", ""), attrs='maxlength="60"')}
{ui.field("رابط الموقع على خرائط قوقل", "map_url", v.get("map_url", ""), type="url", error=errors.get("map_url", ""), hint="افتح الموقع في خرائط قوقل > مشاركة > انسخ الرابط (اختياري)", attrs='inputmode="url"')}
<div class="row2">{ui.field("سعر الإيجار (ر.س)", "price", v.get("price", ""), required=True, error=errors.get("price", ""), attrs='inputmode="numeric"')}
{ui.select("مدة الإيجار", "unit", list(repo.UNITS.items()), v.get("unit", "night"), error=errors.get("unit", ""))}</div>
{ui.field("السعة (عدد الأشخاص)", "capacity", v.get("capacity") or "", error=errors.get("capacity", ""), attrs='inputmode="numeric"')}
{ui.field("رقم واتساب للتواصل", "whatsapp", wa_value, type="tel", required=True, error=errors.get("whatsapp", ""), hint="يصل إليه العملاء مباشرة", attrs='inputmode="tel" placeholder="05XXXXXXXX"')}
<p class="lbl">المرافق والخدمات</p>{ui.checks("amenities", amen, chosen)}
{ui.textarea("وصف الاستراحة", "description", v.get("description", ""), error=errors.get("description", ""), rows=6)}
{ui.textarea("الأيام والأوقات المتاحة", "availability_note", v.get("availability_note", ""), error=errors.get("availability_note", ""), rows=3, hint="مثال: متاحة طوال الأسبوع، الدخول 4 العصر والخروج 11 صباحًا")}
<button class="btn sun big" type="submit">{e(button)}</button></form>"""

    @app.route("GET", r"/owner/consent/(\d{1,9})", "owner")
    async def new_form(ctx: Ctx, raw: str):
        consent = _own_consent(ctx, int(raw))
        if not consent:
            return redirect("/owner/new")
        action = f"/owner/consent/{consent['id']}"
        body = (f'<h1>بيانات الاستراحة</h1>{ui.notice("ok", "تم حفظ موافقتك على التعهد.")}'
                f'{_listing_form(ctx, action, {}, {}, "نشر الإعلان للمراجعة", new=True)}')
        return html_page(ctx, "إضافة استراحة", body, noindex=True)

    @app.route("POST", r"/owner/consent/(\d{1,9})", "owner")
    async def new_save(ctx: Ctx, raw: str):
        consent = _own_consent(ctx, int(raw))
        if not consent:
            return redirect("/owner/new")
        values, errors = repo.validate_listing(db, _form_values(ctx))
        if errors:
            action = f"/owner/consent/{consent['id']}"
            body = f'<h1>بيانات الاستراحة</h1>{_listing_form(ctx, action, {**_form_values(ctx), **values}, errors, "نشر الإعلان للمراجعة", new=True)}'
            return html_page(ctx, "إضافة استراحة", body, 400, noindex=True)
        now = app.clock()
        with db.transaction():
            lid = db.run(
                """INSERT INTO listings(owner_id, consent_id, title, city_id, district, map_url, category_id, description, price, unit, capacity,
                   whatsapp, availability_note, review, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?, 'pending', ?, ?)""",
                (ctx.owner["id"], consent["id"], values["title"], values["city_id"], values["district"], values["map_url"], values["category_id"],
                 values["description"], values["price"], values["unit"], values["capacity"], values["whatsapp"], values["availability_note"], now, now))
            db.run("UPDATE consents SET listing_id = ? WHERE id = ?", (lid, consent["id"]))
            for a in values["amenities"]:
                db.run("INSERT INTO listing_amenities(listing_id, amenity_id) VALUES (?, ?)", (lid, a))
        return redirect(f"/owner/listing/{lid}?msg=" + "أضفنا إعلانك، أضف الصور ثم ننتظر مراجعة الإدارة")

    # ---- one advert -----------------------------------------------------------------------------
    def _mine(ctx: Ctx, raw: str):
        row = repo.any_listing(db, int(raw))
        return row if row and row["owner_id"] == ctx.owner["id"] else None

    @app.route("GET", r"/owner/listing/(\d{1,9})", "owner")
    async def manage(ctx: Ctx, raw: str):
        row = _mine(ctx, raw)
        if not row:
            return not_found(ctx)
        lid = row["id"]
        photos, blocks = repo.photos_of(db, lid), repo.blocks_of(db, lid)
        consent = db.one("SELECT * FROM consents WHERE id = ?", (row["consent_id"],))
        state = repo.REVIEW_LABELS[row["review"]]
        extra = f'<p class="note bad">سبب القرار: {e(row["review_note"])}</p>' if row["review_note"] and row["review"] in ("rejected", "stopped") else ""
        pic = "".join(
            f'<li><img src="/media/{e(p["filename"])}" alt="" width="160" height="120" loading="lazy">'
            f'<form method="post" action="/owner/listing/{lid}/photo/{p["id"]}/cover">{ui.csrf_input(ctx.csrf)}<button class="link" type="submit">{"الغلاف" if i == 0 else "اجعلها الغلاف"}</button></form>'
            f'<form method="post" action="/owner/listing/{lid}/photo/{p["id"]}/delete">{ui.csrf_input(ctx.csrf)}<button class="link bad" type="submit">حذف</button></form></li>'
            for i, p in enumerate(photos))
        blocked = "".join(
            f'<li>{e(ui.day_text(b["start_date"]))}' + (f' — {e(ui.day_text(b["end_date"]))}' if b["end_date"] != b["start_date"] else "") +
            f'<form method="post" action="/owner/listing/{lid}/block/{b["id"]}/delete">{ui.csrf_input(ctx.csrf)}<button class="link bad" type="submit">حذف</button></form></li>' for b in blocks)
        newer = db.pledge()["version"] != consent["pledge_version"] or db.commission_bp() != consent["basis_points"]
        reconsent = (f'<div class="note warn">توجد شروط عمولة جديدة ({util.percent_text(db.commission_bp())}%). إعلانك يبقى على اتفاقك الحالي ({util.percent_text(consent["basis_points"])}%) '
                     f'حتى توافق على الجديدة. <a href="/owner/listing/{lid}/reconsent">راجع الشروط الجديدة</a></div>') if newer else ""
        toggle = ""
        if row["review"] == "approved":
            if row["owner_active"]:
                toggle = f'<form method="post" action="/owner/listing/{lid}/pause">{ui.csrf_input(ctx.csrf)}<button class="btn ghost" type="submit">إيقاف الإعلان مؤقتًا</button></form>'
            else:
                toggle = f'<form method="post" action="/owner/listing/{lid}/resume">{ui.csrf_input(ctx.csrf)}<button class="btn" type="submit">إعادة تفعيل الإعلان</button></form>'
        limit = app.settings.max_photos
        body = f"""<div class="head"><h1>{e(row["title"])}</h1><span class="tag {"ok" if row["review"] == "approved" else "warn" if row["review"] == "pending" else "bad"}">{e(state)}</span></div>
{ui.notice("ok", ctx.flash() or _upload_note(ctx))}{extra}{reconsent}
<div class="actions"><a class="btn ghost" href="/r/{lid}">معاينة الإعلان</a><a class="btn ghost" href="/owner/listing/{lid}/edit">تعديل البيانات</a>{toggle}</div>
<section class="panel"><h2>الصور <small>({len(photos)} من {limit})</small></h2>
<ul class="pics">{pic}</ul>
<form method="post" action="/owner/listing/{lid}/photo" enctype="multipart/form-data" class="upload" data-max="{app.settings.max_upload_mb}">{ui.csrf_input(ctx.csrf)}
<label class="btn ghost" for="photos">اختر صورًا</label><input id="photos" type="file" name="photo" accept="image/jpeg,image/png,image/webp" multiple>
<button class="btn" type="submit">رفع الصور</button><p class="hint">JPG أو PNG أو WebP. الصورة الأولى تكون غلاف الإعلان. نحذف من الصور بيانات الموقع المخزنة داخلها.</p><p class="hint" id="upload-status" role="status"></p></form></section>
<section class="panel"><h2>التواريخ غير المتاحة</h2>
<ul class="blocks">{blocked or '<li class="muted">كل التواريخ متاحة</li>'}</ul>
<form method="post" action="/owner/listing/{lid}/block" class="row2 inline-form">{ui.csrf_input(ctx.csrf)}
{ui.field("من", "start", type="date", required=True)}{ui.field("إلى", "end", type="date", required=True)}<button class="btn" type="submit">أضف فترة محجوزة</button></form></section>
<section class="panel"><h2>اتفاق العمولة</h2><ul class="facts one"><li><b>النسبة المتفق عليها</b>{util.percent_text(consent["basis_points"])}%</li><li><b>تاريخ موافقتك</b>{e(ui.stamp(consent["accepted_at"]))}</li><li><b>نسخة التعهد</b>{consent["pledge_version"]}</li></ul></section>"""
        return html_page(ctx, row["title"], body, noindex=True)

    @app.route("GET", r"/owner/listing/(\d{1,9})/edit", "owner")
    async def edit_page(ctx: Ctx, raw: str):
        row = _mine(ctx, raw)
        if not row:
            return not_found(ctx)
        v = dict(row)
        v["amenities"] = [str(a) for a in repo.amenity_ids_of(db, row["id"])]
        note = ui.notice("note", "تعديل الاسم أو الوصف أو الموقع أو الواتساب يعيد الإعلان للمراجعة. تعديل السعر لا يحتاج مراجعة.") if row["review"] == "approved" else ""
        action = f"/owner/listing/{row['id']}/edit"
        body = f'<h1>تعديل الإعلان</h1>{note}{_listing_form(ctx, action, v, {}, "حفظ التعديلات", new=False)}'
        return html_page(ctx, "تعديل الإعلان", body, noindex=True)

    @app.route("POST", r"/owner/listing/(\d{1,9})/edit", "owner")
    async def edit_save(ctx: Ctx, raw: str):
        row = _mine(ctx, raw)
        if not row:
            return not_found(ctx)
        values, errors = repo.validate_listing(db, _form_values(ctx))
        if errors:
            action = f"/owner/listing/{row['id']}/edit"
            body = f'<h1>تعديل الإعلان</h1>{_listing_form(ctx, action, {**_form_values(ctx), **values}, errors, "حفظ التعديلات", new=False)}'
            return html_page(ctx, "تعديل الإعلان", body, 400, noindex=True)
        changed = any(row[f] != values[f] for f in repo.REVIEWED_FIELDS)
        review = "pending" if changed and row["review"] in ("approved", "rejected") else row["review"]
        if row["review"] == "stopped":
            review = "stopped"                                  # a stopped advert stays stopped until the admin restores it
        with db.transaction():
            db.run("""UPDATE listings SET title=?, city_id=?, district=?, map_url=?, category_id=?, description=?, price=?, unit=?, capacity=?,
                      whatsapp=?, availability_note=?, review=?, updated_at=? WHERE id=?""",
                   (values["title"], values["city_id"], values["district"], values["map_url"], values["category_id"], values["description"], values["price"],
                    values["unit"], values["capacity"], values["whatsapp"], values["availability_note"], review, app.clock(), row["id"]))
            db.run("DELETE FROM listing_amenities WHERE listing_id = ?", (row["id"],))
            for a in values["amenities"]:
                db.run("INSERT INTO listing_amenities(listing_id, amenity_id) VALUES (?, ?)", (row["id"], a))
        msg = "حفظنا التعديلات" + (" وأُعيد الإعلان للمراجعة" if review == "pending" and row["review"] != "pending" else "")
        return redirect(f"/owner/listing/{row['id']}?msg={msg}")

    @app.route("POST", r"/owner/listing/(\d{1,9})/(pause|resume)", "owner")
    async def toggle(ctx: Ctx, raw: str, action: str):
        row = _mine(ctx, raw)
        if not row:
            return not_found(ctx)
        db.run("UPDATE listings SET owner_active = ?, updated_at = ? WHERE id = ?", (0 if action == "pause" else 1, app.clock(), row["id"]))
        return redirect(f"/owner/listing/{row['id']}?msg=" + ("أوقفنا الإعلان، لا يظهر للزوار" if action == "pause" else "أعدنا تفعيل الإعلان"))

    # ---- agreeing again to new terms for an existing advert --------------------------------------------
    @app.route("GET", r"/owner/listing/(\d{1,9})/reconsent", "owner")
    async def reconsent_page(ctx: Ctx, raw: str):
        row = _mine(ctx, raw)
        if not row:
            return not_found(ctx)
        note = "هذه الموافقة تسري على عمليات التأجير المسجلة بعد تاريخها لهذا الإعلان فقط."
        return html_page(ctx, "شروط العمولة الجديدة", _pledge_html(ctx, db.commission_bp(), db.pledge(), f"/owner/listing/{row['id']}/reconsent", "أوافق على الشروط الجديدة", note), noindex=True)

    @app.route("POST", r"/owner/listing/(\d{1,9})/reconsent", "owner")
    async def reconsent_save(ctx: Ctx, raw: str):
        row = _mine(ctx, raw)
        if not row:
            return not_found(ctx)
        cid, problem = _record_consent(ctx)
        if cid is None:
            return html_page(ctx, "شروط العمولة الجديدة", _pledge_html(ctx, db.commission_bp(), db.pledge(), f"/owner/listing/{row['id']}/reconsent", "أوافق على الشروط الجديدة", problem), 400, noindex=True)
        db.run("UPDATE consents SET listing_id = ? WHERE id = ?", (row["id"], cid))
        db.run("UPDATE listings SET consent_id = ?, updated_at = ? WHERE id = ?", (cid, app.clock(), row["id"]))
        return redirect(f"/owner/listing/{row['id']}?msg=سجلنا موافقتك على الشروط الجديدة")

    # ---- photos ---------------------------------------------------------------------------------
    @app.route("POST", r"/owner/listing/(\d{1,9})/photo", "owner")
    async def photo_upload(ctx: Ctx, raw: str):
        row = _mine(ctx, raw)
        if not row:
            return not_found(ctx)
        fetch = ctx.request.headers.get("x-requested-with") == "fetch"
        try:
            files = [f for f in ctx.request.form()[1] if f[0] == "photo"]
        except ValueError:
            files = []

        def done(message: str, ok: bool) -> Response:
            if fetch:
                return text_response(200 if ok else 400, message)
            return redirect(f"/owner/listing/{row['id']}?msg={message}")

        if not files:
            return done("اختر صورة أولًا", False)
        saved, problem = 0, ""
        for _, _, data in files:
            count = db.one("SELECT COUNT(*) AS n FROM photos WHERE listing_id = ?", (row["id"],))["n"]
            if count >= app.settings.max_photos:
                problem = f"الحد الأعلى {app.settings.max_photos} صورة"
                break
            try:
                ext, cleaned, _, _ = images.clean(data, app.settings.max_upload_mb * 1024 * 1024)
            except images.ImageError as exc:
                problem = str(exc)
                continue
            name = secrets.token_hex(16) + "." + ext
            app.settings.uploads_dir.mkdir(parents=True, exist_ok=True)
            (app.settings.uploads_dir / name).write_bytes(cleaned)
            db.run("INSERT INTO photos(listing_id, filename, position, created_at) VALUES (?, ?, ?, ?)", (row["id"], name, count, app.clock()))
            saved += 1
        if saved and row["review"] == "approved":
            db.run("UPDATE listings SET review = 'pending', updated_at = ? WHERE id = ?", (app.clock(), row["id"]))
        if saved:
            return done(f"تم رفع {saved} صورة" + (f" ({problem})" if problem else ""), True)
        return done(problem or "تعذر رفع الصورة", False)

    @app.route("POST", r"/owner/listing/(\d{1,9})/photo/(\d{1,9})/(delete|cover)", "owner")
    async def photo_edit(ctx: Ctx, raw: str, pid: str, action: str):
        row = _mine(ctx, raw)
        photo = db.one("SELECT * FROM photos WHERE id = ? AND listing_id = ?", (int(pid), int(raw))) if row else None
        if not row or not photo:
            return not_found(ctx)
        if action == "delete":
            db.run("DELETE FROM photos WHERE id = ?", (photo["id"],))
            try:
                (app.settings.uploads_dir / photo["filename"]).unlink()
            except OSError:
                pass
        else:
            db.run("UPDATE photos SET position = position + 1 WHERE listing_id = ?", (row["id"],))
            db.run("UPDATE photos SET position = 0 WHERE id = ?", (photo["id"],))
        return redirect(f"/owner/listing/{row['id']}")

    # ---- dates the advert is taken ------------------------------------------------------------------
    @app.route("POST", r"/owner/listing/(\d{1,9})/block", "owner")
    async def block_add(ctx: Ctx, raw: str):
        row = _mine(ctx, raw)
        if not row:
            return not_found(ctx)
        start, end = util.parse_date(ctx.request.field("start")), util.parse_date(ctx.request.field("end")) or util.parse_date(ctx.request.field("start"))
        if not start or not end or end < start or (end - ctx.today()).days > 800:
            return redirect(f"/owner/listing/{row['id']}?msg=تاريخ غير صحيح، تأكد أن النهاية بعد البداية")
        if db.one("SELECT COUNT(*) AS n FROM blocked_dates WHERE listing_id = ?", (row["id"],))["n"] >= repo.MAX_BLOCKS:
            return redirect(f"/owner/listing/{row['id']}?msg=وصلت الحد الأعلى للفترات")
        db.run("INSERT INTO blocked_dates(listing_id, start_date, end_date) VALUES (?, ?, ?)", (row["id"], start.isoformat(), end.isoformat()))
        return redirect(f"/owner/listing/{row['id']}?msg=أضفنا الفترة")

    @app.route("POST", r"/owner/listing/(\d{1,9})/block/(\d{1,9})/delete", "owner")
    async def block_delete(ctx: Ctx, raw: str, bid: str):
        row = _mine(ctx, raw)
        if not row:
            return not_found(ctx)
        db.run("DELETE FROM blocked_dates WHERE id = ? AND listing_id = ?", (int(bid), row["id"]))
        return redirect(f"/owner/listing/{row['id']}")
