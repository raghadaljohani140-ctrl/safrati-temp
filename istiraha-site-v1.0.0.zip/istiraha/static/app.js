(function () {
  'use strict';
  function $(sel, root) { return (root || document).querySelector(sel); }

  // the photos of an advert: a thumbnail shows in the big frame
  var main = $('#main-photo');
  document.querySelectorAll('.th').forEach(function (a) {
    a.addEventListener('click', function (ev) {
      if (!main) return;
      ev.preventDefault();
      main.src = a.getAttribute('data-full');
      document.querySelectorAll('.th.on').forEach(function (x) { x.classList.remove('on'); });
      a.classList.add('on');
    });
  });

  // counting the WhatsApp button (the chat opens anyway)
  var wa = $('#wa');
  if (wa) {
    wa.addEventListener('click', function () {
      try { if (navigator.sendBeacon) navigator.sendBeacon('/api/click/' + wa.getAttribute('data-id')); } catch (e) { /* the count is not important */ }
    });
  }

  document.querySelectorAll('[data-copy]').forEach(function (b) {
    var link = b.getAttribute('data-copy') || window.location.href;
    b.addEventListener('click', function () {
      var done = function () { var old = b.textContent; b.textContent = 'تم النسخ'; setTimeout(function () { b.textContent = old; }, 1800); };
      if (navigator.clipboard) navigator.clipboard.writeText(link).then(done, function () { window.prompt('انسخ الرابط', link); });
      else window.prompt('انسخ الرابط', link);
    });
  });

  // photo upload: each picture is made smaller on the phone first (this also removes its hidden location data), then sent one by one
  var form = $('form.upload');
  if (form && window.fetch && window.FormData && document.createElement('canvas').toBlob) {
    var input = $('#photos', form), status = $('#upload-status', form);
    var maxMb = parseInt(form.getAttribute('data-max') || '8', 10);
    var csrf = $('input[name=_csrf]', form).value;
    var shrink = function (file) {
      return new Promise(function (resolve) {
        if (!/^image\/(jpeg|png|webp)$/.test(file.type)) { resolve(file); return; }
        var img = new Image(), url = URL.createObjectURL(file);
        img.onload = function () {
          var side = 1800, scale = Math.min(1, side / Math.max(img.naturalWidth, img.naturalHeight));
          var c = document.createElement('canvas');
          c.width = Math.round(img.naturalWidth * scale); c.height = Math.round(img.naturalHeight * scale);
          c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
          URL.revokeObjectURL(url);
          c.toBlob(function (blob) { resolve(blob || file); }, 'image/jpeg', 0.84);
        };
        img.onerror = function () { URL.revokeObjectURL(url); resolve(file); };   // the server decides what to do with it
        img.src = url;
      });
    };
    form.addEventListener('submit', function (ev) {
      var files = Array.prototype.slice.call(input.files || []);
      if (!files.length) return;
      ev.preventDefault();
      var ok = 0, bad = '', i = 0;
      var next = function () {
        if (i >= files.length) {
          window.location.href = window.location.pathname + '?up=' + ok + (bad ? '&bad=1' : '');
          return;
        }
        status.textContent = 'جاري رفع الصورة ' + (i + 1) + ' من ' + files.length + '…';
        shrink(files[i]).then(function (blob) {
          if (blob.size > maxMb * 1024 * 1024) { bad = 'صورة أكبر من ' + maxMb + ' ميغابايت'; i++; return next(); }
          var data = new FormData();
          data.append('_csrf', csrf);
          data.append('photo', blob, 'photo.jpg');
          return fetch(form.action, { method: 'POST', body: data, headers: { 'X-Requested-With': 'fetch' }, credentials: 'same-origin' })
            .then(function (r) { return r.text().then(function (t) { if (r.ok) ok++; else bad = t; }); })
            .catch(function () { bad = 'انقطع الاتصال'; })
            .then(function () { i++; next(); });
        });
      };
      next();
    });
  }
})();
