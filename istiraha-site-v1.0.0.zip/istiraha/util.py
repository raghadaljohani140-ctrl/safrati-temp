"""Small, pure helpers: money, phone numbers, WhatsApp links, dates."""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta, timezone
from decimal import ROUND_HALF_UP, Decimal
from urllib.parse import quote

SAUDI_TZ = timezone(timedelta(hours=3))

_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


def digits(text: str) -> str:
    """Western digits only; Arabic-Indic digits are converted first."""
    return re.sub(r"\D", "", (text or "").translate(_DIGITS))


def normalize_phone(text: str) -> str | None:
    """A Saudi mobile number as 9665XXXXXXXX, or None. Accepts 05…, 5…, 9665…, +9665…, 009665…"""
    d = digits(text)
    if d.startswith("00"):
        d = d[2:]
    if d.startswith("966"):
        d = d[3:]
    if d.startswith("0"):
        d = d[1:]
    if re.fullmatch(r"5\d{8}", d):
        return "966" + d
    return None


def show_phone(number: str) -> str:
    return "0" + number[3:] if number.startswith("966") else number


def whatsapp_link(number: str, title: str, url: str) -> str:
    """The chat link with the greeting already written. The title and the advert's address are inside the message."""
    text = "السلام عليكم، أرغب بالاستفسار عن استراحتكم المنشورة في المنصة"
    if title:
        text += f" («{title}»)"
    text += "، وهل هي متاحة في التاريخ المطلوب؟"
    if url:
        text += f"\n{url}"
    return f"https://wa.me/{number}?text={quote(text, safe='')}"


def commission(rent_sar: int, basis_points: int) -> Decimal:
    """Commission in riyals, rounded to the halala. 10.00% is 1000 basis points: 500 SAR gives 50.00."""
    return (Decimal(rent_sar) * Decimal(basis_points) / Decimal(10000)).quantize(Decimal("0.01"), ROUND_HALF_UP)


def to_halalas(value: Decimal) -> int:
    return int((value * 100).to_integral_value(ROUND_HALF_UP))


def money(halalas: int) -> str:
    whole, part = divmod(int(halalas), 100)
    return f"{whole:,}" + (f".{part:02d}" if part else "")


def parse_percent(text: str) -> int | None:
    """"10" or "7.5" or "٧٫٥" -> basis points (1000, 750); None when it is not a percentage between 0 and 100."""
    cleaned = (text or "").translate(_DIGITS).replace("٫", ".").replace(",", ".").replace("%", "").strip()
    if not re.fullmatch(r"\d{1,3}(\.\d{1,2})?", cleaned):
        return None
    bp = int((Decimal(cleaned) * 100).to_integral_value(ROUND_HALF_UP))
    return bp if 0 <= bp <= 10000 else None


def percent_text(bp: int) -> str:
    value = Decimal(bp) / Decimal(100)
    return f"{value.normalize():f}" if value == value.to_integral() else f"{value:.2f}".rstrip("0").rstrip(".")


def parse_int(text: str, low: int, high: int) -> int | None:
    """A whole number written with any digits, optionally with thousands separators ("1,500"). Anything else is refused."""
    cleaned = re.sub(r"[\s,٬،]", "", (text or "").translate(_DIGITS))
    if not re.fullmatch(r"\d{1,9}", cleaned):
        return None
    value = int(cleaned)
    return value if low <= value <= high else None


def parse_date(text: str) -> date | None:
    try:
        return date.fromisoformat((text or "").strip().translate(_DIGITS))
    except ValueError:
        return None


def today(clock=None) -> date:
    now = datetime.fromtimestamp(clock(), SAUDI_TZ) if clock else datetime.now(SAUDI_TZ)
    return now.date()
