"""Pages anyone can open without an account: home, search, one advert, offers, the files."""
from __future__ import annotations

from urllib.parse import urlencode

from . import images, repo, ui, util
from .app import STATIC_DIR, STATIC_TYPES, Ctx, html_page, not_found
from .server import Response, text_response
from .ui import e, num

TERMS = [
    ("ما هذه المنصة", "منصة للتعريف بالاستراحات المعروضة للإيجار داخل المملكة. تعرض الإعلانات كما يدخلها أصحابها، ولا تكون طرفًا في عقد الإيجار بين العميل وصاحب الاستراحة."),
    ("الحجز والدفع", "يتم التواصل والاتفاق على الحجز والسعر والدفع مباشرة بين العميل وصاحب الاستراحة عبر واتساب. تأكد من التفاصيل والتاريخ قبل أي دفع."),
    ("أصحاب الاستراحات", "يلتزم صاحب الاستراحة بصحة بياناته وصوره، وبسداد العمولة المستحقة للمنصة وفق التعهد الإلكتروني الذي يوافق عليه قبل نشر إعلانه."),
    ("حق المنصة", "للمنصة مراجعة الإعلانات وقبولها أو رفضها أو إيقافها عند مخالفتها للشروط أو عند ورود شكاوى موثوقة."),
    ("تنبيه", "هذه الصفحة نص مبدئي ويجب مراجعته قانونيًا قبل إطلاق المنصة رسميًا."),
]
PRIVACY = [
    ("ما نحفظه", "حساب صاحب الاستراحة (الاسم ورقم الجوال وكلمة المرور مشفّرة)، وبيانات إعلانه وصوره، وسجل موافقته على التعهد."),
    ("الزوار", "تصفح الاستراحات والبحث لا يحتاج حسابًا، ولا نحفظ بيانات شخصية للزائر. نحسب عدد المشاهدات والضغط على زر واتساب بدون ربطها بشخص."),
    ("الصور", "نحذف من الصور المرفوعة بيانات الكاميرا والموقع الجغرافي المخزنة داخلها."),
    ("رقم الواتساب", "رقم صاحب الاستراحة يظهر للزوار لأنه وسيلة التواصل الأساسية. لا تضع رقمًا لا تريد نشره."),
]


def register(app) -> None:
    db = app.db

    @app.route("GET", "/")
    async def home(ctx: Ctx):
        today = ctx.today()
        data = repo.homepage(db, today)
        cities = db.all("SELECT * FROM cities WHERE active = 1 ORDER BY sort, id")
        cats = db.all("SELECT * FROM categories WHERE active = 1 ORDER BY sort, id")
        amen = db.all("SELECT * FROM amenities WHERE active = 1 ORDER BY sort, id")
        hero = f"""
<section class="hero">
<div class="hero-copy"><h1>استراحتك المناسبة، من صاحبها مباشرة</h1>
<p>ابحث بالمدينة والسعر والتاريخ، وتواصل مع صاحب الاستراحة على واتساب بدون حساب.</p></div>
<form class="search" method="get" action="/search" role="search">
<div class="row2">{ui.select("المدينة", "city", [(c["id"], c["name"]) for c in cities], blank="كل المدن")}
{ui.select("نوع الاستراحة", "category", [(c["id"], c["name"]) for c in cats], blank="الكل")}</div>
<div class="row2">{ui.field("أعلى سعر (ر.س)", "price_max", type="number", attrs='inputmode="numeric" min="1" placeholder="مثال: 1500"')}
{ui.field("تاريخ الإيجار", "date", type="date", attrs=f'min="{today.isoformat()}"')}</div>
<details class="more"><summary>المزيد من الخيارات</summary>
{ui.field("الحي", "district", attrs='maxlength="60" placeholder="اسم الحي"')}
<p class="lbl">المرافق</p>{ui.checks("amenity", [(a["id"], a["name"]) for a in amen], set())}</details>
<button class="btn big" type="submit">ابحث عن استراحة</button></form></section>"""
        parts = [hero]

        def section(title: str, items: list[dict], more: str = "") -> str:
            if not items:
                return ""
            cards = "".join(ui.card(i, repo.amenities_of(db, i["id"])) for i in items)
            link = f'<a class="more-link" href="{more}">عرض الكل</a>' if more else ""
            return f'<section class="block"><div class="head"><h2>{e(title)}</h2>{link}</div><div class="grid">{cards}</div></section>'

        parts.append(section("الاستراحات المميزة", data["featured"], "/search?featured=1"))
        parts.append(section("العروض والخصومات", data["deals"], "/offers"))
        parts.append(section("أحدث الاستراحات", data["latest"], "/search"))
        if not any(data.values()):
            parts.append('<section class="empty"><h2>لا توجد استراحات منشورة بعد</h2><p>كن أول من يضيف استراحته في المنصة.</p>'
                         '<a class="btn sun" href="/owner/new">أضف استراحتك</a></section>')
        parts.append('<section class="owner-cta"><div><h2>عندك استراحة؟</h2><p>أضفها بنفسك خلال دقائق، ويتواصل معك العملاء مباشرة على واتساب.</p></div>'
                     '<a class="btn sun" href="/owner/new">أضف استراحتك</a></section>')
        return html_page(ctx, "", "".join(parts), canonical="/", extra_class="home")

    def _filters(request) -> dict:
        q = request.query
        return dict(
            city=util.parse_int(q.get("city", ""), 1, 10**6), category=util.parse_int(q.get("category", ""), 1, 10**6),
            district=q.get("district", "").strip()[:60], price_min=util.parse_int(q.get("price_min", ""), 1, 10**7),
            price_max=util.parse_int(q.get("price_max", ""), 1, 10**7), on=util.parse_date(q.get("date", "")),
            amenities=[n for n in (util.parse_int(x, 1, 10**6) for x in request.query_list("amenity")) if n],
            offers_only=q.get("offers") == "1", featured_only=q.get("featured") == "1",
            sort=q.get("sort") if q.get("sort") in repo.SORTS else "new", query=q.get("q", "").strip()[:60],
        )

    @app.route("GET", "/search")
    async def search(ctx: Ctx):
        request = ctx.request
        f = _filters(request)
        page = util.parse_int(request.query.get("page", "1"), 1, 500) or 1
        today = ctx.today()
        items, total = repo.search(db, today, page=page, **f)
        cities = db.all("SELECT * FROM cities WHERE active = 1 ORDER BY sort, id")
        cats = db.all("SELECT * FROM categories WHERE active = 1 ORDER BY sort, id")
        amen = db.all("SELECT * FROM amenities WHERE active = 1 ORDER BY sort, id")
        chosen = set(f["amenities"])
        form = f"""<form class="filters" method="get" action="/search">
<div class="row2 keep">{ui.select("المدينة", "city", [(c["id"], c["name"]) for c in cities], f["city"] or "", blank="كل المدن")}
{ui.select("النوع", "category", [(c["id"], c["name"]) for c in cats], f["category"] or "", blank="الكل")}</div>
<div class="row2 keep">{ui.field("من (ر.س)", "price_min", f["price_min"] or "", type="number", attrs='inputmode="numeric" min="1"')}
{ui.field("إلى (ر.س)", "price_max", f["price_max"] or "", type="number", attrs='inputmode="numeric" min="1"')}</div>
<div class="row2 keep">{ui.select("الترتيب", "sort", list(repo.SORTS.items()), f["sort"])}
{ui.field("التاريخ", "date", f["on"].isoformat() if f["on"] else "", type="date", attrs=f'min="{today.isoformat()}"')}</div>
<details class="more"{" open" if chosen or f["district"] or f["offers_only"] else ""}><summary>المزيد من الخيارات</summary>
{ui.field("الحي", "district", f["district"], attrs='maxlength="60"')}
{ui.checks("amenity", [(a["id"], a["name"]) for a in amen], chosen)}
<label class="chk"><input type="checkbox" name="offers" value="1"{" checked" if f["offers_only"] else ""}><span>العروض والخصومات فقط</span></label></details>
<button class="btn big" type="submit">تحديث النتائج</button></form>"""
        if items:
            cards = "".join(ui.card(i, repo.amenities_of(db, i["id"])) for i in items)
            results = f'<div class="grid">{cards}</div>'
        else:
            results = ('<section class="empty"><h2>ما لقينا استراحات بهذه الشروط</h2>'
                       '<p>جرّب مدينة أخرى، أو ارفع السعر، أو أزل بعض المرافق.</p><a class="btn ghost" href="/search">إزالة الفلاتر</a></section>')
        pairs = [("city", f["city"]), ("category", f["category"]), ("sort", f["sort"] if f["sort"] != "new" else ""),
                 ("price_min", f["price_min"]), ("price_max", f["price_max"]), ("date", f["on"].isoformat() if f["on"] else ""),
                 ("district", f["district"]), ("offers", "1" if f["offers_only"] else ""), ("featured", "1" if f["featured_only"] else ""),
                 *[("amenity", a) for a in f["amenities"]]]
        base = "/search?" + urlencode([(k, v) for k, v in pairs if v])
        body = (f'<h1 class="title">الاستراحات <small>{num(total)} نتيجة</small></h1>{form}{results}'
                f'{ui.pager(page, total, base)}')
        return html_page(ctx, "ابحث عن استراحة", body, noindex=bool(request.query), canonical="/search")

    @app.route("GET", "/offers")
    async def offers(ctx: Ctx):
        items, total = repo.search(db, ctx.today(), offers_only=True, sort="deal", page=util.parse_int(ctx.request.query.get("page", "1"), 1, 500) or 1)
        cards = "".join(ui.card(i, repo.amenities_of(db, i["id"])) for i in items)
        content = f'<div class="grid">{cards}</div>' if items else '<section class="empty"><h2>لا توجد عروض الآن</h2><p>تابعنا قريبًا.</p><a class="btn ghost" href="/search">تصفح كل الاستراحات</a></section>'
        return html_page(ctx, "العروض والخصومات", f'<h1 class="title">العروض والخصومات</h1>{content}{ui.pager(1, total, "/offers")}', canonical="/offers")

    @app.route("GET", r"/r/(\d{1,9})")
    async def listing(ctx: Ctx, raw_id: str):
        lid = int(raw_id)
        item = repo.public_listing(db, lid, ctx.today())
        owner_view = False
        if item is None:
            # the owner and the admin may open an advert that is not public yet
            row = repo.any_listing(db, lid)
            if row and ((ctx.owner and ctx.owner["id"] == row["owner_id"]) or ctx.admin):
                owner_view = True
                item = {**row, **{"discount": 0, "final_price": row["price"], "offer_title": ""}}
            else:
                return not_found(ctx)
        else:
            db.run("UPDATE listings SET views = views + 1 WHERE id = ?", (lid,))
        photos = repo.photos_of(db, lid)
        names = repo.amenities_of(db, lid)
        blocks = [b for b in repo.blocks_of(db, lid) if b["end_date"] >= ctx.today().isoformat()]
        site = ctx.base_url
        link = util.whatsapp_link(item["whatsapp"], item["title"], f"{site}/r/{lid}" if site else "")
        if photos:
            main = f'<img id="main-photo" src="/media/{e(photos[0]["filename"])}" alt="{e(item["title"])}" width="1200" height="900">'
            thumbs = "".join(
                f'<a href="/media/{e(p["filename"])}" class="th" data-full="/media/{e(p["filename"])}"><img src="/media/{e(p["filename"])}" alt="" loading="lazy" width="160" height="120"></a>'
                for p in photos) if len(photos) > 1 else ""
            gallery = f'<div class="gallery"><div class="main-shot">{main}</div>{"<div class=thumbs>" + thumbs + "</div>" if thumbs else ""}</div>'
        else:
            gallery = '<div class="gallery"><div class="main-shot noimg" aria-hidden="true"></div></div>'
        unit = repo.UNITS.get(item["unit"], "")
        deal = (f'<p class="deal">عرض: {e(item["offer_title"])} — خصم {item["discount"]}%</p>' if item["discount"] else "")
        facts = [f'<li><b>المدينة</b>{e(item["city_name"])}</li>']
        if item["district"]:
            facts.append(f'<li><b>الحي</b>{e(item["district"])}</li>')
        facts.append(f'<li><b>النوع</b>{e(item["category_name"])}</li>')
        if item["capacity"]:
            facts.append(f'<li><b>السعة</b>حتى {num(item["capacity"])} شخص</li>')
        facts.append(f'<li><b>السعر</b>{ui.price_html(item)}</li>')
        facts.append(f'<li><b>مدة الإيجار</b>{e(unit)}</li>')
        chips = "".join(f"<li>{e(a)}</li>" for a in names)
        blocked = ""
        if blocks:
            blocked = ('<h2>تواريخ غير متاحة</h2><ul class="blocked">' + "".join(
                f'<li>{e(ui.day_text(b["start_date"]))}' + (f' — {e(ui.day_text(b["end_date"]))}' if b["end_date"] != b["start_date"] else "") + "</li>"
                for b in blocks[:12]) + "</ul>")
        note = f'<h2>الأوقات المتاحة</h2><p>{e(item["availability_note"])}</p>' if item["availability_note"] else ""
        mapbtn = (f'<a class="btn ghost" href="{e(item["map_url"])}" target="_blank" rel="noopener noreferrer">الموقع على الخريطة</a>' if item["map_url"] else "")
        status = ""
        if owner_view:
            status = ui.notice("warn", f"هذه معاينة: حالة الإعلان «{repo.REVIEW_LABELS[item['review']]}»" + ("، وهو موقوف من صاحبه" if not item["owner_active"] else ""))
        body = f"""{status}<article class="detail">
{gallery}
<div class="d-main"><h1>{e(item["title"])}</h1><p class="where">{e(item["city_name"])}{" · " + e(item["district"]) if item["district"] else ""}</p>{deal}
<ul class="facts">{"".join(facts)}</ul>
{"<h2>المرافق والخدمات</h2><ul class=chips>" + chips + "</ul>" if chips else ""}
{"<h2>الوصف</h2><p class=desc>" + e(item["description"]) + "</p>" if item["description"] else ""}
{note}{blocked}
<div class="actions">{mapbtn}<button class="btn ghost" type="button" data-copy="{e(site + '/r/' + str(lid) if site else '')}">نسخ رابط الإعلان</button></div>
<p class="fine">السعر والتوفر يؤكدهما صاحب الاستراحة عند التواصل. الحجز والدفع يتمان بينك وبينه مباشرة.</p></div>
<div class="buy"><div><span class="lbl">يبدأ من</span>{ui.price_html(item)}</div>
<a class="btn wa" id="wa" data-id="{lid}" href="{e(link)}" target="_blank" rel="noopener noreferrer">تواصل واتساب للحجز</a></div></article>"""
        desc = (item["description"] or f"{item['category_name']} للإيجار في {item['city_name']}")[:150]
        cover = f"{site}/media/{photos[0]['filename']}" if photos and site else ""
        return html_page(ctx, item["title"], body, description=desc, canonical=f"/r/{lid}", image=cover, noindex=owner_view, extra_class="detail-page")

    @app.route("POST", r"/api/click/(\d{1,9})", "public")
    async def click(ctx: Ctx, raw_id: str):
        if app.click_limit.allow(ctx.request.ip):
            db.run("UPDATE listings SET clicks = clicks + 1 WHERE id = ? AND review = 'approved'", (int(raw_id),))
        return Response(204, b"", "text/plain")

    @app.route("GET", "/terms")
    async def terms(ctx: Ctx):
        return html_page(ctx, "الشروط والأحكام", _doc("الشروط والأحكام", TERMS), canonical="/terms")

    @app.route("GET", "/privacy")
    async def privacy(ctx: Ctx):
        return html_page(ctx, "الخصوصية", _doc("سياسة الخصوصية", PRIVACY), canonical="/privacy")

    @app.route("GET", r"/media/([A-Za-z0-9]{8,64}\.(?:jpg|png|webp))")
    async def media(ctx: Ctx, name: str):
        path = app.settings.uploads_dir / name
        try:
            data = path.read_bytes()
        except OSError:
            return not_found(ctx)
        return Response(200, data, images.CONTENT_TYPES[name.rsplit(".", 1)[1]], {"Cache-Control": "public, max-age=31536000, immutable"})

    @app.route("GET", r"/static/([A-Za-z0-9_.-]{1,60})")
    async def static(ctx: Ctx, name: str):
        path = STATIC_DIR / name
        kind = STATIC_TYPES.get(path.suffix)
        if kind is None or not path.is_file():
            return not_found(ctx)
        return Response(200, path.read_bytes(), kind, {"Cache-Control": "public, max-age=3600"})

    @app.route("GET", "/robots.txt")
    async def robots(ctx: Ctx):
        site = ctx.settings.site_url
        text = "User-agent: *\nDisallow: /admin\nDisallow: /owner\nDisallow: /api/\n" + (f"Sitemap: {site}/sitemap.xml\n" if site else "")
        return Response(200, text.encode(), "text/plain; charset=utf-8", {"Cache-Control": "public, max-age=3600"})

    @app.route("GET", "/sitemap.xml")
    async def sitemap(ctx: Ctx):
        site = ctx.settings.site_url
        if not site:
            return not_found(ctx)
        urls = [f"{site}/", f"{site}/search", f"{site}/offers"] + [f"{site}/r/{r['id']}" for r in db.all(
            "SELECT l.id FROM listings l JOIN cities c ON c.id = l.city_id WHERE l.review = 'approved' AND l.owner_active = 1 ORDER BY l.id DESC LIMIT 5000")]
        xml = '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' + "".join(
            f"<url><loc>{e(u)}</loc></url>" for u in urls) + "</urlset>"
        return Response(200, xml.encode(), "application/xml; charset=utf-8", {"Cache-Control": "public, max-age=3600"})

    @app.route("GET", "/healthz")
    async def healthz(ctx: Ctx):
        db.one("SELECT 1")
        return text_response(200, "ok")


def _doc(title: str, sections: list[tuple[str, str]]) -> str:
    return f'<article class="doc"><h1>{e(title)}</h1>' + "".join(f"<h2>{e(h)}</h2><p>{e(p)}</p>" for h, p in sections) + "</article>"
