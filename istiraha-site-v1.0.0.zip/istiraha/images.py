"""Checks an uploaded picture and removes what it should not carry (the phone's GPS position, camera data, comments).

Only JPEG, PNG and WebP are accepted, recognised by their bytes and not by the name the visitor gave."""
from __future__ import annotations

import struct

MAX_SIDE = 12000
MIN_SIDE = 80


class ImageError(ValueError):
    pass


def detect(data: bytes) -> str | None:
    if data[:3] == b"\xff\xd8\xff":
        return "jpg"
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "webp"
    return None


def _check_size(w: int, h: int) -> None:
    if not (MIN_SIDE <= w <= MAX_SIDE and MIN_SIDE <= h <= MAX_SIDE):
        raise ImageError("مقاس الصورة غير مناسب")


def _clean_jpeg(data: bytes) -> tuple[bytes, int, int]:
    out = bytearray(b"\xff\xd8")
    i, size = 2, None
    n = len(data)
    while True:
        if i + 4 > n:
            raise ImageError("ملف الصورة ناقص")
        if data[i] != 0xFF:
            raise ImageError("ملف الصورة تالف")
        marker = data[i + 1]
        if marker == 0xFF:
            i += 1
            continue
        if marker == 0xD9:
            raise ImageError("ملف الصورة تالف")
        length = struct.unpack(">H", data[i + 2:i + 4])[0]
        if length < 2 or i + 2 + length > n:
            raise ImageError("ملف الصورة تالف")
        segment = data[i:i + 2 + length]
        if marker in (0xC0, 0xC1, 0xC2) and length >= 8:
            h, w = struct.unpack(">HH", data[i + 5:i + 9])
            size = (w, h)
        if marker == 0xE1 or marker == 0xED or marker == 0xFE:
            pass                                  # camera data, GPS position, Photoshop data, comments: dropped
        else:
            out += segment
        i += 2 + length
        if marker == 0xDA:                        # the picture itself follows, copied as it is
            out += data[i:]
            break
    if size is None:
        raise ImageError("ملف الصورة تالف")
    if not data.rstrip(b"\x00").endswith(b"\xff\xd9"):
        raise ImageError("ملف الصورة ناقص")
    _check_size(*size)
    return bytes(out), size[0], size[1]


_PNG_KEEP = {b"IHDR", b"PLTE", b"IDAT", b"IEND", b"tRNS", b"gAMA", b"cHRM", b"sRGB", b"iCCP", b"sBIT", b"pHYs"}


def _clean_png(data: bytes) -> tuple[bytes, int, int]:
    out = bytearray(data[:8])
    i, size, ended = 8, None, False
    while i + 8 <= len(data):
        length, kind = struct.unpack(">I4s", data[i:i + 8])
        end = i + 12 + length
        if end > len(data):
            raise ImageError("ملف الصورة ناقص")
        if kind == b"IHDR":
            if length != 13:
                raise ImageError("ملف الصورة تالف")
            size = struct.unpack(">II", data[i + 8:i + 16])
        if kind in _PNG_KEEP:
            out += data[i:end]
        i = end
        if kind == b"IEND":
            ended = True
            break
    if size is None or not ended:
        raise ImageError("ملف الصورة ناقص")
    _check_size(*size)
    return bytes(out), size[0], size[1]


def _clean_webp(data: bytes) -> tuple[bytes, int, int]:
    if len(data) < 20:
        raise ImageError("ملف الصورة ناقص")
    declared = struct.unpack("<I", data[4:8])[0] + 8
    if declared > len(data) or declared < 20:
        raise ImageError("ملف الصورة ناقص")
    body, i, size = bytearray(), 12, None
    while i + 8 <= declared:
        kind, length = data[i:i + 4], struct.unpack("<I", data[i + 4:i + 8])[0]
        end = i + 8 + length + (length & 1)
        if end > declared:
            raise ImageError("ملف الصورة تالف")
        chunk = bytearray(data[i:end])
        payload = data[i + 8:i + 8 + length]
        if kind == b"VP8X" and length >= 10:
            chunk[8] &= ~0x0C                      # the flags for EXIF and XMP are cleared
            size = (int.from_bytes(payload[4:7], "little") + 1, int.from_bytes(payload[7:10], "little") + 1)
        elif kind == b"VP8 " and length >= 10 and payload[3:6] == b"\x9d\x01\x2a" and size is None:
            size = (struct.unpack("<H", payload[6:8])[0] & 0x3FFF, struct.unpack("<H", payload[8:10])[0] & 0x3FFF)
        elif kind == b"VP8L" and length >= 5 and payload[0] == 0x2F and size is None:
            bits = int.from_bytes(payload[1:5], "little")
            size = ((bits & 0x3FFF) + 1, ((bits >> 14) & 0x3FFF) + 1)
        if kind in (b"EXIF", b"XMP "):
            i = end
            continue
        body += chunk
        i = end
    if size is None:
        raise ImageError("ملف الصورة تالف")
    _check_size(*size)
    cleaned = b"RIFF" + struct.pack("<I", len(body) + 4) + b"WEBP" + bytes(body)
    return cleaned, size[0], size[1]


def clean(data: bytes, max_bytes: int) -> tuple[str, bytes, int, int]:
    """(extension, cleaned bytes, width, height) or ImageError."""
    if not data:
        raise ImageError("ما وصلت صورة")
    if len(data) > max_bytes:
        raise ImageError(f"الصورة أكبر من {max_bytes // (1024 * 1024)} ميغابايت")
    kind = detect(data)
    if kind is None:
        raise ImageError("نوع الملف غير مدعوم، المسموح JPG أو PNG أو WebP")
    cleaner = {"jpg": _clean_jpeg, "png": _clean_png, "webp": _clean_webp}[kind]
    try:
        cleaned, w, h = cleaner(data)
    except (struct.error, IndexError):
        raise ImageError("ملف الصورة تالف") from None
    return kind, cleaned, w, h


CONTENT_TYPES = {"jpg": "image/jpeg", "png": "image/png", "webp": "image/webp"}
