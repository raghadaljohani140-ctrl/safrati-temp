"""Reading and writing the adverts: search, offers, discounts, validation of what an owner types."""
from __future__ import annotations

import re
from datetime import date, timedelta
from urllib.parse import urlsplit

from . import util
from .db import Database

UNITS = {"night": "الليلة", "day": "اليوم (نهاري)", "period": "الفترة (صباحية أو مسائية)", "week": "الأسبوع"}
UNIT_SHORT = {"night": "ليلة", "day": "يوم", "period": "فترة", "week": "أسبوع"}
SORTS = {"new": "الأحدث", "cheap": "الأرخص", "dear": "الأغلى", "deal": "أعلى خصم"}
PAGE_SIZE = 12
REVIEW_LABELS = {"pending": "بانتظار المراجعة", "approved": "معتمد", "rejected": "مرفوض", "stopped": "موقوف من الإدارة"}
RENTAL_STATUS = {"pending": "قيد التأكيد", "confirmed": "مؤكد", "completed": "تم", "cancelled": "ملغي"}
PAY_STATUS = {"due": "مستحقة", "paid": "مدفوعة", "disputed": "متنازع عليها", "waived": "معفاة"}
# what the admin sees in "latest operations" (the stored keys stay English and stable; an unknown key is shown as it is)
AUDIT_LABELS = {
    "admin_login": "دخول المدير", "admin_password": "تغيير كلمة مرور الإدارة", "owner_password": "تغيير كلمة مرور مالك",
    "lockout": "قفل حساب مؤقتًا", "commission": "تغيير نسبة العمولة", "pledge": "نسخة جديدة من التعهد",
    "block_owner": "إيقاف حساب مالك", "unblock_owner": "إعادة تفعيل مالك", "reset_password": "كلمة مرور مؤقتة لمالك",
    "listing_approve": "اعتماد إعلان", "listing_reject": "رفض إعلان", "listing_stop": "إيقاف إعلان", "listing_feature": "تمييز إعلان",
    "rental_new": "تسجيل عملية تأجير", "rental_update": "تعديل عملية تأجير", "offer_new": "عرض جديد",
    "add_cities": "إضافة مدينة", "add_categories": "إضافة نوع", "add_amenities": "إضافة مرفق",
}
MAX_BLOCKS = 60


def active_offers(db: Database, today: date) -> list:
    return db.all("SELECT * FROM offers WHERE active = 1 AND starts_on <= ? AND ends_on >= ?", (today.isoformat(), today.isoformat()))


def discount_for(listing, offers) -> tuple[int, str]:
    """The biggest discount that applies to this advert, and the offer's title."""
    best, title = 0, ""
    for o in offers:
        if o["listing_id"] and o["listing_id"] != listing["id"]:
            continue
        if not o["listing_id"]:
            if o["city_id"] and o["city_id"] != listing["city_id"]:
                continue
            if o["category_id"] and o["category_id"] != listing["category_id"]:
                continue
        if o["percent"] > best:
            best, title = o["percent"], o["title"]
    return best, title


def price_after(price: int, percent: int) -> int:
    return round(price * (100 - percent) / 100) if percent else price


def _decorate(db: Database, rows, offers) -> list[dict]:
    items = []
    for r in rows:
        item = dict(r)
        pct, offer_title = discount_for(r, offers)
        item.update(discount=pct, offer_title=offer_title, final_price=price_after(r["price"], pct))
        items.append(item)
    return items


_BASE = """
SELECT l.*, c.name AS city_name, g.name AS category_name,
  (SELECT filename FROM photos p WHERE p.listing_id = l.id ORDER BY p.position, p.id LIMIT 1) AS cover
FROM listings l JOIN cities c ON c.id = l.city_id JOIN categories g ON g.id = l.category_id
"""
_PUBLIC = ("l.review = 'approved' AND l.owner_active = 1 AND c.active = 1 AND g.active = 1 "
           "AND l.owner_id IN (SELECT id FROM users WHERE status = 'active')")


def search(db: Database, today: date, *, city: int | None = None, category: int | None = None, district: str = "",
           price_min: int | None = None, price_max: int | None = None, on: date | None = None, amenities: list[int] | None = None,
           offers_only: bool = False, sort: str = "new", page: int = 1, query: str = "", featured_only: bool = False) -> tuple[list[dict], int]:
    where, args = [_PUBLIC], []
    if city:
        where.append("l.city_id = ?")
        args.append(city)
    if category:
        where.append("l.category_id = ?")
        args.append(category)
    if district:
        where.append("l.district LIKE ? ESCAPE '\\'")
        args.append("%" + district.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%")
    if query:
        where.append("(l.title LIKE ? ESCAPE '\\' OR l.description LIKE ? ESCAPE '\\')")
        like = "%" + query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        args += [like, like]
    if featured_only:
        where.append("l.featured = 1")
    if on:
        where.append("NOT EXISTS (SELECT 1 FROM blocked_dates b WHERE b.listing_id = l.id AND ? BETWEEN b.start_date AND b.end_date)")
        args.append(on.isoformat())
    for a in (amenities or [])[:12]:
        where.append("EXISTS (SELECT 1 FROM listing_amenities la WHERE la.listing_id = l.id AND la.amenity_id = ?)")
        args.append(a)
    rows = db.all(f"{_BASE} WHERE {' AND '.join(where)} ORDER BY l.id DESC", tuple(args))
    items = _decorate(db, rows, active_offers(db, today))
    if offers_only:
        items = [i for i in items if i["discount"]]
    if price_min is not None:
        items = [i for i in items if i["final_price"] >= price_min]
    if price_max is not None:
        items = [i for i in items if i["final_price"] <= price_max]
    if sort == "cheap":
        items.sort(key=lambda i: (i["final_price"], -i["id"]))
    elif sort == "dear":
        items.sort(key=lambda i: (-i["final_price"], -i["id"]))
    elif sort == "deal":
        items.sort(key=lambda i: (-i["discount"], -i["id"]))
    total = len(items)
    start = (max(1, page) - 1) * PAGE_SIZE
    return items[start:start + PAGE_SIZE], total


def public_listing(db: Database, listing_id: int, today: date) -> dict | None:
    row = db.one(f"{_BASE} WHERE l.id = ? AND {_PUBLIC}", (listing_id,))
    return _decorate(db, [row], active_offers(db, today))[0] if row else None


def any_listing(db: Database, listing_id: int) -> dict | None:
    row = db.one(f"{_BASE} WHERE l.id = ?", (listing_id,))
    return dict(row) if row else None


def amenities_of(db: Database, listing_id: int) -> list[str]:
    return [r["name"] for r in db.all(
        "SELECT a.name FROM listing_amenities la JOIN amenities a ON a.id = la.amenity_id WHERE la.listing_id = ? ORDER BY a.sort, a.id", (listing_id,))]


def amenity_ids_of(db: Database, listing_id: int) -> set[int]:
    return {r["amenity_id"] for r in db.all("SELECT amenity_id FROM listing_amenities WHERE listing_id = ?", (listing_id,))}


def photos_of(db: Database, listing_id: int) -> list:
    return db.all("SELECT * FROM photos WHERE listing_id = ? ORDER BY position, id", (listing_id,))


def blocks_of(db: Database, listing_id: int) -> list:
    return db.all("SELECT * FROM blocked_dates WHERE listing_id = ? ORDER BY start_date", (listing_id,))


def homepage(db: Database, today: date) -> dict:
    """Three shelves for the front page. An advert sits on the first shelf it qualifies for, so a young site with
    only a few adverts does not show the same card three times."""
    shelves = (("featured", search(db, today, featured_only=True)[0]),
               ("deals", search(db, today, offers_only=True, sort="deal")[0]),
               ("latest", search(db, today)[0]))
    seen: set[int] = set()
    out: dict[str, list[dict]] = {}
    for key, rows in shelves:
        picked = [r for r in rows if r["id"] not in seen][:6]
        seen.update(r["id"] for r in picked)
        out[key] = picked
    return out


# ---- what an owner types ------------------------------------------------------------------------------------
_MAP_HOSTS = ("maps.app.goo.gl", "goo.gl", "www.google.com", "google.com", "maps.google.com", "www.google.com.sa", "maps.apple.com")


def clean_map_url(text: str) -> str | None:
    text = (text or "").strip()
    if not text:
        return ""
    try:
        parts = urlsplit(text)
    except ValueError:
        return None
    if parts.scheme != "https" or (parts.hostname or "") not in _MAP_HOSTS or len(text) > 400:
        return None
    return text


def _text(form, name: str, low: int, high: int, label: str, errors: dict, required: bool = True) -> str:
    value = re.sub(r"[ \t]+", " ", (form.get(name) or "").replace("\r\n", "\n")).strip()
    value = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", value)
    if required and len(value) < low:
        errors[name] = f"{label}: اكتب {low} أحرف على الأقل" if low > 1 else f"اكتب {label}"
    elif len(value) > high:
        errors[name] = f"{label} طويل (الحد {high} حرفًا)"
    return value


def validate_listing(db: Database, form: dict, *, whatsapp_default: str = "") -> tuple[dict, dict]:
    """(values, errors). `form` maps names to a single string, except "amenities" which is a list."""
    errors: dict[str, str] = {}
    v: dict = {}
    v["title"] = _text(form, "title", 4, 80, "اسم الاستراحة", errors)
    v["district"] = _text(form, "district", 0, 60, "الحي", errors, required=False)
    v["description"] = _text(form, "description", 0, 2000, "الوصف", errors, required=False)
    v["availability_note"] = _text(form, "availability_note", 0, 300, "ملاحظة الأوقات", errors, required=False)
    city = util.parse_int(form.get("city") or "", 1, 10**6)
    if not city or not db.one("SELECT 1 FROM cities WHERE id = ? AND active = 1", (city,)):
        errors["city"] = "اختر المدينة"
    v["city_id"] = city
    cat = util.parse_int(form.get("category") or "", 1, 10**6)
    if not cat or not db.one("SELECT 1 FROM categories WHERE id = ? AND active = 1", (cat,)):
        errors["category"] = "اختر نوع الاستراحة"
    v["category_id"] = cat
    price = util.parse_int(form.get("price") or "", 1, 1_000_000)
    if not price:
        errors["price"] = "اكتب سعر الإيجار بالأرقام (بالريال)"
    v["price"] = price
    unit = form.get("unit") or ""
    if unit not in UNITS:
        errors["unit"] = "اختر مدة الإيجار"
    v["unit"] = unit
    cap = (form.get("capacity") or "").strip()
    v["capacity"] = util.parse_int(cap, 1, 5000) if cap else None
    if cap and v["capacity"] is None:
        errors["capacity"] = "عدد الأشخاص غير صحيح"
    phone = util.normalize_phone(form.get("whatsapp") or "") or ""
    if not phone:
        errors["whatsapp"] = "اكتب رقم جوال سعودي صحيح، مثل 0551234567"
    v["whatsapp"] = phone
    url = clean_map_url(form.get("map_url") or "")
    if url is None:
        errors["map_url"] = "رابط الموقع يجب أن يكون رابط خرائط قوقل (يبدأ بـ https)"
    v["map_url"] = url or ""
    ids = set()
    for raw in form.get("amenities") or []:
        n = util.parse_int(str(raw), 1, 10**6)
        if n:
            ids.add(n)
    valid = {r["id"] for r in db.all("SELECT id FROM amenities WHERE active = 1")}
    v["amenities"] = sorted(ids & valid)
    return v, errors


# fields that make the advert go back to review when they change (the price and the dates do not)
REVIEWED_FIELDS = ("title", "district", "description", "map_url", "city_id", "category_id", "whatsapp", "capacity", "availability_note")
