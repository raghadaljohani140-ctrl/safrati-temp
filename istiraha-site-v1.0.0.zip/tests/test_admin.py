import re

from istiraha import security
from tests.helpers import NOW, Case, Client


class AdminAccessTests(Case):
    async def test_login_wrong_and_right(self):
        await self.make_admin()
        c = Client(self.app, "198.51.100.20")
        await c.get("/admin/login")
        await c.post("/admin/login", {"login": "manager", "password": "bad-pass-123"})
        self.assertIn("بيانات الدخول غير صحيحة", c.text)
        r = await c.post("/admin/login", {"login": "MANAGER", "password": "Str0ng-pass!"}, page="/admin/login")
        self.assertEqual((r.status, r.headers["Location"]), (303, "/admin"))
        cookie = [x for x in r.cookies if x.startswith("ist_a=")][0]
        for flag in ("HttpOnly", "Secure", "SameSite=Lax", "Path=/admin"):
            self.assertIn(flag, cookie)
        self.assertEqual((await c.get("/admin")).status, 200)
        self.assertIn("noindex", c.text)

    async def test_admin_pages_need_the_admin_to_be_signed_in(self):
        for path in ("/admin", "/admin/commission", "/admin/owners", "/admin/owner/1", "/admin/listings", "/admin/listing/1", "/admin/rentals", "/admin/rental/new", "/admin/settings", "/admin/offers"):
            r = await self.visitor.get(path)
            self.assertEqual((r.status, r.headers["Location"]), (303, "/admin/login"), path)
        for path in ("/admin/commission", "/admin/pledge", "/admin/rental/new", "/admin/lookup/cities", "/admin/offers", "/admin/listing/1/approve", "/admin/owner/1/block"):
            r = await self.visitor.go("POST", path, {"percent": "1", "_csrf": "x"})
            self.assertIn(r.status, (303, 403), path)
        self.assertEqual(self.db.commission_bp(), 1000)

    async def test_five_wrong_passwords_lock_the_admin_account(self):
        await self.make_admin()
        c = Client(self.app, "198.51.100.21")
        await c.get("/admin/login")
        for _ in range(5):
            await c.post("/admin/login", {"login": "manager", "password": "bad-pass-123"})
        await c.post("/admin/login", {"login": "manager", "password": "Str0ng-pass!"})
        self.assertIn("مقفل", c.text)
        self.clock.t += 29 * 60
        await c.post("/admin/login", {"login": "manager", "password": "Str0ng-pass!"})
        self.assertIn("مقفل", c.text)                                                          # the admin lock is longer
        self.clock.t += 2 * 60
        r = await c.post("/admin/login", {"login": "manager", "password": "Str0ng-pass!"})
        self.assertEqual(r.status, 303)

    async def test_the_admin_session_ends_after_hours(self):
        admin = await self.make_admin()
        self.assertEqual((await admin.get("/admin")).status, 200)
        self.clock.t += 13 * 3600
        self.assertEqual((await admin.get("/admin")).status, 303)

    async def test_changing_the_admin_password(self):
        admin = await self.make_admin()
        await admin.post("/admin/password", {"current": "wrong", "new": "N3w-password!"}, page="/admin/settings")
        self.assertIn("غير صحيحة", await admin.message())
        await admin.post("/admin/password", {"current": "Str0ng-pass!", "new": "123"}, page="/admin/settings")
        self.assertIn("قصيرة", await admin.message())
        await admin.post("/admin/password", {"current": "Str0ng-pass!", "new": "N3w-password!"}, page="/admin/settings")
        self.assertIn("تم تغيير", await admin.message())
        c = Client(self.app, "198.51.100.22")
        await c.get("/admin/login")
        await c.post("/admin/login", {"login": "manager", "password": "Str0ng-pass!"})
        self.assertIn("غير صحيحة", c.text)
        r = await c.post("/admin/login", {"login": "manager", "password": "N3w-password!"}, page="/admin/login")
        self.assertEqual(r.status, 303)


class CommissionTests(Case):
    async def test_the_rate_can_be_changed_from_the_panel_and_the_history_is_kept(self):
        admin = await self.make_admin()
        self.assertEqual(self.db.commission_bp(), 1000)
        await admin.get("/admin/commission")
        self.assertIn("10%", admin.text)
        for value, bp in (("5", 500), ("15", 1500), ("7.5", 750), ("٢٠", 2000)):
            r = await admin.post("/admin/commission", {"percent": value, "note": f"إلى {value}"}, page="/admin/commission")
            self.assertEqual(r.status, 303, value)
            self.assertEqual(self.db.commission_bp(), bp)
        history = self.db.all("SELECT * FROM commission_history ORDER BY id")
        self.assertEqual([h["basis_points"] for h in history], [1000, 500, 1500, 750, 2000])
        self.assertEqual(history[-1]["note"], "إلى ٢٠")
        self.assertEqual(history[-1]["changed_by"], self.db.one("SELECT id FROM users WHERE login = 'manager'")["id"])
        await admin.get("/admin/commission")
        for word in ("20%", "7.5%", "15%", "5%", "النسبة الأولية"):
            self.assertIn(word, admin.text)

    async def test_bad_rates_are_refused(self):
        admin = await self.make_admin()
        for bad in ("", "abc", "-1", "101", "10.555", "1e3"):
            r = await admin.post("/admin/commission", {"percent": bad}, page="/admin/commission")
            self.assertEqual(r.status, 200, bad)
            self.assertIn("نسبة صحيحة", admin.text)
        self.assertEqual(self.db.commission_bp(), 1000)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM commission_history")["n"], 1)

    async def test_an_unchanged_rate_adds_no_history_line(self):
        admin = await self.make_admin()
        await admin.post("/admin/commission", {"percent": "10"}, page="/admin/commission")
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM commission_history")["n"], 1)

    async def test_the_new_rate_applies_to_new_adverts_and_never_changes_old_agreements(self):
        admin = await self.make_admin()
        old_owner = await self.make_owner("0551111111", ip="203.0.113.11")
        old = await self.add_listing(old_owner, "القديمة")
        await admin.post("/admin/commission", {"percent": "15"}, page="/admin/commission")
        new_owner = await self.make_owner("0552222222", ip="203.0.113.12")
        await new_owner.get("/owner/new")
        self.assertIn("15%", new_owner.text)
        self.assertIn("فالعمولة المستحقة 75 ريال", new_owner.text)
        new = await self.add_listing(new_owner, "الجديدة")
        rate = lambda lid: self.db.one("SELECT c.basis_points AS bp FROM listings l JOIN consents c ON c.id = l.consent_id WHERE l.id = ?", (lid,))["bp"]
        self.assertEqual((rate(old), rate(new)), (1000, 1500))
        # the older owner still sees his own agreement, and is offered the new terms without being bound to them
        await old_owner.get(f"/owner/listing/{old}")
        self.assertIn("شروط عمولة جديدة (15%)", old_owner.text)
        self.assertIn("10%", old_owner.text)
        # rentals follow the rate each advert agreed
        self.approve(old)
        self.approve(new)
        for lid in (old, new):
            await admin.post("/admin/rental/new", {"listing": str(lid), "rent": "500", "date": "2026-11-01", "status": "confirmed"}, page="/admin/rental/new")
        rows = self.db.all("SELECT listing_id, basis_points, commission_halalas FROM rentals ORDER BY id")
        self.assertEqual([(r["basis_points"], r["commission_halalas"]) for r in rows], [(1000, 5000), (1500, 7500)])

    async def test_agreeing_again_changes_only_the_future(self):
        admin = await self.make_admin()
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        self.approve(lid)
        await admin.post("/admin/rental/new", {"listing": str(lid), "rent": "1000", "date": "2026-11-01", "status": "confirmed"}, page="/admin/rental/new")
        await admin.post("/admin/commission", {"percent": "12"}, page="/admin/commission")
        await owner.get(f"/owner/listing/{lid}/reconsent")
        self.assertIn("12%", owner.text)
        await owner.post(f"/owner/listing/{lid}/reconsent", {"agree": "1", "version": "1", "bp": "1200"}, page=f"/owner/listing/{lid}/reconsent")
        self.assertEqual(self.db.one("SELECT consent_id FROM listings WHERE id = ?", (lid,))["consent_id"], 2)
        await admin.post("/admin/rental/new", {"listing": str(lid), "rent": "1000", "date": "2026-11-02", "status": "confirmed"}, page="/admin/rental/new")
        rows = self.db.all("SELECT basis_points, commission_halalas, consent_id FROM rentals ORDER BY id")
        self.assertEqual([(r["basis_points"], r["commission_halalas"], r["consent_id"]) for r in rows], [(1000, 10000, 1), (1200, 12000, 2)])
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM consents")["n"], 2)

    async def test_the_old_agreement_text_survives_a_new_pledge_version(self):
        admin = await self.make_admin()
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        original = self.db.one("SELECT pledge_text FROM consents")["pledge_text"]
        text = "نص تعهد جديد ومختلف تمامًا يشرح الالتزام بسداد العمولة المستحقة للمنصة وفق النسبة التي يوافق عليها المالك قبل نشر إعلانه."
        await admin.post("/admin/pledge", {"body": text}, page="/admin/commission")
        self.assertEqual(self.db.pledge()["version"], 2)
        self.assertEqual(self.db.one("SELECT pledge_text FROM consents WHERE id = 1")["pledge_text"], original)
        await owner.get("/owner/new")
        self.assertIn("نص تعهد جديد ومختلف", owner.text)
        self.assertIn("النسخة 2", owner.text)
        await admin.post("/admin/pledge", {"body": "قصير"}, page="/admin/commission")
        self.assertEqual(self.db.pledge()["version"], 2)

    async def test_the_admin_sees_every_owner_agreement(self):
        admin = await self.make_admin()
        owner = await self.make_owner()
        await self.add_listing(owner, "استراحة الاتفاق")
        await admin.post("/admin/commission", {"percent": "20"}, page="/admin/commission")
        oid = self.db.one("SELECT id FROM users WHERE role = 'owner'")["id"]
        await admin.get(f"/admin/owner/{oid}")
        html = admin.text
        for word in ("استراحة الاتفاق", "10%", "نسخة 1", "أتعهد وأوافق على شروط استخدام المنصة", "2026-10-"):
            self.assertIn(word, html)
        await admin.get("/admin/owners")
        self.assertIn("أبو سعد", admin.text)
        self.assertIn("0551234567", admin.text)


class ModerationTests(Case):
    async def test_approve_reject_stop_and_feature(self):
        admin = await self.make_admin()
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        await admin.get("/admin/listings?status=pending")
        self.assertIn("استراحة النخيل", admin.text)
        await admin.post(f"/admin/listing/{lid}/reject", {"note": ""}, page=f"/admin/listing/{lid}")
        self.assertIn("اكتب السبب", await admin.message())
        self.assertEqual(self.db.one("SELECT review FROM listings")["review"], "pending")
        await admin.post(f"/admin/listing/{lid}/reject", {"note": "الصور غير واضحة"}, page=f"/admin/listing/{lid}")
        self.assertEqual(self.db.one("SELECT review, review_note FROM listings")["review"], "rejected")
        await owner.get(f"/owner/listing/{lid}")
        self.assertIn("الصور غير واضحة", owner.text)
        await admin.post(f"/admin/listing/{lid}/approve", page=f"/admin/listing/{lid}")
        row = self.db.one("SELECT * FROM listings")
        self.assertEqual((row["review"], row["review_note"], row["approved_at"]), ("approved", "", NOW))
        self.assertEqual((await self.visitor.get(f"/r/{lid}")).status, 200)
        await admin.post(f"/admin/listing/{lid}/feature", page=f"/admin/listing/{lid}")
        self.assertEqual(self.db.one("SELECT featured FROM listings")["featured"], 1)
        await self.visitor.get("/")
        self.assertIn("الاستراحات المميزة", self.visitor.text)
        await admin.post(f"/admin/listing/{lid}/stop", {"note": "شكوى"}, page=f"/admin/listing/{lid}")
        self.assertEqual((await self.visitor.get(f"/r/{lid}")).status, 404)
        actions = [a["action"] for a in self.db.all("SELECT action FROM audit")]
        for word in ("listing_reject", "listing_approve", "listing_feature", "listing_stop"):
            self.assertIn(word, actions)

    async def test_blocking_an_owner_and_resetting_the_password(self):
        admin = await self.make_admin()
        owner = await self.make_owner()
        oid = self.db.one("SELECT id FROM users WHERE role = 'owner'")["id"]
        await admin.post(f"/admin/owner/{oid}/reset", page=f"/admin/owner/{oid}")
        temp = re.search(r"\(تظهر مرة واحدة\): ([A-Za-z0-9_-]+)", admin.text).group(1)
        self.assertEqual((await owner.get("/owner")).status, 303)                           # the old session was ended
        c = Client(self.app, "203.0.113.70")
        await c.get("/owner/login")
        r = await c.post("/owner/login", {"phone": "0551234567", "password": temp})
        self.assertEqual(r.status, 303)
        await admin.post(f"/admin/owner/{oid}/block", page=f"/admin/owner/{oid}")
        c2 = Client(self.app, "203.0.113.71")
        await c2.get("/owner/login")
        await c2.post("/owner/login", {"phone": "0551234567", "password": temp})
        self.assertIn("موقوف", c2.text)
        await admin.post(f"/admin/owner/{oid}/unblock", page=f"/admin/owner/{oid}")
        r = await c2.post("/owner/login", {"phone": "0551234567", "password": temp}, page="/owner/login")
        self.assertEqual(r.status, 303)


class RentalTests(Case):
    async def prepared(self):
        admin = await self.make_admin()
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        self.approve(lid)
        return admin, owner, lid

    async def test_recording_a_rental_computes_the_commission(self):
        admin, owner, lid = await self.prepared()
        r = await admin.post("/admin/rental/new", {"listing": str(lid), "rent": "500", "date": "2026-11-01", "status": "confirmed", "customer": "عميل 055", "note": "اتفقنا عبر واتساب"}, page="/admin/rental/new")
        self.assertEqual(r.status, 303)
        row = self.db.one("SELECT * FROM rentals")
        self.assertEqual((row["rent"], row["basis_points"], row["commission_halalas"], row["pay_status"]), (500, 1000, 5000, "due"))
        self.assertEqual(row["due_date"], "2026-11-08")                                      # seven days after the rental
        self.assertEqual(row["owner_id"], self.db.one("SELECT owner_id FROM listings")["owner_id"])
        self.assertEqual(self.db.one("SELECT body FROM rental_notes")["body"], "اتفقنا عبر واتساب")
        await admin.get(f"/admin/rental/{row['id']}")
        self.assertIn("50 ر.س", admin.text)
        self.assertIn("10%", admin.text)

    async def test_bad_rental_forms(self):
        admin, owner, lid = await self.prepared()
        for form in ({"listing": "999", "rent": "500", "date": "2026-11-01"}, {"listing": str(lid), "rent": "0", "date": "2026-11-01"},
                     {"listing": str(lid), "rent": "500", "date": "nope"}, {"listing": str(lid), "rent": "500", "date": "2026-11-01", "status": "weird"}):
            r = await admin.post("/admin/rental/new", {"status": "confirmed", **form}, page="/admin/rental/new")
            self.assertEqual(r.status, 400, form)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM rentals")["n"], 0)

    async def test_payment_states_lateness_and_the_totals(self):
        admin, owner, lid = await self.prepared()
        for rent, day in ((500, "2026-10-01"), (1000, "2026-10-25"), (2000, "2026-10-20")):
            await admin.post("/admin/rental/new", {"listing": str(lid), "rent": str(rent), "date": day, "status": "confirmed"}, page="/admin/rental/new")
        # today is 2026-10-26: the first (due 10-08) and the third (due 10-27: not yet) -> only the first is late
        await admin.get("/admin/rentals?pay=late")
        self.assertIn("#1", admin.text)
        self.assertNotIn("#2", admin.text)
        self.assertNotIn("#3", admin.text)
        await admin.post("/admin/rental/3/update", {"rent": "2000", "status": "confirmed", "pay_status": "paid"}, page="/admin/rental/3")
        self.assertEqual(self.db.one("SELECT pay_status, paid_at FROM rentals WHERE id = 3")["paid_at"], NOW)
        await admin.post("/admin/rental/2/update", {"rent": "1000", "status": "confirmed", "pay_status": "disputed"}, page="/admin/rental/2")
        await admin.get("/admin")
        html = admin.text
        self.assertIn("50", html)                                                              # late 50.00
        self.assertIn("200", html)                                                             # paid 200
        self.assertIn("100", html)                                                             # disputed 100
        await admin.get("/admin/rentals?pay=paid")
        self.assertIn("#3", admin.text)
        self.assertNotIn("#1", admin.text)
        await admin.get("/admin/rentals?pay=disputed")
        self.assertIn("#2", admin.text)

    async def test_changing_the_rent_recomputes_with_the_agreed_rate_and_cancelled_ones_leave_the_totals(self):
        admin, owner, lid = await self.prepared()
        await admin.post("/admin/commission", {"percent": "50"}, page="/admin/commission")
        await admin.post("/admin/rental/new", {"listing": str(lid), "rent": "400", "date": "2026-11-01", "status": "confirmed"}, page="/admin/rental/new")
        await admin.post("/admin/rental/1/update", {"rent": "600", "status": "confirmed", "pay_status": "due"}, page="/admin/rental/1")
        row = self.db.one("SELECT * FROM rentals")
        self.assertEqual((row["rent"], row["basis_points"], row["commission_halalas"]), (600, 1000, 6000))        # still the agreed 10%, not today's 50%
        await admin.post("/admin/rental/1/update", {"rent": "600", "status": "cancelled", "pay_status": "due"}, page="/admin/rental/1")
        await admin.get("/admin/rentals")
        self.assertIn("(بدون الملغي): <b>0</b>", admin.text)
        notes = [n["body"] for n in self.db.all("SELECT body FROM rental_notes ORDER BY id")]
        self.assertTrue(any("rent" in n for n in notes) and any("status" in n for n in notes))

    async def test_notes_and_objections_are_kept_in_a_log(self):
        admin, owner, lid = await self.prepared()
        await admin.post("/admin/rental/new", {"listing": str(lid), "rent": "800", "date": "2026-11-01", "status": "confirmed"}, page="/admin/rental/new")
        await admin.post("/admin/rental/1/note", {"kind": "objection", "body": "المالك يعترض: العميل لم يحضر"}, page="/admin/rental/1")
        await admin.post("/admin/rental/1/note", {"kind": "payment", "body": "حوالة بنكية جزئية 40"}, page="/admin/rental/1")
        await admin.post("/admin/rental/1/note", {"kind": "evil", "body": "x"}, page="/admin/rental/1")
        await admin.post("/admin/rental/1/note", {"kind": "note", "body": "   "}, page="/admin/rental/1")
        await admin.get("/admin/rental/1")
        self.assertIn("اعتراض", admin.text)
        self.assertIn("العميل لم يحضر", admin.text)
        self.assertIn("حوالة بنكية", admin.text)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM rental_notes")["n"], 2)

    async def test_the_due_days_setting(self):
        admin, owner, lid = await self.prepared()
        await admin.post("/admin/due", {"days": "30"}, page="/admin/settings")
        await admin.post("/admin/rental/new", {"listing": str(lid), "rent": "500", "date": "2026-11-01", "status": "confirmed"}, page="/admin/rental/new")
        self.assertEqual(self.db.one("SELECT due_date FROM rentals")["due_date"], "2026-12-01")


class ListsAndOffersTests(Case):
    async def test_cities_types_and_facilities(self):
        admin = await self.make_admin()
        await admin.post("/admin/lookup/cities", {"name": "  المجمعة  "}, page="/admin/settings")
        self.assertIsNotNone(self.db.one("SELECT 1 FROM cities WHERE name = 'المجمعة'"))
        await admin.post("/admin/lookup/cities", {"name": "المجمعة"}, page="/admin/settings")
        self.assertIn("موجود", await admin.message())
        await admin.post("/admin/lookup/amenities", {"name": "جلسة خارجية"}, page="/admin/settings")
        await admin.post("/admin/lookup/categories", {"name": "مخيم شتوي"}, page="/admin/settings")
        cid = self.db.one("SELECT id FROM cities WHERE name = 'المجمعة'")["id"]
        await admin.post(f"/admin/lookup/cities/{cid}/toggle", page="/admin/settings")
        await self.visitor.get("/")
        self.assertNotIn("المجمعة", self.visitor.text)                                        # a hidden city leaves the search box
        owner = await self.make_owner()
        await owner.get("/owner/new")
        await owner.post("/owner/new", {"agree": "1", "version": "1", "bp": "1000"})
        await owner.get(owner.location)
        self.assertNotIn("المجمعة", owner.text)
        self.assertIn("جلسة خارجية", owner.text)

    async def test_offers(self):
        admin = await self.make_admin()
        owner = await self.make_owner()
        lid = await self.add_listing(owner, price="1000")
        self.approve(lid)
        r = await admin.post("/admin/offers", {"title": "خصم الخريف", "percent": "25", "city": "", "category": "", "listing": str(lid), "starts": "2026-10-01", "ends": "2026-12-31"}, page="/admin/offers")
        self.assertEqual(r.status, 303)
        await self.visitor.get(f"/r/{lid}")
        self.assertIn("خصم 25%", self.visitor.text)
        self.assertIn("750", self.visitor.text)
        for bad in ({"title": "x", "percent": "25"}, {"title": "خصم", "percent": "95"}, {"title": "خصم", "percent": "10", "starts": "2026-12-01", "ends": "2026-11-01"},
                    {"title": "خصم", "percent": "10", "listing": "9999"}):
            await admin.post("/admin/offers", {"city": "", "category": "", "listing": "", "starts": "2026-10-01", "ends": "2026-12-31", **bad}, page="/admin/offers")
            self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM offers")["n"], 1, bad)
        await admin.post("/admin/offer/1/toggle", page="/admin/offers")
        await self.visitor.get(f"/r/{lid}")
        self.assertNotIn("خصم 25%", self.visitor.text)
        await admin.post("/admin/offer/1/delete", page="/admin/offers")
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM offers")["n"], 0)


class AuditLabelTests(Case):
    async def test_the_latest_operations_are_shown_in_arabic(self):
        admin = await self.make_admin()
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        await admin.post(f"/admin/listing/{lid}/approve", page=f"/admin/listing/{lid}")
        self.db.audit(None, "some_future_action", "x")
        await admin.get("/admin")
        self.assertIn("اعتماد إعلان", admin.text)
        self.assertIn("دخول المدير", admin.text)
        self.assertNotIn("listing_approve", admin.text)
        self.assertNotIn("admin_login", admin.text)
        self.assertIn("some_future_action", admin.text)           # an unknown key is shown as it is, never hidden or a crash

    def test_every_recorded_action_has_a_label(self):
        import pathlib
        from istiraha import repo
        source = "\n".join(p.read_text(encoding="utf-8") for p in pathlib.Path("istiraha").glob("*.py"))
        plain = set(re.findall(r'\.audit\([^,()]+(?:\[[^\]]*\])?,\s*"([a-z_]+)"', source))
        self.assertTrue({"admin_login", "commission", "rental_new", "owner_password", "lockout"} <= plain, plain)
        built = {a + "_owner" for a in ("block", "unblock")} | {f"listing_{a}" for a in ("approve", "reject", "stop", "feature")} \
            | {f"add_{k}" for k in ("cities", "categories", "amenities")}
        for key in plain | built:
            self.assertIn(key, repo.AUDIT_LABELS, key)
        for label in repo.AUDIT_LABELS.values():
            self.assertTrue(re.search(r"[؀-ۿ]", label), label)
