"""A test browser: it talks to the application directly (no network), keeps cookies and finds the form check token."""
import asyncio
import re
import struct
import tempfile
import unittest
import zlib
from pathlib import Path
from urllib.parse import urlencode

from istiraha import security
from istiraha.app import App
from istiraha.db import Database
from istiraha.server import Request, Response, parse_cookies
from istiraha.settings import Settings

NOW = 1_793_000_000.0            # 2026-10-26 about 14:00 in Riyadh


class Clock:
    def __init__(self, start: float = NOW):
        self.t = start

    def __call__(self) -> float:
        return self.t


def make_app(**overrides):
    tmp = tempfile.TemporaryDirectory()
    settings = Settings(data_dir=Path(tmp.name), site_url="https://rest.example", cookie_secure=True, **overrides)
    clock = Clock()
    db = Database(":memory:", clock=clock)
    app = App(settings, db, clock=clock)
    app._tmp = tmp
    return app, clock


class Client:
    def __init__(self, app, ip="203.0.113.7"):
        self.app, self.ip, self.jar, self.last = app, ip, {}, None

    async def go(self, method, path, form=None, files=None, headers=None, query=None, raw=None):
        if "?" in path:
            from urllib.parse import parse_qs
            path, _, qs = path.partition("?")
            query = {**{k: v for k, v in parse_qs(qs).items()}, **(query or {})}
        headers = {"host": "rest.example", "user-agent": "test-browser", **(headers or {})}
        body = b""
        if raw is not None:
            body = raw
        elif files:
            boundary = "----testboundary"
            parts = []
            for k, v in (form or {}).items():
                for item in (v if isinstance(v, list) else [v]):
                    parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{item}\r\n'.encode())
            for name, filename, content in files:
                parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"; filename="{filename}"\r\nContent-Type: application/octet-stream\r\n\r\n'.encode() + content + b"\r\n")
            body = b"".join(parts) + f"--{boundary}--\r\n".encode()
            headers["content-type"] = f"multipart/form-data; boundary={boundary}"
        elif form is not None:
            body = urlencode([(k, x) for k, v in form.items() for x in (v if isinstance(v, list) else [v])]).encode()
            headers["content-type"] = "application/x-www-form-urlencoded"
        if self.jar:
            headers["cookie"] = "; ".join(f"{k}={v}" for k, v in self.jar.items())
        pairs = {}
        multi = {}
        for k, v in (query or {}).items():
            for item in (v if isinstance(v, list) else [v]):
                multi.setdefault(k, []).append(str(item))
        pairs = {k: v[0] for k, v in multi.items()}
        request = Request(method, path, pairs, headers, self.ip, body, parse_cookies(headers.get("cookie", "")))
        request._query_pairs = multi
        response = await self.app.handle(request)
        for line in response.cookies:
            name, _, rest = line.partition("=")
            value = rest.split(";")[0]
            if "Max-Age=0" in line:
                self.jar.pop(name, None)
            else:
                self.jar[name] = value
        self.last = response
        return response

    async def get(self, path, **query):
        return await self.go("GET", path, query=query)

    def csrf(self, html=None):
        text = html if html is not None else self.last.body.decode()
        m = re.search(r'name="_csrf" value="([^"]+)"', text)
        assert m, "no form check token on the page"
        return m.group(1)

    async def post(self, path, form=None, page=None, **kw):
        """POST with the token found on `page` (a path to open first) or on the last page."""
        if page:
            await self.get(page)
        token = self.csrf()
        return await self.go("POST", path, {**(form or {}), "_csrf": token}, **kw)

    async def message(self):
        """The one-time message the last redirect leaves on the page it points to."""
        import html as _h
        await self.get(self.last.headers["Location"])
        m = re.search(r'<p class="note ok" role="status">([^<]*)</p>', self.text)
        return _h.unescape(m.group(1)) if m else ""

    @property
    def text(self):
        return self.last.body.decode()

    @property
    def location(self):
        from urllib.parse import unquote
        return unquote(self.last.headers.get("Location", ""))


def run(coro):
    return asyncio.run(coro)


class Case(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.app, self.clock = make_app()
        self.db = self.app.db
        self.addCleanup(self.db.close)
        self.addCleanup(self.app._tmp.cleanup)
        self.visitor = Client(self.app)

    async def make_admin(self, login="manager", password="Str0ng-pass!"):
        self.db.run("INSERT INTO users(role, login, name, pass_hash, created_at) VALUES ('admin', ?, ?, ?, ?)", (login, login, security.hash_password(password), NOW))
        client = Client(self.app, "198.51.100.9")
        await client.get("/admin/login")
        response = await client.post("/admin/login", {"login": login, "password": password})
        assert response.status == 303 and response.headers["Location"] == "/admin", response.body[:200]
        return client

    async def make_owner(self, phone="0551234567", name="أبو سعد", password="Owner-pass-1", ip="203.0.113.50"):
        client = Client(self.app, ip)
        await client.get("/owner/register")
        response = await client.post("/owner/register", {"name": name, "phone": phone, "password": password, "website": ""})
        assert response.status == 303, client.text[:300]
        return client

    async def add_listing(self, owner, title="استراحة النخيل", city=1, category=1, price="800", unit="night", whatsapp="0551234567", amenities=(1, 2), **extra):
        await owner.get("/owner/new")
        response = await owner.post("/owner/new", {"agree": "1", "version": str(self.db.pledge()["version"]), "bp": str(self.db.commission_bp())})
        assert response.status == 303, owner.text[:300]
        action = owner.location
        await owner.get(action)
        form = {"title": title, "city": str(city), "category": str(category), "price": price, "unit": unit, "whatsapp": whatsapp,
                "district": "حي الياسمين", "description": "استراحة هادئة مع مسبح كبير.", "amenities": [str(a) for a in amenities], **extra}
        response = await owner.post(action, form)
        assert response.status == 303, owner.text[:600]
        return int(re.search(r"/owner/listing/(\d+)", owner.location).group(1))

    def approve(self, lid):
        self.db.run("UPDATE listings SET review='approved', approved_at=? WHERE id=?", (NOW, lid))


def fake_jpeg(width=800, height=600, exif=b"Exif\x00\x00GPS-LAT-24.7136N-LONG-46.6753E"):
    """A structurally valid JPEG (headers + a few bytes of data), carrying fake camera and position data."""
    app1 = b"\xff\xe1" + struct.pack(">H", len(exif) + 2) + exif
    app0 = b"\xff\xe0" + struct.pack(">H", 16) + b"JFIF\x00\x01\x01\x00\x00\x01\x00\x01\x00\x00"
    sof = b"\xff\xc0" + struct.pack(">HBHHB", 11, 8, height, width, 1) + b"\x01\x11\x00"
    sos = b"\xff\xda" + struct.pack(">HB", 8, 1) + b"\x01\x00\x00\x3f\x00"
    return b"\xff\xd8" + app0 + app1 + b"\xff\xfe\x00\x07hello" + sof + sos + b"\x12\x34\x56\x78" + b"\xff\xd9"


def fake_png(width=640, height=480, text=b"secret"):
    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)) + chunk(b"tEXt", b"Comment\x00" + text)
            + chunk(b"IDAT", zlib.compress(b"\x00" * 10)) + chunk(b"IEND", b""))
