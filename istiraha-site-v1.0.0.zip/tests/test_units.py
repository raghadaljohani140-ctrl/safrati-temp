import unittest
from decimal import Decimal

from istiraha import images, security, util
from istiraha.settings import ConfigError, load_settings
from tests.helpers import fake_jpeg, fake_png


class MoneyTests(unittest.TestCase):
    def test_the_example_from_the_brief(self):
        self.assertEqual(util.commission(500, 1000), Decimal("50.00"))
        self.assertEqual(util.money(util.to_halalas(util.commission(500, 1000))), "50")

    def test_other_rates_and_rounding(self):
        self.assertEqual(util.commission(500, 500), Decimal("25.00"))
        self.assertEqual(util.commission(500, 1500), Decimal("75.00"))
        self.assertEqual(util.commission(333, 750), Decimal("24.98"))          # 24.975 rounds up to the halala
        self.assertEqual(util.commission(1000, 0), Decimal("0.00"))
        self.assertEqual(util.money(2498), "24.98")
        self.assertEqual(util.money(123456700), "1,234,567")

    def test_percent_parsing(self):
        for text, bp in (("10", 1000), ("5", 500), ("7.5", 750), ("٧٫٥", 750), ("15%", 1500), ("0", 0), ("100", 10000), ("12.25", 1225)):
            self.assertEqual(util.parse_percent(text), bp, text)
        for bad in ("", "abc", "101", "-5", "10.555", "1e2", "٪"):
            self.assertIsNone(util.parse_percent(bad), bad)
        self.assertEqual(util.percent_text(1000), "10")
        self.assertEqual(util.percent_text(750), "7.5")
        self.assertEqual(util.percent_text(1225), "12.25")


class PhoneTests(unittest.TestCase):
    def test_saudi_numbers_in_every_usual_writing(self):
        for text in ("0551234567", "551234567", "+966551234567", "966551234567", "00966551234567", "٠٥٥١٢٣٤٥٦٧", "055 123 4567", "055-123-4567"):
            self.assertEqual(util.normalize_phone(text), "966551234567", text)
        for bad in ("", "0451234567", "05512345", "05512345678", "abc", "+971551234567", "0155123456"):
            self.assertIsNone(util.normalize_phone(bad), bad)
        self.assertEqual(util.show_phone("966551234567"), "0551234567")

    def test_the_whatsapp_link(self):
        link = util.whatsapp_link("966551234567", "استراحة النخيل", "https://rest.example/r/7")
        self.assertTrue(link.startswith("https://wa.me/966551234567?text="))
        from urllib.parse import parse_qs, urlsplit
        text = parse_qs(urlsplit(link).query)["text"][0]
        self.assertIn("السلام عليكم، أرغب بالاستفسار عن استراحتكم المنشورة في المنصة", text)
        self.assertIn("وهل هي متاحة في التاريخ المطلوب؟", text)
        self.assertIn("استراحة النخيل", text)
        self.assertIn("https://rest.example/r/7", text)
        self.assertNotIn(" ", link)
        self.assertNotIn("\n", link)
        self.assertNotIn("&", link.split("?", 1)[1].replace("%26", ""))

    def test_a_title_cannot_break_out_of_the_link(self):
        link = util.whatsapp_link("966551234567", "x&phone=1#<script>", "")
        self.assertEqual(link.count("?"), 1)
        self.assertNotIn("#", link)
        self.assertNotIn("<", link)


class PasswordTests(unittest.TestCase):
    def test_hash_and_check(self):
        stored = security.hash_password("Correct-Horse-9")
        self.assertTrue(stored.startswith("scrypt$"))
        self.assertNotIn("Correct", stored)
        self.assertTrue(security.check_password("Correct-Horse-9", stored))
        self.assertFalse(security.check_password("correct-horse-9", stored))
        self.assertFalse(security.check_password("x", "garbage"))
        self.assertNotEqual(stored, security.hash_password("Correct-Horse-9"))          # a new salt each time

    def test_weak_passwords_are_refused(self):
        for bad in ("short1", "12345678", "password", "aaaaaaaa", ""):
            self.assertIsNotNone(security.password_problem(bad), bad)
        self.assertIsNone(security.password_problem("Owner-pass-1"))

    def test_limiter(self):
        t = [0.0]
        limit = security.Limiter(3, 60.0, clock=lambda: t[0])
        self.assertEqual([limit.allow("a") for _ in range(4)], [True, True, True, False])
        self.assertTrue(limit.allow("b"))
        t[0] = 61
        self.assertTrue(limit.allow("a"))


class ImageTests(unittest.TestCase):
    def test_jpeg_loses_its_position_data_but_stays_a_picture(self):
        kind, out, w, h = images.clean(fake_jpeg(), 5_000_000)
        self.assertEqual((kind, w, h), ("jpg", 800, 600))
        self.assertNotIn(b"GPS", out)
        self.assertNotIn(b"Exif", out)
        self.assertNotIn(b"hello", out)
        self.assertTrue(out.startswith(b"\xff\xd8\xff\xe0") and out.endswith(b"\xff\xd9"))
        self.assertIn(b"\x12\x34\x56\x78", out)

    def test_png_text_chunks_are_dropped(self):
        kind, out, w, h = images.clean(fake_png(), 5_000_000)
        self.assertEqual((kind, w, h), ("png", 640, 480))
        self.assertNotIn(b"secret", out)
        self.assertTrue(out.endswith(b"IEND\xaeB`\x82"))

    def test_refused_files(self):
        for data, why in ((b"", "empty"), (b"GIF89a....", "gif"), (b"<html><script>", "html"), (b"%PDF-1.4", "pdf"),
                          (b"\xff\xd8\xff", "cut jpeg"), (fake_jpeg(10, 10), "tiny"), (fake_jpeg(20000, 100), "huge"), (b"\x89PNG\r\n\x1a\n", "cut png")):
            with self.assertRaises(images.ImageError, msg=why):
                images.clean(data, 5_000_000)

    def test_size_limit(self):
        with self.assertRaises(images.ImageError):
            images.clean(fake_jpeg() + b"\x00" * 2000, 1000)


class SettingsTests(unittest.TestCase):
    def test_defaults_and_values(self):
        s = load_settings({})
        self.assertEqual((s.port, s.site_name, s.cookie_secure), (8090, "استراحتي", False))
        s = load_settings({"SITE_URL": "https://rest.example/", "PORT": "9000", "SITE_NAME": "مثال"})
        self.assertEqual((s.site_url, s.port, s.site_name, s.cookie_secure), ("https://rest.example", 9000, "مثال", True))

    def test_bad_values_are_refused(self):
        for env in ({"SITE_URL": "javascript:alert(1)"}, {"SITE_URL": "rest.example"}, {"PORT": "abc"}, {"PORT": "99999"}, {"LOG_LEVEL": "LOUD"}, {"MAX_UPLOAD_MB": "0"}):
            with self.assertRaises(ConfigError, msg=str(env)):
                load_settings(env)


if __name__ == "__main__":
    unittest.main()
