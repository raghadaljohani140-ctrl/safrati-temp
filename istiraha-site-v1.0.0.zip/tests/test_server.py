"""The real HTTP server on a real port: what a browser (or an attacker) actually sends over the wire."""
import asyncio
import http.client
import re
import socket
import tempfile
import unittest
from pathlib import Path

from istiraha import security
from istiraha.app import App
from istiraha.db import Database
from istiraha.server import WebServer
from istiraha.settings import Settings
from tests.helpers import fake_jpeg


class Running:
    async def __aenter__(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.settings = Settings(data_dir=Path(self.tmp.name), site_url="https://rest.example", cookie_secure=True)
        self.db = Database(self.settings.db_path)
        self.app = App(self.settings, self.db)
        self.server = WebServer(self.app.handle, body_limit=self.app.body_limit, per_minute=6000, post_per_minute=6000)
        self.port = await self.server.start("127.0.0.1", 0)
        return self

    async def __aexit__(self, *exc):
        await self.server.close()
        self.db.close()
        self.tmp.cleanup()

    async def http(self, method, path, body=None, headers=None):
        def work():
            conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=10)
            conn.request(method, path, body=body, headers=headers or {})
            response = conn.getresponse()
            data = response.read()
            result = (response.status, response.getheaders(), data)
            conn.close()
            return result
        return await asyncio.to_thread(work)

    async def raw(self, payload: bytes, wait=True) -> bytes:
        def work():
            s = socket.create_connection(("127.0.0.1", self.port), timeout=5)
            s.sendall(payload)
            chunks = []
            try:
                while True:
                    data = s.recv(65536)
                    if not data:
                        break
                    chunks.append(data)
            except socket.timeout:
                pass
            s.close()
            return b"".join(chunks)
        return await asyncio.to_thread(work)


def header(headers, name):
    return [v for k, v in headers if k.lower() == name.lower()]


class WireTests(unittest.IsolatedAsyncioTestCase):
    async def test_a_page_comes_with_the_safety_headers(self):
        async with Running() as site:
            status, headers, body = await site.http("GET", "/")
            self.assertEqual(status, 200)
            csp = header(headers, "Content-Security-Policy")[0]
            self.assertIn("default-src 'none'", csp)
            self.assertIn("script-src 'self'", csp)
            self.assertNotIn("unsafe-inline", csp)
            self.assertNotIn("unsafe-eval", csp)
            self.assertIn("frame-ancestors 'none'", csp)
            self.assertEqual(header(headers, "X-Content-Type-Options"), ["nosniff"])
            self.assertEqual(header(headers, "X-Frame-Options"), ["DENY"])
            self.assertEqual(header(headers, "Connection"), ["close"])
            self.assertIn("ist_c=", header(headers, "Set-Cookie")[0])
            self.assertIn("HttpOnly", header(headers, "Set-Cookie")[0])
            self.assertIn("charset=utf-8", header(headers, "Content-Type")[0])
            self.assertIn("استراحتي".encode(), body)

    async def test_gzip_and_head(self):
        async with Running() as site:
            status, headers, body = await site.http("GET", "/static/app.css", headers={"Accept-Encoding": "gzip"})
            self.assertEqual(header(headers, "Content-Encoding"), ["gzip"])
            import gzip
            self.assertIn(b"--pool", gzip.decompress(body))
            status, headers, body = await site.http("HEAD", "/")
            self.assertEqual((status, body), (200, b""))
            self.assertGreater(int(header(headers, "Content-Length")[0]), 100)

    async def test_the_whole_owner_journey_over_real_http(self):
        async with Running() as site:
            def cookies(headers, jar):
                for line in header(headers, "Set-Cookie"):
                    name, _, rest = line.partition("=")
                    jar[name] = rest.split(";")[0]
                return "; ".join(f"{k}={v}" for k, v in jar.items())
            jar: dict[str, str] = {}
            status, headers, body = await site.http("GET", "/owner/register")
            cookie = cookies(headers, jar)
            token = re.search(rb'name="_csrf" value="([^"]+)"', body).group(1).decode()
            form = "name=%D8%A3%D8%A8%D9%88+%D8%B3%D8%B9%D8%AF&phone=0551234567&password=Owner-pass-1&website=&_csrf=" + token
            status, headers, _ = await site.http("POST", "/owner/register", form, {"Content-Type": "application/x-www-form-urlencoded", "Cookie": cookie, "Origin": "https://rest.example", "Host": "rest.example"})
            self.assertEqual((status, header(headers, "Location")), (303, ["/owner/new"]))
            cookie = cookies(headers, jar)
            self.assertIn("ist_o=", cookie)
            status, headers, body = await site.http("GET", "/owner/new", headers={"Cookie": cookie})
            self.assertEqual(status, 200)
            self.assertIn("نسبة العمولة الحالية".encode(), body)
            token = re.search(rb'name="_csrf" value="([^"]+)"', body).group(1).decode()
            # a real multipart upload of a picture over the wire
            status, headers, _ = await site.http("POST", "/owner/new", f"agree=1&version=1&bp=1000&_csrf={token}", {"Content-Type": "application/x-www-form-urlencoded", "Cookie": cookie})
            action = header(headers, "Location")[0]
            status, headers, body = await site.http("GET", action, headers={"Cookie": cookie})
            token = re.search(rb'name="_csrf" value="([^"]+)"', body).group(1).decode()
            fields = "title=%D8%A7%D8%B3%D8%AA%D8%B1%D8%A7%D8%AD%D8%A9+%D8%A7%D9%84%D9%86%D8%AE%D9%8A%D9%84&city=1&category=1&price=800&unit=night&whatsapp=0551234567&_csrf=" + token
            status, headers, _ = await site.http("POST", action, fields, {"Content-Type": "application/x-www-form-urlencoded", "Cookie": cookie})
            self.assertEqual(status, 303)
            lid = int(re.search(r"/owner/listing/(\d+)", header(headers, "Location")[0]).group(1))
            status, headers, body = await site.http("GET", f"/owner/listing/{lid}", headers={"Cookie": cookie})
            token = re.search(rb'name="_csrf" value="([^"]+)"', body).group(1).decode()
            boundary = "XyZ123"
            payload = (f'--{boundary}\r\nContent-Disposition: form-data; name="_csrf"\r\n\r\n{token}\r\n'
                       f'--{boundary}\r\nContent-Disposition: form-data; name="photo"; filename="a.jpg"\r\nContent-Type: image/jpeg\r\n\r\n').encode() + fake_jpeg() + f"\r\n--{boundary}--\r\n".encode()
            status, headers, _ = await site.http("POST", f"/owner/listing/{lid}/photo", payload, {"Content-Type": f"multipart/form-data; boundary={boundary}", "Cookie": cookie})
            self.assertEqual(status, 303)
            name = site.db.one("SELECT filename FROM photos")["filename"]
            site.db.run("UPDATE listings SET review = 'approved'")
            status, headers, body = await site.http("GET", f"/media/{name}")
            self.assertEqual((status, header(headers, "Content-Type")), (200, ["image/jpeg"]))
            self.assertNotIn(b"GPS", body)
            status, _, body = await site.http("GET", f"/r/{lid}")
            self.assertEqual(status, 200)
            self.assertIn(b"wa.me/966551234567", body)

    async def test_bodies_must_declare_their_size_and_stay_small(self):
        async with Running() as site:
            head = b"POST /owner/login HTTP/1.1\r\nHost: x\r\nContent-Type: application/x-www-form-urlencoded\r\n"
            self.assertIn(b"411", (await site.raw(head + b"\r\n"))[:20])
            self.assertIn(b"411", (await site.raw(head + b"Transfer-Encoding: chunked\r\n\r\n0\r\n\r\n"))[:20])
            self.assertIn(b"413", (await site.raw(head + b"Content-Length: 99999999\r\n\r\n"))[:20])
            self.assertIn(b"413", (await site.raw(b"POST /owner/listing/1/photo HTTP/1.1\r\nHost: x\r\nContent-Length: 99999999\r\n\r\n"))[:20])
            self.assertIn(b"411", (await site.raw(head + b"Content-Length: abc\r\n\r\n"))[:20])

    async def test_broken_requests_get_a_clean_refusal(self):
        async with Running() as site:
            for payload, code in ((b"GARBAGE\r\n\r\n", b"400"), (b"GET / HTTP/2\r\n\r\n", b"400"), (b"GET //evil.example/ HTTP/1.1\r\n\r\n", b"400"),
                                  (b"GET /a/../b HTTP/1.1\r\n\r\n", b"400"), (b"GET /%00 HTTP/1.1\r\n\r\n", b"400"), (b"DELETE / HTTP/1.1\r\n\r\n", b"405"),
                                  (b"GET / HTTP/1.1\r\nBad Header\r\n\r\n", b"400"), (b"GET /" + b"a" * 3000 + b" HTTP/1.1\r\n\r\n", b"400"),
                                  (b"GET / HTTP/1.1\r\nX: " + b"a" * 20000 + b"\r\n\r\n", b"431")):
                answer = await site.raw(payload)
                self.assertIn(code, answer[:15], payload[:40])
            status, _, _ = await site.http("GET", "/")                                  # and the server is still fine
            self.assertEqual(status, 200)

    async def test_the_address_header_is_used_only_when_configured(self):
        async with Running() as site:
            for i in range(3):
                await site.http("GET", "/owner/login", headers={"X-Forwarded-For": f"1.1.1.{i}"})
            self.assertEqual(site.server.stats["limited"], 0)

    async def test_the_visitor_cannot_write_into_the_log(self):
        async with Running() as site:
            with self.assertLogs("istiraha", level="DEBUG") as logs:
                await site.http("GET", "/search?district=%0aFAKE-LINE")
                await site.http("GET", "/x%0aINJECTED")
            joined = "\n".join(logs.output)
            self.assertNotIn("FAKE-LINE", joined)
            self.assertNotIn("INJECTED", joined)


class RateLimitTests(unittest.IsolatedAsyncioTestCase):
    async def test_too_many_requests_get_429(self):
        async with Running() as site:
            from istiraha.server import RateLimiter
            site.server._get_limit = RateLimiter(60, burst=5)
            codes = [(await site.http("GET", "/healthz"))[0] for _ in range(9)]
            self.assertEqual(codes[:5], [200] * 5)
            self.assertIn(429, codes[5:])


if __name__ == "__main__":
    unittest.main()
