#!/usr/bin/env bash
# Stops and removes ONLY the rest-house website containers (the website and, if switched on, its tunnel) and the
# project's network.
#   bash uninstall.sh            keep the data (owners, adverts, pictures, pledges)
#   bash uninstall.sh --purge    ALSO delete the data volume and the image. This erases every advert, picture and
#                                saved pledge. It asks you to type the word DELETE first. Make a backup before.
# The folder /opt/istiraha-site, its .env and its backups stay; delete the folder yourself if you want it gone.
# The public cloudflared image that the tunnel downloaded is left alone (other projects may use it).
set -euo pipefail
[ "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" = "/opt/istiraha-site" ] || { echo "ERROR: run from /opt/istiraha-site" >&2; exit 1; }
cd /opt/istiraha-site
[ -f .tunnel.env ] || : > .tunnel.env
case "${1:-}" in
  "")
    docker compose -p istiraha --profile quick --profile domain down ;;
  --purge)
    echo "This will ERASE all the website's data (owners, adverts, pictures, pledges)."
    read -r -p "Type DELETE to continue: " answer || exit 1
    [ "$answer" = "DELETE" ] || { echo "cancelled. Nothing was deleted."; exit 1; }
    docker compose -p istiraha --profile quick --profile domain down --volumes
    docker rmi istiraha-site:local >/dev/null 2>&1 || true ;;
  *)
    echo "usage: bash uninstall.sh [--purge]" >&2; exit 1 ;;
esac
rm -f .state
echo "The rest-house website was removed. Other projects were not touched."
