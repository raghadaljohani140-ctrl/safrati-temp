"""python -m istiraha [serve | check | create-admin | export | import --force | version]"""
from __future__ import annotations

import argparse
import asyncio
import getpass
import logging
import re
import signal
import sqlite3
import sys
import time
import urllib.request

from . import __version__, security
from .app import App
from .db import Database
from .server import WebServer
from .settings import ConfigError, load_settings


def _serve(settings) -> int:
    logging.basicConfig(level=getattr(logging, settings.log_level), format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    db = Database(settings.db_path)
    settings.uploads_dir.mkdir(parents=True, exist_ok=True)
    app = App(settings, db)
    server = WebServer(app.handle, real_ip_header=settings.real_ip_header, body_limit=app.body_limit)

    async def run() -> None:
        port = await server.start(settings.host, settings.port)
        logging.getLogger("istiraha").info("website started on port %d (version %s)", port, __version__)
        stop = asyncio.Event()
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(sig, stop.set)
        await stop.wait()
        await server.close()

    asyncio.run(run())
    db.close()
    return 0


def _check(settings) -> int:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{settings.port}/healthz", timeout=5) as response:
            return 0 if response.status == 200 and response.read() == b"ok" else 1
    except Exception:      # noqa: BLE001
        return 1


def _create_admin(settings) -> int:
    login = input("اسم المستخدم للإدارة (حروف إنجليزية وأرقام): ").strip().lower()
    if not re.fullmatch(r"[a-z][a-z0-9_.-]{2,30}", login):
        print("اسم غير صالح: 3 إلى 31 خانة، يبدأ بحرف إنجليزي.")
        return 2
    password = getpass.getpass("كلمة المرور (لن تظهر أثناء الكتابة): ")
    if password != getpass.getpass("أعد كتابتها: "):
        print("الكلمتان غير متطابقتين.")
        return 2
    problem = security.password_problem(password)
    if problem:
        print(problem)
        return 2
    db = Database(settings.db_path)
    import time
    existing = db.one("SELECT role FROM users WHERE login = ?", (login,))
    if existing and existing["role"] != "admin":
        print("هذا الاسم مستخدم لحساب آخر، اختر اسمًا غيره.")
        db.close()
        return 2
    if existing:
        db.run("UPDATE users SET pass_hash = ?, status = 'active', failed = 0, locked_until = 0 WHERE login = ? AND role = 'admin'", (security.hash_password(password), login))
        db.run("DELETE FROM sessions WHERE user_id = (SELECT id FROM users WHERE login = ?)", (login,))
        print("تم تحديث كلمة مرور هذا المدير وإنهاء جلساته القديمة.")
    else:
        db.run("INSERT INTO users(role, login, name, pass_hash, created_at) VALUES ('admin', ?, ?, ?, ?)", (login, login, security.hash_password(password), time.time()))
        print("تم إنشاء حساب المدير.")
    db.close()
    return 0


MAX_PICTURE = 30 * 1024 * 1024
_PICTURE_NAME = re.compile(r"uploads/[A-Za-z0-9][A-Za-z0-9._-]{0,80}")


def _export(settings, out=None) -> int:
    """Everything the site keeps (the database and the pictures) as one .tar.gz written to standard output.
    The database is copied with SQLite's own backup call, so the copy is consistent while the site is running."""
    import os
    import tarfile
    import tempfile
    out = out or sys.stdout.buffer
    with tempfile.TemporaryDirectory() as tmp:
        snapshot = os.path.join(tmp, "istiraha.db")
        source = sqlite3.connect(settings.db_path)
        dest = sqlite3.connect(snapshot)
        with dest:
            source.backup(dest)
        source.close()
        dest.close()
        with tarfile.open(fileobj=out, mode="w|gz") as tar:
            tar.add(snapshot, arcname="istiraha.db")
            if settings.uploads_dir.is_dir():
                for path in sorted(settings.uploads_dir.iterdir()):
                    if path.is_file() and not path.is_symlink():
                        tar.add(path, arcname=f"uploads/{path.name}")
    out.flush()
    return 0


def _import(settings, source=None, force: bool = False) -> int:
    """Put a copy made by `export` back. Nothing is deleted: the data that was there is kept next to it under a
    name ending in .before-restore. Only a plain database and plain picture files are accepted from the archive."""
    import os
    import shutil
    import tarfile
    import tempfile
    if not force:
        print("إعادة النسخة تستبدل بيانات الموقع الحالية. أضف --force للتأكيد.", file=sys.stderr)
        return 2
    source = source or sys.stdin.buffer
    data = settings.data_dir
    data.mkdir(parents=True, exist_ok=True)
    staging = tempfile.mkdtemp(prefix=".restore-", dir=data)
    try:
        seen_db = False
        with tarfile.open(fileobj=source, mode="r|gz") as tar:
            for member in tar:
                name = member.name
                if not member.isreg():
                    raise ValueError(f"unexpected entry in the archive: {name!r}")
                if name == "istiraha.db":
                    seen_db = True
                    target = os.path.join(staging, "istiraha.db")
                elif _PICTURE_NAME.fullmatch(name) and member.size <= MAX_PICTURE:
                    os.makedirs(os.path.join(staging, "uploads"), exist_ok=True)
                    target = os.path.join(staging, name)
                else:
                    raise ValueError(f"unexpected entry in the archive: {name!r}")
                handle = tar.extractfile(member)
                with open(target, "wb") as f:
                    shutil.copyfileobj(handle, f)
        if not seen_db:
            raise ValueError("the archive has no database")
        check = sqlite3.connect(os.path.join(staging, "istiraha.db"))
        try:
            if check.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise ValueError("the database in the archive is damaged")
            version = check.execute("PRAGMA user_version").fetchone()[0]
        finally:
            check.close()
        from .db import SCHEMA_VERSION
        if version > SCHEMA_VERSION:
            raise ValueError("the archive comes from a newer version of the site")
        stamp = time.strftime("%Y%m%d-%H%M%S")
        for leftover in ("istiraha.db-wal", "istiraha.db-shm"):
            path = data / leftover
            if path.exists():
                os.replace(path, data / f"{leftover}.{stamp}.before-restore")
        if settings.db_path.exists():
            os.replace(settings.db_path, data / f"istiraha.db.{stamp}.before-restore")
        if settings.uploads_dir.exists():
            os.replace(settings.uploads_dir, data / f"uploads.{stamp}.before-restore")
        os.replace(os.path.join(staging, "istiraha.db"), settings.db_path)
        if os.path.isdir(os.path.join(staging, "uploads")):
            os.replace(os.path.join(staging, "uploads"), settings.uploads_dir)
        else:
            settings.uploads_dir.mkdir(parents=True, exist_ok=True)
    except (ValueError, tarfile.TarError, sqlite3.Error, OSError) as exc:
        print(f"لم يتم تغيير شيء: {exc}", file=sys.stderr)
        return 1
    finally:
        shutil.rmtree(staging, ignore_errors=True)
    print("تمت إعادة النسخة. الأصل محفوظ بجانبها بامتداد before-restore.")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="istiraha")
    parser.add_argument("command", nargs="?", default="serve", choices=["serve", "check", "create-admin", "export", "import", "version"])
    parser.add_argument("--force", action="store_true", help="import only: replace the data that is there")
    args = parser.parse_args(argv)
    if args.command == "version":
        print(__version__)
        return 0
    try:
        settings = load_settings()
    except ConfigError as exc:
        print(f"settings error: {exc}", file=sys.stderr)
        return 2
    if args.command == "check":
        return _check(settings)
    if args.command == "create-admin":
        return _create_admin(settings)
    if args.command == "export":
        return _export(settings)
    if args.command == "import":
        return _import(settings, force=args.force)
    return _serve(settings)


if __name__ == "__main__":
    sys.exit(main())
