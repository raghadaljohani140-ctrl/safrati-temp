"""Checks an uploaded picture and removes what it should not carry (the phone's GPS position, camera data, comments).

Only JPEG, PNG and WebP are accepted, recognised by their bytes and not by the name the visitor gave.
The phone itself makes pictures smaller and clean before they are sent, so this is the second line of defence:
it must accept what real phones produce (extra pictures appended to a JPEG, a colour profile, a rotation flag,
a panorama) and still keep every private detail out of what is stored."""
from __future__ import annotations

import struct

MAX_SIDE = 32000
MAX_PIXELS = 144_000_000
MIN_SIDE = 80

UNREADABLE = "ملف الصورة تالف"
INCOMPLETE = "ملف الصورة ناقص (لم يكتمل رفعه)"


class ImageError(ValueError):
    pass


_HEIC_BRANDS = {b"heic", b"heix", b"hevc", b"hevx", b"heim", b"heis", b"hevm", b"hevs", b"mif1", b"msf1"}
_AVIF_BRANDS = {b"avif", b"avis"}


def detect(data: bytes) -> str | None:
    if data[:3] == b"\xff\xd8\xff":
        return "jpg"
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "webp"
    if data[4:8] == b"ftyp":                       # the photo formats of newer phones: recognised only to explain the refusal
        brand = data[8:12]
        if brand in _HEIC_BRANDS:
            return "heic"
        if brand in _AVIF_BRANDS:
            return "avif"
    return None


def _check_size(w: int, h: int) -> None:
    if w < MIN_SIDE or h < MIN_SIDE:
        raise ImageError("الصورة صغيرة جدًا، اختر صورة أكبر")
    if w > MAX_SIDE or h > MAX_SIDE or w * h > MAX_PIXELS:
        raise ImageError("مقاس الصورة كبير جدًا")


# ---- JPEG ----------------------------------------------------------------------------------------

_SOF_SHOWN = (0xC0, 0xC1, 0xC2)                 # baseline, extended and progressive: what every browser can show
_SOF_ALL = (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF)


def _exif_orientation(payload: bytes) -> int:
    """The rotation flag (1-8) from an EXIF block; 1 (no rotation) when it is missing or unreadable."""
    try:
        tiff = payload[6:]
        order = {b"II": "<", b"MM": ">"}.get(tiff[:2])
        if order is None or struct.unpack(order + "H", tiff[2:4])[0] != 42:
            return 1
        at = struct.unpack(order + "I", tiff[4:8])[0]
        count = struct.unpack(order + "H", tiff[at:at + 2])[0]
        for k in range(min(count, 100)):
            entry = tiff[at + 2 + 12 * k:at + 14 + 12 * k]
            tag, kind, amount = struct.unpack(order + "HHI", entry[:8])
            if tag == 0x0112 and kind == 3 and amount == 1:
                value = struct.unpack(order + "H", entry[8:10])[0]
                return value if 1 <= value <= 8 else 1
    except (struct.error, IndexError):
        pass
    return 1


def _orientation_block(value: int) -> bytes:
    """A tiny EXIF block that says only how the picture is turned: without it a phone picture taken upright shows on its side."""
    tiff = b"MM\x00\x2a\x00\x00\x00\x08" + struct.pack(">H", 1) + struct.pack(">HHIHH", 0x0112, 3, 1, value, 0) + b"\x00\x00\x00\x00"
    body = b"Exif\x00\x00" + tiff
    return b"\xff\xe1" + struct.pack(">H", len(body) + 2) + body


def _jpeg_keeps(marker: int, payload: bytes) -> bool:
    if marker == 0xE0:
        return payload.startswith(b"JFIF\x00")             # the plain header; the extension that may hold a small copy of the picture goes
    if marker == 0xE2:
        return payload.startswith(b"ICC_PROFILE\x00")      # the colour profile, so colours look as taken; the multi-picture index goes
    if marker == 0xEE:
        return payload.startswith(b"Adobe")                # the colour flag some files need to show right
    if 0xE1 <= marker <= 0xEF or marker == 0xFE:
        return False                                       # camera data, GPS position, Photoshop data, other makers' data, comments
    return True


def _clean_jpeg(data: bytes) -> tuple[bytes, int, int]:
    n = len(data)
    out = bytearray(b"\xff\xd8")
    i, size, scans, turned = 2, None, 0, False
    while True:
        if i + 2 > n:
            raise ImageError(INCOMPLETE)
        if data[i] != 0xFF:
            raise ImageError(UNREADABLE)
        marker = data[i + 1]
        if marker == 0xFF:                                  # filler bytes before a marker
            i += 1
            continue
        if marker == 0xD9:                                  # the end of the first picture: anything after it (a second picture, a trailer) is not kept
            if not scans:
                raise ImageError(UNREADABLE)
            out += b"\xff\xd9"
            break
        if marker == 0x00 or marker == 0x01 or 0xD0 <= marker <= 0xD8:
            raise ImageError(UNREADABLE)
        if i + 4 > n:
            raise ImageError(INCOMPLETE)
        length = struct.unpack(">H", data[i + 2:i + 4])[0]
        if length < 2:
            raise ImageError(UNREADABLE)
        if i + 2 + length > n:
            raise ImageError(INCOMPLETE)
        payload = data[i + 4:i + 2 + length]
        if marker in _SOF_ALL:
            if marker not in _SOF_SHOWN:
                raise ImageError("هذا النوع من ضغط JPEG غير مدعوم")
            if length < 8:
                raise ImageError(UNREADABLE)
            if size is None:
                h, w = struct.unpack(">HH", payload[1:5])
                size = (w, h)
        if marker == 0xE1 and payload.startswith(b"Exif\x00\x00"):
            rotation = 1 if turned else _exif_orientation(payload)
            if rotation > 1:
                out += _orientation_block(rotation)
                turned = True
        elif _jpeg_keeps(marker, payload):
            out += data[i:i + 2 + length]
        i += 2 + length
        if marker == 0xDA:                                  # the picture's own data follows: copied up to the next real marker
            j = i
            while True:
                k = data.find(b"\xff", j)
                if k == -1 or k + 1 >= n:
                    raise ImageError(INCOMPLETE)
                following = data[k + 1]
                if following == 0xFF:
                    j = k + 1
                elif following == 0x00 or 0xD0 <= following <= 0xD7:      # a stuffed byte or a restart marker belongs to the data
                    j = k + 2
                else:
                    break
            out += data[i:k]
            i = k
            scans += 1
    if size is None:
        raise ImageError(UNREADABLE)
    _check_size(*size)
    return bytes(out), size[0], size[1]


# ---- PNG -----------------------------------------------------------------------------------------

_PNG_KEEP = {b"IHDR", b"PLTE", b"IDAT", b"IEND", b"tRNS", b"gAMA", b"cHRM", b"sRGB", b"iCCP", b"sBIT", b"pHYs"}


def _clean_png(data: bytes) -> tuple[bytes, int, int]:
    out = bytearray(data[:8])
    i, size, ended = 8, None, False
    while i + 8 <= len(data):
        length, kind = struct.unpack(">I4s", data[i:i + 8])
        end = i + 12 + length
        if end > len(data):
            raise ImageError(INCOMPLETE)
        if kind == b"IHDR":
            if length != 13:
                raise ImageError(UNREADABLE)
            size = struct.unpack(">II", data[i + 8:i + 16])
        if kind in _PNG_KEEP:
            out += data[i:end]
        i = end
        if kind == b"IEND":
            ended = True
            break
    if size is None or not ended:
        raise ImageError(INCOMPLETE)
    _check_size(*size)
    return bytes(out), size[0], size[1]


# ---- WebP ----------------------------------------------------------------------------------------

def _clean_webp(data: bytes) -> tuple[bytes, int, int]:
    if len(data) < 20:
        raise ImageError(INCOMPLETE)
    declared = struct.unpack("<I", data[4:8])[0] + 8
    if declared > len(data) or declared < 20:
        raise ImageError(INCOMPLETE)
    body, i, size = bytearray(), 12, None
    while i + 8 <= declared:
        kind, length = data[i:i + 4], struct.unpack("<I", data[i + 4:i + 8])[0]
        end = i + 8 + length + (length & 1)
        if end > declared:
            raise ImageError(UNREADABLE)
        chunk = bytearray(data[i:end])
        payload = data[i + 8:i + 8 + length]
        if kind == b"VP8X" and length >= 10:
            chunk[8] &= ~0x0C                      # the flags for EXIF and XMP are cleared
            size = (int.from_bytes(payload[4:7], "little") + 1, int.from_bytes(payload[7:10], "little") + 1)
        elif kind == b"VP8 " and length >= 10 and payload[3:6] == b"\x9d\x01\x2a" and size is None:
            size = (struct.unpack("<H", payload[6:8])[0] & 0x3FFF, struct.unpack("<H", payload[8:10])[0] & 0x3FFF)
        elif kind == b"VP8L" and length >= 5 and payload[0] == 0x2F and size is None:
            bits = int.from_bytes(payload[1:5], "little")
            size = ((bits & 0x3FFF) + 1, ((bits >> 14) & 0x3FFF) + 1)
        if kind in (b"EXIF", b"XMP "):
            i = end
            continue
        body += chunk
        i = end
    if size is None:
        raise ImageError(UNREADABLE)
    _check_size(*size)
    cleaned = b"RIFF" + struct.pack("<I", len(body) + 4) + b"WEBP" + bytes(body)
    return cleaned, size[0], size[1]


def clean(data: bytes, max_bytes: int) -> tuple[str, bytes, int, int]:
    """(extension, cleaned bytes, width, height) or ImageError."""
    if not data:
        raise ImageError("ما وصلت صورة")
    if len(data) > max_bytes:
        raise ImageError(f"الصورة أكبر من {max_bytes // (1024 * 1024)} ميغابايت")
    kind = detect(data)
    if kind == "heic":
        raise ImageError("صورة بصيغة HEIC (صور الآيفون) وما نقدر نقرأها. اختر الصورة من مكتبة الصور مباشرة، "
                         "أو غيّر الإعدادات ← الكاميرا ← التنسيقات ← الأكثر توافقًا")
    if kind == "avif":
        raise ImageError("صيغة AVIF غير مدعومة، المسموح JPG أو PNG أو WebP")
    if kind is None:
        raise ImageError("نوع الملف غير مدعوم، المسموح JPG أو PNG أو WebP")
    cleaner = {"jpg": _clean_jpeg, "png": _clean_png, "webp": _clean_webp}[kind]
    try:
        cleaned, w, h = cleaner(data)
    except (struct.error, IndexError):
        raise ImageError(UNREADABLE) from None
    return kind, cleaned, w, h


CONTENT_TYPES = {"jpg": "image/jpeg", "png": "image/png", "webp": "image/webp"}
