"""Commission money. The owner's page «عمولاتي» (what he owes, how to pay, telling the manager he has paid) and the manager's side
(earnings, the reports to confirm, his bank details). No money moves through the site: the owner transfers from his own banking app."""
from __future__ import annotations

import re
from datetime import datetime

from . import payments, ui, util
from .app import Ctx, html_page, not_found, verify_login
from .server import redirect
from .ui import e, num
from .views_admin import table, tag

money = util.money


def _tag(state: str | None) -> str:
    """The commission's state as a coloured label (None: the rental was cancelled after the report)."""
    return tag(payments.STATE_KIND[state], payments.STATE_LABELS[state]) if state else tag("muted", "عملية ملغاة")


def _ids(values: list[str]) -> list[int]:
    return [int(v) for v in values if re.fullmatch(r"[0-9]{1,9}", v)][:payments.MAX_ITEMS + 1]


def _riyals(halalas: int) -> str:
    """An amount with its unit, for the big figures and the rows."""
    return f'{money(halalas)}<span class="u">ر.س</span>'


def _when(ts: float | None) -> str:
    """"27 أكتوبر 2026 · 21:35": the date in words, so the right-to-left page never shows its digits back to front."""
    if not ts:
        return "—"
    moment = datetime.fromtimestamp(ts, util.SAUDI_TZ)
    return f"{ui.day_text(moment.date().isoformat())} · {moment:%H:%M}"


def _tile(label: str, halalas: int, *, href: str = "", sub: str = "", kind: str = "") -> str:
    inner = f"<b>{_riyals(halalas)}</b><span>{e(label)}</span>" + (f"<small>{e(sub)}</small>" if sub else "")
    return f'<a class="stat {kind}" href="{href}">{inner}</a>' if href else f'<div class="stat {kind}">{inner}</div>'


def _row(r, state: str | None, mode: str, *, ticked: bool = True, href: str = "") -> str:
    """One rental's commission as a card. mode: "box" (a tick box, to report it), "link" (opens the rental) or "plain"."""
    lines = [f"إيجار {num(r['rent'])} ر.س · {ui.day_text(r['rental_date'])}"]
    lines.append(f"آخر موعد للسداد {ui.day_text(r['due_date'])}" if state in ("due", "late") else f"نسبة العمولة {util.percent_text(r['basis_points'])}%")
    if r["status"] == "pending":
        lines.append("العملية قيد التأكيد")
    details = "".join(f"<small>{e(x)}</small>" for x in lines)
    main = (f'<span class="com-main"><span class="com-top"><b>#{r["id"]} · {e(r["title"])}</b><b class="com-amt">{_riyals(r["commission_halalas"])}</b></span>'
            f'<span class="com-sub">{_tag(state)}</span>{details}</span>')
    if mode == "box":
        return (f'<label class="com-item pickable"><input type="checkbox" name="rental" value="{r["id"]}" data-h="{r["commission_halalas"]}"'
                f'{" checked" if ticked else ""}>{main}</label>')
    if mode == "link":
        return f'<a class="com-item" href="{e(href)}">{main}</a>'
    return f'<div class="com-item">{main}</div>'


def _list(items: list[str]) -> str:
    return '<ul class="com-list">' + "".join(f"<li>{i}</li>" for i in items) + "</ul>"


def _report_card(p, *, owner: str = "", href: str = "", extra: str = "") -> str:
    """One payment report as a card (the owner's history, the manager's waiting list)."""
    title = f"بلاغ #{p['id']}" + (f" · {e(owner)}" if owner else "")
    lines = [f"تحويل بتاريخ {ui.day_text(p['paid_on'])}"] + ([f"المرجع: {p['reference']}"] if p["reference"] else [])
    details = "".join(f"<small>{e(x)}</small>" for x in lines)
    box = "span" if href else "div"                 # a link may only hold inline pieces, while the owner's card holds a form (a block)
    main = (f'<{box} class="com-main"><span class="com-top"><b>{title}</b><b class="com-amt">{_riyals(p["amount_halalas"])}</b></span>'
            f'<span class="com-sub">{tag(payments.REPORT_KIND[p["status"]], payments.REPORT_LABELS[p["status"]])}</span>{details}{extra}</{box}>')
    return f'<a class="com-item" href="{e(href)}">{main}</a>' if href else f'<div class="com-item">{main}</div>'


def register(app) -> None:
    db = app.db

    # =============================================================== the owner: «عمولاتي»
    def _bank_box() -> str:
        d = payments.pay_details(db)
        contact = (f'<p><a class="btn ghost small" href="https://wa.me/{e(d["contact"])}" target="_blank" rel="noopener noreferrer">استفسار من الإدارة على واتساب</a></p>'
                   if d["contact"] else "")
        if not payments.has_bank(d):
            return ('<section class="panel"><h2>طريقة السداد</h2><p>لم تضف الإدارة بيانات الحساب بعد، وتظهر هنا فور إضافتها. '
                    f'تقدر تتواصل مع الإدارة للسداد.</p>{contact}</section>')
        note = f'<p>{e(d["note"])}</p>' if d["note"] else ""
        return f"""<section class="panel pay-box"><h2>طريقة السداد (تحويل بنكي)</h2>
<dl class="bank"><dt>اسم المستفيد</dt><dd>{e(d["holder"])}</dd><dt>البنك</dt><dd>{e(d["bank"])}</dd>
<dt>رقم الآيبان</dt><dd><span class="iban" dir="ltr">{e(payments.show_iban(d["iban"]))}</span>
<button class="btn ghost small" type="button" data-copy="{e(d["iban"])}" data-prompt="انسخ رقم الآيبان">نسخ الآيبان</button></dd></dl>
<p class="hint">قبل تأكيد التحويل تأكد أن اسم المستفيد الذي يظهر في تطبيق بنكك يطابق الاسم أعلاه.</p>{note}{contact}</section>"""

    async def commissions_page(ctx: Ctx, error: str = "", values: dict | None = None, status: int = 200):
        values = values or {}
        today_iso = ctx.today().isoformat()
        reported = payments.reported_ids(db)
        payable, rest = [], []
        sums = {s: 0 for s in payments.STATES}
        for r in payments.owner_rentals(db, ctx.owner["id"]):
            state = payments.state_of(r, today_iso, reported)
            sums[state] += r["commission_halalas"]
            (payable if state in ("due", "late") else rest).append((r, state))

        if not payable and not rest:
            summary = ('<section class="empty"><h2>لا توجد عمولات حتى الآن</h2><p>عندما تسجّل الإدارة عملية تأجير لإحدى استراحاتك تظهر عمولتها هنا، '
                       'وتقدر تسددها وتبلغ بالسداد من نفس الصفحة.</p></section>')
        else:
            owed = sums["due"] + sums["late"]
            tiles = _tile("مستحقة عليك", owed, sub=f"منها متأخرة {money(sums['late'])} ر.س" if sums["late"] else "", kind="bad" if sums["late"] else "")
            tiles += _tile("بانتظار تأكيد الإدارة", sums["reported"]) + _tile("مدفوعة", sums["paid"])
            if sums["disputed"]:
                tiles += _tile("متنازع عليها", sums["disputed"], sub="تواصل مع الإدارة بشأنها")
            summary = f'<div class="stats fill">{tiles}</div>'
        late_note = ui.notice("bad", "عندك عمولة تجاوزت موعد السداد. سدّدها وأبلغ بالسداد من الأسفل.") if sums["late"] else ""

        form = ""
        if payable:
            chosen = set(values.get("rental", [])) if values else None
            ticked = lambda r: chosen is None or str(r["id"]) in chosen
            items = _list([_row(r, state, "box", ticked=ticked(r)) for r, state in payable])
            first = sum(r["commission_halalas"] for r, _ in payable if ticked(r))
            form = f"""{_bank_box()}
<form method="post" action="/owner/commissions/report" class="panel" data-sum>{ui.csrf_input(ctx.csrf)}
<h2>أبلغت بالسداد</h2>
<p>بعد التحويل من تطبيق بنكك اختر العمليات التي سددتها واكتب تاريخ التحويل. اكتب في وصف الحوالة «عمولة» وأرقام العمليات. تتأكد الإدارة من وصول المبلغ ثم تتحدث حالة عمولتك.</p>
{items}
<p class="com-total">المبلغ الذي تحوّله: <b><span id="sum">{money(first)}</span> ر.س</b></p>
<div class="row2">{ui.field("تاريخ التحويل", "paid_on", values.get("paid_on") or ctx.today().isoformat(), type="date", required=True, attrs=f'max="{today_iso}"')}
{ui.field("رقم عملية التحويل أو اسم المحوِّل (اختياري)", "reference", values.get("reference", ""), hint="يساعد الإدارة على مطابقة تحويلك في كشف الحساب", attrs=f'maxlength="{payments.MAX_REFERENCE}"')}</div>
<button class="btn sun big" type="submit">أبلغت بالسداد</button></form>"""
        elif rest:
            form = '<p class="note ok">لا توجد عمولات مستحقة عليك الآن.</p>'

        history = f'<section><h2>سجل العمليات</h2>{_list([_row(r, state, "plain") for r, state in rest])}</section>' if rest else ""

        reports = ""
        sent = payments.reports_of(db, ctx.owner["id"])
        if sent:
            cards = []
            for p in sent:
                extra = f'<small>سبب الرفض: {e(p["decision_note"])}</small>' if p["status"] == "rejected" and p["decision_note"] else ""
                if p["status"] == "pending":
                    extra += (f'<form method="post" action="/owner/commissions/report/{p["id"]}/withdraw">{ui.csrf_input(ctx.csrf)}'
                              '<button class="link bad" type="submit">إلغاء البلاغ</button></form>')
                cards.append(_report_card(p, extra=extra))
            reports = f'<section><h2>بلاغات السداد</h2>{_list(cards)}</section>'

        body = f"""<div class="head"><h1>عمولاتي</h1><a class="btn ghost small" href="/owner">إعلاناتي</a></div>
{ui.notice("ok", ctx.flash())}{ui.notice("bad", error)}{late_note}{summary}{form}{history}{reports}"""
        return html_page(ctx, "عمولاتي", body, status, noindex=True)

    @app.route("GET", "/owner/commissions", "owner")
    async def commissions(ctx: Ctx):
        return await commissions_page(ctx)

    @app.route("POST", "/owner/commissions/report", "owner")
    async def report_post(ctx: Ctx):
        form = ctx.request.form()[0]
        ids = _ids(form.get("rental", []))
        reference = ctx.request.field("reference")
        paid_on_text = ctx.request.field("paid_on")
        rid, problem = payments.create_report(db, ctx.owner["id"], ids, util.parse_date(paid_on_text), reference, ctx.today(), app.clock())
        if rid is None:
            values = {"rental": [str(i) for i in ids], "paid_on": util.clean_text(paid_on_text)[:10], "reference": util.clean_text(reference)[:payments.MAX_REFERENCE + 20]}
            return await commissions_page(ctx, problem, values, 400)
        return redirect(f"/owner/commissions?msg=وصل بلاغك رقم {rid}. ننتظر تأكيد الإدارة بعد مطابقته مع حسابها")

    @app.route("POST", r"/owner/commissions/report/(\d{1,9})/withdraw", "owner")
    async def report_withdraw(ctx: Ctx, raw: str):
        done = payments.withdraw_report(db, int(raw), ctx.owner["id"], app.clock())
        return redirect("/owner/commissions?msg=" + ("ألغينا البلاغ، وتقدر تبلغ من جديد" if done else "هذا البلاغ لم يعد بانتظار التأكيد"))

    # =============================================================== the manager
    def page(ctx: Ctx, title: str, body: str, status: int = 200):
        return html_page(ctx, title, body, status, noindex=True, admin=True, extra_class="admin")

    def msg(ctx: Ctx) -> str:
        return ui.notice("ok", ctx.flash())

    @app.route("GET", "/admin/earnings", "admin")
    async def earnings_page(ctx: Ctx):
        data = payments.earnings(db, ctx.today())
        t, c = data["totals"], data["counts"]
        hero = _tile("المحصّل حتى الآن", t["paid"], href="/admin/rentals?pay=paid", sub=f"من {num(c['paid'])} عملية مدفوعة، قبل أي مصاريف", kind="big")
        tiles = "".join([
            _tile("المحصّل هذا الشهر", data["collected_now"]),
            _tile("المتبقي لك", data["open"], sub="كل ما لم يُحصَّل بعد"),
            _tile("بانتظار تأكيدك", t["reported"], href="#reports", sub=f"{num(c['reported'])} عملية", kind="warn" if t["reported"] else ""),
            _tile("مستحقة", t["due"], href="/admin/rentals?pay=due", sub=f"{num(c['due'])} عملية"),
            _tile("متأخرة", t["late"], href="/admin/rentals?pay=late", sub=f"{num(c['late'])} عملية", kind="bad" if t["late"] else ""),
            _tile("متنازع عليها", t["disputed"], href="/admin/rentals?pay=disputed", sub=f"{num(c['disputed'])} عملية"),
        ])
        waived = (f'<p class="muted">معفاة من العمولة: {money(t["waived"])} ر.س ({num(c["waived"])} عملية). لا تُحتسب ضمن الأرباح ولا المتبقي.</p>' if c["waived"] else "")
        setup = "" if payments.has_bank(payments.pay_details(db)) else (
            '<p class="note warn">لم تضف بيانات حسابك بعد، فلا يرى الملاك كيف يحوّلون لك العمولة. <a href="/admin/pay-details">أضفها الآن</a></p>')

        pending = db.all("""SELECT p.*, u.name AS owner_name FROM payment_reports p JOIN users u ON u.id = p.owner_id WHERE p.status = 'pending' ORDER BY p.id""")
        reports = (_list([_report_card(p, owner=p["owner_name"], href=f"/admin/payment/{p['id']}", extra='<span class="go">مراجعة وتأكيد</span>') for p in pending])
                   if pending else '<p class="muted">لا توجد بلاغات بانتظار التأكيد.</p>')
        decided = db.all("""SELECT p.*, u.name AS owner_name FROM payment_reports p JOIN users u ON u.id = p.owner_id WHERE p.status != 'pending'
                            ORDER BY p.id DESC LIMIT 15""")
        log = ('<details class="more"><summary>آخر القرارات</summary>' + _list([_report_card(p, owner=p["owner_name"], href=f"/admin/payment/{p['id']}") for p in decided])
               + "</details>") if decided else ""

        if not data["months"]:
            tables = ('<section class="empty"><h2>لا توجد عمليات مسجلة بعد</h2><p>سجّل عملية التأجير الأولى لتظهر عمولتها هنا.</p>'
                      '<a class="btn sun" href="/admin/rental/new">تسجيل عملية</a></section>')
        else:
            by_month = table(["الشهر", "العمولة", "المحصّل", "المتبقي"],
                             [[f'<b>{e(ui.MONTHS[int(m["key"][5:7]) - 1])} {e(m["key"][:4])}</b><small>العمليات {num(m["n"])}</small><small>الإيجارات {num(m["rent"])} ر.س</small>',
                               money(m["commission"]), money(m["collected"]), money(m["open"])] for m in data["months"]], fit=True)
            by_owner = table(["المالك", "العمولة", "المحصّل", "المتبقي"],
                             [[f'<a href="/admin/owner/{o["key"]}">{e(o["name"])}</a><small>العمليات {num(o["n"])}</small>', money(o["commission"]), money(o["collected"]),
                               money(o["open"]) + (f'<small class="bad">منه متأخر {money(o["late"])}</small>' if o["late"] else "")] for o in data["owners"]], fit=True)
            tables = (f'<h2>حسب شهر الإيجار</h2><p class="hint">العمولة بدون المعفاة والملغية. المتبقي = العمولة − المحصّل.</p>{by_month}'
                      f'<h2>حسب المالك</h2>{by_owner}')
        body = (f'{msg(ctx)}<h1>الأرباح</h1>{setup}<div class="stats">{hero}{tiles}</div>{waived}'
                f'<h2 id="reports">بلاغات السداد</h2>{reports}{log}{tables}'
                f'<p class="muted">نسبة العمولة الحالية {util.percent_text(db.commission_bp())}% · <a href="/admin/commission">تغيير</a></p>')
        return page(ctx, "الأرباح", body)

    # ---- one report: confirm or refuse -------------------------------------------------------------------
    @app.route("GET", r"/admin/payment/(\d{1,9})", "admin")
    async def payment_detail(ctx: Ctx, raw: str):
        p = db.one("""SELECT p.*, u.name AS owner_name, u.login AS owner_login FROM payment_reports p JOIN users u ON u.id = p.owner_id WHERE p.id = ?""", (int(raw),))
        if not p:
            return not_found(ctx)
        items = payments.report_items(db, p["id"])
        today_iso, reported = ctx.today().isoformat(), payments.reported_ids(db)
        cards = []
        for r in items:
            cards.append(_row(r, payments.state_of(r, today_iso, reported), "link", href=f"/admin/rental/{r['id']}"))
        now_total = sum(r["commission_halalas"] for r in items)
        changed = (f'<p class="note warn">تغيّرت العمولة بعد البلاغ: كانت {money(p["amount_halalas"])} ر.س وصارت {money(now_total)} ر.س. راجع قبل أن تؤكد.</p>'
                   if now_total != p["amount_halalas"] else "")
        status = tag(payments.REPORT_KIND[p["status"]], payments.REPORT_LABELS[p["status"]])
        decided = ""
        if p["status"] != "pending":
            decided = f'<p class="muted">القرار: {e(_when(p["decided_at"]))}.' + (f" السبب: {e(p['decision_note'])}" if p["decision_note"] else "") + "</p>"
        actions = ""
        if p["status"] == "pending":
            actions = f"""<form method="post" action="/admin/payment/{p["id"]}/confirm" class="panel">{ui.csrf_input(ctx.csrf)}<h2>هل وصلك المبلغ؟</h2>
<label class="chk big"><input type="checkbox" name="received" value="1" required><span>راجعت كشف حسابي واستلمت <b>{money(p["amount_halalas"])} ر.س</b> من هذا المالك</span></label>
<button class="btn sun big" type="submit">تأكيد الاستلام</button></form>
<form method="post" action="/admin/payment/{p["id"]}/reject" class="panel">{ui.csrf_input(ctx.csrf)}<h2>ما وصل المبلغ أو وصل ناقصًا؟</h2>
{ui.field("السبب (يراه المالك)", "reason", required=True, hint="مثل: ما وصل التحويل، أو المبلغ أقل", attrs=f'maxlength="{payments.MAX_REASON}"')}
<button class="btn ghost big" type="submit">رفض البلاغ</button></form>"""
        body = f"""{msg(ctx)}<div class="head"><h1>بلاغ سداد #{p["id"]}</h1>{status}</div>{changed}
<ul class="facts"><li><b>المالك</b><a href="/admin/owner/{p["owner_id"]}">{e(p["owner_name"])}</a> {e(util.show_phone(p["owner_login"]))}</li>
<li><b>المبلغ المبلَّغ عنه</b><b>{money(p["amount_halalas"])} ر.س</b></li><li><b>تاريخ التحويل</b>{e(ui.day_text(p["paid_on"]))}</li>
<li><b>المرجع أو اسم المحوِّل</b>{e(p["reference"] or "—")}</li><li class="wide"><b>وقت البلاغ</b>{e(_when(p["created_at"]))}</li></ul>
<h2>العمليات في البلاغ</h2>{_list(cards)}{decided}{actions}
<p><a href="/admin/earnings#reports">رجوع للأرباح</a></p>"""
        return page(ctx, f"بلاغ {p['id']}", body)

    @app.route("POST", r"/admin/payment/(\d{1,9})/confirm", "admin")
    async def payment_confirm(ctx: Ctx, raw: str):
        if ctx.request.field("received") != "1":
            return redirect(f"/admin/payment/{raw}?msg=علّم على أنك راجعت حسابك واستلمت المبلغ")
        done, marked, settled = payments.confirm_report(db, int(raw), ctx.admin["id"], app.clock())
        if not done:
            return redirect(f"/admin/payment/{raw}?msg=هذا البلاغ لم يعد بانتظار التأكيد")
        note = f"أكدنا الاستلام وسجلنا {marked} عملية مدفوعة" + (f"، و{settled} كانت مسددة أو معفاة قبل ذلك" if settled else "")
        return redirect(f"/admin/payment/{raw}?msg={note}")

    @app.route("POST", r"/admin/payment/(\d{1,9})/reject", "admin")
    async def payment_reject(ctx: Ctx, raw: str):
        reason = util.clean_text(ctx.request.field("reason"))
        if not reason:
            return redirect(f"/admin/payment/{raw}?msg=اكتب السبب ليراه المالك")
        if not payments.reject_report(db, int(raw), ctx.admin["id"], reason, app.clock()):
            return redirect(f"/admin/payment/{raw}?msg=هذا البلاغ لم يعد بانتظار التأكيد")
        return redirect(f"/admin/payment/{raw}?msg=رفضنا البلاغ، وتعود العمليات مستحقة ويقرأ المالك السبب")

    # ---- his own bank details -------------------------------------------------------------------------------
    async def pay_details_page(ctx: Ctx, error: str = "", values: dict | None = None, status: int = 200):
        d = values or payments.pay_details(db)
        iban = payments.show_iban(d["iban"]) if payments.clean_iban(d["iban"]) else d["iban"]
        contact = util.show_phone(d["contact"]) if re.fullmatch(r"966[0-9]{9}", d["contact"]) else d["contact"]
        body = f"""{msg(ctx)}<h1>بيانات استلام العمولة</h1>
<p>تظهر هذه البيانات لأصحاب الاستراحات المسجلين فقط، في صفحة «عمولاتي»، ليحوّلوا لك العمولة. اكتبها بنفسك هنا. للحماية نطلب كلمة مرور الإدارة عند كل تغيير.</p>
<form method="post" action="/admin/pay-details" class="panel">{ui.csrf_input(ctx.csrf)}{ui.notice("bad", error)}
{ui.field("اسم صاحب الحساب (كما يظهر في البنك)", "holder", d["holder"], attrs='maxlength="60"', autocomplete="off")}
{ui.field("اسم البنك", "bank", d["bank"], attrs='maxlength="40"', autocomplete="off")}
{ui.field("رقم الآيبان", "iban", iban, hint="يبدأ بـ SA ثم 22 رقمًا. نتحقق من صحته حتى لا يصل مال المالك لحساب خاطئ.", autocomplete="off",
          attrs='dir="ltr" inputmode="text" autocapitalize="characters" autocorrect="off" spellcheck="false" placeholder="SA00 0000 0000 0000 0000 0000"')}
{ui.field("رقم واتساب للاستفسار (اختياري)", "contact", contact, type="tel", hint="يظهر للمالك زر «استفسار من الإدارة»", attrs='inputmode="tel" placeholder="05XXXXXXXX"')}
{ui.textarea("ملاحظة للملاك (اختياري)", "note", d["note"], rows=3, hint="مثل: اكتب في وصف الحوالة رقم جوالك")}
{ui.field("كلمة مرور الإدارة", "password", type="password", required=True, autocomplete="current-password")}
<button class="btn sun big" type="submit">حفظ</button></form>
<p class="hint">لإخفاء طريقة السداد عن الملاك اترك الاسم والبنك والآيبان فارغة.</p>
<p class="muted">اسأل محاسبك أي حساب يصلح لاستلام العمولات (شخصي أم تجاري) وكيف تُصدر الفواتير.</p>
<p><a href="/admin/settings">رجوع للإعدادات</a></p>"""
        return page(ctx, "بيانات استلام العمولة", body, status)

    @app.route("GET", "/admin/pay-details", "admin")
    async def pay_details_get(ctx: Ctx):
        return await pay_details_page(ctx)

    @app.route("POST", "/admin/pay-details", "admin")
    async def pay_details_post(ctx: Ctx):
        f = ctx.request
        typed = {"holder": util.clean_text(f.field("holder")), "bank": util.clean_text(f.field("bank")), "iban": util.clean_text(f.field("iban")),
                 "contact": util.clean_text(f.field("contact")),
                 "note": re.sub(r"[ \t]+", " ", f.field("note").replace("\r\n", "\n")).strip()}
        typed["note"] = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", typed["note"])
        error = ""
        iban = payments.clean_iban(typed["iban"]) if typed["iban"] else ""
        clearing = not (typed["holder"] or typed["bank"] or typed["iban"])
        if not clearing:
            if len(typed["holder"]) < 3 or len(typed["holder"]) > 60:
                error = "اكتب اسم صاحب الحساب (3 إلى 60 حرفًا)"
            elif len(typed["bank"]) < 2 or len(typed["bank"]) > 40:
                error = "اكتب اسم البنك"
            elif not iban:
                error = "رقم الآيبان غير صحيح. يبدأ بـ SA ثم 22 رقمًا، راجعه من تطبيق البنك"
        contact = ""
        if not error and typed["contact"]:
            contact = util.normalize_phone(typed["contact"]) or ""
            if not contact:
                error = "اكتب رقم جوال سعودي صحيح للواتساب، مثل 0551234567"
        if not error and len(typed["note"]) > 200:
            error = "الملاحظة طويلة (الحد 200 حرف)"
        if error:
            return await pay_details_page(ctx, error, typed, 400)
        user, problem = await verify_login(ctx, "admin", ctx.admin["login"], f.field("password"))
        if not user:
            return await pay_details_page(ctx, "كلمة المرور غير صحيحة" if problem == "بيانات الدخول غير صحيحة" else problem, typed, 400)
        payments.save_pay_details(db, {"holder": "" if clearing else typed["holder"], "bank": "" if clearing else typed["bank"],
                                       "iban": "" if clearing else iban, "note": typed["note"], "contact": contact})
        db.audit(ctx.admin["id"], "pay_details", "إخفاء طريقة السداد" if clearing else f"الآيبان ينتهي بـ {iban[-4:]}")
        return redirect("/admin/pay-details?msg=" + ("أخفينا طريقة السداد عن الملاك" if clearing else "حفظنا بيانات الاستلام، وتظهر الآن للملاك"))
