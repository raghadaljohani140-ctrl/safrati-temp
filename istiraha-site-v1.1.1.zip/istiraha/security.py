"""Passwords, session tokens, request limits. Standard library only."""
from __future__ import annotations

import hashlib
import hmac
import secrets
import threading
import time
from typing import Callable

SCRYPT_N, SCRYPT_R, SCRYPT_P = 2 ** 14, 8, 1
MIN_PASSWORD = 8
# One scrypt run holds about 16 MB. Whatever the number of visitors logging in at once, only two run together,
# so a burst of sign-ins slows down instead of using up the container's memory.
_SLOTS = threading.BoundedSemaphore(2)


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    with _SLOTS:
        digest = hashlib.scrypt(password.encode(), salt=salt, n=SCRYPT_N, r=SCRYPT_R, p=SCRYPT_P, maxmem=64 * 1024 * 1024, dklen=32)
    return f"scrypt${SCRYPT_N}${SCRYPT_R}${SCRYPT_P}${salt.hex()}${digest.hex()}"


def check_password(password: str, stored: str) -> bool:
    try:
        scheme, n, r, p, salt, digest = stored.split("$")
        if scheme != "scrypt":
            return False
        with _SLOTS:
            calc = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt), n=int(n), r=int(r), p=int(p), maxmem=64 * 1024 * 1024, dklen=32)
        return hmac.compare_digest(calc.hex(), digest)
    except (ValueError, TypeError):
        return False


COMMON = {"12345678", "123456789", "1234567890", "password", "password1", "qwertyui", "11111111", "00000000", "abcd1234", "12341234"}


def password_problem(password: str) -> str | None:
    if len(password) < MIN_PASSWORD:
        return f"كلمة المرور قصيرة، اكتب {MIN_PASSWORD} خانات على الأقل"
    if len(password) > 128:
        return "كلمة المرور طويلة"
    if password.lower() in COMMON or password.isdigit() or len(set(password)) < 4:
        return "كلمة المرور ضعيفة، اخلط أرقامًا وحروفًا"
    return None


def new_token() -> str:
    return secrets.token_urlsafe(32)


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def same(a: str, b: str) -> bool:
    return bool(a) and bool(b) and hmac.compare_digest(a.encode(), b.encode())


def ip_hash(ip: str) -> str:
    """Only a short fingerprint of the address is kept with a consent record: enough to show where it came from, not to find a person."""
    return hashlib.sha256(("istiraha:" + ip).encode()).hexdigest()[:16]


class Limiter:
    """Counts events per key inside a sliding window. In memory only, bounded."""

    def __init__(self, limit: int, window: float, clock: Callable[[], float] = time.monotonic, max_keys: int = 20000):
        self.limit, self.window, self._clock, self.max_keys = limit, window, clock, max_keys
        self._hits: dict[str, list[float]] = {}

    def allow(self, key: str) -> bool:
        now = self._clock()
        hits = [t for t in self._hits.pop(key, []) if now - t < self.window]
        ok = len(hits) < self.limit
        if ok:
            hits.append(now)
        self._hits[key] = hits
        while len(self._hits) > self.max_keys:
            self._hits.pop(next(iter(self._hits)))
        return ok
