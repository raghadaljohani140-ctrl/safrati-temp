"""Running the site: password hashing under load, the address inside a WhatsApp message, backup and restore, the admin command."""
import hashlib
import io
import os
import re
import sqlite3
import tarfile
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

from istiraha import __main__ as cli
from istiraha import security
from istiraha.db import Database
from istiraha.settings import Settings
from tests.helpers import Case, Client


class HashingLoadTests(unittest.TestCase):
    def test_only_two_password_hashes_run_at_the_same_time(self):
        running, peak, lock = 0, 0, threading.Lock()
        real = hashlib.scrypt

        def slow(*a, **kw):
            nonlocal running, peak
            with lock:
                running += 1
                peak = max(peak, running)
            time.sleep(0.05)
            with lock:
                running -= 1
            return real(*a, **kw)
        stored = security.hash_password("Some-pass-123")
        with mock.patch.object(hashlib, "scrypt", slow):
            threads = [threading.Thread(target=security.check_password, args=("Some-pass-123", stored)) for _ in range(10)]
            for t in threads:
                t.start()
            for t in threads:
                t.join()
        self.assertEqual(peak, 2)


class WhatsAppAddressTests(Case):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.owner = await self.make_owner()
        self.lid = await self.add_listing(self.owner, "استراحة النخيل")
        self.approve(self.lid)

    async def link_for(self, host):
        client = Client(self.app)
        await client.go("GET", f"/r/{self.lid}", headers={"host": host})
        from urllib.parse import unquote
        return unquote(re.search(r'href="(https://wa\.me/[^"]+)"', client.text).group(1).replace("&amp;", "&"))

    async def test_the_configured_address_wins_over_the_host_header(self):
        link = await self.link_for("evil.example")
        self.assertIn(f"https://rest.example/r/{self.lid}", link)
        self.assertNotIn("evil.example", link)

    async def test_a_free_test_link_puts_its_own_address_in_the_message(self):
        object.__setattr__(self.app.settings, "site_url", "")
        link = await self.link_for("quiet-river-1234.trycloudflare.com")
        self.assertIn(f"https://quiet-river-1234.trycloudflare.com/r/{self.lid}", link)

    async def test_any_other_host_is_left_out_of_the_message(self):
        object.__setattr__(self.app.settings, "site_url", "")
        for host in ("evil.example", "trycloudflare.com.evil.example", "x.trycloudflare.com.evil.example", "127.0.0.1:8090", ""):
            link = await self.link_for(host)
            self.assertNotIn("/r/", link, host)
            self.assertIn("wa.me/966551234567", link)                      # the chat still opens, with the title


def make_settings(tmp):
    return Settings(data_dir=Path(tmp), site_url="https://rest.example")


class BackupTests(unittest.TestCase):
    def setUp(self):
        quiet = mock.patch("sys.stdout", new=io.StringIO())
        quiet.start()
        self.addCleanup(quiet.stop)
        self.src = tempfile.TemporaryDirectory()
        self.dst = tempfile.TemporaryDirectory()
        self.addCleanup(self.src.cleanup)
        self.addCleanup(self.dst.cleanup)
        self.s1, self.s2 = make_settings(self.src.name), make_settings(self.dst.name)
        db = Database(self.s1.db_path)
        db.run("INSERT INTO users(role, login, name, pass_hash, created_at) VALUES ('owner','966551234567','أبو سعد','x',1)")
        db.close()
        self.s1.uploads_dir.mkdir()
        (self.s1.uploads_dir / "abc123.jpg").write_bytes(b"picture-bytes")

    def archive(self):
        out = io.BytesIO()
        self.assertEqual(cli._export(self.s1, out), 0)
        return out.getvalue()

    def other_site(self):
        db = Database(self.s2.db_path)
        db.run("INSERT INTO users(role, login, name, pass_hash, created_at) VALUES ('owner','966500000000','قديم','x',1)")
        db.close()
        self.s2.uploads_dir.mkdir()
        (self.s2.uploads_dir / "old.jpg").write_bytes(b"old-picture")

    def test_export_then_import_brings_everything_back(self):
        data = self.archive()
        self.other_site()
        self.assertEqual(cli._import(self.s2, io.BytesIO(data), force=True), 0)
        conn = sqlite3.connect(self.s2.db_path)
        self.assertEqual([r[0] for r in conn.execute("SELECT login FROM users WHERE role='owner'")], ["966551234567"])
        conn.close()
        self.assertEqual((self.s2.uploads_dir / "abc123.jpg").read_bytes(), b"picture-bytes")
        self.assertFalse((self.s2.uploads_dir / "old.jpg").exists())

    def test_nothing_is_deleted_by_a_restore(self):
        data = self.archive()
        self.other_site()
        cli._import(self.s2, io.BytesIO(data), force=True)
        kept = sorted(os.listdir(self.dst.name))
        self.assertTrue(any(n.startswith("istiraha.db.") and n.endswith(".before-restore") for n in kept), kept)
        folder = next(n for n in kept if n.startswith("uploads.") and n.endswith(".before-restore"))
        self.assertEqual((Path(self.dst.name) / folder / "old.jpg").read_bytes(), b"old-picture")
        self.assertFalse(any(n.startswith(".restore-") for n in kept), "the working folder must be cleaned up")

    def test_it_refuses_without_force(self):
        data = self.archive()
        self.other_site()
        with mock.patch("sys.stderr", new=io.StringIO()):
            self.assertEqual(cli._import(self.s2, io.BytesIO(data), force=False), 2)
        self.assertTrue((self.s2.uploads_dir / "old.jpg").exists())

    def hostile(self, build):
        out = io.BytesIO()
        with tarfile.open(fileobj=out, mode="w:gz") as tar:
            build(tar)
        return out.getvalue()

    def test_a_hostile_archive_changes_nothing(self):
        good_db = self.archive()
        with tarfile.open(fileobj=io.BytesIO(good_db), mode="r:gz") as t:
            db_bytes = t.extractfile("istiraha.db").read()

        def add(tar, name, data=b"x", kind=tarfile.REGTYPE, link=""):
            info = tarfile.TarInfo(name)
            info.size = len(data) if kind == tarfile.REGTYPE else 0
            info.type, info.linkname = kind, link
            tar.addfile(info, io.BytesIO(data) if kind == tarfile.REGTYPE else None)
        cases = {
            "path up": lambda t: (add(t, "istiraha.db", db_bytes), add(t, "../evil", b"x")),
            "absolute": lambda t: (add(t, "istiraha.db", db_bytes), add(t, "/etc/passwd", b"x")),
            "symlink": lambda t: (add(t, "istiraha.db", db_bytes), add(t, "uploads/a.jpg", kind=tarfile.SYMTYPE, link="/etc/passwd")),
            "odd name": lambda t: (add(t, "istiraha.db", db_bytes), add(t, "uploads/.hidden/../x", b"x")),
            "other file": lambda t: (add(t, "istiraha.db", db_bytes), add(t, "run.sh", b"x")),
            "no database": lambda t: add(t, "uploads/a.jpg", b"x"),
            "broken database": lambda t: add(t, "istiraha.db", b"this is not a database" * 100),
        }
        self.other_site()
        before = sorted(os.listdir(self.dst.name))
        for label, build in cases.items():
            with self.subTest(label), mock.patch("sys.stderr", new=io.StringIO()):
                self.assertEqual(cli._import(self.s2, io.BytesIO(self.hostile(build)), force=True), 1)
                self.assertEqual(sorted(os.listdir(self.dst.name)), before, "the site's folder must be exactly as it was")
        self.assertEqual((self.s2.uploads_dir / "old.jpg").read_bytes(), b"old-picture")
        self.assertFalse(Path("/evil").exists())

    def test_an_archive_from_a_newer_site_is_refused(self):
        data = self.archive()
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as t:
            db_bytes = t.extractfile("istiraha.db").read()
        newer = Path(self.src.name) / "newer.db"
        newer.write_bytes(db_bytes)
        conn = sqlite3.connect(newer)
        conn.execute("PRAGMA user_version = 99")
        conn.commit()
        conn.close()
        out = io.BytesIO()
        with tarfile.open(fileobj=out, mode="w:gz") as tar:
            tar.add(newer, arcname="istiraha.db")
        self.other_site()
        with mock.patch("sys.stderr", new=io.StringIO()):
            self.assertEqual(cli._import(self.s2, io.BytesIO(out.getvalue()), force=True), 1)


class CreateAdminTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.settings = make_settings(self.tmp.name)
        db = Database(self.settings.db_path)
        db.run("INSERT INTO users(role, login, name, pass_hash, created_at) VALUES ('owner','966551234567','أبو سعد','x',1)")
        db.close()

    def run_cli(self, login, password, again=None):
        with mock.patch("builtins.input", return_value=login), mock.patch("getpass.getpass", side_effect=[password, again or password]), \
                mock.patch("sys.stdout", new=io.StringIO()) as out:
            code = cli._create_admin(self.settings)
        return code, out.getvalue()

    def users(self):
        conn = sqlite3.connect(self.settings.db_path)
        rows = conn.execute("SELECT login, role FROM users ORDER BY id").fetchall()
        conn.close()
        return rows

    def test_it_creates_an_admin_and_the_password_works(self):
        code, _ = self.run_cli("manager", "Str0ng-pass!")
        self.assertEqual(code, 0)
        db = Database(self.settings.db_path)
        row = db.one("SELECT * FROM users WHERE login = 'manager'")
        self.assertEqual(row["role"], "admin")
        self.assertTrue(security.check_password("Str0ng-pass!", row["pass_hash"]))
        db.close()

    def test_a_second_run_changes_the_password_and_ends_old_sessions(self):
        self.run_cli("manager", "Str0ng-pass!")
        db = Database(self.settings.db_path)
        uid = db.one("SELECT id FROM users WHERE login = 'manager'")["id"]
        db.run("INSERT INTO sessions(token_hash, user_id, csrf, created_at, expires_at) VALUES ('h', ?, 'c', 1, 9999999999)", (uid,))
        db.close()
        code, _ = self.run_cli("manager", "An0ther-pass!")
        self.assertEqual(code, 0)
        db = Database(self.settings.db_path)
        self.assertTrue(security.check_password("An0ther-pass!", db.one("SELECT pass_hash FROM users WHERE login='manager'")["pass_hash"]))
        self.assertIsNone(db.one("SELECT 1 FROM sessions WHERE user_id = ?", (uid,)))
        db.close()

    def test_it_never_touches_an_owner_account(self):
        # an owner login is a phone number, which the admin name rule rejects; a clash is refused as well
        for bad in ("966551234567", "ab", "Manager Name", "-x"):
            code, _ = self.run_cli(bad, "Str0ng-pass!")
            self.assertEqual(code, 2, bad)
        self.assertEqual(self.users(), [("966551234567", "owner")])

    def test_weak_or_mismatched_passwords_are_refused(self):
        self.assertEqual(self.run_cli("manager", "12345678")[0], 2)
        self.assertEqual(self.run_cli("manager", "Str0ng-pass!", again="Different-pass1")[0], 2)
        self.assertEqual(self.users(), [("966551234567", "owner")])


if __name__ == "__main__":
    unittest.main()
