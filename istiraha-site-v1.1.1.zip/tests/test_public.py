import re

from istiraha import util
from tests.helpers import NOW, Case, Client


class PublicTests(Case):
    async def seed(self):
        o1 = await self.make_owner("0551111111", "مالك أول", ip="203.0.113.11")
        o2 = await self.make_owner("0552222222", "مالك ثان", ip="203.0.113.12")
        a = await self.add_listing(o1, "استراحة النخيل", city=1, price="800", amenities=(1, 3))        # Riyadh, pool + family
        b = await self.add_listing(o1, "شاليه البحر", city=2, category=2, price="1500", amenities=(1,))   # Jeddah
        c = await self.add_listing(o2, "مزرعة الوادي", city=1, category=3, price="400", amenities=(2,), district="الدرعية")
        for x in (a, b, c):
            self.approve(x)
        return o1, o2, a, b, c

    async def test_an_empty_site_invites_the_first_owner(self):
        await self.visitor.get("/")
        self.assertEqual(self.visitor.last.status, 200)
        self.assertIn("أضف استراحتك", self.visitor.text)
        self.assertIn("لا توجد استراحات منشورة بعد", self.visitor.text)

    async def test_home_has_the_search_box_and_the_sections(self):
        o1, o2, a, b, c = await self.seed()
        d = await self.add_listing(o2, "شاليه الربيع", city=1, category=2, price="900")
        self.approve(d)
        self.db.run("UPDATE listings SET featured = 1 WHERE id = ?", (a,))
        self.db.run("INSERT INTO offers(title, percent, city_id, starts_on, ends_on) VALUES ('عرض الشتاء', 20, 1, '2026-01-01', '2027-12-31')")
        await self.visitor.get("/")
        html = self.visitor.text
        for needle in ("ابحث عن استراحة", 'name="city"', 'name="price_max"', 'name="date"', 'name="category"', "الاستراحات المميزة", "أحدث الاستراحات", "العروض والخصومات", "أضف استراحتك"):
            self.assertIn(needle, html, needle)
        self.assertIn('dir="rtl"', html)
        self.assertIn('lang="ar"', html)
        self.assertIn("خصم 20%", html)

    async def test_an_advert_is_shown_once_on_the_home_page(self):
        """With only a few adverts, the featured, offers and latest shelves must not repeat the same card."""
        o1, o2, a, b, c = await self.seed()
        self.db.run("UPDATE listings SET featured = 1 WHERE id = ?", (a,))
        self.db.run("INSERT INTO offers(title, percent, starts_on, ends_on) VALUES ('عرض', 10, '2026-01-01', '2027-12-31')")   # every advert is on offer
        await self.visitor.get("/")
        main = self.visitor.text.split("<main")[1].split("</main>")[0]
        ids = re.findall(r'<a class="card" href="/r/(\d+)"', main)
        self.assertEqual(sorted(ids), sorted(set(ids)), "an advert appears twice on the home page")
        self.assertEqual(len(ids), 3)                              # nothing is lost either
        self.assertIn("الاستراحات المميزة", main)                  # a is on the first shelf it qualifies for
        self.assertNotIn("أحدث الاستراحات", main)                  # and the latest shelf has nothing left, so it is not drawn

    async def test_search_without_an_account(self):
        await self.seed()
        r = await self.visitor.get("/search")
        self.assertEqual(r.status, 200)
        for title in ("استراحة النخيل", "شاليه البحر", "مزرعة الوادي"):
            self.assertIn(title, self.visitor.text)
        self.assertNotIn("owner/login", self.visitor.text.split("<main")[1].split("</main>")[0])

    async def test_filters(self):
        await self.seed()

        async def titles(**q):
            await self.visitor.get("/search", **q)
            return sorted(set(re.findall(r'<h3>([^<]+)</h3>', self.visitor.text)))
        self.assertEqual(await titles(city=1), ["استراحة النخيل", "مزرعة الوادي"])
        self.assertEqual(await titles(city=2), ["شاليه البحر"])
        self.assertEqual(await titles(price_max=800), ["استراحة النخيل", "مزرعة الوادي"])
        self.assertEqual(await titles(price_min=1000), ["شاليه البحر"])
        self.assertEqual(await titles(price_min=500, price_max=1000), ["استراحة النخيل"])
        self.assertEqual(await titles(category=3), ["مزرعة الوادي"])
        self.assertEqual(await titles(district="الدرعية"), ["مزرعة الوادي"])
        self.assertEqual(await titles(amenity=[1]), ["استراحة النخيل", "شاليه البحر"])          # pool
        self.assertEqual(await titles(amenity=[1, 3]), ["استراحة النخيل"])                       # pool AND family section
        self.assertEqual(await titles(city=1, amenity=[2]), ["مزرعة الوادي"])
        self.assertEqual(await titles(city=2, price_max=100), [])
        self.assertIn("ما لقينا استراحات", self.visitor.text)

    async def test_the_date_filter_hides_a_taken_advert(self):
        o1, _, a, b, c = await self.seed()
        await o1.post(f"/owner/listing/{a}/block", {"start": "2026-12-20", "end": "2026-12-22"}, page=f"/owner/listing/{a}")
        for day, expect in (("2026-12-19", True), ("2026-12-20", False), ("2026-12-21", False), ("2026-12-22", False), ("2026-12-23", True)):
            await self.visitor.get("/search", city=1, date=day)
            self.assertEqual("استراحة النخيل" in self.visitor.text, expect, day)
            self.assertIn("مزرعة الوادي", self.visitor.text)

    async def test_sorting(self):
        await self.seed()
        self.db.run("INSERT INTO offers(title, percent, listing_id, starts_on, ends_on) VALUES ('خصم', 50, 2, '2026-01-01', '2027-12-31')")

        async def order(sort):
            await self.visitor.get("/search", sort=sort)
            return re.findall(r'<h3>([^<]+)</h3>', self.visitor.text)
        self.assertEqual(await order("cheap"), ["مزرعة الوادي", "شاليه البحر", "استراحة النخيل"])      # 400, 750 (after the discount), 800
        self.assertEqual(await order("dear"), ["استراحة النخيل", "شاليه البحر", "مزرعة الوادي"])
        self.assertEqual((await order("deal"))[0], "شاليه البحر")
        await self.visitor.get("/search", offers=1)
        self.assertEqual(re.findall(r'<h3>([^<]+)</h3>', self.visitor.text), ["شاليه البحر"])
        self.assertIn("750", self.visitor.text)
        await self.visitor.get("/offers")
        self.assertIn("شاليه البحر", self.visitor.text)

    async def test_offers_respect_their_scope_and_dates(self):
        await self.seed()
        db = self.db
        db.run("INSERT INTO offers(title, percent, city_id, starts_on, ends_on) VALUES ('عرض الرياض', 10, 1, '2026-01-01', '2027-12-31')")
        db.run("INSERT INTO offers(title, percent, starts_on, ends_on) VALUES ('عرض قديم', 90, '2025-01-01', '2025-02-01')")
        db.run("INSERT INTO offers(title, percent, starts_on, ends_on, active) VALUES ('عرض موقوف', 80, '2026-01-01', '2027-12-31', 0)")
        await self.visitor.get("/search", offers=1)
        self.assertEqual(sorted(re.findall(r'<h3>([^<]+)</h3>', self.visitor.text)), ["استراحة النخيل", "مزرعة الوادي"])
        self.assertIn("خصم 10%", self.visitor.text)
        self.assertNotIn("90%", self.visitor.text)
        self.assertNotIn("80%", self.visitor.text)

    async def test_the_advert_page_and_the_whatsapp_button(self):
        o1, _, a, b, c = await self.seed()
        r = await self.visitor.get(f"/r/{a}")
        self.assertEqual(r.status, 200)
        html = self.visitor.text
        self.assertIn("تواصل واتساب للحجز", html)
        link = re.search(r'id="wa"[^>]*href="([^"]+)"', html).group(1).replace("&amp;", "&")
        self.assertTrue(link.startswith("https://wa.me/966551234567?text="), link)
        from urllib.parse import parse_qs, urlsplit
        text = parse_qs(urlsplit(link).query)["text"][0]
        self.assertIn("استراحة النخيل", text)
        self.assertIn(f"https://rest.example/r/{a}", text)
        self.assertIn('rel="noopener noreferrer"', html)
        for needle in ("مسبح", "قسم عائلي", "حي الياسمين", "800", "استراحة هادئة مع مسبح كبير"):
            self.assertIn(needle, html)
        self.assertNotIn("<script>alert", html)

    async def test_views_and_clicks_are_counted(self):
        _, _, a, *_ = await self.seed()
        await self.visitor.get(f"/r/{a}")
        await self.visitor.get(f"/r/{a}")
        r = await self.visitor.go("POST", f"/api/click/{a}")
        self.assertEqual(r.status, 204)
        row = self.db.one("SELECT views, clicks FROM listings WHERE id = ?", (a,))
        self.assertEqual((row["views"], row["clicks"]), (2, 1))

    async def test_pending_adverts_are_not_public(self):
        o1 = await self.make_owner()
        lid = await self.add_listing(o1)
        for path in (f"/r/{lid}",):
            self.assertEqual((await self.visitor.get(path)).status, 404)
        await self.visitor.get("/search")
        self.assertNotIn("استراحة النخيل", self.visitor.text)
        self.assertEqual((await o1.get(f"/r/{lid}")).status, 200)                       # the owner can preview
        self.assertIn("هذه معاينة", o1.text)
        self.assertIn("noindex", o1.text)

    async def test_paused_and_stopped_adverts_disappear(self):
        o1, _, a, b, c = await self.seed()
        await o1.post(f"/owner/listing/{a}/pause", page=f"/owner/listing/{a}")
        self.assertEqual((await self.visitor.get(f"/r/{a}")).status, 404)
        await o1.post(f"/owner/listing/{a}/resume", page=f"/owner/listing/{a}")
        self.assertEqual((await self.visitor.get(f"/r/{a}")).status, 200)
        admin = await self.make_admin()
        await admin.post(f"/admin/listing/{a}/stop", {"note": "مخالفة"}, page=f"/admin/listing/{a}")
        self.assertEqual((await self.visitor.get(f"/r/{a}")).status, 404)

    async def test_a_blocked_owner_s_adverts_disappear(self):
        o1, _, a, b, c = await self.seed()
        admin = await self.make_admin()
        owner_id = self.db.one("SELECT owner_id FROM listings WHERE id = ?", (a,))["owner_id"]
        await admin.post(f"/admin/owner/{owner_id}/block", page=f"/admin/owner/{owner_id}")
        self.assertEqual((await self.visitor.get(f"/r/{a}")).status, 404)
        self.assertEqual((await self.visitor.get(f"/r/{b}")).status, 404)
        self.assertEqual((await self.visitor.get(f"/r/{c}")).status, 200)
        r = await o1.get("/owner")                                                      # and the blocked owner is signed out
        self.assertEqual(r.status, 303)

    async def test_text_from_owners_cannot_run_as_code(self):
        o1 = await self.make_owner()
        lid = await self.add_listing(o1, title='<img src=x onerror=alert(1)>', description="<script>alert(2)</script>", district='"><svg onload=1>')
        self.approve(lid)
        await self.visitor.get(f"/r/{lid}")
        html = self.visitor.text
        self.assertNotIn("<img src=x", html)
        self.assertNotIn("<script>alert", html)
        self.assertNotIn("<svg onload", html)
        self.assertIn("&lt;img src=x onerror=alert(1)&gt;", html)
        await self.visitor.get("/search", district='"><script>alert(3)</script>')
        self.assertNotIn("<script>alert(3)", self.visitor.text)

    async def test_odd_query_values_do_not_break_search(self):
        await self.seed()
        for q in ({"city": "abc"}, {"price_max": "-5"}, {"price_min": "x" * 50}, {"date": "2026-13-45"}, {"sort": "'; drop table listings;--"}, {"page": "999999"},
                  {"amenity": ["1", "x", "99999999999999999999"]}, {"district": "%"}, {"district": "_"}, {"q": "%' OR 1=1 --"}):
            r = await self.visitor.get("/search", **q)
            self.assertEqual(r.status, 200, q)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM listings")["n"], 3)
        await self.visitor.get("/search", district="%")
        self.assertIn("ما لقينا", self.visitor.text)                  # a percent sign is a letter, not a wildcard

    async def test_pages_robots_sitemap_health(self):
        _, _, a, *_ = await self.seed()
        self.assertEqual((await self.visitor.get("/terms")).status, 200)
        self.assertEqual((await self.visitor.get("/privacy")).status, 200)
        r = await self.visitor.get("/robots.txt")
        self.assertIn("Disallow: /admin", self.visitor.text)
        self.assertIn("Sitemap: https://rest.example/sitemap.xml", self.visitor.text)
        await self.visitor.get("/sitemap.xml")
        self.assertIn(f"https://rest.example/r/{a}", self.visitor.text)
        await self.visitor.get("/healthz")
        self.assertEqual(self.visitor.text, "ok")
        self.assertEqual((await self.visitor.get("/nothing-here")).status, 404)

    async def test_static_and_media_files(self):
        self.assertEqual((await self.visitor.get("/static/app.css")).status, 200)
        self.assertIn("text/css", self.visitor.last.content_type)
        self.assertEqual((await self.visitor.get("/static/app.js")).status, 200)
        for path in ("/static/..%2f..%2fetc%2fpasswd", "/static/nope.exe", "/media/../../etc/passwd", "/media/abcdefgh.jpg", "/media/a.txt"):
            self.assertEqual((await self.visitor.get(path)).status, 404, path)
