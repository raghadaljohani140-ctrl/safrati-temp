"""Automatic publishing: a new advert goes live by itself once it has a picture, unless the manager chose to review every advert."""
import dataclasses
import re

from tests.helpers import NOW, Case, Client, fake_jpeg


class PublishingTests(Case):
    async def upload(self, owner, lid, fetch=False):
        if fetch:
            await owner.get(f"/owner/listing/{lid}")
            return await owner.go("POST", f"/owner/listing/{lid}/photo", {"_csrf": owner.csrf()}, files=[("photo", "x.jpg", fake_jpeg())], headers={"x-requested-with": "fetch"})
        return await owner.post(f"/owner/listing/{lid}/photo", files=[("photo", "x.jpg", fake_jpeg())], page=f"/owner/listing/{lid}")

    def review(self, lid):
        return self.db.one("SELECT review, review_note, approved_at FROM listings WHERE id = ?", (lid,))

    async def test_it_is_on_by_default_and_the_advert_waits_only_for_its_first_picture(self):
        self.assertTrue(self.db.auto_publish())
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        self.assertEqual(self.review(lid)["review"], "pending")
        self.assertEqual((await self.visitor.get(f"/r/{lid}")).status, 404)                  # no picture yet: not shown
        self.assertIn("أضفنا إعلانك. أضف صورة واحدة على الأقل لينشر مباشرة", await owner.message())
        await owner.get("/owner")
        self.assertIn("أضف صورة لينشر", owner.text)
        await owner.get(f"/owner/listing/{lid}")
        self.assertIn("أضف صورة واحدة على الأقل وينشر إعلانك مباشرة", owner.text)
        r = await self.upload(owner, lid)
        self.assertEqual(r.status, 303)
        self.assertIn("وصار إعلانك منشورًا", await owner.message())
        row = self.review(lid)
        self.assertEqual((row["review"], row["approved_at"]), ("approved", NOW))
        self.assertEqual((await self.visitor.get(f"/r/{lid}")).status, 200)
        await self.visitor.get("/search")
        self.assertIn("استراحة النخيل", self.visitor.text)
        await owner.get("/owner")
        self.assertIn("منشور", owner.text)
        self.assertNotIn("أضف صورة لينشر", owner.text)
        self.assertIn("auto_approve", [a["action"] for a in self.db.all("SELECT action FROM audit")])

    async def test_the_phone_upload_path_also_publishes(self):
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        r = await self.upload(owner, lid, fetch=True)
        self.assertEqual((r.status, r.body.decode()), (200, "تم رفع 1 صورة وصار إعلانك منشورًا"))
        self.assertEqual(self.review(lid)["review"], "approved")
        await owner.get(f"/owner/listing/{lid}?up=1")
        self.assertIn("تم رفع 1 صورة وإعلانك منشور", owner.text)

    async def test_when_the_manager_reviews_everything_nothing_is_published_by_itself(self):
        self.db.set_auto_publish(False)
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        self.assertIn("ننتظر مراجعة الإدارة", await owner.message())
        await self.upload(owner, lid)
        self.assertEqual(self.review(lid)["review"], "pending")
        self.assertEqual((await self.visitor.get(f"/r/{lid}")).status, 404)
        await owner.get("/owner")
        self.assertIn("بانتظار المراجعة", owner.text)
        self.assertNotIn("auto_approve", [a["action"] for a in self.db.all("SELECT action FROM audit")])

    async def test_edits_and_new_pictures_keep_a_published_advert_published(self):
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        await self.upload(owner, lid)
        row = self.db.one("SELECT * FROM listings WHERE id = ?", (lid,))
        form = {"title": "اسم جديد للاستراحة", "city": str(row["city_id"]), "category": str(row["category_id"]), "price": "700", "unit": "night",
                "whatsapp": "0551234567", "district": row["district"], "description": "وصف جديد تمامًا", "amenities": ["1"]}
        await owner.get(f"/owner/listing/{lid}/edit")
        self.assertNotIn("يعيد الإعلان للمراجعة", owner.text)                                  # the old warning does not apply any more
        r = await owner.post(f"/owner/listing/{lid}/edit", form)
        self.assertEqual(r.status, 303)
        self.assertNotIn("أُعيد", await owner.message())
        self.assertEqual(self.review(lid)["review"], "approved")
        await self.upload(owner, lid)
        self.assertEqual(self.review(lid)["review"], "approved")
        self.assertEqual((await self.visitor.get(f"/r/{lid}")).status, 200)

    async def test_an_advert_the_manager_rejected_or_stopped_never_publishes_itself(self):
        admin = await self.make_admin()
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        await self.upload(owner, lid)
        await admin.post(f"/admin/listing/{lid}/reject", {"note": "الصور غير واضحة"}, page=f"/admin/listing/{lid}")
        self.assertEqual(self.review(lid)["review"], "rejected")
        row = self.db.one("SELECT * FROM listings WHERE id = ?", (lid,))
        form = {"title": row["title"], "city": str(row["city_id"]), "category": str(row["category_id"]), "price": "800", "unit": "night",
                "whatsapp": "0551234567", "district": row["district"], "description": "وصف أوضح بعد الملاحظة", "amenities": ["1"]}
        await owner.post(f"/owner/listing/{lid}/edit", form, page=f"/owner/listing/{lid}/edit")
        self.assertEqual(self.review(lid)["review"], "pending")                                # he fixed it: back in the manager's hands
        await self.upload(owner, lid)
        self.assertEqual((self.review(lid)["review"], self.review(lid)["review_note"]), ("pending", "الصور غير واضحة"))
        self.assertEqual((await self.visitor.get(f"/r/{lid}")).status, 404)
        await admin.post(f"/admin/listing/{lid}/approve", page=f"/admin/listing/{lid}")        # only he can approve it
        self.assertEqual(self.review(lid)["review"], "approved")
        await admin.post(f"/admin/listing/{lid}/stop", {"note": "شكوى"}, page=f"/admin/listing/{lid}")
        await owner.post(f"/owner/listing/{lid}/edit", {**form, "description": "تعديل آخر"}, page=f"/owner/listing/{lid}/edit")
        await self.upload(owner, lid)
        self.assertEqual(self.review(lid)["review"], "stopped")
        self.assertEqual((await self.visitor.get(f"/r/{lid}")).status, 404)


class PublishingSwitchTests(Case):
    async def test_switching_it_on_publishes_the_waiting_ones_and_leaves_the_manager_s_decisions_alone(self):
        self.db.set_auto_publish(False)
        admin = await self.make_admin()
        owner = await self.make_owner()
        with_photo = await self.add_listing(owner, title="استراحة بصورة")
        without_photo = await self.add_listing(owner, title="استراحة بلا صورة")
        rejected = await self.add_listing(owner, title="استراحة مرفوضة")
        stopped = await self.add_listing(owner, title="استراحة موقوفة")
        await owner.post(f"/owner/listing/{with_photo}/photo", files=[("photo", "x.jpg", fake_jpeg())], page=f"/owner/listing/{with_photo}")
        await owner.post(f"/owner/listing/{rejected}/photo", files=[("photo", "x.jpg", fake_jpeg())], page=f"/owner/listing/{rejected}")
        await admin.post(f"/admin/listing/{rejected}/reject", {"note": "ناقصة"}, page=f"/admin/listing/{rejected}")
        await admin.post(f"/admin/listing/{stopped}/stop", {"note": "شكوى"}, page=f"/admin/listing/{stopped}")
        r = await admin.post("/admin/publishing", {"mode": "auto"}, page="/admin/settings")
        self.assertEqual((r.status, r.headers["Location"].startswith("/admin/settings?m=")), (303, True))
        message = await admin.message()
        self.assertIn("فعّلنا النشر التلقائي", message)
        self.assertIn("ونشرنا 1 إعلانًا", message)
        self.assertIn("و1 ينتظر أول صورة", message)
        states = {lid: self.db.one("SELECT review FROM listings WHERE id = ?", (lid,))["review"] for lid in (with_photo, without_photo, rejected, stopped)}
        self.assertEqual(states, {with_photo: "approved", without_photo: "pending", rejected: "rejected", stopped: "stopped"})
        self.assertTrue(self.db.auto_publish())
        actions = [a["action"] for a in self.db.all("SELECT action FROM audit")]
        self.assertIn("publish_auto", actions)
        self.assertEqual(actions.count("auto_approve"), 1)

    async def test_switching_it_off_and_the_pages_that_show_the_choice(self):
        admin = await self.make_admin()
        await admin.get("/admin/settings")
        self.assertRegex(admin.text, r'name="mode" value="auto" checked')
        await admin.get("/admin")
        self.assertIn("نشر الإعلانات الجديدة: تلقائي", admin.text)
        r = await admin.post("/admin/publishing", {"mode": "manual"}, page="/admin/settings")
        self.assertEqual(r.status, 303)
        self.assertIn("تنتظر اعتمادك", await admin.message())
        self.assertFalse(self.db.auto_publish())
        await admin.get("/admin/settings")
        self.assertRegex(admin.text, r'name="mode" value="manual" checked')
        await admin.get("/admin")
        self.assertIn("نشر الإعلانات الجديدة: بعد موافقتك", admin.text)
        self.assertIn("publish_manual", [a["action"] for a in self.db.all("SELECT action FROM audit")])
        await admin.get("/admin")
        self.assertIn("إيقاف النشر التلقائي", admin.text)                                    # the log line is in Arabic

    async def test_only_the_manager_can_change_it_and_a_bad_value_changes_nothing(self):
        admin = await self.make_admin()
        owner = await self.make_owner()
        for who in (self.visitor, owner):
            r = await who.go("POST", "/admin/publishing", {"mode": "manual", "_csrf": "x"})
            self.assertIn(r.status, (303, 403))
        self.assertTrue(self.db.auto_publish())
        await admin.post("/admin/publishing", {"mode": "banana"}, page="/admin/settings")
        self.assertIn("اختر طريقة النشر", await admin.message())
        self.assertTrue(self.db.auto_publish())
        await admin.post("/admin/publishing", {}, page="/admin/settings")
        self.assertTrue(self.db.auto_publish())


class AdvertLimitTests(Case):
    async def test_one_owner_cannot_fill_the_site_with_adverts(self):
        self.app.settings = dataclasses.replace(self.app.settings, max_listings=2)
        owner = await self.make_owner()
        await self.add_listing(owner, title="الأولى بالاسم")
        await self.add_listing(owner, title="الثانية بالاسم")
        r = await owner.get("/owner/new")
        self.assertEqual(r.status, 400)
        self.assertIn("وصلت للحد الأعلى", owner.text)
        self.assertNotIn('name="agree"', owner.text)
        r = await owner.go("POST", "/owner/new", {"agree": "1", "version": "1", "bp": str(self.db.commission_bp()), "_csrf": owner.csrf()})
        self.assertEqual(r.status, 400)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM consents")["n"], 2)             # no new agreement was even recorded
        other = await self.make_owner("0552222222", "سعد", ip="203.0.113.12")
        self.assertEqual((await other.get("/owner/new")).status, 200)                            # the limit is per owner

    async def test_a_consent_made_before_the_limit_cannot_be_used_after_it(self):
        owner = await self.make_owner()
        await owner.get("/owner/new")
        await owner.post("/owner/new", {"agree": "1", "version": "1", "bp": str(self.db.commission_bp())})
        action = owner.location
        await self.add_listing(owner, title="الأولى بالاسم")
        self.app.settings = dataclasses.replace(self.app.settings, max_listings=1)
        r = await owner.post(action, {"title": "استراحة جديدة", "city": "1", "category": "1", "price": "500", "unit": "night", "whatsapp": "0551234567"}, page=action)
        self.assertEqual(r.status, 400)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM listings")["n"], 1)
