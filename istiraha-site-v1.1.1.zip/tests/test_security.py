import re

from tests.helpers import Case, Client, fake_jpeg


class CsrfTests(Case):
    async def test_every_post_needs_the_check_token(self):
        owner = await self.make_owner()
        admin = await self.make_admin()
        lid = await self.add_listing(owner)
        self.approve(lid)
        await owner.get("/owner")
        await admin.get("/admin")
        attacks = [
            (owner, "/owner/logout", {}), (owner, f"/owner/listing/{lid}/pause", {}), (owner, f"/owner/listing/{lid}/block", {"start": "2026-12-01", "end": "2026-12-02"}),
            (owner, f"/owner/listing/{lid}/edit", {"title": "اختراق الإعلان"}), (owner, "/owner/new", {"agree": "1", "version": "1", "bp": "1000"}),
            (admin, "/admin/commission", {"percent": "1"}), (admin, f"/admin/listing/{lid}/stop", {"note": "x"}), (admin, "/admin/offers", {"title": "خصم كبير", "percent": "90"}),
            (admin, "/admin/logout", {}), (admin, "/admin/rental/new", {"listing": str(lid), "rent": "500", "date": "2026-11-01"}),
        ]
        for client, path, form in attacks:
            for token in (None, "", "wrong-token", "x" * 500):
                body = dict(form) if token is None else {**form, "_csrf": token}
                r = await client.go("POST", path, body)
                self.assertEqual(r.status, 403, (path, token))
        self.assertEqual(self.db.commission_bp(), 1000)
        self.assertEqual(self.db.one("SELECT review, owner_active FROM listings")["review"], "approved")
        self.assertEqual((await owner.get("/owner")).status, 200)                      # nobody was signed out

    async def test_a_token_from_the_public_area_does_not_work_inside_the_admin_area(self):
        admin = await self.make_admin()
        stranger = Client(self.app, "203.0.113.80")
        await stranger.get("/")
        pre = stranger.jar["ist_c"]
        r = await admin.go("POST", "/admin/commission", {"percent": "1", "_csrf": pre})
        self.assertEqual(r.status, 403)
        self.assertEqual(self.db.commission_bp(), 1000)

    async def test_one_owner_s_token_is_useless_for_another(self):
        a = await self.make_owner("0551111111", ip="203.0.113.11")
        b = await self.make_owner("0552222222", ip="203.0.113.12")
        await a.get("/owner")
        token_a = a.csrf()
        r = await b.go("POST", "/owner/logout", {"_csrf": token_a})
        self.assertEqual(r.status, 403)

    async def test_a_login_form_is_protected_by_the_cookie_token(self):
        await self.make_owner()
        c = Client(self.app, "203.0.113.81")
        r = await c.go("POST", "/owner/login", {"phone": "0551234567", "password": "Owner-pass-1"})
        self.assertEqual(r.status, 403)
        await c.get("/owner/login")
        r = await c.go("POST", "/owner/login", {"phone": "0551234567", "password": "Owner-pass-1", "_csrf": "forged-value-forged-value"})
        self.assertEqual(r.status, 403)

    async def test_a_post_from_another_website_is_refused_even_with_a_token(self):
        owner = await self.make_owner()
        await owner.get("/owner")
        token = owner.csrf()
        for origin in ("https://evil.example", "null", "http://rest.example.evil.example", "https://rest.example:444"):
            r = await owner.go("POST", "/owner/logout", {"_csrf": token}, headers={"origin": origin})
            self.assertEqual(r.status, 403, origin)
        r = await owner.go("POST", "/owner/logout", {"_csrf": token}, headers={"origin": "https://rest.example"})
        self.assertEqual(r.status, 303)

    async def test_malformed_bodies_do_not_crash(self):
        owner = await self.make_owner()
        for headers, raw in (({"content-type": "text/plain"}, b"x"), ({"content-type": "multipart/form-data"}, b"--x"), ({"content-type": "multipart/form-data; boundary=zz"}, b"junk" * 50),
                             ({"content-type": "application/x-www-form-urlencoded"}, b"%ff%fe=%00&&&=="), ({}, b"")):
            r = await owner.go("POST", "/owner/new", headers=headers, raw=raw)
            self.assertIn(r.status, (400, 403), headers)


class InjectionTests(Case):
    async def test_sql_text_is_just_text(self):
        owner = await self.make_owner()
        lid = await self.add_listing(owner, title="x'); DROP TABLE listings;--", description="'; DELETE FROM users;--", district="' OR '1'='1")
        self.approve(lid)
        for q in ("' OR 1=1 --", "\\", '"', "%00", "' UNION SELECT pass_hash FROM users --"):
            for key in ("district", "q", "city", "price_max"):
                r = await self.visitor.get("/search", **{key: q})
                self.assertEqual(r.status, 200, (key, q))
        self.assertIn("x&#x27;); DROP TABLE listings;--", (await self.visitor.get(f"/r/{lid}")) and self.visitor.text)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM users")["n"], 1)
        self.assertNotIn("scrypt$", self.visitor.text)

    async def test_owner_text_is_safe_in_the_admin_pages_too(self):
        admin = await self.make_admin()
        owner = await self.make_owner(name='<script>alert("n")</script>')
        lid = await self.add_listing(owner, title="<b onmouseover=alert(1)>عنوان</b>", description="<img src=x onerror=alert(2)>")
        oid = self.db.one("SELECT id FROM users WHERE role = 'owner'")["id"]
        for path in ("/admin/owners", f"/admin/owner/{oid}", "/admin/listings", f"/admin/listing/{lid}", "/admin"):
            await admin.get(path)
            self.assertNotIn("<script>alert", admin.text, path)
            self.assertNotIn("<b onmouseover", admin.text, path)
            self.assertNotIn("<img src=x", admin.text, path)

    async def test_a_visitor_cannot_write_his_own_message_on_a_page(self):
        owner = await self.make_owner()
        for key in ("msg", "m"):
            await owner.get("/owner", **{key: "تم تحويل رصيدك، اتصل بالرقم 0500000000"})
            self.assertNotIn("0500000000", owner.text)
        await owner.get("/owner", up="3")
        self.assertEqual(owner.last.status, 200)

    async def test_a_message_is_shown_once_and_only_through_its_token(self):
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        self.assertRegex(owner.last.headers["Location"], r"\?m=[A-Za-z0-9_-]+$")
        self.assertNotIn("msg=", owner.last.headers["Location"])
        await owner.get(owner.location)
        self.assertIn("أضفنا إعلانك", owner.text)
        await owner.get(owner.location)
        self.assertNotIn("أضفنا إعلانك", owner.text)

    async def test_pages_never_contain_inline_script_or_style_that_the_policy_would_block(self):
        _, _ = await self.make_owner(), None
        for path in ("/", "/search", "/offers", "/terms", "/owner/login", "/owner/register", "/admin/login"):
            await self.visitor.get(path)
            html = self.visitor.text
            self.assertNotRegex(html, r"<script(?![^>]*\bsrc=)", path)
            self.assertNotRegex(html, r"\sstyle=", path)
            self.assertNotRegex(html, r"\son[a-z]+=", path)
            self.assertNotIn("javascript:", html, path)


class PrivacyTests(Case):
    async def test_public_pages_never_show_contact_data_of_accounts_or_hashes(self):
        owner = await self.make_owner("0559998877", name="سري جدًا")
        lid = await self.add_listing(owner, whatsapp="0551234567")
        self.approve(lid)
        for path in ("/", "/search", f"/r/{lid}", "/offers"):
            await self.visitor.get(path)
            self.assertNotIn("0559998877", self.visitor.text, path)
            self.assertNotIn("سري جدًا", self.visitor.text, path)
            self.assertNotIn("scrypt", self.visitor.text, path)

    async def test_the_owner_list_does_not_leak_between_owners_in_the_page_text(self):
        a = await self.make_owner("0551111111", ip="203.0.113.11")
        b = await self.make_owner("0552222222", name="مالك ب", ip="203.0.113.12")
        await self.add_listing(a, "إعلان سري للمالك أ")
        await b.get("/owner")
        self.assertNotIn("إعلان سري", b.text)

    async def test_private_pages_are_not_cached_or_indexed(self):
        owner = await self.make_owner()
        await owner.get("/owner")
        self.assertEqual(owner.last.headers["Cache-Control"], "no-store")
        self.assertIn("noindex", owner.text)
        admin = await self.make_admin()
        await admin.get("/admin")
        self.assertEqual(admin.last.headers["Cache-Control"], "no-store")
