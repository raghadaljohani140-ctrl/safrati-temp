#!/usr/bin/env bash
# Rest-house website: how the public reaches it. The website itself always runs inside the server; this script
# only switches its public link on or off.
#
#   bash web.sh quick     a free temporary public link (it changes if the server restarts): good for trying the site
#   bash web.sh link      show the address again
#   bash web.sh domain    your own domain (asks for the domain and the Cloudflare tunnel token): use this for the real launch
#   bash web.sh proxy     publish the website through a web server you already run on this machine (see below)
#   bash web.sh status    is it running?
#   bash web.sh stop      switch the public link off (the website keeps running, but nobody outside can reach it)
#
# proxy mode:  bash web.sh proxy [DOMAIN [NETWORK]]
#   For a server whose web ports (80 and 443) are already used by a web server in Docker. That web server gets one more
#   entry (the domain forwarded to istiraha-web:8090) and the website container joins one Docker network it is on, NETWORK.
#   The script changes nothing in that other web server: it only connects its own container istiraha-web to NETWORK
#   (and disconnects it again when you switch to another mode).
#
# Safety: runs only inside /opt/istiraha-site and only touches the Docker project "istiraha"
# (containers istiraha-web, istiraha-tunnel, istiraha-domain). No port of the server is opened: visitors reach the
# website only through the tunnel, which connects out from inside the project, or through the web server you named in
# proxy mode. The tunnel token is typed with hidden input and kept only in .tunnel.env (root-only).
set -euo pipefail

APP_DIR="/opt/istiraha-site"
PROJECT="istiraha"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$APP_DIR/.env"
STATE_FILE="$APP_DIR/.state"
TUNNEL_FILE="$APP_DIR/.tunnel.env"

die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
say() { printf '%s\n' "$*"; }

[ "$HERE" = "$APP_DIR" ] || die "this script must live in $APP_DIR (it is in $HERE). Nothing was changed."
cd "$APP_DIR"
umask 077

command -v docker >/dev/null 2>&1 || die "docker is not installed on this server."
docker compose version >/dev/null 2>&1 || die "the 'docker compose' plugin is missing."
command -v curl >/dev/null 2>&1 || die "curl is not installed on this server."

# ---------------------------------------------------------------- helpers
env_get() { [ -f "$ENV_FILE" ] && grep -m1 "^$1=" "$ENV_FILE" | cut -d= -f2- || true; }

env_set() { # NAME VALUE  (values are validated before they get here, so they never contain newlines)
  local tmp
  tmp="$(mktemp "$APP_DIR/.env.XXXXXX")"
  if [ -f "$ENV_FILE" ]; then grep -v "^$1=" "$ENV_FILE" > "$tmp" || true; fi
  printf '%s=%s\n' "$1" "$2" >> "$tmp"
  chmod 600 "$tmp"
  mv "$tmp" "$ENV_FILE"
}

env_unset() { # NAME
  local tmp
  [ -f "$ENV_FILE" ] || return 0
  tmp="$(mktemp "$APP_DIR/.env.XXXXXX")"
  grep -v "^$1=" "$ENV_FILE" > "$tmp" || true
  chmod 600 "$tmp"
  mv "$tmp" "$ENV_FILE"
}

state_get() { [ -f "$STATE_FILE" ] && grep -m1 "^$1=" "$STATE_FILE" | cut -d= -f2- || true; }

state_set() { # ACCESS [PROXY_NETWORK]
  { printf 'ACCESS=%s\n' "$1"; if [ -n "${2:-}" ]; then printf 'PROXY_NETWORK=%s\n' "$2"; fi; } > "$STATE_FILE"
  chmod 600 "$STATE_FILE"
}

mode() { # off | quick | domain | proxy
  case "$(state_get ACCESS)" in
    quick)  echo quick ;;
    domain) echo domain ;;
    proxy)  echo proxy ;;
    *)      echo off ;;
  esac
}

compose() { # the website, plus its tunnel when the public link is switched on
  case "$(mode)" in
    quick)  docker compose -p "$PROJECT" --profile quick "$@" ;;
    domain) docker compose -p "$PROJECT" --profile domain "$@" ;;
    *)      docker compose -p "$PROJECT" "$@" ;;
  esac
}

compose_all() { # every part, switched on or not (to stop or replace them)
  docker compose -p "$PROJECT" --profile quick --profile domain "$@"
}

need_install() {
  [ -f "$ENV_FILE" ] || die "the website is not installed yet. Run first:  bash install.sh"
}

prepare_files() { # compose reads this file for the domain tunnel; it must exist (empty is fine)
  [ -f "$TUNNEL_FILE" ] || : > "$TUNNEL_FILE"
  chmod 600 "$TUNNEL_FILE"
}

check_memory() { # the tunnel needs about 60 MB: never squeeze the other projects on this server
  local kb mb
  case "$(mode)" in quick|domain) return 0 ;; esac   # already running: its memory is already counted
  kb="$(awk '/^MemAvailable:/ {print $2}' "${ISTIRAHA_MEMINFO:-/proc/meminfo}" 2>/dev/null || true)"
  [[ "$kb" =~ ^[0-9]+$ ]] || return 0                # cannot tell: carry on
  mb=$((kb / 1024))
  if [ "$mb" -lt 150 ]; then
    die "only $mb MB of memory is free on this server. The tunnel needs about 60 MB and starting it could slow down the other projects here. Nothing was changed."
  fi
  say "Free memory: $mb MB."
}

valid() { # NAME VALUE -> exit 0 when the value has the right shape
  case "$1" in
    DOMAIN)        [[ "$2" =~ ^([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,24}$ ]] && [ "${#2}" -le 100 ] ;;
    TUNNEL_TOKEN)  [[ "$2" =~ ^[A-Za-z0-9=_+/-]{60,1500}$ ]] ;;
    NETWORK)       valid_network "$2" ;;
    *)             return 1 ;;
  esac
}

ASKED=""
ask() { # NAME PROMPT SECRET(1|0)  -> sets ASKED
  local name="$1" prompt="$2" secret="$3" value="" attempts=0
  while true; do
    if [ "$secret" = 1 ]; then
      read -r -s -p "$prompt (typing is hidden, paste then Enter): " value || die "input was closed."
      echo
    else
      read -r -p "$prompt: " value || die "input was closed."
    fi
    value="${value//[[:space:]]/}"
    if [ "$name" = DOMAIN ]; then
      value="${value,,}"
      value="${value#https://}"
      value="${value%/}"
    fi
    if valid "$name" "$value"; then
      ASKED="$value"
      say "  OK, received ${#value} characters"
      return 0
    fi
    attempts=$((attempts + 1))
    [ "$attempts" -lt 5 ] || die "that did not look right 5 times. Nothing was changed."
    say "  that does not look right (received ${#value} characters). Try again."
  done
}

wait_for_web() { # the website reports its start in its log
  local i logs line
  for i in $(seq 1 30); do
    logs="$(docker logs istiraha-web 2>&1 || true)"
    line="$(printf '%s\n' "$logs" | grep "website started on port" | tail -n 1 || true)"
    if [ -n "$line" ]; then
      say "The website is running:"
      say "$line"
      return 0
    fi
    sleep 2
  done
  say "The website did not report that it started within 60 seconds. Last log lines:"
  docker logs --tail 20 istiraha-web 2>&1 || true
  return 1
}

quick_url() { # the newest temporary address in the tunnel's log (the address of Cloudflare's own API does not count)
  local logs
  logs="$(docker logs istiraha-tunnel 2>&1 || true)"
  printf '%s\n' "$logs" | grep -o 'https://[a-z0-9-]*\.trycloudflare\.com' | grep -v '^https://api\.' | tail -n 1 || true
}

wait_for_url() { # prints the address
  local i url
  for i in $(seq 1 30); do
    url="$(quick_url)"
    if [ -n "$url" ]; then printf '%s\n' "$url"; return 0; fi
    sleep 2
  done
  return 1
}

public_ok() { # ADDRESS -> exit 0 when the website answers from the internet
  local out
  out="$(printf 'url = "%s/healthz"\nsilent\nmax-time = 15\n' "$1" | curl -K - 2>/dev/null || true)"
  [ "$out" = "ok" ]
}

wait_public() { # ADDRESS -> a new address can take a short while to become reachable
  local i
  for i in $(seq 1 20); do
    if public_ok "$1"; then return 0; fi
    sleep 3
  done
  return 1
}

# ---- the shared network of proxy mode (only the website's own container is ever connected or disconnected)
valid_network() { # NAME -> has the shape of a Docker network name, and is not one that must never be used
  [[ "$1" =~ ^[A-Za-z0-9][A-Za-z0-9_.-]{0,62}$ ]] || return 1
  case "$1" in bridge|host|none|istiraha_default) return 1 ;; esac
}

network_exists() { docker network inspect "$1" >/dev/null 2>&1; }

network_members() { # NAME -> the containers on that network, on one line
  docker network inspect -f '{{range $id, $c := .Containers}}{{$c.Name}} {{end}}' "$1" 2>/dev/null || true
}

list_networks() { # the networks on this server that could be used (names only)
  docker network ls --format '{{.Name}}' 2>/dev/null | grep -v -x -e bridge -e host -e none -e istiraha_default || true
}

is_connected() { # NETWORK -> exit 0 when the website container is on it
  local names
  [ -n "${1:-}" ] || return 1
  names="$(docker inspect -f '{{range $k, $v := .NetworkSettings.Networks}}{{$k}} {{end}}' istiraha-web 2>/dev/null || true)"
  [[ " $names " == *" $1 "* ]]
}

join_network() { # NETWORK
  if is_connected "$1"; then return 0; fi
  docker network connect "$1" istiraha-web
}

leave_network() { # NETWORK -> never stops the caller
  if is_connected "$1"; then docker network disconnect "$1" istiraha-web >/dev/null 2>&1 || true; fi
}

leave_proxy() { # leaving proxy mode: off the shared network, and back to trusting only the tunnel's own header
  local net
  [ "$(mode)" = proxy ] || return 0
  net="$(state_get PROXY_NETWORK)"
  if [ -n "$net" ]; then leave_network "$net"; fi
  env_unset REAL_IP_HEADER
}

# ---------------------------------------------------------------- commands
cmd_quick() {
  need_install
  check_memory
  prepare_files
  leave_proxy
  compose_all rm -sf tunnel-domain >/dev/null 2>&1 || true
  env_set SITE_URL ""
  state_set quick
  say "Starting the website and the free temporary link..."
  compose up -d --build web tunnel
  wait_for_web || exit 1
  say "Waiting for the public link..."
  local url
  url="$(wait_for_url)" || {
    say "The tunnel did not show a link within 60 seconds. Last log lines:"
    docker logs --tail 20 istiraha-tunnel 2>&1 || true
    exit 1
  }
  say ""
  say "Website link (open it on your phone):"
  say "  $url"
  if wait_public "$url"; then
    say "It answers from the internet."
  else
    say "It does not answer yet. Wait a minute and open it again. If it still fails:  bash web.sh status"
  fi
  say ""
  say "This link is only for trying the site: it changes if the server restarts, so do not share it with owners."
  say "For the real launch use your own domain:  bash web.sh domain"
  say "Show this link again with:  bash web.sh link"
}

cmd_domain() {
  need_install
  check_memory
  prepare_files
  say "Before this step, in your Cloudflare account (the free plan is enough):"
  say "  1) add your domain to Cloudflare"
  say "  2) Zero Trust > Networks > Tunnels > Create a tunnel > Cloudflared. Copy the long token after --token."
  say "  3) in the tunnel, add a public hostname for your domain: type HTTP, URL  web:8090"
  say ""
  ask DOMAIN "Your domain (example: istirahati.com or www.istirahati.com)" 0
  local domain="$ASKED" token tmp
  ask TUNNEL_TOKEN "Tunnel token" 1
  token="$ASKED"
  tmp="$(mktemp "$APP_DIR/.tunnel.env.XXXXXX")"
  printf 'TUNNEL_TOKEN=%s\n' "$token" > "$tmp"
  chmod 600 "$tmp"
  mv "$tmp" "$TUNNEL_FILE"
  leave_proxy
  compose_all rm -sf tunnel >/dev/null 2>&1 || true
  env_set SITE_URL "https://$domain"
  state_set domain
  say "Starting the website and the tunnel..."
  compose up -d --build web tunnel-domain
  wait_for_web || exit 1
  local i logs connected=0
  for i in $(seq 1 30); do
    logs="$(docker logs istiraha-domain 2>&1 || true)"
    if printf '%s\n' "$logs" | grep -q "Registered tunnel connection"; then connected=1; break; fi
    sleep 2
  done
  if [ "$connected" != 1 ]; then
    say "The tunnel did not connect within 60 seconds. Last log lines:"
    docker logs --tail 15 istiraha-domain 2>&1 || true
    say "Check the token (bash web.sh domain again) and that the public hostname points to  web:8090"
    exit 1
  fi
  say "The tunnel is connected."
  say ""
  say "Website address:  https://$domain"
  if wait_public "https://$domain"; then
    say "It answers from the internet."
  else
    say "It does not answer yet (a new name can take a few minutes). Try again later:  bash web.sh status"
  fi
}

cmd_proxy() { # [DOMAIN [NETWORK]]
  need_install
  local domain="${1:-}" net="${2:-}" members previous
  if [ -z "$domain" ]; then
    ask DOMAIN "The website's address (example: rest.duckdns.org)" 0
    domain="$ASKED"
  else
    domain="${domain,,}"
    domain="${domain#https://}"
    domain="${domain%/}"
    valid DOMAIN "$domain" || die "'${1:-}' does not look like a domain name. Nothing was changed."
  fi
  if [ -z "$net" ]; then
    say "Docker networks on this server (names only):"
    list_networks | sed 's/^/  /'
    ask NETWORK "The network the web server in front of the website is on" 0
    net="$ASKED"
  else
    valid_network "$net" || die "'$net' is not a network that can be used here. Nothing was changed."
  fi
  network_exists "$net" || die "there is no Docker network called '$net' on this server. Nothing was changed."
  members="$(network_members "$net")"
  say "Network '$net' is used by: ${members:-nobody yet}"
  say "(only these containers will be able to reach the website, which they do through the entry shown below)"
  prepare_files
  previous="$(state_get PROXY_NETWORK)"
  if [ "$previous" != "$net" ]; then leave_network "$previous"; fi
  compose_all rm -sf tunnel tunnel-domain >/dev/null 2>&1 || true
  env_set SITE_URL "https://$domain"
  env_set REAL_IP_HEADER "X-Forwarded-For"
  state_set proxy "$net"
  say "Starting the website..."
  compose up -d --build web
  wait_for_web || exit 1
  join_network "$net" || die "could not connect the website to the network '$net'."
  say "The website is connected to the network '$net' as istiraha-web."
  say ""
  say "Website address:  https://$domain"
  say ""
  say "The web server in front must forward that name to the website. The entry looks like this (Caddy syntax):"
  say ""
  say "    $domain {"
  say "        reverse_proxy istiraha-web:8090"
  say "    }"
  say ""
  if wait_public "https://$domain"; then
    say "It answers from the internet."
  else
    say "It does not answer yet. Add the entry above to the web server in front, reload it, wait a minute, then:  bash web.sh status"
  fi
  say "The temporary link (if there was one) is switched off."
}

cmd_link() {
  case "$(mode)" in
    quick)
      local url
      url="$(quick_url)"
      [ -n "$url" ] || die "no link in the tunnel log yet. Try again in a minute, or run:  bash web.sh status"
      say "$url" ;;
    domain|proxy) say "$(env_get SITE_URL)" ;;
    *)      say "The public link is off. Start it with:  bash web.sh quick" ;;
  esac
}

cmd_status() {
  say "Public link: $(mode)"
  compose ps
  if [ "$(mode)" = proxy ]; then
    local net
    net="$(state_get PROXY_NETWORK)"
    if [ -n "$net" ] && is_connected "$net"; then
      say "Connected to the network '$net'."
    else
      say "NOT connected to the network '${net:-?}'. Fix with:  bash web.sh proxy"
    fi
  fi
  say "--- website log ---"
  docker logs --tail 8 istiraha-web 2>&1 || true
  say "--- address ---"
  cmd_link
}

cmd_stop() {
  need_install
  prepare_files
  leave_proxy
  compose_all rm -sf tunnel tunnel-domain
  state_set off
  say "The public link is off. The website keeps running inside the server."
}

case "${1:-}" in
  quick)  cmd_quick ;;
  link)   cmd_link ;;
  domain) cmd_domain ;;
  proxy)  cmd_proxy "${2:-}" "${3:-}" ;;
  status) cmd_status ;;
  stop)   cmd_stop ;;
  *)      die "usage: bash web.sh quick | link | domain | proxy | status | stop" ;;
esac
