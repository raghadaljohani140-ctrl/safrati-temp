"""The page shell and the small pieces every page is made of. Everything a visitor typed goes through e()."""
from __future__ import annotations

import html
from datetime import datetime

from . import __version__, repo, util


def e(value) -> str:
    return html.escape(str(value if value is not None else ""), quote=True)


def num(n: int) -> str:
    return f"{int(n):,}"


def stamp(ts: float | None) -> str:
    if not ts:
        return "—"
    return datetime.fromtimestamp(ts, util.SAUDI_TZ).strftime("%Y-%m-%d %H:%M")


MONTHS = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]


def day_text(iso: str) -> str:
    d = util.parse_date(iso)
    return f"{d.day} {MONTHS[d.month - 1]} {d.year}" if d else iso


class Page:
    """What the shell needs to know about this visit."""

    def __init__(self, site_name: str, site_url: str, user=None, csrf: str = "", admin_user=None, waiting: int = 0):
        self.site_name, self.site_url, self.user, self.csrf, self.admin_user = site_name, site_url, user, csrf, admin_user
        self.waiting = waiting                      # payment reports the manager has not decided yet (a number beside «الأرباح»)


def layout(page: Page, title: str, body: str, *, description: str = "", noindex: bool = False, canonical: str = "",
           image: str = "", extra_class: str = "", admin: bool = False) -> str:
    full = f"{title} | {page.site_name}" if title else page.site_name
    desc = description or f"{page.site_name}: منصة سعودية لإيجار الاستراحات. ابحث بالمدينة والسعر والتاريخ وتواصل مع صاحب الاستراحة مباشرة عبر واتساب."
    robots = '<meta name="robots" content="noindex, nofollow">' if noindex else ""
    canon = f'<link rel="canonical" href="{e(page.site_url + canonical)}">' if page.site_url and canonical else ""
    og_img = f'<meta property="og:image" content="{e(image)}">' if image else ""
    if admin:
        earn = (f'<a href="/admin/earnings" aria-label="الأرباح، {page.waiting} بلاغ سداد بانتظار التأكيد">الأرباح<span class="nbadge">{page.waiting}</span></a>'
                if page.waiting else '<a href="/admin/earnings">الأرباح</a>')
        nav = ('<a href="/admin">اللوحة</a><a href="/admin/listings">الإعلانات</a><a href="/admin/rentals">التأجير</a>'
               f'{earn}'
               '<a href="/admin/commission">العمولة</a><a href="/admin/owners">الملاك</a><a href="/admin/offers">العروض</a><a href="/admin/settings">الإعدادات</a>')
        account = (f'<form method="post" action="/admin/logout" class="inline"><input type="hidden" name="_csrf" value="{e(page.csrf)}">'
                   '<button class="link" type="submit">خروج</button></form>') if page.admin_user else ""
    else:
        nav = '<a href="/search">الاستراحات</a><a href="/offers">العروض</a>'
        if page.user:
            account = ('<a href="/owner">إعلاناتي</a><a href="/owner/commissions">عمولاتي</a>'
                       f'<form method="post" action="/owner/logout" class="inline"><input type="hidden" name="_csrf" value="{e(page.csrf)}">'
                       '<button class="link" type="submit">خروج</button></form>')
        else:
            account = '<a href="/owner/login">دخول الملاك</a>'
    cta = "" if admin else '<a class="btn sun small add" href="/owner/new">أضف استراحتك</a>'
    return f"""<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{e(full)}</title>
<meta name="description" content="{e(desc)}">
<meta name="theme-color" content="#0a5c66">
<meta property="og:title" content="{e(full)}"><meta property="og:description" content="{e(desc)}"><meta property="og:locale" content="ar_SA">
{og_img}{robots}{canon}
<link rel="icon" href="/static/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="/static/app.css?v={__version__}">
</head>
<body class="{e(extra_class)}">
<a class="skip" href="#main">تخطي إلى المحتوى</a>
<header class="top"><div class="wrap bar">
<a class="brand" href="{'/admin' if admin else '/'}"><svg viewBox="0 0 32 32" width="30" height="30" aria-hidden="true"><rect width="32" height="32" rx="9" fill="#0e8a94"/><path d="M5 20c3-3 6-3 9 0s6 3 9 0M5 14c3-3 6-3 9 0s6 3 9 0" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round"/><circle cx="23" cy="8" r="3" fill="#f29e38"/></svg><span>{e(page.site_name)}</span></a>
{cta}<nav class="nav" aria-label="القائمة">{nav}{account}</nav>
</div></header>
<main id="main" class="wrap main">{body}</main>
<footer class="foot"><div class="wrap"><p>{e(page.site_name)}: منصة للتعريف بالاستراحات. الحجز والدفع يتمان مباشرة بين العميل وصاحب الاستراحة عبر واتساب.</p>
<p><a href="/terms">الشروط والأحكام</a> · <a href="/privacy">الخصوصية</a> · <a href="/owner/new">أضف استراحتك</a></p></div></footer>
<script src="/static/app.js?v={__version__}" defer></script>
</body></html>"""


def field(label: str, name: str, value="", *, type: str = "text", error: str = "", hint: str = "", required: bool = False,
          attrs: str = "", autocomplete: str = "") -> str:
    err = f'<p class="err" id="e-{e(name)}">{e(error)}</p>' if error else ""
    hint_html = f'<p class="hint">{e(hint)}</p>' if hint else ""
    ac = f' autocomplete="{e(autocomplete)}"' if autocomplete else ""
    req = " required" if required else ""
    return (f'<div class="f{" bad" if error else ""}"><label for="f-{e(name)}">{e(label)}</label>'
            f'<input id="f-{e(name)}" name="{e(name)}" type="{e(type)}" value="{e(value)}"{req}{ac} {attrs}>{hint_html}{err}</div>')


def textarea(label: str, name: str, value="", *, error: str = "", hint: str = "", rows: int = 5) -> str:
    err = f'<p class="err">{e(error)}</p>' if error else ""
    hint_html = f'<p class="hint">{e(hint)}</p>' if hint else ""
    return (f'<div class="f{" bad" if error else ""}"><label for="f-{e(name)}">{e(label)}</label>'
            f'<textarea id="f-{e(name)}" name="{e(name)}" rows="{rows}">{e(value)}</textarea>{hint_html}{err}</div>')


def select(label: str, name: str, options: list[tuple], selected="", *, error: str = "", blank: str = "", hint: str = "") -> str:
    opts = f'<option value="">{e(blank)}</option>' if blank else ""
    for value, text in options:
        opts += f'<option value="{e(value)}"{" selected" if str(value) == str(selected) else ""}>{e(text)}</option>'
    err = f'<p class="err">{e(error)}</p>' if error else ""
    hint_html = f'<p class="hint">{e(hint)}</p>' if hint else ""
    return (f'<div class="f{" bad" if error else ""}"><label for="f-{e(name)}">{e(label)}</label>'
            f'<select id="f-{e(name)}" name="{e(name)}">{opts}</select>{hint_html}{err}</div>')


def checks(name: str, options: list[tuple], selected: set) -> str:
    out = ""
    for value, text in options:
        out += (f'<label class="chk"><input type="checkbox" name="{e(name)}" value="{e(value)}"'
                f'{" checked" if value in selected else ""}><span>{e(text)}</span></label>')
    return f'<div class="chks">{out}</div>'


def csrf_input(token: str) -> str:
    return f'<input type="hidden" name="_csrf" value="{e(token)}">'


def notice(kind: str, text: str) -> str:
    return f'<p class="note {e(kind)}" role="status">{e(text)}</p>' if text else ""


def price_html(item: dict) -> str:
    unit = repo.UNIT_SHORT.get(item["unit"], "")
    if item.get("discount"):
        return (f'<span class="price"><b>{num(item["final_price"])}</b> ر.س <small>/ {e(unit)}</small></span>'
                f'<s class="was">{num(item["price"])}</s>')
    return f'<span class="price"><b>{num(item["price"])}</b> ر.س <small>/ {e(unit)}</small></span>'


def card(item: dict, amenity_names: list[str] | None = None) -> str:
    cover = (f'<img src="/media/{e(item["cover"])}" alt="{e(item["title"])}" loading="lazy" width="640" height="480">'
             if item.get("cover") else '<div class="noimg" aria-hidden="true"></div>')
    badge = f'<span class="badge">خصم {item["discount"]}%</span>' if item.get("discount") else ""
    if item.get("featured"):
        badge += '<span class="badge star">مميزة</span>'
    place = item["city_name"] + (f" · {item['district']}" if item.get("district") else "")
    chips = "".join(f"<li>{e(a)}</li>" for a in (amenity_names or [])[:3])
    return (f'<a class="card" href="/r/{item["id"]}"><div class="shot">{cover}{badge}</div>'
            f'<div class="info"><h3>{e(item["title"])}</h3><p class="where">{e(place)} · {e(item["category_name"])}</p>'
            f'{"<ul class=chips>" + chips + "</ul>" if chips else ""}<p class="priceline">{price_html(item)}</p></div></a>')


def pager(page: int, total: int, base: str) -> str:
    pages = max(1, -(-total // repo.PAGE_SIZE))
    if pages <= 1:
        return ""
    sep = "&" if "?" in base else "?"
    prev = f'<a class="btn ghost small" href="{e(base)}{sep}page={page - 1}">السابق</a>' if page > 1 else ""
    nxt = f'<a class="btn ghost small" href="{e(base)}{sep}page={page + 1}">التالي</a>' if page < pages else ""
    return f'<nav class="pager" aria-label="الصفحات">{prev}<span>صفحة {page} من {pages}</span>{nxt}</nav>'
