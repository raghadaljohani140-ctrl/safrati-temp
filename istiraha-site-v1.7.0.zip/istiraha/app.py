"""The website: routing, sessions, request checks. The pages themselves are in views_public, views_owner, views_admin, views_money and views_offers."""
from __future__ import annotations

import asyncio
import logging
import re
import secrets
import time
from pathlib import Path
from urllib.parse import unquote, urlsplit

from . import security, ui
from .db import Database
from .server import PERMISSIONS_WITH_PLACE, Request, Response, content_security_policy, cookie, redirect, text_response
from .settings import Settings

log = logging.getLogger("istiraha")

OWNER_COOKIE, ADMIN_COOKIE, PRE_COOKIE = "ist_o", "ist_a", "ist_c"
OWNER_SESSION_DAYS, ADMIN_SESSION_HOURS = 30, 12
LOCK_AFTER, OWNER_LOCK_MINUTES, ADMIN_LOCK_MINUTES = 5, 15, 30
STATIC_DIR = Path(__file__).resolve().parent / "static"
STATIC_SUBFOLDERS = ("vendor/leaflet/", "vendor/leaflet/images/")      # the only folders inside static/ that are served (the map library, as its makers ship it)
STATIC_TYPES = {".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".svg": "image/svg+xml",
                ".png": "image/png", ".jpg": "image/jpeg", ".webp": "image/webp", ".webmanifest": "application/manifest+json", ".txt": "text/plain; charset=utf-8"}
# a hash nobody can match: used so a wrong login takes as long when the account does not exist
_DUMMY_HASH = security.hash_password("not-a-real-account")


_TUNNEL_HOST = re.compile(r"[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*\.trycloudflare\.com")


class Ctx:
    """Everything one request needs: who is visiting, which database, the form check token."""

    def __init__(self, app: "App", request: Request):
        self.app, self.request, self.db, self.settings = app, request, app.db, app.settings
        self.new_cookies: list[str] = []
        self._flash_text: str | None = None
        self.owner = self._session(OWNER_COOKIE, "owner")
        self.admin = self._session(ADMIN_COOKIE, "admin") if request.path.startswith("/admin") else None
        pre = request.cookies.get(PRE_COOKIE, "")
        if not re.fullmatch(r"[A-Za-z0-9_-]{20,64}", pre):
            pre = security.new_token()
            self.new_cookies.append(cookie(PRE_COOKIE, pre, max_age=86400 * 30, secure=self.settings.cookie_secure))
        self.pre = pre

    def _session(self, name: str, role: str):
        token = self.request.cookies.get(name, "")
        if not token or len(token) > 100:
            return None
        row = self.db.one(
            "SELECT s.csrf, s.expires_at, u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?",
            (security.token_hash(token),))
        if not row or row["expires_at"] < self.app.clock() or row["role"] != role or row["status"] != "active":
            return None
        return row

    @property
    def base_url(self) -> str:
        """The address to put inside a WhatsApp message: the configured one, or, while the site is shown through a
        free Cloudflare test link, the link the visitor is on. Any other host name is ignored."""
        if self.settings.site_url:
            return self.settings.site_url
        host = self.request.headers.get("host", "").strip().lower()
        return f"https://{host}" if _TUNNEL_HOST.fullmatch(host) else ""

    @property
    def csrf(self) -> str:
        path = self.request.path
        if path.startswith("/admin"):
            return self.admin["csrf"] if self.admin else self.pre
        return self.owner["csrf"] if self.owner else self.pre

    def flash(self) -> str:
        """The one-time message left by the page before (shown once). A visitor cannot write his own: only a token travels in the address."""
        if self._flash_text is None:
            self._flash_text = self.app.take_flash(self.request.query.get("m", ""))
        return self._flash_text

    def page(self) -> ui.Page:
        waiting = self.db.one("SELECT COUNT(*) AS n FROM payment_reports WHERE status = 'pending'")["n"] if self.admin else 0
        return ui.Page(self.settings.site_name, self.settings.site_url, self.owner, self.csrf, self.admin, waiting)

    def today(self):
        from . import util
        return util.today(self.app.clock)

    def start_session(self, user_id: int, role: str) -> list[str]:
        token = security.new_token()
        now = self.app.clock()
        ttl = OWNER_SESSION_DAYS * 86400 if role == "owner" else ADMIN_SESSION_HOURS * 3600
        self.db.run("DELETE FROM sessions WHERE expires_at < ?", (now,))
        self.db.run("INSERT INTO sessions(token_hash, user_id, csrf, created_at, expires_at) VALUES (?, ?, ?, ?, ?)",
                    (security.token_hash(token), user_id, security.new_token(), now, now + ttl))
        name, path = (OWNER_COOKIE, "/") if role == "owner" else (ADMIN_COOKIE, "/admin")
        return [cookie(name, token, max_age=ttl, secure=self.settings.cookie_secure, path=path)]

    def end_session(self, role: str) -> list[str]:
        name, path = (OWNER_COOKIE, "/") if role == "owner" else (ADMIN_COOKIE, "/admin")
        token = self.request.cookies.get(name, "")
        if token:
            self.db.run("DELETE FROM sessions WHERE token_hash = ?", (security.token_hash(token),))
        return [cookie(name, "", max_age=0, secure=self.settings.cookie_secure, path=path)]


Route = tuple[str, "re.Pattern[str]", str, object]


class App:
    def __init__(self, settings: Settings, db: Database, clock=time.time):
        self.settings, self.db, self.clock = settings, db, clock
        self.routes: list[Route] = []
        self.login_limit = security.Limiter(settings.login_per_minute, 60.0)
        self.register_limit = security.Limiter(settings.register_per_hour, 3600.0)
        self.click_limit = security.Limiter(30, 60.0)
        self._flash: dict[str, tuple[str, float]] = {}
        from . import views_admin, views_founders, views_money, views_offers, views_owner, views_public
        for module in (views_public, views_owner, views_admin, views_money, views_offers, views_founders):
            module.register(self)

    # ---- routing -----------------------------------------------------------------------------------
    def route(self, method: str, pattern: str, area: str = "public"):
        compiled = re.compile("^" + pattern + "$")

        def wrap(func):
            self.routes.append((method, compiled, area, func))
            return func
        return wrap

    def put_flash(self, text: str) -> str:
        now = self.clock()
        for key in [k for k, (_, at) in self._flash.items() if now - at > 300]:
            del self._flash[key]
        while len(self._flash) >= 500:
            self._flash.pop(next(iter(self._flash)))
        token = secrets.token_urlsafe(9)
        self._flash[token] = (text[:200], now)
        return token

    def take_flash(self, token: str) -> str:
        entry = self._flash.pop(token, None) if token else None
        return entry[0] if entry and self.clock() - entry[1] <= 300 else ""

    def body_limit(self, path: str) -> int:
        if re.fullmatch(r"/owner/listing/\d+/photo", path):
            return (self.settings.max_upload_mb + 1) * 1024 * 1024 * 3
        return 64 * 1024

    async def handle(self, request: Request) -> Response:
        ctx = Ctx(self, request)
        try:
            response = await self._dispatch(ctx)
        except _Stop as stop:
            response = stop.response
        response.cookies = [*ctx.new_cookies, *response.cookies]
        location = response.headers.get("Location", "")
        found = re.search(r"([?&])msg=([^&#]*)", location)
        if found:                                          # a message for the next page travels as a one-time token, never as text
            token = self.put_flash(unquote(found.group(2)))
            response.headers["Location"] = location.replace(found.group(0), f"{found.group(1)}m={token}")
        response.headers.setdefault("Cache-Control", "no-store" if request.method == "POST" or ctx.owner or request.path.startswith("/admin") else "no-cache")
        return response

    async def _dispatch(self, ctx: Ctx) -> Response:
        request = ctx.request
        method = "GET" if request.method == "HEAD" else request.method
        allowed = False
        for m, pattern, area, func in self.routes:
            found = pattern.match(request.path)
            if not found:
                continue
            allowed = True
            if m != method:
                continue
            if area == "owner" and not ctx.owner:
                return redirect("/owner/login?next=" + _safe_next(request.path))
            if area == "admin" and not ctx.admin:
                return redirect("/admin/login")
            if method == "POST":
                self._check_post(ctx, area)
            return await func(ctx, *found.groups())
        if allowed:
            return Response(405, b"method", "text/plain", {"Allow": "GET, HEAD, POST"})
        return not_found(ctx)

    def _check_post(self, ctx: Ctx, area: str) -> None:
        request = ctx.request
        origin = request.headers.get("origin", "")
        if origin and origin != "null":
            host = urlsplit(origin).netloc
            expected = {request.headers.get("host", "")}
            if self.settings.site_url:
                expected.add(urlsplit(self.settings.site_url).netloc)
            if host not in expected:
                raise _Stop(text_response(403, "طلب مرفوض"))
        elif origin == "null":
            raise _Stop(text_response(403, "طلب مرفوض"))
        if request.path.startswith("/api/"):
            return                                   # counters only, nothing a visitor can break
        try:
            sent = request.field("_csrf")
        except ValueError:
            raise _Stop(text_response(400, "طلب غير صحيح")) from None
        if not security.same(sent, ctx.csrf):
            raise _Stop(text_response(403, "انتهت صلاحية الصفحة، ارجع للخلف وحدّثها ثم أعد المحاولة"))


class _Stop(Exception):
    def __init__(self, response: Response):
        self.response = response


def _safe_next(path: str) -> str:
    return path if re.fullmatch(r"/[A-Za-z0-9_/-]{0,100}", path) else "/owner"


def not_found(ctx: Ctx) -> Response:
    body = ui.layout(ctx.page(), "الصفحة غير موجودة", '<section class="empty"><h1>الصفحة غير موجودة</h1>'
                     '<p>الرابط قد يكون قديمًا أو غير صحيح.</p><a class="btn" href="/">الرئيسية</a></section>', noindex=True)
    return Response(404, body.encode())


def html_page(ctx: Ctx, title: str, body: str, status: int = 200, *, headers: dict | None = None, **kw) -> Response:
    return Response(status, ui.layout(ctx.page(), title, body, **kw).encode(), headers=dict(headers or {}))


def map_headers(ctx: Ctx, *, tiles: bool = True) -> dict[str, str]:
    """What a page that asks for the device's place, and (when `tiles`) shows the map, changes in the default headers: the geolocation
    permission for the site itself, and the one server the map pictures come from added to the image rule. Every other page keeps the
    default headers exactly."""
    headers = {"Permissions-Policy": PERMISSIONS_WITH_PLACE}
    if tiles:
        headers["Content-Security-Policy"] = content_security_policy(ctx.settings.map_tile_origin)
    return headers


def forbidden(ctx: Ctx) -> Response:
    return html_page(ctx, "غير مسموح", '<section class="empty"><h1>غير مسموح</h1><p>هذه الصفحة ليست لك.</p><a class="btn" href="/">الرئيسية</a></section>', 403, noindex=True)


async def verify_login(ctx: Ctx, role: str, login: str, password: str) -> tuple[object | None, str]:
    """(user, "") or (None, message). The same slow check runs whether or not the account exists."""
    app = ctx.app
    if not app.login_limit.allow(f"{role}:{ctx.request.ip}"):
        return None, "محاولات كثيرة، انتظر دقيقة ثم جرّب"
    user = ctx.db.one("SELECT * FROM users WHERE login = ? AND role = ?", (login, role))
    now = app.clock()
    if user and user["locked_until"] > now:
        await asyncio.to_thread(security.check_password, password, _DUMMY_HASH)
        return None, "الحساب مقفل مؤقتًا بسبب محاولات خاطئة، جرّب بعد قليل"
    ok = await asyncio.to_thread(security.check_password, password, user["pass_hash"] if user else _DUMMY_HASH)
    if not user or not ok:
        if user:
            failed = user["failed"] + 1
            lock = now + (ADMIN_LOCK_MINUTES if role == "admin" else OWNER_LOCK_MINUTES) * 60 if failed >= LOCK_AFTER else 0
            ctx.db.run("UPDATE users SET failed = ?, locked_until = ? WHERE id = ?", (0 if lock else failed, lock, user["id"]))
            if lock:
                ctx.db.audit(user["id"], "lockout", role)
        return None, "بيانات الدخول غير صحيحة"
    if user["status"] != "active":
        return None, "هذا الحساب موقوف، تواصل مع إدارة المنصة"
    ctx.db.run("UPDATE users SET failed = 0, locked_until = 0, last_login = ? WHERE id = ?", (now, user["id"]))
    return user, ""
