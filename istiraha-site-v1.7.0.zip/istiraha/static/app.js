(function () {
  'use strict';
  function $(sel, root) { return (root || document).querySelector(sel); }

  // the photos of an advert: a thumbnail shows in the big frame
  var main = $('#main-photo');
  document.querySelectorAll('.th').forEach(function (a) {
    a.addEventListener('click', function (ev) {
      if (!main) return;
      ev.preventDefault();
      main.src = a.getAttribute('data-full');
      document.querySelectorAll('.th.on').forEach(function (x) { x.classList.remove('on'); });
      a.classList.add('on');
    });
  });

  // counting the WhatsApp button (the chat opens anyway)
  var wa = $('#wa');
  if (wa) {
    wa.addEventListener('click', function () {
      try { if (navigator.sendBeacon) navigator.sendBeacon('/api/click/' + wa.getAttribute('data-id')); } catch (e) { /* the count is not important */ }
    });
  }

  document.querySelectorAll('[data-copy]').forEach(function (b) {
    var link = b.getAttribute('data-copy') || window.location.href;
    b.addEventListener('click', function () {
      var done = function () { var old = b.textContent; b.textContent = 'تم النسخ'; setTimeout(function () { b.textContent = old; }, 1800); };
      var ask = b.getAttribute('data-prompt') || 'انسخ الرابط';
      if (navigator.clipboard) navigator.clipboard.writeText(link).then(done, function () { window.prompt(ask, link); });
      else window.prompt(ask, link);
    });
  });

  // the report of a transfer: the total follows the ticks, and the button waits until something is ticked
  var sumForm = $('form[data-sum]');
  if (sumForm) {
    var out = $('#sum', sumForm), go = $('button[type=submit]', sumForm), boxes = sumForm.querySelectorAll('input[data-h]');
    var recount = function () {
      var halalas = 0;
      Array.prototype.forEach.call(boxes, function (b) { if (b.checked) halalas += parseInt(b.getAttribute('data-h'), 10) || 0; });
      var whole = Math.floor(halalas / 100), part = halalas % 100;
      if (out) out.textContent = whole.toLocaleString('en-US') + (part ? '.' + (part < 10 ? '0' : '') + part : '');
      if (go) go.disabled = halalas === 0;
    };
    Array.prototype.forEach.call(boxes, function (b) { b.addEventListener('change', recount); });
    recount();
  }

  // «الأقرب إليك»: the phone's place is asked for only when the button is pressed, and the page opens again with that place in its address
  var near = $('#near-btn');
  if (near && navigator.geolocation) {
    var nearMsg = $('#near-msg');
    near.hidden = false;
    near.addEventListener('click', function () {
      near.disabled = true;
      nearMsg.textContent = 'جارٍ تحديد موقعك…';
      navigator.geolocation.getCurrentPosition(function (pos) {
        var base = near.getAttribute('data-href') || '/search';
        window.location.href = base + (base.indexOf('?') < 0 ? '?' : '&') + 'lat=' + pos.coords.latitude.toFixed(3) + '&lng=' + pos.coords.longitude.toFixed(3) + '&km=25';
      }, function (err) {
        near.disabled = false;
        nearMsg.textContent = err && err.code === 1 ? 'لم يُسمح للموقع بتحديد مكانك. فعّل إذن الموقع للمتصفح من إعدادات الجهاز ثم أعد المحاولة.'
          : err && err.code === 3 ? 'انتهت مهلة تحديد الموقع، أعد المحاولة.' : 'تعذّر تحديد موقعك الآن، جرّب في مكان مفتوح.';
      }, { enableHighAccuracy: false, timeout: 12000, maximumAge: 300000 });
    });
  }

  // photo upload: choosing photos starts the upload at once. Each picture is made smaller on the phone first (this also
  // removes its hidden location data) and sent one by one; every picture shows its own result, with the reason when it is refused.
  var form = $('form.upload');
  if (form && window.fetch && window.FormData && window.Promise && document.createElement('canvas').toBlob) {
    try {
      var input = $('#photos', form), list = $('#upload-list', form), status = $('#upload-status', form);
      var csrf = $('input[name=_csrf]', form).value;
      var maxBytes = parseInt(form.getAttribute('data-max') || '8', 10) * 1024 * 1024;
      var room = parseInt(form.getAttribute('data-left') || '12', 10);
      var pick = $('.pick', form), path = window.location.pathname, SIDE = 1800, working = false, after = null;
      form.className += ' js';          // the plain button for phones without this script is hidden

      var el = function (tag, cls, text) {
        var n = document.createElement(tag);
        if (cls) n.className = cls;
        if (text) n.textContent = text;
        return n;
      };
      var say = function (text) { status.textContent = text; };
      var kind = function (f) { return ' [' + (f.type || 'بدون نوع') + ']'; };          // shown after a refusal, so a screenshot says what the phone handed over
      var sizeText = function (bytes) { return bytes < 1048576 ? Math.max(1, Math.round(bytes / 1024)) + ' ك.ب' : (bytes / 1048576).toFixed(1).replace('.', '٫') + ' م.ب'; };

      // the picture drawn smaller (white behind it, so a transparent picture does not turn black) and saved as JPEG
      var shrink = function (file) {
        return new Promise(function (resolve, reject) {
          var img = new Image(), url = URL.createObjectURL(file), over = false, timer;
          var end = function (fn, value) {
            if (over) return;
            over = true; clearTimeout(timer); img.onload = img.onerror = null;
            try { URL.revokeObjectURL(url); } catch (e) { /* nothing to free */ }
            fn(value);
          };
          timer = setTimeout(function () { end(reject, 'slow'); }, 30000);
          img.onload = function () {
            try {
              var w = img.naturalWidth, h = img.naturalHeight;
              if (!w || !h) { end(reject, 'size'); return; }
              var scale = Math.min(1, SIDE / Math.max(w, h)), c = document.createElement('canvas');
              c.width = Math.max(1, Math.round(w * scale)); c.height = Math.max(1, Math.round(h * scale));
              var g = c.getContext('2d');
              g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height);
              g.drawImage(img, 0, 0, c.width, c.height);
              c.toBlob(function (blob) { c.width = c.height = 0; if (blob) end(resolve, blob); else end(reject, 'blob'); }, 'image/jpeg', 0.85);
            } catch (e) { end(reject, 'canvas'); }
          };
          img.onerror = function () { end(reject, 'decode'); };
          img.src = url;
        });
      };

      // the picture to send, or the reason (in words the owner can use) why it cannot be sent
      var prepare = function (file) {
        if (file.type && !/^image\//.test(file.type)) return Promise.reject('هذا الملف ليس صورة');
        return shrink(file).then(function (blob) {
          if (blob.size > maxBytes) return Promise.reject('الصورة كبيرة حتى بعد التصغير');
          return blob;
        }, function () {
          if (!file.size) return Promise.reject('الصورة فارغة أو ما نزلت كاملة من الجهاز، جرّب مرة ثانية');
          if (/^image\/(jpeg|png|webp)$/.test(file.type) && file.size <= maxBytes) return file;      // the site itself can read these as they are
          if (/heic|heif/i.test(file.type + ' ' + (file.name || ''))) return Promise.reject('صيغة HEIC ما فتحها المتصفح. اختر الصورة من مكتبة الصور أو غيّر الإعدادات ← الكاميرا ← التنسيقات ← الأكثر توافقًا');
          return Promise.reject('ما قدر المتصفح يفتح هذه الصورة');
        });
      };

      // one picture to the site; a busy site or a dropped connection gets two more tries
      var send = function (blob) {
        var attempt = function (n) {
          return new Promise(function (resolve) {
            var data = new FormData();
            data.append('_csrf', csrf);
            data.append('fetch', '1');          // tells the site to answer in plain words (the header below says the same, a proxy cannot remove this one)
            data.append('photo', blob, 'photo.jpg');
            var ctl = window.AbortController ? new AbortController() : null;
            var timer = setTimeout(function () { if (ctl) ctl.abort(); }, 90000);
            var again = function (why, wait) {
              if (n < 3) setTimeout(function () { resolve(attempt(n + 1)); }, wait || 1500);
              else resolve({ ok: false, why: why });
            };
            fetch(form.action, { method: 'POST', body: data, headers: { 'X-Requested-With': 'fetch' }, credentials: 'same-origin', signal: ctl ? ctl.signal : undefined })
              .then(function (r) {
                clearTimeout(timer);
                var plain = /^text\/plain/.test(r.headers.get('content-type') || '');
                return r.text().then(function (t) {
                  if (r.ok && plain) { resolve({ ok: true }); return; }
                  if (r.ok) { resolve({ ok: false, why: 'انتهت جلستك، سجّل الدخول من جديد ثم أعد المحاولة' }); return; }
                  if (r.status === 429) { again('طلبات كثيرة، انتظر قليلًا ثم أعد المحاولة (429)', (parseInt(r.headers.get('retry-after') || '2', 10) + 1) * 1000); return; }
                  if (r.status >= 500 || r.status === 408) { again('الموقع مشغول الآن، أعد المحاولة بعد قليل (' + r.status + ')'); return; }
                  resolve({ ok: false, why: (plain && t ? t.slice(0, 200) : 'رفضها الموقع') + ' (' + r.status + ')' });
                });
              })
              .catch(function () {
                clearTimeout(timer);
                again('انقطع الاتصال أثناء الرفع، تأكد من الإنترنت وأعد المحاولة');
              });
          });
        };
        return attempt(1);
      };

      var row = function (file, n) {
        var li = el('li'), img = el('img'), box = el('span', 'what'), st = el('span', 'st', 'في الانتظار');
        img.alt = ''; img.width = 56; img.height = 42; img.hidden = true;
        img.onerror = function () { img.hidden = true; };
        img.onload = function () { img.hidden = false; };
        box.appendChild(el('span', 'name', 'صورة ' + n + (file.size ? ' · ' + sizeText(file.size) : '')));
        box.appendChild(st); li.appendChild(img); li.appendChild(box); list.appendChild(li);
        return {
          file: file,
          show: function (kind, text) { li.className = kind; st.textContent = text; },
          thumb: function (blob) { try { img.src = URL.createObjectURL(blob); } catch (e) { /* only the small preview is missing */ } }
        };
      };

      var start = function (picked) {
        working = true; input.disabled = true; if (pick) pick.className += ' off';
        list.textContent = '';
        Array.prototype.forEach.call(document.querySelectorAll('main .note.ok'), function (n) { n.parentNode.removeChild(n); });      // the message of the previous visit is out of date now
        if (after && after.parentNode) after.parentNode.removeChild(after);
        var rows = picked.map(function (f, k) { return row(f, k + 1); });
        var go = rows.slice(0, Math.max(0, room));
        rows.slice(go.length).forEach(function (r) { r.show('bad', 'تجاوزت الحد الأعلى للصور، احذف صورة لتضيف غيرها'); });
        var ok = 0, i = 0;
        var finish = function () {
          working = false; input.value = ''; input.disabled = false; if (pick) pick.className = pick.className.replace(' off', '');
          var failed = picked.length - ok;
          if (ok && !failed) { say('تم رفع ' + ok + ' ✓'); window.location.href = path + '?up=' + ok; return; }
          room -= ok;
          if (room <= 0) { input.disabled = true; if (pick) pick.className += ' off'; }
          say(ok ? 'رُفعت ' + ok + ' من ' + picked.length + '، والباقي سببه مكتوب تحت كل صورة.' : 'ما انرفعت أي صورة، السبب مكتوب تحت كل صورة.');
          if (ok) {
            after = el('a', 'btn go', 'عرض الصور المرفوعة');
            after.href = path + '?up=' + ok + '&bad=1';
            list.parentNode.insertBefore(after, list.nextSibling);
          }
        };
        var next = function () {
          if (i >= go.length) { finish(); return; }
          var item = go[i++];
          say('جاري رفع الصورة ' + i + ' من ' + go.length + '…');
          item.show('run', 'يجهّز الصورة…');
          prepare(item.file).then(function (blob) {
            item.thumb(blob);
            item.show('run', 'يرفع…');
            return send(blob);
          }).then(function (res) {
            if (res.ok) { ok++; item.show('ok', 'تم الرفع'); } else { item.show('bad', res.why + kind(item.file)); }
          }, function (why) {
            item.show('bad', why + kind(item.file));
          }).then(next, next);
        };
        say('جاري تجهيز ' + picked.length + ' من الصور…');
        if (list.scrollIntoView) list.scrollIntoView({ block: 'nearest' });
        next();
      };

      var chosen = function () { return Array.prototype.slice.call(input.files || []); };
      input.addEventListener('change', function () { if (!working && chosen().length) start(chosen()); });
      // a phone that does not announce the choice is noticed anyway: pictures waiting in the chooser are sent within a second
      setInterval(function () { if (!working && chosen().length) start(chosen()); }, 1000);
      form.addEventListener('submit', function (ev) {
        ev.preventDefault();
        if (!working && chosen().length) start(chosen());
      });
    } catch (e) {
      form.className = form.className.replace(' js', '');          // anything unexpected: the plain button works again
    }
  }
})();
