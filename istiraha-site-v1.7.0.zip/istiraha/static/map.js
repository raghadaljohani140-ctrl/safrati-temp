/* The map of the site: the adverts on a map (search page, «عرض الخريطة») and the place picker of the owner (add / edit page).
   It needs the map library next to it (vendor/leaflet) and is loaded only by the pages that show a map. Nothing here is run from the
   page itself: the pages hand over their data in attributes, and every text is put in with textContent. */
(function () {
  'use strict';
  var L = window.L;
  if (!L) return;          // the library did not come: the list and the typed numbers still work

  function $(sel, root) { return (root || document).querySelector(sel); }
  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null && text !== '') n.textContent = text;
    return n;
  }
  function esc(t) { return String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  // a number typed with any digits ("٢٤٫٧١٣٦", "24,7136"); NaN when it is not one number
  function num(t) {
    t = String(t == null ? '' : t).replace(/[٠-٩]/g, function (d) { return d.charCodeAt(0) - 1632; })
      .replace(/[۰-۹]/g, function (d) { return d.charCodeAt(0) - 1776; }).replace(/[٫,،]/g, '.').replace(/\s+/g, '');
    return /^-?\d+(\.\d+)?$/.test(t) ? parseFloat(t) : NaN;
  }
  function problem(err) {
    if (err && err.code === 1) return 'لم يُسمح للموقع بتحديد مكانك. فعّل إذن الموقع للمتصفح من إعدادات الجهاز ثم أعد المحاولة.';
    if (err && err.code === 3) return 'انتهت مهلة تحديد الموقع، أعد المحاولة.';
    return 'تعذّر تحديد موقعك الآن، جرّب في مكان مفتوح.';
  }

  var KINGDOM = { south: 15.5, north: 33.0, west: 34.0, east: 56.5 };          // the same box the site checks when it saves a place
  var COPYRIGHT = 'https://www.openstreetmap.org/copyright';
  var HOME = [24.5, 45.0];                                                        // the Kingdom as a whole, when there is nothing else to show

  // A map in `node`: the pictures from the address the page gave, the credit in its corner (OpenStreetMap's wording is always there),
  // and a word when no picture comes at all (`trouble` is called once).
  function makeMap(node, trouble) {
    var map = L.map(node, { attributionControl: false, minZoom: 4, maxZoom: 18 });
    var src = node.closest('[data-tiles]') || node;          // the pictures' address is on the map's own box, or on the window that holds it
    var credit = src.getAttribute('data-credit') || '';
    L.control.attribution({ prefix: false, position: 'bottomright' })
      .addAttribution((credit ? esc(credit) + ' · ' : '') + '© <a href="' + COPYRIGHT + '" target="_blank" rel="noopener noreferrer">OpenStreetMap</a> contributors')
      .addTo(map);
    var address = src.getAttribute('data-tiles');
    if (!address) { if (trouble) trouble(); return map; }       // no address: no pictures, but the pins and the typed numbers still work
    var layer = L.tileLayer(address, { maxZoom: 18, referrerPolicy: 'strict-origin-when-cross-origin' }).addTo(map);
    var loaded = 0, failed = 0;
    layer.on('tileload', function () { loaded++; });
    layer.on('tileerror', function () {
      failed++;
      if (!loaded && failed === 6 && trouble) trouble();
    });
    return map;
  }

  // ---- the adverts on the map -------------------------------------------------------------------------------------
  function browse(node) {
    var slot = $('#pin-slot'), status = $('#map-status');
    var map = makeMap(node, function () { status.textContent = 'تعذّر تحميل صور الخريطة الآن. العلامات تعمل، ويمكنك استخدام عرض القائمة.'; });
    var items = Array.prototype.map.call(document.querySelectorAll('#pins li'), function (li) {
      var get = function (n) { return li.getAttribute('data-' + n) || ''; };
      return { id: get('id'), lat: parseFloat(get('lat')), lng: parseFloat(get('lng')), title: get('title'), price: get('price'), was: get('was'),
               unit: get('unit'), image: get('image'), place: get('place'), away: get('away') };
    }).filter(function (it) { return isFinite(it.lat) && isFinite(it.lng); });

    // the card under the map: picture, name, price; the whole card is the link to the advert's page
    var card = function (it) {
      var a = el('a', 'pincard'), pic = el('span', 'pc-img'), body = el('span', 'pc-body'), price = el('span', 'price');
      a.href = '/r/' + encodeURIComponent(it.id);
      if (it.image) {
        var im = new Image();
        im.alt = ''; im.width = 104; im.height = 100; im.src = '/media/' + encodeURIComponent(it.image);
        pic.appendChild(im);
      } else {
        pic.appendChild(el('div', 'noimg'));
      }
      price.appendChild(el('b', null, it.price));
      price.appendChild(document.createTextNode(' ر.س '));
      price.appendChild(el('small', null, '/ ' + it.unit));
      if (it.was) price.appendChild(el('s', 'was', it.was));
      body.appendChild(el('b', 'pc-title', it.title));
      body.appendChild(el('span', 'pc-meta', it.place));
      body.appendChild(price);
      if (it.away) body.appendChild(el('span', 'pc-away', '📍 تبعد ' + it.away));
      var go = el('span', 'pc-go', '‹');                 // the whole card is the link; the arrow only says so
      go.setAttribute('aria-hidden', 'true');
      a.appendChild(pic); a.appendChild(body); a.appendChild(go);
      return a;
    };

    var current = null;
    var choose = function (it, marker) {
      if (current) {
        var old = current.getElement();
        if (old) old.classList.remove('on');
        current.setZIndexOffset(0);
      }
      current = marker;
      var icon = marker.getElement();
      if (icon) icon.classList.add('on');
      marker.setZIndexOffset(1000);
      slot.textContent = '';
      slot.appendChild(card(it));
      if (slot.scrollIntoView) {
        var calm = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        slot.scrollIntoView({ block: 'nearest', behavior: calm ? 'auto' : 'smooth' });          // only if the card is not on the screen yet
      }
    };

    items.forEach(function (it) {
      var icon = L.divIcon({ className: 'pin', html: el('span', 'pv', it.price), iconSize: [76, 44], iconAnchor: [38, 22] });
      var marker = L.marker([it.lat, it.lng], { icon: icon, title: it.title, alt: it.title, keyboard: true }).addTo(map);
      marker.on('click', function () { choose(it, marker); });
    });

    // far away the price tags would cover each other: they become dots until the map is close enough
    var far = function () { node.classList.toggle('far', map.getZoom() < 11); };
    map.on('zoomend', far);

    var me = (node.getAttribute('data-me') || '').split(',');
    if (me.length === 2 && isFinite(parseFloat(me[0])) && isFinite(parseFloat(me[1]))) {
      var at = [parseFloat(me[0]), parseFloat(me[1])], km = parseFloat(node.getAttribute('data-km')) || 25;
      // the square around his place that holds the circle of the distance (a circle cannot say its size before the map has a view)
      map.fitBounds(L.latLng(at[0], at[1]).toBounds(km * 2000), { padding: [12, 12] });
      L.marker(at, { icon: L.divIcon({ className: 'me', html: el('i'), iconSize: [24, 24], iconAnchor: [12, 12] }), interactive: false, keyboard: false, zIndexOffset: -1000 }).addTo(map);          // under the price tags, never over one
      L.circle(at, { radius: km * 1000, color: '#2457c5', weight: 2, fillColor: '#2457c5', fillOpacity: 0.08, interactive: false }).addTo(map);
    } else if (items.length === 1) {
      map.setView([items[0].lat, items[0].lng], 14);
    } else if (items.length) {
      map.fitBounds(items.map(function (it) { return [it.lat, it.lng]; }), { padding: [40, 40], maxZoom: 15 });
    } else {
      map.setView(HOME, 5);
    }
    far();
  }

  // ---- the owner sets the place of his advert --------------------------------------------------------------------
  function pick(root) {
    var openBtn = $('#place-open'), clearBtn = $('#place-clear'), state = $('#place-state');
    var latIn = $('#f-lat'), lngIn = $('#f-lng'), citySel = $('#f-city');
    var closeBtn = $('#pk-close'), okBtn = $('#pk-ok'), meBtn = $('#pk-me'), msg = $('#pk-msg');
    if (!openBtn || !latIn || !lngIn) return;
    var centers = {};
    try { centers = JSON.parse(root.getAttribute('data-centers') || '{}'); } catch (e) { centers = {}; }
    var map = null, opener = null;

    var refresh = function () {
      var la = num(latIn.value), ln = num(lngIn.value), has = isFinite(la) && isFinite(ln);
      state.textContent = has ? 'تم تحديد الموقع ✓ (\u2066' + la.toFixed(5) + ', ' + ln.toFixed(5) + '\u2069)' : 'لم تحدد الموقع بعد';          // the numbers read left to right
      openBtn.textContent = has ? 'غيّر الموقع على الخريطة' : 'حدد الموقع على الخريطة';
      clearBtn.hidden = !(latIn.value.trim() || lngIn.value.trim());
    };

    var open = function () {
      opener = document.activeElement;
      root.hidden = false;
      document.documentElement.classList.add('noscroll');
      if (!map) map = makeMap($('#pick-map'), function () { msg.textContent = 'تعذّر تحميل صور الخريطة. أغلق هذه النافذة واكتب الإحداثيات بنفسك.'; });
      var la = num(latIn.value), ln = num(lngIn.value), c = citySel ? centers[citySel.value] : null;
      msg.textContent = 'قرّب الخريطة حتى يظهر الشارع، ثم ثبّت الموقع.';
      var jump = { animate: false };          // no gliding: a second request that comes while the map is still gliding is dropped by the library
      if (isFinite(la) && isFinite(ln)) map.setView([la, ln], 17, jump);
      else if (c) map.setView(c, 12, jump);
      else map.setView(HOME, 5, jump);
      setTimeout(function () { map.invalidateSize(); }, 60);          // the map was hidden while it was made
      closeBtn.focus();
    };
    var close = function () {
      root.hidden = true;
      document.documentElement.classList.remove('noscroll');
      if (opener && opener.focus) opener.focus();
    };

    openBtn.hidden = false;
    openBtn.addEventListener('click', open);
    closeBtn.addEventListener('click', close);
    clearBtn.addEventListener('click', function () { latIn.value = ''; lngIn.value = ''; refresh(); openBtn.focus(); });
    latIn.addEventListener('input', refresh);
    lngIn.addEventListener('input', refresh);

    okBtn.addEventListener('click', function () {
      var c = map.getCenter();
      if (c.lat < KINGDOM.south || c.lat > KINGDOM.north || c.lng < KINGDOM.west || c.lng > KINGDOM.east) {
        msg.textContent = 'هذا الموضع خارج المملكة، حرّك الخريطة إلى استراحتك.';
        return;
      }
      if (map.getZoom() < 14) {
        msg.textContent = 'قرّب الخريطة أكثر (حتى يظهر الشارع) ليكون الموقع دقيقًا.';
        return;
      }
      latIn.value = c.lat.toFixed(6);
      lngIn.value = c.lng.toFixed(6);
      refresh();
      close();
    });

    meBtn.addEventListener('click', function () {
      if (!navigator.geolocation) { msg.textContent = 'جهازك لا يدعم تحديد الموقع.'; return; }
      msg.textContent = 'جارٍ تحديد موقعك…';
      meBtn.disabled = true;
      navigator.geolocation.getCurrentPosition(function (pos) {
        meBtn.disabled = false;
        msg.textContent = 'قرّب العلامة على استراحتك بالضبط ثم ثبّت الموقع.';
        map.setView([pos.coords.latitude, pos.coords.longitude], 17, { animate: false });
      }, function (err) {
        meBtn.disabled = false;
        msg.textContent = problem(err);
      }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
    });

    // Escape closes it; Tab stays inside it while it is open
    root.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape') { close(); return; }
      if (ev.key !== 'Tab') return;
      var list = Array.prototype.filter.call(root.querySelectorAll('button, a[href], [tabindex="0"]'), function (n) { return !n.disabled && n.offsetParent !== null; });
      if (!list.length) return;
      var first = list[0], last = list[list.length - 1];
      if (ev.shiftKey && document.activeElement === first) { ev.preventDefault(); last.focus(); }
      else if (!ev.shiftKey && document.activeElement === last) { ev.preventDefault(); first.focus(); }
    });
    refresh();
  }

  var browseNode = $('#browse-map');
  if (browseNode) {
    try { browse(browseNode); }
    catch (e) {                                   // say it: an empty grey box with no word would look like a page that is still loading
      var st = $('#map-status');
      if (st) st.textContent = 'تعذّر عرض الخريطة الآن. يمكنك استخدام عرض القائمة.';
    }
  }
  var pickNode = $('#picker');
  if (pickNode) { try { pick(pickNode); } catch (e) { /* the typed numbers still work */ } }
})();
