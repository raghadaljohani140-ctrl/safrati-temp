"""Small, pure helpers: money, phone numbers, WhatsApp links, dates, places on the map."""
from __future__ import annotations

import re
import unicodedata
from datetime import date, datetime, timedelta, timezone
from decimal import ROUND_HALF_UP, Decimal
from math import asin, cos, radians, sin, sqrt
from urllib.parse import quote

SAUDI_TZ = timezone(timedelta(hours=3))

_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


def clean_text(text: str) -> str:
    """What a person typed, without what the eye cannot see. Phones with an Arabic keyboard often put invisible direction marks
    (and zero-width or odd space characters) around typed numbers, and a plain comparison then fails although the text looks right.
    Fullwidth and Arabic-Indic digits become 0-9 and every kind of space becomes a normal one."""
    out = []
    for ch in unicodedata.normalize("NFKC", text or ""):
        kind = unicodedata.category(ch)
        if kind in ("Cf", "Cs", "Co", "Cn"):
            continue
        out.append(" " if kind in ("Zs", "Zl", "Zp", "Cc") else ch)
    return re.sub(r" {2,}", " ", "".join(out).translate(_DIGITS)).strip()


def digits(text: str) -> str:
    """Western digits 0-9 only (Arabic-Indic and fullwidth digits are converted first, everything else is dropped)."""
    return re.sub(r"[^0-9]", "", clean_text(text))


def normalize_phone(text: str) -> str | None:
    """A Saudi mobile number as 9665XXXXXXXX, or None. Accepts 05…, 5…, 9665…, +9665…, 009665…"""
    d = digits(text)
    if d.startswith("00"):
        d = d[2:]
    if d.startswith("966"):
        d = d[3:]
    if d.startswith("0"):
        d = d[1:]
    if re.fullmatch(r"5[0-9]{8}", d):
        return "966" + d
    return None


def show_phone(number: str) -> str:
    return "0" + number[3:] if number.startswith("966") else number


def whatsapp_link(number: str, title: str, url: str) -> str:
    """The chat link with the greeting already written. The title and the advert's address are inside the message."""
    text = "السلام عليكم، أرغب بالاستفسار عن استراحتكم المنشورة في المنصة"
    if title:
        text += f" («{title}»)"
    text += "، وهل هي متاحة في التاريخ المطلوب؟"
    if url:
        text += f"\n{url}"
    return f"https://wa.me/{number}?text={quote(text, safe='')}"


def commission(rent_sar: int, basis_points: int) -> Decimal:
    """Commission in riyals, rounded to the halala. 10.00% is 1000 basis points: 500 SAR gives 50.00."""
    return (Decimal(rent_sar) * Decimal(basis_points) / Decimal(10000)).quantize(Decimal("0.01"), ROUND_HALF_UP)


def to_halalas(value: Decimal) -> int:
    return int((value * 100).to_integral_value(ROUND_HALF_UP))


def money(halalas: int) -> str:
    whole, part = divmod(int(halalas), 100)
    return f"{whole:,}" + (f".{part:02d}" if part else "")


def parse_percent(text: str) -> int | None:
    """"10" or "7.5" or "٧٫٥" or "10%" -> basis points (1000, 750); None when it is not a percentage between 0 and 100."""
    cleaned = clean_text(text).replace("٫", ".").replace("٬", "").replace(",", ".").replace("،", ".").replace("%", "").replace("٪", "").strip()
    if not re.fullmatch(r"[0-9]{1,3}(\.[0-9]{1,2})?", cleaned):
        return None
    bp = int((Decimal(cleaned) * 100).to_integral_value(ROUND_HALF_UP))
    return bp if 0 <= bp <= 10000 else None


def percent_text(bp: int) -> str:
    value = Decimal(bp) / Decimal(100)
    return f"{value.normalize():f}" if value == value.to_integral() else f"{value:.2f}".rstrip("0").rstrip(".")


# words a person may write next to a number ("300 ريال", "10 أشخاص"); anything else next to it ("3 آلاف") is refused, never guessed
PRICE_WORDS = frozenset({"ريال", "ريالات", "ريالا", "رس", "سعودي", "سعوديه", "فقط", "sar", "sr"})
PEOPLE_WORDS = frozenset({"شخص", "اشخاص", "شخصا", "فرد", "افراد", "نفر", "انفار", "ضيف", "ضيوف"})
_FOLD = str.maketrans({"أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا", "ى": "ي", "ی": "ي", "ة": "ه", "ک": "ك"})
_NOISE = re.compile(r"[.:;()\[\]{}«»\"'!؟?%٪+،,/\\|*_]")
_INT = re.compile(r"(?P<pre>[^0-9]*)(?P<num>[0-9]{1,3}(?:[,٬، ][0-9]{3})+|[0-9]+)(?:[.٫]0+)?(?P<post>[^0-9]*)")


def _only_words(chunk: str, words: frozenset) -> bool:
    chunk = "".join(ch for ch in chunk if unicodedata.category(ch) != "Mn" and ch != "ـ").translate(_FOLD).lower()
    chunk = _NOISE.sub(" ", chunk.replace(".", ""))          # "ر.س" becomes "رس"; punctuation around a unit is ignored
    return all(word in words for word in chunk.split())


def parse_int(text: str, low: int, high: int, words: frozenset = frozenset()) -> int | None:
    """A whole number written with any digits, with or without correctly placed thousands separators ("1,500", "١٬٥٠٠", "1 500"), a zero
    fraction ("300.00") and, when `words` allows them, a unit ("300 ريال"). Anything else (two numbers, "300.5", "3 آلاف", a minus) is refused."""
    found = _INT.fullmatch(clean_text(text))
    if not found or not (_only_words(found["pre"], words) and _only_words(found["post"], words)):
        return None
    number = re.sub(r"[,٬، ]", "", found["num"])
    if len(number) > 9:
        return None
    value = int(number)
    return value if low <= value <= high else None


def parse_date(text: str) -> date | None:
    try:
        return date.fromisoformat(clean_text(text))
    except ValueError:
        return None


def today(clock=None) -> date:
    now = datetime.fromtimestamp(clock(), SAUDI_TZ) if clock else datetime.now(SAUDI_TZ)
    return now.date()


# ---- places on the map ---------------------------------------------------------------------------------------
EARTH_KM = 6371.0088
# The adverts are all in the Kingdom, so a place an owner chooses must fall inside this generous box around it (a little of the
# neighbouring countries is inside it on purpose). It catches the usual slips: the two numbers swapped, a missing minus sign, 0 and 0.
KINGDOM_BOX = (15.5, 33.0, 34.0, 56.5)             # south, north, west, east
_COORD = re.compile(r"-?[0-9]{1,3}(?:\.[0-9]{1,12})?")


def parse_coord(text: str, low: float, high: float) -> float | None:
    """A latitude or a longitude as a person types it: "24.7136", "٢٤٫٧١٣٦", "24,7136", "-5.5". Rounded to six places (about ten
    centimetres). Anything else (two numbers, degrees and minutes, "NaN", "1e3", a number outside low..high) is refused, never guessed."""
    cleaned = clean_text(text).replace("٫", ".").replace("،", ".").replace(",", ".").replace("\u2212", "-")
    if not _COORD.fullmatch(cleaned):
        return None
    value = float(cleaned)
    return round(value, 6) if low <= value <= high else None


def split_pair(text: str) -> tuple[str, str] | None:
    """"24.7136, 46.6753" (what the map apps copy) -> ("24.7136", "46.6753"); None when it is not exactly two pieces."""
    cleaned = clean_text(text)
    tight = re.fullmatch(r"(-?[0-9]{1,3}\.[0-9]+),(-?[0-9]{1,3}\.[0-9]+)", cleaned)          # "24.7136,46.6753": a comma between two decimals is no decimal mark
    if tight:
        return tight.group(1), tight.group(2)
    parts = [p for p in re.split(r"\s*[;؛]\s*|\s*[,،]\s+|\s+", cleaned) if p]
    return (parts[0], parts[1]) if len(parts) == 2 else None


def in_kingdom(lat: float, lng: float) -> bool:
    south, north, west, east = KINGDOM_BOX
    return south <= lat <= north and west <= lng <= east


def distance_km(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    """The straight-line distance over the ground between two places (great circle, haversine)."""
    p1, p2 = radians(lat1), radians(lat2)
    a = sin((p2 - p1) / 2) ** 2 + cos(p1) * cos(p2) * sin(radians(lng2 - lng1) / 2) ** 2
    return 2 * EARTH_KM * asin(min(1.0, sqrt(a)))


def distance_text(km: float) -> str:
    """"أقل من 1 كم", "3.4 كم", "27 كم": a short distance keeps one decimal, a long one is a whole number."""
    if km < 1:
        return "أقل من 1 كم"
    return f"{km:.1f} كم" if km < 10 else f"{round(km)} كم"
