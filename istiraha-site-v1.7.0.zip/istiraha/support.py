"""How people reach the manager: one e-mail address he sets himself in the settings, and the «report this advert» message prepared for it.

Nothing is sent from the site and nothing about the person who reports is kept: the link opens his own mail app with a message that
already holds the advert's name and address, and he writes why. Until the manager has saved an address, no report link is shown."""
from __future__ import annotations

import re
from urllib.parse import quote

from .db import Database

KEY = "support_email"
_PART = r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?"
_ADDRESS = re.compile(rf"[A-Za-z0-9._%+-]{{1,64}}@(?:{_PART}\.)+[A-Za-z]{{2,24}}")


def clean_email(text: str) -> str | None:
    """The address as it should be kept (no spaces, the domain in lower case), "" for an empty text (it clears the setting), or None when
    what was typed cannot be an address."""
    text = text.strip()
    if not text:
        return ""
    if len(text) > 120 or not _ADDRESS.fullmatch(text):
        return None
    local, _, domain = text.rpartition("@")
    if local.startswith(".") or local.endswith(".") or ".." in local:
        return None
    return f"{local}@{domain.lower()}"


def address(db: Database) -> str:
    """The saved support address, or "" while the manager has not added one."""
    value = db.setting(KEY)
    return value if clean_email(value) else ""


def mailto(email: str, subject: str, body: str = "") -> str:
    """A link that opens the reader's mail app with the message already written (percent-encoded, so Arabic and new lines travel safely)."""
    return f"mailto:{email}?subject={quote(subject, safe='')}" + (f"&body={quote(body, safe='')}" if body else "")


def report_link(email: str, title: str, url: str) -> str:
    """The address of the prepared message that reports one advert: its name and its address in it, and a line left for the reason."""
    return mailto(email, f"بلاغ عن إعلان: {title[:60]}", f"أبلغ عن هذا الإعلان:\n{title[:120]}\n{url}\n\nسبب البلاغ (اكتبه هنا):\n")
