"""Deleting an owner's account.

Everything he made goes at once, and nothing of anybody else's is touched: his adverts with their pictures, blocked dates and facilities,
his offers, his rentals and their notes, his commission reports, his agreements, his sessions and the account itself. The founders' seat of
his adverts goes back to the pool, so another advert can take it.

The deletion is ONE database transaction: if a single step cannot be done (a row of somebody else still points at his, which should never
happen) the database refuses, the whole thing is rolled back and nothing is deleted. The picture files are removed from the disk after the
commit, so a rolled-back deletion never leaves an advert without its pictures.

What stays is only what tells nothing about him: the manager's own log lines that hold numbers (an advert number, a report number, an
amount), and ONE new line that says an account was deleted and how much it held, with no name, number or identity."""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from pathlib import Path

from . import util
from .db import Database

log = logging.getLogger("istiraha")

_FILE = re.compile(r"[0-9a-f]{32}\.(?:jpg|png|webp)")          # the only names the site ever gives a picture file
_UNPAID = "owner_id = ? AND status != 'cancelled' AND pay_status IN ('due', 'disputed')"      # a commission nobody has settled yet (reported but not yet confirmed counts)


@dataclass(frozen=True)
class Gone:
    """What a deletion removed: counts only, and the picture files still to be removed from the disk."""
    listings: int
    photos: int
    rentals: int
    unpaid_halalas: int
    files: tuple[str, ...]


def inventory(db: Database, owner_id: int) -> dict:
    """What the account holds right now (the numbers the deletion page tells him before he decides)."""
    def count(sql: str) -> int:
        return db.one(sql, (owner_id,))["n"]

    return {
        "listings": count("SELECT COUNT(*) AS n FROM listings WHERE owner_id = ?"),
        "photos": count("SELECT COUNT(*) AS n FROM photos WHERE listing_id IN (SELECT id FROM listings WHERE owner_id = ?)"),
        "offers": count("SELECT COUNT(*) AS n FROM offers WHERE owner_id = ?"),
        "rentals": count("SELECT COUNT(*) AS n FROM rentals WHERE owner_id = ?"),
        "unpaid_halalas": db.one(f"SELECT COALESCE(SUM(commission_halalas), 0) AS n FROM rentals WHERE {_UNPAID}", (owner_id,))["n"],
    }


def delete_owner(db: Database, owner_id: int) -> Gone | None:
    """Deletes the owner's account and everything of his, in one transaction. None when there is no such owner (an admin account is never
    deleted here). Raises sqlite3.IntegrityError, with nothing deleted, if the database refuses a step."""
    with db.transaction():
        user = db.one("SELECT * FROM users WHERE id = ? AND role = 'owner'", (owner_id,))
        if user is None:
            return None
        titles = [r["title"] for r in db.all("SELECT title FROM listings WHERE owner_id = ?", (owner_id,))]
        files = tuple(r["filename"] for r in db.all(
            "SELECT filename FROM photos WHERE listing_id IN (SELECT id FROM listings WHERE owner_id = ?)", (owner_id,)))
        held = inventory(db, owner_id)
        mine = "(SELECT id FROM listings WHERE owner_id = ?)"
        # payments first (they point at rentals), then rentals (they point at adverts and agreements), then adverts, then agreements, then him
        db.run("DELETE FROM payment_report_items WHERE report_id IN (SELECT id FROM payment_reports WHERE owner_id = ?)"
               " OR rental_id IN (SELECT id FROM rentals WHERE owner_id = ?)", (owner_id, owner_id))
        db.run("DELETE FROM payment_reports WHERE owner_id = ?", (owner_id,))
        db.run("DELETE FROM rental_notes WHERE rental_id IN (SELECT id FROM rentals WHERE owner_id = ?)", (owner_id,))
        db.run("DELETE FROM rentals WHERE owner_id = ?", (owner_id,))
        db.run(f"DELETE FROM founder_exemptions WHERE listing_id IN {mine}", (owner_id,))
        db.run(f"DELETE FROM offers WHERE owner_id = ? OR listing_id IN {mine}", (owner_id, owner_id))
        db.run("DELETE FROM listings WHERE owner_id = ?", (owner_id,))          # their pictures, blocked dates and facilities go with them
        db.run("DELETE FROM consents WHERE owner_id = ?", (owner_id,))
        db.run("DELETE FROM sessions WHERE user_id = ?", (owner_id,))
        _scrub_log(db, owner_id, user["name"], titles)
        db.run("DELETE FROM users WHERE id = ?", (owner_id,))                    # the last step: it fails, and all of the above is undone, if anything still points at him
        db.audit(None, "owner_deleted", _summary(held))
    return Gone(held["listings"], held["photos"], held["rentals"], held["unpaid_halalas"], files)


def _summary(held: dict) -> str:
    """The one line the manager keeps: how much an account held, and nothing about whose it was."""
    text = f"إعلانات {held['listings']} · عمليات تأجير {held['rentals']}"
    return text + (f" · عمولة غير مسددة {util.money(held['unpaid_halalas'])} ر.س" if held["unpaid_halalas"] else "")


def _scrub_log(db: Database, owner_id: int, name: str, titles: list[str]) -> None:
    """Takes him out of the manager's log. What he did himself goes. In the manager's own lines, the two places that wrote his words in the
    text are cut: the title of an advert that got the founders' year, and his name after an offer the manager stopped, lifted or deleted."""
    db.run("DELETE FROM audit WHERE user_id = ?", (owner_id,))
    for row in db.all("SELECT id, detail FROM audit WHERE action = 'founders_grant'"):
        for title in titles:
            if row["detail"].startswith(title + " · "):
                db.run("UPDATE audit SET detail = ? WHERE id = ?", (row["detail"][len(title) + 3:], row["id"]))
                break
    tail = f" ({name})"
    for row in db.all("SELECT id, detail FROM audit WHERE action IN ('offer_delete', 'offer_lift', 'offer_stop')"):
        if row["detail"].endswith(tail):
            db.run("UPDATE audit SET detail = ? WHERE id = ?", (row["detail"][:-len(tail)], row["id"]))


def remove_files(uploads_dir: Path, names: tuple[str, ...]) -> int:
    """Removes the picture files of a deleted account from the disk. A name the site would never have made is left alone. Returns how many went."""
    removed = 0
    for name in names:
        if not _FILE.fullmatch(name):
            log.warning("a picture name that is not ours was left on the disk")
            continue
        try:
            (uploads_dir / name).unlink()
            removed += 1
        except FileNotFoundError:
            pass
        except OSError:
            log.warning("a picture file of a deleted account could not be removed")
    return removed
