"""Settings come from environment variables only. No secret is ever written in the code."""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path


class ConfigError(ValueError):
    pass


# The map pictures come from one server whose address is a setting, so changing the provider never needs a new release. The default is
# OpenStreetMap's own, which costs nothing (its usage policy is in the README). `{s}` stands for a sub-domain, `{r}` for the sharp-screen suffix.
DEFAULT_TILE_URL = "https://tile.openstreetmap.org/{z}/{x}/{y}.png"
_TILE_HOST = re.compile(r"[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+(?::[0-9]{1,5})?")
_TILE_REST = re.compile(r"[A-Za-z0-9._~:/?&=%+,@!{}-]{0,300}")


def _tile_url_ok(url: str) -> bool:
    """https only, a real host name (an optional «{s}.» in front of it), a path and query of plain characters, and the three places the tile numbers go."""
    if not url.startswith("https://"):
        return False
    host, slash, rest = url[len("https://"):].partition("/")
    if host.startswith("{s}."):
        host = host[4:]
    return bool(slash) and bool(_TILE_HOST.fullmatch(host)) and bool(_TILE_REST.fullmatch(rest)) and all(part in url for part in ("{z}", "{x}", "{y}"))


def _int(env: dict, name: str, default: int, low: int, high: int) -> int:
    raw = (env.get(name) or "").strip()
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError:
        raise ConfigError(f"{name} must be a whole number") from None
    if not low <= value <= high:
        raise ConfigError(f"{name} must be between {low} and {high}")
    return value


@dataclass(frozen=True)
class Settings:
    site_name: str = "استراحتي"
    site_url: str = ""
    data_dir: Path = Path("/data")
    host: str = "0.0.0.0"
    port: int = 8090
    real_ip_header: str = ""
    cookie_secure: bool = False
    log_level: str = "INFO"
    max_upload_mb: int = 8
    max_photos: int = 12
    max_listings: int = 30
    login_per_minute: int = 10
    register_per_hour: int = 6
    map_tile_url: str = DEFAULT_TILE_URL
    map_credit: str = ""                 # extra words for the map's corner, before «© OpenStreetMap» (a paid provider asks for its own name)

    @property
    def map_tile_origin(self) -> str:
        """The server the map pictures come from, as the page's image rule needs it («{s}.» in the address becomes the wildcard «*.»)."""
        return "https://" + self.map_tile_url[len("https://"):].partition("/")[0].replace("{s}", "*")

    @property
    def db_path(self) -> Path:
        return self.data_dir / "istiraha.db"

    @property
    def uploads_dir(self) -> Path:
        return self.data_dir / "uploads"


def load_settings(env: dict | None = None) -> Settings:
    import os
    env = dict(os.environ if env is None else env)
    url = (env.get("SITE_URL") or "").strip().rstrip("/")
    if url and not re.fullmatch(r"https?://[A-Za-z0-9.-]{1,100}(:\d{1,5})?", url):
        raise ConfigError("SITE_URL must look like https://example.com")
    name = (env.get("SITE_NAME") or "استراحتي").strip()[:40] or "استراحتي"
    level = (env.get("LOG_LEVEL") or "INFO").upper()
    if level not in ("DEBUG", "INFO", "WARNING", "ERROR"):
        raise ConfigError("LOG_LEVEL must be DEBUG, INFO, WARNING or ERROR")
    secure_raw = (env.get("COOKIE_SECURE") or "").strip().lower()
    if secure_raw in ("1", "true", "yes"):
        secure = True
    elif secure_raw in ("0", "false", "no"):
        secure = False
    else:
        secure = url.startswith("https://")
    tiles = (env.get("MAP_TILE_URL") or "").strip() or DEFAULT_TILE_URL
    if not _tile_url_ok(tiles):
        raise ConfigError("MAP_TILE_URL must be an https address with {z}, {x} and {y} in it, like " + DEFAULT_TILE_URL)
    credit = re.sub(r"[\x00-\x1f\x7f<>]", "", (env.get("MAP_CREDIT") or "")).strip()[:120]
    return Settings(
        map_tile_url=tiles, map_credit=credit,
        site_name=name, site_url=url, data_dir=Path(env.get("DATA_DIR") or "/data"),
        host=(env.get("HOST") or "0.0.0.0").strip(), port=_int(env, "PORT", 8090, 1, 65535),
        real_ip_header=(env.get("REAL_IP_HEADER") or "").strip(), cookie_secure=secure, log_level=level,
        max_upload_mb=_int(env, "MAX_UPLOAD_MB", 8, 1, 25), max_photos=_int(env, "MAX_PHOTOS", 12, 1, 40),
        max_listings=_int(env, "MAX_LISTINGS", 30, 1, 500),
        login_per_minute=_int(env, "LOGIN_PER_MINUTE", 10, 1, 600),
        register_per_hour=_int(env, "REGISTER_PER_HOUR", 6, 1, 600),
    )
