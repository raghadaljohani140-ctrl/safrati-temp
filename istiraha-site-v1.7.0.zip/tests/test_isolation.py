"""The new project shares nothing with the other projects on the server: no name, no folder, no port, no database, no network call."""
import re
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OTHER_PROJECTS = ("aqar", "mazad", "safrati", "auction", "property-management", "property_management", "ticket", "travelpayouts", "telegram", "bot_token")


PICTURES = {".png", ".jpg", ".webp"}      # the logo and icons: not text, so the text scans skip them (test_the_shipped_pictures_hide_nothing looks inside them)


def project_files():
    """Everything that ships (the tests and the README talk about the other projects in order to say they are separate)."""
    names = ["Dockerfile", "docker-compose.yml", ".env.example", ".dockerignore", ".gitignore",
             "install.sh", "admin.sh", "web.sh", "status.sh", "backup.sh", "restore.sh", "uninstall.sh"]
    files = [ROOT / n for n in names]
    files += [p for p in (ROOT / "istiraha").rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.suffix not in PICTURES]
    return files


class NothingIsSharedTests(unittest.TestCase):
    def test_no_file_mentions_another_project(self):
        for path in project_files():
            text = path.read_text(encoding="utf-8").lower()
            for name in OTHER_PROJECTS:
                self.assertNotIn(name, text, f"{path.relative_to(ROOT)} mentions {name}")

    def test_the_code_only_writes_below_its_own_data_folder(self):
        for path in (ROOT / "istiraha").glob("*.py"):
            text = path.read_text(encoding="utf-8")
            self.assertIsNone(re.search(r"""["'](/opt|/etc|/var|/home|/root|/usr|/srv|/mnt|/proc|/sys|/dev)(/|["'])""", text), path.name)
            for bad in ("~/", "expanduser", "os.environ[", "getenv("):
                self.assertNotIn(bad, text, f"{path.name}: {bad}")
        settings = (ROOT / "istiraha" / "settings.py").read_text(encoding="utf-8")
        self.assertIn('Path(env.get("DATA_DIR") or "/data")', settings)
        self.assertIn('return self.data_dir / "istiraha.db"', settings)
        self.assertIn('return self.data_dir / "uploads"', settings)

    def test_the_site_makes_no_call_to_any_other_service(self):
        for path in (ROOT / "istiraha").glob("*.py"):
            text = path.read_text(encoding="utf-8")
            for bad in ("http.client", "requests", "smtplib", "ftplib", "socket.create_connection", "urlopen(", "subprocess", "os.system", "ctypes"):
                if path.name == "__main__.py" and bad == "urlopen(":
                    continue
                self.assertNotIn(bad, text, f"{path.name}: {bad}")
        main = (ROOT / "istiraha" / "__main__.py").read_text(encoding="utf-8")
        self.assertEqual(re.findall(r'urlopen\(([^,]+),', main), ['f"http://127.0.0.1:{settings.port}/healthz"'])       # only its own health check

    def test_the_pages_load_nothing_from_another_site(self):
        for path in list((ROOT / "istiraha").glob("*.py")) + [p for p in (ROOT / "istiraha" / "static").glob("*") if p.is_file() and p.suffix not in PICTURES]:
            text = path.read_text(encoding="utf-8")
            for url in re.findall(r"https?://[^\s\"')<>]+", text):
                host = re.match(r"https?://([^/:]+)", url).group(1)
                if host.startswith("{"):
                    continue                                    # a template filled in at run time from the page's own address
                self.assertIn(host, {"wa.me", "www.w3.org", "maps.app.goo.gl", "goo.gl", "www.google.com", "google.com", "maps.google.com",
                                     "www.google.com.sa", "maps.apple.com", "rest.example", "example.com",
                                     "www.sitemaps.org", "127.0.0.1",
                                     "tile.openstreetmap.org", "www.openstreetmap.org"}, f"{path.name}: {url}")      # the map: its default picture server, and the credit's link
        from istiraha.server import SECURITY_HEADERS
        csp = SECURITY_HEADERS["Content-Security-Policy"]
        self.assertTrue(csp.startswith("default-src 'none'; script-src 'self'; style-src 'self'; font-src 'self'; img-src 'self'"), csp)
        self.assertNotRegex(csp, r"https?://")                    # no outside host may supply a script, style, font or picture
        # a page with a map adds its picture server to the image rule and changes nothing else in the policy
        from istiraha.server import content_security_policy
        self.assertEqual(content_security_policy(), csp)
        self.assertEqual(content_security_policy("https://tile.openstreetmap.org").replace(" https://tile.openstreetmap.org", ""), csp)

    def test_the_map_library_is_the_official_build_and_makes_no_call_of_its_own(self):
        """Leaflet is copied as its makers ship it (the hashes say so), and it contains nothing that talks to the network: the only outside
        requests of a map page are the pictures the page's own address asks for (and the credit's link, which only the visitor can follow)."""
        import hashlib
        folder = ROOT / "istiraha" / "static" / "vendor" / "leaflet"
        digests = {name: hashlib.sha256((folder / name).read_bytes()).hexdigest() for name in ("leaflet.js", "leaflet.css")}
        self.assertEqual(digests["leaflet.js"], "85d455b4522415f6badc42a0e7d17c919d100347d6b8958bd0dc738fdecd6d50")
        self.assertEqual(digests["leaflet.css"], "a7837102824184820dfa198d1ebcd109ff6d0ff9a2672a074b9a1b4d147d04c6")
        library = (folder / "leaflet.js").read_text(encoding="utf-8")
        self.assertIn("1.9.4", library[:200])
        for bad in ("XMLHttpRequest", "fetch(", "WebSocket", "sendBeacon", "importScripts", "eval(", "new Function", "document.write"):
            self.assertNotIn(bad, library, bad)
        self.assertTrue((folder / "LICENSE.txt").read_text(encoding="utf-8").startswith("BSD 2-Clause License"))
        mine = (ROOT / "istiraha" / "static" / "map.js").read_text(encoding="utf-8")
        for bad in ("XMLHttpRequest", "fetch(", "WebSocket", "sendBeacon", "eval(", "new Function", "innerHTML", "document.write"):
            self.assertNotIn(bad, mine, bad)                      # the site's own map script builds everything with textContent

    def test_no_secret_is_written_in_the_code(self):
        for path in project_files():
            text = path.read_text(encoding="utf-8")
            self.assertNotRegex(text, r"(?i)(password|passwd|secret|api[_-]?key|token)\s*=\s*[\"'][^\"']{8,}[\"']", str(path.relative_to(ROOT)))
            self.assertNotRegex(text, r"-----BEGIN [A-Z ]*PRIVATE KEY-----")
            self.assertNotRegex(text, r"\b[A-Za-z0-9_-]{32,}\.[A-Za-z0-9_-]{6,}\.[A-Za-z0-9_-]{20,}\b")      # a JWT-shaped string

    def test_the_shipped_pictures_hide_nothing(self):
        """The logo, the icons and the share picture carry no camera, location, software or text data (the care the site takes with owners' pictures too)."""
        found = 0
        for path in sorted(p for p in (ROOT / "istiraha" / "static").glob("*") if p.is_file()):          # (the map library's folder is not the site's own pictures)
            data = path.read_bytes()
            if path.suffix == ".png":
                self.assertEqual(data[:8], b"\x89PNG\r\n\x1a\n", path.name)
                pos, kinds = 8, []
                while pos < len(data):
                    size = int.from_bytes(data[pos:pos + 4], "big")
                    kinds.append(data[pos + 4:pos + 8])
                    pos += 12 + size
                self.assertLessEqual(set(kinds), {b"IHDR", b"PLTE", b"tRNS", b"IDAT", b"IEND", b"sRGB", b"gAMA", b"pHYs"}, path.name)
            elif path.suffix == ".jpg":
                self.assertEqual(data[:2], b"\xff\xd8", path.name)
                self.assertNotIn(b"Exif\x00\x00", data[:8192], path.name)
                self.assertNotIn(b"ns.adobe.com", data[:8192], path.name)
            elif path.suffix == ".webp":
                self.assertEqual((data[:4], data[8:12]), (b"RIFF", b"WEBP"), path.name)
                pos, kinds = 12, []
                while pos + 8 <= len(data):
                    size = int.from_bytes(data[pos + 4:pos + 8], "little")
                    kinds.append(data[pos:pos + 4])
                    pos += 8 + size + (size & 1)
                self.assertFalse({b"EXIF", b"XMP ", b"ICCP"} & set(kinds), path.name)
            else:
                continue
            found += 1
        self.assertGreaterEqual(found, 6)

    def test_it_has_its_own_names_everywhere(self):
        compose = (ROOT / "docker-compose.yml").read_text(encoding="utf-8")
        for name in re.findall(r"container_name: (\S+)", compose) + re.findall(r"image: (istiraha\S+)", compose):
            self.assertTrue(name.startswith("istiraha"), name)
        self.assertEqual(re.findall(r"(?m)^APP_DIR=\"([^\"]+)\"", (ROOT / "install.sh").read_text()), ["/opt/istiraha-site"])
        for script in ("install.sh", "web.sh"):
            self.assertIn('PROJECT="istiraha"', (ROOT / script).read_text())


class ReleaseZipTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not (ROOT / "scripts" / "package.py").exists():
            raise unittest.SkipTest("the packaging script is a developer tool and is not part of the release itself")
        cls.out = tempfile.TemporaryDirectory()
        run = subprocess.run([sys.executable, "-I", str(ROOT / "scripts" / "package.py"), "--out", cls.out.name], capture_output=True, text=True, timeout=60)
        assert run.returncode == 0, run.stderr
        lines = run.stdout.splitlines()
        cls.path, cls.digest = Path(lines[0]), lines[1]
        cls.zip = zipfile.ZipFile(cls.path)
        cls.names = cls.zip.namelist()

    @classmethod
    def tearDownClass(cls):
        cls.zip.close()
        cls.out.cleanup()

    def test_the_name_carries_the_version(self):
        from istiraha import __version__
        self.assertEqual(self.path.name, f"istiraha-site-v{__version__}.zip")
        self.assertRegex(self.digest, r"^[0-9a-f]{64}$")

    def test_it_holds_what_the_server_needs(self):
        for needed in ("Dockerfile", "docker-compose.yml", ".env.example", "install.sh", "admin.sh", "web.sh", "status.sh", "backup.sh",
                       "restore.sh", "uninstall.sh", "README.md", "istiraha/__main__.py", "istiraha/static/app.css", "istiraha/static/app.js", "istiraha/static/favicon.svg"):
            self.assertIn(needed, self.names)

    def test_it_never_holds_a_secret_a_database_or_a_cache(self):
        for name in self.names:
            self.assertFalse(name.startswith(("/", "..")) or ".." in name.split("/"), name)
            self.assertNotIn("__pycache__", name)
            self.assertNotRegex(name, r"\.(pyc|db|db-wal|db-shm|zip|tar\.gz|sqlite3?)$")
            self.assertNotIn(name, (".env", ".tunnel.env", ".state"))
            self.assertFalse(name.startswith(("backups/", "scripts/")), name)

    def test_the_scripts_can_be_run(self):
        for name in ("install.sh", "admin.sh", "web.sh", "status.sh", "backup.sh", "restore.sh", "uninstall.sh"):
            mode = self.zip.getinfo(name).external_attr >> 16
            self.assertEqual(mode & 0o777, 0o755, name)

    def test_the_same_files_always_give_the_same_zip(self):
        again = tempfile.TemporaryDirectory()
        self.addCleanup(again.cleanup)
        run = subprocess.run([sys.executable, "-I", str(ROOT / "scripts" / "package.py"), "--out", again.name], capture_output=True, text=True, timeout=60)
        self.assertEqual(run.stdout.splitlines()[1], self.digest)


if __name__ == "__main__":
    unittest.main()
