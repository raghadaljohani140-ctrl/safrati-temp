"""Deleting the account (1.7.0): the owner asks for it himself, with his password, and everything of his goes at once. These tests keep
three promises: what is his is all gone (rows, picture files, sessions, his lines of the log), what is somebody else's is untouched
(to the byte), and a deletion that cannot be completed leaves everything exactly as it was."""
import re
import sqlite3
import unittest
from pathlib import Path

from istiraha import account, founders, util

from .helpers import NOW, Case, Client, fake_jpeg, fake_png

PASSWORD = "Str0ng-pass!"
OWNER_PASSWORD = "Owner-pass-1"
SHOWN = "SA03 8000 0000 6080 1016 7519"           # the example in the public IBAN registry, not anybody's account
ADD_SEAT = "INSERT INTO founder_exemptions(listing_id, starts_on, ends_on, granted_at) VALUES (?, '2026-10-26', '2027-10-25', 1)"

# every table that can hold a row of an owner, and how to find the rows of one of them (the owner's id is the only argument)
OWNERS_ROWS = {
    "users": "SELECT id, role, login, name, pass_hash, status, created_at FROM users WHERE id = :o",           # not the failed-attempt counters: a wrong password moves them
    "sessions": "SELECT * FROM sessions WHERE user_id = :o",
    "consents": "SELECT * FROM consents WHERE owner_id = :o",
    "listings": "SELECT * FROM listings WHERE owner_id = :o",
    "listing_amenities": "SELECT * FROM listing_amenities WHERE listing_id IN (SELECT id FROM listings WHERE owner_id = :o)",
    "photos": "SELECT * FROM photos WHERE listing_id IN (SELECT id FROM listings WHERE owner_id = :o)",
    "blocked_dates": "SELECT * FROM blocked_dates WHERE listing_id IN (SELECT id FROM listings WHERE owner_id = :o)",
    "offers": "SELECT * FROM offers WHERE owner_id = :o OR listing_id IN (SELECT id FROM listings WHERE owner_id = :o)",
    "rentals": "SELECT * FROM rentals WHERE owner_id = :o",
    "rental_notes": "SELECT * FROM rental_notes WHERE rental_id IN (SELECT id FROM rentals WHERE owner_id = :o)",
    "payment_reports": "SELECT * FROM payment_reports WHERE owner_id = :o",
    "payment_report_items": "SELECT * FROM payment_report_items WHERE report_id IN (SELECT id FROM payment_reports WHERE owner_id = :o)",
    "founder_exemptions": "SELECT * FROM founder_exemptions WHERE listing_id IN (SELECT id FROM listings WHERE owner_id = :o)",
    "audit": "SELECT * FROM audit WHERE user_id = :o",
}
SHARED = ("cities", "categories", "amenities", "pledge_versions", "commission_history", "settings")


class AccountCase(Case):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.admin = await self.make_admin()

    def uid(self, phone):
        return self.db.one("SELECT id FROM users WHERE login = ?", (phone,))["id"]

    def rows(self, owner_id):
        """{table: rows} of everything the database holds for one owner, as plain tuples (so two snapshots can be compared)."""
        return {t: [tuple(r) for r in self.db.all(sql.replace(":o", "?").replace("?", str(owner_id)))] for t, sql in OWNERS_ROWS.items()}

    def shared(self):
        return {t: [tuple(r) for r in self.db.all(f"SELECT * FROM {t} ORDER BY 1")] for t in SHARED}

    def files(self):
        folder = self.app.settings.uploads_dir
        return {p.name for p in folder.iterdir()} if folder.exists() else set()

    def count(self, table):
        return self.db.one(f"SELECT COUNT(*) AS n FROM {table}")["n"]

    async def populate(self, phone="0551234567", name="أبو سعد", title="استراحة النخيل", ip="203.0.113.50", password=OWNER_PASSWORD, report=True):
        """An owner who has used everything: an approved advert with two pictures, a blocked period, his own offer, a rental he wrote and
        one the manager wrote with a note on it, a report that he paid, and a founders' seat."""
        owner = await self.make_owner(phone=phone, name=name, ip=ip, password=password)
        lid = await self.add_listing(owner, title=title, whatsapp=phone)
        self.approve(lid)
        await owner.post(f"/owner/listing/{lid}/photo", files=[("photo", "a.jpg", fake_jpeg()), ("photo", "b.png", fake_png())], page=f"/owner/listing/{lid}")
        await owner.post(f"/owner/listing/{lid}/block", {"start": "2026-11-05", "end": "2026-11-07"}, page=f"/owner/listing/{lid}")
        r = await owner.post("/owner/offers", {"title": "خصم الخريف", "percent": "20", "listing": str(lid), "starts": "2026-10-26", "ends": "2026-12-31"}, page="/owner/offers")
        self.assertEqual(r.status, 303, owner.text[:300])
        r = await owner.post("/owner/rental/new", {"listing": str(lid), "rent": "1000", "date": "2026-10-26", "customer": "عميل تجريبي"}, page="/owner/rental/new")
        self.assertEqual(r.status, 303, owner.text[:300])
        r = await self.admin.post("/admin/rental/new", {"listing": str(lid), "rent": "700", "date": "2026-10-20", "status": "confirmed"}, page="/admin/rental/new")
        self.assertEqual(r.status, 303, self.admin.text[:300])
        rid = self.db.one("SELECT MAX(id) AS i FROM rentals")["i"]
        r = await self.admin.post(f"/admin/rental/{rid}/note", {"kind": "note", "body": "اتصلنا بالمالك"}, page=f"/admin/rental/{rid}")
        self.assertEqual(r.status, 303, self.admin.text[:300])
        self.db.run(ADD_SEAT, (lid,))
        if report:
            await self.admin.post("/admin/pay-details", {"holder": "شركة استراحتي", "bank": "مصرف الراجحي", "iban": SHOWN, "contact": "", "note": "", "password": PASSWORD}, page="/admin/pay-details")
            first = self.db.one("SELECT MIN(id) AS i FROM rentals WHERE listing_id = ?", (lid,))["i"]
            r = await owner.post("/owner/commissions/report", {"rental": [str(first)], "paid_on": "2026-10-26", "reference": "HW-1"}, page="/owner/commissions")
            self.assertEqual(r.status, 303, owner.text[:300])
        return owner, lid

    async def delete(self, client, password=OWNER_PASSWORD, sure="1", **extra):
        form = {"password": password, **({"sure": sure} if sure else {}), **extra}
        return await client.post("/owner/delete", form, page="/owner/delete")


class PageTests(AccountCase):
    async def test_the_page_says_what_goes_and_asks_for_the_password_and_a_tick(self):
        owner, lid = await self.populate(report=False)
        await owner.get("/owner")
        self.assertIn('<a href="/owner/delete">حذف حسابي</a>', owner.text)                      # reachable from his page
        r = await owner.get("/owner/delete")
        self.assertEqual(r.status, 200)
        page = owner.text
        for text in ("حذف الحساب", "نهائيًا وفورًا", "استراحاتك (1)", "عروضك (1)", "سجل عمليات التأجير (2)", "موافقاتك على التعهد"):
            self.assertIn(text, page)
        self.assertRegex(page, r'<form method="post" action="/owner/delete" class="delete">')
        self.assertIn('name="password"', page)
        self.assertRegex(page, r'<input type="checkbox" name="sure" value="1" required>')
        self.assertIn('class="btn danger big"', page)
        self.assertIn('href="/owner">تراجع', page)
        self.assertIn("noindex", page)
        self.assertEqual(r.headers["Cache-Control"], "no-store")                                  # an owner's page is never kept by a cache

    async def test_an_owner_with_nothing_yet_is_not_told_about_things_he_does_not_have(self):
        owner = await self.make_owner()
        await owner.get("/owner/delete")
        self.assertNotIn("استراحاتك (", owner.text)
        self.assertNotIn("عروضك (", owner.text)
        self.assertNotIn("سجل عمليات التأجير", owner.text)
        self.assertIn("اسمك ورقم جوالك وكلمة مرورك", owner.text)

    async def test_unpaid_commission_is_said_before_he_decides(self):
        owner, lid = await self.populate(report=False)
        await owner.get("/owner/delete")
        owed = self.db.one("SELECT SUM(commission_halalas) AS s FROM rentals WHERE pay_status = 'due'")["s"]
        self.assertGreater(owed, 0)
        self.assertIn(f"{util.money(owed)} ر.س", owner.text)
        self.assertIn("أتمّ سدادها قبل الحذف", owner.text)
        paid = await self.make_owner(phone="0559876543", name="أبو خالد", ip="203.0.113.51")
        await paid.get("/owner/delete")
        self.assertNotIn("أتمّ سدادها", paid.text)                                                # nothing owed, nothing said

    async def test_only_a_signed_in_owner_reaches_it(self):
        for client in (self.visitor, self.admin):                                                  # an admin session is not an owner session
            self.assertEqual((await client.get("/owner/delete")).status, 303)
            self.assertTrue(client.location.startswith("/owner/login"))
        await self.populate()
        self.assertEqual(self.count("users"), 2)

    async def test_a_blocked_owner_cannot_reach_it(self):
        owner = await self.make_owner()
        self.db.run("UPDATE users SET status = 'blocked' WHERE login = '966551234567'")
        self.assertEqual((await owner.get("/owner/delete")).status, 303)
        self.assertEqual(self.count("users"), 2)                                                   # he is not deleted, the manager keeps his record


class RefusalTests(AccountCase):
    async def test_a_wrong_password_deletes_nothing(self):
        owner, lid = await self.populate()
        before, shared, files = self.rows(self.uid("966551234567")), self.shared(), self.files()
        r = await self.delete(owner, password="wrong-pass-1")
        self.assertEqual(r.status, 400)
        self.assertIn("كلمة المرور غير صحيحة", owner.text)
        self.assertNotIn("wrong-pass-1", owner.text)                                               # what he typed is never put back
        self.assertEqual(self.rows(self.uid("966551234567")), before)
        self.assertEqual((self.shared(), self.files()), (shared, files))
        self.assertEqual((await owner.get("/owner")).status, 200)                                  # and he is still signed in

    async def test_no_password_or_no_tick_deletes_nothing(self):
        owner, lid = await self.populate()
        before = self.rows(self.uid("966551234567"))
        r = await self.delete(owner, sure="")
        self.assertEqual(r.status, 400)
        self.assertIn("علّم المربع", owner.text)
        r = await self.delete(owner, password="")
        self.assertEqual(r.status, 400)
        r = await self.delete(owner, sure="yes")
        self.assertEqual(r.status, 400)                                                            # only the value of the box counts
        self.assertEqual(self.rows(self.uid("966551234567")), before)

    async def test_guessing_the_password_here_locks_the_account_like_the_login_page(self):
        owner, lid = await self.populate()
        before = self.rows(self.uid("966551234567"))
        for _ in range(5):
            await self.delete(owner, password="guess-guess-1")
        r = await self.delete(owner)                                                               # now locked, even with the right one
        self.assertEqual(r.status, 400)
        self.assertIn("مقفل", owner.text)
        after = self.rows(self.uid("966551234567"))
        lockout = [row for row in after.pop("audit") if row[3] == "lockout"]                         # the lock itself is written in his log, as at the login page
        self.assertEqual(len(lockout), 1)
        before.pop("audit")
        self.assertEqual(after, before)

    async def test_a_form_without_the_check_token_or_from_another_site_is_refused(self):
        owner, lid = await self.populate()
        before = self.rows(self.uid("966551234567"))
        r = await owner.go("POST", "/owner/delete", {"password": OWNER_PASSWORD, "sure": "1"})
        self.assertEqual(r.status, 403)
        await owner.get("/owner/delete")
        token = owner.csrf()
        r = await owner.go("POST", "/owner/delete", {"password": OWNER_PASSWORD, "sure": "1", "_csrf": token}, headers={"origin": "https://evil.example"})
        self.assertEqual(r.status, 403)
        r = await owner.go("POST", "/owner/delete", {"password": OWNER_PASSWORD, "sure": "1", "_csrf": "x" * 20})
        self.assertEqual(r.status, 403)
        self.assertEqual(self.rows(self.uid("966551234567")), before)

    async def test_a_get_never_deletes(self):
        owner, lid = await self.populate()
        before = self.rows(self.uid("966551234567"))
        await owner.get(f"/owner/delete?password={OWNER_PASSWORD}&sure=1")
        self.assertEqual(self.rows(self.uid("966551234567")), before)

    async def test_the_visitor_and_the_admin_cannot_post_it(self):
        owner, lid = await self.populate()
        before = self.rows(self.uid("966551234567"))
        for client in (self.visitor, self.admin):
            r = await client.go("POST", "/owner/delete", {"password": OWNER_PASSWORD, "sure": "1", "_csrf": client.jar.get("ist_c", "x" * 20)})
            self.assertIn(r.status, (303, 403))
        self.assertEqual(self.rows(self.uid("966551234567")), before)
        self.assertEqual(self.count("users"), 2)


class DeletionTests(AccountCase):
    async def test_everything_of_his_goes_and_nothing_of_the_other_owner(self):
        mine, my_lid = await self.populate()
        other, other_lid = await self.populate(phone="0559876543", name="أبو خالد", title="مزرعة الواحة", ip="203.0.113.51")
        me, he = self.uid("966551234567"), self.uid("966559876543")
        kept, shared = self.rows(he), self.shared()
        before = self.rows(me)
        for table in ("users", "consents", "listings", "photos", "blocked_dates", "offers", "rentals", "rental_notes", "payment_reports", "payment_report_items", "founder_exemptions", "audit"):
            self.assertTrue(before[table], f"the test must give him rows in {table}")           # the world really holds something of every kind
        self.assertEqual(len(before["photos"]), 2)

        r = await self.delete(mine)
        self.assertEqual(r.status, 200, mine.text[:300])
        self.assertIn("تم حذف حسابك", mine.text)

        after = self.rows(me)
        self.assertEqual(after, {t: [] for t in OWNERS_ROWS}, "nothing of his is left in any table")
        self.assertEqual(self.rows(he), kept, "the other owner is untouched to the last column")
        self.assertEqual(self.shared(), shared, "the cities, types, pledge, commission and settings are untouched")
        self.assertEqual(self.count("users"), 2)                                                    # the manager and the other owner, nobody else
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM users WHERE role = 'owner'")["n"], 1)

    async def test_nothing_in_the_database_is_left_pointing_at_him(self):
        mine, lid = await self.populate()
        await self.populate(phone="0559876543", name="أبو خالد", title="مزرعة الواحة", ip="203.0.113.51")
        await self.delete(mine)
        self.assertEqual(self.db.all("PRAGMA foreign_key_check"), [])
        self.assertEqual(self.db.one("PRAGMA integrity_check")[0], "ok")

    async def test_his_pictures_leave_the_disk_and_the_other_owners_stay(self):
        mine, my_lid = await self.populate()
        other, other_lid = await self.populate(phone="0559876543", name="أبو خالد", title="مزرعة الواحة", ip="203.0.113.51")
        mine_files = {r["filename"] for r in self.db.all("SELECT filename FROM photos WHERE listing_id = ?", (my_lid,))}
        theirs = {r["filename"] for r in self.db.all("SELECT filename FROM photos WHERE listing_id = ?", (other_lid,))}
        self.assertEqual((len(mine_files), len(theirs)), (2, 2))
        self.assertEqual(self.files(), mine_files | theirs)
        await self.delete(mine)
        self.assertEqual(self.files(), theirs)
        for name in mine_files:
            self.assertEqual((await self.visitor.get(f"/media/{name}")).status, 404)
        for name in theirs:
            self.assertEqual((await self.visitor.get(f"/media/{name}")).status, 200)

    async def test_his_advert_is_gone_from_the_site_at_once(self):
        mine, lid = await self.populate()
        other, other_lid = await self.populate(phone="0559876543", name="أبو خالد", title="مزرعة الواحة", ip="203.0.113.51")
        self.assertEqual((await self.visitor.get(f"/r/{lid}")).status, 200)
        self.assertIn("استراحة النخيل", (await self.visitor.get("/search")).body.decode())
        self.assertIn(f"/r/{lid}", (await self.visitor.get("/sitemap.xml")).body.decode())
        await self.delete(mine)
        self.assertEqual((await self.visitor.get(f"/r/{lid}")).status, 404)
        text = (await self.visitor.get("/search")).body.decode()
        self.assertNotIn("استراحة النخيل", text)
        self.assertIn("مزرعة الواحة", text)
        self.assertNotIn(f"/r/{lid}<", (await self.visitor.get("/sitemap.xml")).body.decode())
        self.assertEqual((await self.visitor.get(f"/r/{other_lid}")).status, 200)

    async def test_he_is_signed_out_everywhere_and_the_old_login_no_longer_works(self):
        mine, lid = await self.populate()
        second_phone = Client(self.app, "203.0.113.77")                                             # the same account, signed in on another device
        await second_phone.get("/owner/login")
        r = await second_phone.post("/owner/login", {"phone": "0551234567", "password": OWNER_PASSWORD})
        self.assertEqual(r.status, 303)
        self.assertEqual((await second_phone.get("/owner")).status, 200)
        await self.delete(mine)
        self.assertNotIn("ist_o", mine.jar)                                                         # the cookie is cleared in his browser
        self.assertEqual((await mine.get("/owner")).status, 303)
        self.assertEqual((await second_phone.get("/owner")).status, 303)                            # and on the other device
        fresh = Client(self.app, "203.0.113.78")
        await fresh.get("/owner/login")
        r = await fresh.post("/owner/login", {"phone": "0551234567", "password": OWNER_PASSWORD})
        self.assertEqual(r.status, 200)
        self.assertIn("بيانات الدخول غير صحيحة", fresh.text)

    async def test_the_confirmation_page_is_a_visitors_page(self):
        mine, lid = await self.populate()
        r = await self.delete(mine)
        self.assertEqual(r.status, 200)
        self.assertEqual(r.headers["Cache-Control"], "no-store")
        self.assertNotIn('action="/owner/logout"', mine.text)                                       # no owner menu
        self.assertIn('href="/owner/login"', mine.text)
        self.assertIn('href="/"', mine.text)
        self.assertNotIn("أبو سعد", mine.text)

    async def test_the_same_number_can_open_a_new_account_that_starts_empty(self):
        mine, lid = await self.populate()
        await self.delete(mine)
        again = await self.make_owner(phone="0551234567", name="أبو سعد", password="Another-pass-2", ip="203.0.113.79")
        await again.get("/owner")
        self.assertIn("ما أضفت أي استراحة بعد", again.text)
        self.assertEqual(self.count("rentals"), 0)
        self.assertEqual(self.count("consents"), 0)
        await again.get("/owner/commissions")
        self.assertNotIn("HW-1", again.text)

    async def test_a_second_press_or_a_replayed_form_deletes_nothing_more(self):
        mine, lid = await self.populate()
        other, other_lid = await self.populate(phone="0559876543", name="أبو خالد", title="مزرعة الواحة", ip="203.0.113.51")
        he = self.rows(self.uid("966559876543"))
        await mine.get("/owner/delete")
        token, cookie = mine.csrf(), mine.jar["ist_o"]
        r = await mine.go("POST", "/owner/delete", {"password": OWNER_PASSWORD, "sure": "1", "_csrf": token})
        self.assertEqual(r.status, 200)
        replay = Client(self.app, "203.0.113.50")
        replay.jar["ist_o"] = cookie                                                                 # the old cookie, sent again by a slow phone or a thief
        r = await replay.go("POST", "/owner/delete", {"password": OWNER_PASSWORD, "sure": "1", "_csrf": token})
        self.assertEqual(r.status, 303)
        self.assertTrue(replay.location.startswith("/owner/login"))
        self.assertEqual(self.rows(self.uid("966559876543")), he)

    async def test_the_form_has_no_field_that_says_whose_account_to_delete(self):
        mine, lid = await self.populate()
        other, other_lid = await self.populate(phone="0559876543", name="أبو خالد", title="مزرعة الواحة", ip="203.0.113.51")
        me, he = self.uid("966551234567"), self.uid("966559876543")
        kept = self.rows(he)
        await self.delete(mine, id=str(he), owner=str(he), owner_id=str(he), user=str(he), login="966559876543")      # forged fields are ignored
        self.assertEqual(self.rows(he), kept)
        self.assertEqual(self.rows(me), {t: [] for t in OWNERS_ROWS})

    async def test_the_founders_seat_goes_back_to_the_pool(self):
        mine, lid = await self.populate()
        taken = founders.taken(self.db)
        self.assertEqual(taken, 1)
        await self.delete(mine)
        self.assertEqual((founders.taken(self.db), founders.left(self.db)), (0, founders.CAP))


class LogTests(AccountCase):
    async def test_his_own_lines_go_and_one_line_without_a_name_is_kept_for_the_manager(self):
        mine, lid = await self.populate()
        me = self.uid("966551234567")
        self.assertTrue(self.db.all("SELECT 1 FROM audit WHERE user_id = ?", (me,)))
        before = self.count("audit")
        await self.delete(mine)
        self.assertEqual(self.db.all("SELECT 1 FROM audit WHERE user_id = ?", (me,)), [])
        line = self.db.all("SELECT * FROM audit WHERE action = 'owner_deleted'")
        self.assertEqual(len(line), 1)
        self.assertIsNone(line[0]["user_id"])
        self.assertEqual(line[0]["at"], NOW)
        self.assertIn("إعلانات 1", line[0]["detail"])
        self.assertIn("عمليات تأجير 2", line[0]["detail"])
        self.assertIn("عمولة غير مسددة", line[0]["detail"])
        for secret in ("أبو سعد", "966551234567", "0551234567", "استراحة النخيل"):
            self.assertNotIn(secret, line[0]["detail"])
        self.assertLess(self.count("audit"), before + 1)                                            # his lines went, this one came

    async def test_the_manager_sees_the_line_with_its_label_and_no_owner(self):
        mine, lid = await self.populate()
        await self.delete(mine)
        await self.admin.get("/admin")
        self.assertIn("حذف حساب مالك", self.admin.text)
        self.assertIn("إعلانات 1", self.admin.text)
        for secret in ("أبو سعد", "استراحة النخيل", "966551234567"):
            self.assertNotIn(secret, self.admin.text)

    async def test_an_account_that_owed_nothing_leaves_no_amount_in_the_line(self):
        owner = await self.make_owner()
        await self.delete(owner)
        detail = self.db.one("SELECT detail FROM audit WHERE action = 'owner_deleted'")["detail"]
        self.assertEqual(detail, "إعلانات 0 · عمليات تأجير 0")

    async def test_the_managers_lines_that_quote_his_words_are_cut(self):
        mine, lid = await self.populate()
        other, other_lid = await self.populate(phone="0559876543", name="أبو خالد", title="مزرعة الواحة", ip="203.0.113.51")
        # a line the manager's own actions wrote: the title of an advert that got the founders' year, and an offer of an owner he stopped
        self.db.audit(None, "founders_grant", "استراحة النخيل · مقعد 5 من 100 · من 2026-10-26 إلى 2027-10-25")
        self.db.audit(None, "founders_grant", "مزرعة الواحة · مقعد 6 من 100 · من 2026-10-26 إلى 2027-10-25")
        self.db.audit(1, "offer_stop", "خصم الخريف (أبو سعد)")
        self.db.audit(1, "offer_stop", "خصم الخريف (أبو خالد)")
        self.db.audit(1, "offer_new", "خصم الخريف 20%")
        await self.delete(mine)
        details = {r["detail"] for r in self.db.all("SELECT detail FROM audit")}
        self.assertIn("مقعد 5 من 100 · من 2026-10-26 إلى 2027-10-25", details)                    # his title is cut, the rest stays
        self.assertIn("مزرعة الواحة · مقعد 6 من 100 · من 2026-10-26 إلى 2027-10-25", details)      # the other owner's line is as it was
        self.assertIn("خصم الخريف", details)                                                         # his name is cut after the offer
        self.assertIn("خصم الخريف (أبو خالد)", details)
        self.assertNotIn("خصم الخريف (أبو سعد)", details)
        self.assertNotIn("استراحة النخيل · مقعد 5 من 100 · من 2026-10-26 إلى 2027-10-25", details)
        self.assertIn("خصم الخريف 20%", details)                                                      # a line that never held a name stays


class AllOrNothingTests(AccountCase):
    async def test_when_the_database_refuses_a_step_nothing_is_deleted_and_he_is_told(self):
        mine, lid = await self.populate()
        other, other_lid = await self.populate(phone="0559876543", name="أبو خالد", title="مزرعة الواحة", ip="203.0.113.51")
        me, he = self.uid("966551234567"), self.uid("966559876543")
        consent = self.db.one("SELECT id FROM consents WHERE owner_id = ?", (he,))["id"]
        # a row of somebody else that points at his advert (the program never makes one; the database must still refuse to orphan it)
        self.db.run("""INSERT INTO rentals(listing_id, owner_id, consent_id, basis_points, rent, commission_halalas, rental_date, due_date, created_at)
                       VALUES (?, ?, ?, 1000, 500, 5000, '2026-10-25', '2026-11-01', ?)""", (lid, he, consent, NOW))
        before, theirs, shared, files = self.rows(me), self.rows(he), self.shared(), self.files()
        rentals = self.count("rentals")
        with self.assertLogs("istiraha", level="ERROR"):                                           # the failure is written in the server's log
            r = await self.delete(mine)
        self.assertEqual(r.status, 500)
        self.assertIn("تعذر حذف الحساب", mine.text)
        self.assertIn("لم يُحذف شيء", mine.text)
        self.assertEqual(self.rows(me), before, "everything of his is as it was, to the last column")
        self.assertEqual(self.rows(he), theirs)
        self.assertEqual((self.shared(), self.files(), self.count("rentals")), (shared, files, rentals))
        self.assertEqual(self.db.all("SELECT 1 FROM audit WHERE action = 'owner_deleted'"), [])    # and no line says it happened
        self.assertEqual((await mine.get("/owner")).status, 200)                                  # he is still signed in
        for name in files:
            self.assertTrue((self.app.settings.uploads_dir / name).exists())

    async def test_the_function_raises_and_rolls_back_by_itself(self):
        mine, lid = await self.populate()
        other, other_lid = await self.populate(phone="0559876543", name="أبو خالد", title="مزرعة الواحة", ip="203.0.113.51")
        me, he = self.uid("966551234567"), self.uid("966559876543")
        consent = self.db.one("SELECT id FROM consents WHERE owner_id = ?", (he,))["id"]
        self.db.run("""INSERT INTO rentals(listing_id, owner_id, consent_id, basis_points, rent, commission_halalas, rental_date, due_date, created_at)
                       VALUES (?, ?, ?, 1000, 500, 5000, '2026-10-25', '2026-11-01', ?)""", (lid, he, consent, NOW))
        before = self.rows(me)
        with self.assertRaises(sqlite3.IntegrityError):
            account.delete_owner(self.db, me)
        self.assertEqual(self.rows(me), before)
        self.assertFalse(self.db.conn.in_transaction)                                               # the transaction is closed, the database is usable


class UnitTests(AccountCase):
    async def test_the_numbers_it_reports(self):
        mine, lid = await self.populate()
        me = self.uid("966551234567")
        held = account.inventory(self.db, me)
        self.assertEqual((held["listings"], held["photos"], held["offers"], held["rentals"]), (1, 2, 1, 2))
        owed = self.db.one("SELECT SUM(commission_halalas) AS s FROM rentals WHERE pay_status = 'due'")["s"]
        self.assertEqual(held["unpaid_halalas"], owed)                                                # a report waiting for the manager still counts as unpaid
        gone = account.delete_owner(self.db, me)
        self.assertEqual((gone.listings, gone.photos, gone.rentals, gone.unpaid_halalas), (1, 2, 2, owed))
        self.assertEqual(len(gone.files), 2)

    async def test_an_admin_is_never_deleted_here_and_a_missing_owner_is_not_an_error(self):
        admin_id = self.db.one("SELECT id FROM users WHERE role = 'admin'")["id"]
        self.assertIsNone(account.delete_owner(self.db, admin_id))
        self.assertIsNone(account.delete_owner(self.db, 99999))
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM users WHERE role = 'admin'")["n"], 1)
        self.assertEqual(self.db.all("SELECT 1 FROM audit WHERE action = 'owner_deleted'"), [])

    async def test_a_paid_commission_is_not_counted_as_unpaid(self):
        mine, lid = await self.populate(report=False)
        me = self.uid("966551234567")
        self.db.run("UPDATE rentals SET pay_status = 'paid' WHERE owner_id = ?", (me,))
        self.assertEqual(account.inventory(self.db, me)["unpaid_halalas"], 0)
        self.db.run("UPDATE rentals SET pay_status = 'due', status = 'cancelled' WHERE owner_id = ?", (me,))
        self.assertEqual(account.inventory(self.db, me)["unpaid_halalas"], 0)                        # a cancelled rental owes nothing

    def test_only_names_the_site_made_are_removed_from_the_disk(self):
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            good, other = "a" * 32 + ".jpg", "b" * 32 + ".png"
            (folder / good).write_bytes(b"x")
            (folder / other).write_bytes(b"x")
            (folder / "notes.txt").write_bytes(b"keep")
            (folder.parent / "outside.jpg").write_bytes(b"keep")
            try:
                with self.assertLogs("istiraha", level="WARNING") as logged:
                    removed = account.remove_files(folder, (good, "../outside.jpg", "notes.txt", "c" * 32 + ".jpg", "A" * 32 + ".jpg", ""))
                self.assertEqual(len(logged.records), 4)                                              # one warning for each name that is not ours
                self.assertEqual(removed, 1)                                                          # a missing file is not an error, a strange name is left alone
                self.assertFalse((folder / good).exists())
                self.assertTrue((folder / other).exists())
                self.assertTrue((folder / "notes.txt").exists())
                self.assertTrue((folder.parent / "outside.jpg").exists())
            finally:
                (folder.parent / "outside.jpg").unlink(missing_ok=True)


if __name__ == "__main__":
    unittest.main()
