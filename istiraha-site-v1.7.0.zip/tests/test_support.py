"""Support and reports (1.7.0): the manager saves ONE e-mail address in the settings; the site shows it on the page «الدعم», in the privacy
page and in a «report this advert» link under every public advert. Nothing is sent from the site and nothing about the reporter is kept.
Also the final texts of the terms and of the privacy page, which no longer say they are a draft."""
import re
import unittest
from html import unescape
from urllib.parse import parse_qs, unquote, urlsplit

from istiraha import support
from istiraha.server import SECURITY_HEADERS, content_security_policy

from .helpers import Case, Client

MAIL = "support@rest.example"


class AddressTests(unittest.TestCase):
    def test_a_normal_address_is_kept_and_only_its_domain_is_made_lower_case(self):
        for typed, kept in (("support@example.com", "support@example.com"), ("  Support@Example.COM ", "Support@example.com"),
                            ("a.b+c@sub.example.co.uk", "a.b+c@sub.example.co.uk"), ("a_b-c%d@my-site.sa", "a_b-c%d@my-site.sa")):
            self.assertEqual(support.clean_email(typed), kept, typed)

    def test_an_empty_text_clears_the_setting(self):
        self.assertEqual(support.clean_email(""), "")
        self.assertEqual(support.clean_email("   \t "), "")

    def test_what_cannot_be_an_address_is_refused(self):
        for typed in ("support", "a@b", "a@b.c", "a b@example.com", "a@exam ple.com", "a@@example.com", ".a@example.com", "a.@example.com",
                      "a..b@example.com", "a@-example.com", "a@example-.com", "a@example..com", "<script>@example.com", "a@example.com,b@example.com",
                      "a@example.com\r\nBcc: x@y.com", "a@example.com\nBcc: x@y.com", "'x'@example.com", "a@example.123", "ä@example.com",
                      "mailto:a@example.com", "javascript:alert(1)", "a@" + "b" * 64 + ".com", "a" * 65 + "@example.com", "a@example.com" + "m" * 120, "https://example.com"):
            self.assertIsNone(support.clean_email(typed), typed)

    def test_the_link_cannot_be_bent_by_what_it_carries(self):
        title = 'x&body=evil?cc=a@b.com#frag\nBcc: z@z.com "><script>'
        link = support.report_link(MAIL, title, "https://rest.example/r/5")
        self.assertTrue(link.startswith("mailto:" + MAIL + "?subject="))
        parts = urlsplit(link)
        self.assertEqual(sorted(parse_qs(parts.query)), ["body", "subject"])                         # still exactly two fields: nothing was added by the title
        self.assertEqual(parts.fragment, "")
        for char in ('"', "<", ">", "\n", "\r", " ", "#"):
            self.assertNotIn(char, link)
        fields = parse_qs(parts.query)
        self.assertIn("evil?cc=a@b.com", fields["subject"][0])                                        # it is all text, read back exactly as written
        self.assertIn("https://rest.example/r/5", fields["body"][0])
        self.assertIn("سبب البلاغ", fields["body"][0])

    def test_a_long_title_is_cut_so_the_link_stays_short(self):
        link = support.report_link(MAIL, "ن" * 500, "https://rest.example/r/5")
        self.assertLess(len(link), 1500)


class SupportCase(Case):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.admin = await self.make_admin()

    async def save(self, address):
        return await self.admin.post("/admin/support", {"email": address}, page="/admin/settings")

    async def advert(self, title="استراحة النخيل", approved=True):
        owner = await self.make_owner()
        lid = await self.add_listing(owner, title=title)
        if approved:
            self.approve(lid)
        return owner, lid

    def report_href(self, html):
        found = re.search(r'<p class="fine report">[^<]*<a href="([^"]*)">أبلغ عن هذا الإعلان</a></p>', html)
        return unescape(found.group(1)) if found else None


class SettingsTests(SupportCase):
    async def test_the_panel_warns_until_an_address_is_saved(self):
        await self.admin.get("/admin/settings")
        self.assertIn("بريد الدعم", self.admin.text)
        self.assertIn("لم تضف بريدًا بعد", self.admin.text)
        self.assertIn('action="/admin/support"', self.admin.text)
        self.assertIn('type="email"', self.admin.text)
        r = await self.save(MAIL)
        self.assertEqual(r.status, 303)
        self.assertEqual(await self.admin.message(), "حفظنا بريد الدعم")
        self.assertEqual(self.db.setting(support.KEY), MAIL)
        await self.admin.get("/admin/settings")
        self.assertNotIn("لم تضف بريدًا بعد", self.admin.text)
        self.assertIn(f'value="{MAIL}"', self.admin.text)

    async def test_the_domain_is_made_lower_case_and_spaces_are_cut(self):
        await self.save("  Help@REST.Example ")
        self.assertEqual(self.db.setting(support.KEY), "Help@rest.example")

    async def test_a_wrong_address_is_refused_and_the_old_one_stays(self):
        await self.save(MAIL)
        for typed in ("support", "a@b", "x@y.com\r\nBcc: z@z.com", "javascript:alert(1)", "<b>@x.com"):
            r = await self.save(typed)
            self.assertEqual(r.status, 303, typed)
            self.assertIn("اكتب بريدًا صحيحًا", await self.admin.message())
            self.assertEqual(self.db.setting(support.KEY), MAIL, typed)

    async def test_an_empty_address_removes_it_and_the_report_link_goes(self):
        owner, lid = await self.advert()
        await self.save(MAIL)
        await self.visitor.get(f"/r/{lid}")
        self.assertIsNotNone(self.report_href(self.visitor.text))
        await self.save("")
        self.assertEqual(await self.admin.message(), "أزلنا بريد الدعم")
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM settings WHERE key = ?", (support.KEY,))["n"], 0)
        await self.visitor.get(f"/r/{lid}")
        self.assertIsNone(self.report_href(self.visitor.text))

    async def test_the_change_is_in_the_log_without_the_address(self):
        await self.save(MAIL)
        await self.save("")
        rows = self.db.all("SELECT * FROM audit WHERE action = 'support_email' ORDER BY id")
        self.assertEqual([r["detail"] for r in rows], ["حُفظ بريد جديد", "أُزيل البريد"])
        self.assertTrue(all(MAIL not in r["detail"] for r in rows))
        await self.admin.get("/admin")
        self.assertIn("تغيير بريد الدعم", self.admin.text)

    async def test_only_the_manager_can_change_it_and_the_form_needs_its_token(self):
        owner = await self.make_owner()
        for client, page in ((self.visitor, "/owner/login"), (owner, "/owner")):                     # a page of their own that has a form, so each has a real token
            await client.get(page)
            r = await client.go("POST", "/admin/support", {"email": "evil@example.com", "_csrf": client.csrf()})
            self.assertEqual(r.status, 303)
            self.assertEqual(client.location, "/admin/login")
        r = await self.admin.go("POST", "/admin/support", {"email": "evil@example.com"})
        self.assertEqual(r.status, 403)
        await self.admin.get("/admin/settings")
        r = await self.admin.go("POST", "/admin/support", {"email": "evil@example.com", "_csrf": self.admin.csrf()}, headers={"origin": "https://evil.example"})
        self.assertEqual(r.status, 403)
        self.assertEqual(self.db.setting(support.KEY), "")

    async def test_a_damaged_value_in_the_database_is_never_shown_or_linked(self):
        owner, lid = await self.advert()
        self.db.put_setting(support.KEY, 'javascript:alert(1)"><script>')
        self.assertEqual(support.address(self.db), "")
        await self.visitor.get("/support")
        self.assertNotIn("javascript:", self.visitor.text)
        await self.visitor.get(f"/r/{lid}")
        self.assertNotIn("javascript:", self.visitor.text)
        self.assertIsNone(self.report_href(self.visitor.text))


class SupportPageTests(SupportCase):
    async def test_the_page_is_public_and_says_how_to_reach_us(self):
        await self.save(MAIL)
        r = await self.visitor.get("/support")
        self.assertEqual(r.status, 200)
        page = self.visitor.text
        self.assertIn(f'<a href="mailto:{MAIL}?subject=', page)
        self.assertIn(f'dir="ltr">{MAIL}</a>', page)
        for text in ("الدعم والتواصل", "الإبلاغ عن إعلان", "أبلغ عن هذا الإعلان", "نسيت كلمة المرور", "حذف حسابي", "الشروط والأحكام", "سياسة الخصوصية"):
            self.assertIn(text, page)
        self.assertIn('rel="canonical"', page)
        self.assertNotIn("noindex", page)                                                            # Apple and the visitors must be able to open it
        links = re.search(r'<p class="fine"><a href="/terms">.*?</p>', page).group(0)               # under the text: the two other pages, never itself
        self.assertEqual(re.findall(r'href="([^"]+)"', links), ["/terms", "/privacy"])
        await self.visitor.get("/terms")
        self.assertEqual(re.findall(r'href="([^"]+)"', re.search(r'<p class="fine"><a href="/privacy">.*?</p>', self.visitor.text).group(0)), ["/privacy", "/support"])
        await self.visitor.get("/privacy")
        self.assertEqual(re.findall(r'href="([^"]+)"', re.search(r'<p class="fine"><a href="/terms">.*?</p>', self.visitor.text).group(0)), ["/terms", "/support"])

    async def test_without_an_address_the_page_still_works_and_promises_nothing_it_cannot_keep(self):
        r = await self.visitor.get("/support")
        self.assertEqual(r.status, 200)
        self.assertIn("سنضيف بريد الدعم هنا قريبًا", self.visitor.text)
        self.assertNotIn("mailto:", self.visitor.text)

    async def test_the_pages_carry_the_site_s_normal_security_headers(self):
        await self.save(MAIL)
        owner = await self.make_owner()
        for client, path in ((self.visitor, "/support"), (self.visitor, "/terms"), (self.visitor, "/privacy"), (owner, "/owner/delete")):
            r = await client.get(path)
            self.assertEqual(r.status, 200, path)
            self.assertEqual(r.headers.get("Content-Security-Policy", content_security_policy()), content_security_policy(), path)
            self.assertNotIn("http", content_security_policy())                                       # no outside address is ever allowed there
        self.assertEqual(SECURITY_HEADERS["X-Frame-Options"], "DENY")

    async def test_every_page_has_the_support_link_in_its_footer(self):
        owner, lid = await self.advert()
        for client, path in ((self.visitor, "/"), (self.visitor, "/search"), (self.visitor, "/offers"), (self.visitor, f"/r/{lid}"), (self.visitor, "/terms"),
                             (self.visitor, "/owner/login"), (owner, "/owner"), (self.admin, "/admin")):
            await client.get(path)
            self.assertIn('<a href="/support">الدعم</a>', client.text, path)
        await self.visitor.get("/nothing-here")
        self.assertIn('<a href="/support">الدعم</a>', self.visitor.text)                            # also on the page that says there is no such page


class ReportLinkTests(SupportCase):
    async def test_no_address_no_link(self):
        owner, lid = await self.advert()
        await self.visitor.get(f"/r/{lid}")
        self.assertIsNone(self.report_href(self.visitor.text))
        self.assertNotIn("أبلغ عن هذا الإعلان", self.visitor.text)

    async def test_the_link_opens_a_message_with_the_name_and_the_address_of_the_advert(self):
        owner, lid = await self.advert(title="استراحة النخيل")
        await self.save(MAIL)
        await self.visitor.get(f"/r/{lid}")
        href = self.report_href(self.visitor.text)
        self.assertIsNotNone(href)
        parts = urlsplit(href)
        self.assertEqual((parts.scheme, parts.path), ("mailto", MAIL))
        fields = parse_qs(parts.query)
        self.assertIn("استراحة النخيل", fields["subject"][0])
        self.assertIn("استراحة النخيل", fields["body"][0])
        self.assertIn(f"https://rest.example/r/{lid}", fields["body"][0])
        self.assertIn("سبب البلاغ", fields["body"][0])
        self.assertNotIn("استراحة", unquote(parts.query).split("body=")[0].replace("استراحة النخيل", ""))   # only the advert's own name is in the subject

    async def test_a_hostile_title_cannot_break_out_of_the_link_or_the_page(self):
        title = 'مزرعة "><script>alert(1)</script> & body=x'
        owner, lid = await self.advert(title=title)
        await self.save(MAIL)
        await self.visitor.get(f"/r/{lid}")
        html = self.visitor.text
        self.assertNotIn("<script>alert(1)", html)
        href = self.report_href(html)
        self.assertIsNotNone(href)
        self.assertEqual(sorted(parse_qs(urlsplit(href).query)), ["body", "subject"])
        self.assertIn("script", parse_qs(urlsplit(href).query)["subject"][0])                         # it is text in the message, read back as it was written

    async def test_a_preview_of_an_advert_that_is_not_public_has_nothing_to_report(self):
        owner, lid = await self.advert(approved=False)
        await self.save(MAIL)
        await owner.get(f"/r/{lid}")
        self.assertIn("هذه معاينة", owner.text)
        self.assertNotIn("أبلغ عن هذا الإعلان", owner.text)
        r = await self.visitor.get(f"/r/{lid}")
        self.assertEqual(r.status, 404)

    async def test_the_link_does_not_change_what_the_advert_page_did_before(self):
        owner, lid = await self.advert()
        await self.visitor.get(f"/r/{lid}")
        without = self.visitor.text
        await self.save(MAIL)
        await self.visitor.get(f"/r/{lid}")
        with_link = self.visitor.text
        removed = re.sub(r'<p class="fine report">.*?</p>', "", with_link)
        self.assertEqual(removed, without)                                                          # the whole difference is that one paragraph
        self.assertIn('data-copy="https://rest.example/r/', with_link)                              # and the other buttons are still there
        self.assertIn('id="wa"', with_link)


class FinalTextTests(SupportCase):
    async def test_the_terms_are_final_and_cover_what_the_platform_really_does(self):
        r = await self.visitor.get("/terms")
        self.assertEqual(r.status, 200)
        page = self.visitor.text
        self.assertNotIn("مبدئي", page)
        self.assertNotIn("تنبيه", page)
        self.assertNotIn("قانونيًا قبل إطلاق", page)
        for heading in ("ما هذه المنصة", "الحجز والدفع", "أصحاب الاستراحات", "العمولة", "حق المنصة", "الإبلاغ عن إعلان", "المحتوى الذي ترفعه",
                        "حذف الحساب", "حدود المسؤولية", "تعديل الشروط", "النظام المطبّق والتواصل"):
            self.assertIn(f"<h2>{heading}</h2>", page)
        self.assertIn("لا تستلم المنصة مبالغ الإيجار", page)                                           # the platform never holds the rent
        self.assertIn("حذف حسابي", page)
        self.assertIn('href="/support"', page)
        self.assertEqual(page.count("<h1>"), 1)

    async def test_the_privacy_page_is_final_and_tells_what_is_kept_and_what_is_deleted(self):
        r = await self.visitor.get("/privacy")
        self.assertEqual(r.status, 200)
        page = self.visitor.text
        self.assertNotIn("مبدئي", page)
        for heading in ("ما نجمعه من أصحاب الاستراحات", "الزوار", "ملفات الارتباط", "الصور", "رقم الواتساب", "الموقع والخريطة", "مع من نشارك بياناتك",
                        "الاحتفاظ بالبيانات وحذفها", "حقوقك", "الأطفال", "تعديل هذه السياسة", "التواصل"):
            self.assertIn(f"<h2>{heading}</h2>", page)
        self.assertIn("يُحذف فورًا حسابك وإعلاناتك وصورها", page)
        self.assertIn("نسخ احتياطية", page)                                                           # the one place a copy can stay is not hidden
        self.assertIn("تحذف حسابك متى شئت", page)
        self.assertIn("لا يحتوي الموقع ولا التطبيق على أدوات تتبع", page)
        self.assertIn("tile.openstreetmap.org", page)                                                # the map section is the same as before
        self.assertIn("ولا نرسل إليها شيئًا عنك", page)
        self.assertIn("من صفحة الدعم", page)

    async def test_the_privacy_page_gives_the_address_once_it_is_saved(self):
        await self.visitor.get("/privacy")
        self.assertNotIn(MAIL, self.visitor.text)
        await self.save(MAIL)
        await self.visitor.get("/privacy")
        self.assertIn(f"راسلنا على {MAIL}", self.visitor.text)

    async def test_the_page_never_says_the_texts_are_a_draft_anywhere_on_the_site(self):
        owner, lid = await self.advert()
        await self.save(MAIL)
        for path in ("/", "/search", "/offers", "/terms", "/privacy", "/support", f"/r/{lid}", "/owner/login", "/owner/register"):
            await self.visitor.get(path)
            self.assertNotIn("نص مبدئي", self.visitor.text, path)
            self.assertNotIn("مراجعته قانونيًا", self.visitor.text, path)


if __name__ == "__main__":
    unittest.main()
