"""The term plan of a class in a subject: its lessons in order, which are done, which comes now, which are late, and when each of the rest will be taught.

The lessons are the book's (curriculum.py), the periods are the class's periods in the timetable (schedule.py), the days are the term and its holidays (terms.py).
What the teacher says is stored (done, skipped, the order, the periods a lesson needs); where a lesson falls is worked out each time the plan is shown (planner.py),
so a lesson marked done, a holiday or a day she is absent moves what follows by itself, in the same order, and no lesson is ever removed by the plan.
"""
import contextlib
import datetime
import logging
import sqlite3

from flask import Blueprint, abort, current_app, g, jsonify, render_template, request

from . import billing, classroom, curriculum, planner, share, terms, textfmt
from .classroom import subject_row
from .db import now
from .lessons import mine, start as start_lesson
from .security import login_required
from .students import body, class_row, toint

log = logging.getLogger(__name__)
bp = Blueprint("plan", __name__)


# ---------------------------------------------------------------- helpers
def pair_link(cid, sid):
    """Her class and her subject (404 for anyone else's) and the link between them (she teaches this subject in this class)."""
    class_row(cid)
    subject_row(sid)
    link = current_app.db.execute("SELECT * FROM class_subjects WHERE class_id = ? AND subject_id = ? AND user_id = ?", (cid, sid, g.user["id"])).fetchone()
    if not link:
        abort(404)
    return link


def absent_set(db, uid, term) -> set:
    """The periods she cannot teach (her own absence): {(day, period)} and {(day, None)} for a whole day (recorded in absence.py)."""
    from . import absence
    return absence.absent_periods(db, uid, term)


def past_periods(db, uid, today) -> set:
    """Today's periods that have already ended (known only when she gave the times of her periods): a lesson not marked done does not stay in a period that is over."""
    now = classroom.now_local()
    if today != now.date():
        return set()
    clock = now.strftime("%H:%M")
    return {r["period"] for r in db.execute("SELECT period, ends FROM schedule_times WHERE user_id = ? AND ends != ''", (uid,)) if r["ends"] <= clock}


def used_today(rows, today) -> int:
    """How many periods of today the lessons marked done today have used (a lesson of two periods used two)."""
    return sum(r["periods"] for r in rows if r["status"] == "done" and r["done_on"] == today.isoformat())


def when(occ):
    return {"date": occ.day.isoformat(), "text": share.ar_date(occ.day.isoformat()), "period": occ.period}


def note(db, uid, cid, sid, term_id, kind, text):
    db.execute("INSERT INTO plan_log(user_id, class_id, subject_id, term_id, kind, text, created_at) VALUES (?,?,?,?,?,?,?)", (uid, cid, sid, term_id, kind, text[:300], now()))


def slots_of(db, uid, cid, sid):
    return [(r["day"], r["period"]) for r in db.execute("SELECT day, period FROM schedule_slots WHERE user_id = ? AND class_id = ? AND subject_id = ?", (uid, cid, sid))]


def item_rows(db, uid, cid, sid, term_id, book_id):
    return db.execute("""SELECT pi.*, bl.title, bl.kind, bl.first_page, bl.last_page, bl.unit_id, LENGTH(bl.text) AS size, bu.title AS unit_title, l.status AS lesson_status
                         FROM plan_items pi JOIN book_lessons bl ON bl.id = pi.book_lesson_id LEFT JOIN book_units bu ON bu.id = bl.unit_id LEFT JOIN lessons l ON l.id = pi.lesson_id
                         WHERE pi.user_id = ? AND pi.class_id = ? AND pi.subject_id = ? AND pi.term_id = ? AND bl.book_id = ? ORDER BY pi.position, pi.id""",
                      (uid, cid, sid, term_id, book_id)).fetchall()


# ---------------------------------------------------------------- building and re-basing
def sync_items(db, uid, cid, sid, term_id, book_id):
    """Make the plan hold every lesson of the book: the ones it does not have yet are added where the book puts them; what is there is left as it is."""
    lessons = db.execute("SELECT id, periods FROM book_lessons WHERE book_id = ? ORDER BY position, id", (book_id,)).fetchall()
    have = {r["book_lesson_id"]: r["id"] for r in db.execute("SELECT id, book_lesson_id FROM plan_items WHERE user_id = ? AND class_id = ? AND subject_id = ? AND term_id = ?", (uid, cid, sid, term_id))}
    order = [r["id"] for r in db.execute("""SELECT pi.id FROM plan_items pi JOIN book_lessons bl ON bl.id = pi.book_lesson_id
                                            WHERE pi.user_id = ? AND pi.class_id = ? AND pi.subject_id = ? AND pi.term_id = ? AND bl.book_id = ? ORDER BY pi.position, pi.id""",
                         (uid, cid, sid, term_id, book_id))]
    added, prev_item = 0, None
    for les in lessons:
        item = have.get(les["id"])
        if item is None:
            item = db.execute("""INSERT INTO plan_items(user_id, term_id, class_id, subject_id, book_lesson_id, position, periods, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)""",
                              (uid, term_id, cid, sid, les["id"], 0, les["periods"], now(), now())).lastrowid
            order.insert(order.index(prev_item) + 1 if prev_item in order else 0, item)
            added += 1
        prev_item = item
    for pos, item in enumerate(order):
        db.execute("UPDATE plan_items SET position = ? WHERE id = ?", (pos, item))
    return added


def rebase(db, uid, cid, sid, term, today):
    """Give every lesson that is not done the day it is due: in order, over the periods from today (or from the first day of the term when it has not begun). This is the
    plan «as it was meant to be» that lateness is measured against. The days she has said she is absent are already left out of it, and when something changes the periods
    later (an absence, a holiday, a new timetable) the due days move with it (realigning), so what was on time stays on time."""
    a, b = planner.parse_day(term["starts"]), planner.parse_day(term["ends"])
    first = max(a, today)
    occs = planner.occurrences(slots_of(db, uid, cid, sid), a, b, terms.holidays_of(db, term["id"]), absent_set(db, uid, term), first=first)
    pending = [dict(id=r["id"], periods=r["periods"], status=r["status"], together=r["together_with"]) for r in db.execute(
        "SELECT id, periods, status, together_with FROM plan_items WHERE user_id = ? AND class_id = ? AND subject_id = ? AND term_id = ? AND status = 'pending' ORDER BY position, id", (uid, cid, sid, term["id"]))]
    due = planner.baseline(pending, occs)
    for it in pending:
        o = due.get(it["id"])
        db.execute("UPDATE plan_items SET due_date = ?, due_period = ?, updated_at = ? WHERE id = ?", (o.day.isoformat() if o else "", o.period if o else 0, now(), it["id"]))


# ---------------------------------------------------------------- a change in the periods of the term moves the lessons
def ideas_of(st) -> list:
    """The ways to win back periods when there are too few: pairs of neighbouring lessons that could be taught together (the teacher decides; nothing changes by itself)."""
    by_id = {i["id"]: i for i in st["items"]}
    return [{"first": a, "second": b, "first_title": by_id[a]["title"] if a in by_id else "", "second_title": by_id[b]["title"] if b in by_id else "",
             "saves": by_id[b]["periods"] if b in by_id else 1} for a, b in st["ideas"]]


def snapshot(db, uid, today, absent_extra=()):
    """Where every plan of hers stands in this term, kept to be compared with the plan after a change. absent_extra: periods to count as days off too (a «what if»)."""
    term = terms.current(db, uid, today)
    out = {"term": term["id"] if term else None, "pairs": {}}
    if not term:
        return out
    absent = absent_set(db, uid, term) | set(absent_extra)
    for r in db.execute("SELECT DISTINCT class_id, subject_id FROM plan_items WHERE user_id = ? AND term_id = ? ORDER BY class_id, subject_id", (uid, term["id"])).fetchall():
        st = plan_state(db, uid, r["class_id"], r["subject_id"], today, absent=absent)
        if st["need"] in ("term", "book") or not st["items"]:
            continue
        out["pairs"][(r["class_id"], r["subject_id"])] = st
    return out


def moved_lessons(before, after) -> list:
    """The lessons not yet taught whose first period is somewhere else after a change, in plan order: [{id, title, from, to}] (None when there is no period)."""
    out = []
    for item in after["items"]:
        old = next((i for i in before["items"] if i["id"] == item["id"]), None)
        if not old or old["status"] != "pending" or item["status"] != "pending":
            continue
        a = old["planned"]["first"] if old["planned"] else None
        b = item["planned"]["first"] if item["planned"] else None
        if (a and (a["date"], a["period"])) != (b and (b["date"], b["period"])):
            out.append({"id": item["id"], "title": item["title"], "from": a, "to": b})
    return out


def short_date(text) -> str:
    """'الأحد 8 نوفمبر' from 'الأحد 8 نوفمبر 2026' (the year is dropped in the lines of the log)."""
    parts = str(text or "").split(" ")
    return " ".join(parts[:-1]) if len(parts) > 2 and parts[-1].isdigit() and len(parts[-1]) == 4 else str(text or "")


def _place(w) -> str:
    return f"{short_date(w['text'])} (الحصة {w['period']})" if w else "بلا موعد"


def directions(moved) -> dict:
    """How the lessons that moved went: later, earlier, to a period where there was none (gained), or into having no period (lost)."""
    key = lambda w: (w["date"], w["period"])
    return {"later": [m for m in moved if m["from"] and m["to"] and key(m["to"]) > key(m["from"])],
            "earlier": [m for m in moved if m["from"] and m["to"] and key(m["to"]) < key(m["from"])],
            "gained": [m for m in moved if not m["from"] and m["to"]],
            "lost": [m for m in moved if m["from"] and not m["to"]]}


def describe(why, moved) -> str:
    """One line for the plan's change log: why, how many lessons moved and where the first of them went."""
    d = directions(moved)
    later, earlier, gained, lost = d["later"], d["earlier"], d["gained"], d["lost"]
    parts = []
    if later:
        parts.append(f"تأجّل {textfmt.lessons(len(later))}")
    if earlier:
        parts.append(f"تقدّم {textfmt.lessons(len(earlier))}")
    if gained:
        parts.append(f"صار لـ{textfmt.lessons(len(gained))} موعد")
    if lost:
        parts.append(f"لم تعد الحصص تكفي لـ{textfmt.lessons(len(lost))}")
    head = (later or earlier or [None])[0]
    detail = f" — «{head['title']}» من {_place(head['from'])} إلى {_place(head['to'])}" if head else ""
    return f"{why}: " + "، ".join(parts) + detail


def effect_of(before, after, names, key) -> dict | None:
    """What a change did to one plan: None when no lesson moved."""
    moved = moved_lessons(before, after)
    if not moved:
        return None
    summ = after["summary"] or {}
    short = max(0, -summ.get("spare", 0))
    return {"class_id": key[0], "subject_id": key[1], "class_name": names[key][0], "subject_name": names[key][1], "moved_count": len(moved), "moved": moved[:8],
            **{name: len(found) for name, found in directions(moved).items()},
            "short": short, "unplaced": summ.get("unplaced", 0), "ideas": ideas_of(after) if short else []}


def _names(db, uid) -> dict:
    return {(r["class_id"], r["subject_id"]): (r["class_name"], r["subject_name"]) for r in db.execute(
        """SELECT cs.class_id, cs.subject_id, c.name AS class_name, s.name AS subject_name FROM class_subjects cs
           JOIN classes c ON c.id = cs.class_id JOIN subjects s ON s.id = cs.subject_id WHERE cs.user_id = ?""", (uid,))}


def effects_of(db, uid, before, after) -> list:
    names = _names(db, uid)
    out = []
    if before["term"] and before["term"] == after["term"]:
        for key, st in after["pairs"].items():
            if key in before["pairs"] and key in names:
                e = effect_of(before["pairs"][key], st, names, key)
                if e:
                    out.append(e)
    return out


def preview_effects(db, uid, extra_absent, today=None) -> list:
    """What the plans would do if these periods were days off too, without changing anything."""
    today = today or classroom.today_date()
    return effects_of(db, uid, snapshot(db, uid, today), snapshot(db, uid, today, extra_absent))


def settle(db, uid, before, after, why, today) -> list:
    """After a change in the periods of the term: every lesson keeps its place in the row of periods (so what was on time stays on time and what was late stays late), the change
    is written in the log of each plan it moved, and the effects are returned."""
    if not before["term"] or before["term"] != after["term"]:
        return []
    for key, st in after["pairs"].items():
        old = before["pairs"].get(key)
        if not old:
            continue
        rows = db.execute("SELECT id, due_date, due_period FROM plan_items WHERE user_id = ? AND class_id = ? AND subject_id = ? AND term_id = ? AND status = 'pending' ORDER BY position, id",
                          (uid, key[0], key[1], after["term"])).fetchall()
        dues = [((planner.parse_day(r["due_date"]), r["due_period"]) if planner.parse_day(r["due_date"]) else None) for r in rows]
        for r, was, now_ in zip(rows, dues, planner.shift_due(dues, old["occs"], st["occs"], today)):
            if now_ != was:
                db.execute("UPDATE plan_items SET due_date = ?, due_period = ?, updated_at = ? WHERE id = ?", (now_[0].isoformat() if now_ else "", now_[1] if now_ else 0, now(), r["id"]))
    effects = effects_of(db, uid, before, after)
    for e in effects:
        note(db, uid, e["class_id"], e["subject_id"], after["term"], "realign", describe(why, moved_lessons(before["pairs"][(e["class_id"], e["subject_id"])], after["pairs"][(e["class_id"], e["subject_id"])])))
    return effects


@contextlib.contextmanager
def realigning(db, uid, why, today=None):
    """Wrap a change to the periods of the term (an absence recorded or cancelled, a holiday, the timetable): the plans are compared before and after, the due days of the lessons
    move with the change, and each plan it moved gets a line in its log. The effects are in result["effects"] after the block. Nothing is committed here."""
    today = today or classroom.today_date()
    before = snapshot(db, uid, today)
    result = {"effects": []}
    yield result
    result["effects"] = settle(db, uid, before, snapshot(db, uid, today), why, today)


# ---------------------------------------------------------------- the plan as the screen shows it
def plan_state(db, uid, cid, sid, today, absent=None):
    """Everything about one plan, worked out now: {"need", "term", "book", "items", "summary", "ideas"}. `need` says what is missing before the plan can be shown
    (term, book, build); a missing timetable does not stop the plan, it only leaves the lessons without dates."""
    link = db.execute("SELECT * FROM class_subjects WHERE class_id = ? AND subject_id = ? AND user_id = ?", (cid, sid, uid)).fetchone()
    term = terms.current(db, uid, today)
    book = db.execute("SELECT * FROM books WHERE id = ? AND user_id = ?", (link["book_id"], uid)).fetchone() if link and link["book_id"] else None
    st = {"need": None, "term": terms.term_dict(term), "book": {"id": book["id"], "title": book["title"]} if book else None, "items": [], "summary": None, "ideas": [], "has_slots": False,
          "consumed": [], "occs": [], "term_row": term}
    if not term:
        st["need"] = "term"
        return st
    if not book:
        st["need"] = "book"
        return st
    rows = item_rows(db, uid, cid, sid, term["id"], book["id"])
    have_lessons = db.execute("SELECT COUNT(*) FROM book_lessons WHERE book_id = ?", (book["id"],)).fetchone()[0]
    if not rows or len(rows) < have_lessons:
        st["need"] = "build"
    slots = slots_of(db, uid, cid, sid)
    st["has_slots"] = bool(slots)
    a, b = planner.parse_day(term["starts"]), planner.parse_day(term["ends"])
    holidays = terms.holidays_of(db, term["id"])
    absent = absent_set(db, uid, term) if absent is None else absent          # (a given set is «what if»: the plan as it would be with those days off too)
    past = past_periods(db, uid, today)
    occs = planner.occurrences(slots, a, b, holidays, absent, first=today)
    # the periods of today that lessons she marked done today have used (the earliest ones) are not free for the next lesson, and a period that is over is not either
    todays = sorted((o for o in occs if o.day == today), key=lambda o: o.period)
    consumed = [o.period for o in todays[:used_today(rows, today)]]
    st["consumed"] = consumed
    st["occs"] = occs
    ahead = [o for o in occs if not (o.day == today and (o.period in past or o.period in consumed))]
    items = [dict(id=r["id"], periods=r["periods"], status=r["status"], kind=r["kind"], due=planner.parse_day(r["due_date"]), together=r["together_with"]) for r in rows]
    plan, unplaced = planner.assign(items, ahead)
    together = planner.merged(items)
    leads = {lead: follower for follower, lead in together.items()}
    summ = planner.summary(items, ahead, today, b)
    summ["unplaced"] = unplaced
    weights = {r["id"]: ((r["last_page"] - r["first_page"] + 1) if r["first_page"] and r["last_page"] >= r["first_page"] else max(1, (r["size"] or 0) // 2000)) for r in rows}
    out = []
    for r, it in zip(rows, items):
        first_last = plan.get(r["id"])
        late = r["status"] == "pending" and it["due"] is not None and it["due"] < today
        shifted = bool(first_last and it["due"] and first_last[1].day > it["due"] and not late)
        out.append({"id": r["id"], "book_lesson_id": r["book_lesson_id"], "title": r["title"], "unit": r["unit_title"] or "", "kind": r["kind"], "status": r["status"], "periods": r["periods"],
                    "position": r["position"], "done_on": r["done_on"], "done_text": share.ar_date(r["done_on"]) if r["done_on"] else "",
                    "due": {"date": r["due_date"], "text": share.ar_date(r["due_date"])} if r["due_date"] else None,
                    "planned": {"first": when(first_last[0]), "last": when(first_last[1])} if first_last else None,
                    "late": late, "shifted": shifted, "together": together.get(r["id"]), "leads": leads.get(r["id"]),
                    "has_text": (r["size"] or 0) >= 40, "lesson_id": r["lesson_id"], "lesson_status": r["lesson_status"],
                    "pages": [r["first_page"], r["last_page"]] if r["first_page"] else None, "note": r["note"]})
    st["items"] = out
    st["summary"] = summ
    short = max(0, -summ["spare"])
    st["ideas"] = planner.merge_ideas(items, short, weights) if short else []
    st["weights"] = weights
    return st


def view(db, uid, cid, sid, today):
    st = plan_state(db, uid, cid, sid, today)
    st.pop("term_row", None)
    st.pop("weights", None)
    st.pop("occs", None)
    st["ideas"] = ideas_of(st)
    st["log"] = [{"kind": r["kind"], "text": r["text"], "at": r["created_at"]} for r in db.execute(
        "SELECT kind, text, created_at FROM plan_log WHERE user_id = ? AND class_id = ? AND subject_id = ? ORDER BY id DESC LIMIT 15", (uid, cid, sid))]
    st["today"] = today.isoformat()
    st["today_text"] = share.ar_date(today.isoformat())
    c = db.execute("SELECT name FROM classes WHERE id = ?", (cid,)).fetchone()
    s = db.execute("SELECT name FROM subjects WHERE id = ?", (sid,)).fetchone()
    st["class"], st["subject"] = {"id": cid, "name": c["name"]}, {"id": sid, "name": s["name"]}
    return st


def pairs(db, uid, today):
    """Every class and subject she teaches together, with where its plan stands (for the chooser at the top of the screen)."""
    out = []
    rows = db.execute("""SELECT cs.class_id, cs.subject_id, c.name AS class_name, s.name AS subject_name, b.title AS book_title FROM class_subjects cs
                         JOIN classes c ON c.id = cs.class_id JOIN subjects s ON s.id = cs.subject_id LEFT JOIN books b ON b.id = cs.book_id
                         WHERE cs.user_id = ? ORDER BY c.id, s.name""", (uid,)).fetchall()
    for r in rows:
        st = plan_state(db, uid, r["class_id"], r["subject_id"], today)
        summ = st["summary"]
        current = next((i for i in st["items"] if i["id"] == summ["current"]), None) if summ else None
        out.append({"class_id": r["class_id"], "class_name": r["class_name"], "subject_id": r["subject_id"], "subject_name": r["subject_name"], "book": r["book_title"] or "",
                    "need": st["need"], "percent": summ["percent"] if summ else 0, "late": len(summ["late"]) if summ else 0, "current": current["title"] if current else ""})
    return out


# ---------------------------------------------------------------- pages and API
@bp.get("/plan")
@login_required
def page():
    return render_template("plan.html")


@bp.get("/api/plan/pairs")
@login_required
def pairs_api():
    return jsonify(pairs=pairs(current_app.db, g.user["id"], classroom.today_date()))


@bp.get("/api/plan")
@login_required
def plan_api():
    cid, sid = toint(request.args.get("class_id")), toint(request.args.get("subject_id"))
    pair_link(cid, sid)
    return jsonify(view(current_app.db, g.user["id"], cid, sid, classroom.today_date()))


def _answer(cid, sid):
    return jsonify(view(current_app.db, g.user["id"], cid, sid, classroom.today_date()))


@bp.post("/api/plan/build")
@login_required
def build():
    """Make the plan of a class in a subject from its book: every lesson of the book in order, each given the day it is due. Run again, it adds the lessons the book has gained."""
    data = body()
    cid, sid = toint(data.get("class_id")), toint(data.get("subject_id"))
    link = pair_link(cid, sid)
    db = current_app.db
    uid = g.user["id"]
    term = terms.current(db, uid)
    if not term:
        return jsonify(error="حدّدي بداية الفصل الدراسي ونهايته أولًا من صفحة التقويم"), 400
    if not link["book_id"]:
        return jsonify(error="اربطي كتابًا بهذا الفصل والمادة أولًا"), 400
    fresh = not db.execute("SELECT 1 FROM plan_items WHERE user_id = ? AND class_id = ? AND subject_id = ? AND term_id = ? LIMIT 1", (uid, cid, sid, term["id"])).fetchone()
    added = sync_items(db, uid, cid, sid, term["id"], link["book_id"])
    rebase(db, uid, cid, sid, term, classroom.today_date())
    if added:
        note(db, uid, cid, sid, term["id"], "build", "بُنيت الخطة من الكتاب" if fresh else f"أُضيف إلى الخطة {added} من دروس الكتاب")
    db.commit()
    return _answer(cid, sid)


def item_of(item_id):
    row = mine("plan_items", item_id)
    return row


def clear_links(db, ids):
    """Break the «taught together» link of these lessons and of every lesson linked to them (when one of the pair is moved, skipped or set aside, the merge ends)."""
    ids = [int(i) for i in ids]
    if ids:
        marks = ",".join("?" * len(ids))
        db.execute(f"UPDATE plan_items SET together_with = NULL WHERE id IN ({marks}) OR together_with IN ({marks})", ids + ids)


def _title(db, item):
    return db.execute("SELECT title FROM book_lessons WHERE id = ?", (item["book_lesson_id"],)).fetchone()["title"]


@bp.post("/api/plan/<int:item_id>/done")
@login_required
def mark_done(item_id):
    item = item_of(item_id)
    db = current_app.db
    day = planner.parse_day(body().get("date")) or classroom.today_date()
    if day > classroom.today_date():
        return jsonify(error="لا يمكن تسجيل درس منجزًا في يوم لم يأتِ بعد"), 400
    db.execute("UPDATE plan_items SET status = 'done', done_on = ?, updated_at = ? WHERE id = ?", (day.isoformat(), now(), item_id))
    with_it = []
    if item["status"] == "pending":          # the lesson taught in the same period (merged with it) was taught too
        with_it = db.execute("SELECT * FROM plan_items WHERE together_with = ? AND status = 'pending' AND position > ?", (item_id, item["position"])).fetchall()
    for f in with_it:
        db.execute("UPDATE plan_items SET status = 'done', done_on = ?, updated_at = ? WHERE id = ?", (day.isoformat(), now(), f["id"]))
    names = " و".join([_title(db, item)] + [_title(db, f) for f in with_it])
    note(db, g.user["id"], item["class_id"], item["subject_id"], item["term_id"], "done", f"سُجّل منجزًا: {names}")
    db.commit()
    return _answer(item["class_id"], item["subject_id"])


@bp.post("/api/plan/<int:item_id>/undo")
@login_required
def undo(item_id):
    item = item_of(item_id)
    db = current_app.db
    db.execute("UPDATE plan_items SET status = 'pending', done_on = '', updated_at = ? WHERE id = ?", (now(), item_id))
    with_it = db.execute("SELECT * FROM plan_items WHERE together_with = ? AND status = 'done' AND done_on = ?", (item_id, item["done_on"])).fetchall() if item["status"] == "done" else []
    for f in with_it:
        db.execute("UPDATE plan_items SET status = 'pending', done_on = '', updated_at = ? WHERE id = ?", (now(), f["id"]))
    names = " و".join([_title(db, item)] + [_title(db, f) for f in with_it])
    note(db, g.user["id"], item["class_id"], item["subject_id"], item["term_id"], "undo", f"أُعيد إلى القادمة: {names}")
    db.commit()
    return _answer(item["class_id"], item["subject_id"])


@bp.post("/api/plan/<int:item_id>/skip")
@login_required
def skip(item_id):
    """A lesson she will not teach this class (it stays in the list, greyed, and she can bring it back)."""
    item = item_of(item_id)
    db = current_app.db
    db.execute("UPDATE plan_items SET status = 'skipped', updated_at = ? WHERE id = ?", (now(), item_id))
    clear_links(db, [item_id])
    note(db, g.user["id"], item["class_id"], item["subject_id"], item["term_id"], "skip", f"استُبعد من الخطة: {_title(db, item)}")
    db.commit()
    return _answer(item["class_id"], item["subject_id"])


@bp.post("/api/plan/<int:item_id>/restore")
@login_required
def restore(item_id):
    item = item_of(item_id)
    db = current_app.db
    db.execute("UPDATE plan_items SET status = 'pending', updated_at = ? WHERE id = ?", (now(), item_id))
    note(db, g.user["id"], item["class_id"], item["subject_id"], item["term_id"], "restore", f"أُعيد إلى الخطة: {_title(db, item)}")
    db.commit()
    return _answer(item["class_id"], item["subject_id"])


@bp.patch("/api/plan/<int:item_id>")
@login_required
def edit(item_id):
    """The periods a lesson needs in this class (1 to 6) and a note of her own."""
    item = item_of(item_id)
    data = body()
    db = current_app.db
    if "periods" in data:
        p = toint(data.get("periods"))
        if not 1 <= p <= 6:
            return jsonify(error="عدد الحصص من 1 إلى 6"), 400
        if p != item["periods"]:
            db.execute("UPDATE plan_items SET periods = ?, updated_at = ? WHERE id = ?", (p, now(), item_id))
            note(db, g.user["id"], item["class_id"], item["subject_id"], item["term_id"], "periods", f"{_title(db, item)}: صارت حصصه {p}")
    if "note" in data:
        db.execute("UPDATE plan_items SET note = ?, updated_at = ? WHERE id = ?", (str(data.get("note") or "").strip()[:200], now(), item_id))
    db.commit()
    return _answer(item["class_id"], item["subject_id"])


@bp.post("/api/plan/<int:item_id>/move")
@login_required
def move(item_id):
    """One place earlier or later in her plan (the order of the book is not changed)."""
    item = item_of(item_id)
    step = -1 if body().get("dir") == "up" else 1
    db = current_app.db
    uid = g.user["id"]
    link = db.execute("SELECT book_id FROM class_subjects WHERE class_id = ? AND subject_id = ?", (item["class_id"], item["subject_id"])).fetchone()
    rows = item_rows(db, uid, item["class_id"], item["subject_id"], item["term_id"], link["book_id"]) if link and link["book_id"] else []
    ids = [r["id"] for r in rows]
    if item_id in ids:
        i = ids.index(item_id)
        j = i + step
        if 0 <= j < len(ids):
            ids[i], ids[j] = ids[j], ids[i]
            for pos, x in enumerate(ids):
                db.execute("UPDATE plan_items SET position = ? WHERE id = ?", (pos, x))
            clear_links(db, [ids[i], ids[j]])
            note(db, uid, item["class_id"], item["subject_id"], item["term_id"], "move", f"نُقل في الخطة: {_title(db, item)}")
            db.commit()
    return _answer(item["class_id"], item["subject_id"])


@bp.post("/api/plan/<int:item_id>/here")
@login_required
def here(item_id):
    """«وصلتُ إلى هنا»: every lesson before this one is done, this one is the lesson now, and the lessons left are laid out again from today."""
    item = item_of(item_id)
    db = current_app.db
    uid = g.user["id"]
    link = db.execute("SELECT book_id FROM class_subjects WHERE class_id = ? AND subject_id = ?", (item["class_id"], item["subject_id"])).fetchone()
    term = db.execute("SELECT * FROM terms WHERE id = ?", (item["term_id"],)).fetchone()
    rows = item_rows(db, uid, item["class_id"], item["subject_id"], item["term_id"], link["book_id"]) if link and link["book_id"] else []
    n, gone = 0, []
    for r in rows:
        if r["id"] == item_id:
            break
        if r["status"] == "pending":
            db.execute("UPDATE plan_items SET status = 'done', done_on = '', updated_at = ? WHERE id = ?", (now(), r["id"]))
            gone.append(r["id"])
            n += 1
    clear_links(db, gone)
    if n:
        note(db, uid, item["class_id"], item["subject_id"], item["term_id"], "here", f"اعتُبر {n} من الدروس السابقة منجزة حتى: {_title(db, item)}")
    rebase(db, uid, item["class_id"], item["subject_id"], term, classroom.today_date())
    db.commit()
    return _answer(item["class_id"], item["subject_id"])


@bp.post("/api/plan/rebuild")
@login_required
def rebuild():
    """Lay the lessons that are not done out again from today: they get new due days, so what was late is no longer late. For when the timetable or the term has changed, or she
    wants to start the count again."""
    data = body()
    cid, sid = toint(data.get("class_id")), toint(data.get("subject_id"))
    link = pair_link(cid, sid)
    db = current_app.db
    uid = g.user["id"]
    term = terms.current(db, uid)
    if not term or not link["book_id"]:
        return jsonify(error="حدّدي الفصل الدراسي واربطي كتابًا أولًا"), 400
    sync_items(db, uid, cid, sid, term["id"], link["book_id"])
    rebase(db, uid, cid, sid, term, classroom.today_date())
    note(db, uid, cid, sid, term["id"], "rebuild", "أُعيد توزيع الدروس غير المنجزة من اليوم")
    db.commit()
    return _answer(cid, sid)


@bp.post("/api/plan/merge")
@login_required
def merge():
    """Teach two neighbouring lessons together in one lesson's periods: the second takes no period of its own, so the periods it needed are won back. Both must be lessons
    of the same plan that are still to come, one right after the other. Nothing is deleted: «فكّ الدمج» gives the second its periods again."""
    data = body()
    first, second = item_of(toint(data.get("first"))), item_of(toint(data.get("second")))
    db = current_app.db
    uid = g.user["id"]
    same = (first["class_id"], first["subject_id"], first["term_id"]) == (second["class_id"], second["subject_id"], second["term_id"])
    if first["id"] == second["id"] or not same:
        return jsonify(error="اختاري درسين من خطة واحدة"), 400
    rows = db.execute("""SELECT pi.*, bl.kind FROM plan_items pi JOIN book_lessons bl ON bl.id = pi.book_lesson_id
                         WHERE pi.user_id = ? AND pi.class_id = ? AND pi.subject_id = ? AND pi.term_id = ? ORDER BY pi.position, pi.id""",
                      (uid, first["class_id"], first["subject_id"], first["term_id"])).fetchall()
    pending = [r for r in rows if r["status"] == "pending"]
    ids = [r["id"] for r in pending]
    if first["id"] not in ids or second["id"] not in ids:
        return jsonify(error="يمكن دمج الدروس القادمة فقط"), 400
    if ids.index(second["id"]) != ids.index(first["id"]) + 1:
        return jsonify(error="يمكن دمج درسين متتاليين فقط"), 400
    kinds = {r["id"]: r["kind"] for r in pending}
    if kinds[first["id"]] != "lesson" or kinds[second["id"]] != "lesson":
        return jsonify(error="الدمج للدروس فقط، لا للمراجعة ولا للاختبار"), 400
    if first["together_with"] or second["together_with"] or any(r["together_with"] in (first["id"], second["id"]) for r in pending):
        return jsonify(error="أحد الدرسين مدموج مع درس آخر. فكّي دمجه أولًا"), 400
    db.execute("UPDATE plan_items SET together_with = ?, due_date = ?, due_period = ?, updated_at = ? WHERE id = ?", (first["id"], first["due_date"], first["due_period"], now(), second["id"]))
    note(db, uid, first["class_id"], first["subject_id"], first["term_id"], "merge", f"دُمج الدرسان في حصص واحدة: {_title(db, first)} + {_title(db, second)}")
    db.commit()
    return _answer(first["class_id"], first["subject_id"])


@bp.post("/api/plan/<int:item_id>/unmerge")
@login_required
def unmerge(item_id):
    """Give the lesson its own periods again (it may be either of the two that were merged)."""
    item = item_of(item_id)
    db = current_app.db
    rows = db.execute("SELECT id FROM plan_items WHERE id = ? OR together_with = ?", (item_id, item_id)).fetchall()
    if not item["together_with"] and len(rows) < 2:
        return jsonify(error="هذا الدرس غير مدموج"), 400
    lead = item["together_with"] or item_id
    follower = item_id if item["together_with"] else next(r["id"] for r in rows if r["id"] != item_id)
    pair = [db.execute("SELECT * FROM plan_items WHERE id = ?", (x,)).fetchone() for x in (lead, follower)]
    clear_links(db, [lead, follower])
    note(db, g.user["id"], item["class_id"], item["subject_id"], item["term_id"], "unmerge", f"فُكّ دمج الدرسين: {_title(db, pair[0])} + {_title(db, pair[1])}")
    db.commit()
    return _answer(item["class_id"], item["subject_id"])


@bp.get("/api/plan/spread")
@login_required
def spread_preview():
    """How many periods each lesson could take so the lessons left fill the periods left, by the size of each (pages)."""
    cid, sid = toint(request.args.get("class_id")), toint(request.args.get("subject_id"))
    pair_link(cid, sid)
    db = current_app.db
    st = plan_state(db, g.user["id"], cid, sid, classroom.today_date())
    if st["need"] or not st["summary"]:
        return jsonify(error="ابني الخطة أولًا"), 400
    pend = [i for i in st["items"] if i["status"] == "pending"]
    total = st["summary"]["periods_left"]
    if not pend or not total:
        return jsonify(error="لا توجد حصص قادمة في الجدول لتوزيعها. أضيفي حصص هذه المادة في الجدول"), 400
    proposal = planner.suggest_periods([st["weights"].get(i["id"], 1) for i in pend], total, cap=planner.MAX_SHARED_PERIODS)
    return jsonify(items=[{"id": i["id"], "title": i["title"], "from": i["periods"], "to": p} for i, p in zip(pend, proposal)], total=total, assigned=sum(proposal), spare=total - sum(proposal))


@bp.post("/api/plan/spread")
@login_required
def spread_apply():
    data = body()
    cid, sid = toint(data.get("class_id")), toint(data.get("subject_id"))
    pair_link(cid, sid)
    db = current_app.db
    uid = g.user["id"]
    today = classroom.today_date()
    st = plan_state(db, uid, cid, sid, today)
    if st["need"] or not st["summary"]:
        return jsonify(error="ابني الخطة أولًا"), 400
    pend = [i for i in st["items"] if i["status"] == "pending"]
    total = st["summary"]["periods_left"]
    if not pend or not total:
        return jsonify(error="لا توجد حصص قادمة في الجدول لتوزيعها"), 400
    proposal = planner.suggest_periods([st["weights"].get(i["id"], 1) for i in pend], total, cap=planner.MAX_SHARED_PERIODS)
    for i, p in zip(pend, proposal):
        db.execute("UPDATE plan_items SET periods = ?, updated_at = ? WHERE id = ?", (p, now(), i["id"]))
    rebase(db, uid, cid, sid, st["term_row"], today)
    note(db, uid, cid, sid, st["term_row"]["id"], "spread", "وُزّعت الحصص على الدروس القادمة بحسب حجم كل درس")
    db.commit()
    return _answer(cid, sid)


# ---------------------------------------------------------------- making a lesson of the app from a lesson of the book
@bp.post("/api/plan/<int:item_id>/lesson")
@login_required
def make_lesson(item_id):
    """Turn the book's lesson into a lesson of the app (explanation, questions, the games): it is read from the text kept from the book, and it counts once towards her plan
    (making it again from the same book lesson does not count twice). A lesson the book had no text for takes the text she pastes (`text`)."""
    item = item_of(item_id)
    db = current_app.db
    uid = g.user["id"]
    if item["lesson_id"]:
        row = db.execute("SELECT id, status FROM lessons WHERE id = ? AND user_id = ?", (item["lesson_id"], uid)).fetchone()
        if row:
            return jsonify(lesson_id=row["id"], status=row["status"])
    bl = db.execute("SELECT bl.*, b.subject AS book_subject, b.grade AS book_grade FROM book_lessons bl JOIN books b ON b.id = bl.book_id WHERE bl.id = ?", (item["book_lesson_id"],)).fetchone()
    pasted = str(body().get("text") or "").strip()[:60000]
    text = bl["text"] or ""
    if len(text.strip()) < 40 and len(pasted) < 40:
        curriculum.start_refill(current_app._get_current_object(), bl["book_id"])       # the book is already here: read the lesson's text from its file before asking her for anything
        if not current_app.cfg.background:                       # read at once (the tests, a single-process run): look again
            bl = db.execute("SELECT bl.*, b.subject AS book_subject, b.grade AS book_grade FROM book_lessons bl JOIN books b ON b.id = bl.book_id WHERE bl.id = ?", (bl["id"],)).fetchone()
        text = bl["text"] or ""
        if len(text.strip()) < 40 and current_app.cfg.background:
            return jsonify(error="نقرأ نص هذا الدرس من ملف الكتاب الآن، وقد يستغرق دقيقة. أعيدي الضغط على «حوّلي الدرس» بعد قليل", reading=True), 202
    if len(text.strip()) < 40:
        if len(pasted) < 40:
            return jsonify(error="لم نجد نص هذا الدرس في الكتاب. الصقي نصه هنا، أو ارفعي ملف الدرس من «لوحتي»", need_text=True), 400
        text = pasted
        db.execute("UPDATE book_lessons SET text = ? WHERE id = ?", (text, bl["id"]))
    key = f"book-{bl['id']}"
    counted = db.execute("SELECT 1 FROM lesson_usage WHERE user_id = ? AND file_key = ?", (uid, key)).fetchone()
    if not counted:
        allow = billing.lesson_allowance(db, g.user)
        if allow["left"] <= 0:
            return jsonify(error=billing.lesson_limit_msg(allow)), 400
    subject = db.execute("SELECT name FROM subjects WHERE id = ?", (item["subject_id"],)).fetchone()["name"]
    cur = db.execute("INSERT INTO lessons(user_id, title, original_name, stored_name, kind, text, subject, grade, status, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,'processing',?,?)",
                     (uid, bl["title"][:100], "من الكتاب", key, "book", text, subject[:80], (bl["book_grade"] or "")[:80], now(), now()))
    db.execute("UPDATE plan_items SET lesson_id = ?, updated_at = ? WHERE id = ?", (cur.lastrowid, now(), item_id))
    db.commit()
    start_lesson(current_app._get_current_object(), cur.lastrowid)
    row = db.execute("SELECT status FROM lessons WHERE id = ?", (cur.lastrowid,)).fetchone()
    return jsonify(lesson_id=cur.lastrowid, status=row["status"]), 201


# ---------------------------------------------------------------- today (the home screen, the start screen)
def _covers(item, day_iso, period) -> bool:
    pl = item["planned"]
    return bool(pl) and (pl["first"]["date"], pl["first"]["period"]) <= (day_iso, period) <= (pl["last"]["date"], pl["last"]["period"])


def today_plan(db, uid, today=None):
    """Her periods today with the lesson the plan puts in each: {"periods": [{period, time, class, subject, state, lesson}], "off": why nobody teaches today ('' when somebody does)}.
    A period already over (when the times of her periods are known) is shown as past, with no lesson."""
    today = today or classroom.today_date()
    term = terms.current(db, uid, today)
    rows = db.execute("""SELECT s.period, s.class_id, s.subject_id, c.name AS class_name, sub.name AS subject_name FROM schedule_slots s
                         JOIN classes c ON c.id = s.class_id JOIN subjects sub ON sub.id = s.subject_id WHERE s.user_id = ? AND s.day = ? ORDER BY s.period""", (uid, planner.sun0(today))).fetchall()
    if not rows:
        return {"periods": [], "off": ""}
    off = ""
    if term:
        a, b = planner.parse_day(term["starts"]), planner.parse_day(term["ends"])
        holidays = terms.holidays_of(db, term["id"])
        if today in holidays:
            off = holidays[today]
        elif not (a <= today <= b):
            off = "خارج الفصل الدراسي"
    times = {r["period"]: (r["starts"], r["ends"]) for r in db.execute("SELECT period, starts, ends FROM schedule_times WHERE user_id = ?", (uid,))}
    past = past_periods(db, uid, today)
    gone = absent_set(db, uid, term) if term and not off else set()
    states, taught, out = {}, {}, []
    for r in rows:
        key = (r["class_id"], r["subject_id"])
        if term and not off and key not in states:
            states[key] = plan_state(db, uid, r["class_id"], r["subject_id"], today)
            st = states[key]
            done_now = [i for i in st["items"] if i["status"] == "done" and i["done_on"] == today.isoformat()]
            spread = [i for i in done_now for _ in range(i["periods"])]          # a lesson of two periods fills two of today's periods
            taught[key] = {p: spread[n] for n, p in enumerate(st["consumed"]) if n < len(spread)}
        item, state = None, "now"
        done_here = taught.get(key, {}).get(r["period"])
        if done_here:
            item, state = done_here, "done"
        elif (today, None) in gone or (today, r["period"]) in gone:
            state = "absent"
        elif r["period"] in past:
            state = "past"
        elif term and not off:
            item = next((i for i in states[key]["items"] if i["status"] == "pending" and _covers(i, today.isoformat(), r["period"])), None)
        t = times.get(r["period"])
        out.append({"period": r["period"], "time": f"{t[0]}–{t[1]}" if t and t[0] and t[1] else "", "class_id": r["class_id"], "class_name": r["class_name"],
                    "subject_id": r["subject_id"], "subject_name": r["subject_name"], "state": state,
                    "lesson": {"id": item["id"], "title": item["title"], "lesson_id": item["lesson_id"], "late": item["late"] and state != "done", "periods": item["periods"]} if item else None})
    return {"periods": out, "off": off, "absent_day": (today, None) in gone}


@bp.get("/api/today")
@login_required
def today_api():
    return jsonify(today_plan(current_app.db, g.user["id"]))
