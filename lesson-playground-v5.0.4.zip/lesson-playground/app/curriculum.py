"""The curriculum: the books a teacher teaches from, as units and lessons.

She gives the app a book (a PDF, a Word file, a PowerPoint, a picture of the contents page) or types its contents herself. The book is read in the
background (a long one takes a while and shows how far it has come), the units and lessons are proposed, and she fixes them on a screen and confirms. A book is
linked to the classes that use it, and a lesson of the book can later be turned into a lesson of the app (plan.py), which is the only thing that counts
towards her plan: reading a book costs nothing.
"""
import io
import logging
import threading
import uuid

from flask import Blueprint, abort, current_app, g, jsonify, render_template, request

from . import bookread, db as dbm, extract
from .classroom import ensure_subject, subjects_list
from .db import now
from .lessons import mine
from .security import Limiter, login_required
from .students import body, class_row, clean_name, toint

log = logging.getLogger(__name__)
bp = Blueprint("curriculum", __name__)
MAX_BOOKS = 12
MAX_PERIODS = 6
book_limit = Limiter(10, 3600)
outline_limit = Limiter(60, 3600)
reread_limit = Limiter(20, 3600)


# ---------------------------------------------------------------- reading a book (a worker thread with its own connection)
def process(app, book_id: int):
    conn = dbm.connect(app.cfg.db_path)
    try:
        book = conn.execute("SELECT * FROM books WHERE id = ?", (book_id,)).fetchone()
        if not book:
            return
        try:
            data = (app.cfg.upload_dir / book["stored_name"]).read_bytes()

            def progress(n):
                conn.execute("UPDATE books SET progress = ? WHERE id = ?", (n, book_id))
                conn.commit()

            if book["kind"] == "pdf":                    # how many pages there are, so the screen can say «قرأنا 40 من 200 صفحة» while it reads
                try:
                    from pypdf import PdfReader
                    total = min(len(PdfReader(io.BytesIO(data)).pages), extract.BOOK_MAX_PAGES)
                    conn.execute("UPDATE books SET pages = ? WHERE id = ?", (total, book_id))
                    conn.commit()
                except Exception:
                    pass

            info = extract.book_lines(book["kind"], data, progress)
            res = bookread.analyze(info["lines"], info["pages"], info["hints"])
            known = [r["name"] for r in conn.execute("SELECT name FROM subjects WHERE user_id = ?", (book["user_id"],))]
            subject, grade = bookread.detect_meta(info["first_text"], book["original_name"], known)
            if not conn.execute("SELECT 1 FROM books WHERE id = ?", (book_id,)).fetchone():
                return                                   # she deleted the book while it was being read
            conn.execute("DELETE FROM book_units WHERE book_id = ?", (book_id,))
            conn.execute("DELETE FROM book_lessons WHERE book_id = ?", (book_id,))
            store_structure(conn, book["user_id"], book_id, res["units"], with_text=True)
            warn = " ".join(x for x in (info["warn"], res["warn"]) if x)
            conn.execute("UPDATE books SET subject = ?, grade = ?, pages = ?, progress = ?, status = 'ready', error = '', warn = ?, updated_at = ? WHERE id = ?",
                         (subject, grade, info["page_count"], info["page_count"], warn[:600], now(), book_id))
        except extract.ExtractError as exc:
            conn.execute("UPDATE books SET status = 'failed', error = ?, updated_at = ? WHERE id = ?", (str(exc), now(), book_id))
        except Exception:
            log.exception("could not read book %s", book_id)
            conn.execute("UPDATE books SET status = 'failed', error = ?, updated_at = ? WHERE id = ?", ("حدث خطأ أثناء قراءة الكتاب، جرّبي ملفًا آخر أو اكتبي الفهرس بنفسك", now(), book_id))
        conn.commit()
    finally:
        conn.close()


_refilling = set()


def refill_texts(app, book_id: int):
    """A lesson saved with no text (the book was read by an older reader, or its heading was not printed) gets its text from the stored file, by its page range or its title.
    The units, the lessons, their order and everything she changed stay as they are: only empty texts are filled."""
    if book_id in _refilling:
        return
    _refilling.add(book_id)
    conn = dbm.connect(app.cfg.db_path)
    try:
        book = conn.execute("SELECT * FROM books WHERE id = ?", (book_id,)).fetchone()
        if not book or book["kind"] == "manual" or not book["stored_name"]:
            return
        data = (app.cfg.upload_dir / book["stored_name"]).read_bytes()
        info = extract.book_lines(book["kind"], data)
        res = bookread.analyze(info["lines"], info["pages"], info["hints"])
        found = [l for u in res["units"] for l in u["lessons"] if l.get("text")]
        by_page = {l["first_page"]: l for l in found if l.get("first_page")}
        by_title = {bookread.ck(l["title"]): l for l in found}
        for row in conn.execute("SELECT id, title, first_page FROM book_lessons WHERE book_id = ? AND length(trim(text)) < 40", (book_id,)).fetchall():
            hit = by_page.get(row["first_page"]) if row["first_page"] else None
            hit = hit or by_title.get(bookread.ck(row["title"]))
            if hit:
                conn.execute("UPDATE book_lessons SET text = ? WHERE id = ?", (extract._reflow(hit["text"])[:bookread.MAX_TEXT], row["id"]))
        conn.commit()
    except Exception:
        log.exception("could not refill the texts of book %s", book_id)
    finally:
        conn.close()
        _refilling.discard(book_id)


def start_refill(app, book_id: int):
    if book_id in _refilling:
        return
    if app.cfg.background:
        threading.Thread(target=refill_texts, args=(app, book_id), daemon=True).start()
    else:
        refill_texts(app, book_id)


def start(app, book_id: int):
    if app.cfg.background:
        threading.Thread(target=process, args=(app, book_id), daemon=True).start()
    else:
        process(app, book_id)


def store_structure(conn, uid: int, book_id: int, units, with_text: bool = False):
    """Write the units and lessons bookread found (or the outline she pasted) in the order they come."""
    position, n_lessons = 0, 0
    for u_pos, unit in enumerate(units[:bookread.MAX_UNITS]):
        unit_id = None
        if unit["title"]:
            unit_id = conn.execute("INSERT INTO book_units(user_id, book_id, title, position) VALUES (?,?,?,?)", (uid, book_id, unit["title"][:bookread.MAX_TITLE], u_pos)).lastrowid
        for les in unit["lessons"]:
            if n_lessons >= bookread.MAX_LESSONS:
                return
            text = extract._reflow(les["text"]) if with_text and les.get("text") else ""
            conn.execute("INSERT INTO book_lessons(user_id, book_id, unit_id, title, position, first_page, last_page, periods, kind, text) VALUES (?,?,?,?,?,?,?,?,?,?)",
                         (uid, book_id, unit_id, les["title"][:bookread.MAX_TITLE], position, les.get("first_page") or 0, les.get("last_page") or 0, 1,
                          les.get("kind") or "lesson", text[:bookread.MAX_TEXT]))
            position += 1
            n_lessons += 1


# ---------------------------------------------------------------- what the screens read
def book_detail(bid: int) -> dict:
    db = current_app.db
    uid = g.user["id"]
    b = mine("books", bid)
    units = [{"id": r["id"], "title": r["title"], "lessons": []} for r in db.execute("SELECT id, title FROM book_units WHERE book_id = ? ORDER BY position, id", (bid,))]
    by_id = {u["id"]: u for u in units}
    loose = {"id": None, "title": "", "lessons": []}
    done = {r["book_lesson_id"]: r["n"] for r in db.execute(
        "SELECT book_lesson_id, COUNT(*) AS n FROM plan_items WHERE user_id = ? AND status = 'done' GROUP BY book_lesson_id", (uid,))}
    for r in db.execute("SELECT id, unit_id, title, kind, periods, first_page, last_page, LENGTH(text) AS size FROM book_lessons WHERE book_id = ? ORDER BY position, id", (bid,)):
        les = {"id": r["id"], "title": r["title"], "kind": r["kind"], "periods": r["periods"], "first_page": r["first_page"], "last_page": r["last_page"],
               "has_text": (r["size"] or 0) >= 40, "done": done.get(r["id"], 0)}
        (by_id.get(r["unit_id"]) or loose)["lessons"].append(les)
    out_units = ([loose] if loose["lessons"] else []) + units
    linked = {r["class_id"]: r["subject_id"] for r in db.execute("SELECT class_id, subject_id FROM class_subjects WHERE book_id = ? AND user_id = ?", (bid, uid))}
    subject_id = next((s["id"] for s in subjects_list() if bookread.ck(s["name"]) == bookread.ck(b["subject"])), None)
    other = {}
    if subject_id:
        for r in db.execute("SELECT cs.class_id, bk.id AS book_id, bk.title FROM class_subjects cs JOIN books bk ON bk.id = cs.book_id WHERE cs.user_id = ? AND cs.subject_id = ? AND cs.book_id != ?",
                            (uid, subject_id, bid)):
            other[r["class_id"]] = r["title"]
    classes = [{"id": c["id"], "name": c["name"], "linked": c["id"] in linked, "other": other.get(c["id"], "")}
               for c in db.execute("SELECT id, name FROM classes WHERE user_id = ? ORDER BY id", (uid,))]
    return {"id": b["id"], "title": b["title"], "subject": b["subject"], "grade": b["grade"], "kind": b["kind"], "status": b["status"], "progress": b["progress"], "pages": b["pages"],
            "error": b["error"], "warn": b["warn"], "confirmed": bool(b["confirmed"]), "units": out_units, "classes": classes,
            "lessons": sum(len(u["lessons"]) for u in out_units), "subjects": [s["name"] for s in subjects_list()]}


def books_list():
    db = current_app.db
    uid = g.user["id"]
    counts = {r["book_id"]: r["n"] for r in db.execute("SELECT book_id, COUNT(*) AS n FROM book_lessons WHERE user_id = ? GROUP BY book_id", (uid,))}
    units = {r["book_id"]: r["n"] for r in db.execute("SELECT book_id, COUNT(*) AS n FROM book_units WHERE user_id = ? GROUP BY book_id", (uid,))}
    classes = {}
    for r in db.execute("SELECT cs.book_id, c.name FROM class_subjects cs JOIN classes c ON c.id = cs.class_id WHERE cs.user_id = ? AND cs.book_id IS NOT NULL ORDER BY c.id", (uid,)):
        classes.setdefault(r["book_id"], []).append(r["name"])
    return [{"id": b["id"], "title": b["title"], "subject": b["subject"], "grade": b["grade"], "status": b["status"], "progress": b["progress"], "pages": b["pages"],
             "confirmed": bool(b["confirmed"]), "error": b["error"], "lessons": counts.get(b["id"], 0), "units": units.get(b["id"], 0), "classes": classes.get(b["id"], [])}
            for b in db.execute("SELECT * FROM books WHERE user_id = ? ORDER BY id DESC", (uid,))]


# ---------------------------------------------------------------- pages and the API
@bp.get("/curriculum")
@login_required
def page():
    return render_template("curriculum.html", max_mb=current_app.cfg.max_book_mb)


@bp.get("/curriculum/<int:bid>")
@login_required
def book_page(bid):
    return render_template("book.html", book=mine("books", bid))


@bp.get("/api/books")
@login_required
def books():
    return jsonify(books=books_list())


@bp.post("/api/books")
@login_required
def upload():
    """A book as a file (multipart `file`, optional `title`). The book is read in the background; the answer is its id, and the screen asks again until it is ready."""
    db = current_app.db
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify(error="اختاري ملف الكتاب أولًا"), 400
    if not book_limit.allow(g.user["id"]):
        return jsonify(error="رفعتِ كتبًا كثيرة خلال ساعة، جرّبي بعد قليل"), 429
    if db.execute("SELECT COUNT(*) FROM books WHERE user_id = ?", (g.user["id"],)).fetchone()[0] >= MAX_BOOKS:
        return jsonify(error=f"الحد الأقصى {MAX_BOOKS} كتابًا. احذفي كتابًا قديمًا لإضافة جديد"), 400
    data = f.read()
    limit = current_app.cfg.max_book_mb
    if len(data) > limit * 1024 * 1024:
        return jsonify(error=f"الكتاب كبير، الحد الأقصى {limit} ميجابايت"), 413
    if not data:
        return jsonify(error="الملف فارغ"), 400
    try:
        kind = extract.detect_book(f.filename, data[:16])
    except extract.ExtractError as exc:
        return jsonify(error=str(exc)), 400
    stored = uuid.uuid4().hex + "." + f.filename.rsplit(".", 1)[-1].lower()
    (current_app.cfg.upload_dir / stored).write_bytes(data)
    title = clean_name(request.form.get("title") or f.filename.rsplit(".", 1)[0])[:100] or "كتاب"
    cur = db.execute("INSERT INTO books(user_id, title, original_name, stored_name, kind, status, created_at, updated_at) VALUES (?,?,?,?,?,'processing',?,?)",
                     (g.user["id"], title, f.filename[:200], stored, kind, now(), now()))
    db.commit()
    start(current_app._get_current_object(), cur.lastrowid)
    return jsonify(id=cur.lastrowid), 201


@bp.post("/api/books/outline")
@login_required
def new_outline():
    """A book made from a list she typed (no file): the title and the contents, one lesson to a line."""
    data = body()
    db = current_app.db
    title = clean_name(data.get("title"))[:100]
    if len(title) < 2:
        return jsonify(error="اكتبي اسم الكتاب"), 400
    units = bookread.parse_outline(str(data.get("text") or "")[:60000])
    if sum(len(u["lessons"]) for u in units) < 1:
        return jsonify(error="لم نجد دروسًا في ما كتبتِ. اكتبي كل درس في سطر"), 400
    if db.execute("SELECT COUNT(*) FROM books WHERE user_id = ?", (g.user["id"],)).fetchone()[0] >= MAX_BOOKS:
        return jsonify(error=f"الحد الأقصى {MAX_BOOKS} كتابًا. احذفي كتابًا قديمًا لإضافة جديد"), 400
    cur = db.execute("INSERT INTO books(user_id, title, kind, status, created_at, updated_at) VALUES (?,?,'manual','ready',?,?)", (g.user["id"], title, now(), now()))
    store_structure(db, g.user["id"], cur.lastrowid, units)
    db.commit()
    return jsonify(id=cur.lastrowid), 201


@bp.get("/api/books/<int:bid>")
@login_required
def detail(bid):
    return jsonify(book_detail(bid))


@bp.post("/api/books/<int:bid>/outline")
@login_required
def replace_outline(bid):
    """The contents pasted over a book the reader could not make sense of: they replace the units and lessons (what the teacher already confirmed is not touched)."""
    b = mine("books", bid)
    if b["status"] == "processing":
        return jsonify(error="ما زال الكتاب قيد القراءة"), 409
    if b["confirmed"]:
        return jsonify(error="هذا الكتاب مؤكَّد. عدّلي دروسه من الشاشة نفسها"), 409
    units = bookread.parse_outline(str(body().get("text") or "")[:60000])
    if sum(len(u["lessons"]) for u in units) < 1:
        return jsonify(error="لم نجد دروسًا في ما كتبتِ. اكتبي كل درس في سطر"), 400
    db = current_app.db
    db.execute("DELETE FROM book_units WHERE book_id = ?", (bid,))
    db.execute("DELETE FROM book_lessons WHERE book_id = ?", (bid,))
    store_structure(db, g.user["id"], bid, units)
    db.execute("UPDATE books SET status = 'ready', error = '', warn = '', updated_at = ? WHERE id = ?", (now(), bid))
    db.commit()
    return jsonify(book_detail(bid))


@bp.post("/api/books/<int:bid>/reread")
@login_required
def reread(bid):
    """The book read again from the file she uploaded (the reader may understand it better than it did): only a book she has not confirmed, so nothing she
    approved is replaced. The units and lessons stay on the screen until the new reading is ready."""
    b = mine("books", bid)
    if b["kind"] == "manual" or not b["stored_name"]:
        return jsonify(error="هذا الكتاب كُتب بدون ملف، فليس هناك ما يُعاد قراءته"), 400
    if b["status"] == "processing":
        return jsonify(error="ما زال الكتاب قيد القراءة"), 409
    if b["confirmed"]:
        return jsonify(error="هذا الكتاب مؤكَّد. عدّلي دروسه من الشاشة نفسها"), 409
    if not (current_app.cfg.upload_dir / b["stored_name"]).is_file():
        return jsonify(error="ملف الكتاب لم يعد موجودًا على الخادم. ارفعيه من جديد"), 410
    if not reread_limit.allow(g.user["id"]):
        return jsonify(error="أعدتِ قراءة كتب كثيرة خلال ساعة، جرّبي بعد قليل"), 429
    db = current_app.db
    db.execute("UPDATE books SET status = 'processing', progress = 0, error = '', warn = '', updated_at = ? WHERE id = ?", (now(), bid))
    db.commit()
    start(current_app._get_current_object(), bid)
    return jsonify(book_detail(bid))


@bp.put("/api/books/<int:bid>")
@login_required
def save(bid):
    """The book as the teacher confirms it: its name, subject and class, its units and lessons in order (a lesson with its id keeps its text and its place in the plan; a lesson
    left out is removed), the periods each lesson needs, and the classes that use it."""
    book = mine("books", bid)
    if book["status"] == "processing":
        return jsonify(error="ما زال الكتاب قيد القراءة"), 409
    data = body()
    db = current_app.db
    uid = g.user["id"]
    title = clean_name(data.get("title"))[:100]
    subject = clean_name(data.get("subject"))[:40]
    grade = clean_name(data.get("grade"))[:60]
    if len(title) < 2:
        return jsonify(error="اكتبي اسم الكتاب"), 400
    if len(subject) < 2:
        return jsonify(error="اكتبي اسم المادة"), 400
    units_in = data.get("units")
    if not isinstance(units_in, list) or len(units_in) > bookread.MAX_UNITS + 1:
        return jsonify(error="بيانات الوحدات غير صحيحة"), 400
    total = sum(len(u.get("lessons") or []) for u in units_in if isinstance(u, dict))
    if total > bookread.MAX_LESSONS:
        return jsonify(error=f"الحد الأقصى {bookread.MAX_LESSONS} درسًا في الكتاب"), 400
    if total < 1:
        return jsonify(error="أضيفي درسًا واحدًا على الأقل"), 400
    class_ids = [toint(x) for x in (data.get("class_ids") or []) if isinstance(x, int)]
    for cid in class_ids:
        class_row(cid)                                   # her own classes only
    have_units = {r["id"] for r in db.execute("SELECT id FROM book_units WHERE book_id = ?", (bid,))}
    have_lessons = {r["id"] for r in db.execute("SELECT id FROM book_lessons WHERE book_id = ?", (bid,))}
    keep_units, keep_lessons = set(), set()
    try:
        position = 0
        for u_pos, unit in enumerate(units_in):
            if not isinstance(unit, dict):
                raise ValueError
            utitle = clean_name(unit.get("title"))[:bookread.MAX_TITLE]
            unit_id = None
            if utitle:
                uid_in = unit.get("id")
                if isinstance(uid_in, int) and uid_in in have_units and uid_in not in keep_units:
                    unit_id = uid_in
                    db.execute("UPDATE book_units SET title = ?, position = ? WHERE id = ?", (utitle, u_pos, unit_id))
                else:
                    unit_id = db.execute("INSERT INTO book_units(user_id, book_id, title, position) VALUES (?,?,?,?)", (uid, bid, utitle, u_pos)).lastrowid
                keep_units.add(unit_id)
            for les in unit.get("lessons") or []:
                if not isinstance(les, dict):
                    raise ValueError
                ltitle = clean_name(les.get("title"))[:bookread.MAX_TITLE]
                if len(ltitle) < 1:
                    continue
                periods = min(MAX_PERIODS, max(1, toint(les.get("periods")) or 1))
                kind = les.get("kind") if les.get("kind") in ("lesson", "review", "exam") else "lesson"
                lid = les.get("id")
                if isinstance(lid, int) and lid in have_lessons and lid not in keep_lessons:
                    db.execute("UPDATE book_lessons SET unit_id = ?, title = ?, position = ?, periods = ?, kind = ? WHERE id = ?", (unit_id, ltitle, position, periods, kind, lid))
                else:
                    lid = db.execute("INSERT INTO book_lessons(user_id, book_id, unit_id, title, position, periods, kind) VALUES (?,?,?,?,?,?,?)",
                                     (uid, bid, unit_id, ltitle, position, periods, kind)).lastrowid
                keep_lessons.add(lid)
                position += 1
        if not keep_lessons:
            raise ValueError
        for gone in have_lessons - keep_lessons:
            db.execute("DELETE FROM book_lessons WHERE id = ?", (gone,))          # her plan items for it go with it
        for gone in have_units - keep_units:
            db.execute("DELETE FROM book_units WHERE id = ?", (gone,))
        db.execute("UPDATE books SET title = ?, subject = ?, grade = ?, confirmed = 1, updated_at = ? WHERE id = ?", (title, subject, grade, now(), bid))
        # the classes that use this book (a class has one book for a subject)
        db.execute("UPDATE class_subjects SET book_id = NULL WHERE book_id = ? AND user_id = ?", (bid, uid))
        if class_ids:
            sid = ensure_subject(subject)
            if sid is None:
                raise OverflowError
            for cid in class_ids:
                if not db.execute("SELECT 1 FROM class_subjects WHERE class_id = ? AND subject_id = ?", (cid, sid)).fetchone():
                    db.execute("INSERT INTO class_subjects(user_id, class_id, subject_id, created_at, book_id) VALUES (?,?,?,?,?)", (uid, cid, sid, now(), bid))
                else:
                    db.execute("UPDATE class_subjects SET book_id = ? WHERE class_id = ? AND subject_id = ?", (bid, cid, sid))
        db.commit()
    except OverflowError:
        db.rollback()
        return jsonify(error="وصلتِ إلى الحد الأقصى من المواد"), 400
    except (ValueError, TypeError):
        db.rollback()
        return jsonify(error="بيانات الكتاب غير صحيحة"), 400
    return jsonify(book_detail(bid))


@bp.delete("/api/books/<int:bid>")
@login_required
def delete(bid):
    book = mine("books", bid)
    current_app.db.execute("DELETE FROM books WHERE id = ?", (bid,))          # its units, lessons and plan items go with it; the classes keep their subject
    current_app.db.commit()
    if book["stored_name"]:
        try:
            (current_app.cfg.upload_dir / book["stored_name"]).unlink()
        except OSError:
            pass
    return jsonify(ok=True)
