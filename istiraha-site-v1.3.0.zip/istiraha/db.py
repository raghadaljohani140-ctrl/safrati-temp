"""The database: one SQLite file of its own, created and upgraded here. Nothing else on the server uses it."""
from __future__ import annotations

import sqlite3
import time
from pathlib import Path

SCHEMA_VERSION = 3

# version 1: the first release. Version 2 (below) adds the commission payment reports, version 3 the owners' own offers.
SCHEMA_V1 = """
CREATE TABLE users (
  id INTEGER PRIMARY KEY, role TEXT NOT NULL CHECK (role IN ('owner','admin')),
  login TEXT NOT NULL UNIQUE, name TEXT NOT NULL, pass_hash TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','blocked')),
  failed INTEGER NOT NULL DEFAULT 0, locked_until REAL NOT NULL DEFAULT 0,
  created_at REAL NOT NULL, last_login REAL
);
CREATE TABLE sessions (
  token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  csrf TEXT NOT NULL, created_at REAL NOT NULL, expires_at REAL NOT NULL
);
CREATE INDEX sessions_user ON sessions(user_id);
CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE commission_history (
  id INTEGER PRIMARY KEY, basis_points INTEGER NOT NULL CHECK (basis_points BETWEEN 0 AND 10000),
  changed_at REAL NOT NULL, changed_by INTEGER REFERENCES users(id), note TEXT NOT NULL DEFAULT ''
);
CREATE TABLE pledge_versions (
  id INTEGER PRIMARY KEY, version INTEGER NOT NULL UNIQUE, body TEXT NOT NULL,
  created_at REAL NOT NULL, created_by INTEGER REFERENCES users(id)
);
CREATE TABLE consents (
  id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL REFERENCES users(id),
  listing_id INTEGER, pledge_version INTEGER NOT NULL, pledge_text TEXT NOT NULL,
  basis_points INTEGER NOT NULL, accepted_at REAL NOT NULL, ip_fingerprint TEXT NOT NULL DEFAULT '',
  user_agent TEXT NOT NULL DEFAULT ''
);
CREATE INDEX consents_owner ON consents(owner_id);
CREATE TABLE cities (id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, active INTEGER NOT NULL DEFAULT 1, sort INTEGER NOT NULL DEFAULT 0);
CREATE TABLE categories (id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, active INTEGER NOT NULL DEFAULT 1, sort INTEGER NOT NULL DEFAULT 0);
CREATE TABLE amenities (id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, active INTEGER NOT NULL DEFAULT 1, sort INTEGER NOT NULL DEFAULT 0);
CREATE TABLE listings (
  id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL REFERENCES users(id), consent_id INTEGER NOT NULL REFERENCES consents(id),
  title TEXT NOT NULL, city_id INTEGER NOT NULL REFERENCES cities(id), district TEXT NOT NULL DEFAULT '',
  map_url TEXT NOT NULL DEFAULT '', category_id INTEGER NOT NULL REFERENCES categories(id),
  description TEXT NOT NULL DEFAULT '', price INTEGER NOT NULL CHECK (price > 0), unit TEXT NOT NULL DEFAULT 'night',
  capacity INTEGER, whatsapp TEXT NOT NULL, availability_note TEXT NOT NULL DEFAULT '',
  review TEXT NOT NULL DEFAULT 'pending' CHECK (review IN ('pending','approved','rejected','stopped')),
  review_note TEXT NOT NULL DEFAULT '', owner_active INTEGER NOT NULL DEFAULT 1, featured INTEGER NOT NULL DEFAULT 0,
  views INTEGER NOT NULL DEFAULT 0, clicks INTEGER NOT NULL DEFAULT 0,
  created_at REAL NOT NULL, updated_at REAL NOT NULL, approved_at REAL
);
CREATE INDEX listings_public ON listings(review, owner_active, city_id);
CREATE INDEX listings_owner ON listings(owner_id);
CREATE TABLE listing_amenities (
  listing_id INTEGER NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
  amenity_id INTEGER NOT NULL REFERENCES amenities(id), PRIMARY KEY (listing_id, amenity_id)
);
CREATE TABLE photos (
  id INTEGER PRIMARY KEY, listing_id INTEGER NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
  filename TEXT NOT NULL UNIQUE, position INTEGER NOT NULL DEFAULT 0, created_at REAL NOT NULL
);
CREATE INDEX photos_listing ON photos(listing_id, position);
CREATE TABLE blocked_dates (
  id INTEGER PRIMARY KEY, listing_id INTEGER NOT NULL REFERENCES listings(id) ON DELETE CASCADE,
  start_date TEXT NOT NULL, end_date TEXT NOT NULL, CHECK (end_date >= start_date)
);
CREATE INDEX blocked_listing ON blocked_dates(listing_id);
CREATE TABLE offers (
  id INTEGER PRIMARY KEY, title TEXT NOT NULL, percent INTEGER NOT NULL CHECK (percent BETWEEN 1 AND 90),
  city_id INTEGER REFERENCES cities(id), category_id INTEGER REFERENCES categories(id), listing_id INTEGER REFERENCES listings(id) ON DELETE CASCADE,
  starts_on TEXT NOT NULL, ends_on TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE rentals (
  id INTEGER PRIMARY KEY, listing_id INTEGER NOT NULL REFERENCES listings(id), owner_id INTEGER NOT NULL REFERENCES users(id),
  consent_id INTEGER NOT NULL REFERENCES consents(id), basis_points INTEGER NOT NULL,
  rent INTEGER NOT NULL CHECK (rent > 0), commission_halalas INTEGER NOT NULL, rental_date TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'confirmed' CHECK (status IN ('pending','confirmed','completed','cancelled')),
  pay_status TEXT NOT NULL DEFAULT 'due' CHECK (pay_status IN ('due','paid','disputed','waived')),
  due_date TEXT NOT NULL, paid_at REAL, created_at REAL NOT NULL, created_by INTEGER REFERENCES users(id), customer TEXT NOT NULL DEFAULT ''
);
CREATE INDEX rentals_listing ON rentals(listing_id);
CREATE TABLE rental_notes (
  id INTEGER PRIMARY KEY, rental_id INTEGER NOT NULL REFERENCES rentals(id) ON DELETE CASCADE,
  author_id INTEGER REFERENCES users(id), kind TEXT NOT NULL DEFAULT 'note' CHECK (kind IN ('note','objection','payment')),
  body TEXT NOT NULL, created_at REAL NOT NULL
);
CREATE TABLE audit (id INTEGER PRIMARY KEY, at REAL NOT NULL, user_id INTEGER, action TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '');
"""

# version 2: an owner tells the manager he transferred the commission of some rentals; the manager confirms or refuses.
# The amount is the sum of the rentals' commissions when he reported (never typed by him). Nothing here moves money.
MIGRATION_V2 = """
CREATE TABLE payment_reports (
  id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL REFERENCES users(id),
  amount_halalas INTEGER NOT NULL CHECK (amount_halalas > 0), paid_on TEXT NOT NULL, reference TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','confirmed','rejected','withdrawn')),
  created_at REAL NOT NULL, decided_at REAL, decided_by INTEGER REFERENCES users(id), decision_note TEXT NOT NULL DEFAULT ''
);
CREATE INDEX payment_reports_owner ON payment_reports(owner_id, status);
CREATE TABLE payment_report_items (
  report_id INTEGER NOT NULL REFERENCES payment_reports(id) ON DELETE CASCADE,
  rental_id INTEGER NOT NULL REFERENCES rentals(id), PRIMARY KEY (report_id, rental_id)
);
CREATE INDEX payment_items_rental ON payment_report_items(rental_id);
"""

# version 3: the owner decides his own discount (the manager is only the broker). An offer an owner made carries his id and only ever
# applies to his own adverts; the manager's offers keep owner_id empty, as before. `locked` is the manager stopping an owner's offer: the
# owner can stop and resume his own offers, but cannot resume one the manager stopped. Existing offers are untouched (empty, 0).
MIGRATION_V3 = """
ALTER TABLE offers ADD COLUMN owner_id INTEGER REFERENCES users(id);
ALTER TABLE offers ADD COLUMN locked INTEGER NOT NULL DEFAULT 0;
CREATE INDEX offers_owner ON offers(owner_id);
"""
SCHEMA = SCHEMA_V1 + MIGRATION_V2 + MIGRATION_V3          # what a new database gets; an old one gets only the missing migrations

CITIES = ["الرياض", "جدة", "مكة المكرمة", "المدينة المنورة", "الدمام", "الخبر", "الأحساء", "الطائف", "القصيم", "حائل", "تبوك", "أبها",
          "جازان", "نجران", "الباحة", "ينبع", "الجبيل", "الخرج", "حفر الباطن"]
CATEGORIES = ["استراحة", "شاليه", "مزرعة", "مخيم", "قاعة ومجلس", "فيلا وبيت ضيافة"]
AMENITIES = ["مسبح", "ألعاب أطفال", "قسم عائلي", "قسم رجالي", "قسم نسائي", "مجلس", "مطبخ", "منطقة شواء", "ملعب كرة", "مسبح أطفال",
             "واي فاي", "مواقف سيارات", "خيمة", "غرفة نوم", "تكييف"]

DEFAULT_COMMISSION_BP = 1000
DEFAULT_DUE_DAYS = 7

PLEDGE_V1 = (
    "أتعهد وأوافق على شروط استخدام المنصة، وألتزم بسداد العمولة المستحقة عن عمليات التأجير المشمولة بهذه الشروط، "
    "وفق نسبة العمولة الموضحة لي قبل الموافقة، وبما يتوافق مع آلية احتساب العمولة والشروط المعتمدة. "
    "وأقر بصحة البيانات التي أقدمها عن الاستراحة، وأوافق على تسجيل موافقتي إلكترونيًا وحفظ تاريخها ونسبة العمولة المتفق عليها."
)


class Database:
    def __init__(self, path: Path | str, clock=time.time):
        self.path = str(path)
        self.clock = clock
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path, isolation_level=None, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        if self.path != ":memory:":
            self.conn.execute("PRAGMA journal_mode = WAL")
        self.conn.execute("PRAGMA busy_timeout = 5000")
        self._migrate()

    # ---- schema ----------------------------------------------------------------------------
    def _migrate(self) -> None:
        version = self.conn.execute("PRAGMA user_version").fetchone()[0]
        if version > SCHEMA_VERSION:
            raise RuntimeError(f"the database is newer (version {version}) than this program ({SCHEMA_VERSION})")
        if version == SCHEMA_VERSION:
            return
        self.conn.execute("BEGIN")
        try:
            if version == 0:
                self._run_script(SCHEMA)
                now = self.clock()
                for i, name in enumerate(CITIES):
                    self.conn.execute("INSERT INTO cities(name, sort) VALUES (?, ?)", (name, i))
                for i, name in enumerate(CATEGORIES):
                    self.conn.execute("INSERT INTO categories(name, sort) VALUES (?, ?)", (name, i))
                for i, name in enumerate(AMENITIES):
                    self.conn.execute("INSERT INTO amenities(name, sort) VALUES (?, ?)", (name, i))
                self.conn.execute("INSERT INTO pledge_versions(version, body, created_at) VALUES (1, ?, ?)", (PLEDGE_V1, now))
                self.conn.execute("INSERT INTO commission_history(basis_points, changed_at, note) VALUES (?, ?, 'النسبة الأولية')", (DEFAULT_COMMISSION_BP, now))
                self.conn.execute("INSERT INTO settings(key, value) VALUES ('due_days', ?)", (str(DEFAULT_DUE_DAYS),))
            else:                                        # nothing that exists is touched: new tables, new empty columns
                if version < 2:
                    self._run_script(MIGRATION_V2)
                if version < 3:
                    self._run_script(MIGRATION_V3)
            self.conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
            self.conn.execute("COMMIT")
        except BaseException:
            self.conn.execute("ROLLBACK")
            raise

    def _run_script(self, script: str) -> None:
        for statement in script.split(";\n"):
            if statement.strip():
                self.conn.execute(statement)

    # ---- helpers ---------------------------------------------------------------------------
    def one(self, sql: str, args: tuple = ()):
        return self.conn.execute(sql, args).fetchone()

    def all(self, sql: str, args: tuple = ()):
        return self.conn.execute(sql, args).fetchall()

    def run(self, sql: str, args: tuple = ()) -> int:
        return self.conn.execute(sql, args).lastrowid

    def transaction(self):
        return _Transaction(self.conn)

    def close(self) -> None:
        self.conn.close()

    # ---- commission and pledge ---------------------------------------------------------------
    def commission_bp(self) -> int:
        return self.one("SELECT basis_points FROM commission_history ORDER BY id DESC LIMIT 1")["basis_points"]

    def pledge(self):
        return self.one("SELECT * FROM pledge_versions ORDER BY version DESC LIMIT 1")

    def due_days(self) -> int:
        row = self.one("SELECT value FROM settings WHERE key = 'due_days'")
        return int(row["value"]) if row else DEFAULT_DUE_DAYS

    def setting(self, key: str, default: str = "") -> str:
        row = self.one("SELECT value FROM settings WHERE key = ?", (key,))
        return row["value"] if row else default

    def put_setting(self, key: str, value: str) -> None:
        """Saves a value, or forgets the key when the value is empty."""
        if value:
            self.run("INSERT INTO settings(key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value", (key, value))
        else:
            self.run("DELETE FROM settings WHERE key = ?", (key,))

    def auto_publish(self) -> bool:
        """Automatic publishing: a new advert goes live by itself once it has a picture. It is on until the manager turns it off."""
        row = self.one("SELECT value FROM settings WHERE key = 'auto_publish'")
        return row["value"] != "0" if row else True

    def set_auto_publish(self, on: bool) -> None:
        self.run("INSERT INTO settings(key, value) VALUES ('auto_publish', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value", ("1" if on else "0",))

    def audit(self, user_id: int | None, action: str, detail: str = "") -> None:
        self.run("INSERT INTO audit(at, user_id, action, detail) VALUES (?, ?, ?, ?)", (self.clock(), user_id, action, detail[:500]))


class _Transaction:
    def __init__(self, conn):
        self.conn = conn

    def __enter__(self):
        self.conn.execute("BEGIN IMMEDIATE")

    def __exit__(self, exc_type, exc, tb):
        self.conn.execute("ROLLBACK" if exc_type else "COMMIT")
        return False
