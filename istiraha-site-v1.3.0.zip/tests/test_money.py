"""Paying the commission: the manager's bank details, the owner's page «عمولاتي» and his reports, the manager's earnings."""
import re
import sqlite3
import tempfile
import unittest
from pathlib import Path

from istiraha import db as dbmod
from istiraha import payments
from istiraha.db import Database

from .helpers import NOW, Case

IBAN = "SA0380000000608010167519"                 # the example in the public IBAN registry, not anybody's account
SHOWN = "SA03 8000 0000 6080 1016 7519"
BAD_IBAN = "SA0380000000608010167518"             # one digit off: the check number catches it
PASSWORD = "Str0ng-pass!"


def rows_of(html):
    """Every table row as a list of plain cell texts (the pieces inside one cell are joined with a space)."""
    clean = lambda cell: re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", cell)).strip()
    return [[clean(c) for c in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", tr, re.S)] for tr in re.findall(r"<tr>(.*?)</tr>", html, re.S)]


def tiles(html):
    """{label: figure} of the figure tiles on a page (the unit «ر.س» is a small suffix beside the figure, not part of it)."""
    return {label: value for value, label in re.findall(r'<b>([^<]*)<span class="u">ر\.س</span></b><span>([^<]*)</span>', html)}


class IbanTests(unittest.TestCase):
    def test_a_right_number_is_accepted_however_it_is_typed(self):
        for typed in (IBAN, SHOWN, IBAN.lower(), " " + SHOWN.replace(" ", "  ") + " ", "SA03-8000-0000-6080-1016-7519",
                      "SA٠٣ ٨٠٠٠ ٠٠٠٠ ٦٠٨٠ ١٠١٦ ٧٥١٩", "‏SA0380000000608010167519‏"):
            self.assertEqual(payments.clean_iban(typed), IBAN, typed)

    def test_a_wrong_number_is_refused(self):
        for typed in ("", BAD_IBAN, IBAN[:-1], IBAN + "0", "AE" + IBAN[2:], "SA03 8000 0000 6080 1016 75AB", "0380000000608010167519",
                      "SA0380000000608010167519 SA0380000000608010167519"):
            self.assertIsNone(payments.clean_iban(typed), typed)

    def test_showing_it(self):
        self.assertEqual(payments.show_iban(IBAN), SHOWN)
        self.assertEqual(payments.mask_iban(IBAN), "SA…7519")


class UpgradeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / "old.db"

    def make_first_release(self, extra=""):
        conn = sqlite3.connect(self.path)
        for statement in dbmod.SCHEMA_V1.split(";\n"):
            if statement.strip():
                conn.execute(statement)
        conn.execute("INSERT INTO users(role, login, name, pass_hash, created_at) VALUES ('owner', '966551234567', 'أبو سعد', 'x', 1)")
        conn.execute("INSERT INTO settings(key, value) VALUES ('due_days', '9')")
        if extra:
            conn.execute(extra)
        conn.execute("PRAGMA user_version = 1")
        conn.commit()
        conn.close()

    def make_second_release(self, extra=""):
        """What 1.1.x left on a server: the first release's tables plus the payment reports, at version 2."""
        conn = sqlite3.connect(self.path)
        for statement in (dbmod.SCHEMA_V1 + dbmod.MIGRATION_V2).split(";\n"):
            if statement.strip():
                conn.execute(statement)
        conn.execute("INSERT INTO users(role, login, name, pass_hash, created_at) VALUES ('owner', '966551234567', 'أبو سعد', 'x', 1)")
        if extra:
            conn.execute(extra)
        conn.execute("PRAGMA user_version = 2")
        conn.commit()
        conn.close()

    def test_the_first_release_database_gains_the_new_tables_and_columns_and_loses_nothing(self):
        self.make_first_release()
        db = Database(self.path)
        self.addCleanup(db.close)
        self.assertEqual(db.one("PRAGMA user_version")[0], dbmod.SCHEMA_VERSION)
        self.assertEqual(db.one("SELECT name FROM users")["name"], "أبو سعد")
        self.assertEqual(db.due_days(), 9)
        names = {r["name"] for r in db.all("SELECT name FROM sqlite_master WHERE type = 'table'")}
        self.assertTrue({"payment_reports", "payment_report_items"} <= names)
        self.assertEqual(db.one("SELECT COUNT(*) AS n FROM payment_reports")["n"], 0)
        self.assertTrue({"owner_id", "locked"} <= {r["name"] for r in db.all("PRAGMA table_info(offers)")})

    def test_a_version_two_database_gains_the_offer_columns_and_keeps_its_offers_as_the_managers(self):
        self.make_second_release("INSERT INTO offers(title, percent, starts_on, ends_on) VALUES ('خصم قديم', 15, '2026-10-01', '2026-12-31')")
        db = Database(self.path)
        self.addCleanup(db.close)
        self.assertEqual(db.one("PRAGMA user_version")[0], dbmod.SCHEMA_VERSION)
        old = db.one("SELECT * FROM offers")
        self.assertEqual((old["title"], old["percent"], old["active"]), ("خصم قديم", 15, 1))
        self.assertEqual((old["owner_id"], old["locked"]), (None, 0))              # an offer that was there belongs to nobody: the manager's, as before
        self.assertEqual(db.one("SELECT name FROM users")["name"], "أبو سعد")
        self.assertIn("offers_owner", {r["name"] for r in db.all("SELECT name FROM sqlite_master WHERE type = 'index'")})
        db.run("INSERT INTO offers(title, percent, starts_on, ends_on, owner_id) VALUES ('عرض مالك', 10, '2026-10-01', '2026-12-31', 1)")
        self.assertEqual(db.one("SELECT COUNT(*) AS n FROM offers WHERE owner_id = 1")["n"], 1)

    def test_the_offer_columns_of_an_upgraded_database_and_a_new_one_are_the_same(self):
        self.make_second_release()
        upgraded = Database(self.path)
        fresh = Database(":memory:")
        self.addCleanup(upgraded.close)
        self.addCleanup(fresh.close)
        columns = lambda d: [(r["name"], r["type"], r["notnull"], r["dflt_value"]) for r in d.all("PRAGMA table_info(offers)")]
        self.assertEqual(columns(upgraded), columns(fresh))

    def test_opening_it_again_changes_nothing(self):
        self.make_first_release()
        Database(self.path).close()
        db = Database(self.path)
        self.addCleanup(db.close)
        self.assertEqual(db.one("SELECT COUNT(*) AS n FROM users")["n"], 1)

    def test_a_new_database_has_everything_and_the_same_version(self):
        db = Database(":memory:")
        self.addCleanup(db.close)
        self.assertEqual(db.one("PRAGMA user_version")[0], dbmod.SCHEMA_VERSION)
        self.assertEqual(dbmod.SCHEMA_VERSION, 3)
        self.assertGreater(db.one("SELECT COUNT(*) AS n FROM cities")["n"], 5)
        self.assertEqual(db.one("SELECT COUNT(*) AS n FROM payment_reports")["n"], 0)

    def test_a_failed_upgrade_leaves_the_database_as_it_was(self):
        self.make_first_release("CREATE TABLE payment_report_items (x INTEGER)")          # a clash half way through the upgrade
        with self.assertRaises(sqlite3.OperationalError):
            Database(self.path)
        conn = sqlite3.connect(self.path)
        self.assertEqual(conn.execute("PRAGMA user_version").fetchone()[0], 1)
        names = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
        self.assertNotIn("payment_reports", names)               # the first table was rolled back with the rest
        conn.close()

    def test_a_failed_offer_upgrade_leaves_the_version_two_database_as_it_was(self):
        self.make_second_release()
        conn = sqlite3.connect(self.path)
        conn.execute("ALTER TABLE offers ADD COLUMN locked INTEGER")                  # a clash on the second column, after the first was added
        conn.commit()
        conn.close()
        with self.assertRaises(sqlite3.OperationalError):
            Database(self.path)
        conn = sqlite3.connect(self.path)
        self.assertEqual(conn.execute("PRAGMA user_version").fetchone()[0], 2)
        self.assertNotIn("owner_id", [r[1] for r in conn.execute("PRAGMA table_info(offers)")])      # rolled back with the rest
        conn.close()

    def test_a_database_from_a_newer_program_is_not_touched(self):
        conn = sqlite3.connect(self.path)
        conn.execute(f"PRAGMA user_version = {dbmod.SCHEMA_VERSION + 1}")
        conn.commit()
        conn.close()
        with self.assertRaises(RuntimeError):
            Database(self.path)


class MoneyCase(Case):
    async def world(self):
        admin = await self.make_admin()
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        self.approve(lid)
        return admin, owner, lid

    async def second_owner(self, title="مزرعة الواحة"):
        owner = await self.make_owner(phone="0559876543", name="أبو خالد", ip="203.0.113.51")
        lid = await self.add_listing(owner, title=title, whatsapp="0559876543")
        self.approve(lid)
        return owner, lid

    async def rent(self, admin, lid, rent=500, day="2026-10-20", status="confirmed"):
        r = await admin.post("/admin/rental/new", {"listing": str(lid), "rent": str(rent), "date": day, "status": status}, page="/admin/rental/new")
        self.assertEqual(r.status, 303, admin.text[:300])
        return self.db.one("SELECT MAX(id) AS i FROM rentals")["i"]

    async def set_bank(self, admin, **over):
        form = {"holder": "شركة استراحتي", "bank": "مصرف الراجحي", "iban": SHOWN, "contact": "", "note": "", "password": PASSWORD, **over}
        return await admin.post("/admin/pay-details", form, page="/admin/pay-details")

    async def report(self, owner, ids, paid_on="2026-10-26", reference="", **extra):
        return await owner.post("/owner/commissions/report", {"rental": [str(i) for i in ids], "paid_on": paid_on, "reference": reference, **extra}, page="/owner/commissions")


class BankDetailsTests(MoneyCase):
    async def test_the_manager_saves_his_details_and_they_are_checked(self):
        admin, owner, lid = await self.world()
        await admin.get("/admin/pay-details")
        self.assertIn("بيانات استلام العمولة", admin.text)
        for over, why in (({"iban": BAD_IBAN}, "wrong check number"), ({"iban": ""}, "no iban"), ({"holder": ""}, "no holder"), ({"bank": "x"}, "bank too short"),
                          ({"password": "wrong-password-1"}, "wrong password"), ({"contact": "123"}, "bad phone"), ({"note": "ن" * 201}, "long note")):
            r = await self.set_bank(admin, **over)
            self.assertEqual(r.status, 400, why)
        self.assertEqual(payments.pay_details(self.db)["iban"], "")
        r = await self.set_bank(admin, contact="0551112233", note="اكتب رقم جوالك في وصف الحوالة")
        self.assertEqual(r.status, 303, admin.text[:300])
        d = payments.pay_details(self.db)
        self.assertEqual((d["holder"], d["bank"], d["iban"], d["contact"], d["note"]), ("شركة استراحتي", "مصرف الراجحي", IBAN, "966551112233", "اكتب رقم جوالك في وصف الحوالة"))
        await admin.get("/admin/pay-details")
        self.assertIn(SHOWN, admin.text)
        self.assertNotIn("Str0ng", admin.text)                                    # the password is never put back in the page
        await admin.get("/admin/settings")
        self.assertIn("7519", admin.text)

    async def test_a_wrong_password_is_counted_like_at_sign_in(self):
        admin, owner, lid = await self.world()
        for _ in range(5):
            await self.set_bank(admin, password="wrong-password-1")
        r = await self.set_bank(admin)                                           # now locked, even with the right one
        self.assertEqual(r.status, 400)
        self.assertEqual(payments.pay_details(self.db)["iban"], "")

    async def test_the_audit_log_never_holds_the_whole_number(self):
        admin, owner, lid = await self.world()
        await self.set_bank(admin)
        entries = self.db.all("SELECT action, detail FROM audit WHERE action = 'pay_details'")
        self.assertEqual(len(entries), 1)
        self.assertIn("7519", entries[0]["detail"])
        self.assertNotIn(IBAN, entries[0]["detail"])
        for row in self.db.all("SELECT detail FROM audit"):
            self.assertNotIn(IBAN[2:], row["detail"])
        await admin.get("/admin")
        self.assertIn("تغيير بيانات استلام العمولة", admin.text)

    async def test_empty_name_bank_and_number_hide_the_way_to_pay(self):
        admin, owner, lid = await self.world()
        await self.set_bank(admin)
        await self.rent(admin, lid)
        await owner.get("/owner/commissions")
        self.assertIn(SHOWN, owner.text)
        r = await self.set_bank(admin, holder="", bank="", iban="")
        self.assertEqual(r.status, 303)
        self.assertEqual(payments.pay_details(self.db)["iban"], "")
        await owner.get("/owner/commissions")
        self.assertNotIn(SHOWN, owner.text)
        self.assertIn("لم تضف الإدارة بيانات الحساب بعد", owner.text)

    async def test_only_signed_in_owners_with_something_to_pay_see_the_number(self):
        admin, owner, lid = await self.world()
        await self.set_bank(admin, contact="0551112233")
        for path in ("/", "/search", "/offers", "/terms", "/privacy", f"/r/{lid}", "/owner/login", "/owner/register"):
            await self.visitor.get(path)
            self.assertNotIn(IBAN, self.visitor.text, path)
            self.assertNotIn(SHOWN, self.visitor.text, path)
        r = await self.visitor.get("/owner/commissions")
        self.assertEqual((r.status, r.headers["Location"].split("?")[0]), (303, "/owner/login"))
        await owner.get("/owner/commissions")                                     # nothing registered yet: nothing to pay, so no number
        self.assertNotIn(SHOWN, owner.text)
        await self.rent(admin, lid)
        await owner.get("/owner/commissions")
        self.assertIn(SHOWN, owner.text)
        self.assertIn(f'data-copy="{IBAN}"', owner.text)
        self.assertIn("شركة استراحتي", owner.text)
        self.assertIn("https://wa.me/966551112233", owner.text)
        self.assertNotIn("Str0ng", owner.text)

    async def test_what_the_manager_types_is_escaped(self):
        admin, owner, lid = await self.world()
        await self.set_bank(admin, holder="<script>alert(1)</script>", bank="<b>بنك</b>", note="<img src=x onerror=alert(2)>")
        await self.rent(admin, lid)
        await owner.get("/owner/commissions")
        for raw in ("<script>alert(1)</script>", "<b>بنك</b>", "<img src=x"):
            self.assertNotIn(raw, owner.text)
        self.assertIn("&lt;script&gt;alert(1)&lt;/script&gt;", owner.text)
        await admin.get("/admin/pay-details")
        self.assertNotIn("<script>alert(1)", admin.text)


class OwnerPageTests(MoneyCase):
    async def test_an_owner_sees_his_own_commissions_and_nobody_elses(self):
        admin, owner, lid = await self.world()
        other, other_lid = await self.second_owner()
        mine = await self.rent(admin, lid, 500)
        theirs = await self.rent(admin, other_lid, 4000)
        await owner.get("/owner/commissions")
        self.assertIn("استراحة النخيل", owner.text)
        self.assertIn(f"#{mine}", owner.text)
        self.assertNotIn("مزرعة الواحة", owner.text)
        self.assertNotIn("400", tiles(owner.text).get("مستحقة عليك", ""))
        await other.get("/owner/commissions")
        self.assertIn("مزرعة الواحة", other.text)
        self.assertNotIn("استراحة النخيل", other.text)
        self.assertEqual(tiles(other.text)["مستحقة عليك"], "400")
        # the internal notes the manager keeps on a rental are not for the owner
        await admin.post(f"/admin/rental/{mine}/note", {"kind": "objection", "body": "ملاحظة داخلية سرية"}, page=f"/admin/rental/{mine}")
        await owner.get("/owner/commissions")
        self.assertNotIn("ملاحظة داخلية سرية", owner.text)

    async def test_the_figures_and_the_state_words(self):
        admin, owner, lid = await self.world()
        due = await self.rent(admin, lid, 500, "2026-10-25")                      # due 11-01
        late = await self.rent(admin, lid, 1000, "2026-10-01")                     # due 10-08: late
        paid = await self.rent(admin, lid, 2000, "2026-09-01")
        await admin.post(f"/admin/rental/{paid}/update", {"rent": "2000", "status": "confirmed", "pay_status": "paid"}, page=f"/admin/rental/{paid}")
        disputed = await self.rent(admin, lid, 300, "2026-09-02")
        await admin.post(f"/admin/rental/{disputed}/update", {"rent": "300", "status": "confirmed", "pay_status": "disputed"}, page=f"/admin/rental/{disputed}")
        waived = await self.rent(admin, lid, 400, "2026-09-03")
        await admin.post(f"/admin/rental/{waived}/update", {"rent": "400", "status": "confirmed", "pay_status": "waived"}, page=f"/admin/rental/{waived}")
        cancelled = await self.rent(admin, lid, 700, "2026-09-04", status="cancelled")
        await owner.get("/owner/commissions")
        t = tiles(owner.text)
        self.assertEqual(t["مستحقة عليك"], "150")                           # 50 + 100
        self.assertEqual(t["مدفوعة"], "200")
        self.assertEqual(t["متنازع عليها"], "30")
        self.assertIn("منها متأخرة 100", owner.text)
        self.assertIn("عندك عمولة تجاوزت موعد السداد", owner.text)
        self.assertNotIn(f"#{cancelled} ", owner.text)                            # a cancelled rental owes nothing
        for word in ("متأخرة", "مستحقة", "مدفوعة", "متنازع عليها", "معفاة"):
            self.assertIn(f">{word}<", owner.text)
        self.assertEqual(owner.text.count('name="rental"'), 2)                    # only the due and the late one can be ticked

    async def test_the_front_page_card_and_the_menu_link(self):
        admin, owner, lid = await self.world()
        await owner.get("/owner")
        self.assertNotIn("com-card", owner.text)                                  # no rental yet: nothing to say
        self.assertIn('href="/owner/commissions"', owner.text)                    # the menu has the link
        await self.visitor.get("/")
        self.assertNotIn("/owner/commissions", self.visitor.text)
        await self.rent(admin, lid, 500, "2026-10-01")
        await owner.get("/owner")
        self.assertIn("com-card bad", owner.text)
        self.assertIn("عمولات مستحقة عليك", owner.text)
        await self.report(owner, [1])
        await owner.get("/owner")
        self.assertIn("بانتظار تأكيد الإدارة", owner.text)

    async def test_nothing_due_says_so(self):
        admin, owner, lid = await self.world()
        rid = await self.rent(admin, lid, 500)
        await admin.post(f"/admin/rental/{rid}/update", {"rent": "500", "status": "confirmed", "pay_status": "paid"}, page=f"/admin/rental/{rid}")
        await owner.get("/owner/commissions")
        self.assertIn("لا توجد عمولات مستحقة عليك الآن", owner.text)
        self.assertNotIn('name="rental"', owner.text)
        await owner.get("/owner")
        self.assertIn("com-card ok", owner.text)


class ReportFlowTests(MoneyCase):
    async def test_report_confirm_and_everything_that_follows(self):
        admin, owner, lid = await self.world()
        await self.set_bank(admin)
        a = await self.rent(admin, lid, 500, "2026-10-20")
        b = await self.rent(admin, lid, 1000, "2026-10-01")
        r = await self.report(owner, [a, b], reference="HW-123", amount="1")      # an amount in the form is ignored: the site adds it up itself
        self.assertEqual(r.status, 303, owner.text[:400])
        report = self.db.one("SELECT * FROM payment_reports")
        self.assertEqual((report["amount_halalas"], report["status"], report["paid_on"], report["reference"]), (15000, "pending", "2026-10-26", "HW-123"))
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM payment_report_items")["n"], 2)
        self.assertIn("وصل بلاغك", await owner.message())
        self.assertIn("بلاغ #1", owner.text)
        self.assertIn("بانتظار التأكيد", owner.text)
        self.assertNotIn('name="rental"', owner.text)                             # both are waiting now: nothing left to tick
        self.assertEqual(tiles(owner.text)["بانتظار تأكيد الإدارة"], "150")
        # the manager sees it at once
        await admin.get("/admin")
        self.assertIn("لديك 1 بلاغ سداد بانتظار تأكيدك", admin.text)
        self.assertIn('<span class="nbadge"', admin.text)
        await admin.get("/admin/earnings")
        self.assertEqual(tiles(admin.text)["بانتظار تأكيدك"], "150")
        self.assertIn("HW-123", admin.text)
        await admin.get("/admin/rentals?pay=reported")
        self.assertIn(f"#{a}", admin.text)
        self.assertIn(f"#{b}", admin.text)
        await admin.get(f"/admin/rental/{a}")
        self.assertIn("المالك أبلغ بسداد هذه العمولة", admin.text)
        await admin.get("/admin/payment/1")
        self.assertIn("HW-123", admin.text)
        self.assertIn("أبو سعد", admin.text)
        # confirming needs the tick that says the money was seen
        r = await admin.post("/admin/payment/1/confirm", {}, page="/admin/payment/1")
        self.assertEqual(r.status, 303)
        self.assertEqual(self.db.one("SELECT status FROM payment_reports")["status"], "pending")
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM rentals WHERE pay_status = 'paid'")["n"], 0)
        r = await admin.post("/admin/payment/1/confirm", {"received": "1"}, page="/admin/payment/1")
        self.assertEqual(r.status, 303)
        self.assertIn("أكدنا الاستلام وسجلنا 2 عملية مدفوعة", await admin.message())
        rows = self.db.all("SELECT pay_status, paid_at FROM rentals ORDER BY id")
        self.assertEqual([(x["pay_status"], x["paid_at"]) for x in rows], [("paid", NOW), ("paid", NOW)])
        report = self.db.one("SELECT * FROM payment_reports")
        self.assertEqual((report["status"], report["decided_at"]), ("confirmed", NOW))
        notes = self.db.all("SELECT kind, body FROM rental_notes ORDER BY id")
        self.assertEqual([n["kind"] for n in notes], ["payment", "payment"])
        self.assertIn("بلاغ رقم 1", notes[0]["body"])
        self.assertIn("HW-123", notes[0]["body"])
        self.assertEqual(self.db.one("SELECT action FROM audit WHERE action = 'payment_confirm'")["action"], "payment_confirm")
        # pressing it again changes nothing
        await admin.post("/admin/payment/1/confirm", {"received": "1"}, page="/admin/payment/1")
        self.assertIn("لم يعد بانتظار التأكيد", await admin.message())
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM rental_notes")["n"], 2)
        # the figures moved
        await admin.get("/admin/earnings")
        t = tiles(admin.text)
        self.assertEqual((t["المحصّل حتى الآن"], t["المحصّل هذا الشهر"], t["المتبقي لك"], t["بانتظار تأكيدك"]), ("150", "150", "0", "0"))
        self.assertNotIn('class="nbadge"', admin.text)
        await owner.get("/owner/commissions")
        self.assertEqual(tiles(owner.text)["مدفوعة"], "150")
        self.assertIn("لا توجد عمولات مستحقة عليك الآن", owner.text)
        self.assertIn(">مؤكد<", owner.text)

    async def test_a_refused_report_frees_the_rentals_and_the_owner_reads_why(self):
        admin, owner, lid = await self.world()
        rid = await self.rent(admin, lid, 500)
        await self.report(owner, [rid], reference="X1")
        r = await admin.post("/admin/payment/1/reject", {"reason": "   "}, page="/admin/payment/1")
        self.assertIn("اكتب السبب", await admin.message())
        self.assertEqual(self.db.one("SELECT status FROM payment_reports")["status"], "pending")
        await admin.post("/admin/payment/1/reject", {"reason": "المبلغ الواصل أقل"}, page="/admin/payment/1")
        row = self.db.one("SELECT * FROM payment_reports")
        self.assertEqual((row["status"], row["decision_note"]), ("rejected", "المبلغ الواصل أقل"))
        self.assertEqual(self.db.one("SELECT pay_status FROM rentals")["pay_status"], "due")
        await owner.get("/owner/commissions")
        self.assertIn("سبب الرفض: المبلغ الواصل أقل", owner.text)
        self.assertIn('name="rental"', owner.text)                                # he can report again
        r = await self.report(owner, [rid], reference="X2")
        self.assertEqual(r.status, 303)
        await admin.post("/admin/payment/1/reject", {"reason": "مرة ثانية"}, page="/admin/payment/1")           # an old, decided report
        self.assertEqual(self.db.one("SELECT decision_note FROM payment_reports WHERE id = 1")["decision_note"], "المبلغ الواصل أقل")
        self.assertEqual(self.db.one("SELECT status FROM payment_reports WHERE id = 2")["status"], "pending")

    async def test_an_owner_can_take_back_his_waiting_report_and_only_his_own(self):
        admin, owner, lid = await self.world()
        other, other_lid = await self.second_owner()
        a = await self.rent(admin, lid, 500)
        await self.rent(admin, other_lid, 500)
        await self.report(owner, [a])
        await other.post("/owner/commissions/report/1/withdraw", {}, page="/owner/commissions")
        self.assertEqual(self.db.one("SELECT status FROM payment_reports")["status"], "pending")      # not his
        await owner.post("/owner/commissions/report/1/withdraw", {}, page="/owner/commissions")
        self.assertEqual(self.db.one("SELECT status FROM payment_reports")["status"], "withdrawn")
        await owner.get("/owner/commissions")
        self.assertIn('name="rental"', owner.text)
        await admin.post("/admin/payment/1/confirm", {"received": "1"}, page="/admin/payment/1")           # nothing to confirm any more
        self.assertEqual(self.db.one("SELECT pay_status FROM rentals WHERE id = 1")["pay_status"], "due")
        await owner.post("/owner/commissions/report/1/withdraw", {}, page="/owner/commissions")
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM audit WHERE action = 'payment_withdraw'")["n"], 1)

    async def test_what_cannot_be_reported(self):
        admin, owner, lid = await self.world()
        other, other_lid = await self.second_owner()
        mine = await self.rent(admin, lid, 500)
        paid = await self.rent(admin, lid, 500)
        await admin.post(f"/admin/rental/{paid}/update", {"rent": "500", "status": "confirmed", "pay_status": "paid"}, page=f"/admin/rental/{paid}")
        cancelled = await self.rent(admin, lid, 500, status="cancelled")
        waived = await self.rent(admin, lid, 500)
        await admin.post(f"/admin/rental/{waived}/update", {"rent": "500", "status": "confirmed", "pay_status": "waived"}, page=f"/admin/rental/{waived}")
        theirs = await self.rent(admin, other_lid, 500)
        count = lambda: self.db.one("SELECT COUNT(*) AS n FROM payment_reports")["n"]
        for ids in ([paid], [cancelled], [waived], [theirs], [mine, theirs], [999], []):
            r = await self.report(owner, ids)
            self.assertEqual(r.status, 400, ids)
        self.assertEqual(count(), 0)
        await self.report(owner, [mine])
        self.assertEqual(count(), 1)
        r = await self.report(owner, [mine])                                      # already waiting
        self.assertEqual(r.status, 400)
        self.assertIn("لم تعد متاحة", owner.text)
        self.assertEqual(count(), 1)
        # ids that are not numbers are dropped, not guessed
        r = await owner.post("/owner/commissions/report", {"rental": ["abc", "-1", "1; DROP TABLE rentals", "٣"], "paid_on": "2026-10-26"}, page="/owner/commissions")
        self.assertEqual(r.status, 400)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM rentals")["n"], 5)

    async def test_the_transfer_date_and_the_reference_are_checked(self):
        admin, owner, lid = await self.world()
        rid = await self.rent(admin, lid, 500)
        for day in ("2026-10-27", "2027-01-01", "2025-10-25", "not a date", ""):
            r = await self.report(owner, [rid], paid_on=day)
            self.assertEqual(r.status, 400, day)
            self.assertIn("تاريخ التحويل", owner.text)
            self.assertIn('name="rental"', owner.text)
        r = await self.report(owner, [rid], reference="م" * 81)
        self.assertEqual(r.status, 400)
        self.assertIn("طويل", owner.text)
        r = await self.report(owner, [rid], paid_on="2025-10-26", reference="م" * 80)         # exactly a year ago and the longest reference
        self.assertEqual(r.status, 303)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM payment_reports")["n"], 1)

    async def test_the_page_keeps_what_was_typed_when_a_report_is_refused(self):
        admin, owner, lid = await self.world()
        a = await self.rent(admin, lid, 500)
        b = await self.rent(admin, lid, 700)
        await self.report(owner, [a], paid_on="2026-12-31", reference="REF-KEPT")
        self.assertIn('value="REF-KEPT"', owner.text)
        self.assertIn('value="2026-12-31"', owner.text)
        boxes = re.findall(r'<input type="checkbox" name="rental" value="(\d+)"[^>]*?( checked)?>', owner.text)
        self.assertEqual(sorted((v, bool(c)) for v, c in boxes), [(str(a), True), (str(b), False)])

    async def test_five_waiting_reports_are_the_most_one_owner_may_have(self):
        admin, owner, lid = await self.world()
        ids = [await self.rent(admin, lid, 100 + i) for i in range(6)]
        for rid in ids[:5]:
            r = await self.report(owner, [rid])
            self.assertEqual(r.status, 303)
        r = await self.report(owner, [ids[5]])
        self.assertEqual(r.status, 400)
        self.assertIn("بلاغات كثيرة", owner.text)
        await owner.post("/owner/commissions/report/1/withdraw", {}, page="/owner/commissions")
        r = await self.report(owner, [ids[5]])
        self.assertEqual(r.status, 303)

    async def test_confirming_leaves_what_the_manager_settled_by_hand(self):
        admin, owner, lid = await self.world()
        a, b, c = [await self.rent(admin, lid, 500) for _ in range(3)]
        await self.report(owner, [a, b, c])
        await admin.post(f"/admin/rental/{b}/update", {"rent": "500", "status": "confirmed", "pay_status": "waived"}, page=f"/admin/rental/{b}")
        await admin.post(f"/admin/rental/{c}/update", {"rent": "500", "status": "confirmed", "pay_status": "disputed"}, page=f"/admin/rental/{c}")
        await admin.get("/admin/payment/1")
        self.assertIn("معفاة", admin.text)
        await admin.post("/admin/payment/1/confirm", {"received": "1"}, page="/admin/payment/1")
        self.assertIn("أكدنا الاستلام وسجلنا 2 عملية مدفوعة، و1 كانت مسددة أو معفاة قبل ذلك", await admin.message())
        states = {r["id"]: r["pay_status"] for r in self.db.all("SELECT id, pay_status FROM rentals")}
        self.assertEqual(states, {a: "paid", b: "waived", c: "paid"})            # the money for the disputed one did arrive; the waived one stays waived

    async def test_a_changed_commission_is_pointed_out_before_confirming(self):
        admin, owner, lid = await self.world()
        rid = await self.rent(admin, lid, 500)
        await self.report(owner, [rid])
        await admin.post(f"/admin/rental/{rid}/update", {"rent": "600", "status": "confirmed", "pay_status": "due"}, page=f"/admin/rental/{rid}")
        await admin.get("/admin/payment/1")
        self.assertIn("تغيّرت العمولة بعد البلاغ: كانت 50 ر.س وصارت 60 ر.س", admin.text)


class EarningsTests(MoneyCase):
    async def test_the_figures_by_state_month_and_owner(self):
        admin, owner, lid = await self.world()
        other, other_lid = await self.second_owner()
        update = lambda rid, rent, pay, status="confirmed": admin.post(f"/admin/rental/{rid}/update", {"rent": str(rent), "status": status, "pay_status": pay}, page=f"/admin/rental/{rid}")
        r1 = await self.rent(admin, lid, 1000, "2026-10-01")         # paid now (this month)
        await update(r1, 1000, "paid")
        await self.rent(admin, lid, 500, "2026-10-25")                # due, not late
        r3 = await self.rent(admin, lid, 2000, "2026-09-01")          # late
        r4 = await self.rent(admin, lid, 300, "2026-09-02")           # disputed
        await update(r4, 300, "disputed")
        r5 = await self.rent(admin, lid, 400, "2026-09-03")           # waived
        await update(r5, 400, "waived")
        await self.rent(admin, lid, 100, "2026-10-02", status="cancelled")
        r7 = await self.rent(admin, other_lid, 600, "2026-10-05")     # waiting for confirmation
        r8 = await self.rent(admin, other_lid, 800, "2026-09-10")     # paid last month
        await update(r8, 800, "paid")
        self.db.run("UPDATE rentals SET paid_at = ? WHERE id = ?", (NOW - 40 * 86400, r8))
        await self.report(other, [r7])
        await admin.get("/admin/earnings")
        t = tiles(admin.text)
        self.assertEqual(t["المحصّل حتى الآن"], "180")           # 100 + 80
        self.assertEqual(t["المحصّل هذا الشهر"], "100")
        self.assertEqual(t["بانتظار تأكيدك"], "60")
        self.assertEqual(t["مستحقة"], "50")
        self.assertEqual(t["متأخرة"], "200")
        self.assertEqual(t["متنازع عليها"], "30")
        self.assertEqual(t["المتبقي لك"], "340")                 # 50 + 200 + 60 + 30
        self.assertIn("معفاة من العمولة: 40 ر.س", admin.text)
        rows = rows_of(admin.text)
        month = {}
        for cells in rows:
            m = re.match(r"((?:أكتوبر|سبتمبر) 2026) العمليات (\d+) الإيجارات ([\d,]+) ر\.س$", cells[0]) if cells else None
            if m:
                month[m.group(1)] = [m.group(2), m.group(3), *cells[1:]]
        self.assertEqual(month["أكتوبر 2026"], ["3", "2,100", "210", "100", "110"])        # the cancelled one is left out
        self.assertEqual(month["سبتمبر 2026"], ["4", "3,500", "310", "80", "230"])        # the waived one is counted as a rental, not as commission
        self.assertEqual(sum(int(x[2].replace(",", "")) for x in month.values()), 520)
        people = {}
        for cells in rows:
            m = re.match(r"(أبو سعد|أبو خالد) العمليات (\d+)$", cells[0]) if cells else None
            if m:
                people[m.group(1)] = [m.group(2), *cells[1:]]
        self.assertEqual(people["أبو سعد"], ["5", "380", "100", "280 منه متأخر 200"])
        self.assertEqual(people["أبو خالد"], ["2", "140", "80", "60"])
        self.assertLess(admin.text.index("أبو سعد"), admin.text.index(">أبو خالد<"))           # the one who owes more comes first
        self.assertEqual(r3, 3)

    async def test_an_empty_site_has_an_empty_page_not_a_crash(self):
        admin = await self.make_admin()
        r = await admin.get("/admin/earnings")
        self.assertEqual(r.status, 200)
        self.assertIn("لا توجد عمليات مسجلة بعد", admin.text)
        self.assertEqual(tiles(admin.text)["المحصّل حتى الآن"], "0")
        self.assertIn("لم تضف بيانات حسابك بعد", admin.text)                      # and a reminder to add the bank details
        await self.set_bank(admin)
        await admin.get("/admin/earnings")
        self.assertNotIn("لم تضف بيانات حسابك بعد", admin.text)

    async def test_the_menu_and_the_dashboard_lead_to_the_earnings(self):
        admin, owner, lid = await self.world()
        await admin.get("/admin")
        self.assertIn('href="/admin/earnings"', admin.text)
        self.assertIn("الأرباح بالتفصيل", admin.text)
        self.assertNotIn("بلاغ سداد بانتظار تأكيدك", admin.text)                 # no alert while nothing waits
        await admin.get("/admin/rentals")
        self.assertIn("pay=reported", admin.text)

    async def test_the_dashboard_shows_the_same_commission_figures(self):
        admin, owner, lid = await self.world()
        other, other_lid = await self.second_owner()
        update = lambda rid, rent, pay: admin.post(f"/admin/rental/{rid}/update", {"rent": str(rent), "status": "confirmed", "pay_status": pay}, page=f"/admin/rental/{rid}")
        await update(await self.rent(admin, lid, 1000, "2026-10-01"), 1000, "paid")                       # 100 collected
        await self.rent(admin, lid, 500, "2026-10-25")                                                    # 50 due
        await self.rent(admin, lid, 2000, "2026-09-01")                                                   # 200 late
        await update(await self.rent(admin, lid, 300, "2026-09-02"), 300, "disputed")                     # 30 disputed
        await update(await self.rent(admin, lid, 400, "2026-09-03"), 400, "waived")                       # never expected: on no tile
        await self.report(other, [await self.rent(admin, other_lid, 600, "2026-10-05")])                 # 60 waiting for confirmation
        await admin.get("/admin")
        dash = tiles(admin.text)
        self.assertEqual([dash[k] for k in ("مدفوعة", "مستحقة", "متأخرة", "بانتظار تأكيدك", "متنازع عليها")], ["100", "50", "200", "60", "30"])
        self.assertIn("لديك 1 بلاغ سداد بانتظار تأكيدك", admin.text)
        await admin.get("/admin/earnings")
        page = tiles(admin.text)
        self.assertEqual([page[k] for k in ("المحصّل حتى الآن", "مستحقة", "متأخرة", "بانتظار تأكيدك", "متنازع عليها")], [dash[k] for k in ("مدفوعة", "مستحقة", "متأخرة", "بانتظار تأكيدك", "متنازع عليها")])

    async def test_the_late_filter_ignores_what_the_owner_already_reported(self):
        admin, owner, lid = await self.world()
        a = await self.rent(admin, lid, 500, "2026-10-01")
        b = await self.rent(admin, lid, 500, "2026-10-02")
        await self.report(owner, [a])
        await admin.get("/admin/rentals?pay=late")
        self.assertIn(f"#{b}", admin.text)
        self.assertNotIn(f"#{a}<", admin.text)
        await admin.get("/admin/rentals?pay=due")
        self.assertNotIn(f"#{a}<", admin.text)


class AccessTests(MoneyCase):
    async def test_every_page_and_action_needs_the_right_sign_in(self):
        admin, owner, lid = await self.world()
        rid = await self.rent(admin, lid, 500)
        await self.report(owner, [rid])
        for path in ("/admin/earnings", "/admin/payment/1", "/admin/pay-details"):
            for who in (self.visitor, owner):
                r = await who.get(path)
                self.assertEqual((r.status, r.headers["Location"]), (303, "/admin/login"), path)
        for path in ("/admin/payment/1/confirm", "/admin/payment/1/reject", "/admin/pay-details"):
            r = await owner.go("POST", path, {"received": "1", "reason": "x"})
            self.assertEqual((r.status, r.headers["Location"]), (303, "/admin/login"), path)
        for path in ("/owner/commissions", ):
            r = await self.visitor.get(path)
            self.assertEqual((r.status, r.headers["Location"].split("?")[0]), (303, "/owner/login"))
        for path in ("/owner/commissions/report", "/owner/commissions/report/1/withdraw"):
            r = await self.visitor.go("POST", path, {"rental": "1"})
            self.assertEqual((r.status, r.headers["Location"].split("?")[0]), (303, "/owner/login"), path)
        self.assertEqual(self.db.one("SELECT status FROM payment_reports")["status"], "pending")

    async def test_posts_without_the_form_token_are_refused(self):
        admin, owner, lid = await self.world()
        rid = await self.rent(admin, lid, 500)
        await owner.get("/owner/commissions")
        r = await owner.go("POST", "/owner/commissions/report", {"rental": str(rid), "paid_on": "2026-10-26"})
        self.assertEqual(r.status, 403)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM payment_reports")["n"], 0)
        await self.report(owner, [rid])
        await owner.go("POST", "/owner/commissions/report/1/withdraw", {"_csrf": "wrong"})
        self.assertEqual(self.db.one("SELECT status FROM payment_reports")["status"], "pending")
        await admin.get("/admin/payment/1")
        for path, form in (("/admin/payment/1/confirm", {"received": "1"}), ("/admin/payment/1/reject", {"reason": "x"}),
                           ("/admin/pay-details", {"holder": "x", "bank": "y", "iban": SHOWN, "password": PASSWORD})):
            r = await admin.go("POST", path, form)
            self.assertEqual(r.status, 403, path)
        self.assertEqual(self.db.one("SELECT status FROM payment_reports")["status"], "pending")
        self.assertEqual(payments.pay_details(self.db)["iban"], "")

    async def test_a_blocked_owner_loses_the_page(self):
        admin, owner, lid = await self.world()
        await self.rent(admin, lid, 500)
        owner_id = self.db.one("SELECT id FROM users WHERE role = 'owner'")["id"]
        await admin.post(f"/admin/owner/{owner_id}/block", {}, page=f"/admin/owner/{owner_id}")
        r = await owner.get("/owner/commissions")
        self.assertEqual(r.status, 303)

    async def test_what_an_owner_types_is_escaped_for_the_manager(self):
        admin, owner, lid = await self.world()
        rid = await self.rent(admin, lid, 500)
        await self.report(owner, [rid], reference="<script>alert(1)</script>")
        for path in ("/admin/earnings", "/admin/payment/1"):
            await admin.get(path)
            self.assertNotIn("<script>alert(1)", admin.text, path)
            self.assertIn("&lt;script&gt;alert(1)", admin.text, path)
        await owner.get("/owner/commissions")
        self.assertNotIn("<script>alert(1)", owner.text)
        self.assertIn("&lt;script&gt;", owner.text)


if __name__ == "__main__":
    unittest.main()
