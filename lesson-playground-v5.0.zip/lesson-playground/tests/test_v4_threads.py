"""Version 4: the shared database connection survives several threads at once (the server runs 2 processes x 4 threads), and an answer behaves like a cursor."""
import os
import tempfile
import threading
import unittest

from app import db as dbm
from tests.test_app import Base


class SharedConnectionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db = dbm.connect(os.path.join(self.tmp.name, "t.db"))
        dbm.init(self.db)
        self.db.execute("INSERT INTO users(email, name, pass_hash, created_at) VALUES ('a@b.co', 'a', 'x', 1)")
        self.db.commit()
        self.addCleanup(self.db.close)

    def hammer(self, job, threads=8, rounds=1500):
        errors, done = [], [0]

        def run():
            for _ in range(rounds):
                try:
                    job()
                    done[0] += 1
                except Exception as exc:                      # noqa: BLE001 - the point is to count whatever goes wrong
                    errors.append(repr(exc)[:100])
        ts = [threading.Thread(target=run) for _ in range(threads)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        return errors, done[0]

    def test_the_same_question_asked_by_many_threads_at_once(self):
        errors, done = self.hammer(lambda: self.assertEqual(self.db.execute("SELECT * FROM users WHERE id = ?", (1,)).fetchone()["email"], "a@b.co"))
        self.assertEqual(errors, [])
        self.assertEqual(done, 8 * 1500)

    def test_writes_from_many_threads_are_all_kept(self):
        self.db.execute("CREATE TABLE t(n INTEGER)")

        def add():
            self.db.execute("INSERT INTO t(n) VALUES (1)")
            self.db.commit()
        errors, done = self.hammer(add, threads=6, rounds=200)
        self.assertEqual(errors, [])
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM t").fetchone()[0], 6 * 200)

    def test_an_answer_works_like_a_cursor(self):
        db = self.db
        db.executemany("INSERT INTO settings(key, value) VALUES (?, ?)", [("a", "1"), ("b", "2"), ("c", "3")])
        cur = db.execute("INSERT INTO settings(key, value) VALUES ('d', '4')")
        self.assertEqual(cur.lastrowid, db.execute("SELECT rowid FROM settings WHERE key = 'd'").fetchone()[0])
        rows = db.execute("SELECT key FROM settings ORDER BY key")
        self.assertEqual(rows.fetchone()[0], "a")
        self.assertEqual([r[0] for r in rows.fetchmany(2)], ["b", "c"])
        self.assertEqual([r[0] for r in rows], ["d"])                                   # a for-loop continues where the reads stopped
        self.assertIsNone(rows.fetchone())
        self.assertEqual(rows.fetchall(), [])
        self.assertEqual(db.execute("UPDATE settings SET value = 'x' WHERE key IN ('a', 'b')").rowcount, 2)
        self.assertEqual(db.execute("SELECT key FROM settings WHERE key = 'zzz'").fetchone(), None)
        self.assertEqual([r[1] for r in db.execute("PRAGMA table_info(settings)")], ["key", "value"])
        self.assertTrue(db.execute("SELECT 1").description)
        with self.assertRaises(Exception):
            db.execute("INSERT INTO settings(key, value) VALUES ('a', 'dup')")           # errors still come out as errors
        self.assertEqual(db.execute("SELECT COUNT(*) FROM settings").fetchone()[0], 4)  # and the connection is still usable after one
        db.rollback()
        self.assertFalse(db.in_transaction)


class ParallelRequestsTests(Base):
    def test_a_page_and_its_files_asked_at_the_same_moment(self):
        """What a browser does: the page, the stylesheet and the scripts together, again and again."""
        c0 = self.client()
        self.register(c0)
        paths = ["/dashboard", "/static/css/app.css", "/static/js/app.js", "/static/js/dashboard.js", "/login", "/subscribe"]
        bad = []

        def browse():
            c = self.client()
            with c.session_transaction() as s:
                s.update(uid=1)
            for _ in range(40):
                for p in paths:
                    r = c.get(p)
                    r.close()
                    if r.status_code != 200:
                        bad.append((p, r.status_code))
        ts = [threading.Thread(target=browse) for _ in range(6)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(bad, [])


if __name__ == "__main__":
    unittest.main()
