"""Version 5, phase 7 through the server: the end of a term (the summary, the archive that keeps it for reading and exporting, the new term that starts clean, taking the closing
back), and the teacher's own data (download, restore, the safety copy, the daily copy of the server). Walls between teachers are tested for every route."""
import datetime
import io
import json
import re
import sqlite3
import tempfile
import unittest
from unittest import mock

from app import classroom, create_app, reports, share, termend, textfmt
from app import db as dbm
from tests import test_v5_phase5 as P5

D = datetime.date
MUTATING = ("post", "put", "patch", "delete")
MID = D(2026, 10, 18)          # a Sunday, half way through the term of the tests (6 September - 17 December)


class Phase7(P5.Phase5):
    def setUp(self):
        super().setUp()
        from app import homework
        for lim in (homework.create_limit, termend.close_limit):
            lim.hits.clear()
            self.addCleanup(lim.hits.clear)

    # ---------------------------------------------------------------- a term half way
    def day(self, n=0):
        return (self.today + datetime.timedelta(days=n)).isoformat()

    def homework(self, w, c=None, **over):
        data = {"class_id": w["cid"], "subject_id": w["sid"], "instructions": "حلّي التمرينين 1 و2 في صفحة 14.", "due": self.day(3), **over}
        r = self.api("post", "/api/homework", data, c)
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        return r.get_json()["assignment"]

    def tick(self, aid, items, c=None):
        r = self.api("put", f"/api/homework/{aid}/status", {"items": [{"student_id": s, "status": st} for s, st in items]}, c)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))

    def midterm(self, c=None, names=P5.NAMES, klass="الصف الأول أ"):
        """A teacher half way through her term, in the middle of her work: a class with four students, a book and its plan (the first two lessons taught), points, two homework
        with who did them, an approved exam with marks, a holiday and a day of absence. Today is Sunday 18 October."""
        n0, n1, n2, n3 = names
        self.today = D(2026, 9, 6)          # (the first day of the term: a holiday and an absence are written while they are still ahead, an absence in a past day is refused)
        w = self.world(c=c, names=names, klass=klass)
        self.planned(w, c)
        r = self.api("post", "/api/calendar/holidays", {"from": "2026-09-27", "to": "2026-09-29", "label": "إجازة"}, c)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        r = self.api("post", "/api/absence", {"from": "2026-10-04"}, c)
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        self.today = MID
        items = self.plan(w["cid"], w["sid"], c)["items"]
        for it in items[:2]:
            self.act(it["id"], "done", c=c)
        st = w["students"]
        self.give(st[n0], 3, c=c)
        self.give(st[n0], 1, c=c)
        self.give(st[n1], 2, c=c)
        a, b = self.homework(w, c=c), self.homework(w, c=c, due=self.day(5))
        self.tick(a["id"], [(st[n0], "done"), (st[n1], "partial"), (st[n2], "missing")], c=c)
        self.tick(b["id"], [(st[n0], "done"), (st[n1], "done")], c=c)
        e = self.new_exam(w, c=c, total=20, date="2026-10-15")
        self.approve(e["id"], c=c)
        self.scores(e["id"], [{"student_id": st[n0], "score": 18}, {"student_id": st[n1], "score": 12}, {"student_id": st[n2], "absent": True}], c=c)
        return {**w, "homework": [a["id"], b["id"]], "exam": e["id"]}

    # ---------------------------------------------------------------- the term
    def term(self, c=None):
        r = (c or self.c).get("/api/term")
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def close(self, c=None, status=200, **over):
        data = {"confirm": True, "name": "الفصل الدراسي الثاني", "starts": "2027-01-10", "ends": "2027-05-20", **over}
        r = self.api("post", "/api/term/close", data, c)
        self.assertEqual(r.status_code, status, r.get_data(as_text=True))
        return r.get_json()

    def archive(self, aid, c=None):
        r = (c or self.c).get(f"/api/term/archives/{aid}")
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def rows(self, sql, *args):
        return [dict(r) for r in self.app.db.execute(sql, args).fetchall()]

    def terms_rows(self, c=None):
        return self.rows("SELECT id, name, starts, ends, archived FROM terms ORDER BY id")

    def what_is_there(self):
        """Every table that holds what she did in the term, as it is now."""
        tables = ("classes", "students", "subjects", "class_subjects", "books", "book_units", "book_lessons", "schedule_slots", "calendar_days", "plan_items", "plan_log", "absences", "points",
                  "assignments", "assignment_students", "exams", "exam_questions", "exam_scores", "results", "lessons", "questions", "decks")
        return {t: self.rows(f"SELECT * FROM {t} ORDER BY id") for t in tables}


# ================================================================ how the term went
class Summary(Phase7):
    def test_a_teacher_with_no_term_has_nothing_to_close(self):
        d = self.term()
        self.assertEqual((d["term"], d["summary"], d["archives"], d["can_close"]), (None, None, [], False))
        self.assertIn("التقويم", d["why"])
        self.assertEqual(self.c.get("/api/term/csv").status_code, 404)

    def test_a_term_that_has_not_begun_is_not_summed_up_and_cannot_be_closed(self):
        self.set_term("2026-09-20", "2026-12-17")
        self.assertEqual(self.today, D(2026, 9, 6))
        d = self.term()
        self.assertEqual((d["state"], d["days"], d["summary"], d["can_close"]), ("before", 14, None, False))
        self.assertIn("لم يبدأ", d["why"])
        self.assertEqual(self.c.get("/api/term/csv").status_code, 404)
        self.close(status=400)
        self.assertEqual([t["archived"] for t in self.terms_rows()], [0])

    def test_the_state_of_the_term_follows_the_day(self):
        self.set_term()
        for day, want in ((D(2026, 9, 6), ("running", 102)), (D(2026, 10, 18), ("running", 60)), (D(2026, 12, 17), ("running", 0)), (D(2026, 12, 18), ("ended", 1)), (D(2027, 1, 3), ("ended", 17))):
            self.today = day
            d = self.term()
            self.assertEqual((d["state"], d["days"]), want, day)
            self.assertTrue(d["can_close"])

    def test_the_summary_tells_what_the_term_held_class_by_class(self):
        w = self.midterm()
        s = self.term()["summary"]
        t = s["totals"]
        self.assertEqual((t["classes"], t["students"], t["points"], t["awards"]), (1, 4, 6, 3))
        self.assertEqual((t["lessons_done"], t["lessons_pending"], t["lessons_skipped"]), (2, 5, 0))
        self.assertEqual((t["homework_given"], t["homework_done"], t["homework_checked"], t["homework_percent"]), (2, 3, 5, 60))
        self.assertEqual((t["exams"], t["absence_days"], t["holidays"]), (1, 1, 3))
        self.assertEqual((s["term"]["name"], s["term"]["starts"], s["term"]["ends"]), ("الفصل الدراسي", "2026-09-06", "2026-10-18"))          # (counted up to today)
        c = s["classes"][0]
        self.assertEqual((c["name"], c["students"], c["points"], c["awards"], c["ranked"], c["silent"]), ("الصف الأول أ", 4, 6, 3, 2, 2))
        self.assertEqual([(x["name"], x["points"], x["rank"]) for x in c["top"]], [("سارة", 4, 1), ("نورة", 2, 2)])
        self.assertEqual(c["homework"], {"given": 2, "done": 3, "partial": 1, "missing": 1, "pending": 3, "checked": 5, "percent": 60})
        p = c["plans"][0]
        self.assertEqual((p["subject"], p["done"], p["pending"], p["skipped"], p["need"]), ("العلوم", 2, 5, 0, None))
        self.assertGreater(p["percent"], 0)
        e = c["exams"][0]
        self.assertEqual((e["date"], e["total"], e["students"], e["entered"], e["absent"], e["missing"], e["average"], e["percent"], e["highest"], e["lowest"], e["passed"]),
                         ("2026-10-15", 20, 4, 2, 1, 1, 15.0, 75, 18, 12, 2))
        self.assertNotIn("scores", e)

    def test_every_student_has_a_line_with_the_marks_of_the_exams(self):
        w = self.midterm()
        rows = {r["name"]: r for r in self.term()["summary"]["classes"][0]["rows"]}
        self.assertEqual(sorted(rows), sorted(P5.NAMES))
        s = rows["سارة"]
        self.assertEqual((s["points"], s["awards"], s["rank"], s["hw_done"], s["hw_checked"], s["scores"], s["exam_percent"], s["exam_count"]), (4, 2, 1, 2, 2, [18], 90, 1))
        self.assertEqual((rows["نورة"]["scores"], rows["نورة"]["exam_percent"], rows["نورة"]["hw_done"], rows["نورة"]["hw_checked"]), ([12], 60, 1, 2))
        self.assertEqual((rows["ليان"]["scores"], rows["ليان"]["exam_percent"], rows["ليان"]["exam_count"], rows["ليان"]["hw_checked"]), (["غ"], None, 0, 1))          # absent: no share
        self.assertEqual((rows["مها"]["scores"], rows["مها"]["exam_percent"], rows["مها"]["hw_checked"], rows["مها"]["rank"]), ([None], None, 0, None))

    def test_the_share_in_the_exams_is_the_mean_of_the_exams_she_sat(self):
        w = self.midterm()
        st = w["students"]
        second = self.new_exam(w, total=10, date="2026-10-16")
        self.approve(second["id"])
        self.scores(second["id"], [{"student_id": st["سارة"], "score": 5}, {"student_id": st["نورة"], "score": 10}])
        rows = {r["name"]: r for r in self.term()["summary"]["classes"][0]["rows"]}
        self.assertEqual((rows["سارة"]["exam_count"], rows["سارة"]["exam_percent"]), (2, 70))          # (90 + 50) / 2
        self.assertEqual((rows["نورة"]["exam_count"], rows["نورة"]["exam_percent"]), (2, 80))          # (60 + 100) / 2
        self.assertEqual((rows["ليان"]["exam_count"], rows["ليان"]["exam_percent"]), (0, None))          # absent from the first, not entered in the second

    def test_what_is_outside_the_term_is_not_counted(self):
        w = self.midterm()
        st = w["students"]
        self.today = D(2026, 8, 20)          # before the first day
        self.give(st["مها"], 5)
        self.today = D(2026, 10, 18)
        s = self.term()["summary"]
        self.assertEqual(s["totals"]["points"], 6)
        self.assertEqual(self.rows("SELECT SUM(amount) AS n FROM points")[0]["n"], 11)          # (it was saved, it is only not this term's)

    def test_only_approved_exams_count_and_by_their_day(self):
        w = self.midterm()
        self.new_exam(w, total=10, date="2026-10-16")                 # a draft
        late = self.new_exam(w, total=10, date="2027-02-01")          # approved, but after the term
        self.approve(late["id"])
        early = self.new_exam(w, total=10, date="2026-08-01")         # approved, before the term
        self.approve(early["id"])
        s = self.term()["summary"]
        self.assertEqual(s["totals"]["exams"], 1)
        self.assertEqual([e["date"] for e in s["classes"][0]["exams"]], ["2026-10-15"])

    def test_an_exam_without_a_day_belongs_to_the_day_it_was_made(self):
        w = self.world()
        self.planned(w)
        self.today = MID
        e = self.new_exam(w, total=10)
        self.approve(e["id"])
        self.assertFalse(self.rows("SELECT exam_date FROM exams")[0]["exam_date"])          # (no day: the day it was made counts)
        for made, inside in ((D(2026, 10, 10), True), (D(2026, 9, 6), True), (D(2026, 10, 18), True), (D(2026, 9, 5), False), (D(2026, 10, 19), False)):
            stamp = datetime.datetime(made.year, made.month, made.day, 12, tzinfo=classroom.TZ).timestamp()
            self.app.db.execute("UPDATE exams SET created_at = ?", (stamp,))
            self.app.db.commit()
            self.assertEqual(len(self.term()["summary"]["classes"][0]["exams"]), 1 if inside else 0, made)
        late = datetime.datetime(2026, 10, 18, 23, 50, tzinfo=classroom.TZ).timestamp()          # (the teacher's day is the one in Riyadh, not in UTC)
        self.app.db.execute("UPDATE exams SET created_at = ?", (late,))
        self.app.db.commit()
        self.assertEqual(termend.day_of(late), "2026-10-18")
        self.assertEqual(len(self.term()["summary"]["classes"][0]["exams"]), 1)

    def test_each_class_has_its_own_figures_and_its_students_only(self):
        w = self.midterm()
        other = self.world(names=("ريم", "دانة"), klass="الصف الأول ب", subject="الرياضيات", texts=())
        self.give(other["students"]["ريم"], 5)
        self.homework(other)
        s = self.term()["summary"]
        self.assertEqual([c["name"] for c in s["classes"]], ["الصف الأول أ", "الصف الأول ب"])
        a, b = s["classes"]
        self.assertEqual((a["points"], a["students"], a["homework"]["given"], len(a["exams"])), (6, 4, 2, 1))
        self.assertEqual((b["points"], b["students"], b["homework"]["given"], len(b["exams"])), (5, 2, 1, 0))
        self.assertEqual(sorted(r["name"] for r in b["rows"]), ["دانة", "ريم"])
        self.assertEqual(s["totals"]["points"], 11)
        self.assertEqual(s["totals"]["students"], 6)

    def test_another_teachers_term_never_enters_mine(self):
        w = self.midterm()
        b = self.second_teacher()
        self.today = D(2026, 10, 18)
        mine = self.term()["summary"]["totals"]
        self.midterm(c=b, names=("هيا", "وعد", "جود", "رند"), klass="الصف الثاني")
        self.today = D(2026, 10, 18)
        self.app.db.execute("INSERT INTO absences(user_id, day, period, reason, created_at) VALUES (2, '2026-10-11', 0, '', 0)")          # her own absence on another day of the same term
        self.app.db.commit()
        self.assertEqual(self.term()["summary"]["totals"], mine)
        self.assertEqual(self.term(c=b)["summary"]["totals"]["absence_days"], 2)
        theirs = self.term(c=b)["summary"]
        self.assertEqual((theirs["totals"]["classes"], theirs["totals"]["students"], [c["name"] for c in theirs["classes"]]), (1, 4, ["الصف الثاني"]))

    def test_the_sheet_of_the_live_term(self):
        w = self.midterm()
        r = self.c.get("/api/term/csv")
        self.assertEqual((r.status_code, r.mimetype), (200, "text/csv"))
        self.assertTrue(r.data.startswith("﻿".encode()))
        rows = [x.split(",") for x in r.data.decode("utf-8-sig").strip().split("\r\n")]
        self.assertEqual(rows[1][:3], ["الفصل", "الطالب", "النقاط"])
        by = {x[1]: x for x in rows[2:]}
        self.assertEqual(sorted(by), sorted(P5.NAMES))
        self.assertEqual(by["سارة"][:8], ["الصف الأول أ", "سارة", "4", "2", "1", "0", "0", ""])
        self.assertEqual(by["سارة"][8:], ["2", "2", "1", "90"])
        one = [x.split(",") for x in self.c.get("/api/term/csv?class=" + "الصف الأول أ").data.decode("utf-8-sig").strip().split("\r\n")]
        self.assertEqual(one[1][:2], ["الترتيب", "الطالب"])
        self.assertIn("متوسط الاختبارات %", one[1])
        self.assertEqual(len(one[1]), 9 + 1 + 1)          # the nine, the one exam, the share
        self.assertEqual(self.c.get("/api/term/csv?class=لا%20فصل").status_code, 404)

    def test_the_sheet_of_one_class_has_that_class_only(self):
        w = self.midterm()
        other = self.world(names=("ريم", "دانة"), klass="الصف الأول ب", subject="الرياضيات", texts=())
        self.give(other["students"]["ريم"], 5)
        every = self.c.get("/api/term/csv").data.decode("utf-8-sig")
        self.assertIn("ريم", every)
        self.assertIn("سارة", every)
        one = self.c.get("/api/term/csv?class=" + "الصف الأول ب").data.decode("utf-8-sig")
        self.assertIn("ريم", one)
        self.assertIn("دانة", one)
        for name in P5.NAMES:
            self.assertNotIn(name, one)
        first = self.c.get("/api/term/csv?class=" + "الصف الأول أ").data.decode("utf-8-sig")
        self.assertNotIn("ريم", first)
        self.assertNotIn("دانة", first)
        self.assertIn("سارة", first)

    def test_a_name_that_looks_like_a_formula_is_made_plain_text_in_the_sheet(self):
        w = self.world(names=("=HYPERLINK(1)", "+1", "عادية"))
        self.planned(w)
        self.today = MID
        text = self.c.get("/api/term/csv").data.decode("utf-8-sig")
        self.assertIn("'=HYPERLINK(1)", text)
        self.assertIn("'+1", text)
        self.assertNotIn(",=HYPERLINK", text)
        one = self.c.get("/api/term/csv?class=" + "الصف الأول أ").data.decode("utf-8-sig")          # the sheet of one class is guarded the same way
        self.assertIn("'=HYPERLINK(1)", one)
        self.assertIn("'+1", one)
        self.assertNotIn(",=HYPERLINK", one)
        self.assertNotIn(",+1,", one)

    def test_the_summary_changes_nothing(self):
        self.midterm()
        before = self.what_is_there()
        self.term()
        self.c.get("/api/term/csv")
        self.assertEqual(self.what_is_there(), before)
        self.assertEqual(self.rows("SELECT COUNT(*) AS n FROM term_archives")[0]["n"], 0)


# ================================================================ closing the term
class Closing(Phase7):
    def test_closing_must_be_confirmed(self):
        self.midterm()
        for bad in ({"confirm": False}, {"confirm": "yes"}, {"confirm": 1}, {"confirm": None}):
            r = self.api("post", "/api/term/close", {"name": "ب", "starts": "2027-01-10", "ends": "2027-05-20", **bad})
            self.assertEqual(r.status_code, 400, bad)
        r = self.api("post", "/api/term/close", {"starts": "2027-01-10", "ends": "2027-05-20"})
        self.assertEqual(r.status_code, 400)
        self.assertEqual([t["archived"] for t in self.terms_rows()], [0])

    def test_the_new_term_needs_two_real_days_in_order(self):
        self.midterm()
        for bad in ({"starts": ""}, {"ends": ""}, {"starts": "2027-13-01"}, {"ends": "ليس تاريخا"}, {"starts": 5}, {"ends": None}, {"starts": "2027-5-1"},
                    {"starts": "2027-05-20", "ends": "2027-01-10"}, {"starts": "2027-01-10", "ends": "2027-01-10"}, {"starts": "2027-01-10", "ends": "2028-01-10"}):
            self.close(status=400, **bad)
        self.assertEqual(self.rows("SELECT COUNT(*) AS n FROM term_archives")[0]["n"], 0)
        self.assertEqual([t["archived"] for t in self.terms_rows()], [0])

    def test_the_new_term_begins_after_the_old_one_ends(self):
        self.midterm()          # today 18 Oct: the old term ends today when it is closed
        self.close(status=400, starts="2026-10-18", ends="2027-02-01")
        self.close(status=400, starts="2026-10-01", ends="2027-02-01")
        self.assertEqual([t["archived"] for t in self.terms_rows()], [0])
        self.close(starts="2026-10-19", ends="2027-02-01")          # the very next day is fine

    def test_the_new_term_may_not_overlap_an_older_one(self):
        self.midterm()
        first = self.close(starts="2027-01-10", ends="2027-05-20")
        self.today = D(2027, 5, 21)
        self.close(status=400, starts="2027-05-01", ends="2027-09-01")          # inside the term that has just begun
        self.close(status=400, starts="2026-06-01", ends="2026-09-10")          # reaches back into the first one
        self.close(status=400, starts="2026-12-01", ends="2027-02-01")
        self.close(starts="2027-06-01", ends="2027-09-01")
        self.assertEqual([t["archived"] for t in self.terms_rows()], [1, 1, 0])

    def test_the_new_term_may_not_overlap_one_that_is_already_there_ahead(self):
        self.midterm()
        self.app.db.execute("INSERT INTO terms(user_id, name, starts, ends, created_at) VALUES (1, 'فصل قادم', '2027-07-01', '2027-10-30', 0)")
        self.app.db.commit()
        self.close(status=400, starts="2027-01-10", ends="2027-07-15")          # reaches into it
        self.close(status=400, starts="2027-08-01", ends="2027-09-01")          # inside it
        self.close(status=400, starts="2027-06-01", ends="2028-01-10")          # swallows it
        self.assertEqual(self.count("SELECT COUNT(*) FROM term_archives"), 0)
        self.close(starts="2027-01-10", ends="2027-06-30")          # ends the day before it begins

    def test_a_term_that_has_ended_is_closed_with_its_own_last_day(self):
        w = self.midterm()
        self.today = D(2026, 12, 20)
        r = self.close()
        arc = self.rows("SELECT * FROM term_archives")[0]
        self.assertEqual((arc["starts"], arc["ends"], arc["orig_ends"], arc["closed_on"]), ("2026-09-06", "2026-12-17", "2026-12-17", "2026-12-20"))
        self.assertEqual((arc["term_id"], arc["new_term_id"]), (self.terms_rows()[0]["id"], r["term"]["id"]))
        self.assertEqual(self.terms_rows()[0]["ends"], "2026-12-17")

    def test_a_term_closed_early_ends_the_day_it_is_closed(self):
        w = self.midterm()          # 18 October of a term that ends on 17 December
        r = self.close()
        old, new = self.terms_rows()
        self.assertEqual((old["archived"], old["starts"], old["ends"]), (1, "2026-09-06", "2026-10-18"))
        arc = self.rows("SELECT * FROM term_archives")[0]
        self.assertEqual((arc["ends"], arc["orig_ends"], arc["closed_on"]), ("2026-10-18", "2026-12-17", "2026-10-18"))
        self.assertEqual((new["archived"], new["name"], new["starts"], new["ends"]), (0, "الفصل الدراسي الثاني", "2027-01-10", "2027-05-20"))

    def test_closing_makes_the_archive_and_the_new_term_the_current_one(self):
        w = self.midterm()
        r = self.close()
        self.assertEqual((r["ok"], r["term"]["name"], r["term"]["starts"], r["term"]["ends"]), (True, "الفصل الدراسي الثاني", "2027-01-10", "2027-05-20"))
        cal = self.c.get("/api/calendar").get_json()
        self.assertEqual((cal["term"]["id"], cal["term"]["name"]), (r["term"]["id"], "الفصل الدراسي الثاني"))
        self.assertEqual(cal["holidays"], 0)          # the holidays belong to the old term
        d = self.term()
        self.assertEqual([a["id"] for a in d["archives"]], [r["archive_id"]])
        self.assertEqual((d["state"], d["term"]["name"]), ("before", "الفصل الدراسي الثاني"))
        self.assertEqual(d["archives"][0]["totals"]["points"], 6)
        self.assertTrue(d["archives"][0]["latest"])

    def test_the_name_has_a_default_and_is_cleaned_and_cut(self):
        self.midterm()
        r = self.close(name="   ")
        self.assertEqual(r["term"]["name"], "الفصل الدراسي الجديد")          # «الفصل الدراسي» has no number: the next one is a new term
        self.assertEqual(termend.next_name("الفصل الدراسي الأول"), "الفصل الدراسي الثاني")
        self.assertEqual(termend.next_name("الفصل الثاني 1448"), "الفصل الثالث 1448")
        self.assertEqual(termend.next_name("الفصل الدراسي الثالث"), "الفصل الدراسي الأول")
        self.assertEqual(termend.next_name("ترم"), "الفصل الدراسي الجديد")
        self.today = D(2027, 5, 21)
        r = self.close(name="  " + "ط" * 100 + "  ", starts="2027-06-01", ends="2027-09-01")
        self.assertEqual(len(r["term"]["name"]), 60)

    def test_nothing_she_did_in_the_term_is_deleted_or_changed(self):
        w = self.midterm()
        before = self.what_is_there()
        plan_before = before.pop("plan_items")
        log_before = before.pop("plan_log")
        slots_before = before.pop("calendar_days")
        self.close()
        after = self.what_is_there()
        for t, rows in before.items():
            self.assertEqual(after[t], rows, t)
        self.assertEqual([r for r in after["plan_items"] if r["term_id"] == self.terms_rows()[0]["id"]], plan_before)          # the old plan is as it was
        self.assertEqual(after["calendar_days"], slots_before)          # and so are the holidays of the old term
        self.assertEqual(after["plan_log"][:len(log_before)], log_before)

    def test_the_classes_the_students_the_books_and_the_timetable_stay(self):
        w = self.midterm()
        self.close()
        self.assertEqual(self.c.get("/api/students").get_json()["classes"][0]["name"], "الصف الأول أ")
        self.assertEqual(sorted(s["name"] for s in self.c.get(f"/api/students?class_id={w['cid']}").get_json()["students"]), sorted(P5.NAMES))
        self.assertEqual(self.count("SELECT COUNT(*) FROM book_lessons"), 7)
        self.assertEqual(self.count("SELECT COUNT(*) FROM schedule_slots"), 2)
        self.assertEqual(self.c.get("/api/schedule").status_code, 200)

    def test_the_old_term_leaves_the_current_reports_but_not_the_data(self):
        w = self.midterm()
        self.close()
        r = self.c.get(f"/api/reports/class/{w['cid']}?period=term").get_json()
        self.assertEqual((r["points"], r["first"], r["last"]), (0, "2027-01-10", "2027-05-20"))          # the new term has no points yet
        self.assertEqual(self.c.get(f"/api/reports/class/{w['cid']}?period=all").get_json()["points"], 6)
        self.assertEqual(self.c.get(f"/api/reports/class/{w['cid']}?period=all").get_json()["homework"]["given"], 2)

    def test_the_snapshot_keeps_its_numbers_when_the_data_changes_later(self):
        w = self.midterm()
        r = self.close()
        before = self.archive(r["archive_id"])["summary"]
        self.assertEqual(before["totals"]["points"], 6)
        self.assertEqual(self.api("delete", f"/api/classes/{w['cid']}").status_code, 200)
        self.give_anything = None
        after = self.archive(r["archive_id"])["summary"]
        self.assertEqual(after, before)
        self.assertEqual(after["classes"][0]["name"], "الصف الأول أ")
        self.assertEqual(after["classes"][0]["rows"][0]["name"], "سارة")

    def test_the_snapshot_is_the_summary_of_the_day_it_was_closed(self):
        w = self.midterm()
        live = self.term()["summary"]
        r = self.close()
        self.assertEqual(self.archive(r["archive_id"])["summary"], live)

    def test_a_failure_while_closing_changes_nothing(self):
        w = self.midterm()
        before = (self.what_is_there(), self.terms_rows())
        with mock.patch("app.termend.carry_plans", side_effect=RuntimeError("boom")):
            r = self.api("post", "/api/term/close", {"confirm": True, "name": "ب", "starts": "2027-01-10", "ends": "2027-05-20"})
        self.assertEqual(r.status_code, 500)
        self.assertEqual((self.what_is_there(), self.terms_rows()), before)
        self.assertEqual(self.count("SELECT COUNT(*) FROM term_archives"), 0)
        self.close()          # and the same request works afterwards

    def test_closing_is_limited_to_ten_times_an_hour(self):
        self.midterm()
        for i in range(10):
            r = self.close()
            self.assertEqual(self.api("post", f"/api/term/archives/{r['archive_id']}/reopen", {"confirm": True}).status_code, 200)
        self.close(status=429)

    def test_there_is_a_most_for_the_archives(self):
        self.midterm()
        first = self.terms_rows()[0]["id"]
        for i in range(termend.MAX_ARCHIVES):
            self.app.db.execute("INSERT INTO terms(user_id, name, starts, ends, archived, created_at) VALUES (1, ?, ?, ?, 1, 1)", (f"قديم {i}", f"{1900 + i}-01-01", f"{1900 + i}-02-01"))
            tid = self.app.db.execute("SELECT MAX(id) FROM terms").fetchone()[0]
            self.app.db.execute("INSERT INTO term_archives(user_id, term_id, name, starts, ends, orig_ends, closed_on, created_at) VALUES (1, ?, 'x', 'a', 'b', 'b', 'c', 1)", (tid,))
        self.app.db.commit()
        self.assertEqual(self.close(status=400)["error"].count("الحد الأقصى"), 1)
        d = self.term()
        self.assertFalse(d["can_close"])


# ================================================================ the plan of the new term
class NewPlan(Phase7):
    def test_the_lessons_she_taught_are_set_aside_in_the_new_plan_not_deleted(self):
        w = self.midterm()
        old = self.plan(w["cid"], w["sid"])["items"]
        taught = [i["title"] for i in old if i["status"] == "done"]
        self.assertEqual(len(taught), 2)
        r = self.close()
        self.assertEqual(r["carried"], 2)
        self.today = D(2027, 1, 12)
        p = self.plan(w["cid"], w["sid"])
        self.assertEqual(p["term"]["name"], "الفصل الدراسي الثاني")
        self.assertIsNone(p["need"])
        by = {i["title"]: i for i in p["items"]}
        self.assertEqual(len(p["items"]), 7)
        for t in taught:
            self.assertEqual(by[t]["status"], "skipped", t)
            self.assertIn("أُنجز في «الفصل الدراسي»", by[t]["note"])
        self.assertEqual(sorted(i["status"] for i in p["items"]).count("pending"), 5)
        self.assertEqual(p["summary"]["percent"], 0)          # the new term starts from nothing
        self.assertTrue(all(i["planned"] for i in p["items"] if i["status"] == "pending"))          # and the rest is laid out over the new term
        first = min(i["planned"]["first"]["date"] for i in p["items"] if i["status"] == "pending")
        self.assertGreaterEqual(first, "2027-01-10")

    def test_the_rest_of_the_plan_gets_its_due_days_in_the_new_term(self):
        w = self.midterm()
        self.close()
        new_id = self.terms_rows()[1]["id"]
        pending = self.rows("SELECT * FROM plan_items WHERE term_id = ? AND status = 'pending' ORDER BY position, id", new_id)
        self.assertEqual(len(pending), 5)
        for it in pending:
            self.assertGreaterEqual(it["due_date"], "2027-01-10", it["position"])          # laid out over the new term, from its first day
            self.assertGreater(it["due_period"], 0)
        self.assertEqual([it["due_date"] for it in pending], sorted(it["due_date"] for it in pending))

    def test_a_lesson_set_aside_can_be_brought_back(self):
        w = self.midterm()
        self.close()
        self.today = D(2027, 1, 12)
        skipped = next(i for i in self.plan(w["cid"], w["sid"])["items"] if i["status"] == "skipped")
        self.act(skipped["id"], "restore")
        got = next(i for i in self.plan(w["cid"], w["sid"])["items"] if i["id"] == skipped["id"])
        self.assertEqual(got["status"], "pending")

    def test_the_lessons_she_did_not_teach_wait_in_the_new_plan(self):
        w = self.midterm()
        old = {i["title"]: i["status"] for i in self.plan(w["cid"], w["sid"])["items"]}
        self.close()
        self.today = D(2027, 1, 12)
        new = {i["title"]: i["status"] for i in self.plan(w["cid"], w["sid"])["items"]}
        self.assertEqual({t: ("skipped" if s == "done" else s) for t, s in old.items()}, new)

    def test_the_old_plan_is_still_in_the_database_under_its_own_term(self):
        w = self.midterm()
        old_id = self.terms_rows()[0]["id"]
        before = self.rows("SELECT * FROM plan_items WHERE term_id = ? ORDER BY id", old_id)
        r = self.close()
        self.assertEqual(self.rows("SELECT * FROM plan_items WHERE term_id = ? ORDER BY id", old_id), before)
        self.assertEqual(self.count("SELECT COUNT(*) FROM plan_items WHERE term_id = ?", r["term"]["id"]), 7)
        self.assertEqual(self.count("SELECT COUNT(*) FROM plan_items WHERE term_id = ? AND status = 'skipped'", r["term"]["id"]), 2)

    def test_the_plan_log_tells_what_was_set_aside(self):
        w = self.midterm()
        r = self.close()
        log = self.rows("SELECT kind, text FROM plan_log WHERE term_id = ?", r["term"]["id"])
        self.assertEqual([l["kind"] for l in log], ["term"])
        self.assertIn("الفصل الدراسي الثاني", log[0]["text"])

    def test_without_carrying_the_new_plan_is_left_to_be_built(self):
        w = self.midterm()
        r = self.close(carry=False)
        self.assertEqual(r["carried"], 0)
        self.assertEqual(self.count("SELECT COUNT(*) FROM plan_items WHERE term_id = ?", r["term"]["id"]), 0)
        self.today = D(2027, 1, 12)
        self.assertEqual(self.plan(w["cid"], w["sid"])["need"], "build")
        p = self.build(w["cid"], w["sid"])
        self.assertEqual(sorted(i["status"] for i in p["items"]).count("pending"), 7)

    def test_carrying_is_the_default(self):
        w = self.midterm()
        for value in (True, None, "no", 0):
            r = self.close(carry=value)
            self.assertEqual(r["carried"], 2, value)
            self.api("post", f"/api/term/archives/{r['archive_id']}/reopen", {"confirm": True})

    def test_only_lessons_of_the_book_linked_now_are_set_aside(self):
        w = self.midterm()
        other = self.outline_book(title="كتاب الترم الثاني", text=P5.OUTLINE_SCI)
        self.confirm(other, [w["cid"]], subject="العلوم")          # the class now uses another book for this subject
        r = self.close()
        self.assertEqual(r["carried"], 0)
        self.assertEqual(self.count("SELECT COUNT(*) FROM plan_items WHERE term_id = ? AND status = 'skipped'", r["term"]["id"]), 0)
        self.assertEqual(self.count("SELECT COUNT(*) FROM plan_items WHERE term_id = ?", r["term"]["id"]), 7)

    def test_a_pair_that_had_no_plan_gets_none(self):
        w = self.world()
        self.set_term()
        self.today = MID
        r = self.close()
        self.assertEqual((r["carried"], self.count("SELECT COUNT(*) FROM plan_items")), (0, 0))

    def test_other_teachers_plans_are_not_touched(self):
        w = self.midterm()
        b = self.second_teacher()
        theirs = self.midterm(c=b, names=("هيا", "وعد", "جود", "رند"), klass="الصف الثاني")
        before = self.rows("SELECT * FROM plan_items WHERE user_id = 2 ORDER BY id")
        self.close()
        self.assertEqual(self.rows("SELECT * FROM plan_items WHERE user_id = 2 ORDER BY id"), before)
        self.assertEqual([t["archived"] for t in self.rows("SELECT archived FROM terms WHERE user_id = 2")], [0])


# ================================================================ taking it back
class Reopening(Phase7):
    def test_the_last_closing_can_be_taken_back_and_everything_is_as_it_was(self):
        w = self.midterm()
        before = (self.what_is_there(), self.terms_rows())
        r = self.close()
        self.assertEqual(self.api("post", "/api/calendar/holidays", {"from": "2027-02-01", "label": "إجازة جديدة"}).status_code, 200)          # something she added to the new term
        self.assertEqual(self.api("post", f"/api/term/archives/{r['archive_id']}/reopen", {"confirm": True}).status_code, 200)
        after_tables, after_terms = self.what_is_there(), self.terms_rows()
        old = before[1][0]
        self.assertEqual(after_terms, [{**old, "ends": "2026-12-17"}])          # open again, with its last day back
        for t, rows in before[0].items():
            self.assertEqual(after_tables[t], rows, t)
        self.assertEqual(self.count("SELECT COUNT(*) FROM term_archives"), 0)
        self.assertEqual(self.term()["term"]["name"], "الفصل الدراسي")
        self.assertEqual(self.term()["archives"], [])
        self.close()          # she can close it again

    def test_reopening_needs_a_confirmation(self):
        w = self.midterm()
        r = self.close()
        for bad in ({}, {"confirm": False}, {"confirm": "true"}, {"confirm": 1}):
            self.assertEqual(self.api("post", f"/api/term/archives/{r['archive_id']}/reopen", bad).status_code, 400, bad)
        self.assertEqual(self.count("SELECT COUNT(*) FROM term_archives"), 1)

    def test_only_the_latest_closing_can_be_taken_back(self):
        w = self.midterm()
        first = self.close()
        self.today = D(2027, 5, 21)
        second = self.close(starts="2027-06-01", ends="2027-09-01")
        self.assertEqual(self.api("post", f"/api/term/archives/{first['archive_id']}/reopen", {"confirm": True}).status_code, 409)
        self.assertFalse(self.archive(first["archive_id"])["can_reopen"])
        self.assertTrue(self.archive(second["archive_id"])["can_reopen"])
        self.assertEqual(self.api("post", f"/api/term/archives/{second['archive_id']}/reopen", {"confirm": True}).status_code, 200)
        self.assertTrue(self.archive(first["archive_id"])["can_reopen"])          # now the first is the latest

    def test_an_older_closing_is_refused_even_when_its_new_term_looks_open(self):
        w = self.midterm()
        first = self.close()
        self.today = D(2027, 5, 21)
        second = self.close(starts="2027-06-01", ends="2027-09-01")
        self.app.db.execute("UPDATE terms SET archived = 0 WHERE id = ?", (first["term"]["id"],))          # (a state the pages never make: the rule must not lean on the other one)
        self.app.db.commit()
        self.assertEqual(self.api("post", f"/api/term/archives/{first['archive_id']}/reopen", {"confirm": True}).status_code, 409)
        self.assertEqual(self.count("SELECT COUNT(*) FROM term_archives"), 2)
        self.assertEqual(self.count("SELECT COUNT(*) FROM terms"), 3)

    def test_it_cannot_be_taken_back_when_the_new_term_is_gone(self):
        w = self.midterm()
        r = self.close()
        self.app.db.execute("UPDATE term_archives SET new_term_id = NULL WHERE id = ?", (r["archive_id"],))
        self.app.db.commit()
        self.assertEqual(self.api("post", f"/api/term/archives/{r['archive_id']}/reopen", {"confirm": True}).status_code, 409)
        self.assertFalse(self.archive(r["archive_id"])["can_reopen"])

    def test_a_term_that_is_not_hers_or_not_there_is_not_found(self):
        w = self.midterm()
        r = self.close()
        self.assertEqual(self.api("post", "/api/term/archives/999/reopen", {"confirm": True}).status_code, 404)
        b = self.second_teacher()
        self.assertEqual(self.api("post", f"/api/term/archives/{r['archive_id']}/reopen", {"confirm": True}, c=b).status_code, 404)
        self.assertEqual(self.count("SELECT COUNT(*) FROM term_archives"), 1)


# ================================================================ the archive
class Archives(Phase7):
    def test_the_list_is_newest_first_with_its_figures(self):
        w = self.midterm()
        first = self.close()
        self.today = D(2027, 5, 21)
        second = self.close(name="الثالث", starts="2027-06-01", ends="2027-09-01")
        d = self.term()
        self.assertEqual([a["id"] for a in d["archives"]], [second["archive_id"], first["archive_id"]])
        self.assertEqual([a["latest"] for a in d["archives"]], [True, False])
        a = d["archives"][1]
        self.assertEqual((a["name"], a["starts"], a["ends"], a["closed_on"]), ("الفصل الدراسي", "2026-09-06", "2026-10-18", "2026-10-18"))
        self.assertEqual((a["starts_text"], a["closed_text"]), (share.ar_date("2026-09-06"), share.ar_date("2026-10-18")))
        self.assertEqual(a["totals"]["points"], 6)
        self.assertEqual(d["archives"][0]["totals"]["points"], 0)

    def test_one_archive_with_the_whole_summary(self):
        w = self.midterm()
        r = self.close()
        a = self.archive(r["archive_id"])
        self.assertEqual((a["name"], a["can_reopen"]), ("الفصل الدراسي", True))
        self.assertEqual(a["summary"]["version"], termend.SNAPSHOT_VERSION)
        self.assertEqual(a["summary"]["classes"][0]["rows"][0]["name"], "سارة")
        self.assertEqual(self.archive(r["archive_id"])["summary"]["totals"], a["totals"])

    def test_the_sheet_of_an_archived_term_and_of_one_class(self):
        w = self.midterm()
        r = self.close()
        every = self.c.get(f"/api/term/archives/{r['archive_id']}/csv")
        self.assertEqual((every.status_code, every.mimetype), (200, "text/csv"))
        rows = [x.split(",") for x in every.data.decode("utf-8-sig").strip().split("\r\n")]
        self.assertEqual({x[1] for x in rows[2:]}, set(P5.NAMES))
        one = self.c.get(f"/api/term/archives/{r['archive_id']}/csv?class=الصف الأول أ").data.decode("utf-8-sig").strip().split("\r\n")
        self.assertEqual(len(one), 2 + 4)
        self.assertEqual(self.c.get(f"/api/term/archives/{r['archive_id']}/csv?class=ب").status_code, 404)

    def test_the_sheet_still_opens_after_the_class_is_gone(self):
        w = self.midterm()
        r = self.close()
        self.api("delete", f"/api/classes/{w['cid']}")
        text = self.c.get(f"/api/term/archives/{r['archive_id']}/csv").data.decode("utf-8-sig")
        self.assertIn("سارة", text)

    def test_the_pages_open_for_the_owner_only(self):
        w = self.midterm()
        r = self.close()
        for url in ("/term", f"/term/{r['archive_id']}"):
            page = self.c.get(url)
            self.assertEqual(page.status_code, 200, url)
            self.assertEqual(page.headers["Cache-Control"], "no-store")
        self.assertIn("الفصل الدراسي", self.c.get(f"/term/{r['archive_id']}").get_data(as_text=True))
        self.assertEqual(self.c.get("/term/999").status_code, 404)
        b = self.second_teacher()
        self.assertEqual(b.get(f"/term/{r['archive_id']}").status_code, 404)
        anon = self.client()
        for url in ("/term", f"/term/{r['archive_id']}"):
            self.assertEqual(anon.get(url).status_code, 302)

    def test_nobody_else_reads_or_changes_an_archive(self):
        w = self.midterm()
        r = self.close()
        aid = r["archive_id"]
        b = self.second_teacher()
        for url in (f"/api/term/archives/{aid}", f"/api/term/archives/{aid}/csv"):
            self.assertEqual(b.get(url).status_code, 404, url)
        self.assertEqual(self.j(b, "post", f"/api/term/archives/{aid}/reopen", {"confirm": True}).status_code, 404)
        d = self.term(c=b)
        self.assertEqual((d["archives"], d["term"]), ([], None))
        anon = self.client()
        for method, url in (("get", "/api/term"), ("get", "/api/term/csv"), ("get", f"/api/term/archives/{aid}"), ("get", f"/api/term/archives/{aid}/csv"),
                            ("post", "/api/term/close"), ("post", f"/api/term/archives/{aid}/reopen")):
            res = anon.get(url) if method == "get" else self.j(anon, method, url, {})
            self.assertEqual(res.status_code, 401, url)
        for url in ("/api/term/close", f"/api/term/archives/{aid}/reopen"):          # no form token
            res = self.c.post(url, json={"confirm": True, "starts": "2027-01-10", "ends": "2027-05-20"})
            self.assertEqual(res.status_code, 403, url)
        self.assertEqual(self.count("SELECT COUNT(*) FROM term_archives"), 1)


# ================================================================ the home screen
class HomeNote(Phase7):
    def note(self, c=None):
        from app import classroom
        with self.app.test_request_context():
            return termend.note(self.app.db, 1, self.today)

    def test_no_note_without_a_term_or_far_from_its_end(self):
        self.assertIsNone(self.note())
        self.set_term()
        for day in (D(2026, 9, 6), D(2026, 10, 18), D(2026, 12, 2)):
            self.today = day
            self.assertIsNone(self.note(), day)

    def test_a_note_in_the_last_two_weeks_and_after_the_end(self):
        self.set_term()
        self.today = D(2026, 12, 3)
        n = self.note()
        self.assertEqual(n["state"], "soon")
        self.assertIn("بعد 14 يومًا", n["text"])
        self.assertEqual(n["url"], "/term")
        self.today = D(2026, 12, 17)
        self.assertIn("اليوم", self.note()["text"])
        self.today = D(2026, 12, 20)
        n = self.note()
        self.assertEqual(n["state"], "ended")
        self.assertIn("قبل 3 أيام", n["text"])

    def test_the_note_shows_on_the_home_screen_and_leads_to_the_page(self):
        self.set_term()
        page = self.c.get("/dashboard").get_data(as_text=True)
        self.assertNotIn('href="/term"', page)
        self.today = D(2026, 12, 20)
        page = self.c.get("/dashboard").get_data(as_text=True)
        self.assertIn('href="/term"', page)
        self.assertIn("انتهى «الفصل الدراسي»", page)

    def test_after_closing_the_note_is_gone(self):
        self.set_term()
        self.today = D(2026, 12, 20)
        self.close(starts="2027-01-10", ends="2027-05-20")
        self.assertIsNone(self.note())


# ================================================================ the pages
class Pages(Phase7):
    def test_the_page_of_the_term_and_its_scripts(self):
        page = self.c.get("/term").get_data(as_text=True)
        for needle in ("js/term-common.js", "js/term.js", "css/term.css", 'id="tm-root"'):
            self.assertIn(needle, page)
        self.assertLess(page.index("js/term-common.js"), page.index("js/term.js"))
        for url in ("/static/js/term-common.js", "/static/js/term.js", "/static/js/term-archive.js", "/static/css/term.css"):
            self.assertEqual(self.c.get(url).status_code, 200, url)

    def test_the_follow_up_pages_link_to_the_end_of_the_term(self):
        for url in ("/points", "/reports"):
            page = self.c.get(url).get_data(as_text=True)
            self.assertIn('href="/term"', page, url)


# ================================================================ a half is rounded up, everywhere
class Rounding(Phase7):
    def test_a_share_of_a_whole_rounds_the_half_up(self):
        for part, whole, want in ((1, 8, 13), (3, 8, 38), (5, 8, 63), (7, 8, 88), (12.5, 20, 63), (152.5, 200, 76), (1, 3, 33), (2, 3, 67), (0, 5, 0), (5, 5, 100), (1, 200, 1), (13, 200, 7)):
            self.assertEqual(textfmt.percent(part, whole), want, (part, whole))
        for whole in (0, None):
            self.assertIsNone(textfmt.percent(3, whole))
        self.assertEqual(textfmt.percent(0, 7), 0)

    def test_the_marks_of_an_exam_say_63_for_12_and_a_half_out_of_20(self):
        w = self.midterm()
        e = self.exam(w["exam"])
        self.assertEqual((e["scores"]["average"], e["scores"]["percent"]), (15.0, 75))
        st = w["students"]
        self.scores(w["exam"], [{"student_id": st["سارة"], "score": 12.5}, {"student_id": st["نورة"], "score": 12.5}])
        self.assertEqual(self.exam(w["exam"])["scores"]["percent"], 63)
        rows = {r["name"]: r for r in self.term()["summary"]["classes"][0]["rows"]}
        self.assertEqual((rows["سارة"]["exam_percent"], rows["نورة"]["exam_percent"]), (63, 63))
        sheet = self.c.get(f"/api/exams/{w['exam']}/scores/csv").data.decode("utf-8-sig")
        self.assertIn(",12.5,63,", sheet)

    def test_one_eighth_of_the_homework_is_13_in_the_summary_and_in_the_report(self):
        w = self.world()
        self.planned(w)
        self.today = MID
        a, b = self.homework(w), self.homework(w, due=self.day(5))
        st = w["students"]
        self.tick(a["id"], [(st["سارة"], "done"), (st["نورة"], "missing"), (st["ليان"], "missing"), (st["مها"], "missing")])
        self.tick(b["id"], [(st[n], "missing") for n in P5.NAMES])
        t = self.term()["summary"]["totals"]
        self.assertEqual((t["homework_done"], t["homework_checked"], t["homework_percent"]), (1, 8, 13))
        self.assertEqual(self.c.get(f"/api/reports/class/{w['cid']}?period=term").get_json()["homework"]["percent"], 13)
        self.assertEqual(self.api("get", f"/api/homework/{a['id']}").get_json()["assignment"]["stats"]["percent"], 25)


# ================================================================ a database of an earlier version
class Upgrade(unittest.TestCase):
    def test_a_database_of_version_5_without_the_archive_gets_it_and_loses_nothing(self):
        with tempfile.TemporaryDirectory() as tmp:
            app = create_app(INSTANCE=tmp, BACKGROUND=False)
            db = app.db
            db.execute("INSERT INTO users(id, email, name, pass_hash, created_at) VALUES (1, 'a@b.co', 'x', 'h', 1)")
            db.execute("INSERT INTO terms(id, user_id, name, starts, ends, created_at) VALUES (1, 1, 'ف', '2026-09-06', '2026-12-17', 1)")
            db.commit()
            db.execute("DROP TABLE term_archives")
            db.commit()
            dbm.init(db)
            dbm.init(db)          # and again: nothing is added twice
            self.assertEqual([r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE name = 'term_archives'")], ["term_archives"])
            self.assertEqual(db.execute("SELECT COUNT(*) FROM terms").fetchone()[0], 1)
            db.close()

    def test_the_archive_follows_its_teacher_and_its_term(self):
        with tempfile.TemporaryDirectory() as tmp:
            app = create_app(INSTANCE=tmp, BACKGROUND=False)
            db = app.db
            db.execute("INSERT INTO users(id, email, name, pass_hash, created_at) VALUES (1, 'a@b.co', 'x', 'h', 1)")
            db.execute("INSERT INTO terms(id, user_id, name, starts, ends, created_at) VALUES (1, 1, 'ف', '2026-09-06', '2026-12-17', 1), (2, 1, 'ف2', '2027-01-10', '2027-05-20', 1)")
            db.execute("INSERT INTO term_archives(id, user_id, term_id, new_term_id, name, starts, ends, orig_ends, closed_on, created_at) VALUES (1, 1, 1, 2, 'ف', 'a', 'b', 'b', 'c', 1)")
            db.commit()
            with self.assertRaises(sqlite3.IntegrityError):          # one archive for a term
                db.execute("INSERT INTO term_archives(user_id, term_id, name, starts, ends, orig_ends, closed_on, created_at) VALUES (1, 1, 'ف', 'a', 'b', 'b', 'c', 1)")
            db.execute("DELETE FROM terms WHERE id = 2")
            self.assertIsNone(db.execute("SELECT new_term_id FROM term_archives").fetchone()[0])          # the archive stays when the term it began goes
            db.execute("DELETE FROM terms WHERE id = 1")
            self.assertEqual(db.execute("SELECT COUNT(*) FROM term_archives").fetchone()[0], 0)
            db.execute("INSERT INTO terms(id, user_id, name, starts, ends, created_at) VALUES (3, 1, 'ف3', '2027-01-10', '2027-05-20', 1)")
            db.execute("INSERT INTO term_archives(user_id, term_id, name, starts, ends, orig_ends, closed_on, created_at) VALUES (1, 3, 'ف', 'a', 'b', 'b', 'c', 1)")
            db.commit()
            db.execute("DELETE FROM users WHERE id = 1")
            self.assertEqual([db.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in ("terms", "term_archives")], [0, 0])
            db.close()


if __name__ == "__main__":
    unittest.main()
