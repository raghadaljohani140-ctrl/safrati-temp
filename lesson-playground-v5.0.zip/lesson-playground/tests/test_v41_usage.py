"""The lesson allowance of a paid plan (version 4.1): every lesson that was READ SUCCESSFULLY is written once in a log of its own, deleting a lesson never
gives its place back, a failed file is never written, and the count starts again only when the next cycle of the subscription begins."""
import re
import sqlite3
import tempfile
import time
import unittest
from urllib.parse import unquote_plus

from app import billing, create_app, db as dbm
from tests import fixtures as F
from tests.test_app import Base
from tests.test_billing import Money

DAY = 86400


class Usage(Base):
    def teacher(self, email="a@example.com", plan="monthly", days=30):
        c = self.client()
        self.register(c, email)
        uid = self.app.db.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone()[0]
        if plan != "free":
            billing.grant_plan(self.app.db, uid, plan, days)          # the same function the manager's «منح باقة» uses
        return c, uid

    def user(self, uid):
        return self.app.db.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()

    def allow(self, uid, now=None):
        return billing.lesson_allowance(self.app.db, self.user(uid), now)

    def up(self, c, data=None, name="cell.pptx"):
        r = self.upload(c, name, data or F.pptx_bytes())
        m = re.search(r"/lessons/(\d+)", r.headers["Location"])
        return int(m.group(1)) if m else None

    def drop(self, c, lid):
        self.assertEqual(self.j(c, "delete", f"/api/lessons/{lid}").status_code, 200)

    def kept(self, uid):
        return self.app.db.execute("SELECT COUNT(*) FROM lessons WHERE user_id = ?", (uid,)).fetchone()[0]

    def logged(self, uid):
        return self.app.db.execute("SELECT COUNT(*) FROM lesson_usage WHERE user_id = ?", (uid,)).fetchone()[0]

    def set_plan_limit(self, code, n):
        self.app.db.execute("UPDATE plans SET max_lessons = ? WHERE code = ?", (n, code))
        self.app.db.commit()


class TheRequestedBehaviour(Usage):
    def test_five_uploaded_three_deleted_still_five_then_six(self):
        c, uid = self.teacher()
        ids = [self.up(c) for _ in range(5)]
        self.assertEqual((self.allow(uid)["used"], self.allow(uid)["limit"]), (5, 30))
        self.assertIn("5 من 30 دروس", c.get("/dashboard").get_data(as_text=True))
        for lid in ids[2:]:                                          # the three NEWEST: SQLite hands their numbers to the next lessons
            self.drop(c, lid)
        self.assertEqual(self.kept(uid), 2)
        self.assertEqual(self.allow(uid)["used"], 5)                 # deleting did not give anything back
        self.assertIn("5 من 30 دروس", c.get("/dashboard").get_data(as_text=True))
        new = self.up(c)
        self.assertIn(new, ids[2:])                                  # the freed number was reused, and the new lesson was still counted as a new one
        self.assertEqual(self.allow(uid)["used"], 6)
        self.assertIn("6 من 30 دروس", c.get("/dashboard").get_data(as_text=True))

    def test_the_count_stays_even_when_every_lesson_is_deleted(self):
        c, uid = self.teacher()
        ids = [self.up(c) for _ in range(4)]
        for lid in ids:
            self.drop(c, lid)
        self.assertEqual(self.kept(uid), 0)
        page = c.get("/dashboard").get_data(as_text=True)
        self.assertIn("4 من 30 دروس", page)
        self.assertIn("لا توجد دروس بعد", page)                       # the list is empty, the usage is not
        self.assertEqual(self.allow(uid)["used"], 4)

    def test_a_file_that_fails_is_not_counted(self):
        c, uid = self.teacher()
        good = self.up(c)
        for name, data in (("short.pptx", F.pptx_bytes(lines=["أ"] * 8, title="و")), ("broken.pdf", b"%PDF-1.4 this is not a pdf at all")):
            lid = self.up(c, data, name)
            row = self.app.db.execute("SELECT status FROM lessons WHERE id = ?", (lid,)).fetchone()
            self.assertEqual(row["status"], "failed", name)
        self.assertEqual(self.kept(uid), 3)                           # the failed files are in her list (she may delete them) ...
        self.assertEqual(self.allow(uid)["used"], 1)                  # ... but only the lesson that was read is counted
        self.assertEqual(self.logged(uid), 1)
        self.drop(c, good)
        self.assertEqual(self.allow(uid)["used"], 1)

    def test_a_refused_file_is_not_counted_either(self):
        c, uid = self.teacher()
        self.assertIsNone(self.up(c, b"hello", "notes.txt"))           # wrong type
        self.assertIsNone(self.up(c, b"", "empty.pdf"))                 # empty
        self.assertEqual((self.kept(uid), self.allow(uid)["used"]), (0, 0))

    def test_reading_the_same_lesson_again_does_not_count_it_again(self):
        c, uid = self.teacher()
        lid = self.up(c)
        for _ in range(3):
            self.assertEqual(self.j(c, "post", f"/api/lessons/{lid}/regenerate").status_code, 200)
        self.assertEqual(self.allow(uid)["used"], 1)
        self.assertEqual(self.j(c, "patch", f"/api/lessons/{lid}", {"title": "عنوان جديد"}).status_code, 200)        # renaming is not a new lesson
        self.assertEqual(self.allow(uid)["used"], 1)

    def test_the_limit_is_reached_by_uploads_and_deleting_does_not_open_it(self):
        self.set_plan_limit("monthly", 3)
        c, uid = self.teacher(days=90)                                  # three cycles: a new one will begin
        ids = [self.up(c) for _ in range(3)]
        self.assertTrue(all(ids))
        r = self.upload(c, "d.pptx", F.pptx_bytes())
        msg = unquote_plus(r.headers["Location"])
        self.assertIn("حد الدروس في دورة اشتراكك (3 دروس)", msg)
        self.assertIn("حذف الدروس لا يعيد", msg)
        self.assertIn("تبدأ دورة جديدة في", msg)
        for lid in ids[:2]:
            self.drop(c, lid)
        r = self.upload(c, "e.pptx", F.pptx_bytes())
        self.assertIn("حد الدروس في دورة اشتراكك", unquote_plus(r.headers["Location"]))         # still closed after deleting two
        self.assertEqual((self.kept(uid), self.allow(uid)["used"], self.allow(uid)["left"]), (1, 3, 0))

    def test_when_the_subscription_ends_with_the_cycle_she_is_told_to_renew(self):
        self.set_plan_limit("monthly", 2)
        c, uid = self.teacher(days=30)                                  # one cycle only
        self.up(c)
        self.up(c)
        msg = unquote_plus(self.upload(c, "d.pptx", F.pptx_bytes()).headers["Location"])
        self.assertIn("حد الدروس في دورة اشتراكك (درسان)", msg)
        self.assertIn("جدّدي اشتراكك", msg)
        self.assertNotIn("تبدأ دورة جديدة", msg)
        self.assertNotIn("تتجدد في", c.get("/dashboard").get_data(as_text=True))

    def test_the_count_starts_again_when_the_next_cycle_begins(self):
        self.set_plan_limit("monthly", 3)
        c, uid = self.teacher()
        for _ in range(3):
            self.up(c)
        self.assertEqual(self.allow(uid)["left"], 0)
        day = 86400
        # the subscription began 31 days ago and the three lessons were read on its first days: the second cycle began a day ago
        self.app.db.execute("UPDATE users SET plan_started = ?, plan_expires = ? WHERE id = ?", (time.time() - 31 * day, time.time() + 60 * day, uid))
        self.app.db.execute("UPDATE lesson_usage SET used_at = ? WHERE user_id = ?", (time.time() - 30 * day, uid))
        self.app.db.commit()
        self.assertEqual((self.allow(uid)["used"], self.allow(uid)["left"]), (0, 3))
        self.assertIsNotNone(self.up(c))
        self.assertEqual(self.allow(uid)["used"], 1)
        self.assertEqual(self.kept(uid), 4)                            # the old lessons are still in her list


class Cycles(Usage):
    def row(self, **kw):
        base = dict(id=1, plan_code="monthly", plan_expires=0, plan_started=0, created_at=0)
        base.update(kw)
        return base

    def test_cycle_bounds_follow_the_day_the_subscription_began(self):
        c, uid = self.teacher()
        t0 = 1_800_000_000.0
        self.app.db.execute("UPDATE users SET plan_started = ?, plan_expires = ? WHERE id = ?", (t0, t0 + 95 * DAY, uid))
        self.app.db.commit()
        u = self.user(uid)
        db = self.app.db
        self.assertEqual(billing.cycle_of(db, u, t0 + 1), (t0, t0 + 30 * DAY))
        self.assertEqual(billing.cycle_of(db, u, t0 + 30 * DAY - 1), (t0, t0 + 30 * DAY))
        self.assertEqual(billing.cycle_of(db, u, t0 + 30 * DAY), (t0 + 30 * DAY, t0 + 60 * DAY))      # the exact moment the new cycle begins
        self.assertEqual(billing.cycle_of(db, u, t0 + 91 * DAY), (t0 + 90 * DAY, t0 + 120 * DAY))
        # a yearly plan counts a whole year
        db.execute("UPDATE users SET plan_code = 'yearly', plan_expires = ? WHERE id = ?", (t0 + 400 * DAY, uid))
        db.commit()
        self.assertEqual(billing.cycle_of(db, self.user(uid), t0 + 10 * DAY), (t0, t0 + 365 * DAY))

    def test_usage_is_counted_inside_the_cycle_only(self):
        c, uid = self.teacher()
        t0 = 1_800_000_000.0
        db = self.app.db
        db.execute("UPDATE users SET plan_started = ?, plan_expires = ? WHERE id = ?", (t0, t0 + 90 * DAY, uid))
        for i, at in enumerate((2, 3, 20, 31, 45)):
            db.execute("INSERT INTO lesson_usage(user_id, lesson_id, file_key, used_at) VALUES (?, NULL, ?, ?)", (uid, f"k{i}", t0 + at * DAY))
        db.commit()
        self.assertEqual(self.allow(uid, t0 + 29 * DAY)["used"], 3)
        self.assertEqual(self.allow(uid, t0 + 50 * DAY)["used"], 2)             # days 31 and 45 are in the second cycle, the three first lessons are not
        self.assertEqual(self.allow(uid, t0 + 59 * DAY)["used"], 2)
        self.assertEqual(self.allow(uid, t0 + 61 * DAY)["used"], 0)
        # the day the next cycle begins is shown only while the subscription still runs
        self.assertEqual(self.allow(uid, t0 + 10 * DAY)["renews"], t0 + 30 * DAY)
        self.assertEqual(self.allow(uid, t0 + 70 * DAY)["renews"], None)          # the subscription ends at day 90, exactly when that cycle ends: no new cycle comes

    def test_renewing_early_does_not_restart_the_count(self):
        self.set_plan_limit("monthly", 5)
        c, uid = self.teacher()
        for _ in range(4):
            self.up(c)
        before = self.user(uid)
        billing.grant_plan(self.app.db, uid, "monthly", 30)               # the manager lengthens the running plan
        req = self.app.db.execute("INSERT INTO subscription_requests(user_id, plan_code, period, amount, created_at) VALUES (?,?,?,?,?)", (uid, "monthly", "month", 2900, time.time()))
        billing.confirm_request(self.app.db, self.app.db.execute("SELECT * FROM subscription_requests WHERE id = ?", (req.lastrowid,)).fetchone())      # and a payment is confirmed
        after = self.user(uid)
        self.assertEqual(after["plan_started"], before["plan_started"])
        self.assertGreater(after["plan_expires"], before["plan_expires"] + 55 * DAY)
        self.assertEqual(self.allow(uid)["used"], 4)

    def test_a_new_subscription_after_the_old_one_ended_is_a_new_cycle(self):
        c, uid = self.teacher()
        for _ in range(3):
            self.up(c)
        db = self.app.db
        db.execute("UPDATE users SET plan_expires = ?, plan_started = ? WHERE id = ?", (time.time() - 5 * DAY, time.time() - 35 * DAY, uid))
        db.execute("UPDATE lesson_usage SET used_at = ?", (time.time() - 20 * DAY,))
        db.commit()
        self.assertFalse(self.allow(uid)["cycle"])                           # it ended: the free plan again
        billing.grant_plan(db, uid, "monthly", 30)                          # a new subscription starts today
        self.assertEqual((self.allow(uid)["cycle"], self.allow(uid)["used"]), (True, 0))

    def test_a_plan_set_by_hand_without_dates_still_has_a_cycle(self):
        c, uid = self.teacher(plan="free")
        self.up(c)
        self.app.db.execute("UPDATE users SET plan_code = 'monthly' WHERE id = ?", (uid,))            # what `manage.py set-plan` does: no start, no end
        self.app.db.commit()
        a = self.allow(uid)
        self.assertTrue(a["cycle"])
        self.assertEqual((a["used"], a["limit"]), (1, 30))


class FreePlanAndHolding(Usage):
    def test_the_free_plan_still_counts_the_lessons_she_keeps(self):
        c, uid = self.teacher(plan="free")
        ids = [self.up(c) for _ in range(3)]
        a = self.allow(uid)
        self.assertEqual((a["cycle"], a["used"], a["limit"], a["left"]), (False, 3, 3, 0))
        r = self.upload(c, "x.pptx", F.pptx_bytes())
        self.assertIn("احذفي درسًا قديمًا", unquote_plus(r.headers["Location"]))
        self.drop(c, ids[0])
        self.assertEqual(self.allow(uid)["left"], 1)                          # as before: on the free plan a deleted lesson gives its place back
        self.assertIsNotNone(self.up(c))
        self.assertNotIn("تتجدد في", c.get("/dashboard").get_data(as_text=True))

    def test_an_ended_subscription_is_the_free_plan_again(self):
        c, uid = self.teacher()
        for _ in range(4):
            self.up(c)
        self.app.db.execute("UPDATE users SET plan_expires = ? WHERE id = ?", (time.time() - 1, uid))
        self.app.db.commit()
        a = self.allow(uid)
        self.assertEqual((a["cycle"], a["used"], a["limit"]), (False, 4, 3))
        self.assertIn("عدتِ إلى الباقة المجانية", c.get("/dashboard").get_data(as_text=True))

    def test_files_being_read_hold_their_place(self):
        self.set_plan_limit("monthly", 3)
        c, uid = self.teacher()
        self.up(c)
        self.up(c)
        db = self.app.db
        db.execute("INSERT INTO lessons(user_id, title, original_name, stored_name, kind, status, created_at, updated_at) VALUES (?, 't', 'a.pdf', 'busy-1.pdf', 'pdf', 'processing', ?, ?)", (uid, time.time(), time.time()))
        db.commit()
        a = self.allow(uid)
        self.assertEqual((a["used"], a["left"]), (2, 0))                       # two read + one being read = all three places
        r = self.upload(c, "z.pptx", F.pptx_bytes())
        self.assertIn("حد الدروس في دورة اشتراكك", unquote_plus(r.headers["Location"]))

    def test_a_file_stuck_for_long_holds_nothing_and_a_lesson_read_again_is_not_held_twice(self):
        self.set_plan_limit("monthly", 3)
        c, uid = self.teacher()
        lid = self.up(c)
        db = self.app.db
        old = time.time() - 3 * 3600
        db.execute("INSERT INTO lessons(user_id, title, original_name, stored_name, kind, status, created_at, updated_at) VALUES (?, 't', 'a.pdf', 'stuck.pdf', 'pdf', 'processing', ?, ?)", (uid, old, old))
        db.execute("UPDATE lessons SET status = 'processing' WHERE id = ?", (lid,))          # a lesson that is being read AGAIN (it is already in the log)
        db.commit()
        a = self.allow(uid)
        self.assertEqual((a["used"], a["left"]), (1, 2))


class LogLifecycle(Usage):
    def test_deleting_the_account_removes_her_log_and_only_hers(self):
        a, ua = self.teacher("a@example.com")
        b, ub = self.teacher("b@example.com")
        for _ in range(2):
            self.up(a)
        self.up(b)
        self.assertEqual((self.logged(ua), self.logged(ub)), (2, 1))
        self.assertEqual(self.j(a, "post", "/api/me/delete", {"password": "Teacher-pass-1"}).status_code, 200)
        self.assertEqual((self.logged(ua), self.logged(ub)), (0, 1))
        self.assertEqual(self.allow(ub)["used"], 1)

    def test_the_log_keeps_no_title_and_no_text(self):
        c, uid = self.teacher()
        self.up(c)
        cols = [r[1] for r in self.app.db.execute("PRAGMA table_info(lesson_usage)")]
        self.assertEqual(sorted(cols), sorted(["id", "user_id", "lesson_id", "file_key", "used_at"]))

    def test_a_lesson_deleted_while_it_is_being_read_is_not_counted(self):
        c, uid = self.teacher()
        lid = self.up(c)
        lesson = dict(self.app.db.execute("SELECT * FROM lessons WHERE id = ?", (lid,)).fetchone())
        self.drop(c, lid)
        self.app.db.execute("DELETE FROM lesson_usage WHERE user_id = ?", (uid,))
        billing.count_lesson(self.app.db, lesson)                       # the reading ends after she deleted the lesson
        self.app.db.commit()
        self.assertEqual(self.logged(uid), 0)

    def test_two_lessons_with_the_same_number_are_two_lessons(self):
        c, uid = self.teacher()
        first = self.up(c)
        self.drop(c, first)
        second = self.up(c)
        self.assertEqual(first, second)                                   # the very same number
        self.assertEqual(self.logged(uid), 2)


class ManagerPage(Money):
    def test_subscriber_page_shows_kept_and_used(self):
        adm = self.admin()
        t = self.client()
        self.register(t)
        uid = self.uid("a@example.com")
        billing.grant_plan(self.app.db, uid, "monthly", 30)
        ids = []
        for _ in range(3):
            r = self.upload(t, "cell.pptx", F.pptx_bytes())
            ids.append(int(re.search(r"/lessons/(\d+)", r.headers["Location"]).group(1)))
        self.assertEqual(self.j(t, "delete", f"/api/lessons/{ids[0]}").status_code, 200)
        page = adm.get(f"/admin/subscriptions/{uid}").get_data(as_text=True)
        self.assertRegex(page, r"دروسها المحفوظة</dt><dd>2</dd>")
        self.assertRegex(page, r"المستهلك من حد الدروس</dt><dd>3 من 30 في الدورة الحالية")


class OldDatabases(unittest.TestCase):
    def make(self, d):
        conn = dbm.connect(d + "/x.db")
        dbm.init(conn)
        conn.execute("INSERT INTO users(email, name, pass_hash, created_at) VALUES ('t@x.com', 't', 'h', 1)")
        for i, st in enumerate(("ready", "ready", "failed", "processing", "ready"), start=1):
            conn.execute("INSERT INTO lessons(id, user_id, title, original_name, stored_name, kind, status, created_at, updated_at) VALUES (?,1,'t','a.pdf',?, 'pdf', ?, ?, ?)",
                         (i, f"file{i}.pdf", st, 1000.0 + i, 1000.0 + i))
        conn.commit()
        return conn

    def test_lessons_that_are_already_there_are_written_once_and_nothing_else_changes(self):
        with tempfile.TemporaryDirectory() as d:
            conn = self.make(d)
            conn.execute("DROP TABLE lesson_usage")                         # a database made by version 4.0 has no such table
            conn.commit()
            before = [tuple(r) for r in conn.execute("SELECT * FROM lessons ORDER BY id")]
            dbm.init(conn)
            rows = conn.execute("SELECT lesson_id, file_key, used_at FROM lesson_usage ORDER BY lesson_id").fetchall()
            self.assertEqual([(r[0], r[1], r[2]) for r in rows], [(1, "file1.pdf", 1001.0), (2, "file2.pdf", 1002.0), (5, "file5.pdf", 1005.0)])      # only those that were read
            self.assertEqual([tuple(r) for r in conn.execute("SELECT * FROM lessons ORDER BY id")], before)            # the lessons were not touched
            dbm.init(conn)
            dbm.init(conn)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM lesson_usage").fetchone()[0], 3)                       # running it again adds nothing
            conn.execute("DELETE FROM lessons WHERE id = 2")
            conn.commit()
            dbm.init(conn)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM lesson_usage").fetchone()[0], 3)                       # a deleted lesson stays counted and is not added twice

    def test_the_usage_log_is_not_tied_to_the_lessons_table(self):
        with tempfile.TemporaryDirectory() as d:
            conn = self.make(d)
            fks = [(r[2], r[3]) for r in conn.execute("PRAGMA foreign_key_list(lesson_usage)")]
            self.assertEqual(fks, [("users", "user_id")])                      # only the account owns the rows: no lesson can remove one


if __name__ == "__main__":
    unittest.main()
