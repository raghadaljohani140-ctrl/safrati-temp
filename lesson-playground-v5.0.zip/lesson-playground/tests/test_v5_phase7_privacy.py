"""Version 5, phase 7: what the site lets out and what it keeps. Three promises, each tried against the real code with a made-up network:

1. the smart reader (the only thing the site ever calls outside) is sent the text of a lesson and nothing about the teacher, her students, her classes or her school;
2. the site opens no other connection at all, whatever a teacher does (the backup page included);
3. deleting an account takes everything of hers, in every table and on the disk, and nothing of anyone else's, and the same e-mail can start again from nothing."""
import io
import json
import os
import re
import time
import zipfile
from unittest import mock

from app import aiq, backup, auth
from app import db as dbm
from tests import files5 as X
from tests import test_v5_phase5 as P5
from tests import test_v5_phase7_backup as B7

KEY = "test-key-not-a-real-key-0123456789"
PASSWORD = "Teacher-pass-1"
TEACHER = "نوف العتيبي"
SCHOOL = "مدرسة الأمل"
PHONE_AS_TYPED, PHONE_STORED = "0501234567", "966501234567"
PREFIX = "أعدي نحو 24 سؤالًا متنوعًا من هذا الدرس:\n\n"
LETTERS = "ء-ي"


def appears(word, text):
    """A short name counts as present when it stands as a word of its own (so «مها» is not found inside «مهارة»); anything longer is looked for as it is."""
    if len(word) >= 7 or not re.fullmatch(f"[{LETTERS}]+", word):
        return word in text
    return re.search(f"(?<![{LETTERS}]){re.escape(word)}(?![{LETTERS}])", text) is not None


def text_of(raw):
    zf = zipfile.ZipFile(io.BytesIO(raw))
    return "\n".join(zf.read(n).decode("utf-8") for n in zf.namelist())


class Wire:
    """Everything that tries to leave the server while a test runs. A request the site makes with urllib is written down and answered with a made-up reply (nothing is sent);
    a socket or a name lookup opened by anything else is written down and refused."""

    class Reply:
        def __init__(self, data):
            self.data = data

        def __enter__(self):
            return self

        def __exit__(self, *exc):
            return False

        def read(self):
            return self.data

    def __init__(self):
        self.requests, self.sockets = [], []

    def urlopen(self, req, *args, **kw):
        self.requests.append({"url": req.full_url, "method": req.get_method(), "headers": {k.lower(): v for k, v in req.header_items()}, "body": req.data or b""})
        return self.Reply(json.dumps({"content": [{"type": "text", "text": "[]"}], "usage": {"input_tokens": 50, "output_tokens": 5}}).encode())

    def refuse(self, *args, **kw):
        self.sockets.append(args)
        raise OSError("no connection is allowed in this test")

    def install(self, case):
        for target, fake in (("urllib.request.urlopen", self.urlopen), ("socket.socket.connect", self.refuse), ("socket.create_connection", self.refuse), ("socket.getaddrinfo", self.refuse)):
            p = mock.patch(target, fake)
            p.start()
            case.addCleanup(p.stop)
        return self

    def sent(self, i=0):
        """What went out in request number i: the address, the headers, the body read back as JSON, and the body as it was sent."""
        r = self.requests[i]
        return r["url"], r["headers"], json.loads(r["body"].decode("utf-8")), r["body"]


class Private(B7.Backup):
    def setUp(self):
        super().setUp()
        self.wire = Wire().install(self)
        self.db = self.app.db
        self.db.execute("UPDATE users SET name = ?, plan_code = 'monthly', plan_expires = ? WHERE id = 1", (TEACHER, time.time() + 30 * 86400))          # (a paid plan: many lessons below)
        self.db.commit()

    def reader_on(self, c=None):
        """The server has its key and she has agreed: the paid reader may be called for her."""
        self.app.cfg.ai_provider, self.app.cfg.anthropic_key = "claude", KEY
        self.assertEqual(self.api("post", "/api/me/consent", {"ai_consent": True}, c).status_code, 200)

    def about_her(self):
        """Everything that says who she is and who her students are: none of it may leave the server with a lesson."""
        return [TEACHER, "a@example.com", PASSWORD, SCHOOL, "الصف الأول أ", *P5.NAMES]

    def assert_clean(self, body, forbidden):
        text = json.dumps(body, ensure_ascii=False)
        for word in forbidden:
            self.assertFalse(appears(word, text), word)

    def assert_lesson_is_neutral(self, text):
        for word in self.about_her():
            self.assertFalse(appears(word, text), f"(the lesson of the test must not contain «{word}» itself, or the check below proves nothing)")


# ================================================================ 1. the smart reader
class SmartReader(Private):
    def test_a_lesson_goes_out_as_its_own_text_and_nothing_else(self):
        self.rich(close=False)          # a class with four students, a school header, points, homework, an exam: a teacher with a lot of names around her
        self.wire.requests.clear()
        self.reader_on()
        lid = self.lesson(name="cell2.pptx")
        self.assertEqual(len(self.wire.requests), 1, "one lesson read, one call")
        url, headers, body, raw = self.wire.sent()
        text = self.db.execute("SELECT text FROM lessons WHERE id = ?", (lid,)).fetchone()["text"]
        self.assert_lesson_is_neutral(text)
        self.assertEqual(url, "https://api.anthropic.com/v1/messages")
        self.assertEqual(self.wire.requests[0]["method"], "POST")
        self.assertEqual(set(headers), {"x-api-key", "anthropic-version", "content-type"})          # nothing about her in the headers either: no cookie, no address, no user agent
        self.assertEqual(headers["x-api-key"], KEY)
        self.assertEqual(set(body), {"model", "max_tokens", "thinking", "system", "messages"})
        self.assertEqual(body["system"], aiq.ClaudeProvider.RULES)
        self.assertEqual(body["messages"], [{"role": "user", "content": PREFIX + text[:aiq.aimodel.MAX_TEXT_CHARS]}])          # the file's text, and the fixed sentence in front of it
        self.assert_clean(body, self.about_her())
        self.assertNotIn(KEY, json.dumps(body))          # the key travels in its header only
        for ident in (b'"user_id"', b'"student_id"', b'"class_id"', b'"email"', b'"name"', b'"lesson_id"'):
            self.assertNotIn(ident, raw)

    def test_the_exam_builder_sends_the_text_of_the_lessons_and_nothing_else(self):
        w = self.world()
        lid = self.lesson()
        e = self.new_exam(w, uploads=[lid], lessons=w["lessons"][:2])
        self.assertEqual(self.api("patch", f"/api/exams/{e['id']}", {"header": SCHOOL}).status_code, 200)
        self.reader_on()
        self.wire.requests.clear()
        r = self.api("post", f"/api/exams/{e['id']}/more", {"kind": "mcq"})
        self.assertIn(r.status_code, (200, 502), r.get_data(as_text=True))          # (the made-up reply has no usable question: what matters is what was sent)
        self.assertEqual(len(self.wire.requests), 1)
        url, headers, body, raw = self.wire.sent()
        self.assertEqual(url, aiq.ClaudeProvider.URL)
        self.assertEqual(set(headers), {"x-api-key", "anthropic-version", "content-type"})
        self.assertEqual(len(body["messages"]), 1)
        content = body["messages"][0]["content"]
        self.assertTrue(content.startswith(PREFIX))
        texts = [self.db.execute("SELECT text FROM lessons WHERE id = ?", (lid,)).fetchone()["text"]] + \
                [self.db.execute("SELECT text FROM book_lessons WHERE id = ?", (b,)).fetchone()["text"] for b in w["lessons"][:2]]
        rest = content[len(PREFIX):]
        for t in texts:
            self.assertTrue(t.strip())
            self.assert_lesson_is_neutral(t)
            self.assertIn(t.strip(), rest)          # every lesson of the exam is there ...
            rest = rest.replace(t.strip(), "", 1)
        self.assertEqual(rest.strip(), "")          # ... and there is nothing else: not the exam, its header, its class, its marks
        self.assert_clean(body, self.about_her())
        self.assertNotIn(KEY, json.dumps(body))

    def test_nothing_goes_out_unless_the_server_has_a_key_and_she_agreed_and_the_manager_allows_it(self):
        self.app.cfg.ai_provider, self.app.cfg.anthropic_key = "claude", KEY
        self.lesson()          # the server is ready, she has not agreed
        self.assertEqual(self.wire.requests, [])
        self.assertEqual(self.api("post", "/api/me/consent", {"ai_consent": True}).status_code, 200)
        self.app.cfg.anthropic_key = ""
        self.lesson()          # she agreed, the server has no key
        self.assertEqual(self.wire.requests, [])
        self.app.cfg.anthropic_key, self.app.cfg.ai_provider = KEY, "offline"
        self.lesson()          # a key, but the site is set to the free reader
        self.assertEqual(self.wire.requests, [])
        self.app.cfg.ai_provider = "claude"
        dbm.put_setting(self.db, "ai_enabled", "0")
        self.lesson()          # the manager's own switch is off
        self.assertEqual(self.wire.requests, [])
        dbm.put_setting(self.db, "ai_enabled", "1")
        self.assertEqual(self.api("post", "/api/me/consent", {"ai_consent": False}).status_code, 200)
        self.lesson()          # she took her agreement back
        self.assertEqual(self.wire.requests, [])
        self.assertEqual(self.api("post", "/api/me/consent", {"ai_consent": True}).status_code, 200)
        self.lesson()
        self.assertEqual(len(self.wire.requests), 1)          # everything on: now it goes, once

    def test_the_exam_builder_needs_the_same_agreement(self):
        w = self.world()
        e = self.new_exam(w, lessons=w["lessons"][:2])
        more = lambda: self.api("post", f"/api/exams/{e['id']}/more", {"kind": "mcq"}).status_code
        self.app.cfg.ai_provider, self.app.cfg.anthropic_key = "claude", KEY
        self.assertEqual(more(), 409)          # the site is ready, she has not agreed
        self.assertEqual(self.api("post", "/api/me/consent", {"ai_consent": True}).status_code, 200)
        dbm.put_setting(self.db, "ai_enabled", "0")
        self.assertEqual(more(), 409)          # the manager's switch is off
        dbm.put_setting(self.db, "ai_enabled", "1")
        self.app.cfg.anthropic_key = ""
        self.assertEqual(more(), 409)          # the site has no key
        self.app.cfg.anthropic_key, self.app.cfg.ai_provider = KEY, "offline"
        self.assertEqual(more(), 409)          # the site is set to the free reader
        self.assertEqual(self.wire.requests, [])
        self.app.cfg.ai_provider = "claude"
        self.assertIn(more(), (200, 502))
        self.assertEqual(len(self.wire.requests), 1)

    def test_a_lesson_made_from_the_book_goes_out_as_its_text_only(self):
        w = self.midterm()
        self.reader_on()
        self.wire.requests.clear()
        item = self.plan(w["cid"], w["sid"])["items"][2]
        r = self.api("post", f"/api/plan/{item['id']}/lesson")
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        self.assertEqual(len(self.wire.requests), 1)
        _, _, body, _ = self.wire.sent()
        self.assertEqual(len(body["messages"]), 1)
        self.assertTrue(body["messages"][0]["content"].startswith(PREFIX))
        self.assertIn(P5.LESSON3.strip()[:80], body["messages"][0]["content"])
        self.assert_clean(body, self.about_her())

    def test_the_sentence_she_agrees_to_says_what_is_true(self):
        page = lambda: self.c.get("/dashboard").get_data(as_text=True)
        self.assertIn("غير مفعّل الآن", page())          # the site has no key: it says so
        self.assertNotIn("مفعّل في الموقع الآن", page())
        self.reader_on()
        self.assertIn("مفعّل في الموقع الآن", page())          # the site has a key: it says so, and what is sent
        self.assertIn("يُرسل نص الدرس وحده", page())
        self.assertNotIn("غير مفعّل الآن", page())

    def test_the_backup_never_calls_the_reader(self):
        self.rich()
        self.reader_on()
        self.wire.requests.clear()
        raw = self.download()
        self.preview(raw)
        self.restore(raw)
        self.assertEqual(self.undo().status_code, 200)
        self.assertEqual(self.wire.requests, [])          # (a restored lesson is not read again: it comes back with its questions)


# ================================================================ 2. no other connection
class NoOtherConnection(Private):
    def test_every_page_of_a_teacher_with_everything_opens_no_connection(self):
        self.rich()          # the class, the book, the plan, points, homework, an exam, a lesson with its deck and results, the term closed
        b = self.second_teacher()
        self.rich(c=b, names=B7.SECOND, klass="الصف الثاني")
        pages = sorted({r.rule for r in self.app.url_map.iter_rules() if "GET" in r.methods and not r.arguments and not r.rule.startswith("/static")})
        self.assertGreater(len(pages), 30)
        for who in (self.c, b):
            for page in pages:
                self.assertLess(who.get(page).status_code, 500, page)
        raw = self.download()
        self.preview(raw)
        self.restore(raw)
        self.assertEqual(self.undo().status_code, 200)
        self.assertEqual(self.wire.requests, [], "the site called an address")
        self.assertEqual(self.wire.sockets, [], "the site opened a connection")

    def test_with_the_reader_on_the_only_address_is_the_readers(self):
        self.rich(close=False)
        self.reader_on()
        for _ in range(2):
            self.lesson()
        self.assertEqual(len(self.wire.requests), 2)
        self.assertEqual({r["url"] for r in self.wire.requests}, {"https://api.anthropic.com/v1/messages"})
        self.assertEqual(self.wire.sockets, [])


# ================================================================ what the file she downloads must not carry
class FileHasNoSecrets(Private):
    def test_no_secret_of_the_site_and_no_way_in_to_the_account_is_in_the_file(self):
        self.app.cfg.anthropic_key = KEY
        self.rich()
        phone = self.client()
        auth.register_limit.hits.clear()
        auth.register_day_limit.hits.clear()
        self.assertEqual(self.register(phone, email=PHONE_AS_TYPED, name="هالة").status_code, 302)
        _, tables = self.unpack(self.download())
        for t, rows in tables.items():
            for r in rows:
                self.assertNotIn("user_id", r, t)          # (no number of her account, and no name of a file on the disk of the server, in any row)
                self.assertNotIn("stored_name", r, t)
        for c, who in ((self.c, "a@example.com"), (phone, PHONE_AS_TYPED)):
            blob = text_of(self.download(c=c))
            for secret in (KEY, self.app.cfg.secret, who, PHONE_AS_TYPED, PHONE_STORED, PASSWORD, "a@example.com", "pbkdf2", "scrypt", "csrf", "pass_hash"):
                self.assertNotIn(secret, blob, f"{secret} in the file of {who}")

    def test_the_file_of_one_teacher_has_nothing_of_another(self):
        self.rich()
        b = self.second_teacher()
        self.rich(c=b, names=B7.SECOND, klass="الصف الثاني")
        mine, theirs = self.download(), self.download(c=b)
        _, mt = self.unpack(mine)
        _, tt = self.unpack(theirs)
        self.assertEqual({r["name"] for r in mt["students"]}, set(P5.NAMES))
        self.assertEqual({r["name"] for r in tt["students"]}, set(B7.SECOND))
        self.assertEqual([r["name"] for r in mt["classes"]], ["الصف الأول أ"])
        self.assertEqual([r["name"] for r in tt["classes"]], ["الصف الثاني"])
        for word in ("الصف الثاني", "b@example.com"):
            self.assertNotIn(word, text_of(mine), word)
        for word in ("الصف الأول أ", "a@example.com", TEACHER):
            self.assertNotIn(word, text_of(theirs), word)


# ================================================================ 3. deleting an account
class Deletion(Private):
    def files(self):
        return sorted(os.listdir(self.app.cfg.upload_dir))

    def stored(self, uid):
        names = [r[0] for r in self.db.execute("SELECT stored_name FROM lessons WHERE user_id = ? UNION ALL SELECT stored_name FROM books WHERE user_id = ?", (uid, uid))]
        return sorted(n for n in names if n)

    def user_tables(self):
        return [t for t in self.every_table() if "user_id" in [r[1] for r in self.db.execute(f"PRAGMA table_info({t})")]]

    def rows(self, table, uid):
        return [tuple(r) for r in self.db.execute(f"SELECT * FROM {table} WHERE user_id = ? ORDER BY rowid", (uid,))]

    def furnish(self, c, names, klass):
        """A teacher with every kind of thing the site keeps for her, files included, and a safety copy of her own account kept inside the database."""
        self.rich(c=c, names=names, klass=klass)
        self.restore(self.download(c=c), c=c)          # (this is what makes the safety copy)
        self.assertIn(self.post_book("math.docx", X.book_docx(True), c=c).status_code, (200, 201))          # a book file on the disk

    def delete(self, c, password=PASSWORD, status=200):
        r = self.api("post", "/api/me/delete", {"password": password}, c)
        self.assertEqual(r.status_code, status, r.get_data(as_text=True))

    def check(self, gone, gone_email):
        keeper_email = "a@example.com" if gone_email == "b@example.com" else "b@example.com"
        ug, uk = self.uid_of(gone_email), self.uid_of(keeper_email)
        tables = self.user_tables()
        for t in backup.ORDER:
            self.assertIn(t, tables)
        self.assertIn("user_backups", tables)
        theirs_before = {t: self.rows(t, uk) for t in tables}
        files_gone, files_kept = self.stored(ug), self.stored(uk)
        self.assertTrue(files_gone and files_kept, "the accounts of the test must have files on the disk")
        for t in ("lessons", "books", "user_backups", "students", "results", "exam_scores", "term_archives", "plan_items", "points", "assignments"):
            self.assertTrue(self.rows(t, ug) and self.rows(t, uk), f"(both accounts of the test must have rows in {t})")
        globals_before = {t: [tuple(r) for r in self.db.execute(f"SELECT * FROM {t} ORDER BY rowid")] for t in ("plans", "settings", "expenses")}
        self.delete(gone)
        for t in tables:
            self.assertEqual(self.rows(t, ug), [], f"rows of the deleted account are left in {t}")
            self.assertEqual(self.rows(t, uk), theirs_before[t], f"the other account changed in {t}")
        self.assertEqual(self.count("SELECT COUNT(*) FROM users WHERE id = ?", ug), 0)
        self.assertEqual([tuple(r) for r in self.db.execute("PRAGMA foreign_key_check")], [])
        for t, rows in globals_before.items():
            self.assertEqual([tuple(r) for r in self.db.execute(f"SELECT * FROM {t} ORDER BY rowid")], rows, t)
        for n in files_gone:
            self.assertFalse((self.app.cfg.upload_dir / n).exists(), n)
        for n in files_kept:
            self.assertTrue((self.app.cfg.upload_dir / n).is_file(), n)
        self.assertEqual(self.files(), files_kept, "a file nobody owns is left on the disk")
        # she is out: the old session is dead, the password does not work, and the e-mail is free again
        self.assertEqual(gone.get("/api/backup").status_code, 401)
        self.assertEqual(gone.get("/api/backup/download").status_code, 401)
        c2 = self.client()
        bad = c2.post("/login", data={"_csrf": self.token(c2), "email": gone_email, "password": PASSWORD})
        self.assertEqual(bad.status_code, 400)
        return ug

    def test_deleting_the_second_account_takes_all_of_it_and_none_of_the_first(self):
        self.furnish(self.c, P5.NAMES, "الصف الأول أ")
        b = self.second_teacher()
        self.furnish(b, B7.SECOND, "الصف الثاني")
        ub = self.check(b, "b@example.com")
        # the same e-mail signs up again and is handed the same number: nothing of the old account may be waiting under it
        auth.register_limit.hits.clear()
        auth.register_day_limit.hits.clear()
        again = self.client()
        self.assertEqual(self.register(again, email="b@example.com", name="جديدة").status_code, 302)
        self.assertEqual(self.uid_of("b@example.com"), ub)
        info = again.get("/api/backup").get_json()
        self.assertEqual(sum(info["current"].values()), 0, info["current"])
        self.assertIsNone(info["safety"])
        manifest, tables = self.unpack(again.get("/api/backup/download").data)
        self.assertEqual(manifest["rows"], 0)
        self.assertEqual(self.files(), self.stored(1))

    def test_deleting_the_first_account_takes_all_of_it_and_none_of_the_second(self):
        self.furnish(self.c, P5.NAMES, "الصف الأول أ")
        b = self.second_teacher()
        self.furnish(b, B7.SECOND, "الصف الثاني")
        self.check(self.c, "a@example.com")
        self.assertEqual(self.count("SELECT COUNT(*) FROM students WHERE name IN (?,?,?,?)", *P5.NAMES), 0)
        self.assertEqual(self.count("SELECT COUNT(*) FROM students WHERE name IN (?,?,?,?)", *B7.SECOND), 4)

    def test_a_wrong_password_deletes_nothing_and_a_file_that_is_already_gone_does_not_stop_the_deletion(self):
        self.furnish(self.c, P5.NAMES, "الصف الأول أ")
        before = self.snapshot()
        files = self.files()
        self.delete(self.c, password="not-her-password-1", status=400)
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(self.files(), files)
        for n in self.stored(1)[:2]:          # a file already missing (a disk cleaned by hand, a lesson that came back from a backup after its file was deleted)
            (self.app.cfg.upload_dir / n).unlink()
        self.delete(self.c)
        for t in self.user_tables():
            self.assertEqual(self.rows(t, 1), [], t)
        self.assertEqual(self.files(), [])
