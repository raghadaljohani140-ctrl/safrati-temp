import io
import json
import re
import unittest

from app import aiq, extract, meta
from tests import fixtures as F
from tests.test_app import Base

HEADER = "المادة: العلوم العامة الصف: الأول الثانوي المرحلة: الثانوية"


def damaged_pdf(lines):
    """A PDF like the teacher's: every word its own text object, placed left-to-right (so the words of a line come out reversed), with ى / ھ in the middle of words."""
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.pdfgen import canvas
    try:
        pdfmetrics.getFont("DJ")
    except KeyError:
        pdfmetrics.registerFont(TTFont("DJ", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"))
    buf = io.BytesIO()
    cv = canvas.Canvas(buf, pagesize=(595, 842))
    y = 780
    for ln in lines:
        x = 40
        for w in reversed(ln.split()):
            w = "".join("ى" if c == "ي" and i + 1 < len(w) else "ھ" if c == "ه" and i + 1 < len(w) else c for i, c in enumerate(w))
            cv.setFont("DJ", 14)
            cv.drawString(x, y, w[::-1])
            x += pdfmetrics.stringWidth(w, "DJ", 14) + 8
        y -= 30
    cv.save()
    return buf.getvalue()


BODY = ["مقدمة في مفهوم الطاقة والتحول العالمي والمصادر المتجددة.",
        "الطاقة المتجددة هي الطاقة التي تأتي من مصادر طبيعية لا تنفد مثل الشمس والرياح."]


def line_pdf(lines):
    """A PDF whose lines are written as whole runs in reading order: the reader hands them back with every line backwards, ي where the text has ى, and no easy common words."""
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.pdfgen import canvas
    try:
        pdfmetrics.getFont("DJ")
    except KeyError:
        pdfmetrics.registerFont(TTFont("DJ", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"))
    buf = io.BytesIO()
    cv = canvas.Canvas(buf, pagesize=(595, 842))
    y = 780
    for ln in lines:
        cv.setFont("DJ", 12)
        cv.drawString(30, y, ln)
        y -= 24
    cv.save()
    return buf.getvalue()


class TextTests(unittest.TestCase):
    def test_a_pdf_whose_lines_come_out_backwards_is_turned_back(self):
        for lines in (["اتفقت شرائع جميع الرسل من آدم إلي محمد عليهم الصلاة والسلام علي دعوة الناس إلي توحيد الله.", "الإيمان بالله هو أول أركان الإيمان وأعظمها في الدين والعقيدة الصحيحة."],
                      ["الأنبياء والمرسلون الكرام عليهم الصلاة والسلام.", "المعجزات والكتب السماوية والشرائع المنزلة.", "الاعتقاد الصحيح والعبادة الخالصة والأخلاق الحسنة.", "الدعوة الصادقة والتوحيد الخالص والإخلاص التام."]):
            text = extract.from_pdf(line_pdf(lines))
            self.assertIn(lines[0].split()[0] + " " + lines[0].split()[1], text)
            self.assertNotIn("ةوعد", text)
            self.assertNotIn(lines[0][::-1][:12], text)


    def test_letters_that_do_not_join_become_normal_letters(self):
        broken = "أساسىات المفھوم والأكادىمىة کیف على إلى مستشفى"
        fixed = extract.arabic_letters(broken)
        self.assertEqual(fixed, "أساسيات المفهوم والأكاديمية كيف على إلى مستشفى")      # a final ى stays
        self.assertEqual(extract.arabic_letters("ﻣﻔﻬﻮم ﺍﻟﻄﺎﻗﺔ"), "مفهوم الطاقة")             # presentation forms

    def test_words_of_a_left_to_right_pdf_are_put_back_in_order_and_header_is_removed(self):
        text, details = extract.read("pdf", damaged_pdf([HEADER, "الوحدة الثالثة: الطاقة المتجددة", *BODY]))
        self.assertIn("الطاقة المتجددة هي الطاقة التي تأتي من مصادر طبيعية لا تنفد مثل الشمس والرياح.", text)
        self.assertIn("مقدمة في مفهوم الطاقة والتحول العالمي والمصادر المتجددة.", text)
        for bad in ("ى", "ھ", "المادة", "الصف:", "المرحلة"):
            self.assertNotIn(bad if bad != "ى" else "ىا", text)
        self.assertEqual(details, {"subject": "العلوم العامة", "grade": "الأول الثانوي"})
        self.assertNotIn("الأول الثانوي", text)

    def test_a_normal_chromium_pdf_still_reads_the_same(self):
        text = extract.extract("pdf", F.pdf_bytes())
        self.assertIn("النواة هي مركز التحكم في الخلية", text)

    def test_subject_and_class_never_reach_a_question(self):
        text, _ = meta.split_header(HEADER + "\n" + "\n".join(BODY))
        items = [
            {"kind": "qa", "question": "في مادة العلوم للصف الأول الثانوي، ما الطاقة المتجددة؟", "answer": "الطاقة التي تأتي من مصادر طبيعية", "evidence": "الطاقة المتجددة هي الطاقة التي تأتي من مصادر طبيعية لا تنفد مثل الشمس والرياح"},
            {"kind": "mcq", "question": "ما المقصود بالطاقة المتجددة؟", "answer": "الطاقة التي تأتي من مصادر طبيعية", "options": ["الطاقة التي تأتي من مصادر طبيعية", "الصف الأول الثانوي"], "evidence": "الطاقة المتجددة هي الطاقة التي تأتي من مصادر طبيعية لا تنفد مثل الشمس والرياح"},
            {"kind": "qa", "question": "ما المادة؟", "answer": "المادة: العلوم", "evidence": "الطاقة المتجددة هي الطاقة التي تأتي من مصادر طبيعية لا تنفد"},
            {"kind": "qa", "question": "ما مصدر الطاقة المتجددة للصف الثالث الثانوي؟", "answer": "الشمس", "evidence": "مثل الشمس والرياح"},
        ]
        out = aiq.clean_items(items, text, strict=False)
        blob = json.dumps(out, ensure_ascii=False)
        for word in ("مادة", "للصف", "الصف", "الثانوي"):
            self.assertNotIn(word, blob)
        self.assertEqual(out[0]["question"], "ما الطاقة المتجددة؟")
        self.assertEqual(len(out), 2)                                     # the one with the class as an option, and the one asking for the subject, are dropped

    def test_the_offline_generator_makes_clean_questions_from_a_damaged_pdf(self):
        class C:
            ai_provider, anthropic_key, anthropic_model = "offline", "", "m"
        text, _ = extract.read("pdf", damaged_pdf([HEADER, *BODY]))
        _, items, _ = aiq.make_questions(C, text, False)
        self.assertTrue(items)
        blob = json.dumps(items, ensure_ascii=False)
        for word in ("المادة", "الصف", "العلوم العامة", "الأول الثانوي"):
            self.assertNotIn(word, blob)


class UploadTests(Base):
    def test_the_lesson_keeps_subject_and_class_as_its_own_details_only(self):
        c = self.client()
        self.register(c)
        r = self.upload(c, "energy.pdf", damaged_pdf([HEADER, "الوحدة الثالثة: الطاقة المتجددة", *BODY]))
        lid = int(re.search(r"/lessons/(\d+)", r.headers["Location"]).group(1))
        row = self.app.db.execute("SELECT * FROM lessons WHERE id = ?", (lid,)).fetchone()
        self.assertEqual((row["status"], row["subject"], row["grade"]), ("ready", "العلوم العامة", "الأول الثانوي"))
        st = c.get(f"/api/lessons/{lid}").get_json()
        self.assertEqual((st["subject"], st["grade"]), ("العلوم العامة", "الأول الثانوي"))
        self.assertIn('id="lesson-info"', c.get(f"/lessons/{lid}").get_data(as_text=True))
        qs = c.get(f"/api/lessons/{lid}/questions").get_json()["questions"]
        self.assertTrue(qs)
        blob = json.dumps(qs, ensure_ascii=False)
        for word in ("العلوم العامة", "الأول الثانوي", "المادة", "الصف"):
            self.assertNotIn(word, blob)
        self.assertNotIn("العلوم العامة", row["text"])


class StudentTests(Base):
    def setUp(self):
        super().setUp()
        self.c, self.lid = self.teacher_with_lesson()

    def students(self, c=None):
        return (c or self.c).get("/api/students").get_json()["students"]

    def deck(self, games=("pick", "qa")):
        qs = self.c.get(f"/api/lessons/{self.lid}/questions").get_json()["questions"]
        r = self.j(self.c, "post", f"/api/lessons/{self.lid}/decks", {"games": list(games), "question_ids": [q["id"] for q in qs]})
        self.assertEqual(r.status_code, 201)
        return r.get_json()["id"], qs

    def test_add_edit_delete_and_save_the_list(self):
        r = self.j(self.c, "post", "/api/students", {"names": ["سارة أحمد", "  نورة   علي ", "سارة أحمد", "x"]})
        self.assertEqual((r.status_code, r.get_json()["added"], r.get_json()["skipped"]), (201, 2, 2))
        self.assertEqual([s["name"] for s in self.students()], ["سارة أحمد", "نورة علي"])
        sid = self.students()[0]["id"]
        self.assertEqual(self.j(self.c, "patch", f"/api/students/{sid}", {"name": "سارة محمد"}).status_code, 200)
        self.assertEqual(self.j(self.c, "patch", f"/api/students/{sid}", {"name": "نورة علي"}).status_code, 409)
        self.assertEqual(self.j(self.c, "post", "/api/students", {"name": "ريم"}).status_code, 201)
        self.assertEqual(len(self.students()), 3)
        self.assertEqual(self.j(self.c, "delete", f"/api/students/{sid}").status_code, 200)
        self.assertEqual(sorted(s["name"] for s in self.students()), ["ريم", "نورة علي"])
        self.assertEqual(self.c.get("/students").status_code, 200)

    def test_results_are_linked_to_the_student_and_summed(self):
        self.j(self.c, "post", "/api/students", {"names": ["سارة", "نورة"]})
        a, b = self.students()
        deck, qs = self.deck()
        def rec(s, q, ok, run="r1", game="pick"):
            return self.j(self.c, "post", "/api/results", {"student_id": s["id"], "deck_id": deck, "question_id": q["id"], "game": game, "correct": ok, "run": run})
        self.assertEqual(rec(a, qs[0], True).status_code, 200)
        self.assertEqual(rec(a, qs[1], False).status_code, 200)
        self.assertEqual(rec(a, qs[1], True).status_code, 200)                 # marking the same question again corrects it, never doubles it
        self.assertEqual(rec(b, qs[0], False).status_code, 200)
        by = {s["name"]: s for s in self.students()}
        self.assertEqual((by["سارة"]["answered"], by["سارة"]["correct"], by["سارة"]["percent"], by["سارة"]["level"]), (2, 2, 100, "ممتاز"))
        self.assertEqual((by["نورة"]["answered"], by["نورة"]["percent"], by["نورة"]["level"]), (1, 0, "يحتاج إلى دعم"))
        detail = self.c.get(f"/api/students/{a['id']}/results").get_json()
        self.assertEqual((detail["decks"][0]["answered"], detail["decks"][0]["correct"], len(detail["recent"])), (2, 2, 2))
        self.assertEqual(self.j(self.c, "post", "/api/results", {"student_id": a["id"], "deck_id": deck, "question_id": 99999, "correct": 1}).status_code, 400)
        self.assertEqual(self.j(self.c, "post", "/api/results", {"student_id": "x", "deck_id": deck, "question_id": qs[0]["id"]}).status_code, 404)
        self.j(self.c, "delete", f"/api/students/{a['id']}/results")
        self.assertEqual({s["name"]: s["answered"] for s in self.students()}["سارة"], 0)
        # deleting the student takes her results with her; the deck keeps working
        self.j(self.c, "delete", f"/api/students/{b['id']}")
        self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM results").fetchone()[0], 0)

    def test_a_teacher_never_sees_or_touches_another_teachers_students(self):
        self.j(self.c, "post", "/api/students", {"name": "سارة"})
        sid = self.students()[0]["id"]
        deck, qs = self.deck()
        other = self.client()
        self.register(other, "b@example.com")
        self.assertEqual(self.students(other), [])
        for method, url, data in (("patch", f"/api/students/{sid}", {"name": "x1"}), ("delete", f"/api/students/{sid}", None)):
            self.assertEqual(self.j(other, method, url, data).status_code, 404)
        self.assertEqual(other.get(f"/api/students/{sid}/results").status_code, 404)
        self.assertEqual(self.j(other, "post", "/api/results", {"student_id": sid, "deck_id": deck, "question_id": qs[0]["id"], "correct": 1}).status_code, 404)
        self.assertEqual(self.j(other, "post", "/api/students", {"name": "سارة"}).status_code, 201)        # the same name is fine for her
        self.assertEqual(len(self.students()), 1)

    def test_results_need_login_and_the_page_is_private(self):
        anon = self.client()
        self.assertEqual(anon.get("/students").status_code, 302)
        self.assertEqual(anon.get("/api/students").status_code, 401)
        self.assertEqual(anon.post("/api/results", json={}).status_code in (401, 403), True)

    def test_account_deletion_removes_students_and_results(self):
        self.j(self.c, "post", "/api/students", {"name": "سارة"})
        deck, qs = self.deck()
        s = self.students()[0]
        self.j(self.c, "post", "/api/results", {"student_id": s["id"], "deck_id": deck, "question_id": qs[0]["id"], "correct": 1, "run": "a"})
        self.assertEqual(self.j(self.c, "post", "/api/me/delete", {"password": "Teacher-pass-1"}).status_code, 200)
        db = self.app.db
        self.assertEqual((db.execute("SELECT COUNT(*) FROM students").fetchone()[0], db.execute("SELECT COUNT(*) FROM results").fetchone()[0]), (0, 0))

    def test_the_students_wheel_is_a_game_and_old_decks_get_it_too(self):
        deck, qs = self.deck(("qa",))
        data = self.c.get(f"/api/decks/{deck}/data").get_json()
        self.assertIn("pick", data["game_info"])
        self.assertEqual(sorted(data["game_info"]["pick"]["kinds"]), sorted(aiq.KINDS))
        page = self.c.get(f"/lessons/{self.lid}").get_data(as_text=True)
        self.assertIn('value="pick"', page)

    def test_classes_each_with_its_own_names(self):
        a = self.j(self.c, "post", "/api/classes", {"name": "أول ثانوي 1"}).get_json()["id"]
        b = self.j(self.c, "post", "/api/classes", {"name": "أول ثانوي 2"}).get_json()["id"]
        self.assertEqual(self.j(self.c, "post", "/api/classes", {"name": "أول ثانوي 1"}).status_code, 409)
        self.j(self.c, "post", "/api/students", {"class_id": a, "names": ["سارة", "نورة"]})
        self.j(self.c, "post", "/api/students", {"class_id": b, "names": ["سارة", "ريم"]})            # the same first name in another class is fine
        names = lambda cid: sorted(s["name"] for s in self.c.get(f"/api/students?class_id={cid}").get_json()["students"])
        self.assertEqual((names(a), names(b)), (["سارة", "نورة"], ["ريم", "سارة"]))
        cl = {c["name"]: c["count"] for c in self.c.get("/api/classes").get_json()["classes"]}
        self.assertEqual(cl, {"أول ثانوي 1": 2, "أول ثانوي 2": 2})
        self.assertEqual(self.j(self.c, "patch", f"/api/classes/{b}", {"name": "ثاني ثانوي"}).status_code, 200)
        # the data of her other classes is untouched when one class is deleted, and its students' results go with it
        deck, qs = self.deck()
        sid = self.c.get(f"/api/students?class_id={b}").get_json()["students"][0]["id"]
        self.j(self.c, "post", "/api/results", {"student_id": sid, "deck_id": deck, "question_id": qs[0]["id"], "correct": 1, "run": "x"})
        self.assertEqual(self.j(self.c, "delete", f"/api/classes/{b}").status_code, 200)
        self.assertEqual(names(a), ["سارة", "نورة"])
        self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM results").fetchone()[0], 0)
        self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM students").fetchone()[0], 2)

    def test_classes_are_private_too(self):
        cid = self.j(self.c, "post", "/api/classes", {"name": "فصلي"}).get_json()["id"]
        other = self.client()
        self.register(other, "b@example.com")
        self.assertEqual(other.get("/api/classes").get_json()["classes"], [])
        self.assertEqual(self.j(other, "patch", f"/api/classes/{cid}", {"name": "x1"}).status_code, 404)
        self.assertEqual(self.j(other, "delete", f"/api/classes/{cid}").status_code, 404)
        self.assertEqual(self.j(other, "post", "/api/students", {"class_id": cid, "names": ["دخيلة"]}).status_code, 404)
        self.assertEqual(self.j(self.c, "post", "/api/classes", {"name": "x"}).status_code, 400)

    def test_a_name_typed_with_no_class_goes_to_a_first_class(self):
        self.j(self.c, "post", "/api/students", {"name": "سارة"})
        cl = self.c.get("/api/classes").get_json()["classes"]
        self.assertEqual([(c["name"], c["count"]) for c in cl], [("الفصل الأول", 1)])

    def test_version_three_students_move_into_a_first_class_with_their_results(self):
        import sqlite3, tempfile
        from app import db as dbm
        with tempfile.TemporaryDirectory() as d:
            conn = sqlite3.connect(d + "/v3.db")
            conn.row_factory = sqlite3.Row
            dbm.init(conn)
            conn.execute("INSERT INTO users(email, name, pass_hash, created_at) VALUES ('o@x.com','o','h',1)")
            conn.executescript("DROP TABLE results; DROP TABLE students; DROP TABLE classes;"
                               "CREATE TABLE students(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, name TEXT NOT NULL, created_at REAL NOT NULL, UNIQUE(user_id, name));"
                               "CREATE TABLE results(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE, deck_id INTEGER, deck_title TEXT NOT NULL DEFAULT '', question_id INTEGER, question TEXT NOT NULL DEFAULT '', game TEXT NOT NULL DEFAULT '', kind TEXT NOT NULL DEFAULT '', correct INTEGER NOT NULL, run TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL);"
                               "INSERT INTO students(user_id, name, created_at) VALUES (1,'سارة',1),(1,'نورة',1);"
                               "INSERT INTO results(user_id, student_id, correct, created_at) VALUES (1,1,1,1),(1,1,0,2),(1,2,1,3);")
            conn.commit()
            dbm.init(conn)
            rows = conn.execute("SELECT s.name, c.name AS cls FROM students s JOIN classes c ON c.id = s.class_id ORDER BY s.id").fetchall()
            self.assertEqual([(r["name"], r["cls"]) for r in rows], [("سارة", "الفصل الأول"), ("نورة", "الفصل الأول")])
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM results").fetchone()[0], 3)          # no result was lost in the move
            conn.execute("INSERT INTO classes(user_id, name, created_at) VALUES (1,'الفصل الثاني',1)")
            conn.execute("INSERT INTO students(user_id, class_id, name, created_at) VALUES (1, 2, 'سارة', 1)")       # the same name in a second class

    def test_old_database_gets_the_new_tables_and_columns(self):
        import sqlite3, tempfile
        from app import db as dbm
        with tempfile.TemporaryDirectory() as d:
            conn = sqlite3.connect(d + "/old.db")
            conn.executescript("CREATE TABLE users(id INTEGER PRIMARY KEY, email TEXT, name TEXT, pass_hash TEXT, plan_code TEXT DEFAULT 'free', ai_consent INTEGER DEFAULT 0, created_at REAL);"
                               "CREATE TABLE lessons(id INTEGER PRIMARY KEY, user_id INTEGER, title TEXT, original_name TEXT, stored_name TEXT, kind TEXT, text TEXT DEFAULT '', status TEXT DEFAULT 'ready', error TEXT DEFAULT '', engine TEXT DEFAULT '', created_at REAL, updated_at REAL);"
                               "CREATE TABLE plans(code TEXT PRIMARY KEY, name TEXT, max_lessons INTEGER, max_decks INTEGER, price_month INTEGER DEFAULT 0, price_year INTEGER DEFAULT 0, purchasable INTEGER DEFAULT 0);"
                               "INSERT INTO users(email, name, pass_hash, created_at) VALUES ('o@x.com','o','h',1); INSERT INTO lessons(user_id,title,original_name,stored_name,kind,created_at,updated_at) VALUES (1,'t','a','b','pdf',1,1);")
            conn.row_factory = sqlite3.Row
            dbm.init(conn)
            cols = [r[1] for r in conn.execute("PRAGMA table_info(lessons)")]
            self.assertIn("subject", cols)
            self.assertIn("grade", cols)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM lessons").fetchone()[0], 1)           # nothing was lost
            conn.execute("INSERT INTO students(user_id, name, created_at) VALUES (1, 'x', 1)")


if __name__ == "__main__":
    unittest.main()
