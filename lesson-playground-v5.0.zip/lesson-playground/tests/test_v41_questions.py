"""A sentence taken out of the middle of a text can lean on the one before it («وتسميته بتوحيد الألوهية…»). As a true-or-false statement, a blank or a half it is
not clear, so the free reader leaves such sentences out (and takes only a borrowed «و» off a sentence whose subject is right there)."""
import unittest

from app import aiq, costmodel, grounding as G
from tests import fixtures as F

TEXT = """توحيد الألوهية
توحيد الألوهية هو إفراد الله وحده بالعبادة والخضوع له وحده في كل شيء.
وتسميته بتوحيد الألوهية لأنه مبني على إخلاص التأله لله وحده في جميع العبادات.
وتوحيد الربوبية هو الإقرار بأن الله وحده الخالق الرازق المدبر لجميع الأمور في الكون.
هذا النوع من التوحيد أقر به المشركون في زمن النبي قبل بعثته عليه الصلاة والسلام.
أنواع التوحيد ثلاثة وهي الربوبية والألوهية والأسماء والصفات عند أهل العلم.
والأسماء والصفات إثبات ما أثبته الله لنفسه من الأسماء الحسنى والصفات العلى.
ثم تأتي ثمرات التوحيد العظيمة في حياة المسلم ومنها الأمن والطمأنينة في القلب.
حكمه واجب على كل مسلم بالغ عاقل ولا يصح إيمان أحد بدونه.
وظيفة الإيمان بالله تثبيت القلب وحماية صاحبه من القلق والخوف على الرزق.
"""


class StandaloneTests(unittest.TestCase):
    LEANING = [
        "وتسميته بتوحيد الألوهية لأنه مبني على إخلاص التأله لله وحده",              # the sentence of the report
        "وَتَسْمِيَتُهُ بتوحيد الألوهية لأنه مبني على إخلاص التأله",                  # with vowel signs
        "«وتسميته بتوحيد الألوهية لأنه مبني على إخلاص التأله»",                      # inside quotation marks
        "و تسميته بتوحيد الألوهية لأنه مبني على إخلاص التأله",                       # the «و» apart
        "ثم تخرج الفضلات من الجسم عبر الأمعاء الغليظة بعد الامتصاص",
        "هذا النوع من التوحيد أقر به المشركون في زمن النبي",
        "ولذلك سمي بهذا الاسم عند العلماء منذ القدم",
        "أنواعه ثلاثة أنواع رئيسية عند العلماء المتقدمين",
        "حكمه واجب على كل مسلم بالغ عاقل",
        "أركانها خمسة يجب على المسلم معرفتها والعمل بها",
        "الذي يحيط بالخلية هو الغشاء الخلوي الرقيق جدا",
        "والتي تحيط بالخلية هي الجدار الخلوي في النبات",
        "فهو يحمي الخلية من المؤثرات الخارجية كلها",
        "ويقوم بحماية الخلية من المؤثرات الخارجية دائما",
        "وفي الخلية النباتية جدار خلوي يحميها ويعطيها شكلها",
        "لكن الخلية الحيوانية لا تحتوي على جدار خلوي",
        "كما أن النواة تحتوي على المادة الوراثية للخلية",
    ]
    ALONE = [
        "الخلية هي الوحدة الأساسية للحياة في جميع الكائنات الحية",
        "وظيفة الميتوكوندريا إنتاج الطاقة للخلية الحية",                              # a word that merely begins with و
        "وحدة بناء الجسم هي الخلية الحية الصغيرة",
        "وزن الجسم يقاس بالكيلوجرام في المختبر",
        "ولد النبي محمد صلى الله عليه وسلم في مكة المكرمة",
        "والدة الطالب تحضر الاجتماع كل شهر دراسي",
        "عبدالله بن مسعود صحابي جليل من علماء الصحابة",                               # a name that ends with ه
        "الله خالق كل شيء ومدبر أمره سبحانه وتعالى",
        "تنبيه مهم لجميع الطلاب في الصف قبل الاختبار",                                # a plain noun that ends with ه
        "غير المسلمين لهم حقوق محفوظة في الدولة الإسلامية",
        "أي مادة لها كتلة وتشغل حيزا من الفراغ المحيط",
        "الوراثة انتقال الصفات من الآباء إلى الأبناء",
        "فائدة الماء للجسم كبيرة جدا في كل وقت",                                      # a word that merely begins with ف
        "فيروس صغير جدا يصيب الخلايا الحية ويتكاثر فيها",
        "أولا: الخلية هي الوحدة الأساسية للحياة كلها",
    ]

    def test_sentences_that_lean_on_the_one_before_are_refused(self):
        for s in self.LEANING:
            self.assertIsNone(aiq.standalone(s), s)

    def test_sentences_that_stand_alone_are_kept_exactly(self):
        for s in self.ALONE:
            self.assertEqual(aiq.standalone(s), s, s)

    def test_only_a_borrowed_waw_is_taken_off_when_the_subject_is_there(self):
        self.assertEqual(aiq.standalone("والنواة مركز التحكم في الخلية الحية"), "النواة مركز التحكم في الخلية الحية")
        self.assertEqual(aiq.standalone("وَالنَّوَاةُ مركز التحكم في الخلية"), "النَّوَاةُ مركز التحكم في الخلية")
        self.assertEqual(aiq.standalone("وتوحيد الربوبية هو الإقرار بأن الله وحده الخالق"), "توحيد الربوبية هو الإقرار بأن الله وحده الخالق")
        self.assertEqual(aiq.standalone("وصلاة الجماعة هي الصلاة مع الناس في المسجد"), "صلاة الجماعة هي الصلاة مع الناس في المسجد")
        self.assertIsNone(aiq.standalone("وهذا النوع أقر به المشركون في زمن النبي"))             # what is left still points back
        self.assertIsNone(aiq.standalone("وتسميته هي الاسم الذي عرف به عند العلماء"))
        self.assertIsNone(aiq.standalone("وتتكون من أجزاء كثيرة أهمها النواة والغشاء"))         # a verb with no subject of its own

    def test_empty_and_marks_only(self):
        for s in ("", "   ", "«»", "- "):
            self.assertIsNone(aiq.standalone(s))

    def test_the_ordinary_lessons_lose_nothing(self):
        for s in F.LESSON + [l for l in costmodel.SAMPLE_LESSON.splitlines() if l.strip()]:
            self.assertEqual(aiq.standalone(s), s.strip(), s)


class GeneratorTests(unittest.TestCase):
    def test_no_question_starts_in_the_middle_of_a_thought(self):
        out = aiq.OfflineProvider().generate(TEXT)
        self.assertTrue(out)
        for q in out:
            if q["kind"] in aiq.LOOK:
                self.assertIsNotNone(aiq.standalone(q["question"]), q["question"])
            self.assertNotIn("وتسميته", q["question"] + q["evidence"] + q["answer"])
            self.assertNotIn("حكمه", q["question"])
            self.assertNotIn(q["question"].split()[0], ("وتسميته", "وتوحيد", "والأسماء", "ثم", "هذا", "حكمه"), q["question"])         # «وظيفة» is a real word and stays

    def test_the_subject_that_was_there_still_gives_its_questions_without_the_waw(self):
        out = aiq.OfflineProvider().generate(TEXT)
        terms = [q["question"] for q in out if q["kind"] == "qa"]
        self.assertIn("ما المقصود بـ «توحيد الربوبية»؟", terms)
        self.assertFalse(any("«و" in t for t in terms))
        self.assertIn("اذكري ما تعرفينه عن «توحيد الربوبية»", [q["question"] for q in out if q["kind"] == "review"])

    def test_every_question_is_still_backed_by_the_file(self):
        out = aiq.clean_items(aiq.OfflineProvider().generate(TEXT), TEXT, True)
        self.assertTrue(out)
        self.assertTrue(all(q["clear"] for q in out))
        n = G.norm(TEXT)
        self.assertTrue(all(G.in_text(q["evidence"], n) for q in out))

    def test_a_lesson_without_such_sentences_gives_what_it_gave_before(self):
        # the very same twelve questions the earlier version made for this lesson
        out = aiq.OfflineProvider().generate("\n".join(F.LESSON))
        self.assertEqual(len(out), 12)
        self.assertEqual({q["kind"] for q in out}, set(aiq.KINDS))


class PaidReaderAnswersTests(unittest.TestCase):
    def test_a_statement_that_starts_with_waw_is_dropped_from_any_reader(self):
        text = "توحيد الألوهية هو إفراد الله بالعبادة. وتسميته بتوحيد الألوهية لأنه مبني على إخلاص التأله لله وحده في العبادات."
        items = [dict(kind="tf", question="وتسميته بتوحيد الألوهية لأنه مبني على إخلاص التأله لله وحده في العبادات", answer="صح",
                      evidence="وتسميته بتوحيد الألوهية لأنه مبني على إخلاص التأله لله وحده في العبادات"),
                 dict(kind="tf", question="توحيد الألوهية هو إفراد الله بالعبادة", answer="صح", evidence="توحيد الألوهية هو إفراد الله بالعبادة"),
                 dict(kind="qa", question="لماذا سمي توحيد الألوهية بهذا الاسم؟", answer="لأنه مبني على إخلاص التأله لله وحده", evidence="لأنه مبني على إخلاص التأله لله وحده في العبادات")]
        out = aiq.clean_items(items, text, False)
        self.assertEqual([q["question"] for q in out], ["توحيد الألوهية هو إفراد الله بالعبادة", "لماذا سمي توحيد الألوهية بهذا الاسم؟"])


if __name__ == "__main__":
    unittest.main()
