"""Builds real lesson files for the tests: an Arabic PowerPoint, an Arabic PDF (printed by a browser), and a picture with text."""
import io
import subprocess
import tempfile
from pathlib import Path

LESSON = [
    "الخلية هي الوحدة الأساسية للحياة في جميع الكائنات الحية.",
    "النواة هي مركز التحكم في الخلية وتحتوي على المادة الوراثية.",
    "تقوم الميتوكوندريا بإنتاج الطاقة للخلية لأن عملية التنفس الخلوي تحدث داخلها.",
    "تحتوي الخلية النباتية على جدار خلوي يحمي الخلية ويعطيها شكلها الثابت.",
    "الغشاء الخلوي ينظم دخول المواد وخروجها من الخلية الحية.",
    "البلاستيدات الخضراء تحتوي على الكلوروفيل الذي يمتص ضوء الشمس لصنع الغذاء.",
    "الخلايا الحيوانية لا تحتوي على جدار خلوي ولا على بلاستيدات خضراء في تركيبها.",
    "الريبوسومات تصنع البروتينات التي تحتاجها الخلية للنمو والإصلاح.",
]


def pptx_bytes(lines=LESSON, title="أجزاء الخلية"):
    from pptx import Presentation
    prs = Presentation()
    s = prs.slides.add_slide(prs.slide_layouts[1])
    s.shapes.title.text = title
    s.placeholders[1].text = "\n".join(lines[:4])
    s2 = prs.slides.add_slide(prs.slide_layouts[1])
    s2.shapes.title.text = "تابع"
    s2.placeholders[1].text = "\n".join(lines[4:])
    buf = io.BytesIO()
    prs.save(buf)
    return buf.getvalue()


def pdf_bytes(lines=LESSON, title="أجزاء الخلية"):
    """An Arabic PDF printed by Chromium (what a teacher's PDF looks like inside)."""
    from playwright.sync_api import sync_playwright
    html = "<html dir=rtl lang=ar><body style='font-family:DejaVu Sans;font-size:18px'><h1>%s</h1>%s</body></html>" % (title, "".join("<p>%s</p>" % l for l in lines))
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page()
        pg.set_content(html)
        data = pg.pdf()
        b.close()
    return data


def png_bytes(text="The cell is the basic unit of life in all living things. The nucleus controls the cell."):
    from PIL import Image, ImageDraw, ImageFont
    img = Image.new("RGB", (1400, 220), "white")
    d = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 34)
    except OSError:
        font = ImageFont.load_default()
    d.text((20, 70), text, fill="black", font=font)
    buf = io.BytesIO()
    img.save(buf, "PNG")
    return buf.getvalue()
