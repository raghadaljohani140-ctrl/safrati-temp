"""Version 5, phase 5 through the server: formal exams made from the lessons of the book (or her own files), edited question by question, approved, printed on A4 with an
answer key of its own, announced in WhatsApp, and the marks of her students kept per class. Walls between teachers and between classes are tested for every route."""
import csv
import io
import json
import re
import sqlite3
import tempfile
import unittest
from unittest import mock

from markupsafe import escape

from app import aiq, billing, create_app, examq, exams, share, textfmt
from app import db as dbm
from app import grounding as G
from app.security import Limiter
from tests import fixtures as FX
from tests import test_v5_phase4 as P4

LESSON1 = "\n".join(FX.LESSON)
LESSON2 = """الجهاز الهضمي هو مجموعة من الأعضاء التي تعمل معًا لتحليل الطعام وامتصاصه.
تبدأ عملية الهضم في الفم لأن اللعاب يحتوي على إنزيمات تفكك النشويات.
المعدة عضو عضلي يخلط الطعام مع العصارات الهضمية ويحوله إلى سائل.
الأمعاء الدقيقة هي المكان الرئيس لامتصاص الغذاء إلى الدم.
الكبد يفرز العصارة الصفراوية التي تساعد على هضم الدهون.
الأمعاء الغليظة تمتص الماء من الفضلات قبل أن تخرج من الجسم.
المريء أنبوب عضلي ينقل الطعام من الفم إلى المعدة بحركات متتابعة.
يحتاج الجسم إلى الألياف لأنها تساعد الأمعاء على الحركة المنتظمة."""
LESSON3 = """النبات يصنع غذاءه بنفسه لأنه يحتوي على الكلوروفيل في أوراقه.
عملية البناء الضوئي هي العملية التي يصنع بها النبات الغذاء باستخدام ضوء الشمس والماء وغاز ثاني أكسيد الكربون.
الجذور تثبت النبات في التربة وتمتص الماء والأملاح من الأرض.
الساق تحمل الأوراق والأزهار وتنقل الماء والغذاء بين أجزاء النبات.
الأزهار هي الجزء الذي يتكاثر به النبات وتتحول بعد التلقيح إلى ثمار.
الثمرة تحمي البذور وتساعد على انتشارها بعيدًا عن النبات الأم.
البذرة تنبت عندما تجد الماء والدفء والهواء المناسب.
تحتاج النباتات إلى ضوء الشمس لأنه مصدر الطاقة اللازمة للبناء الضوئي."""
OUTLINE_SCI = """الوحدة الأولى: الكائنات الحية
الدرس الأول: الخلية
الدرس الثاني: الهضم
الدرس الثالث: النبات
الوحدة الثانية: المادة
الدرس الأول: الحالات
الدرس الثاني: التغيرات
مراجعة الوحدة الثانية
اختبار الوحدة الثانية"""
WANT = {"mcq": 4, "tf": 3, "cloze": 2, "qa": 2, "essay": 2}          # 13 questions
NAMES = ("سارة", "نورة", "ليان", "مها")
HEAD = "مدرسة النور الابتدائية\nإدارة التعليم بالرياض"
MUTATING = ("post", "put", "patch", "delete")


# ================================================================ examq on its own
class Pure(unittest.TestCase):
    def pools(self):
        return [("الخلية", examq.pool_of(LESSON1)), ("الهضم", examq.pool_of(LESSON2))]

    def test_a_lesson_gives_questions_of_every_kind_each_with_its_sentence(self):
        pool = examq.pool_of(LESSON1)
        self.assertEqual(set(pool), set(examq.KINDS))
        for kind in ("mcq", "tf", "cloze", "short", "essay"):
            self.assertTrue(pool[kind], kind)
        for kind, items in pool.items():
            for q in items:
                self.assertEqual(q["kind"], kind)
                self.assertTrue(q["question"] and q["evidence"], q)
                self.assertIn(q["clear"], (0, 1))
        self.assertTrue(all(q["answer"] in ("صح", "خطأ") for q in pool["tf"]))
        self.assertTrue(all(q["answer"] in q["options"] and len(q["options"]) >= 2 for q in pool["mcq"]))
        self.assertTrue(all(aiq.BLANK in q["question"] for q in pool["cloze"]))

    def test_nothing_comes_out_of_an_empty_or_huge_text(self):
        self.assertEqual({k: v for k, v in examq.pool_of("").items() if v}, {})
        self.assertEqual({k: v for k, v in examq.pool_of(None).items() if v}, {})
        examq.pool_of("جملة قصيرة مفيدة جدا. " * 5000)          # cut to MAX_TEXT, no crash

    def test_every_sentence_is_asked_once_in_an_exam(self):
        chosen, spares, short = examq.allocate(self.pools(), {"mcq": 4, "tf": 4, "cloze": 3, "qa": 2, "short": 2, "essay": 2})
        evidence = [G.norm(q["evidence"]) for q in chosen]
        self.assertEqual(len(evidence), len(set(evidence)))
        self.assertEqual(len(chosen), 17 - sum(short.values()))

    def test_the_sections_follow_the_paper_and_both_lessons_are_asked_from(self):
        chosen, _, _ = examq.allocate(self.pools(), {"mcq": 4, "tf": 4, "essay": 2, "cloze": 3})
        kinds = [q["kind"] for q in chosen]
        self.assertEqual(kinds, sorted(kinds, key=examq.KINDS.index))
        for kind in ("mcq", "tf", "cloze"):
            self.assertEqual({q["source"] for q in chosen if q["kind"] == kind}, {"الخلية", "الهضم"}, kind)          # each kind takes from the lessons in turn

    def test_the_rest_stays_as_spares_and_never_repeats_a_chosen_question(self):
        chosen, spares, _ = examq.allocate(self.pools(), {"mcq": 4, "tf": 4})
        self.assertTrue(spares)
        self.assertFalse({(q["kind"], q["question"]) for q in chosen} & {(q["kind"], q["question"]) for q in spares})          # a spare of ANOTHER kind may be the same sentence: it can't join while that sentence is asked
        self.assertLessEqual(len(spares), examq.MAX_SPARES)
        for kind in examq.KINDS:
            self.assertLessEqual(sum(1 for q in spares if q["kind"] == kind), examq.SPARES_PER_KIND)

    def test_a_kind_the_lessons_cannot_fill_is_reported_short(self):
        one = [("درس", examq.pool_of("الخلية هي الوحدة الأساسية للحياة في جميع الكائنات الحية."))]
        chosen, _, short = examq.allocate(one, {"mcq": 10, "tf": 10})
        self.assertLessEqual(len(chosen), 1)          # one sentence is asked once, not twenty times
        for kind in ("mcq", "tf"):
            self.assertEqual(sum(1 for q in chosen if q["kind"] == kind) + short.get(kind, 0), 10)

    def test_nothing_wanted_nothing_chosen(self):
        self.assertEqual(examq.allocate(self.pools(), {})[0], [])
        self.assertEqual(examq.allocate(self.pools(), {"mcq": 0})[2], {})
        self.assertEqual(examq.allocate([], {"mcq": 3})[2], {"mcq": 3})

    def test_marks_add_up_to_the_total_in_half_marks(self):
        thirteen = ["mcq"] * 4 + ["tf"] * 3 + ["cloze"] * 2 + ["qa"] * 2 + ["essay"] * 2
        for total, kinds in ((20, thirteen), (30, thirteen), (40, thirteen), (100, thirteen), (7, thirteen), (6.5, thirteen), (10, ["mcq"] * 3), (7.5, ["mcq", "tf", "qa"])):
            marks = examq.distribute(total, kinds)
            self.assertAlmostEqual(sum(marks), total, msg=total)
            self.assertTrue(all(m >= 0.5 and m * 2 == int(m * 2) for m in marks), (total, marks))

    def test_questions_of_a_kind_are_worth_the_same_when_the_total_shares_evenly(self):
        self.assertEqual(examq.distribute(20, ["mcq"] * 10 + ["tf"] * 10), [1.0] * 20)
        marks = examq.distribute(30, ["mcq"] * 5 + ["essay"] * 1)
        self.assertEqual(len(set(marks[:5])), 1)
        self.assertGreater(marks[5], marks[0])          # an essay is worth more than a multiple choice

    def test_a_total_that_cannot_be_shared_is_refused(self):
        for total, kinds in ((2, ["mcq"] * 5), (5, []), ("x", ["mcq"]), (None, ["mcq"]), (1001, ["mcq"]), (0, ["mcq"])):
            self.assertIsNone(examq.distribute(total, kinds), (total, kinds))
        self.assertEqual(examq.distribute(2.5, ["mcq"] * 5), [0.5] * 5)          # the smallest a question can be worth

    def test_a_question_is_worth_half_a_mark_to_fifty_in_half_marks(self):
        for raw, want in ((1, 1), ("2", 2), (0.5, 0.5), (1.3, 1.5), (1.2, 1.0), (50, 50), ("2.5", 2.5)):
            self.assertEqual(examq.clean_marks(raw), want, raw)
        for raw in (0.3, 0, -1, 50.2, 51, "abc", None, "", float("nan"), float("inf"), [], {}):
            self.assertIsNone(examq.clean_marks(raw), raw)

    def test_marks_are_written_without_a_useless_decimal(self):
        self.assertEqual([examq.fmt_marks(x) for x in (1, 1.0, 1.5, 0.5, 10.0, 0, None)], ["1", "1", "1.5", "0.5", "10", "0", "0"])

    def test_marks_are_said_the_way_a_paper_says_them(self):
        for x, want in ((1, "درجة واحدة"), (2, "درجتان"), (3, "3 درجات"), (10, "10 درجات"), (11, "11 درجة"), (20, "20 درجة"), (0.5, "نصف درجة"), (1.5, "درجة ونصف"),
                        (2.5, "درجتان ونصف"), (3.5, "3 درجات ونصف"), (11.5, "11 درجة ونصف"), (0, "0 درجات"), (None, "0 درجات"), ("x", "0 درجات")):
            self.assertEqual(textfmt.marks(x), want, x)

    def test_two_spares_from_one_sentence_are_one_alternative(self):
        used = [{"question": "ما وظيفة النواة داخل الخلية الحية؟", "evidence": "النواة هي مركز التحكم في الخلية."}]
        spares = [
            {"question": "اذكري أحد الأشياء التي ينظمها الغشاء الخلوي للخلية.", "evidence": "الغشاء الخلوي ينظم دخول المواد وخروجها."},
            {"question": "ماذا يفعل الغشاء المحيط بالخلية الحية بالمواد؟", "evidence": "الغشاء الخلوي ينظم دخول المواد وخروجها."},
            {"question": "ما الذي يتحكم في كل عمل تقوم به الخلية يوميًا؟", "evidence": "النواة هي مركز التحكم في الخلية."},          # the sentence of a question already there
        ]
        self.assertEqual(examq.spares_left(spares, used), 1)
        self.assertEqual(examq.next_spare(spares, used), spares[0])
        self.assertIsNone(examq.next_spare(spares[2:], used))
        self.assertEqual(examq.spares_left([], used), 0)

    def test_the_letters_of_the_options(self):
        self.assertEqual(examq.letters(4), ["أ", "ب", "ج", "د"])
        self.assertEqual(examq.letters(0), [])
        self.assertEqual(len(examq.letters(20)), 8)


# ================================================================ the base of the server tests
class Phase5(P4.Phase4):
    def setUp(self):
        super().setUp()
        exams.build_limit.hits.clear()
        self.addCleanup(exams.build_limit.hits.clear)

    def world(self, c=None, names=NAMES, klass="الصف الأول أ", subject="العلوم", texts=(LESSON1, LESSON2, LESSON3)):
        """A class with students, its subject and a book of two units whose first lessons have a text: ids of all of them."""
        c = c or self.c
        cid, sid = self.make_class(klass, c), self.make_subject(subject, c)
        if names:
            self.assertEqual(self.api("post", "/api/students", {"class_id": cid, "names": list(names)}, c).status_code, 201)
        bid = self.outline_book(text=OUTLINE_SCI, c=c)
        self.confirm(bid, [cid], subject=subject, c=c)
        book = self.book(bid, c)
        lessons = [l for u in book["units"] for l in u["lessons"]]
        for l, t in zip(lessons, texts):
            self.app.db.execute("UPDATE book_lessons SET text = ? WHERE id = ?", (t, l["id"]))
        self.app.db.commit()
        students = {s["name"]: s["id"] for s in c.get(f"/api/students?class_id={cid}").get_json()["students"]}
        return {"cid": cid, "sid": sid, "bid": bid, "units": [u["id"] for u in book["units"]], "lessons": [l["id"] for l in lessons],
                "kind": {l["id"]: l["kind"] for l in lessons}, "title": {l["id"]: l["title"] for l in lessons}, "students": students}

    def new_exam(self, w, c=None, status=201, **over):
        data = {"class_id": w["cid"], "subject_id": w["sid"], "lessons": w["lessons"][:2], "wanted": dict(WANT), **over}
        r = self.api("post", "/api/exams", data, c)
        self.assertEqual(r.status_code, status, r.get_data(as_text=True))
        return r.get_json()["exam"] if status == 201 else r.get_json()

    def exam(self, eid, c=None):
        r = (c or self.c).get(f"/api/exams/{eid}")
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()["exam"]

    def post(self, eid, what, data=None, c=None, status=200, method="post"):
        r = self.api(method, f"/api/exams/{eid}/{what}" if what else f"/api/exams/{eid}", data if data is not None else {}, c)
        self.assertEqual(r.status_code, status, (what, r.get_data(as_text=True)))
        return r.get_json()

    def approve(self, eid, c=None, status=200):
        return self.post(eid, "approve", c=c, status=status)

    def add_q(self, eid, kind, question, answer="", options=None, marks=None, c=None, status=201):
        data = {"kind": kind, "question": question, "answer": answer}
        if options is not None:
            data["options"] = options
        if marks is not None:
            data["marks"] = marks
        return self.post(eid, "questions", data, c=c, status=status)

    @staticmethod
    def of(e, kind=None):
        return [q for q in e["questions"] if kind in (None, q["kind"])]

    def rows(self, sql, *args):
        return [dict(r) for r in self.app.db.execute(sql, args).fetchall()]

    def exam_rows(self, eid, state="used"):
        return self.rows("SELECT * FROM exam_questions WHERE exam_id = ? AND state = ? ORDER BY position, id", eid, state)

    def scores(self, eid, lines, c=None, status=200):
        return self.post(eid, "scores", {"scores": lines}, c=c, status=status, method="put")

    def tables(self):
        return [self.count(f"SELECT COUNT(*) FROM {t}") for t in ("exams", "exam_questions", "exam_scores")]

    def planned(self, w, c=None):
        """The plan of the class built (a term and two periods a week), as the screen of the plan has it."""
        self.set_term(c=c)
        self.set_slots([(0, 1, w["cid"], w["sid"]), (2, 2, w["cid"], w["sid"])], c=c)
        return self.build(w["cid"], w["sid"], c)


# ================================================================ what an exam may cover
class Sources(Phase5):
    def test_the_screen_lists_the_units_the_lessons_their_texts_and_what_is_done(self):
        w = self.world()
        plan = self.planned(w)
        first = plan["items"][0]
        self.act(first["id"], "done")
        d = self.c.get(f"/api/exams/sources?class_id={w['cid']}&subject_id={w['sid']}").get_json()
        self.assertEqual(d["book"]["id"], w["bid"])
        self.assertEqual(len(d["units"]), 2)
        lessons = [l for u in d["units"] for l in u["lessons"]]
        self.assertEqual([l["has_text"] for l in lessons], [True, True, True, False, False, False])          # the review line is there, without a text
        self.assertEqual([l["done"] for l in lessons][:3], [first["book_lesson_id"] == w["lessons"][0], False, False])
        self.assertNotIn(w["lessons"][-1], [l["id"] for l in lessons])          # «اختبار الوحدة» is a line of the book, not a lesson
        self.assertEqual([k["key"] for k in d["kinds"]], list(examq.KINDS))
        self.assertEqual({k["key"]: k["count"] for k in d["kinds"]}, examq.DEFAULT_COUNTS)
        self.assertEqual(d["header"], "")

    def test_a_class_without_a_book_still_offers_her_own_files(self):
        cid, sid = self.make_class(), self.make_subject("اللغة")
        r = self.upload(self.c, "cell.pptx", FX.pptx_bytes())
        lid = int(re.search(r"/lessons/(\d+)", r.headers["Location"]).group(1))
        d = self.c.get(f"/api/exams/sources?class_id={cid}&subject_id={sid}").get_json()
        self.assertEqual((d["book"], d["units"]), (None, []))
        self.assertEqual([u["id"] for u in d["uploads"]], [lid])

    def test_the_subject_is_optional_and_the_class_is_not(self):
        w = self.world()
        self.assertEqual(self.c.get(f"/api/exams/sources?class_id={w['cid']}").status_code, 200)
        self.assertEqual(self.c.get("/api/exams/sources").status_code, 404)
        self.assertEqual(self.c.get(f"/api/exams/sources?class_id={w['cid']}&subject_id=9999").status_code, 404)


# ================================================================ making an exam
class Making(Phase5):
    def test_an_exam_is_built_from_the_lessons_she_ticked(self):
        w = self.world()
        before = self.tables_untouched()
        e = self.new_exam(w, title="اختبار الفترة الأولى", date="2026-10-04", minutes=45, total=20)
        self.assertEqual((e["status"], e["status_text"], e["title"], e["minutes"]), ("draft", "مسودة", "اختبار الفترة الأولى", 45))
        self.assertEqual((e["date"], e["date_text"]), ("2026-10-04", "الأحد 4 أكتوبر 2026"))
        self.assertEqual((e["count"], e["counts"]), (13, {"mcq": 4, "tf": 3, "cloze": 2, "qa": 2, "short": 0, "essay": 2}))
        self.assertEqual(e["short"], {})
        self.assertEqual((e["total"], e["total_text"], e["total_word"]), (20, "20", "20 درجة"))
        self.assertAlmostEqual(sum(q["marks"] for q in e["questions"]), 20)
        kinds = [q["kind"] for q in e["questions"]]
        self.assertEqual(kinds, sorted(kinds, key=examq.KINDS.index))
        self.assertEqual([q["position"] for q in e["questions"]], list(range(1, 14)))
        evidence = [G.norm(q["evidence"]) for q in e["questions"]]
        self.assertEqual(len(evidence), len(set(evidence)))          # a sentence of the book is asked once
        self.assertEqual({q["source"] for q in e["questions"]}, {w["title"][w["lessons"][0]], w["title"][w["lessons"][1]]})
        self.assertTrue(all(q["origin"] == "auto" and q["clear"] and not q["edited"] for q in e["questions"]))
        self.assertGreater(sum(e["spares"].values()), 0)
        self.assertEqual([s["label"] for s in e["sources"]], [w["title"][w["lessons"][0]], w["title"][w["lessons"][1]]])
        self.assertEqual(e["class"]["id"], w["cid"])
        self.assertEqual(e["subject"]["id"], w["sid"])
        self.assertEqual(self.tables_untouched(), before)          # the questions of the lessons, the book and the plan are as they were
        self.assertEqual([x["id"] for x in self.c.get("/api/exams").get_json()["exams"]], [e["id"]])

    def tables_untouched(self):
        return [self.count(f"SELECT COUNT(*) FROM {t}") for t in ("questions", "lessons", "book_lessons", "book_units", "plan_items", "students", "points")]

    def test_without_a_total_each_question_is_worth_the_usual_marks_of_its_kind(self):
        e = self.new_exam(self.world())
        for q in e["questions"]:
            self.assertEqual(q["marks"], examq.DEFAULT_MARKS[q["kind"]], q["kind"])
        self.assertEqual(e["total"], sum(examq.DEFAULT_MARKS[q["kind"]] for q in e["questions"]))

    def test_a_total_is_shared_between_the_questions(self):
        w = self.world()
        for total in (20, 30, 7.5):
            e = self.new_exam(w, total=total)
            self.assertAlmostEqual(e["total"], total)
            self.assertAlmostEqual(sum(q["marks"] for q in e["questions"]), total)
            self.assertTrue(all(q["marks"] >= 0.5 for q in e["questions"]))

    def test_a_unit_stands_for_all_its_lessons(self):
        w = self.world()
        e = self.new_exam(w, lessons=[], units=[w["units"][0]], wanted={"mcq": 3, "tf": 3})
        self.assertEqual([s["label"] for s in e["sources"]], [w["title"][i] for i in w["lessons"][:3]])
        self.assertEqual({q["source"] for q in e["questions"]}, set(w["title"][i] for i in w["lessons"][:3]))

    def test_lessons_without_a_text_are_left_out_and_she_is_told(self):
        w = self.world()
        no_text, review, line = w["lessons"][3], w["lessons"][5], w["lessons"][6]
        self.assertEqual((w["kind"][review], w["kind"][line]), ("review", "exam"))
        r = self.api("post", "/api/exams", {"class_id": w["cid"], "subject_id": w["sid"], "lessons": [w["lessons"][0], no_text, review, line], "wanted": {"mcq": 2}})
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        d = r.get_json()
        self.assertEqual([s["label"] for s in d["exam"]["sources"]], [w["title"][w["lessons"][0]]])
        self.assertEqual(len(d["skipped"]), 2)
        self.assertIn(w["title"][no_text], d["skipped"][0])
        self.assertTrue(all("نص" in x for x in d["skipped"]))          # the line of the unit exam is dropped without a word: it is not a lesson
        r = self.api("post", "/api/exams", {"class_id": w["cid"], "subject_id": w["sid"], "lessons": [no_text], "wanted": {"mcq": 2}})
        self.assertEqual(r.status_code, 400)
        self.assertIn("اختاري درسًا", r.get_json()["error"])
        self.assertEqual(len(r.get_json()["skipped"]), 1)

    def test_the_text_of_a_lesson_made_from_the_plan_is_used_when_the_book_kept_none(self):
        w = self.world()
        none = w["lessons"][3]
        plan = self.planned(w)
        item = next(i for i in plan["items"] if i["book_lesson_id"] == none)
        made = self.app.db.execute("INSERT INTO lessons(user_id, title, original_name, stored_name, kind, text, status, created_at, updated_at) VALUES (1, 'درس', 'a.pptx', 'a', 'pptx', ?, 'ready', 1, 1)", (LESSON2,)).lastrowid
        self.app.db.execute("UPDATE plan_items SET lesson_id = ? WHERE id = ?", (made, item["id"]))
        self.app.db.commit()
        e = self.new_exam(w, lessons=[none], wanted={"mcq": 2})
        self.assertEqual(e["count"], 2)

    def test_a_lesson_of_her_own_files_can_be_used(self):
        w = self.world()
        r = self.upload(self.c, "cell.pptx", FX.pptx_bytes())
        lid = int(re.search(r"/lessons/(\d+)", r.headers["Location"]).group(1))
        e = self.new_exam(w, lessons=[], uploads=[lid], wanted={"mcq": 3, "tf": 2})
        self.assertEqual([s["t"] for s in e["sources"]], ["up"])
        self.assertEqual(e["count"], 5)

    def test_what_the_lessons_cannot_give_is_reported_not_invented(self):
        w = self.world()
        e = self.new_exam(w, lessons=[w["lessons"][0]], wanted={"qa": 20, "mcq": 2})
        self.assertGreater(e["short"]["qa"], 0)
        self.assertEqual(e["counts"]["qa"] + e["short"]["qa"], 20)
        self.assertNotIn("mcq", e["short"])

    def test_bad_requests_are_refused_and_nothing_is_saved(self):
        w = self.world()
        two = w["lessons"][:2]
        base = {"class_id": w["cid"], "subject_id": w["sid"], "lessons": two, "wanted": dict(WANT)}
        for change, word in (({"wanted": {}}, "عدد الأسئلة"), ({"wanted": {"mcq": 0}}, "عدد الأسئلة"), ({"wanted": {"mcq": examq.MAX_PER_KIND + 1}}, "عدد الأسئلة"),
                             ({"wanted": {"mcq": 40, "tf": 40, "cloze": 40}}, "عدد الأسئلة"), ({"wanted": {"mcq": -1}}, "عدد الأسئلة"), ({"wanted": "x"}, "عدد الأسئلة"),
                             ({"wanted": None}, "عدد الأسئلة"), ({"date": "2026-13-45"}, "تاريخ"), ({"date": "غدا"}, "تاريخ"), ({"minutes": 601}, "زمن"), ({"minutes": -5}, "زمن"),
                             ({"total": 0.2}, "الدرجة الكلية"), ({"total": 1001}, "الدرجة الكلية"), ({"total": "abc"}, "الدرجة الكلية"), ({"total": 1}, "لا تكفي"),
                             ({"lessons": []}, "درسًا واحدًا"), ({"lessons": [], "units": [], "uploads": []}, "درسًا واحدًا")):
            r = self.api("post", "/api/exams", {**base, **change})
            self.assertEqual(r.status_code, 400, change)
            self.assertIn(word, r.get_json()["error"], change)
        self.assertEqual(self.api("post", "/api/exams", {**base, "class_id": 9999}).status_code, 404)
        self.assertEqual(self.api("post", "/api/exams", {**base, "class_id": None}).status_code, 404)
        self.assertEqual(self.api("post", "/api/exams", {**base, "subject_id": 9999}).status_code, 404)
        self.assertEqual(self.api("post", "/api/exams", {**base, "lessons": [9999]}).status_code, 404)
        self.assertEqual(self.api("post", "/api/exams", {**base, "lessons": [], "units": [9999]}).status_code, 404)
        self.assertEqual(self.api("post", "/api/exams", {**base, "lessons": [], "uploads": [9999]}).status_code, 404)
        self.assertEqual(self.tables(), [0, 0, 0])

    def test_there_is_a_most_lessons_for_one_exam_and_one_most_for_all_her_exams(self):
        w = self.world()
        with mock.patch.object(exams, "MAX_SOURCES", 1):
            r = self.api("post", "/api/exams", {"class_id": w["cid"], "lessons": w["lessons"][:2], "wanted": {"mcq": 2}})
            self.assertEqual(r.status_code, 400)
        r = self.api("post", "/api/exams", {"class_id": w["cid"], "lessons": w["lessons"] * 80, "wanted": {"mcq": 2}})          # the same lesson 480 times is one lesson
        self.assertEqual(r.status_code, 400)          # but a list that long is refused outright
        with mock.patch.object(exams, "MAX_EXAMS", 1):
            self.new_exam(w)
            self.assertEqual(self.new_exam(w, status=400)["error"].count("الحد الأقصى"), 1)
            e = self.c.get("/api/exams").get_json()["exams"][0]
            self.assertEqual(self.api("post", f"/api/exams/{e['id']}/copy", {"class_id": w["cid"]}).status_code, 400)

    def test_making_exams_is_not_unlimited(self):
        w = self.world()
        with mock.patch.object(exams, "build_limit", Limiter(1, 3600)):
            self.new_exam(w)
            r = self.new_exam(w, status=429)
            self.assertIn("جرّبي", r["error"])
        self.assertEqual(self.count("SELECT COUNT(*) FROM exams"), 1)

    def test_the_title_is_made_when_she_gives_none_and_cut_when_too_long(self):
        w = self.world()
        e = self.new_exam(w)
        self.assertEqual(e["title"], "اختبار العلوم — الصف الأول أ")
        self.assertEqual(self.new_exam(w, title="   ")["title"], "اختبار العلوم — الصف الأول أ")
        long = self.new_exam(w, title="س" * 300)["title"]
        self.assertTrue(0 < len(long) <= exams.MAX_TITLE)
        self.assertEqual(self.new_exam(w, subject_id=None)["title"], "اختبار الصف الأول أ")

    def test_the_head_of_the_paper_is_remembered_for_her_next_exam(self):
        w = self.world()
        self.assertEqual(self.new_exam(w)["header"], "")
        e = self.new_exam(w, header=HEAD)
        self.assertEqual(e["header"], HEAD)
        self.assertEqual(self.new_exam(w)["header"], HEAD)          # not sent: the last one is used
        self.assertEqual(self.c.get(f"/api/exams/sources?class_id={w['cid']}").get_json()["header"], HEAD)
        self.assertEqual(self.new_exam(w, header="")["header"], "")          # sent empty: she cleared it
        self.assertEqual(self.new_exam(w)["header"], "")
        long = "\n".join(["أ" * 300, "", "  ", "ب", "ج", "د", "هـ"])
        lines = self.new_exam(w, header=long)["header"].split("\n")
        self.assertEqual((len(lines), len(lines[0])), (3, 100))          # three short lines at most, blanks dropped

    def test_the_exam_of_a_deleted_class_goes_and_the_exam_of_a_deleted_subject_stays(self):
        w = self.world()
        other = self.world(klass="الصف الأول ب", subject="الفيزياء", names=("ريم", "جود"))
        a, b = self.new_exam(w)["id"], self.new_exam(other)["id"]
        self.assertEqual(self.api("delete", f"/api/subjects/{w['sid']}").status_code, 200)
        self.assertIsNone(self.exam(a)["subject"])          # the paper does not need the subject to exist
        self.assertEqual(self.api("delete", f"/api/classes/{w['cid']}").status_code, 200)
        self.assertEqual(self.c.get(f"/api/exams/{a}").status_code, 404)
        self.assertEqual(self.exam(b)["count"], 13)
        self.assertEqual(self.count("SELECT COUNT(*) FROM exam_questions WHERE exam_id = ?", a), 0)


# ================================================================ replacing, adding, editing
class Editing(Phase5):
    def fresh(self, **over):
        w = self.world()
        return w, self.new_exam(w, wanted={"mcq": 4, "tf": 3, "cloze": 2, "qa": 2, "essay": 2}, **over)

    def test_replacing_takes_the_next_spare_and_keeps_the_place_and_the_marks(self):
        w, e = self.fresh(total=20)
        q = self.of(e, "mcq")[1]
        r = self.post(e["id"], f"questions/{q['id']}/replace")
        new = r["question"]
        self.assertNotEqual(new["id"], q["id"])
        self.assertEqual((new["kind"], new["position"], new["marks"]), ("mcq", q["position"], q["marks"]))
        self.assertNotEqual(G.norm(new["evidence"]), G.norm(q["evidence"]))
        self.assertEqual(r["replaced"], q["id"])
        self.assertEqual(r["spares"], r["exam"]["spares"]["mcq"])
        self.assertLessEqual(r["spares"], e["spares"]["mcq"])
        got = r["exam"]
        self.assertEqual([x["id"] for x in got["questions"]].count(q["id"]), 0)
        self.assertEqual(len(got["questions"]), 13)
        self.assertEqual(got["total"], e["total"])
        self.assertEqual([x["position"] for x in got["questions"]], list(range(1, 14)))
        evidence = [G.norm(x["evidence"]) for x in got["questions"]]
        self.assertEqual(len(evidence), len(set(evidence)))
        self.assertEqual(self.rows("SELECT state FROM exam_questions WHERE id = ?", q["id"])[0]["state"], "dropped")          # it does not come back as a spare

    def test_replacing_again_and_again_ends_with_a_clear_message_and_the_count_was_right(self):
        w, e = self.fresh()
        qid, done, left = self.of(e, "mcq")[0]["id"], 0, e["spares"]["mcq"]
        while True:
            r = self.api("post", f"/api/exams/{e['id']}/questions/{qid}/replace", {})
            if r.status_code == 409:
                break
            self.assertEqual(r.status_code, 200)
            done += 1
            qid, left = r.get_json()["question"]["id"], r.get_json()["spares"]
            self.assertLess(done, 200)
        d = r.get_json()
        self.assertGreaterEqual(done, 1)
        self.assertEqual(left, 0)          # the figure she saw after the last swap said that no alternative was left
        self.assertEqual(d["spares"], 0)
        self.assertFalse(d["can_ask_ai"])
        self.assertIn("أضيفي سؤالك بيدك", d["error"])
        self.assertNotIn("القارئ الذكي", d["error"])          # it is not on for her, so it is not offered
        self.assertEqual(self.exam(e["id"])["count"], 13)

    def test_the_count_of_alternatives_tells_whether_the_next_swap_works(self):
        w, e = self.fresh()
        for kind in ("tf", "cloze", "essay", "qa"):
            q = self.of(e, kind)[0]
            for _ in range(60):
                left = self.exam(e["id"])["spares"][kind]
                r = self.api("post", f"/api/exams/{e['id']}/questions/{q['id']}/replace", {})
                self.assertEqual(r.status_code, 200 if left else 409, (kind, left))
                if r.status_code == 409:
                    break
                q = r.get_json()["question"]
            else:
                self.fail("never ends")

    def test_a_deleted_question_is_gone_for_good(self):
        w, e = self.fresh()
        q = self.of(e, "tf")[0]
        got = self.post(e["id"], f"questions/{q['id']}", status=200, method="delete")["exam"]
        self.assertEqual((got["count"], got["counts"]["tf"]), (12, 2))
        self.assertEqual([x["position"] for x in got["questions"]], list(range(1, 13)))
        self.assertAlmostEqual(got["total"], e["total"] - q["marks"])
        self.assertEqual(self.rows("SELECT state FROM exam_questions WHERE id = ?", q["id"])[0]["state"], "dropped")
        for _ in range(60):          # even when the spares of the kind are all used, the deleted one is not among them
            r = self.api("post", f"/api/exams/{e['id']}/spare", {"kind": "tf"})
            if r.status_code != 201:
                break
        self.assertNotIn(q["id"], [x["id"] for x in self.exam(e["id"])["questions"]])
        self.assertEqual(self.api("delete", f"/api/exams/{e['id']}/questions/{q['id']}").status_code, 404)          # and it can't be deleted twice

    def test_one_more_question_of_a_kind_comes_from_the_spares_to_the_end_of_its_section(self):
        w, e = self.fresh()
        self.assertEqual(e["counts"]["short"], 0)
        self.assertGreater(e["spares"]["short"], 0)
        r = self.post(e["id"], "spare", {"kind": "short"}, status=201)
        new = r["question"]
        self.assertEqual((new["kind"], new["marks"], new["origin"]), ("short", float(examq.DEFAULT_MARKS["short"]), "auto"))
        got = r["exam"]
        self.assertEqual((got["count"], got["counts"]["short"]), (14, 1))
        self.assertEqual(got["total"], e["total"] + examq.DEFAULT_MARKS["short"])
        kinds = [q["kind"] for q in got["questions"]]
        self.assertEqual(kinds, sorted(kinds, key=examq.KINDS.index))
        self.assertEqual([q["position"] for q in got["questions"]], list(range(1, 15)))
        last = self.of(got, "qa")[-1]
        r2 = self.post(e["id"], "spare", {"kind": "qa"}, status=201 if got["spares"]["qa"] else 409)
        if got["spares"]["qa"]:
            self.assertGreater(self.of(r2["exam"], "qa")[-1]["position"], last["position"])

    def test_spares_run_out_with_a_message_and_a_bad_kind_is_refused(self):
        w, e = self.fresh()
        for _ in range(100):
            r = self.api("post", f"/api/exams/{e['id']}/spare", {"kind": "mcq"})
            if r.status_code == 409:
                break
        self.assertEqual(r.status_code, 409)
        self.assertIn("أضيفي سؤالك بيدك", r.get_json()["error"])
        for bad in ("x", "", None, 5):
            self.assertEqual(self.api("post", f"/api/exams/{e['id']}/spare", {"kind": bad}).status_code, 400)

    def test_the_exam_holds_a_hundred_questions_at_most(self):
        w, e = self.fresh()
        with mock.patch.object(examq, "MAX_QUESTIONS", 14):
            self.add_q(e["id"], "qa", "ما اسم أكبر محيط على الأرض؟", "المحيط الهادئ")
            self.assertEqual(self.add_q(e["id"], "qa", "ما اسم أطول نهر في العالم؟", "النيل", status=400)["error"].count("14"), 1)
            r = self.api("post", f"/api/exams/{e['id']}/spare", {"kind": "short"})
            self.assertEqual(r.status_code, 400)

    def test_her_own_questions_follow_the_same_rules_as_the_book_ones(self):
        w, e = self.fresh()
        before = self.exam(e["id"])
        for data, word in (({"kind": "x", "question": "سؤال صحيح الصياغة", "answer": "ج"}, "نوع السؤال"),
                           ({"kind": "qa", "question": "ما", "answer": "ج"}, "نص السؤال"),
                           ({"kind": "qa", "question": "ما هي عاصمة السعودية؟", "answer": ""}, "الإجابة النموذجية"),
                           ({"kind": "essay", "question": "اشرحي دورة الماء في الطبيعة.", "answer": "  "}, "الإجابة النموذجية"),
                           ({"kind": "tf", "question": "الشمس نجم", "answer": "ربما"}, "صح"),
                           ({"kind": "mcq", "question": "ما لون السماء؟", "answer": "أزرق", "options": ["أزرق"]}, "خيارين"),
                           ({"kind": "mcq", "question": "ما لون السماء؟", "answer": "أزرق", "options": ["أزرق", "أزرق"]}, "خيارين"),
                           ({"kind": "mcq", "question": "ما لون السماء؟", "answer": "أحمر", "options": ["أزرق", "أخضر"]}, "الإجابة"),
                           ({"kind": "mcq", "question": "ما لون السماء؟", "answer": "أزرق", "options": "أزرق"}, "خيارين"),
                           ({"kind": "cloze", "question": "عاصمة السعودية هي الرياض", "answer": "الرياض"}, "فراغًا"),
                           ({"kind": "qa", "question": "ما هي عاصمة السعودية؟", "answer": "الرياض", "marks": 0.2}, "درجة السؤال"),
                           ({"kind": "qa", "question": "ما هي عاصمة السعودية؟", "answer": "الرياض", "marks": "abc"}, "درجة السؤال"),
                           ({"kind": "qa", "question": "ما هي عاصمة السعودية؟", "answer": "الرياض", "marks": 51}, "درجة السؤال")):
            r = self.api("post", f"/api/exams/{e['id']}/questions", data)
            self.assertEqual(r.status_code, 400, data)
            self.assertIn(word, r.get_json()["error"], data)
        self.assertEqual(self.exam(e["id"]), before)

    def test_her_own_question_of_each_kind_goes_to_the_end_of_its_section(self):
        w, e = self.fresh(total=20)
        made = [self.add_q(e["id"], *a, **kw)["question"] for a, kw in (
            (("mcq", "ما أكبر كواكب المجموعة الشمسية؟", "المشتري"), {"options": ["المشتري", " الأرض ", "", "المريخ"]}),
            (("tf", "الشمس نجم", "صح"), {}),
            (("cloze", "عاصمة السعودية هي _____", "الرياض"), {"marks": 2.5}),
            (("qa", "ما هي عاصمة السعودية؟", "الرياض"), {}),
            (("short", "أكملي: الماء يغلي عند", "مئة درجة"), {}),
            (("essay", "اشرحي دورة الماء في الطبيعة.", "تبخر ثم تكاثف ثم هطول"), {"marks": 6}))]
        self.assertEqual([q["origin"] for q in made], ["manual"] * 6)
        self.assertEqual({q["source"] for q in made}, {"سؤالك"})
        self.assertTrue(all(q["clear"] and not q["edited"] for q in made))
        self.assertEqual(made[0]["options"], ["المشتري", "الأرض", "المريخ"])          # a blank option is dropped, the rest trimmed
        self.assertEqual(made[1]["options"], [])
        self.assertEqual([q["marks"] for q in made], [1, 1, 2.5, 2, 2, 6])          # the usual marks of the kind unless she said
        got = self.exam(e["id"])
        self.assertEqual(got["count"], 19)
        kinds = [q["kind"] for q in got["questions"]]
        self.assertEqual(kinds, sorted(kinds, key=examq.KINDS.index))
        self.assertEqual([q["position"] for q in got["questions"]], list(range(1, 20)))
        for q in made:
            same = self.of(got, q["kind"])
            self.assertEqual(same[-1]["id"], q["id"], q["kind"])          # last in its own section
        self.assertAlmostEqual(got["total"], 20 + 1 + 1 + 2.5 + 2 + 2 + 6)

    def test_changing_the_words_of_a_question_is_her_decision_and_removes_the_warning(self):
        w, e = self.fresh()
        q = self.of(e, "mcq")[0]
        self.app.db.execute("UPDATE exam_questions SET clear = 0 WHERE id = ?", (q["id"],))
        self.app.db.commit()
        opts = q["options"]
        got = self.post(e["id"], f"questions/{q['id']}", {"question": "  سؤال جديد أكتبه بنفسي؟ ", "answer": opts[1], "options": opts}, method="patch")["question"]
        self.assertEqual((got["question"], got["answer"], got["clear"], got["edited"]), ("سؤال جديد أكتبه بنفسي؟", opts[1], True, True))
        r = self.api("patch", f"/api/exams/{e['id']}/questions/{q['id']}", {"answer": "ليست بين الخيارات"})
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.of(self.exam(e["id"]), "mcq")[0]["answer"], opts[1])          # the wrong edit changed nothing
        r = self.api("patch", f"/api/exams/{e['id']}/questions/{self.of(e, 'tf')[0]['id']}", {"answer": "ربما"})
        self.assertEqual(r.status_code, 400)

    def test_changing_only_the_marks_keeps_the_question_and_its_warning(self):
        w, e = self.fresh(total=20)
        q = self.of(e, "qa")[0]
        self.app.db.execute("UPDATE exam_questions SET clear = 0 WHERE id = ?", (q["id"],))
        self.app.db.commit()
        r = self.post(e["id"], f"questions/{q['id']}", {"marks": 3}, method="patch")
        got = r["question"]
        self.assertEqual((got["marks"], got["clear"], got["edited"], got["question"]), (3, False, False, q["question"]))          # the warning stays: she did not touch the words
        self.assertAlmostEqual(r["exam"]["total"], e["total"] - q["marks"] + 3)
        self.assertEqual(self.post(e["id"], f"questions/{q['id']}", {"marks": 1.3}, method="patch")["question"]["marks"], 1.5)
        for bad in (0.2, 0, -1, 51, "x", None):
            self.assertEqual(self.api("patch", f"/api/exams/{e['id']}/questions/{q['id']}", {"marks": bad}).status_code, 400, bad)
        self.assertEqual(self.of(self.exam(e["id"]), "qa")[0]["marks"], 1.5)

    def test_only_a_question_in_the_exam_can_be_changed(self):
        w, e = self.fresh()
        spare = self.exam_rows(e["id"], "spare")[0]["id"]
        gone = self.of(e, "tf")[0]["id"]
        self.api("delete", f"/api/exams/{e['id']}/questions/{gone}")
        for qid in (spare, gone, 99999):
            for method, tail, data in (("patch", "", {"marks": 2}), ("delete", "", {}), ("post", "/replace", {}), ("post", "/move", {"dir": 1})):
                r = self.api(method, f"/api/exams/{e['id']}/questions/{qid}{tail}", data)
                self.assertEqual(r.status_code, 404, (method, tail, qid))
        self.assertEqual(self.exam(e["id"])["count"], 12)

    def test_a_question_moves_inside_its_section_only(self):
        w, e = self.fresh()
        mcq = self.of(e, "mcq")
        ids = [q["id"] for q in mcq]
        got = self.post(e["id"], f"questions/{ids[1]}/move", {"dir": -1})["exam"]
        self.assertEqual([q["id"] for q in self.of(got, "mcq")], [ids[1], ids[0], ids[2], ids[3]])
        self.assertEqual([q["position"] for q in got["questions"]], list(range(1, 14)))
        got = self.post(e["id"], f"questions/{ids[1]}/move", {"dir": -1})["exam"]          # at the top of its section already: nothing happens
        self.assertEqual([q["id"] for q in self.of(got, "mcq")], [ids[1], ids[0], ids[2], ids[3]])
        got = self.post(e["id"], f"questions/{ids[3]}/move", {"dir": 1})["exam"]          # and the last one can't go further down into the next section
        self.assertEqual([q["id"] for q in self.of(got, "mcq")], [ids[1], ids[0], ids[2], ids[3]])
        self.assertEqual([q["kind"] for q in got["questions"]], sorted([q["kind"] for q in got["questions"]], key=examq.KINDS.index))
        moved = {q["id"]: q["marks"] for q in got["questions"]}
        self.assertEqual({q["id"]: q["marks"] for q in e["questions"]}, moved)          # the marks stay with the question

    def test_the_marks_can_be_spread_to_a_total(self):
        w, e = self.fresh()
        for total in (40, 20, 6.5):
            got = self.post(e["id"], "marks", {"total": total})["exam"]
            self.assertAlmostEqual(got["total"], total)
            self.assertAlmostEqual(sum(q["marks"] for q in got["questions"]), total)
        r = self.api("post", f"/api/exams/{e['id']}/marks", {"total": 5})
        self.assertEqual(r.status_code, 400)
        self.assertIn("لا تكفي", r.get_json()["error"])
        for bad in ("x", None, "", [1]):
            self.assertEqual(self.api("post", f"/api/exams/{e['id']}/marks", {"total": bad}).status_code, 400, bad)
        self.assertAlmostEqual(self.exam(e["id"])["total"], 6.5)          # the refused ones changed nothing
        for q in list(self.exam(e["id"])["questions"]):
            self.api("delete", f"/api/exams/{e['id']}/questions/{q['id']}")
        self.assertEqual(self.api("post", f"/api/exams/{e['id']}/marks", {"total": 20}).status_code, 400)

    def test_the_total_is_always_the_sum_of_the_marks(self):
        w, e = self.fresh(total=30)
        eid = e["id"]
        steps = [lambda: self.post(eid, f"questions/{self.of(self.exam(eid), 'mcq')[0]['id']}/replace"),
                 lambda: self.add_q(eid, "essay", "اشرحي دورة الماء في الطبيعة.", "تبخر", marks=7.5),
                 lambda: self.post(eid, f"questions/{self.of(self.exam(eid), 'tf')[1]['id']}", method="delete"),
                 lambda: self.post(eid, f"questions/{self.of(self.exam(eid), 'qa')[0]['id']}", {"marks": 4.5}, method="patch"),
                 lambda: self.post(eid, "spare", {"kind": "short"}, status=201)]
        for step in steps:
            step()
            got = self.exam(eid)
            self.assertAlmostEqual(got["total"], sum(q["marks"] for q in got["questions"]))
            self.assertAlmostEqual(got["total"], sum(r["marks"] for r in self.exam_rows(eid)))

    def test_the_details_can_change_at_any_time(self):
        w, e = self.fresh()
        got = self.post(e["id"], "", {"title": "  اختبار الشهر  ", "date": "2026-10-11", "minutes": 60, "header": HEAD, "notes": "أحضري القلم\nبدون آلة حاسبة\nسطر ثالث لا يبقى"}, method="patch")["exam"]
        self.assertEqual((got["title"], got["date"], got["minutes"], got["header"]), ("اختبار الشهر", "2026-10-11", 60, HEAD))
        self.assertEqual(got["notes"], "أحضري القلم\nبدون آلة حاسبة")
        self.assertEqual(self.post(e["id"], "", {"date": ""}, method="patch")["exam"]["date"], "")
        for bad, word in (({"title": "ا"}, "عنوانًا"), ({"date": "2026-02-30"}, "تاريخ"), ({"minutes": 9999}, "زمن")):
            r = self.api("patch", f"/api/exams/{e['id']}", bad)
            self.assertEqual(r.status_code, 400, bad)
            self.assertIn(word, r.get_json()["error"])
        self.assertEqual(self.new_exam(w)["header"], HEAD)          # the head she wrote last is the one next time
        self.assertEqual(self.post(e["id"], "", {}, method="patch")["exam"]["title"], "اختبار الشهر")


# ================================================================ approving
class Approving(Phase5):
    def test_an_exam_without_questions_is_not_approved(self):
        w = self.world()
        e = self.new_exam(w, wanted={"mcq": 1})
        self.api("delete", f"/api/exams/{e['id']}/questions/{e['questions'][0]['id']}")
        r = self.api("post", f"/api/exams/{e['id']}/approve", {})
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.exam(e["id"])["status"], "draft")

    def test_approval_counts_the_questions_the_text_does_not_back(self):
        w = self.world()
        e = self.new_exam(w)
        for q in e["questions"][:2]:
            self.app.db.execute("UPDATE exam_questions SET clear = 0 WHERE id = ?", (q["id"],))
        self.app.db.commit()
        got = self.approve(e["id"])["exam"]
        self.assertEqual((got["status"], got["status_text"], got["unclear"]), ("approved", "معتمد", 2))
        self.assertGreater(got["approved_at"], 0)

    def test_an_approved_exam_is_locked_until_she_takes_the_approval_back(self):
        w = self.world()
        e = self.new_exam(w, total=20)
        eid, q = e["id"], e["questions"][0]
        self.approve(eid)
        locked = [("post", "questions", {"kind": "qa", "question": "ما هي عاصمة السعودية؟", "answer": "الرياض"}), ("patch", f"questions/{q['id']}", {"marks": 3}),
                  ("delete", f"questions/{q['id']}", {}), ("post", f"questions/{q['id']}/replace", {}), ("post", f"questions/{q['id']}/move", {"dir": 1}),
                  ("post", "spare", {"kind": "short"}), ("post", "marks", {"total": 40}), ("post", "more", {"kind": "qa"})]
        for method, tail, data in locked:
            r = self.api(method, f"/api/exams/{eid}/{tail}", data)
            self.assertEqual(r.status_code, 409, (method, tail))
            self.assertIn("معتمد", r.get_json()["error"])
        got = self.exam(eid)
        self.assertEqual(([x["id"] for x in got["questions"]], got["total"], got["status"]), ([x["id"] for x in e["questions"]], e["total"], "approved"))
        self.assertFalse(got["can_ask_ai"])
        # but what is not on the paper's questions may still change, and the exam can be copied, read and deleted
        self.assertEqual(self.post(eid, "", {"title": "عنوان جديد"}, method="patch")["exam"]["title"], "عنوان جديد")
        self.assertEqual(self.c.get(f"/exams/{eid}/print").status_code, 200)
        self.assertEqual(self.c.get(f"/api/exams/{eid}/share").status_code, 200)
        # taking the approval back opens it again
        back = self.post(eid, "unapprove")["exam"]
        self.assertEqual((back["status"], back["approved_at"]), ("draft", 0))
        self.post(eid, f"questions/{q['id']}", {"marks": 3}, method="patch")
        self.assertEqual(self.approve(eid)["exam"]["status"], "approved")

    def test_approval_is_refused_when_a_recorded_mark_is_above_the_new_total(self):
        w = self.world()
        e = self.new_exam(w, total=20)
        eid = e["id"]
        self.approve(eid)
        sid = w["students"]["سارة"]
        self.scores(eid, [{"student_id": sid, "score": 18}])
        self.post(eid, "unapprove")
        self.post(eid, "marks", {"total": 10})
        r = self.api("post", f"/api/exams/{eid}/approve", {})
        self.assertEqual(r.status_code, 409)
        self.assertIn("18", r.get_json()["error"])
        self.assertEqual(self.exam(eid)["status"], "draft")
        self.post(eid, "marks", {"total": 20})
        self.assertEqual(self.approve(eid)["exam"]["scores"]["highest"], 18)

    def test_the_marks_recorded_survive_taking_the_approval_back(self):
        w = self.world()
        e = self.new_exam(w, total=20)
        self.approve(e["id"])
        self.scores(e["id"], [{"student_id": w["students"]["سارة"], "score": 15}])
        self.post(e["id"], "unapprove")
        self.assertEqual(self.count("SELECT COUNT(*) FROM exam_scores WHERE exam_id = ?", e["id"]), 1)
        self.assertEqual(self.c.get(f"/api/exams/{e['id']}/scores").get_json()["students"][0]["score"], 15)
        self.scores(e["id"], [{"student_id": w["students"]["سارة"], "score": 12}], status=409)          # but no new mark while it is a draft
        self.approve(e["id"])
        self.assertEqual(self.c.get(f"/api/exams/{e['id']}/scores").get_json()["students"][0]["score"], 15)


# ================================================================ the paper and the answer key
class Paper(Phase5):
    def build(self):
        w = self.world()
        e = self.new_exam(w, title="اختبار الفترة الأولى", date="2026-10-04", minutes=45, total=20, header=HEAD)
        eid = e["id"]
        self.add_q(eid, "qa", "ما اسم أكبر محيط على الأرض؟", "ANSWER-QA-الهادئ")
        self.add_q(eid, "essay", "اشرحي دورة الماء في الطبيعة.", "ANSWER-ESSAY-التبخر")
        self.add_q(eid, "short", "أكملي: الماء يغلي عند", "ANSWER-SHORT-مئة")
        self.add_q(eid, "cloze", "أكبر قارة في العالم هي _____", "ANSWER-CLOZE-آسيا")
        return w, self.exam(eid)

    def page(self, eid, what, c=None):
        r = (c or self.c).get(f"/exams/{eid}/{what}")
        self.assertEqual(r.status_code, 200)
        return r.get_data(as_text=True)

    def test_the_paper_has_the_questions_and_no_answers_and_the_key_has_the_answers(self):
        w, e = self.build()
        eid = e["id"]
        self.approve(eid)
        paper, key = self.page(eid, "print"), self.page(eid, "key")
        for needle in ("اختبار الفترة الأولى", "مدرسة النور الابتدائية", "إدارة التعليم بالرياض", "الأحد 4 أكتوبر 2026", "45", "السؤال الأول", "السؤال الثاني"):
            self.assertIn(needle, paper, needle)
        for q in e["questions"]:
            if q["kind"] != "cloze":
                self.assertIn(str(escape(q["question"])), paper, q["question"])
                self.assertIn(str(escape(q["question"].replace("_____", "........"))), key, q["question"])          # the key writes a blank as dots
        for answer in ("ANSWER-QA-الهادئ", "ANSWER-ESSAY-التبخر", "ANSWER-SHORT-مئة", "ANSWER-CLOZE-آسيا"):
            self.assertNotIn(answer, paper, answer)
            self.assertIn(answer, key, answer)
        sheet = paper.split("<article", 1)[1]
        self.assertNotIn("مفتاح الإجابة", sheet)          # only the buttons above the sheet lead to the key; the sheet itself never names it
        self.assertNotIn("key-stamp", sheet)
        self.assertIn("مفتاح الإجابة · للمعلمة فقط", key)
        for q in self.of(e, "mcq"):
            self.assertIn(str(escape(q["answer"])), key)
        for name in NAMES:
            self.assertNotIn(name, paper)          # a blank paper names nobody

    def test_a_section_for_every_kind_that_is_there_and_none_for_a_kind_that_is_not(self):
        w, e = self.build()
        sections = lambda eid, what="print": re.findall(r'<section class="p-sec k-(\w+)"', self.page(eid, what))
        self.assertEqual(sections(e["id"]), ["mcq", "tf", "cloze", "qa", "short", "essay"])
        self.assertEqual(sections(e["id"], "key"), ["mcq", "tf", "cloze", "qa", "short", "essay"])
        e2 = self.new_exam(w, wanted={"mcq": 3})
        self.assertEqual(sections(e2["id"]), ["mcq"])
        for needle in ("السؤال الأول:", "السؤال الثاني:"):
            self.assertEqual(self.page(e2["id"], "print").count(needle), 1 if needle.endswith("الأول:") else 0)

    def test_a_draft_is_marked_and_an_approved_exam_is_not(self):
        w, e = self.build()
        for what in ("print", "key"):
            self.assertIn("is-draft", self.page(e["id"], what))
        self.approve(e["id"])
        for what in ("print", "key"):
            self.assertNotIn("is-draft", self.page(e["id"], what))

    def test_the_pages_obey_the_content_security_policy(self):
        w, e = self.build()
        self.approve(e["id"])
        for page in (self.page(e["id"], "print"), self.page(e["id"], "key"), self.c.get("/exams").get_data(as_text=True), self.c.get(f"/exams/{e['id']}").get_data(as_text=True)):
            self.assertIsNone(re.search(r"<script(?![^>]*\bsrc=)[^>]*>", page), "an inline script")
            self.assertIsNone(re.search(r"\sstyle\s*=", page), "an inline style")
            self.assertIsNone(re.search(r"\son[a-z]+\s*=", page), "an inline handler")

    def test_the_pages_of_the_exam_belong_to_a_signed_in_teacher(self):
        w, e = self.build()
        anon = self.client()
        for url in ("/exams", f"/exams/{e['id']}", f"/exams/{e['id']}/print", f"/exams/{e['id']}/key"):
            r = anon.get(url)
            self.assertEqual((r.status_code, r.headers["Location"].split("?")[0]), (302, "/login"), url)
        self.assertEqual(self.c.get("/exams").status_code, 200)
        self.assertIn("الاختبارات", self.c.get("/dashboard").get_data(as_text=True))          # the way in is on the menu

    def test_the_paper_page_of_an_exam_that_is_not_there_is_not_found(self):
        self.assertEqual(self.c.get("/exams/9999").status_code, 404)
        self.assertEqual(self.c.get("/exams/9999/print").status_code, 404)
        self.assertEqual(self.c.get("/exams/9999/key").status_code, 404)

    def test_the_options_of_a_multiple_choice_get_their_letters(self):
        w, e = self.build()
        q = self.of(e, "mcq")[0]
        key = self.page(e["id"], "key")
        letter = examq.letters(len(q["options"]))[q["options"].index(q["answer"])]
        self.assertRegex(key, rf"<b>{letter}-</b>\s*{re.escape(str(escape(q['answer'])))}")
        paper = self.page(e["id"], "print")
        for letter, option in zip(examq.letters(len(q["options"])), q["options"]):
            self.assertRegex(paper, rf"<b>{letter}-</b>\s*{re.escape(str(escape(option)))}")          # every option has its letter on the paper


# ================================================================ the marks of the students
class Marks(Phase5):
    def approved(self, **over):
        w = self.world()
        e = self.new_exam(w, total=20, **over)
        self.approve(e["id"])
        return w, e

    def test_marks_wait_for_the_approval_but_the_sheet_can_be_read(self):
        w = self.world()
        e = self.new_exam(w, total=20)
        r = self.api("put", f"/api/exams/{e['id']}/scores", {"scores": [{"student_id": w["students"]["سارة"], "score": 5}]})
        self.assertEqual(r.status_code, 409)
        self.assertEqual(self.count("SELECT COUNT(*) FROM exam_scores"), 0)
        d = self.c.get(f"/api/exams/{e['id']}/scores").get_json()
        self.assertEqual([s["score"] for s in d["students"]], [None] * 4)

    def test_the_sheet_lists_the_students_of_the_class_by_name(self):
        w, e = self.approved()
        d = self.c.get(f"/api/exams/{e['id']}/scores").get_json()
        self.assertEqual([s["name"] for s in d["students"]], sorted(NAMES))
        self.assertEqual({s["student_id"] for s in d["students"]}, set(w["students"].values()))
        self.assertEqual(d["stats"], {"students": 4, "entered": 0, "absent": 0, "average": None, "percent": None, "highest": None, "lowest": None, "passed": 0, "missing": 4})

    def test_saving_marks_and_the_figures_she_sees(self):
        w, e = self.approved()
        s = w["students"]
        d = self.scores(e["id"], [{"student_id": s["سارة"], "score": 18}, {"student_id": s["نورة"], "score": "9.5"}, {"student_id": s["ليان"], "absent": True},
                                 {"student_id": s["مها"], "score": ""}])
        self.assertEqual(d["stats"], {"students": 4, "entered": 2, "absent": 1, "average": 13.75, "percent": 69, "highest": 18, "lowest": 9.5, "passed": 1, "missing": 1})
        by = {r["name"]: r for r in d["students"]}
        self.assertEqual((by["سارة"]["score"], by["نورة"]["score"], by["ليان"]["absent"], by["مها"]["score"]), (18, 9.5, True, None))
        again = self.c.get(f"/api/exams/{e['id']}/scores").get_json()
        self.assertEqual(again["stats"], d["stats"])
        summary = self.c.get("/api/exams").get_json()["exams"][0]["scores"]
        self.assertEqual((summary["entered"], summary["average"], summary["percent"]), (2, 13.75, 69))

    def test_one_line_per_student_and_a_second_save_replaces_it(self):
        w, e = self.approved()
        sid = w["students"]["سارة"]
        self.scores(e["id"], [{"student_id": sid, "score": 10, "note": "ممتازة"}])
        self.scores(e["id"], [{"student_id": sid, "score": 12.456}])
        rows = self.rows("SELECT * FROM exam_scores WHERE exam_id = ?", e["id"])
        self.assertEqual([(r["score"], r["absent"], r["note"]) for r in rows], [(12.46, 0, "")])
        self.scores(e["id"], [{"student_id": sid, "score": 15, "absent": True, "note": "مريضة"}])          # absent: no mark is kept
        rows = self.rows("SELECT * FROM exam_scores WHERE exam_id = ?", e["id"])
        self.assertEqual([(r["score"], r["absent"], r["note"]) for r in rows], [(None, 1, "مريضة")])
        self.scores(e["id"], [{"student_id": sid, "score": 0}])
        self.assertEqual(self.rows("SELECT score FROM exam_scores WHERE exam_id = ?", e["id"])[0]["score"], 0)          # zero is a mark, not an empty box

    def test_every_line_is_checked_before_any_is_saved(self):
        w, e = self.approved()
        good = {"student_id": w["students"]["سارة"], "score": 10}
        for bad in ({"student_id": w["students"]["نورة"], "score": "abc"}, {"student_id": w["students"]["نورة"], "score": -1}, {"student_id": w["students"]["نورة"], "score": 20.5},
                    {"student_id": w["students"]["نورة"], "score": "nan"}, {"student_id": w["students"]["نورة"], "score": "inf"}, "not a line", 5, None):
            r = self.api("put", f"/api/exams/{e['id']}/scores", {"scores": [good, bad]})
            self.assertEqual(r.status_code, 400, bad)
        for body in ({}, {"scores": []}, {"scores": "x"}, {"scores": [good] * 501}):
            self.assertEqual(self.api("put", f"/api/exams/{e['id']}/scores", body).status_code, 400, str(body)[:30])
        self.assertEqual(self.count("SELECT COUNT(*) FROM exam_scores"), 0)          # the good line next to a bad one was not saved
        self.scores(e["id"], [{"student_id": w["students"]["سارة"], "score": 20}])          # the full mark is allowed

    def test_the_note_is_cut_and_trimmed(self):
        w, e = self.approved()
        self.scores(e["id"], [{"student_id": w["students"]["سارة"], "score": 5, "note": "  " + "ن" * 300}])
        self.assertEqual(len(self.rows("SELECT note FROM exam_scores")[0]["note"]), 100)

    def test_a_student_of_another_class_is_refused_and_nothing_is_saved(self):
        w, e = self.approved()
        other = self.world(klass="الصف الأول ب", subject="الفيزياء", names=("ريم", "جود"))
        foreign = other["students"]["ريم"]
        r = self.api("put", f"/api/exams/{e['id']}/scores", {"scores": [{"student_id": w["students"]["سارة"], "score": 10}, {"student_id": foreign, "score": 10}]})
        self.assertEqual(r.status_code, 404)
        self.assertEqual(self.count("SELECT COUNT(*) FROM exam_scores"), 0)
        self.assertEqual(self.api("put", f"/api/exams/{e['id']}/scores", {"scores": [{"student_id": 99999, "score": 1}]}).status_code, 404)

    def test_marks_are_tied_to_the_class_of_the_exam(self):
        w, e = self.approved()
        self.scores(e["id"], [{"student_id": i, "score": 10} for i in w["students"].values()])
        self.assertEqual({r["class_id"] for r in self.rows("SELECT class_id FROM exam_scores WHERE exam_id = ?", e["id"])}, {w["cid"]})

    def test_a_deleted_student_takes_his_mark_with_him_and_the_others_stay(self):
        w, e = self.approved()
        self.scores(e["id"], [{"student_id": i, "score": 10} for i in w["students"].values()])
        self.api("delete", f"/api/students/{w['students']['سارة']}")
        d = self.c.get(f"/api/exams/{e['id']}/scores").get_json()
        self.assertEqual((len(d["students"]), d["stats"]["entered"], d["stats"]["students"]), (3, 3, 3))

    def test_the_csv_opens_in_excel_with_its_arabic_and_cannot_run_a_formula(self):
        w, e = self.approved(title="اختبار الشهر")
        s = w["students"]
        self.app.db.execute("UPDATE students SET name = ? WHERE id = ?", ("=HYPERLINK(\"http://x\")", s["مها"]))
        self.app.db.commit()
        self.scores(e["id"], [{"student_id": s["سارة"], "score": 17.5, "note": "+1 مشاركة"}, {"student_id": s["نورة"], "absent": True}, {"student_id": s["مها"], "score": 8, "note": "@خطأ"}])
        r = self.c.get(f"/api/exams/{e['id']}/scores/csv")
        self.assertEqual(r.status_code, 200)
        self.assertIn("text/csv", r.headers["Content-Type"])
        self.assertIn("attachment", r.headers["Content-Disposition"])
        raw = r.get_data(as_text=True)
        self.assertTrue(raw.startswith("﻿"))
        rows = list(csv.reader(io.StringIO(raw.lstrip("﻿"))))
        self.assertEqual(rows[0], ["اختبار الشهر", "الصف الأول أ", "الدرجة الكلية: 20"])
        self.assertEqual(rows[1], ["الطالبة", "الدرجة", "النسبة", "غائبة", "ملاحظة"])
        by = {r[0]: r for r in rows[2:]}
        self.assertEqual(by["سارة"], ["سارة", "17.5", "88", "", "'+1 مشاركة"])          # 87.5 rounds to 88, and a note that starts like a formula is written as text
        self.assertEqual(by["نورة"], ["نورة", "", "", "نعم", ""])          # an empty note stays empty: no stray apostrophe
        self.assertEqual(by["ليان"], ["ليان", "", "", "", ""])
        self.assertEqual(by["'=HYPERLINK(\"http://x\")"][1:], ["8", "40", "", "'@خطأ"])
        self.assertEqual(len(rows), 6)

    def test_the_marks_of_a_deleted_exam_go_with_it(self):
        w, e = self.approved()
        self.scores(e["id"], [{"student_id": i, "score": 10} for i in w["students"].values()])
        self.assertEqual(self.api("delete", f"/api/exams/{e['id']}").status_code, 200)
        self.assertEqual(self.tables(), [0, 0, 0])
        self.assertEqual(self.count("SELECT COUNT(*) FROM students"), 4)          # the students are still hers


# ================================================================ WhatsApp
class Sharing(Phase5):
    def ready(self, **over):
        w = self.world()
        e = self.new_exam(w, title="اختبار الفترة الأولى", date="2026-10-04", minutes=45, total=20, **over)
        self.add_q(e["id"], "qa", "ما اسم أكبر محيط على الأرض؟", "ANSWER-QA-الهادئ")
        self.add_q(e["id"], "essay", "اشرحي دورة الماء في الطبيعة.", "ANSWER-ESSAY-التبخر")
        self.add_q(e["id"], "cloze", "أكبر قارة في العالم هي _____", "ANSWER-CLOZE-آسيا")
        self.approve(e["id"])
        return w, self.exam(e["id"])

    def share(self, eid, c=None):
        r = (c or self.c).get(f"/api/exams/{eid}/share")
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def test_the_announcement_says_what_when_how_long_and_how_many_marks(self):
        w, e = self.ready()
        d = self.share(e["id"])
        a = d["announce"]
        self.assertIn("اختبار الفترة الأولى", a)
        for needle in ("الأحد 4 أكتوبر 2026", "45 دقيقة", "الدرجة الكلية: " + e["total_text"], w["title"][w["lessons"][0]], w["title"][w["lessons"][1]], "العلوم", "الصف الأول أ"):
            self.assertIn(needle, a, needle)
        for q in e["questions"]:
            self.assertNotIn(q["question"], a)
        for name in NAMES:
            self.assertNotIn(name, a)
        self.assertNotIn("http", a)          # no phone number and no link: only the facts

    def test_the_text_of_the_exam_has_the_questions_in_sections_and_no_answers(self):
        w, e = self.ready()
        t = self.share(e["id"])["text"]
        self.assertIn("*السؤال الأول:", t)
        for q in e["questions"]:
            if q["kind"] != "cloze":
                self.assertIn(q["question"].replace("_____", "........"), t, q["question"])
        for answer in ("ANSWER-QA-الهادئ", "ANSWER-ESSAY-التبخر", "ANSWER-CLOZE-آسيا"):
            self.assertNotIn(answer, t)
        self.assertIn("أكبر قارة في العالم هي ........", t)          # the blank is dots the phone shows well
        self.assertNotIn("_____", t)
        self.assertRegex(t, r"\( \) ")          # a true/false line has its brackets
        self.assertIn("   أ) ", t)          # the options of a multiple choice are on a line under it
        first = self.of(e, "mcq")[0]
        self.assertIn(f"1) {first['question'].replace('_____', '........')} [{first['marks_text']}]", t)
        self.assertIn("(" + textfmt.marks(sum(q["marks"] for q in self.of(e, "mcq"))) + ")", t)

    def test_the_links_open_whatsapp_with_the_text_already_written(self):
        w, e = self.ready()
        d = self.share(e["id"])
        for text, url in ((d["announce"], d["announce_wa"]), (d["text"], d["text_wa"])):
            self.assertTrue(url.startswith("https://wa.me/?text="))
            from urllib.parse import parse_qs, urlparse
            self.assertEqual(parse_qs(urlparse(url).query)["text"][0], text)          # the exact text, nothing more
        self.assertFalse(d["text_too_long"])

    def test_the_group_link_of_the_class_comes_with_it(self):
        w, e = self.ready()
        self.assertEqual(self.share(e["id"])["group"], "")
        r = self.api("patch", f"/api/classes/{w['cid']}", {"whatsapp": "https://chat.whatsapp.com/AbCdEf123456?mode=x"})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(self.share(e["id"])["group"], "https://chat.whatsapp.com/AbCdEf123456")

    def test_a_text_too_long_for_a_link_is_flagged_and_gets_no_link(self):
        w, e = self.ready()
        with mock.patch.object(share, "MAX_TEXT", 60):
            d = self.share(e["id"])
        self.assertTrue(d["text_too_long"])
        self.assertEqual(d["text_wa"], "")
        self.assertTrue(d["announce_wa"].endswith("%E2%80%A6"))          # the announcement is cut with an ellipsis

    def test_a_draft_can_be_shared_too_for_a_look_before_approving(self):
        w = self.world()
        e = self.new_exam(w)
        d = self.share(e["id"])
        self.assertTrue(d["announce"] and d["text"])


# ================================================================ copy, delete, list
class Keeping(Phase5):
    def test_the_same_questions_for_another_class_as_a_draft_without_the_marks_of_students(self):
        w = self.world()
        other = self.world(klass="الصف الأول ب", subject="الفيزياء", names=("ريم", "جود"))
        e = self.new_exam(w, total=20, date="2026-10-04", minutes=40, header=HEAD)
        self.approve(e["id"])
        self.scores(e["id"], [{"student_id": w["students"]["سارة"], "score": 10}])
        r = self.post(e["id"], "copy", {"class_id": other["cid"]}, status=201)["exam"]
        self.assertEqual((r["status"], r["date"], r["class"]["id"], r["minutes"], r["header"]), ("draft", "", other["cid"], 40, HEAD))
        self.assertEqual(r["title"], f"{e['title']} ({'الصف الأول ب'})")
        self.assertEqual([(q["question"], q["marks"], q["kind"], q["position"]) for q in r["questions"]], [(q["question"], q["marks"], q["kind"], q["position"]) for q in e["questions"]])
        self.assertEqual(r["total"], e["total"])
        self.assertEqual(sum(r["spares"].values()), 0)          # the alternatives belong to the first exam
        self.assertEqual(self.count("SELECT COUNT(*) FROM exam_scores WHERE exam_id = ?", r["id"]), 0)
        self.assertEqual(self.count("SELECT COUNT(*) FROM exam_scores WHERE exam_id = ?", e["id"]), 1)
        self.assertEqual(self.exam(e["id"])["status"], "approved")          # the first is untouched
        for q in r["questions"]:
            self.assertIn(q["origin"], ("auto", "manual", "ai"))
        self.assertEqual(self.api("post", f"/api/exams/{e['id']}/copy", {"class_id": 99999}).status_code, 404)
        self.assertEqual(self.api("post", f"/api/exams/{e['id']}/copy", {}).status_code, 404)

    def test_the_copy_to_the_same_class_is_allowed_and_independent(self):
        w = self.world()
        e = self.new_exam(w)
        c = self.post(e["id"], "copy", {"class_id": w["cid"]}, status=201)["exam"]
        self.post(c["id"], f"questions/{c['questions'][0]['id']}", method="delete")
        self.assertEqual((self.exam(e["id"])["count"], self.exam(c["id"])["count"]), (13, 12))

    def test_the_list_shows_the_newest_first_and_can_be_filtered_by_class(self):
        w = self.world()
        other = self.world(klass="الصف الأول ب", subject="الفيزياء", names=("ريم", "جود"))
        a, b, c = self.new_exam(w)["id"], self.new_exam(other)["id"], self.new_exam(w)["id"]
        self.assertEqual([x["id"] for x in self.c.get("/api/exams").get_json()["exams"]], [c, b, a])
        self.assertEqual([x["id"] for x in self.c.get(f"/api/exams?class_id={w['cid']}").get_json()["exams"]], [c, a])
        self.assertEqual([x["id"] for x in self.c.get(f"/api/exams?class_id={other['cid']}").get_json()["exams"]], [b])
        self.assertEqual(self.c.get("/api/exams?class_id=99999").status_code, 404)
        row = self.c.get("/api/exams").get_json()["exams"][0]
        self.assertNotIn("questions", row)          # a list line is light: no questions in it
        self.assertEqual((row["count"], row["status"]), (13, "draft"))
        self.assertNotIn("scores", row)          # the figures of marks are for an approved exam

    def test_deleting_an_exam_takes_its_questions_with_it_and_only_its_own(self):
        w = self.world()
        a, b = self.new_exam(w)["id"], self.new_exam(w)["id"]
        before = self.count("SELECT COUNT(*) FROM exam_questions WHERE exam_id = ?", b)
        self.assertEqual(self.api("delete", f"/api/exams/{a}").status_code, 200)
        self.assertEqual(self.count("SELECT COUNT(*) FROM exam_questions WHERE exam_id = ?", a), 0)
        self.assertEqual(self.count("SELECT COUNT(*) FROM exam_questions WHERE exam_id = ?", b), before)
        self.assertEqual(self.api("delete", f"/api/exams/{a}").status_code, 404)

    def test_an_approved_exam_shows_the_figures_of_its_marks_in_the_list(self):
        w = self.world()
        e = self.new_exam(w, total=20)
        self.approve(e["id"])
        row = self.c.get("/api/exams").get_json()["exams"][0]
        self.assertEqual(row["scores"]["students"], 4)
        self.assertEqual((row["scores"]["entered"], row["scores"]["missing"]), (0, 4))


# ================================================================ the smart reader, only when it is on for her and inside her usual allowance
class SmartReader(Phase5):
    ITEMS = [{"kind": "qa", "question": "ما وظيفة الريبوسومات داخل الخلية الحية؟", "answer": "تصنع البروتينات التي تحتاجها الخلية للنمو والإصلاح",
              "options": [], "evidence": "الريبوسومات تصنع البروتينات التي تحتاجها الخلية للنمو والإصلاح."},
             {"kind": "qa", "question": "ماذا يفعل الغشاء الخلوي بالمواد التي تدخل الخلية؟", "answer": "ينظم دخولها وخروجها", "options": [],
              "evidence": "الغشاء الخلوي ينظم دخول المواد وخروجها من الخلية الحية."},
             {"kind": "qa", "question": "أين توجد المادة الوراثية داخل الخلية الحية؟", "answer": "في النواة", "options": [],
              "evidence": "النواة هي مركز التحكم في الخلية وتحتوي على المادة الوراثية."},
             {"kind": "tf", "question": "الخلايا الحيوانية لها جدار خلوي", "answer": "خطأ", "options": [], "evidence": "الخلايا الحيوانية لا تحتوي على جدار خلوي"}]

    def turn_on(self, quota=40):
        self.app.db.execute("UPDATE users SET plan_code = 'monthly', plan_expires = ?, ai_consent = 1 WHERE email = 'a@example.com'", (9e9,))
        self.app.db.execute("UPDATE plans SET ai_quota = ? WHERE code = 'monthly'", (quota,))
        self.app.db.commit()
        self.app.cfg.ai_provider, self.app.cfg.anthropic_key = "claude", "TEST-KEY"
        self.addCleanup(setattr, self.app.cfg, "ai_provider", "offline")
        self.addCleanup(setattr, self.app.cfg, "anthropic_key", "")

    def stub(self, calls, items=None):
        def post(inner, payload):
            calls.append(payload["model"])
            return {"content": [{"type": "text", "text": json.dumps(self.ITEMS if items is None else items, ensure_ascii=False)}], "usage": {"input_tokens": 3000, "output_tokens": 1500}}
        return post

    def one_lesson(self):
        w = self.world()
        return w, self.new_exam(w, lessons=[w["lessons"][0]], wanted={"qa": 1})

    def test_it_is_off_by_default_and_the_screen_is_told(self):
        w, e = self.one_lesson()
        self.assertFalse(e["can_ask_ai"])
        r = self.api("post", f"/api/exams/{e['id']}/more", {"kind": "qa"})
        self.assertEqual(r.status_code, 409)
        self.assertIn("غير مفعّل", r.get_json()["error"])
        self.assertEqual(self.count("SELECT COUNT(*) FROM ai_usage"), 0)

    def test_it_adds_spares_of_the_kind_asked_and_every_call_is_counted(self):
        self.turn_on()
        w, e = self.one_lesson()
        self.assertTrue(e["can_ask_ai"])
        calls = []
        orig = aiq.ClaudeProvider._post
        aiq.ClaudeProvider._post = self.stub(calls)
        try:
            d = self.post(e["id"], "more", {"kind": "qa"})
        finally:
            aiq.ClaudeProvider._post = orig
        self.assertEqual(calls, ["claude-haiku-5-5"])
        self.assertEqual(d["added"], 3)          # the true/false one is another kind
        spares = self.exam_rows(e["id"], "spare")
        added = [r for r in spares if r["origin"] == "ai"]
        self.assertEqual((len(added), {r["kind"] for r in added}, {r["source"] for r in added}), (3, {"qa"}, {"القارئ الذكي"}))
        self.assertEqual(self.exam(e["id"])["count"], 1)          # the exam itself did not change: they wait as alternatives
        use = self.rows("SELECT * FROM ai_usage")
        self.assertEqual(len(use), 1)
        self.assertEqual((use[0]["user_id"], use[0]["lesson_id"], use[0]["input_tokens"], use[0]["output_tokens"]), (1, None, 3000, 1500))
        self.assertEqual(use[0]["cost"], billing.cost_halalas("claude-haiku-5-5", 3000, 1500))
        # one of them is now swapped in with the usual replace
        r = self.post(e["id"], f"questions/{self.of(self.exam(e['id']), 'qa')[0]['id']}/replace")
        self.assertEqual(r["question"]["kind"], "qa")

    def test_what_reads_like_a_question_already_there_is_not_added_twice(self):
        self.turn_on()
        w, e = self.one_lesson()
        orig = aiq.ClaudeProvider._post
        aiq.ClaudeProvider._post = self.stub([])
        try:
            first = self.post(e["id"], "more", {"kind": "qa"})["added"]
            second = self.post(e["id"], "more", {"kind": "qa"})["added"]
        finally:
            aiq.ClaudeProvider._post = orig
        self.assertEqual((first, second), (3, 0))

    def test_the_usual_allowance_stops_it(self):
        self.turn_on(quota=1)
        w, e = self.one_lesson()
        calls = []
        orig = aiq.ClaudeProvider._post
        aiq.ClaudeProvider._post = self.stub(calls)
        try:
            self.post(e["id"], "more", {"kind": "qa"})
            r = self.api("post", f"/api/exams/{e['id']}/more", {"kind": "qa"})
            self.assertEqual(r.status_code, 409)
            self.assertIn("حصة", r.get_json()["error"])
        finally:
            aiq.ClaudeProvider._post = orig
        self.assertEqual(len(calls), 1)          # the second request never reached the paid service
        self.assertEqual(self.count("SELECT COUNT(*) FROM ai_usage"), 1)

    def test_without_her_agreement_or_with_the_manager_switch_off_it_never_runs(self):
        self.turn_on()
        w, e = self.one_lesson()
        calls = []
        orig = aiq.ClaudeProvider._post
        aiq.ClaudeProvider._post = self.stub(calls)
        try:
            self.app.db.execute("UPDATE users SET ai_consent = 0")
            self.app.db.commit()
            self.assertEqual(self.api("post", f"/api/exams/{e['id']}/more", {"kind": "qa"}).status_code, 409)
            self.app.db.execute("UPDATE users SET ai_consent = 1")
            self.app.db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES ('ai_enabled', '0')")
            self.app.db.commit()
            self.assertEqual(self.api("post", f"/api/exams/{e['id']}/more", {"kind": "qa"}).status_code, 409)
            self.app.db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES ('ai_enabled', '1')")
            self.app.db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES ('ai_cap_sar', '0.01')")          # the month's cap of the whole site
            self.app.db.commit()
            self.assertEqual(self.api("post", f"/api/exams/{e['id']}/more", {"kind": "qa"}).status_code, 409)
        finally:
            aiq.ClaudeProvider._post = orig
        self.assertEqual(calls, [])

    def test_a_bad_kind_is_refused_and_a_failed_call_says_so_without_charging_for_nothing(self):
        self.turn_on()
        w, e = self.one_lesson()
        for bad in ("x", "", None):
            self.assertEqual(self.api("post", f"/api/exams/{e['id']}/more", {"kind": bad}).status_code, 400)
        orig = aiq.ClaudeProvider._post
        aiq.ClaudeProvider._post = lambda inner, payload: (_ for _ in ()).throw(OSError("network down"))
        try:
            r = self.api("post", f"/api/exams/{e['id']}/more", {"kind": "qa"})
        finally:
            aiq.ClaudeProvider._post = orig
        self.assertEqual(r.status_code, 502)
        self.assertIn("تعذّر", r.get_json()["error"])
        self.assertEqual(self.exam(e["id"])["count"], 1)

    def test_the_exhausted_message_offers_it_only_when_it_is_on(self):
        self.turn_on()
        w, e = self.one_lesson()
        for _ in range(100):
            r = self.api("post", f"/api/exams/{e['id']}/spare", {"kind": "qa"})
            if r.status_code == 409:
                break
        self.assertEqual(r.status_code, 409)
        self.assertIn("القارئ الذكي", r.get_json()["error"])
        q = self.of(self.exam(e["id"]), "qa")[0]
        r = self.api("post", f"/api/exams/{e['id']}/questions/{q['id']}/replace", {})
        self.assertEqual((r.status_code, r.get_json()["can_ask_ai"]), (409, True))


# ================================================================ walls
class Walls(Phase5):
    """Every route of the exams, asked by another teacher, behaves as if the exam did not exist; every route asked by the same teacher about another class stays inside its class."""

    def setUp(self):
        super().setUp()
        self.w = self.world(texts=(LESSON1, LESSON2, LESSON3))
        self.c2 = self.second_teacher()
        self.w2 = self.world(c=self.c2, klass="الصف الأول أ", subject="العلوم", names=NAMES)          # the very same names for a class, a subject and the students
        e = self.new_exam(self.w, total=20, header=HEAD)
        self.add_q(e["id"], "qa", "ما اسم أكبر محيط على الأرض؟", "ANSWER-QA-الهادئ")
        self.approve(e["id"])
        self.scores(e["id"], [{"student_id": self.w["students"]["سارة"], "score": 17, "note": "ملاحظة سرية"}])
        self.e = self.exam(e["id"])
        self.q = self.e["questions"][0]
        self.spare = self.exam_rows(e["id"], "spare")[0]["id"]
        self.snapshot = self.picture()

    def calls(self, eid, qid, spare, student, cls):
        return [("get", f"/exams/{eid}", None), ("get", f"/exams/{eid}/print", None), ("get", f"/exams/{eid}/key", None),
                ("get", f"/api/exams/{eid}", None), ("patch", f"/api/exams/{eid}", {"title": "هجوم"}), ("delete", f"/api/exams/{eid}", None),
                ("post", f"/api/exams/{eid}/copy", {"class_id": cls}),
                ("post", f"/api/exams/{eid}/questions", {"kind": "qa", "question": "ما هي عاصمة السعودية؟", "answer": "الرياض"}),
                ("patch", f"/api/exams/{eid}/questions/{qid}", {"marks": 2}), ("delete", f"/api/exams/{eid}/questions/{qid}", None),
                ("post", f"/api/exams/{eid}/questions/{qid}/replace", {}), ("post", f"/api/exams/{eid}/questions/{qid}/move", {"dir": 1}),
                ("post", f"/api/exams/{eid}/questions/{spare}/replace", {}), ("patch", f"/api/exams/{eid}/questions/{spare}", {"marks": 2}),
                ("post", f"/api/exams/{eid}/spare", {"kind": "tf"}), ("post", f"/api/exams/{eid}/marks", {"total": 30}),
                ("post", f"/api/exams/{eid}/approve", {}), ("post", f"/api/exams/{eid}/unapprove", {}), ("post", f"/api/exams/{eid}/more", {"kind": "qa"}),
                ("get", f"/api/exams/{eid}/scores", None), ("put", f"/api/exams/{eid}/scores", {"scores": [{"student_id": student, "score": 1}]}),
                ("get", f"/api/exams/{eid}/scores/csv", None), ("get", f"/api/exams/{eid}/share", None)]

    def picture(self):
        """Everything stored about her exam: the exam, its questions and spares, its marks, and what the screens read of them."""
        eid = self.e["id"]
        return (self.exam(eid), self.c.get(f"/api/exams/{eid}/scores").get_json(), self.rows("SELECT * FROM exams WHERE id = ?", eid),
                self.rows("SELECT * FROM exam_questions WHERE exam_id = ? ORDER BY id", eid), self.rows("SELECT * FROM exam_scores WHERE exam_id = ? ORDER BY id", eid))

    def unchanged(self):
        self.assertEqual(self.picture(), self.snapshot)

    def test_another_teacher_reads_and_changes_nothing_of_the_exam_every_route_is_not_found(self):
        for method, url, data in self.calls(self.e["id"], self.q["id"], self.spare, self.w["students"]["سارة"], self.w2["cid"]):
            r = getattr(self.c2, method)(url, json=data, headers={"X-CSRF": self.token(self.c2)}) if method != "get" else self.c2.get(url)
            self.assertEqual(r.status_code, 404, (method, url))
            self.assertNotIn("ANSWER-QA", r.get_data(as_text=True))
            self.assertNotIn("ملاحظة سرية", r.get_data(as_text=True))
        self.unchanged()

    def test_another_teacher_sees_only_her_own_exams(self):
        self.assertEqual(self.c2.get("/api/exams").get_json()["exams"], [])
        mine = self.new_exam(self.w2, c=self.c2)
        self.assertEqual([x["id"] for x in self.c2.get("/api/exams").get_json()["exams"]], [mine["id"]])
        self.assertEqual(self.c2.get(f"/api/exams?class_id={self.w['cid']}").status_code, 404)
        self.assertEqual([x["id"] for x in self.c.get("/api/exams").get_json()["exams"]], [self.e["id"]])

    def test_another_teacher_cannot_build_an_exam_from_anything_of_hers(self):
        base = {"class_id": self.w2["cid"], "subject_id": self.w2["sid"], "lessons": self.w2["lessons"][:2], "wanted": {"mcq": 2}}
        self.assertEqual(self.api("post", "/api/exams", base, self.c2).status_code, 201)
        upload = self.upload(self.c, "cell.pptx", FX.pptx_bytes())
        lid = int(re.search(r"/lessons/(\d+)", upload.headers["Location"]).group(1))
        for change in ({"class_id": self.w["cid"]}, {"subject_id": self.w["sid"]}, {"lessons": [self.w["lessons"][0]]}, {"lessons": [], "units": [self.w["units"][0]]},
                       {"lessons": [], "uploads": [lid]}, {"lessons": self.w2["lessons"][:1] + self.w["lessons"][:1]}):
            r = self.api("post", "/api/exams", {**base, **change}, self.c2)
            self.assertEqual(r.status_code, 404, change)
        self.assertEqual(self.count("SELECT COUNT(*) FROM exams WHERE user_id = 2"), 1)          # only the one she was entitled to
        for url in (f"/api/exams/sources?class_id={self.w['cid']}", f"/api/exams/sources?class_id={self.w2['cid']}&subject_id={self.w['sid']}"):
            self.assertEqual(self.c2.get(url).status_code, 404, url)
        lessons = self.c2.get(f"/api/exams/sources?class_id={self.w2['cid']}&subject_id={self.w2['sid']}").get_json()
        self.assertEqual(lessons["uploads"], [])          # her own files are not offered to anyone else
        self.unchanged()

    def test_another_teacher_cannot_mix_her_exam_with_a_question_a_class_or_a_student_of_hers(self):
        mine = self.new_exam(self.w2, c=self.c2, total=10)
        for method, tail, data in (("patch", "", {"marks": 2}), ("delete", "", {}), ("post", "/replace", {}), ("post", "/move", {"dir": 1})):
            r = self.api(method, f"/api/exams/{mine['id']}/questions/{self.q['id']}{tail}", data, self.c2)          # a question of hers, through an exam of her own
            self.assertEqual(r.status_code, 404, (method, tail))
        self.approve(mine["id"], c=self.c2)
        self.assertEqual(self.api("post", f"/api/exams/{mine['id']}/copy", {"class_id": self.w["cid"]}, self.c2).status_code, 404)
        self.assertEqual(self.api("put", f"/api/exams/{mine['id']}/scores", {"scores": [{"student_id": self.w["students"]["سارة"], "score": 1}]}, self.c2).status_code, 404)
        self.assertEqual(self.count("SELECT COUNT(*) FROM exam_scores WHERE exam_id = ?", mine["id"]), 0)
        # even a student with the very same name in her own class is a different person
        ok = self.scores(mine["id"], [{"student_id": self.w2["students"]["سارة"], "score": 1}], c=self.c2)
        self.assertEqual(ok["stats"]["entered"], 1)
        self.unchanged()

    def test_a_question_is_reached_only_through_its_own_exam_even_by_the_same_teacher(self):
        w = self.w
        other = self.new_exam(w)          # a second exam of hers, in the very same class
        for method, tail, data in (("patch", "", {"marks": 2}), ("delete", "", {}), ("post", "/replace", {}), ("post", "/move", {"dir": 1})):
            r = self.api(method, f"/api/exams/{other['id']}/questions/{self.q['id']}{tail}", data)
            self.assertEqual(r.status_code, 404, (method, tail))
        self.assertEqual(self.api("patch", f"/api/exams/{other['id']}/questions/{self.spare}", {"marks": 2}).status_code, 404)
        self.unchanged()
        self.assertEqual(self.exam(other["id"])["count"], 13)

    def test_the_same_teachers_other_class_cannot_read_or_write_the_marks_of_this_one(self):
        other = self.world(klass="الصف الأول ب", subject="الفيزياء", names=("ريم", "جود", "سارة"))          # even a student of the same name
        d = self.c.get(f"/api/exams/{self.e['id']}/scores").get_json()
        self.assertEqual({s["student_id"] for s in d["students"]}, set(self.w["students"].values()))
        self.assertTrue(set(other["students"].values()).isdisjoint({s["student_id"] for s in d["students"]}))
        self.assertNotIn("ريم", self.c.get(f"/api/exams/{self.e['id']}/scores/csv").get_data(as_text=True))
        for foreign in other["students"].values():
            r = self.api("put", f"/api/exams/{self.e['id']}/scores", {"scores": [{"student_id": foreign, "score": 5}]})
            self.assertEqual(r.status_code, 404)
        # the exam of the other class does not show the marks of this one, and a copy starts blank
        b = self.new_exam(other, total=20)
        self.approve(b["id"])
        db = self.c.get(f"/api/exams/{b['id']}/scores").get_json()
        self.assertEqual({s["name"] for s in db["students"]}, {"ريم", "جود", "سارة"})
        self.assertEqual([s["score"] for s in db["students"]], [None] * 3)          # «سارة» of the other class has no mark: the mark belongs to the other «سارة»
        copy = self.post(self.e["id"], "copy", {"class_id": other["cid"]}, status=201)["exam"]
        self.approve(copy["id"])
        self.assertEqual([s["score"] for s in self.c.get(f"/api/exams/{copy['id']}/scores").get_json()["students"]], [None] * 3)
        self.assertEqual([x["id"] for x in self.c.get(f"/api/exams?class_id={other['cid']}").get_json()["exams"]], [copy["id"], b["id"]])
        for text in (self.share_text(b["id"]), self.share_text(copy["id"])):
            self.assertNotIn("الصف الأول أ", text.replace(self.e["title"], ""))
        self.unchanged()

    def share_text(self, eid):
        d = self.c.get(f"/api/exams/{eid}/share").get_json()
        return d["announce"] + d["text"]

    def test_nothing_works_without_signing_in_or_without_the_form_token(self):
        eid, qid = self.e["id"], self.q["id"]
        anon = self.client()
        for method, url, data in self.calls(eid, qid, self.spare, 1, 1):
            r = anon.get(url) if method == "get" else getattr(anon, method)(url, json=data, headers={"X-CSRF": self.token(anon)})
            if url.startswith("/api/"):
                self.assertEqual(r.status_code, 401, (method, url))
            else:
                self.assertEqual(r.status_code, 302, (method, url))
        for method, url, data in self.calls(eid, qid, self.spare, self.w["students"]["سارة"], self.w["cid"]):
            if method in MUTATING:
                r = getattr(self.c, method)(url, json=data)          # signed in, but no token
                self.assertEqual(r.status_code, 403, (method, url))
        self.assertEqual(anon.get("/api/exams").status_code, 401)
        self.assertEqual(anon.post("/api/exams", json={}, headers={"X-CSRF": self.token(anon)}).status_code, 401)
        self.unchanged()


# ================================================================ the old database
class Upgrade(unittest.TestCase):
    def seed(self, db):
        db.execute("INSERT INTO users(id, email, name, pass_hash, created_at) VALUES (1, 'a@example.com', 'معلمة', 'x', 1)")
        db.execute("INSERT INTO classes(id, user_id, name, created_at) VALUES (1, 1, 'الصف الأول', 1)")
        db.execute("INSERT INTO students(id, user_id, class_id, name, created_at) VALUES (1, 1, 1, 'سارة', 1)")
        db.execute("INSERT INTO results(user_id, student_id, deck_title, correct, created_at) VALUES (1, 1, 'عرض', 1, 1)")
        db.commit()

    def test_a_database_of_version_4_gets_the_three_tables_and_loses_nothing(self):
        with tempfile.TemporaryDirectory() as tmp:
            app = create_app(INSTANCE=tmp, BACKGROUND=False)
            db = app.db
            self.seed(db)
            for t in ("exam_scores", "exam_questions", "exams"):          # a database as version 4.x left it
                db.execute(f"DROP TABLE {t}")
            db.commit()
            self.assertEqual(db.execute("SELECT COUNT(*) FROM sqlite_master WHERE name LIKE 'exam%'").fetchone()[0], 0)
            dbm.init(db)
            dbm.init(db)          # and again: nothing is added twice
            self.assertEqual(sorted(r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type = 'table' AND name LIKE 'exam%'")), ["exam_questions", "exam_scores", "exams"])
            self.assertEqual([db.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in ("users", "classes", "students", "results")], [1, 1, 1, 1])
            db.close()

    def test_the_tables_refuse_what_makes_no_sense_and_follow_their_parents(self):
        with tempfile.TemporaryDirectory() as tmp:
            app = create_app(INSTANCE=tmp, BACKGROUND=False)
            db = app.db
            self.seed(db)
            exam = "INSERT INTO exams(id, user_id, class_id, title, status, created_at, updated_at) VALUES (%s, 1, 1, 'ا', %s, 1, 1)"
            with self.assertRaises(sqlite3.IntegrityError):
                db.execute(exam % ("1", "'published'"))
            db.execute(exam % ("1", "'draft'"))
            q = "INSERT INTO exam_questions(exam_id, user_id, kind, question, state, origin, created_at) VALUES (1, 1, ?, 'س', ?, ?, 1)"
            for kind, state, origin in (("essayy", "used", "auto"), ("qa", "gone", "auto"), ("qa", "used", "robot")):
                with self.assertRaises(sqlite3.IntegrityError, msg=(kind, state, origin)):
                    db.execute(q, (kind, state, origin))
            db.execute(q, ("qa", "used", "auto"))
            db.execute("INSERT INTO exam_scores(exam_id, user_id, class_id, student_id, score, updated_at) VALUES (1, 1, 1, 1, 5, 1)")
            with self.assertRaises(sqlite3.IntegrityError):          # a student has one line per exam
                db.execute("INSERT INTO exam_scores(exam_id, user_id, class_id, student_id, score, updated_at) VALUES (1, 1, 1, 1, 6, 1)")
            with self.assertRaises(sqlite3.IntegrityError):          # and the exam must exist
                db.execute("INSERT INTO exam_scores(exam_id, user_id, class_id, student_id, score, updated_at) VALUES (77, 1, 1, 1, 6, 1)")
            db.commit()
            db.execute("DELETE FROM students WHERE id = 1")
            self.assertEqual(db.execute("SELECT COUNT(*) FROM exam_scores").fetchone()[0], 0)
            db.execute("DELETE FROM classes WHERE id = 1")
            self.assertEqual([db.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in ("exams", "exam_questions")], [0, 0])
            db.close()


if __name__ == "__main__":
    unittest.main()
