import io
import json
import re
import tempfile
import unittest

from app import aiq, create_app
from app import grounding as G
from tests import fixtures as F


class Base(unittest.TestCase):
    def setUp(self):
        from app import auth, lessons
        auth.register_limit.hits.clear()
        auth.register_day_limit.hits.clear()
        lessons.upload_limit.hits.clear()
        auth.login_limit.hits.clear()
        self.tmp = tempfile.TemporaryDirectory()
        self.app = create_app(INSTANCE=self.tmp.name, BACKGROUND=False)
        self.addCleanup(self.tmp.cleanup)
        self.addCleanup(self.app.db.close)

    def client(self):
        return self.app.test_client()

    def token(self, c):
        html = c.get("/login").get_data(as_text=True)
        return re.search(r'name="csrf" content="([^"]+)"', html).group(1)

    def register(self, c, email="a@example.com", name="معلمة", pw="Teacher-pass-1"):
        t = self.token(c)
        return c.post("/register", data={"_csrf": t, "name": name, "email": email, "password": pw, "password2": pw, "terms": "1"})

    def j(self, c, method, url, data=None):
        t = self.token(c)
        return getattr(c, method)(url, json=data, headers={"X-CSRF": t})

    def upload(self, c, name, data, title=""):
        t = self.token(c)
        return c.post("/lessons/upload", data={"_csrf": t, "title": title, "lesson": (io.BytesIO(data), name)}, content_type="multipart/form-data")

    def teacher_with_lesson(self, c=None, email="a@example.com"):
        c = c or self.client()
        self.register(c, email)
        r = self.upload(c, "cell.pptx", F.pptx_bytes())
        lid = int(re.search(r"/lessons/(\d+)", r.headers["Location"]).group(1))
        return c, lid


class AuthTests(Base):
    def test_register_login_logout(self):
        c = self.client()
        r = self.register(c)
        self.assertEqual((r.status_code, r.headers["Location"]), (302, "/dashboard"))
        self.assertEqual(c.get("/dashboard").status_code, 200)
        t = self.token(c)
        c.post("/logout", data={"_csrf": t})
        self.assertEqual(c.get("/dashboard").status_code, 302)
        c2 = self.client()
        t = self.token(c2)
        bad = c2.post("/login", data={"_csrf": t, "email": "a@example.com", "password": "wrong-pass-9"})
        self.assertEqual(bad.status_code, 400)
        ok = c2.post("/login", data={"_csrf": t, "email": "A@Example.com", "password": "Teacher-pass-1"})
        self.assertEqual(ok.status_code, 302)

    def test_validation(self):
        c = self.client()
        t = self.token(c)
        base = {"_csrf": t, "name": "معلمة", "email": "b@example.com", "password": "Teacher-pass-1", "password2": "Teacher-pass-1", "terms": "1"}
        for change, word in (({"email": "nope"}, "بريد"), ({"password": "short", "password2": "short"}, "8 خانات"), ({"password2": "different-1"}, "غير متطابقتين"),
                             ({"terms": ""}, "الشروط"), ({"name": "x"}, "اسمك")):
            r = c.post("/register", data={**base, **change})
            self.assertEqual(r.status_code, 400, change)
            self.assertIn(word, r.get_data(as_text=True))
        self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM users").fetchone()[0], 0)
        from app import auth
        auth.register_limit.hits.clear()
        self.assertEqual(c.post("/register", data=base).status_code, 302)
        self.assertEqual(self.register(self.client(), "b@example.com").status_code, 400)           # same e-mail twice

    def test_password_is_hashed_and_login_is_rate_limited(self):
        c = self.client()
        self.register(c)
        h = self.app.db.execute("SELECT pass_hash FROM users").fetchone()[0]
        self.assertNotIn("Teacher-pass-1", h)
        from app import auth, lessons
        auth.login_limit.hits.clear()
        c2 = self.client()
        t = self.token(c2)
        codes = [c2.post("/login", data={"_csrf": t, "email": "a@example.com", "password": "bad-pass-%d" % i}).status_code for i in range(10)]
        self.assertEqual(codes[-1], 429)
        auth.login_limit.hits.clear()

    def test_every_post_needs_the_form_token(self):
        c = self.client()
        self.assertEqual(c.post("/register", data={"name": "معلمة", "email": "z@example.com", "password": "Teacher-pass-1", "password2": "Teacher-pass-1", "terms": "1"}).status_code, 403)
        self.assertEqual(c.post("/api/me/consent", json={"ai_consent": True}).status_code, 403)


class ExtractTests(Base):
    def test_pptx_pdf_and_image(self):
        c = self.client()
        self.register(c)
        for name, data in (("a.pptx", F.pptx_bytes()), ("a.pdf", F.pdf_bytes()), ("a.png", F.png_bytes())):
            r = self.upload(c, name, data)
            self.assertEqual(r.status_code, 302, name)
        rows = self.app.db.execute("SELECT kind, status, text FROM lessons ORDER BY id").fetchall()
        self.assertEqual([r["status"] for r in rows], ["ready", "ready", "ready"])
        self.assertIn("الخلية هي الوحدة الأساسية", rows[0]["text"])
        self.assertIn("الخلية هي الوحدة الأساسية", rows[1]["text"])                              # an Arabic PDF is read the right way round
        self.assertIn("basic unit of life", rows[2]["text"])

    def test_wrong_files_are_refused(self):
        c = self.client()
        self.register(c)
        for name, data in (("a.exe", b"MZ\x90\x00" * 20), ("a.pdf", b"not a pdf"), ("a.pptx", b"PK-not"), ("a.png", b"GIF89a....."), ("a.txt", b"hello world")):
            r = self.upload(c, name, data)
            self.assertIn("msg=", r.headers["Location"], name)
        self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM lessons").fetchone()[0], 0)
        self.assertEqual(list(self.app.cfg.upload_dir.iterdir()), [])

    def test_an_empty_or_textless_file_fails_with_a_clear_message(self):
        c = self.client()
        self.register(c)
        from pptx import Presentation
        buf = io.BytesIO()
        Presentation().save(buf)
        self.upload(c, "blank.pptx", buf.getvalue())
        row = self.app.db.execute("SELECT status, error FROM lessons").fetchone()
        self.assertEqual(row["status"], "failed")
        self.assertIn("نصًا كافيًا", row["error"])

    def test_size_limit(self):
        c = self.client()
        self.register(c)
        r = self.upload(c, "big.pdf", b"%PDF-" + b"0" * (16 * 1024 * 1024))
        self.assertEqual(r.status_code, 413)


class QuestionTests(Base):
    def test_questions_come_from_the_file_with_their_evidence(self):
        c, lid = self.teacher_with_lesson()
        qs = self.j(c, "get", f"/api/lessons/{lid}/questions").get_json()["questions"]
        self.assertGreaterEqual(len(qs), 12)
        self.assertEqual({q["kind"] for q in qs}, set(aiq.KINDS))
        text = G.norm(self.app.db.execute("SELECT text FROM lessons").fetchone()[0])
        for q in qs:
            self.assertTrue(q["clear"], q)
            self.assertIn(G.norm(q["evidence"]), text)                                          # the quotation is really in the file
            if q["kind"] not in ("tf",):
                self.assertIn(G.norm(q["answer"]), G.norm(q["evidence"]))
            if q["kind"] == "mcq":
                self.assertIn(q["answer"], q["options"])
                self.assertEqual(len(set(q["options"])), 4)

    def test_a_question_whose_answer_is_not_in_the_file_is_flagged_never_trusted(self):
        text = "الخلية هي الوحدة الأساسية للحياة في جميع الكائنات الحية."
        bad = [dict(kind="qa", question="ما عاصمة فرنسا؟", answer="باريس", evidence="باريس عاصمة فرنسا"),
               dict(kind="qa", question="ما الخلية؟", answer="مصنع الطاقة", evidence="الخلية هي الوحدة الأساسية للحياة في جميع الكائنات الحية"),
               dict(kind="qa", question="ما الخلية؟", answer=G.UNCLEAR, evidence="")]
        out = aiq.clean_items(bad, text, strict=True)
        self.assertEqual([q["clear"] for q in out], [0, 0, 0])
        good = aiq.clean_items([dict(kind="qa", question="ما الخلية؟", answer="الوحدة الأساسية للحياة", evidence="الخلية هي الوحدة الأساسية للحياة في جميع الكائنات الحية")], text, True)
        self.assertEqual(good[0]["clear"], 1)

    def test_editing_saves_and_tells_when_the_file_does_not_back_the_answer(self):
        c, lid = self.teacher_with_lesson()
        qs = self.j(c, "get", f"/api/lessons/{lid}/questions").get_json()["questions"]
        q = next(x for x in qs if x["kind"] == "qa")
        r = self.j(c, "patch", f"/api/questions/{q['id']}", {"answer": "مصنع الطاقة في المدينة", "evidence": q["evidence"]})
        self.assertEqual(r.status_code, 200)
        self.assertFalse(r.get_json()["question"]["clear"])
        r = self.j(c, "patch", f"/api/questions/{q['id']}", {"answer": q["answer"], "evidence": q["evidence"]})
        self.assertTrue(r.get_json()["question"]["clear"])
        self.assertEqual(self.j(c, "patch", f"/api/questions/{q['id']}", {"question": "x"}).status_code, 400)
        mc = next(x for x in qs if x["kind"] == "mcq")
        self.assertEqual(self.j(c, "patch", f"/api/questions/{mc['id']}", {"answer": "ليست ضمن الخيارات"}).status_code, 400)

    def test_add_and_delete_manual_questions_and_regenerate_keeps_them(self):
        c, lid = self.teacher_with_lesson()
        r = self.j(c, "post", f"/api/lessons/{lid}/questions", {"kind": "tf", "question": "الشمس تدور حول الأرض", "answer": "خطأ"})
        self.assertEqual(r.status_code, 201)
        mid = r.get_json()["question"]["id"]
        self.assertEqual(self.j(c, "post", f"/api/lessons/{lid}/questions", {"kind": "tf", "question": "abc", "answer": "ربما"}).status_code, 400)
        self.assertEqual(self.j(c, "post", f"/api/lessons/{lid}/questions", {"kind": "mcq", "question": "سؤال", "answer": "أ", "options": ["ب", "ج"]}).status_code, 400)
        self.j(c, "post", f"/api/lessons/{lid}/regenerate")
        ids = [q["id"] for q in self.j(c, "get", f"/api/lessons/{lid}/questions").get_json()["questions"]]
        self.assertIn(mid, ids)
        self.assertEqual(self.j(c, "delete", f"/api/questions/{mid}").status_code, 200)
        self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM questions WHERE id = ?", (mid,)).fetchone()[0], 0)

    def test_a_file_with_no_sentences_gives_a_warning_not_invented_questions(self):
        c = self.client()
        self.register(c)
        from pptx import Presentation
        prs = Presentation()
        s = prs.slides.add_slide(prs.slide_layouts[1])
        s.shapes.title.text = "عنوان فقط"
        s.placeholders[1].text = "كلمة\nأخرى\nثالثة\nرابعة\nخامسة\nسادسة\nسابعة\nثامنة\nتاسعة\nعاشرة"
        buf = io.BytesIO()
        prs.save(buf)
        self.upload(c, "words.pptx", buf.getvalue())
        row = self.app.db.execute("SELECT status, error FROM lessons").fetchone()
        self.assertEqual(row["status"], "ready")
        self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM questions").fetchone()[0], 0)
        self.assertIn("لم نستطع صياغة أسئلة", row["error"])


class IsolationTests(Base):
    def test_one_teacher_never_reaches_another_teachers_things(self):
        a, lid = self.teacher_with_lesson(email="a@example.com")
        qid = self.j(a, "get", f"/api/lessons/{lid}/questions").get_json()["questions"][0]["id"]
        did = self.j(a, "post", f"/api/lessons/{lid}/decks", {"games": ["qa"], "question_ids": [qid]}).get_json()["id"]
        b = self.client()
        self.register(b, "b@example.com")
        for method, url, data in (("get", f"/lessons/{lid}", None), ("get", f"/present/{did}", None), ("get", f"/api/lessons/{lid}", None),
                                  ("get", f"/api/lessons/{lid}/questions", None), ("patch", f"/api/questions/{qid}", {"question": "اختراق"}),
                                  ("delete", f"/api/questions/{qid}", None), ("delete", f"/api/lessons/{lid}", None), ("get", f"/api/decks/{did}/data", None),
                                  ("delete", f"/api/decks/{did}", None), ("post", f"/api/lessons/{lid}/decks", {"games": ["qa"], "question_ids": [qid]}),
                                  ("post", f"/api/lessons/{lid}/questions", {"kind": "qa", "question": "سؤال دخيل", "answer": "x"}), ("post", f"/api/lessons/{lid}/regenerate", None)):
            self.assertEqual(self.j(b, method, url, data).status_code, 404, url)
        self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM lessons").fetchone()[0], 1)
        self.assertNotIn("اختراق", self.app.db.execute("SELECT group_concat(question) FROM questions").fetchone()[0])
        self.assertNotIn("cell", b.get("/dashboard").get_data(as_text=True))

    def test_uploaded_files_are_not_served_publicly(self):
        c, lid = self.teacher_with_lesson()
        name = self.app.db.execute("SELECT stored_name FROM lessons").fetchone()[0]
        anon = self.client()
        for path in (f"/uploads/{name}", f"/static/{name}", f"/instance/uploads/{name}", f"/static/../instance/uploads/{name}", f"/{name}"):
            self.assertEqual(anon.get(path).status_code, 404, path)
        self.assertEqual(anon.get(f"/lessons/{lid}").status_code, 302)
        self.assertEqual(anon.get(f"/api/lessons/{lid}").status_code, 401)


class DeletionTests(Base):
    def test_deleting_a_lesson_removes_file_questions_and_decks(self):
        c, lid = self.teacher_with_lesson()
        qid = self.j(c, "get", f"/api/lessons/{lid}/questions").get_json()["questions"][0]["id"]
        self.j(c, "post", f"/api/lessons/{lid}/decks", {"games": ["wheel"], "question_ids": [qid]})
        self.assertEqual(len(list(self.app.cfg.upload_dir.iterdir())), 1)
        self.assertEqual(self.j(c, "delete", f"/api/lessons/{lid}").status_code, 200)
        for t in ("lessons", "questions", "decks"):
            self.assertEqual(self.app.db.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0], 0, t)
        self.assertEqual(list(self.app.cfg.upload_dir.iterdir()), [])

    def test_deleting_the_account_removes_everything_of_hers_and_only_hers(self):
        a, lid_a = self.teacher_with_lesson(email="a@example.com")
        b, lid_b = self.teacher_with_lesson(email="b@example.com")
        self.assertEqual(self.j(a, "post", "/api/me/delete", {"password": "wrong-one-1"}).status_code, 400)
        self.assertEqual(self.j(a, "post", "/api/me/delete", {"password": "Teacher-pass-1"}).status_code, 200)
        self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM users").fetchone()[0], 1)
        self.assertEqual(self.app.db.execute("SELECT COUNT(DISTINCT user_id) FROM lessons").fetchone()[0], 1)
        self.assertEqual(len(list(self.app.cfg.upload_dir.iterdir())), 1)
        self.assertEqual(self.j(b, "get", f"/api/lessons/{lid_b}").status_code, 200)
        self.assertEqual(a.get("/dashboard").status_code, 302)


class DeckTests(Base):
    def test_validation_of_a_deck(self):
        c, lid = self.teacher_with_lesson()
        qs = self.j(c, "get", f"/api/lessons/{lid}/questions").get_json()["questions"]
        tf = [q["id"] for q in qs if q["kind"] == "tf"]
        self.assertEqual(self.j(c, "post", f"/api/lessons/{lid}/decks", {"games": [], "question_ids": tf}).status_code, 400)
        self.assertEqual(self.j(c, "post", f"/api/lessons/{lid}/decks", {"games": ["tf"], "question_ids": []}).status_code, 400)
        self.assertEqual(self.j(c, "post", f"/api/lessons/{lid}/decks", {"games": ["mcq"], "question_ids": tf}).status_code, 400)          # no multiple-choice among them
        self.assertEqual(self.j(c, "post", f"/api/lessons/{lid}/decks", {"games": ["hack"], "question_ids": tf}).status_code, 400)
        r = self.j(c, "post", f"/api/lessons/{lid}/decks", {"games": ["tf", "wheel", "teams"], "question_ids": tf + [999999], "title": "عرضي"})
        self.assertEqual(r.status_code, 201)
        data = self.j(c, "get", f"/api/decks/{r.get_json()['id']}/data").get_json()
        self.assertEqual((data["title"], data["games"]), ("عرضي", ["tf", "wheel", "teams"]))
        self.assertEqual(sorted(q["id"] for q in data["questions"]), sorted(tf))
        self.assertEqual(c.get(f"/present/{r.get_json()['id']}").status_code, 200)

    def test_plan_limits(self):
        c, lid = self.teacher_with_lesson()
        qid = self.j(c, "get", f"/api/lessons/{lid}/questions").get_json()["questions"][0]["id"]
        for _ in range(5):
            self.assertEqual(self.j(c, "post", f"/api/lessons/{lid}/decks", {"games": ["wheel"], "question_ids": [qid]}).status_code, 201)
        r = self.j(c, "post", f"/api/lessons/{lid}/decks", {"games": ["wheel"], "question_ids": [qid]})
        self.assertEqual(r.status_code, 403)
        self.assertIn("حد العروض", r.get_json()["error"])
        for i in range(2):
            self.upload(c, f"l{i}.pptx", F.pptx_bytes())
        r = self.upload(c, "l3.pptx", F.pptx_bytes())
        from urllib.parse import unquote_plus
        self.assertIn("حد الدروس", unquote_plus(r.headers["Location"]))
        self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM lessons").fetchone()[0], 3)
        self.app.db.execute("UPDATE users SET plan_code = 'monthly'")
        self.app.db.commit()
        self.assertEqual(self.j(c, "post", f"/api/lessons/{lid}/decks", {"games": ["wheel"], "question_ids": [qid]}).status_code, 201)

    def test_plans_exist_and_only_paid_ones_are_purchasable(self):
        rows = self.app.db.execute("SELECT code, purchasable FROM plans ORDER BY code").fetchall()
        self.assertEqual([(r[0], r[1]) for r in rows], [("free", 0), ("monthly", 1), ("yearly", 1)])


class ProviderTests(Base):
    TEXT = "الخلية هي الوحدة الأساسية للحياة في جميع الكائنات الحية. النواة هي مركز التحكم في الخلية وتحتوي على المادة الوراثية."

    def test_paid_provider_is_never_used_by_default_or_without_consent(self):
        class Cfg:
            ai_provider, anthropic_key, anthropic_model = "offline", "", "m"
        self.assertEqual(aiq.provider_for(Cfg, True).name, "offline")
        Cfg.ai_provider, Cfg.anthropic_key = "claude", "KEY"
        self.assertEqual(aiq.provider_for(Cfg, False).name, "offline")          # the teacher did not agree
        Cfg.anthropic_key = ""
        self.assertEqual(aiq.provider_for(Cfg, True).name, "offline")           # no key
        Cfg.anthropic_key = "KEY"
        self.assertEqual(aiq.provider_for(Cfg, True).name, "claude")

    def test_claude_answers_are_checked_against_the_file(self):
        reply = {"content": [{"text": json.dumps([
            {"kind": "qa", "question": "ما الخلية؟", "answer": "الوحدة الأساسية للحياة", "evidence": "الخلية هي الوحدة الأساسية للحياة في جميع الكائنات الحية"},
            {"kind": "qa", "question": "ما عاصمة فرنسا؟", "answer": "باريس", "evidence": "باريس هي العاصمة"},
            {"kind": "qa", "question": "ما وظيفة الجسم الجولجي؟", "answer": G.UNCLEAR, "evidence": ""}], ensure_ascii=False)}]}
        sent = {}

        def transport(payload):
            sent.update(payload)
            return reply
        prov = aiq.ClaudeProvider("KEY", "model-x", transport=transport)
        out = aiq.clean_items(prov.generate(self.TEXT), self.TEXT, strict=False)
        self.assertEqual([q["clear"] for q in out], [1, 0, 0])
        self.assertIn("نص الملف فقط", sent["system"])
        self.assertIn("الوحدة الأساسية", sent["messages"][0]["content"])

    def test_a_failing_paid_provider_falls_back_to_offline(self):
        class Cfg:
            ai_provider, anthropic_key, anthropic_model = "claude", "KEY", "m"
        orig = aiq.ClaudeProvider._post
        aiq.ClaudeProvider._post = lambda self, payload: (_ for _ in ()).throw(OSError("network down"))
        try:
            name, items, used = aiq.make_questions(Cfg, self.TEXT * 3, True)
        finally:
            aiq.ClaudeProvider._post = orig
        self.assertEqual(name, "offline")
        self.assertTrue(items)

    def test_consent_toggle(self):
        c = self.client()
        self.register(c)
        self.assertEqual(self.app.db.execute("SELECT ai_consent FROM users").fetchone()[0], 0)
        self.j(c, "post", "/api/me/consent", {"ai_consent": True})
        self.assertEqual(self.app.db.execute("SELECT ai_consent FROM users").fetchone()[0], 1)
        self.j(c, "post", "/api/me/consent", {"ai_consent": "yes"})              # only a real true counts
        self.assertEqual(self.app.db.execute("SELECT ai_consent FROM users").fetchone()[0], 0)


class HeaderTests(Base):
    def test_security_headers_and_no_inline_scripts(self):
        c, lid = self.teacher_with_lesson()
        for path in ("/", "/login", "/dashboard", f"/lessons/{lid}"):
            r = c.get(path)
            self.assertIn("script-src 'self'", r.headers["Content-Security-Policy"])
            html = r.get_data(as_text=True)
            self.assertNotRegex(html, r"<script(?![^>]*\bsrc=)")
            self.assertNotRegex(html, r"\son[a-z]+=")
        self.assertEqual(c.get("/dashboard").headers["Cache-Control"], "no-store")


if __name__ == "__main__":
    unittest.main()
