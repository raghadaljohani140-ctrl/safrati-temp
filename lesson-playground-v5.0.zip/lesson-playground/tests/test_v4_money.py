"""Version 4: the exact cost of the paid reader, the cap that protects the project, the model that can not be swapped, the manager's subscription actions."""
import time
import unittest

from app import aimodel, aiq, billing, db as dbm
from tests import fixtures as F
from tests.test_billing import DAY, Money

MONTH = 30 * DAY


class CostTests(unittest.TestCase):
    def test_prices_are_the_official_ones_and_exact(self):
        self.assertEqual(aimodel.MODEL, "claude-haiku-5-5")
        self.assertEqual(billing.cost_nano("claude-haiku-5-5", 1_000_000 - 900_001, 0), 99_999 * 100)       # up to 100,000 prompt tokens: 0.10 dollars per million
        self.assertEqual(billing.cost_nano("claude-haiku-5-5", 10_000, 2_000), 10_000 * 100 + 2_000 * 500)  # and 0.50 per million of answer
        self.assertEqual(billing.cost_nano("claude-haiku-5-5", 200_000, 1_000), 200_000 * 500 + 1_000 * 2_500)   # a longer prompt pays the long-prompt prices
        self.assertEqual(billing.cost_nano("some-new-model", 1_000_000, 0), 4_000_000_000)                  # an unknown model is costed like the dearest
        # nano-dollars to halalas: 3.75 riyals per dollar, rounded up once
        self.assertEqual(billing.nano_to_halalas(1_000_000_000), 375)
        self.assertEqual(billing.nano_to_halalas(1), 1)
        self.assertEqual(billing.nano_to_halalas(0), 0)

    def test_the_worst_call_is_bounded_and_dearer_than_any_real_call(self):
        small, big = billing.worst_call_nano(200), billing.worst_call_nano(None)
        self.assertLess(small, big)
        self.assertEqual(billing.worst_call_nano(10 ** 9), big)                                             # the text is cut at 60,000 characters
        self.assertLessEqual(billing.worst_call_halalas(), 35)                                              # about a third of a riyal, whatever the file
        # more than a real call can be: 60,000 characters of Arabic at one token per character and the longest answer
        self.assertGreater(big, billing.cost_nano(aimodel.MODEL, 60_000, aimodel.MAX_OUT_TOKENS))

    def test_the_month_sum_is_exact_not_a_sum_of_roundings(self):
        db = dbm.connect(":memory:")
        dbm.init(db)
        db.execute("INSERT INTO users(email, name, pass_hash, created_at) VALUES ('a@x.co', 'a', 'h', 1)")
        for _ in range(10):
            billing.log_ai(db, 1, None, aimodel.MODEL, 3000, 1500)                                          # 0.39375 halala each
        self.assertEqual(db.execute("SELECT SUM(cost) FROM ai_usage").fetchone()[0], 10)                    # every row rounds up to 1
        self.assertEqual(billing.ai_cost_month(db), 4)                                                      # but the real bill is 3.9375 halalas
        db.execute("INSERT INTO ai_usage(user_id, lesson_id, model, input_tokens, output_tokens, cost, created_at) VALUES (1, NULL, 'old', 1, 1, 7, ?)", (time.time(),))
        self.assertEqual(billing.ai_cost_month(db), 4 + 7)                                                  # a row from before exact counting keeps its own figure


class CapTests(Money):
    def teacher(self):
        t = self.client()
        self.register(t)
        self.app.db.execute("UPDATE users SET plan_code = 'monthly', plan_expires = ?, ai_consent = 1", (time.time() + 10 * DAY,))
        self.app.db.commit()
        return t, self.app.db.execute("SELECT * FROM users").fetchone()

    def test_a_call_that_could_pass_the_cap_is_not_made(self):
        _, user = self.teacher()
        db = self.app.db
        need = billing.worst_call_halalas(1000)
        db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES ('ai_cap_sar', ?)", (str((need + 1) / 100),))       # room for exactly one worst-case call
        db.commit()
        with billing.paid_slot(db, user, 1000) as first:
            self.assertTrue(first)
            with billing.paid_slot(db, user, 1000) as second:                                               # two files at the same moment: the second waits for the free reader
                self.assertFalse(second)
        with billing.paid_slot(db, user, 1000) as again:                                                    # the hold is released afterwards
            self.assertTrue(again)

    def test_the_cap_counts_the_real_bill_too(self):
        _, user = self.teacher()
        db = self.app.db
        db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES ('ai_cap_sar', '1')")
        db.commit()
        self.assertTrue(billing.ai_allowed(db, user))
        billing.log_ai(db, user["id"], None, aimodel.MODEL, 1_000_000, 0)                                  # 1.88 riyals in one go
        self.assertFalse(billing.ai_allowed(db, user))

    def test_the_manager_switch_stops_the_paid_reader(self):
        _, user = self.teacher()
        self.assertTrue(billing.ai_allowed(self.app.db, user))
        dbm.put_setting(self.app.db, "ai_enabled", "0")
        self.assertFalse(billing.ai_allowed(self.app.db, user))

    def test_the_request_is_pinned_to_the_approved_model_with_thinking_off(self):
        sent = {}

        def transport(payload):
            sent.update(payload)
            return {"content": [{"type": "thinking", "thinking": "x"}, {"type": "text", "text": "[]"}], "usage": {"input_tokens": 5, "output_tokens": 2}}
        prov = aiq.ClaudeProvider("KEY", "claude-opus-5-5", transport=transport)                           # a different model asked for: ignored
        prov.generate("ا" * (aimodel.MAX_TEXT_CHARS + 500))
        self.assertEqual(sent["model"], "claude-haiku-5-5")
        self.assertEqual(sent["thinking"], {"type": "disabled"})
        self.assertEqual(sent["max_tokens"], aimodel.MAX_OUT_TOKENS)
        self.assertNotIn("temperature", sent)
        self.assertLessEqual(len(sent["messages"][0]["content"]), aimodel.MAX_TEXT_CHARS + 200)             # the text is cut at the limit the cap is built on

        class Cfg:
            ai_provider, anthropic_key, anthropic_model = "claude", "KEY", "claude-opus-5-5"
        self.assertEqual(aiq.provider_for(Cfg, True).model, "claude-haiku-5-5")

    def test_no_key_means_no_call_and_no_cost(self):
        calls = []
        orig = aiq.ClaudeProvider._post
        aiq.ClaudeProvider._post = lambda inner, payload: calls.append(payload)
        try:
            t, _ = self.teacher()
            self.upload(t, "cell.pptx", F.pptx_bytes())                                                     # the server has no key and AI_PROVIDER is offline
        finally:
            aiq.ClaudeProvider._post = orig
        self.assertEqual(calls, [])
        self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM ai_usage").fetchone()[0], 0)


class SubscriptionActionTests(Money):
    def setUp(self):
        super().setUp()
        self.t = self.client()
        self.register(self.t)
        self.uid1 = self.uid("a@example.com")
        self.db = self.app.db

    def user(self):
        return self.db.execute("SELECT * FROM users WHERE id = ?", (self.uid1,)).fetchone()

    def test_grant_extend_and_stop_are_logged_and_keep_the_lessons(self):
        self.upload(self.t, "cell.pptx", F.pptx_bytes())
        now = time.time()
        billing.grant_plan(self.db, self.uid1, "monthly", 30, "هدية", now)
        u = self.user()
        self.assertEqual((u["plan_code"], round((u["plan_expires"] - now) / DAY)), ("monthly", 30))
        self.assertEqual(billing.status_of(u["plan_code"], u["plan_expires"], True, now), "active")
        billing.extend_days(self.db, self.uid1, 10, "", now)
        self.assertEqual(round((self.user()["plan_expires"] - now) / DAY), 40)                              # from the end date, not from today
        billing.stop_plan(self.db, self.uid1, "بطلب منها", now)
        u = self.user()
        self.assertEqual((u["plan_code"], u["plan_expires"]), ("free", 0))
        self.assertEqual(billing.status_of(u["plan_code"], u["plan_expires"], True, now), "expired")
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM lessons").fetchone()[0], 1)
        self.assertEqual([r[0] for r in self.db.execute("SELECT kind FROM plan_events ORDER BY id")], ["grant", "extend", "stop"])
        with self.assertRaises(ValueError):
            billing.extend_days(self.db, self.uid1, 5)                                                      # nothing to extend on a free plan
        with self.assertRaises(ValueError):
            billing.grant_plan(self.db, self.uid1, "free", 5)
        with self.assertRaises(ValueError):
            billing.grant_plan(self.db, self.uid1, "monthly", 0)

    def test_a_lapsed_plan_extended_starts_from_today(self):
        now = time.time()
        self.db.execute("UPDATE users SET plan_code = 'monthly', plan_expires = ? WHERE id = ?", (now - 5 * DAY, self.uid1))
        self.db.commit()
        billing.extend_days(self.db, self.uid1, 7, "", now)
        self.assertEqual(round((self.user()["plan_expires"] - now) / DAY), 7)

    def test_the_counts_the_manager_sees(self):
        now = time.time()
        for i, (code, ends) in enumerate((("monthly", now + 20 * DAY), ("monthly", now + 2 * DAY), ("yearly", now - DAY))):
            self.db.execute("INSERT INTO users(email, name, pass_hash, plan_code, plan_expires, created_at) VALUES (?, ?, 'h', ?, ?, ?)", (f"s{i}@x.co", f"س{i}", code, ends, now))
        self.db.commit()
        c = billing.subscriber_counts(self.db, now)
        self.assertEqual((c["total"], c["active"], c["soon"], c["expired"], c["free"], c["pending"]), (4, 2, 1, 1, 1, 0))

    def test_the_period_comes_from_the_plan(self):
        self.assertEqual([billing.period_of(self.db.execute("SELECT * FROM plans WHERE code = ?", (c,)).fetchone()) for c in ("monthly", "yearly")], ["month", "year"])
        self.assertEqual((billing.period_of("yearly"), billing.period_of("monthly")), ("year", "month"))
        self.db.execute("INSERT INTO plans(code, name, max_lessons, max_decks, price_month, price_year, purchasable, ai_quota, period) VALUES ('term', 'فصلية', 90, 400, 0, 9900, 1, 40, 'year')")
        self.assertEqual(billing.plan_price(self.db.execute("SELECT * FROM plans WHERE code = 'term'").fetchone()), 9900)


class FinanceTests(Money):
    def test_fixed_and_variable_costs_come_out_of_the_profit(self):
        db = self.app.db
        self.admin()
        t = self.client()
        self.register(t)
        uid = self.uid("a@example.com")
        now = time.time()
        key = billing.mkey(now)
        db.execute("INSERT INTO subscription_requests(user_id, plan_code, period, amount, status, created_at, decided_at, ref_code) VALUES (?, 'monthly', 'month', 2900, 'confirmed', ?, ?, 'LP-1')", (uid, now, now))
        dbm.put_setting(db, "fixed_sar", "10")
        billing.add_expense(db, "fixed", "الخادم", 3000, key)                                              # 30 riyals every month from this month
        billing.add_expense(db, "variable", "إعلان", 500, key)                                              # 5 riyals once
        f = billing.finance(db)
        self.assertEqual((f["gross"], f["fixed"], f["variable"]), (2900, 1000 + 3000, 500))
        self.assertEqual(f["net"], 2900 - 4000 - 500)
        db.execute("UPDATE expenses SET ended_month = ? WHERE kind = 'fixed'", (billing.madd(key, -1),))   # stopped from last month: no longer counted
        self.assertEqual(billing.finance(db)["fixed"], 1000)
        with self.assertRaises(ValueError):
            billing.add_expense(db, "fixed", "", 100, key)
        with self.assertRaises(ValueError):
            billing.add_expense(db, "weekly", "x", 100, key)

    def test_months_are_listed_from_the_first_one(self):
        self.assertEqual(billing.mrange("2026-11", "2027-02"), ["2026-11", "2026-12", "2027-01", "2027-02"])
        self.assertEqual((billing.madd("2026-12", 1), billing.madd("2026-01", -1)), ("2027-01", "2025-12"))
        self.assertEqual(billing.mlabel("2026-11"), "نوفمبر 2026")


class PlansKeepEditsTests(Money):
    def test_restarting_does_not_undo_what_the_manager_changed(self):
        db = self.app.db
        db.execute("UPDATE plans SET price_month = 3900, ai_quota = 55, name = 'شهرية بلس' WHERE code = 'monthly'")
        db.commit()
        dbm.init(db)                                                                                        # what happens at every start
        row = db.execute("SELECT * FROM plans WHERE code = 'monthly'").fetchone()
        self.assertEqual((row["price_month"], row["ai_quota"], row["name"], row["period"]), (3900, 55, "شهرية بلس", "month"))


class OfflineQualityTests(unittest.TestCase):
    NOISE = ["وزارة التعليم الإدارة العامة للتعليم بمنطقة الرياض", "مدرسة الأمل الابتدائية للبنات العام الدراسي 1447 هـ", "إعداد المعلمة سارة المطيري للتواصل 0551234567",
             "للمزيد زوروا الموقع www.example.com صفحة 3"]

    def lesson(self):
        return "\n".join(self.NOISE) + "\n" + "\n".join(F.LESSON)

    def test_cover_lines_never_become_questions(self):
        out = aiq.OfflineProvider().generate(self.lesson())
        blob = " ".join(q["question"] + q["answer"] + q["evidence"] + " ".join(q.get("options") or []) for q in out)
        for bad in ("وزارة", "مدرسة", "المعلمة", "0551234567", "example.com", "1447"):
            self.assertNotIn(bad, blob)
        self.assertGreaterEqual(len(out), 10)

    def test_a_sentence_is_not_asked_over_and_over(self):
        out = aiq.OfflineProvider().generate("\n".join(F.LESSON))
        looks = [aiq.G.norm(q["evidence"]) for q in out if q["kind"] in aiq.LOOK]
        self.assertEqual(len(looks), len(set(looks)))                                                       # one blank, one option list, one true/false OR one half per sentence
        texts = [aiq.G.norm(q["question"]) for q in out]
        self.assertEqual(len(texts), len(set(texts)))
        self.assertEqual({q["kind"] for q in out}, set(aiq.KINDS))

    def test_a_real_sentence_about_the_school_is_kept(self):
        self.assertFalse(aiq.is_noise("المدرسة مكان يتعلم فيه الطلاب القراءة والكتابة والحساب كل يوم"))
        self.assertTrue(aiq.is_noise("مدرسة الأمل الابتدائية للبنات"))

    def test_the_paid_reader_answers_are_cleaned_the_same_way(self):
        text = "الخلية هي الوحدة الأساسية للحياة في جميع الكائنات الحية."
        ev = "الخلية هي الوحدة الأساسية للحياة في جميع الكائنات الحية"
        items = [dict(kind="qa", question="ما الخلية؟", answer="الوحدة الأساسية للحياة", evidence=ev),
                 dict(kind="qa", question="ما الخلية؟", answer="الوحدة الأساسية للحياة", evidence=ev),
                 dict(kind="qa", question="ما اسم المدرسة؟", answer="مدرسة الأمل", evidence="وزارة التعليم مدرسة الأمل")]
        self.assertEqual(len(aiq.clean_items(items, text + " وزارة التعليم مدرسة الأمل", True)), 1)


if __name__ == "__main__":
    unittest.main()
