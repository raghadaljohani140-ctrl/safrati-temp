"""Version 5, phase 7: «نسختي الاحتياطية» through the server. The file she downloads, what is in it and what is not, putting it back (the same account, another account, an older state),
the safety copy and going back to it, and the files that are made to break things: a restore is all or nothing, and it never reaches another teacher or the disk."""
import datetime
import hashlib
import io
import json
import time
import re
import sqlite3
import zipfile
from unittest import mock

from app import api, backup
from app import db as dbm
from tests import fixtures as F
from tests import test_v5_phase5 as P5
from tests import test_v5_phase7 as P7

D = datetime.date
SECOND = ("هيا", "وعد", "جود", "رند")


class Backup(P7.Phase7):
    def setUp(self):
        super().setUp()
        for lim in (backup.download_limit, backup.preview_limit, backup.restore_limit, api.delete_limit):          # (counted per user number, and every test starts with user number 1)
            lim.hits.clear()
            self.addCleanup(lim.hits.clear)

    # ---------------------------------------------------------------- a teacher with a little of everything
    def lesson(self, c=None, name="cell.pptx", data=None):
        c = c or self.c
        r = c.post("/lessons/upload", data={"_csrf": self.token(c), "title": "الخلية", "lesson": (io.BytesIO(data or F.pptx_bytes()), name)}, content_type="multipart/form-data")
        self.assertEqual(r.status_code, 302, r.get_data(as_text=True))
        return int(re.search(r"/lessons/(\d+)", r.headers["Location"]).group(1))

    def rich(self, c=None, names=P5.NAMES, klass="الصف الأول أ", close=True):
        """A term half way (a class, a book and its plan, points, homework, an exam), a lesson she uploaded with its deck and the answers of her students, an exam made from that lesson too,
        a setting, and the term closed."""
        c = c or self.c
        w = self.midterm(c=c, names=names, klass=klass)
        lid = self.lesson(c)
        qs = c.get(f"/api/lessons/{lid}/questions").get_json()["questions"]
        self.assertTrue(len(qs) >= 3)
        r = self.api("post", f"/api/lessons/{lid}/decks", {"games": ["pick", "qa"], "question_ids": [q["id"] for q in qs], "title": "عرضي"}, c)
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        deck = r.get_json()["id"]
        st = w["students"]
        for n, who in enumerate(list(st.values())[:2]):
            for i, q in enumerate(qs[:3]):
                r = self.api("post", "/api/results", {"student_id": who, "deck_id": deck, "question_id": q["id"], "game": "pick", "correct": (i + n) % 2, "run": f"r{n}"}, c)
                self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        e = self.new_exam(w, c=c, uploads=[lid], lessons=w["lessons"][:1])
        self.assertEqual(self.api("patch", f"/api/exams/{e['id']}", {"header": "مدرسة الأمل"}, c).status_code, 200)
        if close:
            self.close(c=c)
        return {**w, "lid": lid, "deck": deck, "qids": [q["id"] for q in qs], "exam2": e["id"]}

    # ---------------------------------------------------------------- the file
    def download(self, c=None, status=200):
        r = (c or self.c).get("/api/backup/download")
        self.assertEqual(r.status_code, status, r.data[:200])
        return r.data

    def put(self, url, raw, c=None, confirm=True, status=200, **extra):
        c = c or self.c
        form = {"file": (io.BytesIO(raw), "backup.zip"), **extra}
        if confirm:
            form["confirm"] = "yes"
        r = c.post(url, data=form, headers={"X-CSRF": self.token(c)}, content_type="multipart/form-data")
        self.assertEqual(r.status_code, status, r.get_data(as_text=True)[:400])
        return r.get_json()

    def preview(self, raw, c=None, status=200):
        return self.put("/api/backup/preview", raw, c=c, confirm=False, status=status)

    def restore(self, raw, c=None, status=200):
        return self.put("/api/backup/restore", raw, c=c, status=status)

    def undo(self, c=None, confirm=True):
        return self.api("post", "/api/backup/undo", {"confirm": confirm}, c)

    # ---------------------------------------------------------------- looking inside a file, and making one
    @staticmethod
    def unpack(raw):
        zf = zipfile.ZipFile(io.BytesIO(raw))
        manifest = json.loads(zf.read("manifest.json"))
        tables = {t: [json.loads(x) for x in zf.read(f"tables/{t}.jsonl").decode("utf-8").splitlines() if x] for t in backup.ORDER}
        return manifest, tables

    @staticmethod
    def pack(manifest, tables, extra=None, skip=(), raw_tables=None):
        out = io.BytesIO()
        meta = {}
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
            for t in backup.ORDER:
                data = (raw_tables or {}).get(t)
                if data is None:
                    data = "".join(json.dumps(r, ensure_ascii=False) + "\n" for r in tables[t]).encode("utf-8")
                meta[t] = {"rows": len(tables[t]), "sha256": hashlib.sha256(data).hexdigest()}
                if t not in skip:
                    zf.writestr(f"tables/{t}.jsonl", data)
            m = {**manifest, "tables": meta, "rows": sum(x["rows"] for x in meta.values())}
            m.update((extra or {}).get("manifest", {}))
            zf.writestr("manifest.json", json.dumps(m, ensure_ascii=False))
            for name, data in (extra or {}).get("members", {}).items():
                zf.writestr(name, data)
        return out.getvalue()

    def tweak(self, raw, fn, **kw):
        manifest, tables = self.unpack(raw)
        fn(tables)
        return self.pack(manifest, tables, **kw)

    # ---------------------------------------------------------------- what is in the database
    def every_table(self):
        return [r[0] for r in self.app.db.execute("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]

    def snapshot(self):
        """Every row of every table of the database (all teachers, the plans, the meters): the proof that a failed restore changed nothing."""
        return {t: [tuple(r) for r in self.app.db.execute(f"SELECT * FROM {t} ORDER BY rowid")] for t in self.every_table()}

    def canon(self, uid):
        """What one teacher has, with the ids taken out: each id is replaced by the place of its row among her rows of that table, so two accounts (or one before and after a restore)
        hold the same thing exactly when these are equal. Written here with SQL, apart from the code that is tested."""
        db = self.app.db
        rank = {}
        for t in backup.ORDER:
            if "id" in [r[1] for r in db.execute(f"PRAGMA table_info({t})")]:
                rank[t] = {r[0]: i for i, r in enumerate(db.execute(f"SELECT id FROM {t} WHERE user_id = ? ORDER BY id", (uid,)), 1)}
        out = {}
        for t in backup.ORDER:
            fks = {r[3]: r[2] for r in db.execute(f"PRAGMA foreign_key_list({t})") if r[2] != "users"}
            rows = []
            for row in db.execute(f"SELECT * FROM {t} WHERE user_id = ?" + (" ORDER BY id" if t in rank else ""), (uid,)):
                d = dict(row)
                if t == "plan_log" and any(d[c] is not None and d[c] not in rank[p] for c, p in backup.SOFT[t].items()):
                    continue          # (a line of the log about a class or a term that is gone is left out of a backup)
                d.pop("id", None)
                d.pop("user_id", None)
                d.pop("stored_name", None)
                for col, parent in fks.items():
                    if d.get(col) is not None:
                        d[col] = rank[parent][d[col]]
                for col, parent in backup.SOFT.get(t, {}).items():
                    if d.get(col) is not None:
                        d[col] = rank[parent].get(d[col])
                if t == "decks":
                    d["question_ids"] = [rank["questions"][q] for q in json.loads(d["question_ids"])]
                if t == "exams":
                    d["sources"] = [{**s, "id": rank["book_lessons" if s["t"] == "bl" else "lessons"][s["id"]]} for s in json.loads(d["sources"])]
                rows.append(d)
            out[t] = rows
        return out

    def uid_of(self, email):
        return self.app.db.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone()["id"]

    def counts(self, uid=1):
        return backup.counts_of(self.app.db, uid)


# ================================================================ the file she downloads
class Contents(Backup):
    def test_the_file_is_a_zip_with_a_manifest_and_a_file_for_every_table(self):
        self.rich()
        r = self.c.get("/api/backup/download")
        self.assertEqual((r.status_code, r.mimetype), (200, "application/zip"))
        self.assertRegex(r.headers["Content-Disposition"], r'^attachment; filename="lessonplay-backup-2026-10-18\.zip"$')
        self.assertEqual(r.headers["Cache-Control"], "no-store")
        zf = zipfile.ZipFile(io.BytesIO(r.data))
        self.assertIsNone(zf.testzip())
        self.assertEqual(sorted(zf.namelist()), sorted(["manifest.json"] + [f"tables/{t}.jsonl" for t in backup.ORDER]))
        m = json.loads(zf.read("manifest.json"))
        self.assertEqual((m["format"], m["version"]), (backup.FORMAT, backup.VERSION))
        self.assertEqual(sorted(m["tables"]), sorted(backup.ORDER))
        for t, meta in m["tables"].items():
            data = zf.read(f"tables/{t}.jsonl")
            self.assertEqual((meta["rows"], meta["sha256"]), (data.count(b"\n"), hashlib.sha256(data).hexdigest()), t)

    def test_every_table_of_the_database_is_in_the_file_or_left_out_on_purpose(self):
        self.rich()
        every = set(self.every_table())
        self.assertEqual(every, set(backup.ORDER) | set(backup.EXCLUDED), every ^ (set(backup.ORDER) | set(backup.EXCLUDED)))
        self.assertFalse(set(backup.ORDER) & set(backup.EXCLUDED))
        for t, why in backup.EXCLUDED.items():
            self.assertTrue(why, t)

    def test_a_table_points_only_at_tables_above_it_or_at_the_account(self):
        self.rich()
        seen = set()
        for t in backup.ORDER:
            for r in self.app.db.execute(f"PRAGMA foreign_key_list({t})"):
                parent = r[2]
                self.assertTrue(parent == "users" or parent == t or parent in seen, f"{t} points at {parent}")
            seen.add(t)

    def test_every_column_is_in_the_file_unless_it_is_left_out_on_purpose(self):
        w = self.rich()
        manifest, tables = self.unpack(self.download())
        for t in backup.ORDER:
            if not tables[t]:
                continue
            cols = [r[1] for r in self.app.db.execute(f"PRAGMA table_info({t})")]
            want = {c for c in cols if c != "user_id" and c not in backup.SKIP.get(t, ())}
            self.assertEqual(set(tables[t][0]), want, t)
        self.assertEqual(backup.SKIP, {"lessons": ("stored_name",), "books": ("stored_name",)})          # (a new column that must not travel is a decision, so it is written down)

    def test_the_file_holds_what_she_has(self):
        w = self.rich()
        manifest, tables = self.unpack(self.download())
        have = {t: self.count(f"SELECT COUNT(*) FROM {t} WHERE user_id = 1") for t in backup.ORDER}
        self.assertEqual({t: m["rows"] for t, m in manifest["tables"].items()}, have)
        for t in ("classes", "students", "books", "book_lessons", "lessons", "questions", "decks", "points", "results", "exams", "exam_scores", "terms", "term_archives", "plan_items", "calendar_days",
                  "absences", "schedule_slots", "assignments", "assignment_students"):
            self.assertGreater(have[t], 0, t)
        self.assertEqual(manifest["counts"], self.counts())
        self.assertEqual({r["name"] for r in tables["students"]}, set(P5.NAMES))

    def test_nothing_of_the_account_the_plan_or_the_meters_is_in_it(self):
        self.rich()
        self.app.db.execute("INSERT INTO ai_usage(user_id, lesson_id, model, input_tokens, output_tokens, cost, created_at) VALUES (1, 1, 'm', 10, 10, 1, 1)")
        self.app.db.execute("INSERT INTO subscription_requests(user_id, plan_code, period, amount, ref_code, payer_name, status, created_at) VALUES (1, 'monthly', 'month', 2900, 'REF123', 'دافعة', 'pending', 1)")
        self.app.db.commit()
        raw = self.download()
        zf = zipfile.ZipFile(io.BytesIO(raw))
        blob = b"".join(zf.read(n) for n in zf.namelist()).decode("utf-8")
        for secret in ("a@example.com", "Teacher-pass-1", "pass_hash", "pbkdf2", "scrypt", "REF123", "دافعة", "ai_usage", "subscription_requests", "plan_expires", "stored_name"):
            self.assertNotIn(secret, blob, secret)
        stored = self.app.db.execute("SELECT stored_name FROM lessons").fetchone()["stored_name"]
        self.assertNotIn(stored, blob)

    def test_another_teachers_data_is_never_in_my_file(self):
        self.rich()
        b = self.second_teacher()
        self.rich(c=b, names=SECOND, klass="الصف الثاني")
        mine = zipfile.ZipFile(io.BytesIO(self.download()))
        blob = b"".join(mine.read(n) for n in mine.namelist()).decode("utf-8")
        for name in SECOND:
            self.assertNotIn(name, blob)
        self.assertNotIn("الصف الثاني", blob)
        theirs = zipfile.ZipFile(io.BytesIO(self.download(c=b)))
        blob = b"".join(theirs.read(n) for n in theirs.namelist()).decode("utf-8")
        for name in P5.NAMES:
            self.assertNotIn(name, blob)

    def test_an_empty_account_has_a_file_too(self):
        manifest, tables = self.unpack(self.download())
        self.assertEqual(manifest["rows"], 0)
        self.assertTrue(all(not rows for rows in tables.values()))
        self.preview(self.download())          # and it can be read

    def test_the_file_is_the_same_whenever_nothing_changed(self):
        self.rich()
        a = self.unpack(self.download())[1]
        b = self.unpack(self.download())[1]
        self.assertEqual(a, b)

    def test_a_row_is_one_line_and_text_keeps_its_letters(self):
        self.rich()
        manifest, tables = self.unpack(self.download())
        self.assertIn("مها", {r["name"] for r in tables["students"]})
        zf = zipfile.ZipFile(io.BytesIO(self.download()))
        self.assertIn("سارة".encode("utf-8"), zf.read("tables/students.jsonl"))          # (not \u0633: the file can be read by a person)


# ================================================================ putting it back
class RoundTrip(Backup):
    def wreck(self, w):
        """Change her account in every way a teacher might regret: a class gone with its students and points, a lesson and a book deleted, another point given."""
        self.assertEqual(self.api("delete", f"/api/classes/{w['cid']}").status_code, 200)
        self.assertEqual(self.api("delete", f"/api/lessons/{w['lid']}").status_code, 200)
        self.assertEqual(self.api("delete", f"/api/books/{w['bid']}").status_code, 200)

    def test_what_was_downloaded_comes_back_exactly(self):
        w = self.rich()
        before, raw = self.canon(1), self.download()
        self.wreck(w)
        self.assertNotEqual(self.canon(1), before)
        self.assertEqual(self.count("SELECT COUNT(*) FROM students WHERE user_id = 1"), 0)
        r = self.restore(raw)
        self.assertTrue(r["ok"])
        self.assertEqual(self.canon(1), before)
        self.assertEqual(r["file"]["counts"], self.counts())

    def test_a_restore_into_an_untouched_account_changes_nothing(self):
        self.rich()
        before, raw = self.canon(1), self.download()
        self.restore(raw)
        self.assertEqual(self.canon(1), before)
        self.restore(self.download())          # and again
        self.assertEqual(self.canon(1), before)

    def test_what_is_written_again_can_be_used_as_before(self):
        w = self.rich()
        raw = self.download()
        self.wreck(w)
        self.restore(raw)
        cid = self.app.db.execute("SELECT id FROM classes WHERE user_id = 1").fetchone()["id"]
        sid = self.app.db.execute("SELECT id FROM subjects WHERE user_id = 1").fetchone()["id"]
        self.today = P7.MID
        st = self.c.get(f"/api/students?class_id={cid}").get_json()["students"]
        self.assertEqual(sorted(s["name"] for s in st), sorted(P5.NAMES))
        self.assertEqual(self.give(st[0]["id"], 2)["amount"] if "amount" in self.give(st[0]["id"], 2) else 2, 2)          # a point can be given again
        self.assertTrue(self.c.get(f"/api/points/board?class_id={cid}").get_json()["rows"])
        self.assertEqual(self.c.get("/api/term").status_code, 200)
        self.assertEqual(self.c.get("/dashboard").status_code, 200)
        self.assertEqual(self.c.get("/exams").status_code, 200)
        lid = self.app.db.execute("SELECT id FROM lessons WHERE user_id = 1").fetchone()["id"]
        qs = self.c.get(f"/api/lessons/{lid}/questions").get_json()["questions"]
        self.assertTrue(qs)
        self.assertEqual(self.c.get(f"/lessons/{lid}").status_code, 200)
        deck = self.app.db.execute("SELECT id FROM decks WHERE user_id = 1 AND auto = 0").fetchone()["id"]
        d = self.c.get(f"/api/decks/{deck}/data").get_json()
        self.assertEqual(sorted(q["id"] for q in d["questions"]), sorted(q["id"] for q in qs))          # the deck holds this lesson's questions under their new ids
        self.assertEqual(self.c.get(f"/present/{deck}").status_code, 200)

    def test_the_references_between_rows_follow_the_new_ids(self):
        w = self.rich()
        raw = self.download()
        self.wreck(w)
        self.app.db.execute("INSERT INTO classes(user_id, name, created_at) VALUES (1, 'يأخذ أرقامًا قديمة', 0)")          # so the old numbers are taken by something else
        self.app.db.commit()
        self.restore(raw)
        db = self.app.db
        ids = {t: {r[0] for r in db.execute(f"SELECT id FROM {t}")} for t in backup.ORDER if t != "teacher_settings"}
        for t in backup.ORDER:
            for r in db.execute(f"PRAGMA foreign_key_list({t})"):
                if r[2] == "users":
                    continue
                orphans = db.execute(f"SELECT COUNT(*) FROM {t} WHERE {r[3]} IS NOT NULL AND {r[3]} NOT IN (SELECT id FROM {r[2]})").fetchone()[0]
                self.assertEqual(orphans, 0, f"{t}.{r[3]}")
        self.assertEqual(db.execute("PRAGMA foreign_key_check").fetchall(), [])
        deck = db.execute("SELECT * FROM decks WHERE auto = 0").fetchone()
        q_of_lesson = {r[0] for r in db.execute("SELECT id FROM questions WHERE lesson_id = ?", (deck["lesson_id"],))}
        self.assertEqual(set(json.loads(deck["question_ids"])), q_of_lesson)
        exam = db.execute("SELECT * FROM exams WHERE title != '' AND sources LIKE '%\"up\"%'").fetchone()
        up = [x for x in json.loads(exam["sources"]) if x["t"] == "up"]
        self.assertEqual([x["id"] for x in up], [deck["lesson_id"]])
        bl = [x for x in json.loads(exam["sources"]) if x["t"] == "bl"]
        self.assertTrue(bl and all(x["id"] in ids["book_lessons"] for x in bl))
        for r in db.execute("SELECT * FROM results"):
            self.assertIn(r["question_id"], q_of_lesson)
        for r in db.execute("SELECT * FROM plan_log"):
            self.assertTrue(r["class_id"] in ids["classes"] or r["class_id"] is None)
            self.assertTrue(r["term_id"] in ids["terms"] or r["term_id"] is None)

    def test_lessons_taught_together_stay_together(self):
        w = self.rich(close=False)
        items = self.plan(w["cid"], w["sid"])["items"]
        pend = [i for i in items if i["status"] == "pending"]
        r = self.api("post", "/api/plan/merge", {"first": pend[0]["id"], "second": pend[1]["id"]})
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        before = self.canon(1)
        self.assertTrue(any(i["together_with"] for i in before["plan_items"]))
        raw = self.download()
        self.restore(raw)
        self.assertEqual(self.canon(1), before)

    def test_the_settings_of_her_account_come_back(self):
        w = self.rich()
        raw = self.download()
        self.app.db.execute("UPDATE teacher_settings SET data = '{}' WHERE user_id = 1")
        self.app.db.commit()
        self.restore(raw)
        data = json.loads(self.app.db.execute("SELECT data FROM teacher_settings WHERE user_id = 1").fetchone()["data"])
        self.assertEqual(data.get("exam_header"), "مدرسة الأمل")

    def test_the_account_itself_is_not_touched(self):
        w = self.rich()
        before = [tuple(r) for r in self.app.db.execute("SELECT * FROM users ORDER BY id")]
        raw = self.download()
        self.wreck(w)
        self.restore(raw)
        self.assertEqual([tuple(r) for r in self.app.db.execute("SELECT * FROM users ORDER BY id")], before)
        self.assertEqual(self.c.get("/dashboard").status_code, 200)          # still signed in

    def test_the_meters_are_not_touched(self):
        w = self.rich()
        self.app.db.execute("INSERT INTO ai_usage(user_id, lesson_id, model, input_tokens, output_tokens, cost, created_at) VALUES (1, 1, 'm', 10, 10, 1, 1)")
        self.app.db.commit()
        meters = {t: [tuple(r) for r in self.app.db.execute(f"SELECT * FROM {t} ORDER BY rowid")] for t in ("ai_usage", "lesson_usage", "plan_events", "subscription_requests", "plans")}
        raw = self.download()
        self.wreck(w)
        self.restore(raw)
        self.assertEqual({t: [tuple(r) for r in self.app.db.execute(f"SELECT * FROM {t} ORDER BY rowid")] for t in meters}, meters)


# ================================================================ another account
class OtherAccount(Backup):
    def rows_of(self, uid):
        """Her rows exactly as stored, ids included."""
        return {t: [tuple(r) for r in self.app.db.execute(f"SELECT * FROM {t} WHERE user_id = ? ORDER BY rowid", (uid,))] for t in backup.ORDER}

    def test_a_file_fits_another_account_and_replaces_what_that_one_had(self):
        self.rich()
        raw, mine = self.download(), self.canon(1)
        b = self.second_teacher()
        ub = self.uid_of("b@example.com")
        self.rich(c=b, names=SECOND, klass="الصف الثاني")
        theirs = self.canon(ub)
        self.assertNotEqual(theirs, mine)
        mine_exact = self.rows_of(1)
        self.restore(raw, c=b)
        self.assertEqual(self.canon(ub), mine)          # she has what the file held, nothing else
        self.assertEqual(self.rows_of(1), mine_exact)          # and the first account is exactly as it was, ids included
        self.assertEqual(self.count("SELECT COUNT(*) FROM students WHERE user_id = ? AND name IN (?,?,?,?)", ub, *SECOND), 0)
        self.assertEqual(self.undo(c=b).status_code, 200)
        self.assertEqual(self.canon(ub), theirs)          # and her own things were kept in the safety copy
        self.assertEqual(self.rows_of(1), mine_exact)

    def test_a_restore_never_touches_another_teacher(self):
        w = self.rich()
        raw = self.download()
        b = self.second_teacher()
        ub = self.uid_of("b@example.com")
        self.rich(c=b, names=SECOND, klass="الصف الثاني")
        theirs = self.rows_of(ub)
        meters = [tuple(r) for r in self.app.db.execute("SELECT * FROM users WHERE id = ?", (ub,))]
        self.api("delete", f"/api/classes/{w['cid']}")
        self.restore(raw)
        self.assertEqual(self.rows_of(ub), theirs)
        self.assertEqual([tuple(r) for r in self.app.db.execute("SELECT * FROM users WHERE id = ?", (ub,))], meters)
        self.assertEqual(self.count("SELECT COUNT(*) FROM user_backups WHERE user_id = ?", ub), 0)

    def test_an_empty_file_empties_the_account_and_can_be_undone(self):
        self.rich()
        b = self.second_teacher()
        empty = self.download(c=b)
        before = self.canon(1)
        r = self.restore(empty)
        self.assertEqual(sum(r["file"]["counts"].values()), 0)
        self.assertEqual({t: len(rows) for t, rows in self.canon(1).items() if rows}, {})
        self.assertEqual(self.undo().status_code, 200)
        self.assertEqual(self.canon(1), before)

    def test_ids_of_the_file_that_other_teachers_own_are_not_taken_from_them(self):
        self.rich()
        raw = self.download()
        b = self.second_teacher()
        ub = self.uid_of("b@example.com")
        self.rich(c=b, names=SECOND, klass="الصف الثاني")
        theirs = self.rows_of(ub)
        self.restore(raw, c=b)          # (her ids and mine overlap: the file's numbers are only names for rows inside it)
        self.restore(raw)
        self.assertEqual(self.canon(1), self.canon(ub))
        classes = [r[0] for r in self.app.db.execute("SELECT id FROM classes")]
        self.assertEqual(len(classes), len(set(classes)))
        self.assertNotEqual(theirs, self.rows_of(ub))


# ================================================================ the safety copy
class Safety(Backup):
    def wreck(self, w):
        self.assertEqual(self.api("delete", f"/api/classes/{w['cid']}").status_code, 200)

    def test_nothing_is_kept_before_the_first_restore(self):
        self.rich()
        d = self.c.get("/api/backup").get_json()
        self.assertIsNone(d["safety"])
        self.assertEqual(d["current"], self.counts())
        self.assertEqual(self.count("SELECT COUNT(*) FROM user_backups"), 0)

    def test_a_restore_keeps_what_she_had_and_she_can_go_back_and_forth(self):
        w = self.rich()
        raw, full = self.download(), self.canon(1)
        self.wreck(w)
        wrecked = self.canon(1)
        self.restore(raw)
        s = self.c.get("/api/backup").get_json()["safety"]
        self.assertEqual((s["counts"]["students"], s["counts"]["classes"]), (0, 0))          # what she had just before: the account without the class
        self.assertGreater(s["size"], 0)
        self.assertTrue(s["created_text"])
        self.assertEqual(self.canon(1), full)
        r = self.undo()
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        self.assertEqual(self.canon(1), wrecked)
        self.assertEqual(self.c.get("/api/backup").get_json()["safety"]["counts"]["students"], len(P5.NAMES))          # now it holds the state before going back
        self.assertEqual(self.undo().status_code, 200)
        self.assertEqual(self.canon(1), full)

    def test_one_safety_copy_per_teacher_and_it_is_hers(self):
        w = self.rich()
        raw = self.download()
        b = self.second_teacher()
        ub = self.uid_of("b@example.com")
        self.rich(c=b, names=SECOND, klass="الصف الثاني")
        self.restore(raw)
        self.restore(raw, c=b)
        self.restore(raw)
        self.assertEqual(self.count("SELECT COUNT(*) FROM user_backups"), 2)
        mine = self.c.get("/api/backup").get_json()["safety"]
        theirs = b.get("/api/backup").get_json()["safety"]
        self.assertEqual(mine["counts"]["students"], len(P5.NAMES))          # (the state before her last restore)
        self.assertEqual(theirs["counts"]["students"], len(SECOND))
        self.assertEqual(self.undo(c=b).status_code, 200)
        self.assertEqual({r["name"] for r in self.app.db.execute("SELECT name FROM students WHERE user_id = ?", (ub,))}, set(SECOND))

    def test_going_back_needs_a_confirmation_and_a_copy(self):
        w = self.rich()
        self.assertEqual(self.undo().status_code, 404)
        self.restore(self.download())
        for bad in (None, False, "yes", 1):
            r = self.api("post", "/api/backup/undo", {} if bad is None else {"confirm": bad})
            self.assertEqual(r.status_code, 400, bad)
        self.assertEqual(self.undo().status_code, 200)

    def test_a_failed_restore_leaves_the_old_safety_copy_alone(self):
        w = self.rich()
        raw = self.download()
        self.restore(raw)
        kept = self.app.db.execute("SELECT data, created_at FROM user_backups").fetchone()
        kept = (bytes(kept["data"]), kept["created_at"])
        bad = self.tweak(raw, lambda t: t["students"][0].update(class_id=99999))
        self.put("/api/backup/restore", bad, status=400)
        again = self.app.db.execute("SELECT data, created_at FROM user_backups").fetchone()
        self.assertEqual((bytes(again["data"]), again["created_at"]), kept)

    def test_deleting_the_account_deletes_the_safety_copy_and_everything(self):
        w = self.rich()
        self.restore(self.download())
        self.assertEqual(self.count("SELECT COUNT(*) FROM user_backups"), 1)
        files = [r[0] for r in self.app.db.execute("SELECT stored_name FROM lessons")]
        r = self.api("post", "/api/me/delete", {"password": "Teacher-pass-1"})
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        for t in list(backup.ORDER) + ["user_backups", "users"]:
            self.assertEqual(self.count(f"SELECT COUNT(*) FROM {t}"), 0, t)
        for f in files:
            self.assertFalse((self.app.cfg.upload_dir / f).exists(), f)

    def test_the_safety_copy_is_a_file_the_same_code_reads(self):
        w = self.rich()
        self.restore(self.download())
        blob = bytes(self.app.db.execute("SELECT data FROM user_backups").fetchone()["data"])
        manifest, tables = self.unpack(blob)
        self.assertEqual((manifest["format"], manifest["version"]), (backup.FORMAT, backup.VERSION))
        self.preview(blob)


# ================================================================ all or nothing
class AllOrNothing(Backup):
    def second(self):
        b = self.second_teacher()
        self.rich(c=b, names=SECOND, klass="الصف الثاني")
        return b

    def test_a_failure_in_the_middle_changes_nothing(self):
        self.rich()
        raw = self.download()
        b = self.second()
        before = self.snapshot()
        original = backup.Restorer.table

        def broken(me, name):
            if name == "results" and me.uid != 1:          # (the trial in memory is account 1; the real write is hers)
                raise sqlite3.OperationalError("disk is full")
            return original(me, name)

        with mock.patch.object(backup.Restorer, "table", broken):
            r = self.put("/api/backup/restore", raw, c=b, status=500)
        self.assertIn("لم يتغير شيء", r["error"])
        self.assertEqual(self.snapshot(), before)

    def test_a_reference_that_breaks_at_the_end_changes_nothing(self):
        self.rich()
        raw = self.download()
        b = self.second()
        before = self.snapshot()
        original = backup.Restorer.special

        def bent(me, name, vals, row):
            original(me, name, vals, row)
            if name == "students" and me.uid != 1:
                vals["class_id"] = 987654          # a student of a class that does not exist: the database only notices when the transaction is committed
        with mock.patch.object(backup.Restorer, "special", bent):
            self.put("/api/backup/restore", raw, c=b, status=500)
        self.assertEqual(self.snapshot(), before)

    def test_a_file_that_is_bad_half_way_is_refused_before_anything_is_written(self):
        self.rich()
        raw = self.download()
        b = self.second()
        before = self.snapshot()
        bad = self.tweak(raw, lambda t: t["exam_scores"][0].update(student_id=424242))          # the last tables are the ones that break
        r = self.put("/api/backup/restore", bad, c=b, status=400)
        self.assertEqual(r["error"], backup.CORRUPT)
        self.assertEqual(self.snapshot(), before)

    def test_a_file_that_can_not_be_used_is_found_out_before_the_real_database_is_even_opened(self):
        """The whole file is tried in memory first: a bad file never takes the write lock of the site (every teacher is waiting behind it) and never makes a safety copy to throw away."""
        self.rich()
        raw = self.download()
        b = self.second()
        bad = self.tweak(raw, lambda t: t["exam_scores"][0].update(student_id=424242))
        opened = []
        real = backup.connect

        def spy(path):
            opened.append(str(path))
            return real(path)

        with mock.patch.object(backup, "connect", spy):
            self.put("/api/backup/restore", bad, c=b, status=400)
            self.assertEqual(opened, [])
            self.restore(raw, c=b)          # and a good one does open it, once
        self.assertEqual(opened, [str(self.app.cfg.db_path)])

    def test_files_are_not_removed_when_the_restore_fails(self):
        self.rich()
        raw = self.download()
        b = self.second()
        names = [r[0] for r in self.app.db.execute("SELECT stored_name FROM lessons")]
        self.assertTrue(all((self.app.cfg.upload_dir / n).exists() for n in names))
        with mock.patch.object(backup.Restorer, "table", side_effect=sqlite3.OperationalError("boom")):
            self.put("/api/backup/restore", raw, c=b, status=500)
        self.assertTrue(all((self.app.cfg.upload_dir / n).exists() for n in names))

    def test_two_restores_of_one_account_do_not_run_together(self):
        w = self.rich()
        raw = self.download()
        before = self.snapshot()
        backup._running[1] = True
        try:
            r = self.put("/api/backup/restore", raw, status=400)
        finally:
            backup._running.pop(1, None)
        self.assertEqual(r["error"], backup.BUSY)
        self.assertEqual(self.snapshot(), before)
        self.restore(raw)          # and the lock is let go

    def test_the_lock_is_let_go_after_a_failure(self):
        self.rich()
        raw = self.download()
        with mock.patch.object(backup.Restorer, "table", side_effect=RuntimeError("boom")):
            self.put("/api/backup/restore", raw, status=500)
        self.assertEqual(backup._running, {})
        self.restore(raw)

    def test_the_preview_changes_nothing(self):
        self.rich()
        raw = self.download()
        b = self.second()
        before = self.snapshot()
        p = self.preview(raw, c=b)
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(p["file"]["counts"]["students"], len(P5.NAMES))
        self.assertEqual(p["current"]["students"], len(SECOND))
        self.assertIsNone(p["safety"])


# ================================================================ files that are made to break things
def zip_of(members, level=zipfile.ZIP_DEFLATED):
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", level) as zf:
        for name, data in members.items():
            zf.writestr(name, data)
    return out.getvalue()


class Hostile(Backup):
    def setUp(self):
        super().setUp()
        for lim in (backup.download_limit, backup.preview_limit, backup.restore_limit):          # (many files are tried in a test: the limits have their own tests)
            patcher = mock.patch.object(lim, "tries", 10 ** 6)
            patcher.start()
            self.addCleanup(patcher.stop)
        self.w = self.rich()
        self.raw = self.download()
        self.manifest, self.tables = self.unpack(self.raw)

    def refuse(self, raw, message=None, c=None):
        """The file is refused at the preview and at the restore, with a message for her, and nothing in the database moves."""
        before = self.snapshot()
        p = self.preview(raw, c=c, status=400)
        r = self.put("/api/backup/restore", raw, c=c, status=400)
        if message:
            self.assertEqual((p["error"], r["error"]), (message, message))
        self.assertTrue(p["error"] and r["error"])
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(backup._running, {})
        return p["error"]

    def accept(self, raw, c=None):
        self.preview(raw, c=c)
        return self.restore(raw, c=c)

    def members(self, raw=None):
        zf = zipfile.ZipFile(io.BytesIO(raw or self.raw))
        return {n: zf.read(n) for n in zf.namelist()}

    def with_rows(self, table, rows, **kw):
        """A file whose manifest is right for the rows it carries, so that only the rows can be wrong."""
        t = {k: list(v) for k, v in self.tables.items()}
        t[table] = rows
        return self.pack(self.manifest, t, **kw)

    def altered(self, table, index=0, **over):
        rows = [dict(r) for r in self.tables[table]]
        rows[index].update(over)
        return self.with_rows(table, rows)

    # ---- what is not a backup at all
    def test_what_is_not_a_backup(self):
        png = b"\x89PNG\r\n\x1a\n" + bytes(range(256)) * 4
        for junk in (b"", b"hello", png, b"PK\x03\x04" + b"junk" * 50, b'{"format": "lessonplay-backup"}', zip_of({"word/document.xml": b"<x/>"}), zip_of({"a.txt": b"a"})):
            self.assertEqual(self.refuse(junk), backup.NOT_BACKUP, junk[:20])

    def test_no_file_at_all(self):
        for url, form in (("/api/backup/preview", {}), ("/api/backup/restore", {"confirm": "yes"})):
            r = self.c.post(url, data=form, headers={"X-CSRF": self.token(self.c)}, content_type="multipart/form-data")
            self.assertEqual(r.status_code, 400, url)
            self.assertIn("اختاري", r.get_json()["error"])

    def test_a_restore_must_be_confirmed(self):
        before = self.snapshot()
        for form in ({}, {"confirm": "no"}, {"confirm": "true"}, {"confirm": "1"}, {"confirm": ""}, {"confirm": "YES"}):
            r = self.c.post("/api/backup/restore", data={"file": (io.BytesIO(self.raw), "b.zip"), **form}, headers={"X-CSRF": self.token(self.c)}, content_type="multipart/form-data")
            self.assertEqual(r.status_code, 400, form)
        self.assertEqual(self.snapshot(), before)

    # ---- the manifest
    def test_a_manifest_that_says_something_else(self):
        m = self.members()
        good = json.loads(m["manifest.json"])

        def with_manifest(**over):
            return zip_of({**m, "manifest.json": json.dumps({**good, **over})})

        self.assertEqual(self.refuse(with_manifest(format="something-else")), backup.NOT_BACKUP)
        self.assertEqual(self.refuse(with_manifest(version=backup.VERSION + 1)), backup.NEWER)
        self.assertEqual(self.refuse(with_manifest(version=99)), backup.NEWER)
        for v in (0, -1, "1", True, 1.5, None):
            self.assertEqual(self.refuse(with_manifest(version=v)), backup.CORRUPT, v)
        for tables in (None, [], "x", {}, {k: v for k, v in good["tables"].items() if k != "students"}, {**good["tables"], "extra": {"rows": 0, "sha256": "0" * 64}}):
            self.assertEqual(self.refuse(with_manifest(tables=tables)), backup.CORRUPT, str(tables)[:30])
        for bad in ({"rows": -1}, {"rows": "3"}, {"rows": True}, {"rows": 3.5}, {"sha256": "xyz"}, {"sha256": "A" * 64}, {"sha256": None}):
            tables = json.loads(json.dumps(good["tables"]))
            tables["students"].update(bad)
            self.assertEqual(self.refuse(with_manifest(tables=tables)), backup.CORRUPT, bad)
        for text in (b"[]", b"not json", b'{"format": NaN}', b"", b"\xff\xfe"):
            self.assertIn(self.refuse(zip_of({**m, "manifest.json": text})), (backup.CORRUPT, backup.NOT_BACKUP), text)

    def test_the_creation_time_in_the_manifest_may_be_anything_it_is_only_shown(self):
        m = self.members()
        good = json.loads(m["manifest.json"])
        for v in ("yesterday", None, True, 1e30, -1e30, [1]):
            out = self.preview(zip_of({**m, "manifest.json": json.dumps({**good, "created_at": v})}))
            self.assertEqual(out["file"]["created_at"], 0, v)
            self.assertEqual(out["file"]["created_text"], "", v)
        out = self.preview(self.raw)
        self.assertGreater(out["file"]["created_at"], 1e9)
        self.assertIn("الساعة", out["file"]["created_text"])

    # ---- the fingerprints
    def test_a_table_that_was_changed_after_the_file_was_made(self):
        m = self.members()
        data = m["tables/students.jsonl"]
        lines = data.splitlines(keepends=True)
        for changed in (data.replace("سارة".encode(), "سارا".encode()), b"".join(lines[1:]), data + lines[0].replace(b'"id":', b'"id":9', 1), data.replace(b"\n", b"\r\n", 1), data + b"\n"):
            self.assertEqual(self.refuse(zip_of({**m, "tables/students.jsonl": changed})), backup.CORRUPT)

    def test_a_member_whose_size_is_a_lie(self):
        out = bytearray(self.raw)
        for sig, at_size, at_name_len, name_from in ((b"PK\x01\x02", 24, 28, 46), (b"PK\x03\x04", 22, 26, 30)):
            at = 0
            while True:
                at = out.find(sig, at)
                if at < 0:
                    break
                n = int.from_bytes(out[at + at_name_len:at + at_name_len + 2], "little")
                if bytes(out[at + name_from:at + name_from + n]) == b"tables/students.jsonl":
                    out[at + at_size:at + at_size + 4] = (10).to_bytes(4, "little")          # it says: ten bytes
                at += 4
        self.assertEqual(self.refuse(bytes(out)), backup.CORRUPT)

    # ---- the members of the zip
    def test_members_that_are_not_part_of_a_backup(self):
        m = self.members()
        for extra in ("../evil.txt", "/etc/passwd", "tables/unknown.jsonl", "tables/../../x", "readme.txt", "tables/", "manifest.json.bak", "C:\\x"):
            self.assertEqual(self.refuse(zip_of({**m, extra: b"x"})), backup.CORRUPT, extra)
        self.assertEqual(self.refuse(zip_of({k: v for k, v in m.items() if k != "tables/points.jsonl"})), backup.CORRUPT)
        many = {**m, **{f"extra/{i}.txt": b"x" for i in range(100)}}
        self.assertEqual(self.refuse(zip_of(many)), backup.CORRUPT)

    def test_a_name_twice(self):
        members = self.members()
        for second in (b"", members["tables/points.jsonl"]):          # (another reader would see the other one of the two: a file like that is not one of ours, even when both are the same)
            out = io.BytesIO()
            with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
                for n, d in members.items():
                    zf.writestr(n, d)
                with self.assertWarns(UserWarning):
                    zf.writestr("tables/points.jsonl", second)
            self.assertEqual(self.refuse(out.getvalue()), backup.CORRUPT)

    def test_an_encrypted_member(self):
        raw = bytearray(self.raw)
        at = raw.find(b"PK\x01\x02")
        raw[at + 8] |= 1          # the flag of a member that is encrypted
        self.assertEqual(self.refuse(bytes(raw)), backup.CORRUPT)

    # ---- size
    def test_a_member_that_unpacks_to_too_much(self):
        with mock.patch.object(backup, "MAX_MEMBER", 1000):
            self.assertEqual(self.refuse(self.raw), backup.TOO_BIG)

    def test_all_of_them_together_unpack_to_too_much(self):
        total = sum(i.file_size for i in zipfile.ZipFile(io.BytesIO(self.raw)).infolist())
        with mock.patch.object(backup, "MAX_TOTAL", total - 1):
            self.assertEqual(self.refuse(self.raw), backup.TOO_BIG)
        with mock.patch.object(backup, "MAX_TOTAL", total):
            self.preview(self.raw)

    def test_too_many_rows(self):
        with mock.patch.object(backup, "MAX_ROWS", self.manifest["rows"] - 1):
            self.assertEqual(self.refuse(self.raw), backup.TOO_BIG)
        with mock.patch.object(backup, "MAX_ROWS", self.manifest["rows"]):
            self.preview(self.raw)

    def test_a_row_that_is_too_long(self):
        with mock.patch.object(backup, "MAX_LINE", 100):
            self.assertEqual(self.refuse(self.raw), backup.TOO_BIG)

    def test_a_file_bigger_than_she_may_upload(self):
        with mock.patch.object(backup, "MAX_FILE_MB", 1), mock.patch.object(backup, "MAX_FILE", 1024 * 1024):
            big = zip_of({"x": bytes(2 * 1024 * 1024)}, zipfile.ZIP_STORED)
            for url in ("/api/backup/preview", "/api/backup/restore"):
                r = self.c.post(url, data={"file": (io.BytesIO(big), "b.zip"), "confirm": "yes"}, headers={"X-CSRF": self.token(self.c)}, content_type="multipart/form-data")
                self.assertEqual(r.status_code, 413, url)
                self.assertIn("1 ميجابايت", r.get_json()["error"])
            fit = zip_of({"x": bytes(900 * 1024)}, zipfile.ZIP_STORED)
            r = self.c.post("/api/backup/preview", data={"file": (io.BytesIO(fit), "b.zip")}, headers={"X-CSRF": self.token(self.c)}, content_type="multipart/form-data")
            self.assertEqual((r.status_code, r.get_json()["error"]), (400, backup.NOT_BACKUP))          # (small enough to be read: it is only not a backup)

    def test_a_zip_bomb_is_not_unpacked(self):
        """A table that says it unpacks to more than a table may, and a thousand times its own size: refused from the headers, before one byte of it is read."""
        line = b'{"id":1}\n'
        bomb = zip_of({**self.members(), "tables/students.jsonl": line * (backup.MAX_MEMBER // len(line) + 10)})
        self.assertLess(len(bomb), 2 * 1024 * 1024)          # a couple of hundred KB that would be 120 MB
        with mock.patch("zipfile.ZipExtFile.readline", side_effect=AssertionError("it must not be unpacked")):
            self.assertEqual(self.refuse(bomb), backup.TOO_BIG)

    def test_a_table_with_far_more_rows_than_it_says_is_stopped_at_the_first_extra_row(self):
        line = b'{"id":1}\n'
        flood = zip_of({**self.members(), "tables/students.jsonl": line * 1_000_000})          # 9 MB, under every limit
        seen = []
        real = zipfile.ZipExtFile.readline

        def counting(self_, *a, **kw):
            seen.append(1)
            return real(self_, *a, **kw)

        with mock.patch("zipfile.ZipExtFile.readline", counting):
            self.assertEqual(self.refuse(flood), backup.CORRUPT)
        self.assertLess(len(seen), 200000)          # (the tables before it were read; it was not read to its end, twice)

    def test_rows_that_are_good_in_themselves_do_not_get_in_by_the_hundred_thousand_either(self):
        """Nothing but the count in the manifest is wrong here, and the fingerprint is that of what the table carries: without the stop at the first extra row, every one of them would be
        written to the trial database in memory before the count was looked at."""
        body = "".join(json.dumps({"id": 90000 + i, "name": f"صف {i}", "created_at": 1.0}, ensure_ascii=False) + "\n" for i in range(150000)).encode("utf-8")
        flood = self.pack(self.manifest, self.tables, raw_tables={"classes": body})
        self.assertGreater(150000, len(self.tables["classes"]))
        seen = []
        real = zipfile.ZipExtFile.readline

        def counting(self_, *a, **kw):
            seen.append(1)
            return real(self_, *a, **kw)

        with mock.patch("zipfile.ZipExtFile.readline", counting):
            self.assertEqual(self.refuse(flood), backup.CORRUPT)
        self.assertLess(len(seen), 1000)          # (two passes, the preview and the restore, each stopping at the second class)

    # ---- the rows
    def test_lines_that_are_not_rows(self):
        base = self.tables["classes"]
        for junk in (b"[1,2]\n", b'"text"\n', b"123\n", b"null\n", b"{bad}\n", b'{"id": NaN}\n', b'{"id": Infinity}\n', b"[" * 5000 + b"]" * 5000 + b"\n", b"\xff\xfe\n", b"\n"):
            raw_tables = {"classes": b"".join(json.dumps(r, ensure_ascii=False).encode() + b"\n" for r in base[:-1]) + junk}
            raw = self.pack(self.manifest, {**self.tables, "classes": base[:-1] + [{}]}, raw_tables=raw_tables)
            self.assertEqual(self.refuse(raw), backup.CORRUPT, junk[:12])

    def test_values_of_the_wrong_kind(self):
        cases = (("students", "name", [123, [], {}, True, 1.5]), ("students", "created_at", ["x", True, [], None]), ("points", "amount", ["5", True, 5.5, None, [5], 2 ** 60]),
                 ("exam_scores", "score", ["x", True, [], {}]), ("results", "correct", [2, -1, "1", True, None]), ("classes", "name", [None]), ("lessons", "text", [5, [], None]),
                 ("books", "pages", ["x", 1e30, [], True]), ("plan_items", "position", [2 ** 70, 2 ** 60, "x", None]), ("questions", "question", [None, 5, {}]), ("terms", "starts", [None, 5, []]))
        for table, col, values in cases:
            for v in values:
                self.assertEqual(self.refuse(self.altered(table, **{col: v})), backup.CORRUPT, (table, col, v))

    def test_a_number_too_big_to_be_a_number(self):
        """1e999 is written as one number by another program and read as infinity here."""
        rows = [dict(r) for r in self.tables["exam_scores"]]
        text = "".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows[1:])
        first = re.sub(r'"score": [^,}]+', '"score": 1e999', json.dumps(rows[0], ensure_ascii=False))
        self.assertIn("1e999", first)
        raw = self.pack(self.manifest, {**self.tables, "exam_scores": rows}, raw_tables={"exam_scores": (first + "\n" + text).encode()})
        self.assertEqual(self.refuse(raw), backup.CORRUPT)

    def test_ids_that_are_not_ids(self):
        different = {"classes": {"name": "ص"}, "students": {"name": "ص"}, "points": {"client_key": "ص"}, "lessons": {}}
        for table in different:
            for v in (None, 0, -1, True, "3", 1.5, [1], 2 ** 60):
                self.assertEqual(self.refuse(self.altered(table, id=v)), backup.CORRUPT, (table, v))
            rows = [dict(r) for r in self.tables[table]]
            del rows[0]["id"]
            self.assertEqual(self.refuse(self.with_rows(table, rows)), backup.CORRUPT, table)
            rows = [dict(r) for r in self.tables[table]]
            rows.append({**rows[0], **different[table]})
            self.assertEqual(self.refuse(self.with_rows(table, rows)), backup.CORRUPT, table)          # one id for two rows

    def test_a_reference_to_a_row_that_is_not_in_the_file(self):
        for table, col in (("students", "class_id"), ("plan_items", "book_lesson_id"), ("plan_items", "term_id"), ("plan_items", "class_id"), ("questions", "lesson_id"), ("decks", "lesson_id"),
                           ("points", "student_id"), ("exam_scores", "exam_id"), ("assignment_students", "assignment_id"), ("schedule_slots", "subject_id"), ("calendar_days", "term_id"),
                           ("book_lessons", "book_id"), ("book_units", "book_id"), ("class_subjects", "class_id"), ("exam_questions", "exam_id"), ("term_archives", "term_id"), ("results", "student_id")):
            for v in (999999, "x", True, 0, -3, 1.5, [1]):
                self.assertEqual(self.refuse(self.altered(table, **{col: v})), backup.CORRUPT, (table, col, v))

    def test_a_link_that_may_be_empty_is_emptied_when_what_it_points_at_is_not_there(self):
        optional = (("book_lessons", "unit_id"), ("class_subjects", "book_id"), ("plan_items", "lesson_id"), ("plan_items", "together_with"), ("points", "subject_id"), ("results", "deck_id"),
                    ("results", "question_id"), ("assignments", "subject_id"), ("exams", "subject_id"), ("term_archives", "new_term_id"))
        for table, col in optional:
            rows = [dict(r) for r in self.tables[table]]
            self.assertTrue(rows, table)
            for r in rows:
                r[col] = 999999
            out = self.accept(self.with_rows(table, rows))
            self.assertEqual(out["file"]["counts"][table] if table in out["file"]["counts"] else len(rows), len(rows), table)
            self.assertEqual(self.count(f"SELECT COUNT(*) FROM {table} WHERE {col} IS NOT NULL"), 0, (table, col))
            self.assertEqual(self.count(f"SELECT COUNT(*) FROM {table}"), len(rows), table)
            self.accept(self.raw)          # (and back to the real file)
        for table, col in optional:
            for v in ("x", True, 1.5, [1]):
                self.assertEqual(self.refuse(self.altered(table, **{col: v})), backup.CORRUPT, (table, col, v))          # a link that is not even a number is not a link that is gone

    def test_a_line_of_the_log_about_something_that_is_gone_is_left_out(self):
        rows = [dict(r) for r in self.tables["plan_log"]]
        rows[0]["class_id"] = 999999
        out = self.accept(self.with_rows("plan_log", rows))
        self.assertEqual(self.count("SELECT COUNT(*) FROM plan_log"), len(rows) - 1)

    def test_values_the_database_does_not_allow(self):
        times = [{"id": 1, "period": 1, "starts": "07:00", "ends": "07:45"}]
        cases = (self.altered("points", source="x"), self.altered("points", amount=0), self.altered("points", amount=51), self.altered("points", amount=-51), self.altered("plan_items", status="zzz"),
                 self.altered("exam_questions", kind="zzz"), self.altered("exam_questions", state="zzz"), self.altered("exam_questions", origin="zzz"), self.altered("exams", status="zzz"),
                 self.altered("results", correct=2), self.altered("assignments", kind="zzz"), self.altered("assignments", closed=2), self.altered("schedule_slots", day=9),
                 self.altered("schedule_slots", period=0), self.altered("schedule_slots", period=13), self.altered("questions", kind="zzz"), self.altered("assignment_students", status="zzz"),
                 self.altered("absences", period=99), self.altered("absences", period=-1), self.with_rows("schedule_times", [{**times[0], "period": 13}]),
                 self.with_rows("schedule_times", [{**times[0], "period": 0}]))
        for raw in cases:
            self.assertEqual(self.refuse(raw), backup.CORRUPT)
        self.accept(self.with_rows("schedule_times", times))          # (and a row that is fine is taken)
        self.assertEqual(self.count("SELECT COUNT(*) FROM schedule_times"), 1)

    def test_names_that_must_be_different_but_are_not(self):
        times = [{"id": 1, "period": 1, "starts": "07:00", "ends": "07:45"}, {"id": 2, "period": 1, "starts": "08:00", "ends": "08:45"}]
        cases = []
        for table, over in (("classes", {}), ("subjects", {}), ("students", {}), ("calendar_days", {})):
            rows = [dict(r) for r in self.tables[table]]
            rows.append({**rows[0], "id": max(r["id"] for r in rows) + 1, **over})
            cases.append(self.with_rows(table, rows))
        cases.append(self.with_rows("schedule_times", times))
        slots = [dict(r) for r in self.tables["schedule_slots"]]
        slots.append({**slots[0], "id": 99})
        cases.append(self.with_rows("schedule_slots", slots))
        keys = [dict(r) for r in self.tables["points"]]
        keys[0]["client_key"], keys[1]["client_key"] = "same", "same"
        cases.append(self.with_rows("points", keys))
        scores = [dict(r) for r in self.tables["exam_scores"]]
        scores.append({**scores[0], "id": 99})
        cases.append(self.with_rows("exam_scores", scores))
        for raw in cases:
            self.assertEqual(self.refuse(raw), backup.CORRUPT)

    def test_text_the_database_can_not_hold(self):
        rows = [dict(r) for r in self.tables["students"]]
        text = '{"id":1,"class_id":%d,"name":"\\ud800","created_at":1}\n' % self.tables["classes"][0]["id"]
        raw = self.pack(self.manifest, {**self.tables, "students": [rows[0]]}, raw_tables={"students": text.encode()})
        self.assertEqual(self.refuse(raw), backup.CORRUPT)          # half of a character: it can not be written

    def test_a_nul_character_is_dropped_and_a_long_name_is_cut(self):
        out = self.accept(self.altered("students", name="ريم\x00نور" + "ا" * 600))
        name = self.app.db.execute("SELECT name FROM students ORDER BY id").fetchone()[0]
        self.assertNotIn("\x00", name)
        self.assertEqual(len(name), backup.SHORT_MAX)
        self.assertTrue(name.startswith("ريمنور"))

    def test_a_text_that_is_too_long(self):
        longest = max(len(v) for t, rows in self.tables.items() for r in rows for k, v in r.items() if isinstance(v, str) and k not in backup.SHORT and k != "data")
        size = max(longest + 1, 2000)
        raw = self.altered("lessons", text="ا" * size)
        with mock.patch.object(backup, "TEXT_MAX", size - 1):
            self.assertEqual(self.refuse(raw), backup.CORRUPT)
        with mock.patch.object(backup, "TEXT_MAX", size):
            self.accept(raw)
        self.assertEqual(self.app.db.execute("SELECT LENGTH(text) FROM lessons").fetchone()[0], size)

    def test_the_summary_of_a_closed_term_has_a_limit_of_its_own(self):
        data = self.tables["term_archives"][0]["data"]
        with mock.patch.object(backup, "DATA_MAX", len(data) - 1):
            self.assertEqual(self.refuse(self.raw), backup.CORRUPT)
        with mock.patch.object(backup, "DATA_MAX", len(data)):
            self.accept(self.raw)

    def test_columns_and_keys_that_are_not_ours_are_ignored(self):
        rows = [{**r, "surprise": "x", "user_id": 2, "stored_name": "../../app.db"} for r in self.tables["students"]]
        b = self.second_teacher()
        ub = self.uid_of("b@example.com")
        self.accept(self.with_rows("students", rows))
        self.assertEqual(self.count("SELECT COUNT(*) FROM students WHERE user_id = ?", ub), 0)
        self.assertEqual(self.count("SELECT COUNT(*) FROM students WHERE user_id = 1"), len(rows))

    def test_a_column_the_file_does_not_have_gets_its_default(self):
        rows = [{k: v for k, v in r.items() if k != "whatsapp"} for r in self.tables["classes"]]
        self.accept(self.with_rows("classes", rows))
        self.assertEqual(self.app.db.execute("SELECT whatsapp FROM classes").fetchone()[0], "")
        rows = [{k: v for k, v in r.items() if k != "name"} for r in self.tables["classes"]]
        self.assertEqual(self.refuse(self.with_rows("classes", rows)), backup.CORRUPT)          # a column that has no default can not be missing

    # ---- names of files
    def test_the_name_of_a_stored_file_is_never_taken_from_the_file(self):
        lessons = [{**r, "stored_name": "../../app.db"} for r in self.tables["lessons"]]
        books = [{**r, "stored_name": "../../secret.key"} for r in self.tables["books"]]
        raw = self.pack(self.manifest, {**self.tables, "lessons": lessons, "books": books})
        b = self.second_teacher()
        ub = self.uid_of("b@example.com")
        self.accept(raw, c=b)
        names = [r[0] for r in self.app.db.execute("SELECT stored_name FROM lessons WHERE user_id = ?", (ub,))]
        self.assertTrue(names and all(re.fullmatch(r"restored-[0-9a-f]{32}", n) for n in names), names)
        self.assertEqual([r[0] for r in self.app.db.execute("SELECT stored_name FROM books WHERE user_id = ?", (ub,))], [""])
        lid = self.app.db.execute("SELECT id FROM lessons WHERE user_id = ?", (ub,)).fetchone()[0]
        self.assertEqual(self.api("delete", f"/api/lessons/{lid}", c=b).status_code, 200)
        bid = self.app.db.execute("SELECT id FROM books WHERE user_id = ?", (ub,)).fetchone()[0]
        self.assertEqual(self.api("delete", f"/api/books/{bid}", c=b).status_code, 200)
        self.accept(raw, c=b)
        self.assertEqual(self.api("post", "/api/me/delete", {"password": "Teacher-pass-1"}, c=b).status_code, 200)          # everything of hers goes, and only hers
        self.assertTrue((self.app.cfg.instance / "app.db").exists())
        self.assertTrue((self.app.cfg.instance / "secret.key").exists())

    def test_a_lesson_that_was_still_being_read_is_not_left_reading(self):
        lessons = [{**r, "status": "processing"} for r in self.tables["lessons"]]
        books = [{**r, "status": "processing"} for r in self.tables["books"]]
        self.accept(self.pack(self.manifest, {**self.tables, "lessons": lessons, "books": books}))
        self.assertEqual({r[0] for r in self.app.db.execute("SELECT status FROM lessons")}, {"failed"})
        self.assertEqual({r[0] for r in self.app.db.execute("SELECT status FROM books")}, {"failed"})
        self.assertTrue(all(r[0] for r in self.app.db.execute("SELECT error FROM lessons")))
        self.assertTrue(all(r[0] for r in self.app.db.execute("SELECT error FROM books")))

    def test_a_kind_or_a_status_that_makes_no_sense_is_made_safe(self):
        lessons = [{**r, "kind": "../../x", "status": "zzz"} for r in self.tables["lessons"]]
        self.accept(self.pack(self.manifest, {**self.tables, "lessons": lessons}))
        row = self.app.db.execute("SELECT kind, status FROM lessons").fetchone()
        self.assertEqual((row[0], row[1]), ("txt", "failed"))

    # ---- ids inside JSON
    def test_the_ids_inside_a_deck_and_an_exam_are_only_ones_of_the_file(self):
        qs = {q["id"] for q in self.tables["questions"]}
        decks = [dict(r) for r in self.tables["decks"]]
        decks[0]["question_ids"] = json.dumps(sorted(qs)[:3] + [999999, "x", None, True, 1.5, [3], {"a": 1}])
        exams = [dict(r) for r in self.tables["exams"]]
        lesson = self.tables["lessons"][0]["id"]
        exams[0]["sources"] = json.dumps([{"t": "bl", "id": 999999}, {"t": "up", "id": 999999}, {"t": "zz", "id": 1}, {"id": 1}, "x", {"t": "up"}, {"t": "bl", "id": True},
                                          {"t": "up", "id": lesson, "label": "درس", "evil": "x", "label2": 1}])
        exams[1]["sources"] = "not json"
        self.accept(self.pack(self.manifest, {**self.tables, "decks": decks, "exams": exams}))
        got = json.loads(self.app.db.execute("SELECT question_ids FROM decks WHERE auto = 0").fetchone()[0])
        mine = {r[0] for r in self.app.db.execute("SELECT id FROM questions")}
        self.assertEqual(len(got), 3)
        self.assertTrue(set(got) <= mine)
        sources = [json.loads(r[0]) for r in self.app.db.execute("SELECT sources FROM exams ORDER BY id")]
        new_lesson = self.app.db.execute("SELECT id FROM lessons").fetchone()[0]
        self.assertEqual(sources[0], [{"t": "up", "label": "درس", "id": new_lesson}])
        self.assertEqual(sources[1], [])

    def test_settings_that_are_not_an_object_become_empty(self):
        for data in ('["x"]', "not json", "5", "null", '{"exam_header": "مدرسة"}'):
            self.accept(self.with_rows("teacher_settings", [{"data": data}]))
            got = json.loads(self.app.db.execute("SELECT data FROM teacher_settings WHERE user_id = 1").fetchone()[0])
            self.assertEqual(got, {"exam_header": "مدرسة"} if "مدرسة" in data else {}, data)


# ================================================================ what her plan keeps
class Limits(Backup):
    def on_plan(self, code, uid=1):
        expires = 0 if code == "free" else time.time() + 20 * 86400
        self.app.db.execute("UPDATE users SET plan_code = ?, plan_expires = ?, ai_consent = 1 WHERE id = ?", (code, expires, uid))
        self.app.db.commit()

    def many(self, lessons=5, decks=2, c=None):
        """A paid teacher with `lessons` lessons and `decks` decks of her own on each (the newest lesson is the last)."""
        c = c or self.c
        self.on_plan("monthly")
        made = []
        for i in range(lessons):
            lid = self.lesson(c, name=f"cell{i}.pptx")
            qs = c.get(f"/api/lessons/{lid}/questions").get_json()["questions"]
            for j in range(decks):
                r = self.api("post", f"/api/lessons/{lid}/decks", {"games": ["pick"], "question_ids": [q["id"] for q in qs[:3]], "title": f"عرض {i}-{j}"}, c)
                self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
            made.append(lid)
        return made

    def empty_her(self, lids):
        for lid in lids:
            self.assertEqual(self.api("delete", f"/api/lessons/{lid}").status_code, 200)

    def titles(self, table="decks"):
        return [r[0] for r in self.app.db.execute(f"SELECT title FROM {table} WHERE auto = 0 ORDER BY id")] if table == "decks" else [r[0] for r in self.app.db.execute(f"SELECT created_at FROM {table} ORDER BY id")]

    def test_the_free_plan_keeps_the_newest_lessons_and_the_decks_of_those(self):
        lids = self.many(5, 2)
        raw = self.download()
        self.empty_her(lids)
        self.on_plan("free")
        free = self.app.db.execute("SELECT max_lessons, max_decks FROM plans WHERE code = 'free'").fetchone()
        self.assertEqual((free[0], free[1]), (3, 5))
        p = self.preview(raw)
        self.assertEqual(p["file"]["counts"]["lessons"], 3)
        self.assertEqual(p["file"]["left_out"]["lessons"], 2)
        self.assertEqual(p["file"]["counts"]["decks"], 5)          # six decks belong to the three lessons she keeps; the plan holds five
        self.assertEqual(p["file"]["left_out"]["decks"], 5)          # the four of the two lessons left out, and the oldest of the six
        self.assertTrue(any("3" in n and "الدروس" in n for n in p["file"]["notes"]), p["file"]["notes"])
        self.assertTrue(any("5" in n and "العروض" in n for n in p["file"]["notes"]), p["file"]["notes"])
        self.assertEqual(self.count("SELECT COUNT(*) FROM lessons"), 0)          # (the preview wrote nothing)
        out = self.restore(raw)
        self.assertEqual(out["file"]["left_out"], {"lessons": 2, "decks": 5})
        self.assertEqual(self.count("SELECT COUNT(*) FROM lessons"), 3)
        self.assertEqual(self.count("SELECT COUNT(*) FROM decks WHERE auto = 0"), 5)
        kept = [r[0] for r in self.app.db.execute("SELECT original_name FROM lessons ORDER BY created_at")]
        self.assertEqual(kept, ["cell2.pptx", "cell3.pptx", "cell4.pptx"])          # the newest three
        titles = {r[0] for r in self.app.db.execute("SELECT title FROM decks WHERE auto = 0")}
        self.assertEqual(titles, {"عرض 2-1", "عرض 3-0", "عرض 3-1", "عرض 4-0", "عرض 4-1"})          # and the newest five decks of them (the oldest, 2-0, is the one that waits)
        self.assertEqual(self.count("SELECT COUNT(*) FROM questions WHERE lesson_id NOT IN (SELECT id FROM lessons)"), 0)
        self.assertEqual(self.count("SELECT COUNT(*) FROM decks d WHERE NOT EXISTS (SELECT 1 FROM lessons l WHERE l.id = d.lesson_id)"), 0)

    def test_decks_of_a_lesson_left_out_take_no_place_from_the_decks_of_the_lessons_that_stay(self):
        lids = self.many(5, 2)
        qs = self.c.get(f"/api/lessons/{lids[0]}/questions").get_json()["questions"]
        for j in range(5):          # five newer decks, all on the oldest lesson: the one the free plan leaves out
            r = self.api("post", f"/api/lessons/{lids[0]}/decks", {"games": ["pick"], "question_ids": [q["id"] for q in qs[:3]], "title": f"جديد {j}"})
            self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        raw = self.download()
        self.empty_her(lids)
        self.on_plan("free")
        p = self.preview(raw)
        self.assertEqual((p["file"]["counts"]["lessons"], p["file"]["counts"]["decks"], p["file"]["left_out"]), (3, 5, {"lessons": 2, "decks": 10}))
        self.restore(raw)
        titles = {r[0] for r in self.app.db.execute("SELECT title FROM decks WHERE auto = 0")}
        self.assertEqual(titles, {"عرض 2-1", "عرض 3-0", "عرض 3-1", "عرض 4-0", "عرض 4-1"})          # the places go to decks that have a lesson to stand on, not to the newer ones that have none

    def test_what_is_left_out_stays_in_the_file_for_a_better_plan(self):
        lids = self.many(5, 2)
        raw = self.download()
        self.empty_her(lids)
        self.on_plan("free")
        self.restore(raw)
        self.on_plan("monthly")
        out = self.restore(raw)          # the same file, now that the plan holds it all
        self.assertEqual(out["file"]["left_out"], {})
        self.assertEqual(self.count("SELECT COUNT(*) FROM lessons"), 5)
        self.assertEqual(self.count("SELECT COUNT(*) FROM decks WHERE auto = 0"), 10)

    def test_a_paid_plan_gets_every_lesson_back(self):
        lids = self.many(5, 2)
        raw = self.download()
        self.empty_her(lids)
        p = self.preview(raw)
        self.assertEqual((p["file"]["counts"]["lessons"], p["file"]["counts"]["decks"], p["file"]["left_out"], p["file"]["notes"]), (5, 10, {}, []))
        self.restore(raw)
        self.assertEqual((self.count("SELECT COUNT(*) FROM lessons"), self.count("SELECT COUNT(*) FROM decks WHERE auto = 0")), (5, 10))

    def test_the_decks_a_plan_holds_are_counted_without_the_one_the_app_keeps_for_a_lesson(self):
        lids = self.many(2, 0)
        for lid in lids:
            self.assertEqual(self.c.get(f"/lessons/{lid}/today").status_code, 302)          # opening «حصة اليوم» is what makes the deck the app keeps for the lesson
        raw = self.download()
        self.assertEqual(self.count("SELECT COUNT(*) FROM decks WHERE auto = 1"), 2)
        self.empty_her(lids)
        self.on_plan("free")
        p = self.preview(raw)
        self.assertEqual((p["file"]["counts"]["decks"], p["file"]["left_out"]), (0, {}))
        self.restore(raw)
        self.assertEqual(self.count("SELECT COUNT(*) FROM decks WHERE auto = 1"), 2)

    def test_a_plan_that_ended_leaves_her_what_she_already_keeps(self):
        self.many(5, 2)
        raw = self.download()
        self.on_plan("free")          # (the subscription ended: her five lessons and ten decks stay, and a restore of the same ones does not take any away)
        out = self.restore(raw)
        self.assertEqual(out["file"]["left_out"], {})
        self.assertEqual((self.count("SELECT COUNT(*) FROM lessons"), self.count("SELECT COUNT(*) FROM decks WHERE auto = 0")), (5, 10))
        lids = [r[0] for r in self.app.db.execute("SELECT id FROM lessons ORDER BY id")]
        self.empty_her(lids[:2])          # she deletes two lessons: three remain with six decks, and the file brings back no more than the plan holds or than she keeps now
        out = self.restore(raw)
        self.assertEqual(out["file"]["left_out"], {"lessons": 2, "decks": 4})
        self.assertEqual((self.count("SELECT COUNT(*) FROM lessons"), self.count("SELECT COUNT(*) FROM decks WHERE auto = 0")), (3, 6))

    def test_a_paid_plan_is_not_cut_by_the_number_of_lessons_it_gives_in_a_cycle(self):
        lids = self.many(5, 1)
        self.app.db.execute("UPDATE plans SET max_lessons = 2 WHERE code = 'monthly'")          # (what a cycle gives her to read is not what she may keep)
        self.app.db.commit()
        raw = self.download()
        self.empty_her(lids)
        p = self.preview(raw)
        self.assertEqual((p["file"]["counts"]["lessons"], p["file"]["left_out"]), (5, {}))
        self.restore(raw)
        self.assertEqual(self.count("SELECT COUNT(*) FROM lessons"), 5)

    def test_the_deck_the_app_keeps_for_a_lesson_never_takes_the_place_of_hers(self):
        lids = self.many(5, 2)
        for lid in lids:
            self.assertEqual(self.c.get(f"/lessons/{lid}/today").status_code, 302)          # (these are made last: the newest decks of all)
        raw = self.download()
        self.empty_her(lids)
        self.on_plan("free")
        out = self.restore(raw)
        self.assertEqual(out["file"]["left_out"], {"lessons": 2, "decks": 5})
        self.assertEqual(self.count("SELECT COUNT(*) FROM decks WHERE auto = 0"), 5)
        self.assertEqual(self.count("SELECT COUNT(*) FROM decks WHERE auto = 1"), 3)          # one for each lesson she keeps

    def test_going_back_to_the_safety_copy_is_never_cut(self):
        self.many(5, 2)
        empty = self.download(c=self.second_teacher())
        self.restore(empty)          # she has nothing now, and the safety copy holds her five lessons and ten decks
        self.assertEqual(self.count("SELECT COUNT(*) FROM lessons"), 0)
        self.on_plan("free")          # the plan holds three, the copy has five: it is hers as she left it
        out = self.undo()
        self.assertEqual(out.status_code, 200, out.get_data(as_text=True))
        self.assertEqual(out.get_json()["file"]["left_out"], {})
        self.assertEqual((self.count("SELECT COUNT(*) FROM lessons"), self.count("SELECT COUNT(*) FROM decks WHERE auto = 0")), (5, 10))

    def test_what_a_restore_keeps_does_not_move_the_questions_the_results_and_the_exams_of_the_lessons_kept(self):
        lids = self.many(3, 1)
        qs = self.c.get(f"/api/lessons/{lids[0]}/questions").get_json()["questions"]
        st = self.midterm()["students"]
        d = self.app.db.execute("SELECT id FROM decks WHERE lesson_id = ? AND auto = 0", (lids[0],)).fetchone()[0]
        who = list(st.values())[0]
        self.assertEqual(self.api("post", "/api/results", {"student_id": who, "deck_id": d, "question_id": qs[0]["id"], "game": "pick", "correct": 1, "run": "x"}).status_code, 200)
        raw = self.download()
        mine = self.canon(1)
        self.empty_her(lids)
        self.on_plan("free")
        self.restore(raw)
        self.assertEqual(self.canon(1), mine)          # three lessons fit the free plan: nothing was cut, nothing moved


# ================================================================ the files she uploaded
class Files(Backup):
    def lesson_row(self, lid=None):
        sql = "SELECT * FROM lessons" + (" WHERE id = ?" if lid else " ORDER BY id")
        return self.app.db.execute(sql, (lid,) if lid else ()).fetchone()

    def path(self, name):
        return self.app.cfg.upload_dir / name

    def test_a_lesson_that_is_still_hers_keeps_its_file_and_can_be_read_again(self):
        self.rich(close=False)
        row = self.lesson_row()
        raw = self.download()
        self.assertTrue(self.path(row["stored_name"]).is_file())
        self.restore(raw)
        again = self.lesson_row()
        self.assertEqual(again["stored_name"], row["stored_name"])
        self.assertTrue(self.path(again["stored_name"]).is_file())
        self.assertEqual(self.api("post", f"/api/lessons/{again['id']}/regenerate").status_code, 200)          # its original is still here
        self.assertEqual(self.lesson_row(again["id"])["status"], "ready")

    def test_two_lessons_that_look_the_same_do_not_share_one_file(self):
        self.rich(close=False)
        row = self.lesson_row()
        manifest, tables = self.unpack(self.download())
        lessons = [dict(r) for r in tables["lessons"]]
        lessons.append({**lessons[0], "id": max(r["id"] for r in lessons) + 1})
        self.restore(self.pack(manifest, {**tables, "lessons": lessons}))
        names = [r[0] for r in self.app.db.execute("SELECT stored_name FROM lessons ORDER BY id")]
        self.assertEqual(len(names), 2)
        self.assertEqual(len(set(names)), 2)
        self.assertEqual(sum(n == row["stored_name"] for n in names), 1)
        self.assertEqual(sum(bool(re.fullmatch(r"restored-[0-9a-f]{32}", n)) for n in names), 1)
        self.assertTrue(self.path(row["stored_name"]).is_file())

    def test_the_file_of_a_lesson_that_is_not_in_the_backup_goes_with_the_restore(self):
        self.rich(close=False)
        raw = self.download()
        extra = self.lesson(name="second.pptx")
        gone = self.path(self.lesson_row(extra)["stored_name"])
        keep = self.path(self.lesson_row()["stored_name"])
        self.assertTrue(gone.is_file())
        self.restore(raw)
        self.assertFalse(gone.exists())
        self.assertTrue(keep.is_file())
        self.assertEqual(self.count("SELECT COUNT(*) FROM lessons"), 1)

    def test_a_refused_file_deletes_nothing_from_the_disk(self):
        self.rich(close=False)
        names = [r[0] for r in self.app.db.execute("SELECT stored_name FROM lessons")]
        manifest, tables = self.unpack(self.download())
        students = [dict(r) for r in tables["students"]]
        students[0]["class_id"] = 987654
        bad = self.pack(manifest, {**tables, "students": students})
        self.put("/api/backup/restore", bad, status=400)
        self.assertTrue(all(self.path(n).is_file() for n in names))
        self.assertEqual([r[0] for r in self.app.db.execute("SELECT stored_name FROM lessons")], names)

    def test_a_lesson_that_comes_back_without_its_file_still_works_and_says_why_it_can_not_be_read_again(self):
        self.rich(close=False)
        raw = self.download()
        lid = self.lesson_row()["id"]
        self.assertEqual(self.api("delete", f"/api/lessons/{lid}").status_code, 200)
        self.restore(raw)
        row = self.lesson_row()
        self.assertRegex(row["stored_name"], r"^restored-[0-9a-f]{32}$")
        self.assertFalse(self.path(row["stored_name"]).exists())
        self.assertEqual((row["status"], bool(row["text"])), ("ready", True))
        qs = self.c.get(f"/api/lessons/{row['id']}/questions").get_json()["questions"]
        self.assertGreaterEqual(len(qs), 3)
        r = self.api("post", f"/api/lessons/{row['id']}/regenerate")
        self.assertEqual(r.status_code, 409)
        self.assertIn("غير محفوظ", r.get_json()["error"])
        self.assertEqual(self.lesson_row()["status"], "ready")          # nothing was started, nothing was lost
        self.assertEqual(len(self.c.get(f"/api/lessons/{row['id']}/questions").get_json()["questions"]), len(qs))
        self.assertEqual(self.c.get(f"/lessons/{row['id']}").status_code, 200)
        self.assertEqual(self.c.get(f"/lessons/{row['id']}/today").status_code, 302)          # today's lesson opens from the text and questions kept
        self.assertEqual(self.c.get(f"/api/lessons/{row['id']}/today").status_code, 200)
        self.assertEqual(self.api("delete", f"/api/lessons/{row['id']}").status_code, 200)          # and deleting it has no file to remove

    def test_a_lesson_made_from_a_book_has_no_file_to_lose(self):
        w = self.rich(close=False)
        item = self.plan(w["cid"], w["sid"])["items"][2]
        r = self.api("post", f"/api/plan/{item['id']}/lesson")
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        lid = r.get_json()["lesson_id"]
        self.assertEqual(self.lesson_row(lid)["kind"], "book")
        raw = self.download()
        self.empty_lessons()
        self.restore(raw)
        row = self.app.db.execute("SELECT * FROM lessons WHERE kind = 'book'").fetchone()
        self.assertEqual(row["status"], "ready")
        self.assertEqual(self.api("post", f"/api/lessons/{row['id']}/regenerate").status_code, 200)          # its text is in the book: it can be made again
        self.assertEqual(self.lesson_row(row["id"])["status"], "ready")

    def empty_lessons(self):
        for (lid,) in self.app.db.execute("SELECT id FROM lessons").fetchall():
            self.assertEqual(self.api("delete", f"/api/lessons/{lid}").status_code, 200)

    def test_another_account_gets_the_lessons_and_the_books_without_files(self):
        self.rich(close=False)
        raw = self.download()
        b = self.second_teacher()
        ub = self.uid_of("b@example.com")
        self.restore(raw, c=b)
        mine = {r[0] for r in self.app.db.execute("SELECT stored_name FROM lessons WHERE user_id = 1")}
        hers = [r[0] for r in self.app.db.execute("SELECT stored_name FROM lessons WHERE user_id = ?", (ub,))]
        self.assertTrue(hers and all(re.fullmatch(r"restored-[0-9a-f]{32}", n) for n in hers), hers)
        self.assertFalse(mine & set(hers))
        self.assertEqual({r[0] for r in self.app.db.execute("SELECT stored_name FROM books WHERE user_id = ?", (ub,))}, {""})
        lid = self.app.db.execute("SELECT id FROM lessons WHERE user_id = ?", (ub,)).fetchone()[0]
        self.assertEqual(self.api("delete", f"/api/lessons/{lid}", c=b).status_code, 200)
        self.assertTrue(all(self.path(n).is_file() for n in mine))          # deleting hers never touches mine
        self.assertEqual(self.api("get", f"/api/lessons/{self.lesson_row()['id']}/questions", c=b).status_code, 404)

    def test_a_book_keeps_its_outline_and_loses_only_its_file(self):
        w = self.rich(close=False)
        before = self.app.db.execute("SELECT stored_name FROM books").fetchone()[0]
        raw = self.download()
        bid = self.app.db.execute("SELECT id FROM books").fetchone()[0]
        outline = self.canon(1)["book_lessons"]
        self.assertEqual(self.api("delete", f"/api/books/{bid}").status_code, 200)
        self.assertFalse(before and self.path(before).exists())
        self.restore(raw)
        self.assertEqual(self.canon(1)["book_lessons"], outline)
        row = self.app.db.execute("SELECT * FROM books").fetchone()
        self.assertEqual((row["stored_name"], row["status"]), ("", "ready"))
        self.assertEqual(self.api("delete", f"/api/books/{row['id']}").status_code, 200)

    def test_nothing_the_restore_writes_goes_outside_the_upload_folder(self):
        self.rich(close=False)
        raw = self.download()
        before = sorted(p.name for p in self.app.cfg.instance.rglob("*") if p.is_file())
        self.restore(raw)
        self.restore(raw)
        after = sorted(p.name for p in self.app.cfg.instance.rglob("*") if p.is_file())
        self.assertEqual(before, after)          # no file came from the restore: not one, anywhere


# ================================================================ the page, the walls and the limits
class Pages(Backup):
    def anon(self):
        return self.client()

    def test_every_door_needs_a_login(self):
        a = self.anon()
        for method, url in (("get", "/api/backup"), ("get", "/api/backup/download")):
            self.assertEqual(getattr(a, method)(url).status_code, 401, url)
        for url in ("/api/backup/preview", "/api/backup/restore", "/api/backup/undo"):
            r = a.post(url, data={"file": (io.BytesIO(b"PK\x03\x04"), "b.zip"), "confirm": "yes"}, content_type="multipart/form-data")
            self.assertIn(r.status_code, (401, 403), url)          # (a form with no token is refused before it is looked at)
        r = a.get("/backup")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/login", r.headers["Location"])

    def test_a_post_without_the_token_is_refused(self):
        self.rich()
        raw = self.download()
        before = self.snapshot()
        for url in ("/api/backup/preview", "/api/backup/restore"):
            r = self.c.post(url, data={"file": (io.BytesIO(raw), "b.zip"), "confirm": "yes"}, content_type="multipart/form-data")
            self.assertEqual(r.status_code, 403, url)
            r = self.c.post(url, data={"file": (io.BytesIO(raw), "b.zip"), "confirm": "yes"}, headers={"X-CSRF": "wrong"}, content_type="multipart/form-data")
            self.assertEqual(r.status_code, 403, url)
        self.assertEqual(self.c.post("/api/backup/undo", json={"confirm": True}).status_code, 403)
        self.assertEqual(self.snapshot(), before)

    def test_going_back_needs_a_real_yes(self):
        self.rich()
        self.restore(self.download())
        before = self.snapshot()
        for v in ("yes", "true", 1, [1], {"a": 1}, None, "", 0, False):
            r = self.api("post", "/api/backup/undo", {"confirm": v})
            self.assertEqual(r.status_code, 400, v)
        self.assertEqual(self.api("post", "/api/backup/undo", {}).status_code, 400)
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(self.undo().status_code, 200)

    def test_going_back_with_no_safety_copy_says_so(self):
        r = self.undo()
        self.assertEqual(r.status_code, 404)
        self.assertIn("error", r.get_json())

    def test_the_status_says_what_she_has_and_whether_there_is_a_safety_copy(self):
        w = self.rich()
        s = self.c.get("/api/backup").get_json()
        self.assertEqual(s["max_mb"], backup.MAX_FILE_MB)
        self.assertIsNone(s["safety"])
        self.assertEqual(s["current"], self.counts())
        self.assertEqual(s["current"]["classes"], 1)
        self.assertEqual(s["current"]["students"], 4)
        raw = self.download()
        self.restore(raw)
        s = self.c.get("/api/backup").get_json()
        self.assertEqual(s["safety"]["counts"]["students"], 4)
        self.assertGreater(s["safety"]["size"], 1000)
        self.assertIn("الساعة", s["safety"]["created_text"])
        self.assertNotIn("data", s["safety"])          # (the copy itself never goes to the page)
        b = self.second_teacher()
        self.assertIsNone(b.get("/api/backup").get_json()["safety"])          # hers is hers

    def test_the_page_is_there_and_is_not_kept_by_the_browser(self):
        r = self.c.get("/backup")
        self.assertEqual(r.status_code, 200)
        html = r.get_data(as_text=True)
        for mount in ("bk-root", "bk-now", "bk-download", "bk-file", "bk-preview", "bk-done", "bk-safety", "bk-err"):
            self.assertIn(f'id="{mount}"', html, mount)
        self.assertIn(f'data-max-mb="{backup.MAX_FILE_MB}"', html)
        self.assertIn("js/backup.js", html)
        self.assertIn("css/backup.css", html)
        self.assertNotRegex(html, r"\son\w+=\"", "no inline handler: the page's policy forbids them")
        self.assertNotIn("<script>", html)
        self.assertEqual(r.headers["Cache-Control"], "no-store")
        for path in ("/static/js/backup.js", "/static/css/backup.css"):
            self.assertEqual(self.c.get(path).status_code, 200, path)

    def test_the_dashboard_and_the_end_of_the_term_point_to_it(self):
        html = self.c.get("/dashboard").get_data(as_text=True)
        self.assertIn('id="backup-link"', html)
        self.assertIn('href="/backup"', html)
        js = self.c.get("/static/js/term.js").get_data(as_text=True)
        self.assertIn("/backup", js)

    def test_a_download_has_a_name_with_the_day_and_comes_as_a_file(self):
        self.rich()
        r = self.c.get("/api/backup/download")
        self.assertEqual(r.mimetype, "application/zip")
        self.assertEqual(r.headers["Content-Disposition"], f'attachment; filename="lessonplay-backup-{self.today.isoformat()}.zip"')
        self.assertEqual(r.headers["Cache-Control"], "no-store")
        self.assertEqual(int(r.headers["Content-Length"]), len(r.data))

    # ---- how often
    def test_the_downloads_in_an_hour_are_limited(self):
        for _ in range(10):
            self.download()
        r = self.c.get("/api/backup/download")
        self.assertEqual(r.status_code, 429)
        self.assertIn("error", r.get_json())
        b = self.second_teacher()
        self.download(c=b)          # another teacher has her own count

    def test_the_files_she_tries_in_an_hour_are_limited_and_a_refused_file_counts(self):
        raw = self.download()
        for i in range(15):
            self.put("/api/backup/preview", raw if i % 2 else b"not a backup", confirm=False, status=200 if i % 2 else 400)
        r = self.put("/api/backup/preview", raw, confirm=False, status=429)
        self.assertIn("error", r)
        b = self.second_teacher()
        self.preview(raw, c=b)

    def test_the_restores_in_an_hour_are_limited_and_going_back_counts_with_them(self):
        self.rich()
        raw = self.download()
        for _ in range(5):
            self.restore(raw)
        self.assertEqual(self.undo().status_code, 200)          # the sixth
        before = self.snapshot()
        self.restore(raw, status=429)
        self.assertEqual(self.undo().status_code, 429)
        self.assertEqual(self.snapshot(), before)
        self.put("/api/backup/restore", raw, confirm=False, status=400)          # (not confirmed: it says so before it counts anything)

    def test_two_restores_of_one_account_at_once_do_not_run_together(self):
        self.rich()
        raw = self.download()
        with backup._running_lock:
            backup._running[1] = True
        try:
            before = self.snapshot()
            r = self.put("/api/backup/restore", raw, status=400)
            self.assertEqual(r["error"], backup.BUSY)
            self.assertEqual(self.snapshot(), before)
        finally:
            backup._running.pop(1, None)
        self.restore(raw)
