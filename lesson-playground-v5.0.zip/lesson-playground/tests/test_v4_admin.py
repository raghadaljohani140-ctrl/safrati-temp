"""Version 4: the manager's pages (/admin): who may open them, search, requests and receipts, extend / grant / stop, the paid reader's settings and log,
the money (expenses, taxes, net profit, CSV), the packages and the platform switches, the charts, and an empty site."""
import io
import re
import time
import unittest

from app import admin, aimodel, billing, charts
from tests import fixtures as F
from tests.test_billing import DAY, IBAN, Money

PAGES = ["/admin", "/admin/subscriptions", "/admin/ai", "/admin/finance", "/admin/finance.csv", "/admin/platform"]
POSTS = ["/admin/requests/1/confirm", "/admin/requests/1/reject", "/admin/subscriptions/2/extend", "/admin/subscriptions/2/grant", "/admin/subscriptions/2/stop",
         "/admin/ai/settings", "/admin/finance/bank", "/admin/finance/general", "/admin/finance/expenses", "/admin/finance/expenses/1/delete", "/admin/finance/expenses/1/stop",
         "/admin/platform/plans", "/admin/platform/plans/monthly", "/admin/platform/plans/monthly/delete", "/admin/platform/settings", "/admin/settings"]


class World(Money):
    """The manager and three teachers: Sara (will pay), Noura, Huda."""

    def world(self):
        self.setup_bank()
        self.boss = self.admin()
        self.people = {}
        for key, name in (("sara", "سارة العتيبي"), ("noura", "نورة القحطاني"), ("huda", "هدى الشمري")):
            c = self.client()
            self.register(c, f"{key}@example.com", name)
            setattr(self, key, c)
        self.db = self.app.db

    def user(self, email):
        return self.db.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()

    def page(self, url, **q):
        return self.boss.get(url, query_string=q or None).get_data(as_text=True)

    def events(self, email):
        return [(e["kind"], e["days"], e["note"]) for e in self.db.execute("SELECT * FROM plan_events WHERE user_id = ? ORDER BY id", (self.uid(email),))]

    def lesson_of(self, c, title="خلية النبات"):
        r = self.upload(c, "cell.pptx", F.pptx_bytes(), title=title)
        return int(re.search(r"/lessons/(\d+)", r.headers["Location"]).group(1))


class AccessTests(World):
    def test_visitors_go_to_login_teachers_get_not_found_the_manager_gets_the_page(self):
        self.world()
        paths = PAGES + [f"/admin/subscriptions/{self.uid('sara@example.com')}"]
        anon = self.client()
        for p in paths:
            r = anon.get(p)
            self.assertEqual(r.status_code, 302, p)
            self.assertIn("/login", r.headers["Location"], p)
            self.assertEqual(self.sara.get(p).status_code, 404, p)
            self.assertEqual(self.boss.get(p).status_code, 200, p)

    def test_no_action_works_for_a_teacher_or_a_visitor(self):
        self.world()
        before = self.db.execute("SELECT COUNT(*) FROM plans").fetchone()[0]
        for p in POSTS:
            self.assertEqual(self.post(self.sara, p, days="5", plan="monthly", code="xx", name="خدعة", ai_cap_sar="9999").status_code, 404, p)
            self.assertEqual(self.post(self.client(), p).status_code, 302, p)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM plans").fetchone()[0], before)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM expenses").fetchone()[0], 0)
        self.assertEqual(self.user("sara@example.com")["plan_code"], "free")

    def test_the_manager_account_is_not_a_subscriber(self):
        self.world()
        self.assertEqual(self.boss.get(f"/admin/subscriptions/{self.uid('boss@example.com')}").status_code, 404)
        self.assertEqual(self.post(self.boss, f"/admin/subscriptions/{self.uid('boss@example.com')}/grant", plan="monthly", days="5").status_code, 404)
        self.assertNotIn("boss@example.com", self.page("/admin/subscriptions"))

    def test_pages_obey_the_content_policy(self):
        """No inline script, style or event handler: the site's policy only allows files from itself."""
        self.world()
        uid = self.uid("sara@example.com")
        for p in PAGES[:4] + ["/admin/platform", f"/admin/subscriptions/{uid}", "/admin/ai?m=all"]:
            html = self.page(p)
            self.assertEqual(re.findall(r"<script(?![^>]*\bsrc=)[^>]*>", html), [], p)
            self.assertIsNone(re.search(r"\sstyle\s*=", html), p)
            self.assertIsNone(re.search(r"\son[a-z]+\s*=", html), p)
            self.assertNotIn("javascript:", html, p)


class OverviewTests(World):
    def test_the_overview_shows_every_number_the_manager_asked_for(self):
        self.world()
        req = self.ask(self.sara)
        html = self.page("/admin")
        for label in ("إجمالي المشتركات", "المشتركات النشطات", "المشتركات المجانيات", "الاشتراكات المنتهية", "طلبات الاشتراك المعلّقة", "إجمالي الإيرادات", "صافي الربح", "تكلفة الذكاء الاصطناعي"):
            self.assertIn(label, html)
        self.assertIn(req["ref_code"], html)                                      # the waiting request is on the first page
        self.assertEqual(billing.subscriber_counts(self.db), {"total": 3, "active": 0, "soon": 0, "free": 3, "expired": 0, "pending": 1})
        self.assertIn("<svg", html)

    def test_counts_follow_what_the_manager_does(self):
        self.world()
        sara, noura = self.uid("sara@example.com"), self.uid("noura@example.com")
        billing.grant_plan(self.db, sara, "monthly", 30)
        billing.grant_plan(self.db, noura, "monthly", 30)
        billing.stop_plan(self.db, noura)                                         # she paid once: stopped is «expired», not «free»
        self.assertEqual(billing.subscriber_counts(self.db), {"total": 3, "active": 1, "soon": 0, "free": 1, "expired": 1, "pending": 0})
        billing.grant_plan(self.db, self.uid("huda@example.com"), "monthly", 3)       # three days left: still active, and flagged as ending soon
        counts = billing.subscriber_counts(self.db)
        self.assertEqual((counts["active"], counts["soon"]), (2, 1))
        self.assertIn("ينتهي خلال أسبوع", self.page("/admin"))


class SearchTests(World):
    def test_search_by_name_email_and_request_number(self):
        self.world()
        req = self.ask(self.sara)
        code = req["ref_code"]
        find = lambda q: self.page("/admin/subscriptions", q=q)
        page = find("سارة")
        self.assertIn("سارة العتيبي", page)
        self.assertNotIn("نورة القحطاني", page)
        page = find("noura@")
        self.assertIn("نورة القحطاني", page)
        self.assertNotIn("سارة العتيبي", page)
        digits = code.translate(str.maketrans("0123456789", "٠١٢٣٤٥٦٧٨٩"))
        for q in (code, code.lower(), code.replace("-", " "), code.replace("-", ""), digits):       # LP-1001, lp1001, LP 1001, Arabic digits
            page = find(q)
            self.assertIn("سارة العتيبي", page, q)
            self.assertNotIn("نورة القحطاني", page, q)
        self.assertNotIn("سارة العتيبي", find("%"))                              # a percent sign is just a letter, not «everything»
        self.assertNotIn("سارة العتيبي", find("_"))
        self.assertEqual(self.boss.get("/admin/subscriptions?q=" + "x" * 500).status_code, 200)

    def test_status_filters(self):
        self.world()
        billing.grant_plan(self.db, self.uid("sara@example.com"), "monthly", 30)
        billing.grant_plan(self.db, self.uid("noura@example.com"), "monthly", 30)
        billing.stop_plan(self.db, self.uid("noura@example.com"))
        for st, who, others in (("active", "سارة", ("نورة", "هدى")), ("expired", "نورة", ("سارة", "هدى")), ("free", "هدى", ("سارة", "نورة"))):
            page = self.page("/admin/subscriptions", st=st)
            self.assertIn(who, self.table_names(page), st)
            for o in others:
                self.assertNotIn(o, self.table_names(page), st)
        self.assertEqual(self.boss.get("/admin/subscriptions?st=nonsense&p=abc").status_code, 200)

    def table_names(self, html):
        """Only the subscribers' list (the part after its heading), not the requests above it."""
        i = html.find("المشتركات (")
        return html[i:] if i >= 0 else html


class RequestTests(World):
    def test_confirm_and_reject_go_back_to_the_page_they_came_from(self):
        self.world()
        a, b, c = self.ask(self.sara), self.ask(self.noura), self.ask(self.huda)
        r = self.post(self.boss, f"/admin/requests/{a['id']}/confirm", next="/admin/subscriptions?st=active")
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r.headers["Location"].startswith("/admin/subscriptions?st=active&msg="), r.headers["Location"])
        sara = self.user("sara@example.com")
        self.assertEqual(sara["plan_code"], "monthly")
        self.assertAlmostEqual(sara["plan_expires"] - time.time(), 30 * DAY, delta=120)
        r = self.post(self.boss, f"/admin/requests/{b['id']}/reject", note="الإيصال غير واضح", next="https://evil.example/")
        self.assertTrue(r.headers["Location"].startswith("/admin?msg="), r.headers["Location"])          # an outside address is never followed
        row = self.db.execute("SELECT * FROM subscription_requests WHERE id = ?", (b["id"],)).fetchone()
        self.assertEqual((row["status"], row["note"]), ("rejected", "الإيصال غير واضح"))
        self.assertEqual(self.user("noura@example.com")["plan_code"], "free")
        r = self.post(self.boss, f"/admin/requests/{c['id']}/reject", next="//evil.example")
        self.assertTrue(r.headers["Location"].startswith("/admin?msg="), r.headers["Location"])
        for rid in (a["id"], b["id"]):                                                    # a decided request can not be decided again
            self.assertEqual(self.post(self.boss, f"/admin/requests/{rid}/confirm").status_code, 404)
        self.assertEqual(self.post(self.boss, f"/admin/requests/{c['id']}/refund").status_code, 404)

    def test_receipts_are_seen_by_the_manager_only(self):
        self.world()
        req = self.ask(self.sara)
        self.assertEqual(self.boss.get(f"/admin/requests/{req['id']}/receipt").status_code, 404)             # nothing uploaded yet
        png = b"\x89PNG\r\n\x1a\n" + b"0" * 64
        self.sara.post(f"/subscribe/{req['id']}/paid", content_type="multipart/form-data",
                       data={"_csrf": self.token(self.sara), "payer_name": "سارة العتيبي", "transfer_date": "2026-11-03", "receipt": (io.BytesIO(png), "r.png")})
        r = self.boss.get(f"/admin/requests/{req['id']}/receipt")
        self.assertEqual((r.status_code, r.get_data()), (200, png))
        self.assertEqual(self.noura.get(f"/admin/requests/{req['id']}/receipt").status_code, 404)
        self.assertIn("سارة العتيبي", self.page("/admin"))                                          # the payer's name and the receipt link are on the request card
        self.assertIn(f"/admin/requests/{req['id']}/receipt", self.page("/admin"))


class SubscriberTests(World):
    def test_grant_extend_and_stop(self):
        self.world()
        email = "sara@example.com"
        uid = self.uid(email)
        lid = self.lesson_of(self.sara)
        act = lambda a, **kw: self.post(self.boss, f"/admin/subscriptions/{uid}/{a}", **kw)
        r = act("grant", plan="monthly", days="10", note="هدية")
        self.assertIn(f"/admin/subscriptions/{uid}", r.headers["Location"])
        u = self.user(email)
        self.assertEqual(u["plan_code"], "monthly")
        self.assertAlmostEqual(u["plan_expires"] - time.time(), 10 * DAY, delta=120)
        act("extend", days="5")                                                           # from the end date, not from today
        self.assertAlmostEqual(self.user(email)["plan_expires"] - time.time(), 15 * DAY, delta=120)
        act("extend", days="٣")                                                           # Arabic digits
        self.assertAlmostEqual(self.user(email)["plan_expires"] - time.time(), 18 * DAY, delta=120)
        kept = self.user(email)["plan_expires"]
        for bad in ("0", "-4", "99999", "abc", ""):
            act("extend", days=bad)
        act("grant", plan="free", days="5")
        act("grant", plan="nonexistent", days="5")
        self.assertEqual(self.user(email)["plan_expires"], kept)
        self.assertEqual(self.events(email), [("grant", 10, "هدية"), ("extend", 5, ""), ("extend", 3, "")])
        html = self.page(f"/admin/subscriptions/{uid}")
        self.assertIn("منح باقة", html)
        self.assertIn("تمديد", html)
        act("stop", note="طلبت الإيقاف")
        u = self.user(email)
        self.assertEqual((u["plan_code"], u["plan_expires"]), ("free", 0))
        self.assertEqual(self.events(email)[-1], ("stop", 0, "طلبت الإيقاف"))
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM lessons WHERE id = ?", (lid,)).fetchone()[0], 1)         # her lessons stay
        self.assertEqual(self.sara.get(f"/lessons/{lid}").status_code, 200)
        act("stop")                                                                       # already free: nothing happens
        act("extend", days="5")                                                           # nothing to extend
        self.assertEqual(len(self.events(email)), 4)
        self.assertEqual(act("explode").status_code, 404)

    def test_renewing_early_loses_no_days_and_a_new_plan_starts_today(self):
        self.world()
        email = "sara@example.com"
        uid = self.uid(email)
        billing.grant_plan(self.db, uid, "monthly", 20)
        req = self.ask(self.sara)                                                         # she asks the same plan again before it ends
        self.post(self.boss, f"/admin/requests/{req['id']}/confirm")
        self.assertAlmostEqual(self.user(email)["plan_expires"] - time.time(), 50 * DAY, delta=120)
        billing.grant_plan(self.db, uid, "yearly", 10)                                    # another plan: starts today
        self.assertAlmostEqual(self.user(email)["plan_expires"] - time.time(), 10 * DAY, delta=120)

    def test_the_subscriber_page_tells_the_whole_story(self):
        self.world()
        uid = self.uid("sara@example.com")
        req = self.ask(self.sara)
        self.post(self.boss, f"/admin/requests/{req['id']}/confirm")
        billing.log_ai(self.db, uid, None, aimodel.MODEL, 3000, 1500)
        html = self.page(f"/admin/subscriptions/{uid}")
        for text in ("سارة العتيبي", "sara@example.com", req["ref_code"], "نشط"):
            self.assertIn(text, html)
        self.assertEqual(self.boss.get("/admin/subscriptions/99999").status_code, 404)


class AiAdminTests(World):
    def settings(self, **kw):
        base = {"ai_cap_sar": "50", "quota_free": "0", "quota_monthly": "40", "quota_yearly": "40", "ai_enabled": "1"}
        return self.post(self.boss, "/admin/ai/settings", **{**base, **kw})

    def test_cap_quotas_and_the_manual_switch(self):
        self.world()
        db = self.db
        self.settings(ai_cap_sar="12.5", quota_monthly="25", quota_yearly="60", ai_enabled="")
        self.assertEqual(billing.ai_cap_halalas(db), 1250)
        self.assertFalse(billing.ai_switch_on(db))
        self.assertEqual({r["code"]: r["ai_quota"] for r in db.execute("SELECT * FROM plans")}, {"free": 0, "monthly": 25, "yearly": 60})
        user = self.user("sara@example.com")
        billing.grant_plan(db, user["id"], "monthly", 30)
        user = self.user("sara@example.com")
        self.assertFalse(billing.ai_allowed(db, user))                                   # switched off by hand
        self.settings(ai_cap_sar="12.5", quota_monthly="25")
        self.assertTrue(billing.ai_switch_on(db))
        self.assertTrue(billing.ai_allowed(db, user))
        for _ in range(25):
            billing.log_ai(db, user["id"], None, aimodel.MODEL, 3000, 1500)
        self.assertFalse(billing.ai_allowed(db, user))                                   # the plan's 25 lessons are used
        self.settings(ai_cap_sar="٣٠٫٥", quota_monthly="٢٦")                                 # Arabic digits and the Arabic decimal mark
        self.assertEqual(billing.ai_cap_halalas(db), 3050)
        self.assertTrue(billing.ai_allowed(db, user))                                    # one more lesson allowed now
        before = billing.ai_cap_halalas(db)
        r = self.settings(ai_cap_sar="abc")
        self.assertIn("msg=", r.headers["Location"])
        self.assertEqual(billing.ai_cap_halalas(db), before)                             # a wrong number changes nothing
        self.settings(ai_cap_sar="-3")
        self.assertEqual(billing.ai_cap_halalas(db), before)

    def test_the_cap_stops_the_paid_reader_by_itself(self):
        self.world()
        db = self.db
        billing.grant_plan(db, self.uid("sara@example.com"), "monthly", 30)
        user = self.user("sara@example.com")
        self.settings(ai_cap_sar="0.05")                                                  # five halalas
        self.assertTrue(billing.ai_allowed(db, user))
        for _ in range(5):
            billing.log_ai(db, user["id"], None, aimodel.MODEL, 30_000, 10_000)           # about a hundredth of a riyal each
        self.assertFalse(billing.ai_allowed(db, user))
        html = self.page("/admin")
        self.assertIn("سقف", html)
        self.assertIn("توقف الذكاء المدفوع تلقائيًا", html)

    def test_the_usage_log_and_its_filters(self):
        self.world()
        db = self.db
        sara, noura = self.uid("sara@example.com"), self.uid("noura@example.com")
        lid = self.lesson_of(self.sara, "خلية النبات")
        billing.log_ai(db, sara, lid, aimodel.MODEL, 3000, 1500)
        billing.log_ai(db, noura, None, aimodel.MODEL, 100, 100)
        billing.log_ai(db, noura, None, aimodel.MODEL, 100, 100, now=time.time() - 70 * DAY)             # an old month
        page = self.page("/admin/ai")
        self.assertIn("خلية النبات", page)
        self.assertIn("سارة العتيبي", page)
        self.assertIn("نورة القحطاني", page)
        self.assertIn(">3<", page.replace(" ", "").replace("\n", ""))                    # the number of calls this month appears as a figure
        only = self.page("/admin/ai", q="خلية")
        self.assertIn("خلية النبات", only)
        self.assertNotIn("نورة القحطاني", only.split("سجل")[-1])
        self.assertEqual(self.boss.get("/admin/ai?m=all").status_code, 200)
        self.assertEqual(self.boss.get("/admin/ai?m=2026-13").status_code, 200)         # a wrong month falls back to this one
        self.assertEqual(self.boss.get("/admin/ai?m=<script>").status_code, 200)
        self.assertEqual(self.boss.get("/admin/ai?p=999").status_code, 200)
        stats = billing.ai_stats(db)
        self.assertEqual((stats["month"]["calls"], stats["all"]["calls"]), (2, 3))
        self.assertEqual(stats["month"]["lessons"], 1)                                   # lessons processed: only hers (the other call belongs to no lesson)


class FinanceTests(World):
    def test_net_profit_counts_everything(self):
        self.world()
        db = self.db
        cur = billing.mkey(time.time())
        self.post(self.boss, "/admin/finance/general", fixed_sar="10", vat="1")
        req = self.ask(self.sara)
        self.post(self.boss, f"/admin/requests/{req['id']}/confirm")                     # 29 riyals, VAT inside
        billing.log_ai(db, self.uid("sara@example.com"), None, aimodel.MODEL, 3000, 1500)  # one halala
        self.post(self.boss, "/admin/finance/expenses", kind="fixed", title="استضافة", amount="5", month=cur)
        self.post(self.boss, "/admin/finance/expenses", kind="variable", title="إعلان", amount="2", month=cur)
        fin = billing.finance(db)
        vat = round(2900 - 2900 / 1.15)
        self.assertEqual((fin["gross"], fin["vat"], fin["ai"], fin["fixed"], fin["variable"]), (2900, vat, 1, 1000 + 500, 200))
        self.assertEqual(fin["net"], 2900 - vat - 1 - 1500 - 200)
        html = self.page("/admin/finance")
        self.assertIn(billing.riyals(fin["net"]), html)
        self.assertIn("استضافة", html)
        self.assertIn("إعلان", html)
        csv = self.boss.get("/admin/finance.csv")
        text = csv.get_data(as_text=True)
        self.assertTrue(text.startswith("﻿month,revenue_incl_vat,vat,ai_cost,fixed_costs,variable_costs,net_profit"))
        self.assertIn(f"{cur},29.00,{vat / 100:.2f},0.01,15.00,2.00,{fin['net'] / 100:.2f}", text)
        self.assertIn("attachment", csv.headers["Content-Disposition"])
        self.post(self.boss, "/admin/finance/general", fixed_sar="10")                   # not registered for VAT: nothing to take out
        self.assertEqual(billing.finance(db)["vat"], 0)

    def test_fixed_expenses_can_end_and_any_expense_can_be_deleted(self):
        self.world()
        db = self.db
        cur = billing.mkey(time.time())
        self.post(self.boss, "/admin/finance/general", fixed_sar="0")
        self.post(self.boss, "/admin/finance/expenses", kind="fixed", title="نطاق", amount="12.5", month=billing.madd(cur, -2))
        self.assertEqual(billing.finance(db)["fixed"], 1250)
        months = billing.months_table(db)
        self.assertEqual([m["month"] for m in months][0], billing.madd(cur, -2))         # the table starts at the first month that has anything in it
        eid = db.execute("SELECT id FROM expenses").fetchone()[0]
        self.post(self.boss, f"/admin/finance/expenses/{eid}/stop")
        fin = billing.finance(db)
        self.assertEqual(fin["fixed"], 0)                                                 # counted up to last month, never again
        self.assertEqual(fin["months"][-2]["fixed"], 1250)
        self.post(self.boss, f"/admin/finance/expenses/{eid}/delete")
        self.assertEqual(db.execute("SELECT COUNT(*) FROM expenses").fetchone()[0], 0)
        self.assertEqual(self.post(self.boss, f"/admin/finance/expenses/{eid}/delete").status_code, 404)
        self.assertEqual(self.post(self.boss, "/admin/finance/expenses/1/explode").status_code, 404)

    def test_wrong_expenses_are_refused(self):
        self.world()
        cur = billing.mkey(time.time())
        for kw in (dict(kind="other", title="x", amount="5", month=cur), dict(kind="fixed", title="", amount="5", month=cur), dict(kind="fixed", title="x", amount="0", month=cur),
                   dict(kind="fixed", title="x", amount="-5", month=cur), dict(kind="fixed", title="x", amount="abc", month=cur), dict(kind="fixed", title="x", amount="5", month="2026-13"),
                   dict(kind="fixed", title="x", amount="5", month=""), dict(kind="fixed", title="x", amount="nan", month=cur)):
            r = self.post(self.boss, "/admin/finance/expenses", **kw)
            self.assertIn("msg=", r.headers["Location"], kw)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM expenses").fetchone()[0], 0)

    def test_the_bank_account_is_checked_and_saved(self):
        self.world()
        self.post(self.boss, "/admin/finance/bank", bank_name="بنك الراجحي", bank_holder="رغد", bank_iban="sa03 8000 0000 6080 1016 7519")
        self.assertEqual(self.app.db.execute("SELECT value FROM settings WHERE key = 'bank_iban'").fetchone()[0], IBAN)
        r = self.post(self.boss, "/admin/finance/bank", bank_name="x", bank_holder="y", bank_iban="12345")
        self.assertIn("msg=", r.headers["Location"])
        self.assertEqual(self.app.db.execute("SELECT value FROM settings WHERE key = 'bank_iban'").fetchone()[0], IBAN)       # a wrong IBAN changes nothing
        self.assertIn(IBAN, self.page("/admin/finance"))
        self.ask(self.sara)
        self.assertIn(IBAN, self.sara.get("/subscribe").get_data(as_text=True))          # and a teacher who asked for a plan sees it

    def test_negative_numbers_keep_their_sign_on_the_left(self):
        self.assertEqual(admin._riyals(-821), "⁦-8.21⁩")
        self.assertEqual(admin._riyals(821), "8.21")
        self.assertEqual(admin._riyals(0), "0")
        self.assertEqual(admin._riyals(None), "0")


class PlatformTests(World):
    def plan(self, **kw):
        base = dict(code="term", name="فصلية", period="year", price="99", max_lessons="50", max_decks="60", ai_quota="10", purchasable="1")
        return self.post(self.boss, "/admin/platform/plans", **{**base, **kw})

    def test_a_new_package_is_sold_for_its_own_period_and_price(self):
        self.world()
        db = self.db
        self.plan()
        row = db.execute("SELECT * FROM plans WHERE code = 'term'").fetchone()
        self.assertEqual((row["price_year"], row["price_month"], row["period"], row["purchasable"], row["max_lessons"]), (9900, 0, "year", 1, 50))
        page = self.sara.get("/subscribe").get_data(as_text=True)
        self.assertIn("فصلية", page)
        self.assertIn("99", page)
        self.assertIn("كل سنة", page)
        req = self.ask(self.sara, "term")
        self.assertEqual((req["amount"], req["period"]), (9900, "year"))
        self.post(self.boss, f"/admin/requests/{req['id']}/confirm")
        u = self.user("sara@example.com")
        self.assertEqual(u["plan_code"], "term")
        self.assertAlmostEqual(u["plan_expires"] - time.time(), 365 * DAY, delta=120)
        self.assertEqual(billing.plan_of(db, u)["max_lessons"], 50)

    def test_package_rules(self):
        self.world()
        db = self.db
        n = lambda: db.execute("SELECT COUNT(*) FROM plans").fetchone()[0]
        self.plan()
        self.assertEqual(n(), 4)
        for kw in (dict(), dict(code="Bad Code"), dict(code="1abc"), dict(code="x"), dict(code="new", name="ب"), dict(code="new", period="week"), dict(code="new", price="0"),
                   dict(code="new", price="-5"), dict(code="new", max_lessons="0"), dict(code="new", ai_quota="-1"), dict(code="monthly")):
            self.plan(**kw)
        self.assertEqual(n(), 4)                                                          # none of those was accepted, and «monthly» is not overwritten
        self.assertEqual(db.execute("SELECT price_month FROM plans WHERE code = 'monthly'").fetchone()[0], 2900)
        self.plan(code="gift", name="هدية", price="0", purchasable="")                    # a free package that is not for sale is fine
        self.assertEqual(db.execute("SELECT purchasable FROM plans WHERE code = 'gift'").fetchone()[0], 0)
        self.assertNotIn("هدية", self.sara.get("/subscribe").get_data(as_text=True))
        self.assertEqual(self.post(self.boss, "/admin/platform/plans/gift/delete").status_code, 302)
        self.assertEqual(n(), 4)                                                          # deleted: nobody uses it
        for code in ("free", "monthly", "yearly"):
            self.post(self.boss, f"/admin/platform/plans/{code}/delete")
        self.assertEqual(n(), 4)                                                          # the three base packages stay
        req = self.ask(self.sara, "term")
        self.post(self.boss, f"/admin/requests/{req['id']}/confirm")
        self.post(self.boss, "/admin/platform/plans/term/delete")
        self.assertEqual(db.execute("SELECT COUNT(*) FROM plans WHERE code = 'term'").fetchone()[0], 1)    # a package with subscribers is hidden, not deleted
        self.assertEqual(self.post(self.boss, "/admin/platform/plans/nothing/delete").status_code, 404)

    def test_editing_a_price_keeps_old_requests_as_they_were(self):
        self.world()
        db = self.db
        old = self.ask(self.sara)
        self.post(self.boss, "/admin/platform/plans/monthly", name="شهرية", period="month", price="35", max_lessons="30", max_decks="100", ai_quota="40", purchasable="1")
        self.assertEqual(db.execute("SELECT price_month FROM plans WHERE code = 'monthly'").fetchone()[0], 3500)
        self.assertEqual(db.execute("SELECT amount FROM subscription_requests WHERE id = ?", (old["id"],)).fetchone()[0], 2900)
        self.post(self.sara, f"/subscribe/{old['id']}/cancel")                          # she cancels and asks again: the new request has the new price
        self.assertEqual(self.ask(self.sara)["amount"], 3500)
        self.post(self.boss, "/admin/platform/plans/free", name="مجانية", period="year", price="500", max_lessons="4", max_decks="6", ai_quota="0", purchasable="1")
        free = db.execute("SELECT * FROM plans WHERE code = 'free'").fetchone()
        self.assertEqual((free["price_month"], free["price_year"], free["purchasable"], free["period"], free["max_lessons"]), (0, 0, 0, "", 4))      # free stays free
        self.assertEqual(self.post(self.boss, "/admin/platform/plans/nothing", name="xx", period="month", price="5", max_lessons="3", max_decks="3", ai_quota="0").status_code, 404)

    def test_closing_registrations_and_the_upload_size(self):
        self.world()
        db = self.db
        self.post(self.boss, "/admin/platform/settings", upload_mb="1")                   # the box is unticked: closed
        self.assertEqual(billing.upload_limit_mb(db, self.app.cfg.max_upload_mb), 1)
        newcomer = self.client()
        self.register(newcomer, "new@example.com", "زائرة")
        self.assertIsNone(db.execute("SELECT 1 FROM users WHERE email = 'new@example.com'").fetchone())
        self.assertIn("متوقف", newcomer.get("/register").get_data(as_text=True))
        self.assertEqual(self.sara.get("/dashboard").status_code, 200)                    # teachers already inside are not affected
        r = self.sara.post("/lessons/upload", content_type="multipart/form-data",
                           data={"_csrf": self.token(self.sara), "lesson": (io.BytesIO(b"%PDF-" + b"0" * (1024 * 1024 + 10)), "big.pdf")})
        self.assertEqual(r.status_code, 302)
        self.assertIn("msg=", r.headers["Location"])
        self.assertIn("الحد الأقصى 1 ميجابايت", self.sara.get("/dashboard?msg=" + "الحد الأقصى 1 ميجابايت").get_data(as_text=True))
        self.assertEqual(db.execute("SELECT COUNT(*) FROM lessons").fetchone()[0], 0)
        self.post(self.boss, "/admin/platform/settings", upload_mb="9999", registrations_open="1")      # more than the server allows: refused, nothing changes
        self.assertEqual(billing.upload_limit_mb(db, self.app.cfg.max_upload_mb), 1)
        self.post(self.boss, "/admin/platform/settings", upload_mb="5", registrations_open="1")
        self.register(newcomer, "new@example.com", "زائرة")
        self.assertIsNotNone(db.execute("SELECT 1 FROM users WHERE email = 'new@example.com'").fetchone())
        self.assertEqual(self.post(self.boss, "/admin/platform/settings", upload_mb="abc").status_code, 302)


class ChartTests(unittest.TestCase):
    def test_ticks_are_round_include_zero_and_cover_the_data(self):
        for low, top, integer in ((-214, 178, False), (0, 307, False), (0, 2, True), (-5, 0, False), (0, 0, False), (0, 0, True), (0, 0.4, False), (-0.02, 0.07, False), (0, 1_250_000, False)):
            ticks, step = charts._ticks(low, top, integer=integer)
            self.assertIn(0, ticks, (low, top))
            self.assertLessEqual(ticks[0], low)
            self.assertGreaterEqual(ticks[-1], top)
            self.assertGreater(ticks[-1], ticks[0], "an axis always has some height")
            self.assertEqual(len({round(b - a, 6) for a, b in zip(ticks, ticks[1:])}), 1, "equal steps")
            if integer:
                self.assertTrue(all(float(t).is_integer() for t in ticks))

    def test_a_chart_with_nothing_in_it_still_draws(self):
        svg = str(charts.bars(["ينا", "فبر"], [{"name": "x", "cls": "s1", "values": [0, 0]}]))
        self.assertIn("<svg", svg)
        self.assertNotIn("nan", svg)
        self.assertNotIn("inf", svg)
        self.assertIn("<svg", str(charts.stacked([{"name": "a", "cls": "s1", "value": 0}])))
        self.assertIn("<svg", str(charts.gauge(0, 0)))

    def test_charts_use_no_inline_style_or_script_and_keep_negative_numbers_readable(self):
        svg = str(charts.bars(["ينا", "فبر", "مار"], [{"name": "الصافي", "cls": "s3", "values": [-89.05, 12, 200]}], name="الصافي"))
        self.assertNotIn("style=", svg)
        self.assertNotIn("<script", svg)
        self.assertIn("⁦-89.05⁩", svg)                                         # the latest bar and the hover title keep «-» on the left of the number
        self.assertIn("<title>", svg)
        self.assertIn('aria-label="الصافي"', svg)
        fig = str(charts.figure("عنوان", svg, [("s3", "الصافي")], ["الشهر", "الصافي"], [["ينا", "-89.05"]]))
        self.assertIn("<details", fig)
        self.assertIn("<table", fig)


class EmptySiteTests(World):
    def test_every_page_works_before_there_is_any_data(self):
        """The first day: no subscribers, no requests, no calls, no money, and the manager sets the fixed cost to zero."""
        self.boss = self.admin()
        self.app.db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES ('fixed_sar', '0')")
        self.app.db.commit()
        for p in PAGES + ["/admin/ai?m=all", "/admin/subscriptions?st=soon", "/admin/finance?m=x"]:
            self.assertEqual(self.boss.get(p).status_code, 200, p)
        self.assertEqual(billing.subscriber_counts(self.app.db), {"total": 0, "active": 0, "soon": 0, "free": 0, "expired": 0, "pending": 0})


if __name__ == "__main__":
    unittest.main()
