"""Reading Arabic PDFs: the same lesson written by programs that write Arabic in different ways must come out the same, with marks and numbers in place."""
import html
import io
import re
import unicodedata
import unittest
from unittest import mock

from app import extract, pdfgeo
from tests.test_app import Base

LINES = [
    "المادة: التوحيد الصف: الأول المتوسط المرحلة: المتوسطة",
    "درس التوحيد وأقسامه",
    "شرط قبول الأعمال الصالحة",
    "اتفقت شرائع جميع الرسل على دعوة الناس إلى توحيد الله وعبادته وحده لا شريك له.",
    "التوحيد هو إفراد الله تعالى بالعبادة وهو أول واجب على المكلف وأعظم ما أمر الله به.",
    "وينقسم التوحيد إلى ثلاثة أقسام هي توحيد الربوبية وتوحيد الألوهية وتوحيد الأسماء والصفات.",
    "توحيد الربوبية هو الإيمان بأن الله وحده الخالق الرازق المدبر لجميع الأمور في الكون.",
]
VOCALIZED = [
    "شَرْطُ قَبُولِ الأَعْمَالِ الصَّالِحَةِ",
    "التَّوْحِيدُ هُوَ إِفْرَادُ اللهِ تَعَالَى بِالعِبَادَةِ وَهُوَ أَوَّلُ وَاجِبٍ عَلَى المُكَلَّفِ.",
    "اتَّفَقَتْ شَرَائِعُ جَمِيعِ الرُّسُلِ عَلَى دَعْوَةِ النَّاسِ إِلَى تَوْحِيدِ اللهِ وَعِبَادَتِهِ وَحْدَهُ.",
]
MIXED = [
    "الدرس 5 من Unit 3 في عام 2024 (النسبة 25%).",
    "السؤال 1: ما هو التوحيد؟",
    "ص 25 - 30 من الكتاب المقرر.",
    "قال تعالى: (قل هو الله أحد) وهي سورة الإخلاص.",
    "«التوحيد» أقسام: 1) الربوبية 2) الألوهية 3) الأسماء والصفات.",
    "درجة الحرارة 36.5 درجة مئوية في الصباح.",
    "الساعة 12:30 ظهرا وتنتهي في 1:45 عصرا.",
    "رابط الدرس https://example.com/page ثم افتحي الصفحة.",
    "عدد الطلاب: 25 طالبا في الفصل.",
    "الصف الأول (أ) و(ب) والثاني.",
    "الدرس ٥ من ١٠ في الكتاب.",
    "1. التوحيد",
    "• أقسام التوحيد الثلاثة",
    "[1] المرجع الأول، و[2] المرجع الثاني.",
    "﴿قل هو الله أحد﴾ سورة الإخلاص.",
    "قال: «اتق الله» (متفق عليه) [البخاري].",
    "السؤال رقم 3 (درجتان) والسؤال 4 (3 درجات).",
    "أ) الربوبية ب) الألوهية ج) الأسماء.",
    "المعادلة (x + 2) = 5 هي معادلة من الدرجة الأولى.",
    "التاريخ 1446/05/12 هـ الموافق 2024/11/14 م.",
]
MARKS = re.compile("[ً-ٰٟ]")
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"


def _clusters(word):
    out = []
    for c in word:
        if MARKS.match(c) and out:
            out[-1] += c
        else:
            out.append(c)
    return out


def _canvas(buf):
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.pdfgen import canvas
    try:
        pdfmetrics.getFont("DJ")
    except KeyError:
        pdfmetrics.registerFont(TTFont("DJ", FONT))
    return canvas.Canvas(buf, pagesize=(595, 842), pageCompression=0), pdfmetrics


def screen_order_pdf(lines, per="word", marks="after"):
    """What older programs write: the letters of a word (or of a whole line) in SCREEN order, left to right; the marks of a letter after it ("after") or the
    whole string simply turned round so that they come before it ("before")."""
    buf = io.BytesIO()
    cv, pm = _canvas(buf)
    turn = (lambda s: "".join(reversed(_clusters(s)))) if marks == "after" else (lambda s: s[::-1])
    y = 790
    for ln in lines:
        cv.setFont("DJ", 13)
        if per == "line":
            cv.drawString(30, y, turn(ln))
        else:
            x = 30
            for w in reversed(ln.split()):
                cv.drawString(x, y, turn(w))
                x += pm.stringWidth(w, "DJ", 13) + 6
        y -= 26
    cv.save()
    return buf.getvalue()


def reading_order_pdf(lines):
    """What some programs (the Apple and Office exporters) write: every word's letters in READING order, placed right to left with TJ adjustments, so a
    reader that trusts the writing order turns every word backwards."""
    buf = io.BytesIO()
    cv, pm = _canvas(buf)
    font = pm.getFont("DJ")
    y = 790
    for ln in lines:
        x_right = 560
        for w in ln.split():
            groups = _clusters(w)
            widths = [pm.stringWidth(g[0], "DJ", 13) for g in groups]
            text = cv.beginText()
            text.setFont("DJ", 13)
            text.setTextOrigin(x_right - widths[0], y)
            code, arr, cur = [], [], None
            for k, g in enumerate(groups):
                for subset, chunk in font.splitString(g, cv._doc):
                    if subset != cur:
                        if arr:
                            code.append("[" + " ".join(arr) + "] TJ")
                            arr = []
                        code.append("%s 13 Tf" % font.getSubsetInternalName(subset, cv._doc))
                        cur = subset
                    arr.append("(%s)" % cv._escape(chunk))
                if k + 1 < len(groups):
                    arr.append(str((widths[k] + widths[k + 1]) * 1000 / 13))
            if arr:
                code.append("[" + " ".join(arr) + "] TJ")
            text._code.extend(code)
            cv.drawText(text)
            x_right -= sum(widths) + 6
        y -= 26
    cv.save()
    return buf.getvalue()


def chromium_pdf(lines):
    from playwright.sync_api import sync_playwright
    body = "".join("<p>%s</p>" % html.escape(l) for l in lines)
    page = "<!doctype html><html lang='ar' dir='rtl'><meta charset='utf-8'><style>body{font-family:'DejaVu Sans';font-size:15px;line-height:1.9;margin:40px}</style><body>%s</body></html>" % body
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page()
        pg.set_content(page)
        data = pg.pdf(format="A4")
        b.close()
    return data


def lines_of(data):
    return [l for l in extract.from_pdf(data).splitlines() if l.strip()]


class QualityTests(unittest.TestCase):
    TEXT = ("اتفقت شرائع جميع الرسل على دعوة الناس إلى توحيد الله وعبادته وحده لا شريك له.\n"
            "التوحيد هو إفراد الله تعالى بالعبادة وهو أول واجب على المكلف وأعظم ما أمر الله به.\n"
            "وينقسم التوحيد إلى ثلاثة أقسام هي توحيد الربوبية وتوحيد الألوهية وتوحيد الأسماء والصفات.")

    def test_the_score_tells_normal_arabic_from_backwards_arabic(self):
        self.assertGreater(extract._quality(self.TEXT), 0.5)
        backwards = "\n".join(" ".join(w[::-1] for w in l.split()) for l in self.TEXT.splitlines())
        self.assertLess(extract._quality(backwards), -0.5)
        self.assertIsNone(extract._quality("قصير جدا"))                     # too short to tell

    def test_marks_that_come_before_their_letter_are_moved_behind_it(self):
        self.assertEqual(extract._fix_marks("َشْرُط َقُبوِل"), "شَرْطُ قَبُولِ")
        right = "شَرْطُ قَبُولِ الأَعْمَالِ"
        self.assertEqual(extract._fix_marks(right), right)                  # marks already behind their letters stay


class BidiTests(unittest.TestCase):
    @staticmethod
    def back(shown):
        return "".join(pdfgeo.logical([(pdfgeo._cls(c), c) for c in shown], True))

    def test_a_line_shown_left_to_right_is_read_right_to_left(self):
        # on the page the letters of an Arabic word stand left to right in the order they are SEEN: the last letter first
        self.assertEqual(self.back("سلام"[::-1]), "سلام")
        # the first word of the sentence stands at the RIGHT of the page, so it comes last in the left-to-right string
        self.assertEqual(self.back("المعلم"[::-1] + " " + "الكتاب"[::-1]), "الكتاب المعلم")

    def test_numbers_and_latin_words_keep_their_own_order(self):
        # page, left to right: «الكتاب» «من» «25» «الدرس»  (each Arabic word with its letters turned round)
        shown = "الكتاب"[::-1] + " " + "من"[::-1] + " 25 " + "الدرس"[::-1]
        self.assertEqual(self.back(shown), "الدرس 25 من الكتاب")
        # a Latin word followed by its number reads as written: «Unit 3»
        self.assertEqual(self.back("Unit 3 " + "الدرس"[::-1]), "الدرس Unit 3")

    def test_brackets_stored_mirrored_are_put_right(self):
        self.assertEqual(pdfgeo.fix_brackets(")النسبة 25("), "(النسبة 25)")
        self.assertEqual(pdfgeo.fix_brackets("1( الربوبية 2( الألوهية"), "1) الربوبية 2) الألوهية")
        self.assertEqual(pdfgeo.fix_brackets("(كما هي) و[هذه]"), "(كما هي) و[هذه]")


class MarkTests(unittest.TestCase):
    """Fatha, damma, shadda... must stay on the letter they were written on, whichever way the program that made the PDF wrote them."""
    U = staticmethod(lambda t, x0, x1, i, y=700.0: pdfgeo.Unit(t, x0, x1, y, 10.0, i))

    def test_a_span_text_is_read_from_utf16_and_plain_bytes(self):
        self.assertEqual(pdfgeo._actual(b"\xfe\xff\x06\x35\x06\x4e\x06\x51"), "صَّ")
        self.assertEqual(pdfgeo._actual(b"ab"), "ab")
        self.assertEqual(pdfgeo._actual(None), "")

    def test_a_glyph_without_a_letter_gets_what_its_span_says_less_what_the_other_glyphs_give(self):
        class G:                                                              # what pdfminer gives for a drawn glyph
            def __init__(self, t):
                self._text = t

            def get_text(self):
                return self._text
        stacked, base = G("\x00"), G("ﺼ")                                    # two marks in one glyph, and the letter they stand on
        pdfgeo._fill([stacked, base], "صَّ")
        self.assertEqual(unicodedata.normalize("NFC", stacked.get_text()), "َّ")
        self.assertEqual(base.get_text(), "ﺼ")                                # glyphs that already have a letter are never touched
        far = [G("\x00")] + [G("ب") for _ in range(8)]
        pdfgeo._fill(far, "ب" * 8 + "xyz12")                                  # a span about much more than these glyphs: nothing is changed
        self.assertEqual(far[0].get_text(), "\x00")

    def test_a_mark_over_a_letter_goes_to_that_letter_when_the_file_gives_no_habit(self):
        # file order (screen order, marks BEFORE their letter): the shadda stands over the mim, which comes AFTER it in the file
        nun, shadda, mim = self.U("ن", 206.3, 210.3, 0), self.U("ّ", 211.0, 211.0, 1), self.U("م", 210.3, 217.0, 2)
        out = pdfgeo._attach_marks([nun, shadda, mim])
        self.assertEqual([u.t for u in out], ["ن", "مّ"])
        # the same letters when the file writes marks AFTER their letter: the mark stands over the first one
        mim, shadda, nun = self.U("م", 210.3, 217.0, 0), self.U("ّ", 215.0, 215.0, 1), self.U("ن", 206.3, 210.3, 2)
        out = pdfgeo._attach_marks([mim, shadda, nun])
        self.assertEqual([u.t for u in out], ["مّ", "ن"])

    def test_a_mark_exactly_between_two_letters_follows_the_files_habit(self):
        a, mark, b = self.U("ب", 100.0, 108.0, 0), self.U("َ", 108.0, 108.0, 1), self.U("ت", 108.0, 115.0, 2)
        self.assertEqual([u.t for u in pdfgeo._attach_marks([a, mark, b])], ["بَ", "ت"])           # no habit shown: marks follow their letter

    def test_a_clear_habit_of_the_file_is_kept_even_when_a_mark_sits_a_little_outside_its_letter(self):
        # marks written BEFORE their letter in four words (each word ends the file's run with a marked letter): the habit is clear
        units = []
        x = 500.0
        for k in range(4):
            units += [self.U("ُ", x, x, len(units)), self.U("د", x - 0.5, x + 5, len(units) + 1)]
            x -= 20.0
            units += [self.U(" ", x + 10, x + 14, len(units))]
        self.assertEqual(pdfgeo._marks_follow(units), (False, True))
        # a damma written before its letter, but whose place is a hair inside the letter to its left (a wide mark over a narrow letter)
        first, mark, second = self.U("ل", 200.0, 203.0, 0), self.U("ُ", 203.2, 203.2, 1), self.U("ا", 203.0, 206.0, 2)
        out = pdfgeo._attach_marks(units + [first, mark, second])
        self.assertEqual(out[-1].t, "اُ")                                       # the file's habit says «before its letter»: the letter after it

    def test_a_vocalized_browser_pdf_keeps_every_mark_on_its_letter_even_stacked_ones(self):
        lines = VOCALIZED + ["مُحَمَّدٌ رَسُولُ اللَّهِ", "الضريبة المضمّنة", "غير مسجّلة في الضريبة"]
        got = lines_of(chromium_pdf(lines))
        self.assertEqual([unicodedata.normalize("NFC", g) for g in got[:len(lines)]], [unicodedata.normalize("NFC", w) for w in lines])

    def test_a_browser_pdf_with_only_a_mark_or_two_puts_them_on_the_right_letter(self):
        lines = LINES[3:6] + ["الضريبة المضمّنة", "غير مسجّلة في الضريبة"]
        got = lines_of(chromium_pdf(lines))
        self.assertEqual([unicodedata.normalize("NFC", g) for g in got[:len(lines)]], [unicodedata.normalize("NFC", w) for w in lines])


class PdfReadingTests(unittest.TestCase):
    def check(self, got, want, label):
        self.assertEqual([l for l in got if l.strip()][:len(want)], want, label)

    def test_letters_in_screen_order_are_read_right_for_words_and_for_lines(self):
        for per in ("word", "line"):
            for marks in ("after", "before"):
                data = screen_order_pdf(LINES + VOCALIZED, per=per, marks=marks)
                self.check(lines_of(data), LINES + VOCALIZED, f"{per}/{marks}")

    def test_letters_written_in_reading_order_are_not_turned_backwards(self):
        data = reading_order_pdf(LINES + VOCALIZED)
        self.check(lines_of(data), LINES + VOCALIZED, "reading order")
        self.assertNotIn("طرش", extract.from_pdf(data))                    # «شرط» turned round: the fault this guards against

    def test_a_browser_pdf_with_numbers_brackets_and_latin_words_reads_exactly(self):
        data = chromium_pdf(MIXED)
        self.check(lines_of(data), MIXED, "chromium")

    def test_the_older_reader_alone_still_reads_ordinary_files(self):
        with mock.patch.object(pdfgeo, "pages", return_value=None):
            for data in (screen_order_pdf(LINES), chromium_pdf(LINES)):
                text = MARKS.sub("", extract.from_pdf(data)).replace("\x00", "")
                self.assertIn("شرط قبول الأعمال الصالحة", text)
                self.assertIn("اتفقت شرائع جميع الرسل على دعوة الناس إلى توحيد الله", text)

    def test_when_the_position_reader_misses_text_the_older_reader_is_used(self):
        data = chromium_pdf(LINES)
        for fake in (["", ""], ["شرط"], [""] * 3):
            with mock.patch.object(pdfgeo, "pages", return_value=fake):
                text = extract.from_pdf(data)
            self.assertIn("اتفقت شرائع جميع الرسل على دعوة الناس إلى توحيد الله", MARKS.sub("", text).replace("\x00", ""), fake)

    def test_when_the_reader_doubts_the_letters_the_teacher_is_told(self):
        with mock.patch.object(extract, "_quality", return_value=-0.5):
            text, details = extract.read("pdf", chromium_pdf(LINES))
        self.assertTrue(details.get("warn"))
        self.assertIn("شرط", text)

    def test_a_good_reading_has_no_warning(self):
        text, details = extract.read("pdf", reading_order_pdf(LINES))
        self.assertNotIn("warn", details)
        self.assertIn("شرط قبول الأعمال الصالحة", text)


class WarningNoteTests(Base):
    def test_the_warning_is_kept_with_the_lesson_and_questions_still_made(self):
        c = self.client()
        self.register(c)
        with mock.patch.object(extract, "_quality", return_value=-0.5):
            r = self.upload(c, "tawhid.pdf", reading_order_pdf(LINES * 2))
        lid = int(re.search(r"/lessons/(\d+)", r.headers["Location"]).group(1))
        st = c.get(f"/api/lessons/{lid}").get_json()
        self.assertEqual(st["status"], "ready")
        self.assertIn("اتجاه الحروف", st["error"])


if __name__ == "__main__":
    unittest.main()
