"""The cost report's arithmetic: it must be the site's own arithmetic, ordered sensibly, and it must need nothing from outside."""
import contextlib
import io
import json
import socket
import unittest
from unittest import mock

from app import aimodel, billing, costmodel


class CostModelTests(unittest.TestCase):
    def test_the_report_is_about_the_pinned_model_and_uses_the_sites_own_prices(self):
        r = costmodel.report()
        self.assertEqual(r["official"]["model"], aimodel.MODEL)
        self.assertEqual(aimodel.MODEL, "claude-haiku-5-5")
        self.assertEqual(r["official"]["usd_per_mtok"], [0.10, 0.50] if isinstance(r["official"]["usd_per_mtok"], list) else (0.10, 0.50))
        c = costmodel.call(9000)
        self.assertEqual(c["halalas"], billing.cost_halalas(aimodel.MODEL, c["tokens_in"], c["tokens_out"]))
        self.assertAlmostEqual(c["usd"], (c["tokens_in"] * 0.10 + c["tokens_out"] * 0.50) / 1e6, places=9)

    def test_the_worst_call_is_the_one_the_cap_holds_back(self):
        w = costmodel.worst_cases()["absolute_bound"]
        self.assertEqual(w["per_call_sar"], billing.worst_call_halalas() / 100)
        self.assertEqual(billing.worst_call_halalas(), 31)
        self.assertAlmostEqual(w["per_teacher_month"], 40 * 0.31)

    def test_one_typical_lesson_costs_a_halala_or_two(self):
        t = costmodel.call(costmodel.LESSON_CHARS["typical"])
        self.assertTrue(1 <= t["halalas"] <= 2, t)
        self.assertLess(t["sar"], 0.02)

    def test_the_estimates_are_ordered_low_central_high_and_the_bound_is_above_them_all(self):
        for size, chars in costmodel.LESSON_CHARS.items():
            low, mid, high = costmodel.call(chars, "low", "low")["sar"], costmodel.call(chars)["sar"], costmodel.call(chars, "high", "high")["sar"]
            self.assertLess(low, mid, size)
            self.assertLess(mid, high, size)
            self.assertLess(high, billing.worst_call_halalas() / 100, size)
        w = costmodel.worst_cases()
        self.assertLess(w["heavy_use"]["per_teacher_month"], w["every_file_at_the_cap"]["per_teacher_month"])
        self.assertLess(w["every_file_at_the_cap"]["per_teacher_month"], w["absolute_bound"]["per_teacher_month"])

    def test_costs_grow_with_lessons_with_teachers_and_with_the_size_of_the_file(self):
        self.assertLess(costmodel.teacher_month(10), costmodel.teacher_month(20))
        self.assertLess(costmodel.teacher_month(20), costmodel.teacher_month(40))
        self.assertAlmostEqual(costmodel.teacher_month(40), 4 * costmodel.teacher_month(10))
        self.assertAlmostEqual(costmodel.fleet(500, 20), 5 * costmodel.fleet(100, 20))
        self.assertLess(costmodel.call(3000)["sar"], costmodel.call(9000)["sar"])
        self.assertLess(costmodel.call(9000)["sar"], costmodel.call(60000)["sar"])

    def test_the_answer_is_never_longer_than_the_limit_the_request_sets(self):
        self.assertLessEqual(costmodel.call(60000, "high", "high")["tokens_out"], aimodel.MAX_OUT_TOKENS)
        self.assertLessEqual(costmodel.call(10 ** 7)["tokens_in"], round((aimodel.MAX_TEXT_CHARS + costmodel.MEASURED["instructions_chars"]) * 0.55))   # the text is cut at the limit

    def test_the_price_a_teacher_pays_is_split_into_vat_and_net_the_way_the_site_does(self):
        m = costmodel.revenue("monthly")
        self.assertAlmostEqual(m["net"], 29 / 1.15, places=6)
        self.assertAlmostEqual(m["vat"], 29 - 29 / 1.15, places=6)
        y = costmodel.revenue("yearly")
        self.assertAlmostEqual(y["gross"], 249 / 12)
        self.assertAlmostEqual(y["net"], 249 / 12 / 1.15, places=6)
        self.assertEqual(costmodel.revenue("monthly", vat_registered=False)["net"], 29)

    def test_the_margin_is_what_is_left_of_the_net_revenue_after_ai_and_fixed_costs(self):
        m = costmodel.margin("monthly", 100, 20)
        self.assertAlmostEqual(m["profit"], m["net_revenue"] - m["ai"] - m["fixed"])
        self.assertAlmostEqual(m["margin_pct"], 100 * m["profit"] / m["net_revenue"])
        self.assertAlmostEqual(m["fixed"], costmodel.FIXED_SAR + costmodel.FIXED_PER_TEACHER * 100)
        u = costmodel.unit("yearly", 40)
        self.assertAlmostEqual(u["left"], u["net_revenue"] - u["ai"])
        self.assertGreater(u["margin_pct"], 90)                       # the AI is a small part of what a teacher pays
        self.assertGreater(costmodel.margin("monthly", 100, 40)["margin_pct"], costmodel.margin("monthly", 100, 40, ratio="high")["margin_pct"])

    def test_break_even_and_the_cap_advice(self):
        self.assertTrue(1 < costmodel.break_even("monthly", 40) < 3)
        self.assertGreater(costmodel.break_even("yearly", 40), costmodel.break_even("monthly", 40))
        self.assertEqual(costmodel.cap_advice(100)["cap_sar"], 50)                               # never under the floor
        self.assertEqual(costmodel.cap_advice(10_000)["cap_sar"], 1000)                           # a tenth of the month's net revenue
        self.assertEqual(costmodel.teachers_under_cap(50, 40), int(50 // costmodel.teacher_month(40)))
        self.assertGreater(costmodel.teachers_under_cap(50, 10), costmodel.teachers_under_cap(50, 40))

    def test_it_needs_no_network_and_no_key(self):
        def refuse(*a, **k):
            raise AssertionError("the cost model must not open a connection")
        with mock.patch.object(socket, "socket", refuse), mock.patch.object(socket, "create_connection", refuse):
            r = costmodel.report()
        self.assertTrue(r["fleet"][100][10]["central"] > 0)
        src = open(costmodel.__file__, encoding="utf-8").read()
        for word in ("urllib", "requests", "anthropic_key", "ANTHROPIC"):
            self.assertNotIn(word, src)

    def test_it_prints_for_a_person_and_as_json(self):
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            costmodel.main([])
        self.assertIn("claude-haiku-5-5", out.getvalue())
        self.assertIn("هللة", out.getvalue())
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            costmodel.main(["--json"])
        self.assertIn("one_lesson", json.loads(out.getvalue()))


if __name__ == "__main__":
    unittest.main()
