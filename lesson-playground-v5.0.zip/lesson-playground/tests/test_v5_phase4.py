"""Version 5, phase 4 through the server: participation points kept per student, class, subject and day; the board of the first three; the log she can correct; the reports of a class
and of a student; and the walls between classes and between teachers."""
import csv
import datetime
import io
import re
import sqlite3
import tempfile
import unittest
from unittest import mock
from urllib.parse import parse_qs, urlparse

from app import create_app
from app import db as dbm
from app import scoring
from tests import fixtures as FX
from tests import test_v5_phase2 as P2

D = datetime.date


class Phase4(P2.Phase2):
    def klass(self, name="الصف الأول أ", names=("سارة", "نورة", "ليان", "مها"), c=None):
        """A class with students: (class id, {name: student id})."""
        cid = self.make_class(name, c)
        r = self.api("post", "/api/students", {"class_id": cid, "names": list(names)}, c)
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        rows = (c or self.c).get(f"/api/students?class_id={cid}").get_json()["students"]
        return cid, {s["name"]: s["id"] for s in rows}

    def give(self, student, amount=1, c=None, status=201, **extra):
        r = self.api("post", "/api/points", {"student_id": student, "amount": amount, **extra}, c)
        self.assertEqual(r.status_code, status, r.get_data(as_text=True))
        return r.get_json()

    def board(self, cid, c=None, **q):
        qs = "&".join(f"{k}={v}" for k, v in {"class_id": cid, **q}.items())
        r = (c or self.c).get(f"/api/points/board?{qs}")
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def log(self, c=None, **q):
        r = (c or self.c).get("/api/points/log?" + "&".join(f"{k}={v}" for k, v in q.items()))
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def pts(self):
        return self.count("SELECT COUNT(*) FROM points")

    def second_teacher(self):
        c = self.client()
        self.register(c, email="b@example.com", name="أخرى")
        return c

    def standing(self, b):
        return [(r["name"], r["points"], r["rank"]) for r in b["rows"]]


# ================================================================ giving a point
class Awarding(Phase4):
    def test_a_point_belongs_to_the_class_of_its_student_and_to_the_day(self):
        cid, st = self.klass()
        r = self.give(st["سارة"], 2, source="game", game="pick", ref="درس الخلية")
        self.assertFalse(r["duplicate"])
        self.assertEqual(r["today"], 2)
        row = self.app.db.execute("SELECT * FROM points").fetchone()
        self.assertEqual((row["class_id"], row["student_id"], row["day"], row["amount"], row["source"], row["game"], row["ref"], row["subject_id"]),
                         (cid, st["سارة"], "2026-09-06", 2, "game", "pick", "درس الخلية", None))
        self.assertEqual(self.give(st["سارة"], 3)["today"], 5)
        self.assertEqual(self.give(st["نورة"], 1)["today"], 1)

    def test_a_point_may_name_its_subject(self):
        cid, st = self.klass()
        sid = self.make_subject()
        self.give(st["سارة"], 1, subject_id=sid)
        self.assertEqual(self.app.db.execute("SELECT subject_id FROM points").fetchone()[0], sid)

    def test_the_amount_is_a_whole_number_of_points_and_never_zero(self):
        cid, st = self.klass()
        for bad in (0, 51, -51, 1.5, "2", True, None, [1], {"a": 1}, float("inf")):
            r = self.api("post", "/api/points", {"student_id": st["سارة"], "amount": bad})
            self.assertEqual(r.status_code, 400, bad)
            self.assertIn("عدد النقاط", r.get_json()["error"])
        for good in (1, 50, -1, -50, 2.0):
            self.give(st["سارة"], good)
        self.assertEqual(self.pts(), 5)
        self.assertEqual(self.app.db.execute("SELECT SUM(amount) FROM points").fetchone()[0], 1 + 50 - 1 - 50 + 2)

    def test_the_student_must_be_hers(self):
        cid, st = self.klass()
        other = self.second_teacher()
        ocid, ost = self.klass("فصل أخرى", ("هند",), other)
        for sid in (ost["هند"], 99999, 0, None):
            r = self.api("post", "/api/points", {"student_id": sid, "amount": 1})
            self.assertEqual(r.status_code, 404, sid)
        self.assertEqual(self.api("post", "/api/points", {"student_id": st["سارة"], "amount": 1}, other).status_code, 404)
        self.assertEqual(self.pts(), 0)

    def test_the_subject_must_be_hers(self):
        cid, st = self.klass()
        other = self.second_teacher()
        osub = self.make_subject("العلوم", other)
        r = self.api("post", "/api/points", {"student_id": st["سارة"], "amount": 1, "subject_id": osub})
        self.assertEqual(r.status_code, 404)
        self.assertEqual(self.pts(), 0)

    def test_sending_the_same_point_twice_writes_it_once(self):
        cid, st = self.klass()
        first = self.give(st["سارة"], 2, key="a:run1:q7:" + str(st["سارة"]))
        again = self.give(st["سارة"], 2, key="a:run1:q7:" + str(st["سارة"]), status=200)
        self.assertEqual((first["duplicate"], again["duplicate"], again["id"] == first["id"], again["today"]), (False, True, True, 2))
        self.assertEqual(self.pts(), 1)
        self.give(st["سارة"], 2, key="a:run1:q8:" + str(st["سارة"]))
        self.assertEqual(self.pts(), 2)
        self.give(st["سارة"], 1)          # points without a key are never merged
        self.give(st["سارة"], 1)
        self.assertEqual(self.pts(), 4)

    def test_a_key_is_one_teachers_own(self):
        cid, st = self.klass()
        other = self.second_teacher()
        ocid, ost = self.klass("فصل أخرى", ("هند",), other)
        self.give(st["سارة"], 1, key="same-key")
        self.give(ost["هند"], 1, c=other, key="same-key")          # not a duplicate of hers
        self.assertEqual(self.pts(), 2)
        self.assertEqual(self.give(ost["هند"], 1, c=other, key="same-key", status=200)["duplicate"], True)

    def test_a_key_is_made_of_plain_characters(self):
        cid, st = self.klass()
        for bad in ("a b", "بدر", "x" * 65, "a;b", "a'b"):
            self.assertEqual(self.api("post", "/api/points", {"student_id": st["سارة"], "amount": 1, "key": bad}).status_code, 400, bad)
        self.assertEqual(self.pts(), 0)

    def test_a_point_kept_while_offline_keeps_its_day(self):
        cid, st = self.klass()
        real = 1_900_000_000.0
        with mock.patch("app.points.now", return_value=real):
            self.give(st["سارة"], 1, at=real - 3600 * 30)                    # a day and a half ago
            self.give(st["نورة"], 1, at=real - 8 * 86400)                    # too old: counted now
            self.give(st["ليان"], 1, at=real + 3600)                         # in the future: counted now
            self.give(st["مها"], 1, at="yesterday")
        days = {r["student_id"]: r["day"] for r in self.app.db.execute("SELECT student_id, day FROM points")}
        old = datetime.datetime.fromtimestamp(real - 3600 * 30, datetime.timezone(datetime.timedelta(hours=3))).date().isoformat()
        self.assertEqual(days[st["سارة"]], old)
        for name in ("نورة", "ليان", "مها"):
            self.assertEqual(days[st[name]], "2026-09-06", name)

    def test_a_point_written_by_hand_may_name_a_day(self):
        cid, st = self.klass()
        self.give(st["سارة"], 1, day="2026-09-01")
        self.give(st["سارة"], 1, day="2026-09-06")
        for bad in ("2026-09-07", "2025-01-01", "كذا", "2026-13-01"):
            r = self.api("post", "/api/points", {"student_id": st["سارة"], "amount": 1, "day": bad})
            self.assertEqual(r.status_code, 400, bad)
        r = self.give(st["نورة"], 1, source="game", day="2026-09-01")                # a point from a game is always of now
        self.assertEqual(self.app.db.execute("SELECT day FROM points WHERE id = ?", (r["id"],)).fetchone()[0], "2026-09-06")
        self.assertEqual(self.pts(), 3)

    def test_the_game_name_is_kept_plain(self):
        cid, st = self.klass()
        self.give(st["سارة"], 1, source="game", game="<b>PICK</b>;drop table", ref="x" * 200, note="n" * 200)
        row = self.app.db.execute("SELECT game, ref, note FROM points").fetchone()
        self.assertEqual(row["game"], "bpickbdroptable"[:20])
        self.assertLessEqual(len(row["ref"]), 80)
        self.assertLessEqual(len(row["note"]), 80)

    def test_too_many_points_in_an_hour_are_refused(self):
        from app import points
        cid, st = self.klass()
        points.award_limit.hits.clear()
        old, points.award_limit.tries = points.award_limit.tries, 3
        try:
            for _ in range(3):
                self.give(st["سارة"], 1)
            r = self.api("post", "/api/points", {"student_id": st["سارة"], "amount": 1})
            self.assertEqual(r.status_code, 429)
        finally:
            points.award_limit.tries = old
            points.award_limit.hits.clear()

    def test_everything_needs_a_signed_in_teacher(self):
        anon = self.client()
        for method, url in (("post", "/api/points"), ("get", "/api/points/log"), ("get", "/api/points/board?class_id=1"), ("get", "/api/points/settings"), ("get", "/api/reports/class/1"),
                            ("get", "/api/reports/student/1"), ("get", "/api/reports/class/1/csv"), ("delete", "/api/points/1"), ("patch", "/api/points/1")):
            r = self.j(anon, method, url, {} if method != "get" else None)
            self.assertEqual(r.status_code, 401, (method, url))
        for url in ("/points", "/reports"):
            r = anon.get(url)
            self.assertEqual((r.status_code, "/login" in r.headers["Location"]), (302, True), url)


# ================================================================ correcting the log
class Correcting(Phase4):
    def test_taking_a_point_back_removes_it_from_the_board(self):
        cid, st = self.klass()
        a = self.give(st["سارة"], 2)
        self.give(st["سارة"], 3)
        self.assertEqual(self.standing(self.board(cid))[0], ("سارة", 5, 1))
        self.assertEqual(self.api("delete", f"/api/points/{a['id']}").status_code, 200)
        self.assertEqual(self.standing(self.board(cid))[0], ("سارة", 3, 1))
        self.assertEqual(self.api("delete", f"/api/points/{a['id']}").status_code, 404)          # already gone

    def test_another_teacher_cannot_touch_a_point(self):
        cid, st = self.klass()
        a = self.give(st["سارة"], 2)
        other = self.second_teacher()
        self.assertEqual(self.api("delete", f"/api/points/{a['id']}", None, other).status_code, 404)
        self.assertEqual(self.api("patch", f"/api/points/{a['id']}", {"amount": 9}, other).status_code, 404)
        self.assertEqual(self.pts(), 1)
        self.assertEqual(self.app.db.execute("SELECT amount FROM points").fetchone()[0], 2)

    def test_a_line_can_be_corrected_in_every_part(self):
        cid, st = self.klass()
        sub = self.make_subject()
        a = self.give(st["سارة"], 2, source="game", game="live")
        r = self.api("patch", f"/api/points/{a['id']}", {"amount": 5, "note": "إجابة ممتازة", "day": "2026-09-02", "subject_id": sub, "student_id": st["نورة"]})
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        e = r.get_json()["entry"]
        self.assertEqual((e["amount"], e["note"], e["day"], e["subject_id"], e["subject"], e["student"], e["edited"]), (5, "إجابة ممتازة", "2026-09-02", sub, "الرياضيات", "نورة", True))
        self.assertEqual(e["source"], "game")          # where it came from is not rewritten
        r = self.api("patch", f"/api/points/{a['id']}", {"subject_id": None})
        self.assertIsNone(r.get_json()["entry"]["subject_id"])
        r = self.api("patch", f"/api/points/{a['id']}", {"amount": -2})
        self.assertEqual(r.get_json()["entry"]["amount"], -2)
        self.assertEqual(self.standing(self.board(cid))[-1][1], -2)

    def test_a_correction_that_does_not_make_sense_is_refused_and_changes_nothing(self):
        cid, st = self.klass()
        ocid, ost = self.klass("الصف الأول ب", ("هند",))
        a = self.give(st["سارة"], 2)
        for body in ({"amount": 0}, {"amount": 60}, {"amount": "x"}, {"day": "2027-01-01"}, {"day": "كذا"}, {"student_id": ost["هند"]}, {}):
            r = self.api("patch", f"/api/points/{a['id']}", body)
            self.assertEqual(r.status_code, 400, body)
        r = self.api("patch", f"/api/points/{a['id']}", {"student_id": 99999})
        self.assertEqual(r.status_code, 404)
        row = self.app.db.execute("SELECT * FROM points").fetchone()
        self.assertEqual((row["amount"], row["student_id"], row["edited_at"]), (2, st["سارة"], 0))

    def test_a_line_cannot_be_moved_to_another_teachers_student_or_subject(self):
        cid, st = self.klass()
        a = self.give(st["سارة"], 2)
        other = self.second_teacher()
        ocid, ost = self.klass("فصل أخرى", ("هند",), other)
        osub = self.make_subject("العلوم", other)
        self.assertEqual(self.api("patch", f"/api/points/{a['id']}", {"student_id": ost["هند"]}).status_code, 404)
        self.assertEqual(self.api("patch", f"/api/points/{a['id']}", {"subject_id": osub}).status_code, 404)
        self.assertEqual(self.app.db.execute("SELECT student_id, subject_id FROM points").fetchone()[:], (st["سارة"], None))


# ================================================================ the board
class Board(Phase4):
    def test_the_board_ranks_the_class_and_names_the_first_three_places(self):
        cid, st = self.klass(names=("أمل", "بدر", "جود", "دانة", "هيا"))
        for name, n in (("أمل", 5), ("بدر", 3), ("جود", 3), ("دانة", 1)):
            self.give(st[name], n)
        b = self.board(cid, period="all")
        self.assertEqual(self.standing(b), [("أمل", 5, 1), ("بدر", 3, 2), ("جود", 3, 2), ("دانة", 1, 3), ("هيا", 0, None)])
        self.assertEqual([r["name"] for r in b["top"]], ["أمل", "بدر", "جود", "دانة"])          # a tie shares its place, so four stand on three places
        self.assertEqual((b["total"], b["awards"], b["more"], b["class"]["id"]), (12, 4, 0, cid))

    def test_a_student_with_nothing_is_not_on_the_podium(self):
        cid, st = self.klass()
        self.give(st["سارة"], 2)
        b = self.board(cid, period="all")
        self.assertEqual([r["name"] for r in b["top"]], ["سارة"])
        self.assertEqual(len(b["rows"]), 4)
        self.assertEqual([r["rank"] for r in b["rows"]], [1, None, None, None])

    def test_points_taken_off_can_leave_a_student_below_zero_and_off_the_podium(self):
        cid, st = self.klass()
        self.give(st["سارة"], 2)
        self.give(st["نورة"], -3)
        b = self.board(cid, period="all")
        self.assertEqual(self.standing(b)[:2], [("سارة", 2, 1), ("ليان", 0, None)])
        self.assertIn(("نورة", -3, None), self.standing(b))

    def test_a_class_where_everyone_has_the_same_points_is_cut_for_the_screen(self):
        cid, st = self.klass(names=[f"طالب{i:02d}" for i in range(14)])
        for sid in st.values():
            self.give(sid, 1)
        b = self.board(cid, period="all")
        self.assertEqual((len(b["top"]), b["more"]), (9, 5))
        self.assertTrue(all(r["rank"] == 1 for r in b["rows"]))

    def test_the_period_decides_which_days_count(self):
        cid, st = self.klass()
        s = st["سارة"]
        for day, n in (("2026-09-06", 1), ("2026-09-03", 2), ("2026-08-30", 4), ("2026-08-10", 8)):
            self.give(s, n, day=day)
        total = lambda period: self.board(cid, period=period)["rows"][0]["points"]
        self.assertEqual(total("today"), 1)
        self.assertEqual(total("week"), 1)          # her week began on Sunday 6 September: the Thursday before is last week
        self.assertEqual(total("all"), 15)
        self.assertEqual(total("term"), 15)         # no term yet: nothing to cut
        self.set_term("2026-08-30", "2026-12-17")
        self.assertEqual(total("term"), 7)          # 10 August is before the term
        self.today = D(2026, 9, 9)
        self.assertEqual(total("week"), 1)
        self.assertEqual(total("today"), 0)

    def test_the_subject_narrows_the_board(self):
        cid, st = self.klass()
        math, sci = self.make_subject("الرياضيات"), self.make_subject("العلوم")
        self.give(st["سارة"], 2, subject_id=math)
        self.give(st["سارة"], 3, subject_id=sci)
        self.give(st["نورة"], 4)
        self.assertEqual(self.standing(self.board(cid, period="all", subject_id=math))[0], ("سارة", 2, 1))
        self.assertEqual(self.standing(self.board(cid, period="all", subject_id=sci))[0], ("سارة", 3, 1))
        self.assertEqual(self.standing(self.board(cid, period="all"))[:2], [("سارة", 5, 1), ("نورة", 4, 2)])

    def test_a_board_asks_for_a_class_and_a_known_period(self):
        cid, st = self.klass()
        self.assertEqual(self.c.get("/api/points/board").status_code, 400)
        self.assertEqual(self.c.get(f"/api/points/board?class_id={cid}&period=year").status_code, 400)
        self.assertEqual(self.c.get("/api/points/board?class_id=99999").status_code, 404)

    def test_two_classes_never_share_a_point(self):
        a, sa = self.klass("الصف الأول أ", ("سارة", "نورة"))
        b, sb = self.klass("الصف الأول ب", ("سارة", "هند"))          # the same name in two classes
        self.give(sa["سارة"], 3)
        self.give(sb["سارة"], 1)
        self.give(sb["هند"], 2)
        ba, bb = self.board(a, period="all"), self.board(b, period="all")
        self.assertEqual(self.standing(ba), [("سارة", 3, 1), ("نورة", 0, None)])
        self.assertEqual(self.standing(bb), [("هند", 2, 1), ("سارة", 1, 2)])
        self.assertEqual({r["student_id"] for r in ba["rows"]}, set(sa.values()))
        self.assertEqual(self.log(class_id=a)["total"], 1)
        self.assertEqual(self.log(class_id=b)["total"], 2)

    def test_another_teachers_class_cannot_be_read_by_any_screen(self):
        cid, st = self.klass()
        self.give(st["سارة"], 2)
        other = self.second_teacher()
        for url in (f"/api/points/board?class_id={cid}", f"/api/points/log?class_id={cid}", f"/api/points/log?student_id={st['سارة']}", f"/api/reports/class/{cid}",
                    f"/api/reports/class/{cid}/csv", f"/api/reports/student/{st['سارة']}"):
            self.assertEqual(other.get(url).status_code, 404, url)
        self.assertEqual(other.get("/api/points/log").get_json(), {"entries": [], "total": 0, "sum": 0})

    def test_deleting_a_student_or_a_class_takes_its_points_and_deleting_a_subject_does_not(self):
        cid, st = self.klass()
        sub = self.make_subject()
        self.give(st["سارة"], 1, subject_id=sub)
        self.give(st["نورة"], 1, subject_id=sub)
        self.api("delete", f"/api/students/{st['سارة']}")
        self.assertEqual(self.pts(), 1)
        self.api("delete", f"/api/subjects/{sub}")
        self.assertEqual((self.pts(), self.app.db.execute("SELECT subject_id FROM points").fetchone()[0]), (1, None))
        self.api("delete", f"/api/classes/{cid}")
        self.assertEqual(self.pts(), 0)

    def test_deleting_the_account_takes_the_points(self):
        cid, st = self.klass()
        self.give(st["سارة"], 1)
        self.assertEqual(self.api("post", "/api/me/delete", {"password": "Teacher-pass-1"}).status_code, 200)
        self.assertEqual(self.pts(), 0)


# ================================================================ the log
class Log(Phase4):
    def setUp(self):
        super().setUp()
        self.cid, self.st = self.klass()
        self.math, self.sci = self.make_subject("الرياضيات"), self.make_subject("العلوم")
        s, n = self.st["سارة"], self.st["نورة"]
        self.a = self.give(s, 1, subject_id=self.math, source="game", game="pick", day=None)["id"]
        self.b = self.give(s, 2, subject_id=self.sci, day="2026-09-03", note="مشاركة")["id"]
        self.c_ = self.give(n, 3, subject_id=self.math, day="2026-09-03")["id"]
        self.d = self.give(n, 4, day="2026-08-20")["id"]

    def ids(self, **q):
        return [e["id"] for e in self.log(**q)["entries"]]

    def test_the_newest_day_comes_first_and_every_line_says_what_it_is(self):
        d = self.log()
        self.assertEqual((d["total"], d["sum"]), (4, 10))
        self.assertEqual([e["id"] for e in d["entries"]][0], self.a)
        self.assertEqual([e["id"] for e in d["entries"]][-1], self.d)
        e = d["entries"][0]
        self.assertEqual((e["student"], e["class"], e["subject"], e["day"], e["amount"], e["label"], e["game"]), ("سارة", "الصف الأول أ", "الرياضيات", "2026-09-06", 1, "لعبة: عجلة الحظ", "pick"))
        self.assertEqual(self.log()["entries"][2]["label"], "يدوي")
        self.assertEqual(self.log()["entries"][1]["note"] in ("مشاركة", ""), True)

    def test_filters(self):
        self.assertEqual(sorted(self.ids(student_id=self.st["سارة"])), sorted([self.a, self.b]))
        self.assertEqual(sorted(self.ids(subject_id=self.math)), sorted([self.a, self.c_]))
        self.assertEqual(sorted(self.ids(day="2026-09-03")), sorted([self.b, self.c_]))
        self.assertEqual(self.ids(**{"from": "2026-09-01"}), [self.a, self.c_, self.b] if self.ids(**{"from": "2026-09-01"})[1] == self.c_ else [self.a, self.b, self.c_])
        self.assertEqual(self.ids(to="2026-08-31"), [self.d])
        self.assertEqual(self.log(class_id=self.cid, subject_id=self.sci, student_id=self.st["سارة"])["sum"], 2)
        self.assertEqual(self.log(**{"from": "2026-09-01", "to": "2026-09-05", "subject_id": self.math})["total"], 1)

    def test_a_bad_filter_is_a_sentence(self):
        for q in ("day=كذا", "from=2026-13-40", "to=x"):
            r = self.c.get("/api/points/log?" + q)
            self.assertEqual(r.status_code, 400, q)
            self.assertIn("يوم", r.get_json()["error"])

    def test_pages_of_the_log(self):
        first = self.log(limit=3)
        self.assertEqual((len(first["entries"]), first["total"]), (3, 4))
        rest = self.log(limit=3, offset=3)
        self.assertEqual(len(rest["entries"]), 1)
        self.assertEqual({e["id"] for e in first["entries"]} | {e["id"] for e in rest["entries"]}, {self.a, self.b, self.c_, self.d})
        self.assertEqual(len(self.log(limit=100000)["entries"]), 4)
        self.assertEqual(len(self.log(limit=-5)["entries"]), 4)

    def test_a_correction_shows_in_the_log_and_the_board(self):
        self.api("patch", f"/api/points/{self.c_}", {"amount": 10})
        self.assertEqual(self.log(student_id=self.st["نورة"])["sum"], 14)
        e = next(x for x in self.log()["entries"] if x["id"] == self.c_)
        self.assertTrue(e["edited"])


# ================================================================ how many points an answer gives
class Settings(Phase4):
    def test_the_defaults_and_her_own_numbers(self):
        d = self.c.get("/api/points/settings").get_json()
        self.assertEqual((d["correct"], d["try"], d["limits"]), (1, 0, {"correct": [0, 5], "try": [0, 3]}))
        r = self.api("put", "/api/points/settings", {"correct": 3, "try": 1})
        self.assertEqual((r.status_code, r.get_json()["correct"], r.get_json()["try"]), (200, 3, 1))
        self.assertEqual(self.c.get("/api/points/settings").get_json()["correct"], 3)
        self.api("put", "/api/points/settings", {"correct": 0})
        d = self.c.get("/api/points/settings").get_json()
        self.assertEqual((d["correct"], d["try"]), (0, 1))          # what was not sent stays

    def test_a_number_out_of_range_is_refused(self):
        for body in ({"correct": 6}, {"correct": -1}, {"try": 4}, {"correct": "2"}, {"correct": True}, {"try": 1.5}):
            self.assertEqual(self.api("put", "/api/points/settings", body).status_code, 400, body)
        self.assertEqual(self.c.get("/api/points/settings").get_json()["correct"], 1)

    def test_they_do_not_overwrite_the_other_settings_of_her_week(self):
        self.api("put", "/api/schedule", {"slots": [], "days": [0, 1, 2], "periods": 6})
        before = self.c.get("/api/schedule").get_json()
        self.api("put", "/api/points/settings", {"correct": 2})
        after = self.c.get("/api/schedule").get_json()
        self.assertEqual((after["days"], after["periods"]), (before["days"], before["periods"]))

    def test_each_teacher_has_her_own_numbers(self):
        self.api("put", "/api/points/settings", {"correct": 4})
        other = self.second_teacher()
        self.assertEqual(other.get("/api/points/settings").get_json()["correct"], 1)


# ================================================================ reports
class Reports(Phase4):
    def answer(self, student, correct, when=None, deck="عرض الخلية", n=[0]):
        n[0] += 1
        uid = self.app.db.execute("SELECT user_id FROM students WHERE id = ?", (student,)).fetchone()[0]
        self.app.db.execute("INSERT INTO results(user_id, student_id, deck_id, deck_title, question_id, question, game, kind, correct, run, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                            (uid, student, None, deck, n[0], "سؤال", "pick", "mcq", 1 if correct else 0, f"r{n[0]}", when or 1_788_000_000 + n[0]))
        self.app.db.commit()

    def noon(self, day):
        return datetime.datetime.combine(D.fromisoformat(day), datetime.time(12, 0), datetime.timezone(datetime.timedelta(hours=3))).timestamp()

    def report(self, cid, c=None, **q):
        r = (c or self.c).get(f"/api/reports/class/{cid}?" + "&".join(f"{k}={v}" for k, v in q.items()))
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def test_the_report_of_a_class_has_the_points_the_answers_and_who_was_silent(self):
        cid, st = self.klass(names=("أمل", "بدر", "جود", "دانة"))
        self.give(st["أمل"], 3)
        self.give(st["بدر"], 1)
        for ok in (True, True, False):
            self.answer(st["أمل"], ok, self.noon("2026-09-06"))
        self.answer(st["جود"], True, self.noon("2026-09-06"))
        r = self.report(cid, period="today")
        self.assertEqual((r["students"], r["points"], r["awards"], r["ranked"]), (4, 4, 2, 2))
        rows = {x["name"]: x for x in r["rows"]}
        self.assertEqual((rows["أمل"]["points"], rows["أمل"]["rank"], rows["أمل"]["answered"], rows["أمل"]["correct"], rows["أمل"]["percent"]), (3, 1, 3, 2, 67))
        self.assertEqual((rows["جود"]["points"], rows["جود"]["answered"], rows["جود"]["percent"]), (0, 1, 100))
        self.assertEqual((rows["بدر"]["answered"], rows["بدر"]["percent"], rows["بدر"]["level"]), (0, None, None))
        self.assertEqual(r["silent"], ["دانة"])          # ج answered a question, so she took part
        self.assertEqual([x["name"] for x in r["top"]], ["أمل", "بدر"])
        self.assertTrue(r["answers"])
        self.assertEqual((r["period"], r["period_name"], r["first"], r["last"]), ("today", "اليوم", "2026-09-06", "2026-09-06"))

    def test_the_answers_follow_the_period(self):
        cid, st = self.klass(names=("أمل", "بدر"))
        self.answer(st["أمل"], True, self.noon("2026-09-06"))
        self.answer(st["أمل"], False, self.noon("2026-09-02"))
        self.assertEqual({x["name"]: x["answered"] for x in self.report(cid, period="today")["rows"]}["أمل"], 1)
        self.assertEqual({x["name"]: x["answered"] for x in self.report(cid, period="week")["rows"]}["أمل"], 1)
        self.assertEqual({x["name"]: x["answered"] for x in self.report(cid, period="all")["rows"]}["أمل"], 2)
        edge = datetime.datetime.combine(D(2026, 9, 6), datetime.time.min, datetime.timezone(datetime.timedelta(hours=3))).timestamp()
        self.answer(st["بدر"], True, edge)                    # the first second of the day is that day's
        self.answer(st["بدر"], True, edge - 1)                # the second before it is yesterday's
        self.assertEqual({x["name"]: x["answered"] for x in self.report(cid, period="today")["rows"]}["بدر"], 1)

    def test_next_to_a_subject_only_the_points_are_told(self):
        cid, st = self.klass(names=("أمل", "بدر"))
        math = self.make_subject()
        self.give(st["أمل"], 2, subject_id=math)
        self.give(st["بدر"], 5)
        self.answer(st["أمل"], True)
        r = self.report(cid, period="all", subject_id=math)
        self.assertFalse(r["answers"])
        self.assertEqual([(x["name"], x["points"], x["answered"]) for x in r["rows"]], [("أمل", 2, None), ("بدر", 0, None)])
        self.assertEqual(r["subject"]["name"], "الرياضيات")

    def test_the_chart_has_a_bar_for_every_day_even_a_quiet_one(self):
        cid, st = self.klass(names=("أمل",))
        self.give(st["أمل"], 2)
        self.give(st["أمل"], 3, day="2026-09-04")
        r = self.report(cid, period="all")
        self.assertEqual(len(r["days"]), 14)
        self.assertEqual(r["days"][-1]["day"], "2026-09-06")
        by = {d["day"]: d["points"] for d in r["days"]}
        self.assertEqual((by["2026-09-06"], by["2026-09-05"], by["2026-09-04"], by["2026-08-24"]), (2, 0, 3, 0))
        self.assertEqual(len(self.report(cid, period="today")["days"]), 1)
        self.assertEqual(len(self.report(cid, period="week")["days"]), 1)          # the week began today

    def test_the_report_tells_where_the_plan_of_the_class_stands(self):
        cid, sid, bid = self.scenario()
        self.build(cid, sid)
        _, st = None, None
        self.api("post", "/api/students", {"class_id": cid, "names": ["أمل"]})
        r = self.report(cid, period="all")
        self.assertEqual([(p["subject_name"], p["percent"], p["need"]) for p in r["plans"]], [("الرياضيات", 0, None)])
        self.assertTrue(r["plans"][0]["current"])
        none = self.report(self.make_class("فصل بلا مادة"), period="all")
        self.assertEqual(none["plans"], [])

    def test_a_report_of_an_empty_class_is_still_a_report(self):
        cid = self.make_class()
        r = self.report(cid, period="term")
        self.assertEqual((r["students"], r["points"], r["rows"], r["top"], r["silent"]), (0, 0, [], [], []))

    def test_the_report_of_a_student(self):
        cid, st = self.klass(names=("أمل", "بدر", "جود"))
        math, sci = self.make_subject("الرياضيات"), self.make_subject("العلوم")
        self.give(st["أمل"], 3, subject_id=math, source="game", game="pick")
        self.give(st["أمل"], 2, subject_id=sci, day="2026-09-04")
        self.give(st["أمل"], 1)
        self.give(st["بدر"], 9)
        self.answer(st["أمل"], True, self.noon("2026-09-06"))
        self.answer(st["أمل"], False, self.noon("2026-09-06"), deck="عرض ثانٍ")
        r = self.c.get(f"/api/reports/student/{st['أمل']}?period=all").get_json()
        self.assertEqual((r["points"], r["awards"], r["rank"], r["ranked"], r["classmates"]), (6, 3, 2, 2, 3))
        self.assertEqual(r["student"], {"id": st["أمل"], "name": "أمل", "class_id": cid, "class_name": "الصف الأول أ"})
        self.assertEqual([(x["name"], x["points"]) for x in r["by_subject"]], [("الرياضيات", 3), ("العلوم", 2), ("بلا مادة", 1)])
        self.assertEqual(len(r["recent"]), 3)
        self.assertEqual(r["recent"][0]["day"], "2026-09-06")
        self.assertEqual((r["answers"]["answered"], r["answers"]["correct"], r["answers"]["percent"]), (2, 1, 50))
        self.assertEqual(sorted(x["title"] for x in r["decks"]), ["عرض الخلية", "عرض ثانٍ"])
        self.assertEqual(len(r["days"]), 14)
        sub = self.c.get(f"/api/reports/student/{st['أمل']}?period=all&subject_id={math}").get_json()
        self.assertEqual((sub["points"], sub["rank"], sub["answers"], sub["decks"]), (3, 1, None, []))
        self.assertEqual([x["name"] for x in sub["by_subject"]], ["الرياضيات"])

    def test_the_summary_a_teacher_may_copy_or_send_by_whatsapp(self):
        from urllib.parse import parse_qs, urlparse
        cid, st = self.klass(names=("أمل", "بدر", "جود"))
        self.give(st["أمل"], 3)
        self.give(st["بدر"], 1)
        self.answer(st["أمل"], True, self.noon("2026-09-06"))
        r = self.c.get(f"/api/reports/student/{st['أمل']}?period=today").get_json()
        self.assertEqual(r["text"].split("\n")[0], "ملخص الطالب أمل · الصف الأول أ")
        self.assertIn("النقاط: 3 نقاط · المركز 1 من 3", r["text"])          # of the class (three), not of the two who have points
        self.assertIn("الأسئلة: 1 صحيحة من 1 (100٪)", r["text"])
        self.assertIn("الفترة: اليوم (الأحد 6 سبتمبر 2026)", r["text"])
        u = urlparse(r["wa"])
        self.assertEqual((u.netloc, u.path), ("wa.me", "/"))
        self.assertEqual(parse_qs(u.query)["text"][0], r["text"])

    def test_a_student_report_asks_for_a_known_period_and_her_own_student(self):
        cid, st = self.klass(names=("أمل",))
        self.assertEqual(self.c.get(f"/api/reports/student/{st['أمل']}?period=decade").status_code, 400)
        self.assertEqual(self.c.get("/api/reports/student/99999").status_code, 404)
        self.assertEqual(self.c.get(f"/api/reports/student/{st['أمل']}?subject_id=99999").status_code, 404)

    def test_the_sheet_opens_in_excel_with_its_arabic(self):
        cid, st = self.klass(names=("أمل", "=cmd|' /C calc'!A0", "جود"))
        self.give(st["أمل"], 3, day="2026-09-05")
        self.give(st["جود"], 1)
        self.answer(st["أمل"], True, self.noon("2026-09-05"))
        r = self.c.get(f"/api/reports/class/{cid}/csv?period=all")
        self.assertEqual((r.status_code, r.mimetype), (200, "text/csv"))
        self.assertIn("attachment", r.headers["Content-Disposition"])
        raw = r.data
        self.assertTrue(raw.startswith("﻿".encode()))
        rows = list(csv.reader(io.StringIO(raw.decode("utf-8-sig"))))
        self.assertEqual(rows[0][0], "الصف الأول أ")
        self.assertEqual(rows[1], ["الترتيب", "الطالب", "النقاط", "مرات المنح", "آخر مشاركة", "الأسئلة", "الصحيحة", "النسبة"])
        self.assertEqual(rows[2], ["1", "أمل", "3", "1", "2026-09-05", "1", "1", "100"])
        names = [x[1] for x in rows[2:]]
        self.assertIn("'=cmd|' /C calc'!A0", names)          # never a formula
        self.assertFalse(any(n.startswith("=") for n in names))
        sub = self.c.get(f"/api/reports/class/{cid}/csv?period=all&subject_id={self.make_subject()}").data.decode("utf-8-sig")
        self.assertEqual(list(csv.reader(io.StringIO(sub)))[1], ["الترتيب", "الطالب", "النقاط", "مرات المنح", "آخر مشاركة"])

    def test_the_pages_open(self):
        for url in ("/points", "/reports"):
            r = self.c.get(url)
            self.assertEqual(r.status_code, 200, url)
            self.assertEqual(r.headers["Cache-Control"], "no-store")


# ================================================================ what the pages carry
class Pages(Phase4):
    def lesson(self):
        r = self.upload(self.c, "cell.pptx", FX.pptx_bytes())
        return int(re.search(r"/lessons/(\d+)", r.headers["Location"]).group(1))

    def stage_html(self, query=""):
        loc = self.c.get(f"/lessons/{self.lesson()}/today{query}").headers["Location"]
        return loc, self.c.get(loc.split("?")[0]).get_data(as_text=True)

    def test_the_stage_has_the_points_button_the_subject_picker_and_the_plug_in(self):
        _, html = self.stage_html()
        for ident in ("b-points", "b-subject", "b-class", "b-student", "b-score"):
            self.assertIn(f'id="{ident}"', html)
        self.assertIn("css/points.css", html)
        self.assertLess(html.index("js/present.js"), html.index("js/stage-points.js"))          # the plug-in registers after the stage has been defined
        self.assertIn("الفريقان", html)          # the two teams keep their button, now told apart from the students' points

    def test_the_subject_she_chose_reaches_the_stage_and_anything_else_is_dropped(self):
        loc, _ = self.stage_html("?class=3&subject=5")
        q = parse_qs(urlparse(loc).query)
        self.assertEqual((q["class"], q["subject"]), (["3"], ["5"]))
        self.assertNotIn("subject", self.stage_html("?subject=abc")[0])
        self.assertNotIn("subject", self.stage_html("?subject=5%20or%201")[0])

    def test_every_file_the_new_screens_need_is_served(self):
        for url in ("/static/js/stage-points.js", "/static/js/follow.js", "/static/js/points.js", "/static/js/reports.js", "/static/css/points.css"):
            r = self.c.get(url)
            self.assertEqual(r.status_code, 200, url)
            self.assertGreater(len(r.data), 500, url)

    def test_the_two_pages_carry_their_parts_and_the_header_leads_to_them(self):
        pts = self.c.get("/points").get_data(as_text=True)
        rep = self.c.get("/reports").get_data(as_text=True)
        for ident in ("pt-board", "pt-form", "pt-log", "pt-classes", "pt-subjects", "pt-periods", "pt-s-correct", "pt-s-try", "pt-pending"):
            self.assertIn(f'id="{ident}"', pts, ident)
        for ident in ("rp-class", "rp-student", "rp-table", "rp-csv", "rp-classes", "rp-periods", "rp-pending"):
            self.assertIn(f'id="{ident}"', rep, ident)
        self.assertIn("js/follow.js", pts)
        self.assertLess(pts.index("js/follow.js"), pts.index("js/points.js"))
        self.assertLess(rep.index("js/follow.js"), rep.index("js/reports.js"))
        for html in (pts, rep):
            self.assertIn('class="follow-nav', html)
            self.assertIn('href="/points">المتابعة</a>', html)
            self.assertIn("css/points.css", html)
        self.assertRegex(pts, r'<a href="/points" class="on" aria-current="page">')
        self.assertRegex(rep, r'<a href="/reports" class="on" aria-current="page">')

    def test_no_page_of_the_phase_uses_an_inline_script_or_style(self):
        for url in ("/points", "/reports"):
            html = self.c.get(url).get_data(as_text=True)
            self.assertNotRegex(html, r"<script(?![^>]*\bsrc=)[^>]*>", url)
            self.assertNotRegex(html, r"<style", url)
            self.assertNotRegex(html, r"\sstyle=", url)
            self.assertNotRegex(html, r"\son[a-z]+=", url)

    def test_the_pages_need_a_sign_in(self):
        anon = self.client()
        for url in ("/points", "/reports"):
            self.assertEqual(anon.get(url).status_code, 302, url)

    def test_the_students_page_leads_to_the_points_and_the_list_carries_each_total(self):
        self.assertIn('href="/points"', self.c.get("/students").get_data(as_text=True))
        cid, st = self.klass(names=("أمل", "بدر", "جود"))
        other, ost = self.klass("الصف الثاني", ("هيا", "وعد"))
        self.give(st["أمل"], 3)
        self.give(st["أمل"], 2)
        self.give(st["بدر"], 1)
        self.give(ost["هيا"], 7)
        rows = {s["name"]: s for s in self.c.get("/api/students").get_json()["students"]}
        self.assertEqual({n: rows[n]["points"] for n in ("أمل", "بدر", "جود", "هيا", "وعد")}, {"أمل": 5, "بدر": 1, "جود": 0, "هيا": 7, "وعد": 0})
        one = self.c.get(f"/api/students?class_id={cid}").get_json()["students"]
        self.assertEqual(sorted(s["name"] for s in one), ["أمل", "بدر", "جود"])          # a class lists its own students with their own totals
        self.assertEqual({s["name"]: s["points"] for s in one}, {"أمل": 5, "بدر": 1, "جود": 0})

    def test_the_total_follows_a_correction_and_a_taking_back(self):
        _, st = self.klass(names=("أمل", "بدر"))
        a = self.give(st["أمل"], 3)["id"]
        b = self.give(st["أمل"], 4)["id"]
        total = lambda: {s["name"]: s["points"] for s in self.c.get("/api/students").get_json()["students"]}["أمل"]
        self.assertEqual(total(), 7)
        self.assertEqual(self.api("patch", f"/api/points/{a}", {"amount": 10}).status_code, 200)
        self.assertEqual(total(), 14)
        self.assertEqual(self.api("delete", f"/api/points/{b}").status_code, 200)
        self.assertEqual(total(), 10)

    def test_another_teachers_list_never_carries_my_points(self):
        _, st = self.klass(names=("أمل", "بدر"))
        self.give(st["أمل"], 9)
        c2 = self.second_teacher()
        _, st2 = self.klass("صف آخر", ("أمل", "بدر"), c=c2)          # the same names, another teacher
        rows = c2.get("/api/students").get_json()["students"]
        self.assertEqual({s["points"] for s in rows}, {0})
        self.assertEqual(c2.get("/api/points/board?class_id=%d" % self.c.get("/api/students").get_json()["classes"][0]["id"]).status_code, 404)


# ================================================================ the old database
class Upgrade(unittest.TestCase):
    def test_a_database_of_version_4_gets_the_table_and_loses_nothing(self):
        with tempfile.TemporaryDirectory() as tmp:
            app = create_app(INSTANCE=tmp, BACKGROUND=False)
            db = app.db
            db.execute("INSERT INTO users(id, email, name, pass_hash, created_at) VALUES (1, 'a@example.com', 'معلمة', 'x', 1)")
            db.execute("INSERT INTO classes(id, user_id, name, created_at) VALUES (1, 1, 'الصف الأول', 1)")
            db.execute("INSERT INTO students(id, user_id, class_id, name, created_at) VALUES (1, 1, 1, 'سارة', 1)")
            db.execute("INSERT INTO results(user_id, student_id, deck_title, correct, created_at) VALUES (1, 1, 'عرض', 1, 1)")
            db.execute("INSERT INTO points(user_id, class_id, student_id, day, amount, created_at) VALUES (1, 1, 1, '2026-09-06', 2, 1)")
            db.commit()
            db.execute("DROP TABLE points")                       # a database as version 4.x left it
            db.commit()
            self.assertEqual(db.execute("SELECT name FROM sqlite_master WHERE name = 'points'").fetchone(), None)
            dbm.init(db)
            dbm.init(db)                                          # and again: nothing is added twice
            self.assertEqual(db.execute("SELECT COUNT(*) FROM points").fetchone()[0], 0)
            self.assertEqual([db.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in ("users", "classes", "students", "results")], [1, 1, 1, 1])
            db.execute("INSERT INTO points(user_id, class_id, student_id, day, amount, created_at) VALUES (1, 1, 1, '2026-09-06', 2, 1)")
            db.commit()
            db.close()

    def test_the_table_refuses_what_makes_no_sense(self):
        with tempfile.TemporaryDirectory() as tmp:
            app = create_app(INSTANCE=tmp, BACKGROUND=False)
            db = app.db
            db.execute("INSERT INTO users(id, email, name, pass_hash, created_at) VALUES (1, 'a@example.com', 'معلمة', 'x', 1)")
            db.execute("INSERT INTO classes(id, user_id, name, created_at) VALUES (1, 1, 'ص', 1)")
            db.execute("INSERT INTO students(id, user_id, class_id, name, created_at) VALUES (1, 1, 1, 'سارة', 1)")
            ins = "INSERT INTO points(user_id, class_id, student_id, day, amount, source, created_at) VALUES (1, 1, 1, '2026-09-06', ?, ?, 1)"
            for amount, source in ((0, "manual"), (51, "manual"), (-51, "manual"), (1, "other")):
                with self.assertRaises(sqlite3.IntegrityError, msg=(amount, source)):
                    db.execute(ins, (amount, source))
            db.close()


class Pure(unittest.TestCase):
    def test_week_starts_on_sunday(self):
        for day, start in ((D(2026, 9, 6), D(2026, 9, 6)), (D(2026, 9, 7), D(2026, 9, 6)), (D(2026, 9, 12), D(2026, 9, 6)), (D(2026, 9, 13), D(2026, 9, 13))):
            self.assertEqual(scoring.week_start(day), start, day)

    def test_bounds(self):
        today, term = D(2026, 9, 9), {"starts": "2026-09-06", "ends": "2026-12-17"}
        self.assertEqual(scoring.bounds("today", today), ("2026-09-09", "2026-09-09"))
        self.assertEqual(scoring.bounds("week", today), ("2026-09-06", "2026-09-09"))
        self.assertEqual(scoring.bounds("term", today, term), ("2026-09-06", "2026-12-17"))
        self.assertEqual(scoring.bounds("term", today, None), (None, None))
        self.assertEqual(scoring.bounds("all", today, term), (None, None))

    def test_places(self):
        rows = [{"name": n, "points": p} for n, p in (("بدر", 2), ("أمل", 2), ("دانة", 0), ("جود", 9), ("هيا", -1), ("وعد", 1))]
        out = scoring.standings(rows)
        self.assertEqual([(r["name"], r["rank"]) for r in out], [("جود", 1), ("أمل", 2), ("بدر", 2), ("وعد", 3), ("دانة", None), ("هيا", None)])
        top, more = scoring.podium(out)
        self.assertEqual(([r["name"] for r in top], more), (["جود", "أمل", "بدر", "وعد"], 0))
        top, more = scoring.podium(out, places=1)
        self.assertEqual(([r["name"] for r in top], more), (["جود"], 0))
        self.assertEqual(scoring.podium([]), ([], 0))
        self.assertEqual(scoring.standings([]), [])

    def test_a_long_tie_is_cut(self):
        out = scoring.standings([{"name": f"{i:02d}", "points": 1} for i in range(20)])
        top, more = scoring.podium(out, cap=9)
        self.assertEqual((len(top), more), (9, 11))


if __name__ == "__main__":
    unittest.main()
