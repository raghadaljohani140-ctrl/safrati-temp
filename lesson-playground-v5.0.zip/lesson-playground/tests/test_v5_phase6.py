"""Version 5, phase 6 through the server: activities and homework. A teacher gives a class (or some of its students) a homework, an activity, a project, a reading or a revision,
gets the message for the class's WhatsApp group, and ticks who did it, who did part of it and who did not. Walls between teachers and between classes are tested for every route."""
import datetime
import re
import sqlite3
import tempfile
import unittest
from unittest import mock
from urllib.parse import parse_qs, urlparse

from app import create_app, homework, share, textfmt
from app import db as dbm
from tests import test_v5_phase4 as P4

D = datetime.date
NAMES = ("سارة", "نورة", "ليان", "مها")
WORDS = "حلّي التمرينين 1 و2 في صفحة 14، واحفظي المصطلحات الجديدة."
MUTATING = ("post", "put", "patch", "delete")


class Phase6(P4.Phase4):
    def setUp(self):
        super().setUp()
        homework.create_limit.hits.clear()
        self.addCleanup(homework.create_limit.hits.clear)

    # ---------------------------------------------------------------- small helpers
    def day(self, n=0):
        return (self.today + datetime.timedelta(days=n)).isoformat()

    def world(self, c=None, names=NAMES, klass="الصف الأول أ", subject="العلوم", sid=None):
        """A class with students and a subject (a new one, or the one given): their ids."""
        c = c or self.c
        cid = self.make_class(klass, c)
        sid = sid or self.make_subject(subject, c)
        if names:
            self.assertEqual(self.api("post", "/api/students", {"class_id": cid, "names": list(names)}, c).status_code, 201)
        students = {s["name"]: s["id"] for s in c.get(f"/api/students?class_id={cid}").get_json()["students"]}
        return {"cid": cid, "sid": sid, "students": students}

    def make(self, w, c=None, status=201, **over):
        data = {"class_id": w["cid"], "subject_id": w["sid"], "instructions": WORDS, "due": self.day(2), **over}
        r = self.api("post", "/api/homework", data, c)
        self.assertEqual(r.status_code, status, r.get_data(as_text=True))
        return r.get_json()["assignment"] if status == 201 else r.get_json()

    def get(self, aid, c=None):
        r = (c or self.c).get(f"/api/homework/{aid}")
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()["assignment"]

    def mark(self, aid, items, c=None, status=200):
        r = self.api("put", f"/api/homework/{aid}/status", {"items": [{"student_id": s, "status": st} for s, st in items]}, c)
        self.assertEqual(r.status_code, status, r.get_data(as_text=True))
        return r.get_json()

    def edit(self, aid, data, c=None, status=200):
        r = self.api("patch", f"/api/homework/{aid}", data, c)
        self.assertEqual(r.status_code, status, r.get_data(as_text=True))
        return r.get_json()

    def listing(self, c=None, **q):
        r = (c or self.c).get("/api/homework" + ("?" + "&".join(f"{k}={v}" for k, v in q.items()) if q else ""))
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def share(self, aid, c=None):
        r = (c or self.c).get(f"/api/homework/{aid}/share")
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def rows(self, sql, *args):
        return [dict(r) for r in self.app.db.execute(sql, args).fetchall()]

    def lines(self, aid):
        return {r["student_id"]: r["status"] for r in self.rows("SELECT student_id, status FROM assignment_students WHERE assignment_id = ?", aid)}

    def tables(self):
        return [self.count(f"SELECT COUNT(*) FROM {t}") for t in ("assignments", "assignment_students")]

    @staticmethod
    def stats(a):
        s = a["stats"]
        return (s["total"], s["done"], s["partial"], s["missing"], s["pending"])


# ================================================================ the small pure parts
class Pure(unittest.TestCase):
    def test_counting_homework_in_arabic(self):
        self.assertEqual([textfmt.assignments(n) for n in (0, 1, 2, 3, 10, 11, 25)],
                         ["0 واجبات", "واجب واحد", "واجبان", "3 واجبات", "10 واجبات", "11 واجبًا", "25 واجبًا"])

    def test_the_days_are_said_the_way_people_say_them(self):
        got = {n: textfmt.day_offset(n) for n in (0, 1, -1, 2, -2, 3, 7, 10, 11, 30, -3, -9, -12)}
        self.assertEqual(got, {0: "اليوم", 1: "غدًا", -1: "أمس", 2: "بعد يومين", -2: "قبل يومين", 3: "بعد 3 أيام", 7: "بعد 7 أيام", 10: "بعد 10 أيام", 11: "بعد 11 يومًا",
                               30: "بعد 30 يومًا", -3: "قبل 3 أيام", -9: "قبل 9 أيام", -12: "قبل 12 يومًا"})

    def test_what_she_typed_keeps_its_lines_and_loses_the_clutter(self):
        self.assertEqual(homework.clean_text("  حلّي   السؤال \r\n\r\n\r\n\r\n  ثم   راجعي  "), "حلّي السؤال\n\nثم راجعي")
        self.assertEqual(homework.clean_text(None), "")
        self.assertEqual(homework.clean_text("ا" * 50, 10), "ا" * 10)
        self.assertEqual(homework.one_line(" a \n b\t c ", 100), "a b c")

    def test_the_due_day_must_be_a_real_day_in_range(self):
        today = D(2026, 9, 6)
        self.assertEqual(homework.parse_due("", today), ("", None))
        self.assertEqual(homework.parse_due(None, today), ("", None))
        self.assertEqual(homework.parse_due("2026-09-06", today), ("2026-09-06", None))
        self.assertEqual(homework.parse_due(" 2026-09-10 ", today), ("2026-09-10", None))
        for bad in ("2026-09-05", "2026-02-30", "غدًا", "06/09/2026", "2026-9-6x", "x", 5, "20260908", "2026-W37-2", "2026-9-8", "2026-09-08T10:00", "٢٠٢٦-٠٩-٠٨"):
            d, err = homework.parse_due(bad, today)
            self.assertIsNone(d, bad)
            self.assertTrue(err, bad)
        last = (today + datetime.timedelta(days=homework.MAX_DAYS_AHEAD)).isoformat()
        self.assertEqual(homework.parse_due(last, today), (last, None))
        self.assertIsNone(homework.parse_due((today + datetime.timedelta(days=homework.MAX_DAYS_AHEAD + 1)).isoformat(), today)[0])

    def test_how_near_a_day_is(self):
        today = D(2026, 9, 6)
        self.assertEqual(homework.due_info("", today), ("none", None))
        self.assertEqual(homework.due_info("2026-09-06", today), ("today", 0))
        self.assertEqual(homework.due_info("2026-09-07", today), ("tomorrow", 1))
        self.assertEqual(homework.due_info("2026-09-20", today), ("later", 14))
        self.assertEqual(homework.due_info("2026-09-04", today), ("past", -2))

    def test_the_figures_of_an_assignment(self):
        c = homework.counts_of([{"status": s} for s in ("done", "done", "partial", "missing", "pending", "pending", "pending", "pending")])
        self.assertEqual((c["total"], c["done"], c["partial"], c["missing"], c["pending"], c["checked"], c["percent"]), (8, 2, 1, 1, 4, 4, 25))
        self.assertEqual(homework.counts_of([])["percent"], None)
        self.assertEqual(homework.counts_of([{"status": "done"}] + [{"status": "pending"}] * 7)["percent"], 13)          # 12.5 rounds up (as everywhere: textfmt.percent, and Math.round on the screens)

    def test_the_default_title_is_the_kind_the_subject_and_the_topic(self):
        self.assertEqual(homework.default_title("homework", "العلوم", "الخلية"), "واجب العلوم — الخلية")
        self.assertEqual(homework.default_title("activity", "", ""), "نشاط")
        self.assertEqual(homework.default_title("project", "الرياضيات", ""), "مشروع الرياضيات")
        self.assertLessEqual(len(homework.default_title("reading", "م" * 200, "ن" * 200)), homework.MAX_TITLE)

    def test_every_kind_has_a_name_and_a_picture(self):
        self.assertEqual([k["key"] for k in homework.KIND_LIST], ["homework", "activity", "project", "reading", "review"])
        self.assertEqual([k["name"] for k in homework.KIND_LIST], ["واجب", "نشاط", "مشروع", "قراءة", "مراجعة"])
        self.assertTrue(all(k["icon"] for k in homework.KIND_LIST))


# ================================================================ making one
class Making(Phase6):
    def test_a_homework_is_made_with_the_class_the_words_and_the_day(self):
        w = self.world()
        a = self.make(w, topic="الخلية")
        self.assertEqual((a["kind"], a["kind_name"], a["title"], a["topic"], a["instructions"]), ("homework", "واجب", "واجب العلوم — الخلية", "الخلية", WORDS))
        self.assertEqual((a["given"], a["due"], a["due_state"], a["due_label"], a["closed"]), (self.day(0), self.day(2), "later", "بعد يومين", False))
        self.assertEqual((a["class"]["id"], a["class"]["name"], a["subject"]["id"], a["subject"]["name"]), (w["cid"], "الصف الأول أ", w["sid"], "العلوم"))
        self.assertEqual(self.stats(a), (4, 0, 0, 0, 4))
        self.assertEqual([s["name"] for s in a["students"]], sorted(NAMES))
        self.assertTrue(all(s["status"] == "pending" for s in a["students"]))
        self.assertTrue(a["everyone"] and a["others"] == [])
        row = self.rows("SELECT * FROM assignments")[0]
        self.assertEqual((row["user_id"], row["class_id"], row["subject_id"], row["given_date"], row["due_date"], row["closed"]), (1, w["cid"], w["sid"], self.day(0), self.day(2), 0))
        self.assertEqual(self.tables(), [1, 4])

    def test_the_title_is_made_when_she_gives_none_and_a_title_of_hers_is_kept_and_cut(self):
        w = self.world()
        self.assertEqual(self.make(w)["title"], "واجب العلوم")
        self.assertEqual(self.make(w, kind="activity", topic="تجربة")["title"], "نشاط العلوم — تجربة")
        self.assertEqual(self.make(w, title="  واجب   الأسبوع  ")["title"], "واجب الأسبوع")
        long = self.make(w, title="ع" * 200)["title"]
        self.assertEqual(len(long), homework.MAX_TITLE)
        self.assertEqual(self.make(w, topic="ن" * 300)["topic"], "ن" * homework.MAX_TOPIC)
        self.assertEqual(self.make(w, subject_id=None)["title"], "واجب")

    def test_every_kind_works_and_a_wrong_one_is_refused(self):
        w = self.world()
        for kind, name in (("homework", "واجب"), ("activity", "نشاط"), ("project", "مشروع"), ("reading", "قراءة"), ("review", "مراجعة")):
            a = self.make(w, kind=kind)
            self.assertEqual((a["kind"], a["kind_name"]), (kind, name))
        n = self.tables()
        for bad in ("quiz", "", "HOMEWORK", 3, ["homework"], {"a": 1}):
            r = self.make(w, status=400, kind=bad)
            self.assertIn("نوع", r["error"])
        self.assertEqual(self.tables(), n)
        self.assertEqual(self.make(w, **{"kind": None})["kind"], "homework")          # no kind is the usual one

    def test_the_words_keep_their_lines_and_are_trimmed(self):
        w = self.world()
        a = self.make(w, instructions="  أولًا:   حلّي  السؤال 1\r\n\r\n\r\n\r\nثانيًا: احفظي    القاعدة  \n")
        self.assertEqual(a["instructions"], "أولًا: حلّي السؤال 1\n\nثانيًا: احفظي القاعدة")

    def test_words_that_are_too_short_or_too_long_are_refused_and_never_cut(self):
        w = self.world()
        for bad in ("", "  ", "اب", None, 5, ["x"]):
            r = self.make(w, status=400, instructions=bad)
            self.assertIn("اكتبي المطلوب", r["error"])
        r = self.make(w, status=400, instructions="ا" * (homework.MAX_INSTRUCTIONS + 1))
        self.assertIn(str(homework.MAX_INSTRUCTIONS), r["error"])
        self.assertEqual(self.tables(), [0, 0])
        a = self.make(w, instructions="ا" * homework.MAX_INSTRUCTIONS)
        self.assertEqual(len(a["instructions"]), homework.MAX_INSTRUCTIONS)

    def test_the_due_day_is_today_or_later_and_not_too_far(self):
        w = self.world()
        self.assertEqual(self.make(w, due=self.day(0))["due_state"], "today")
        self.assertEqual(self.make(w, due=self.day(1))["due_state"], "tomorrow")
        a = self.make(w, due="")
        self.assertEqual((a["due"], a["due_state"], a["due_label"], a["due_text"]), ("", "none", "", ""))
        self.assertEqual(self.make(w, due=None)["due"], "")
        self.assertEqual(self.make(w, due=self.day(homework.MAX_DAYS_AHEAD))["due"], self.day(homework.MAX_DAYS_AHEAD))
        n = self.tables()
        for bad in (self.day(-1), self.day(homework.MAX_DAYS_AHEAD + 1), "2026-13-01", "غدًا", "x", 20260908, True):
            self.make(w, status=400, due=bad)
        self.assertEqual(self.tables(), n)

    def test_the_day_follows_the_teachers_day_not_the_servers(self):
        w = self.world()
        a = self.make(w, due=self.day(0))
        self.today += datetime.timedelta(days=1)          # the next morning the same homework is a day late
        late = self.get(a["id"])
        self.assertEqual((late["due_state"], late["due_label"]), ("past", "أمس"))
        self.today += datetime.timedelta(days=4)
        self.assertEqual(self.get(a["id"])["due_label"], "قبل 5 أيام")

    def test_for_all_the_class_or_for_the_students_she_chooses(self):
        w = self.world()
        st = w["students"]
        some = self.make(w, students=[st["سارة"], st["مها"]])
        self.assertEqual(sorted(s["name"] for s in some["students"]), ["سارة", "مها"])
        self.assertEqual(sorted(o["name"] for o in some["others"]), ["ليان", "نورة"])
        self.assertFalse(some["everyone"])
        self.assertEqual(set(self.lines(some["id"])), {st["سارة"], st["مها"]})
        every = self.make(w, students="all")
        self.assertEqual(len(every["students"]), 4)
        dup = self.make(w, students=[st["سارة"], st["سارة"], str(st["سارة"])])
        self.assertEqual([s["name"] for s in dup["students"]], ["سارة"])
        self.assertEqual(self.make(w, students=None)["stats"]["total"], 4)

    def test_a_list_of_nobody_or_a_strange_list_is_refused(self):
        w = self.world()
        n = self.tables()
        for bad in ([], "some", 5, {"a": 1}, True):
            r = self.make(w, status=400, students=bad)
            self.assertIn("error", r, bad)
        self.assertEqual(self.tables(), n)
        self.make(w, status=400, students=list(range(1, homework.MAX_TARGETS + 2)))
        self.assertEqual(self.tables(), n)

    def test_a_student_who_joins_the_class_later_is_not_on_an_old_homework(self):
        w = self.world()
        a = self.make(w)
        self.assertEqual(self.api("post", "/api/students", {"class_id": w["cid"], "names": ["هدى"]}).status_code, 201)
        later = self.get(a["id"])
        self.assertEqual(later["stats"]["total"], 4)
        self.assertEqual([o["name"] for o in later["others"]], ["هدى"])
        self.assertFalse(later["everyone"])
        self.assertEqual(self.make(w)["stats"]["total"], 5)          # a new one includes her

    def test_a_class_with_no_students_still_gets_its_homework_and_its_message(self):
        w = self.world(names=())
        a = self.make(w)
        self.assertEqual((a["stats"]["total"], a["students"], a["everyone"]), (0, [], True))
        self.assertIn(WORDS, self.share(a["id"])["announce"])

    def test_the_subject_is_optional(self):
        w = self.world()
        a = self.make(w, subject_id=None)
        self.assertIsNone(a["subject"])
        self.assertIsNone(self.rows("SELECT subject_id FROM assignments")[0]["subject_id"])
        b = self.make(w, subject_id=0)
        self.assertIsNone(b["subject"])

    def test_the_class_is_needed_and_must_be_hers(self):
        w = self.world()
        for bad in (None, 0, 9999, "x"):
            self.make(w, status=404, class_id=bad)
        self.make(w, status=404, subject_id=9999)
        self.assertEqual(self.tables(), [0, 0])

    def test_there_is_a_most_for_all_her_homework_and_making_them_is_not_unlimited(self):
        w = self.world()
        with mock.patch.object(homework, "MAX_ASSIGNMENTS", 3):
            for _ in range(3):
                self.make(w)
            r = self.make(w, status=400)
            self.assertIn("3", r["error"])
            self.assertEqual(self.api("post", f"/api/homework/{self.listing()['assignments'][0]['id']}/copy", {"class_id": w["cid"]}).status_code, 400)
        self.assertEqual(self.tables()[0], 3)
        homework.create_limit.hits.clear()
        with mock.patch.object(homework, "create_limit", homework.Limiter(2, 3600)):
            self.make(w)
            self.make(w)
            self.make(w, status=429)

    def test_a_refused_homework_leaves_nothing_behind(self):
        w = self.world()
        self.make(w, status=404, students=[99999])
        self.make(w, status=400, due="x")
        self.make(w, status=400, instructions="")
        self.assertEqual(self.tables(), [0, 0])


# ================================================================ the list
class Listing(Phase6):
    def test_open_ones_come_first_the_nearest_day_first_and_those_with_no_day_last(self):
        w = self.world()
        late = self.make(w, due=self.day(9), title="بعيد")
        none = self.make(w, due="", title="بلا موعد")
        near = self.make(w, due=self.day(1), title="قريب")
        mid = self.make(w, due=self.day(4), title="وسط")
        done = self.make(w, due=self.day(0), title="منتهٍ")
        self.edit(done["id"], {"closed": True})
        got = [a["title"] for a in self.listing()["assignments"]]
        self.assertEqual(got, ["قريب", "وسط", "بعيد", "بلا موعد", "منتهٍ"])
        self.assertEqual([a["id"] for a in self.listing(state="open")["assignments"]], [near["id"], mid["id"], late["id"], none["id"]])
        self.assertEqual([a["id"] for a in self.listing(state="closed")["assignments"]], [done["id"]])

    def test_two_with_the_same_day_show_the_newer_first(self):
        w = self.world()
        a, b = self.make(w, due=self.day(3)), self.make(w, due=self.day(3))
        self.assertEqual([x["id"] for x in self.listing()["assignments"]], [b["id"], a["id"]])

    def test_a_class_can_be_asked_for_and_a_class_of_someone_else_is_not_found(self):
        w = self.world()
        w2 = self.world(klass="الصف الثاني ب", subject="الرياضيات", names=("هدى", "أمل"))
        a, b = self.make(w), self.make(w2)
        self.assertEqual([x["id"] for x in self.listing(class_id=w["cid"])["assignments"]], [a["id"]])
        self.assertEqual([x["id"] for x in self.listing(class_id=w2["cid"])["assignments"]], [b["id"]])
        self.assertEqual(len(self.listing()["assignments"]), 2)
        self.assertEqual(self.c.get("/api/homework?class_id=99999").status_code, 404)
        self.assertEqual(self.c.get("/api/homework?class_id=abc").status_code, 200)          # not a number: no filter

    def test_the_list_carries_the_figures_of_every_homework(self):
        w = self.world()
        st = w["students"]
        a = self.make(w)
        self.mark(a["id"], [(st["سارة"], "done"), (st["نورة"], "partial"), (st["ليان"], "missing")])
        row = self.listing()["assignments"][0]
        self.assertEqual(self.stats(row), (4, 1, 1, 1, 1))
        self.assertEqual((row["stats"]["checked"], row["stats"]["percent"]), (3, 25))
        self.assertEqual(self.listing()["kinds"][0], {"key": "homework", "name": "واجب", "icon": "📚"})
        self.assertEqual(self.listing()["today"], self.day(0))

    def test_a_homework_needs_review_when_its_day_has_come_and_someone_is_unchecked(self):
        w = self.world()
        st = w["students"]
        a = self.make(w, due=self.day(1))
        self.assertFalse(self.listing()["assignments"][0]["needs_review"])
        self.assertEqual(self.listing()["attention"], 0)
        self.today += datetime.timedelta(days=1)          # its day
        self.assertTrue(self.listing()["assignments"][0]["needs_review"])
        self.assertEqual(self.listing()["attention"], 1)
        self.mark(a["id"], [(st[n], "done") for n in NAMES[:3]])
        self.assertTrue(self.listing()["assignments"][0]["needs_review"])          # one is still unchecked
        self.mark(a["id"], [(st["مها"], "missing")])
        self.assertFalse(self.listing()["assignments"][0]["needs_review"])
        self.assertEqual(self.listing()["attention"], 0)

    def test_one_with_no_day_or_one_she_ended_never_asks_for_attention(self):
        w = self.world()
        none = self.make(w, due="")
        ended = self.make(w, due=self.day(0))
        self.edit(ended["id"], {"closed": True})
        self.today += datetime.timedelta(days=30)
        got = {a["id"]: a for a in self.listing()["assignments"]}
        self.assertFalse(got[none["id"]]["needs_review"] or got[ended["id"]]["needs_review"])
        self.assertEqual(self.listing()["attention"], 0)

    def test_attention_counts_homework_not_students(self):
        w = self.world()
        for _ in range(3):
            self.make(w, due=self.day(0))
        self.make(w, due=self.day(5))
        self.assertEqual(self.listing()["attention"], 3)

    def test_every_open_one_is_listed_however_many_and_only_the_newest_finished_ones(self):
        w = self.world(names=("سارة",))
        with mock.patch.object(homework, "LIST_LIMIT", 3):
            ids = [self.make(w, title=f"واجب {i}")["id"] for i in range(7)]
            for i in ids[:5]:
                self.edit(i, {"closed": True})
            got = self.listing()["assignments"]
            self.assertEqual([a["id"] for a in got if not a["closed"]], sorted(ids[5:], reverse=True))
            self.assertEqual([a["id"] for a in got if a["closed"]], [ids[4], ids[3], ids[2]])
            self.assertEqual(len(self.listing(state="open")["assignments"]), 2)

    def test_the_list_of_a_new_teacher_is_empty(self):
        d = self.listing()
        self.assertEqual((d["assignments"], d["attention"]), ([], 0))


# ================================================================ who did it
class Tracking(Phase6):
    def setUp(self):
        super().setUp()
        self.w = self.world()
        self.st = self.w["students"]
        self.a = self.make(self.w)

    def test_a_student_can_be_marked_as_done_part_or_not_done(self):
        st, aid = self.st, self.a["id"]
        r = self.mark(aid, [(st["سارة"], "done"), (st["نورة"], "partial"), (st["ليان"], "missing")])["assignment"]
        self.assertEqual(self.stats(r), (4, 1, 1, 1, 1))
        by = {s["name"]: s["status"] for s in r["students"]}
        self.assertEqual(by, {"سارة": "done", "نورة": "partial", "ليان": "missing", "مها": "pending"})
        self.assertEqual(self.lines(aid), {st["سارة"]: "done", st["نورة"]: "partial", st["ليان"]: "missing", st["مها"]: "pending"})
        self.assertEqual(self.get(aid)["stats"]["percent"], 25)

    def test_the_same_tap_again_clears_the_state(self):
        st, aid = self.st, self.a["id"]
        self.mark(aid, [(st["سارة"], "done")])
        r = self.mark(aid, [(st["سارة"], "pending")])["assignment"]
        self.assertEqual(self.stats(r), (4, 0, 0, 0, 4))

    def test_changing_a_mind_replaces_the_state(self):
        st, aid = self.st, self.a["id"]
        self.mark(aid, [(st["سارة"], "done")])
        self.mark(aid, [(st["سارة"], "missing")])
        self.assertEqual(self.lines(aid)[st["سارة"]], "missing")

    def test_several_students_in_one_call_and_the_last_line_for_a_student_wins(self):
        st, aid = self.st, self.a["id"]
        r = self.mark(aid, [(st["سارة"], "done"), (st["نورة"], "done"), (st["سارة"], "missing")])["assignment"]
        self.assertEqual(self.stats(r), (4, 1, 0, 1, 2))

    def test_every_line_is_checked_before_any_is_saved(self):
        st, aid = self.st, self.a["id"]
        before = self.lines(aid)
        self.mark(aid, [(st["سارة"], "done"), (st["نورة"], "excellent")], status=400)
        self.assertEqual(self.lines(aid), before)
        self.mark(aid, [(st["سارة"], "done"), (99999, "done")], status=404)
        self.assertEqual(self.lines(aid), before)
        r = self.api("put", f"/api/homework/{aid}/status", {"items": [{"student_id": st["سارة"], "status": "done"}, "x"]})
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.lines(aid), before)

    def test_nothing_to_save_or_too_much_is_refused(self):
        aid = self.a["id"]
        for bad in (None, [], "x", {"a": 1}, 5):
            self.assertEqual(self.api("put", f"/api/homework/{aid}/status", {"items": bad}).status_code, 400, bad)
        self.assertEqual(self.api("put", f"/api/homework/{aid}/status", {}).status_code, 400)
        many = [{"student_id": 1, "status": "done"}] * (homework.MAX_TARGETS + 1)
        self.assertEqual(self.api("put", f"/api/homework/{aid}/status", {"items": many}).status_code, 400)

    def test_a_status_that_does_not_exist_is_refused(self):
        st, aid = self.st, self.a["id"]
        for bad in ("", "DONE", "finished", None, 1, True, ["done"]):
            self.assertEqual(self.api("put", f"/api/homework/{aid}/status", {"items": [{"student_id": st["سارة"], "status": bad}]}).status_code, 400, bad)
        self.assertEqual(set(self.lines(aid).values()), {"pending"})

    def test_the_rest_of_the_class_can_be_marked_in_one_tap_without_touching_the_ones_already_marked(self):
        st, aid = self.st, self.a["id"]
        self.mark(aid, [(st["سارة"], "missing"), (st["نورة"], "partial")])
        r = self.api("post", f"/api/homework/{aid}/rest", {"status": "done"})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(self.lines(aid), {st["سارة"]: "missing", st["نورة"]: "partial", st["ليان"]: "done", st["مها"]: "done"})
        self.assertEqual(self.stats(r.get_json()["assignment"]), (4, 2, 1, 1, 0))

    def test_the_rest_can_be_marked_as_part_or_not_done_but_not_as_unchecked(self):
        st, aid = self.st, self.a["id"]
        for status in ("partial", "missing"):
            self.assertEqual(self.api("post", f"/api/homework/{aid}/rest", {"status": status}).status_code, 200)
        for bad in ("pending", "x", "", None, 3):
            self.assertEqual(self.api("post", f"/api/homework/{aid}/rest", {"status": bad}).status_code, 400, bad)
        self.assertEqual(set(self.lines(aid).values()), {"partial"})          # the first tap marked them all; the second found nobody unchecked

    def test_the_rest_of_a_homework_does_not_touch_another_homework(self):
        other = self.make(self.w)
        self.api("post", f"/api/homework/{self.a['id']}/rest", {"status": "done"})
        self.assertEqual(set(self.lines(other["id"]).values()), {"pending"})

    def test_marking_is_for_the_students_on_the_homework_only(self):
        some = self.make(self.w, students=[self.st["سارة"]])
        self.mark(some["id"], [(self.st["نورة"], "done")], status=404)
        self.assertEqual(self.lines(some["id"]), {self.st["سارة"]: "pending"})

    def test_the_marks_of_one_homework_are_independent_of_another(self):
        b = self.make(self.w)
        self.mark(self.a["id"], [(self.st["سارة"], "done")])
        self.assertEqual(self.lines(b["id"])[self.st["سارة"]], "pending")

    def test_marking_moves_the_time_it_was_last_touched(self):
        before = self.rows("SELECT updated_at FROM assignments")[0]["updated_at"]
        self.mark(self.a["id"], [(self.st["سارة"], "done")])
        self.assertGreater(self.rows("SELECT updated_at FROM assignments")[0]["updated_at"], before)

    def test_the_response_is_the_whole_assignment_as_the_page_needs_it(self):
        r = self.mark(self.a["id"], [(self.st["سارة"], "done")])["assignment"]
        self.assertEqual([s["name"] for s in r["students"]], sorted(NAMES))
        self.assertEqual([k["key"] for k in r["statuses"]], ["pending", "done", "partial", "missing"])
        self.assertEqual([k["key"] for k in r["kinds"]][:2], ["homework", "activity"])
        self.assertEqual(r["statuses"][1]["name"], "أنجز")

    def test_a_deleted_student_takes_his_line_and_the_figures_follow(self):
        self.mark(self.a["id"], [(self.st["سارة"], "done"), (self.st["نورة"], "missing")])
        self.assertEqual(self.api("delete", f"/api/students/{self.st['سارة']}").status_code, 200)
        a = self.get(self.a["id"])
        self.assertEqual(self.stats(a), (3, 0, 0, 1, 2))
        self.assertNotIn(self.st["سارة"], self.lines(self.a["id"]))


# ================================================================ changing it
class Editing(Phase6):
    def setUp(self):
        super().setUp()
        self.w = self.world()
        self.st = self.w["students"]
        self.a = self.make(self.w, topic="الخلية")

    def test_anything_of_it_can_change_at_any_time(self):
        w2 = self.make_subject("الرياضيات")
        r = self.edit(self.a["id"], {"kind": "project", "title": "مشروع الخلية", "topic": "الخلية الحيوانية", "instructions": "اصنعي نموذجًا للخلية.", "due": self.day(6), "subject_id": w2})["assignment"]
        self.assertEqual((r["kind"], r["title"], r["topic"], r["instructions"], r["due"], r["subject"]["name"]), ("project", "مشروع الخلية", "الخلية الحيوانية", "اصنعي نموذجًا للخلية.", self.day(6), "الرياضيات"))
        row = self.rows("SELECT * FROM assignments")[0]
        self.assertEqual((row["kind"], row["due_date"], row["subject_id"]), ("project", self.day(6), w2))

    def test_what_is_not_sent_is_not_changed(self):
        before = self.rows("SELECT * FROM assignments")[0]
        self.edit(self.a["id"], {})
        after = self.rows("SELECT * FROM assignments")[0]
        self.assertEqual({k: v for k, v in before.items() if k != "updated_at"}, {k: v for k, v in after.items() if k != "updated_at"})
        self.edit(self.a["id"], {"topic": "أخرى"})
        row = self.rows("SELECT * FROM assignments")[0]
        self.assertEqual((row["title"], row["instructions"], row["due_date"]), (before["title"], before["instructions"], before["due_date"]))

    def test_changing_the_kind_does_not_rename_it(self):
        r = self.edit(self.a["id"], {"kind": "activity"})["assignment"]
        self.assertEqual((r["kind"], r["title"]), ("activity", self.a["title"]))

    def test_bad_changes_are_refused_and_nothing_changes(self):
        before = self.rows("SELECT * FROM assignments")[0]
        for data in ({"kind": "quiz"}, {"instructions": "ا"}, {"instructions": "ا" * 1501}, {"title": "ا"}, {"title": ""}, {"due": self.day(-1)}, {"due": "x"}, {"closed": "yes"}, {"closed": 1},
                     {"closed": None}, {"students": []}, {"students": "some"}):
            self.edit(self.a["id"], data, status=400)
        self.assertEqual(self.rows("SELECT * FROM assignments")[0], before)

    def test_the_due_day_may_be_cleared_but_not_set_before_the_day_it_was_given(self):
        self.assertEqual(self.edit(self.a["id"], {"due": ""})["assignment"]["due_state"], "none")
        self.today += datetime.timedelta(days=5)
        self.edit(self.a["id"], {"due": self.day(-5)})          # the day it was given: allowed even when it is past
        self.edit(self.a["id"], {"due": self.day(-6)}, status=400)
        self.assertEqual(self.get(self.a["id"])["due_state"], "past")

    def test_a_homework_is_ended_and_opened_again(self):
        r = self.edit(self.a["id"], {"closed": True})["assignment"]
        self.assertTrue(r["closed"])
        self.assertFalse(r["needs_review"])
        self.assertFalse(self.edit(self.a["id"], {"closed": False})["assignment"]["closed"])

    def test_ending_a_homework_keeps_what_was_marked(self):
        self.api("put", f"/api/homework/{self.a['id']}/status", {"items": [{"student_id": self.st["سارة"], "status": "done"}]})
        self.edit(self.a["id"], {"closed": True})
        self.assertEqual(self.lines(self.a["id"])[self.st["سارة"]], "done")
        self.assertEqual(self.stats(self.get(self.a["id"])), (4, 1, 0, 0, 3))

    def test_the_subject_can_be_taken_off(self):
        self.assertIsNone(self.edit(self.a["id"], {"subject_id": None})["assignment"]["subject"])

    def test_the_students_can_be_changed_those_taken_off_lose_their_line_and_the_others_keep_theirs(self):
        st, aid = self.st, self.a["id"]
        self.api("put", f"/api/homework/{aid}/status", {"items": [{"student_id": st["سارة"], "status": "done"}, {"student_id": st["نورة"], "status": "missing"}]})
        r = self.edit(aid, {"students": [st["سارة"], st["ليان"]]})["assignment"]
        self.assertEqual(self.lines(aid), {st["سارة"]: "done", st["ليان"]: "pending"})
        self.assertEqual(self.stats(r), (2, 1, 0, 0, 1))
        self.assertEqual(sorted(o["name"] for o in r["others"]), ["مها", "نورة"])
        r = self.edit(aid, {"students": "all"})["assignment"]
        self.assertEqual(self.lines(aid), {st["سارة"]: "done", st["ليان"]: "pending", st["نورة"]: "pending", st["مها"]: "pending"})          # an old line is kept, a new one starts unchecked
        self.assertTrue(r["everyone"])

    def test_a_student_of_the_class_who_joined_later_can_be_added(self):
        self.api("post", "/api/students", {"class_id": self.w["cid"], "names": ["هدى"]})
        new = {s["name"]: s["id"] for s in self.c.get(f"/api/students?class_id={self.w['cid']}").get_json()["students"]}["هدى"]
        r = self.edit(self.a["id"], {"students": [*self.st.values(), new]})["assignment"]
        self.assertEqual(r["stats"]["total"], 5)
        self.assertTrue(r["everyone"])

    def test_a_student_who_is_not_hers_or_not_of_this_class_makes_the_whole_change_fail(self):
        other = self.world(klass="الصف الثاني ب", names=("هدى",), sid=self.w["sid"])
        before = (self.lines(self.a["id"]), self.rows("SELECT * FROM assignments")[0])
        self.edit(self.a["id"], {"students": [self.st["سارة"], other["students"]["هدى"]], "title": "عنوان جديد"}, status=404)
        self.assertEqual((self.lines(self.a["id"]), self.rows("SELECT * FROM assignments")[0]), before)

    def test_changing_the_students_alone_moves_the_time_it_was_touched(self):
        before = self.rows("SELECT updated_at FROM assignments")[0]["updated_at"]
        self.edit(self.a["id"], {"students": [self.st["سارة"]]})
        self.assertGreater(self.rows("SELECT updated_at FROM assignments")[0]["updated_at"], before)

    def test_a_homework_that_is_not_there_is_not_found(self):
        self.assertEqual(self.api("patch", "/api/homework/9999", {"title": "ما"}).status_code, 404)
        self.assertEqual(self.c.get("/api/homework/9999").status_code, 404)


# ================================================================ the same for another class
class Copying(Phase6):
    def setUp(self):
        super().setUp()
        self.w = self.world()
        self.w2 = self.world(klass="الصف الأول ب", subject="الرياضيات", names=("هدى", "أمل", "جود"))
        self.a = self.make(self.w, kind="activity", topic="تجربة", title="نشاط التجربة", due=self.day(3))

    def copy(self, aid, cid, c=None, status=201):
        r = self.api("post", f"/api/homework/{aid}/copy", {"class_id": cid}, c)
        self.assertEqual(r.status_code, status, r.get_data(as_text=True))
        return r.get_json()["assignment"] if status == 201 else None

    def test_the_copy_is_a_new_homework_for_all_the_students_of_the_other_class(self):
        b = self.copy(self.a["id"], self.w2["cid"])
        self.assertNotEqual(b["id"], self.a["id"])
        self.assertEqual((b["kind"], b["title"], b["topic"], b["instructions"], b["due"], b["given"]), ("activity", "نشاط التجربة", "تجربة", WORDS, self.day(3), self.day(0)))
        self.assertEqual((b["class"]["id"], b["subject"]["id"]), (self.w2["cid"], self.w["sid"]))
        self.assertEqual(sorted(s["name"] for s in b["students"]), ["أمل", "جود", "هدى"])
        self.assertEqual(self.tables(), [2, 7])

    def test_the_marks_are_not_copied_and_the_two_are_independent(self):
        self.api("put", f"/api/homework/{self.a['id']}/status", {"items": [{"student_id": self.w["students"]["سارة"], "status": "done"}]})
        b = self.copy(self.a["id"], self.w2["cid"])
        self.assertEqual(set(self.lines(b["id"]).values()), {"pending"})
        self.edit(b["id"], {"instructions": "تعليمات أخرى للفصل الآخر."})
        self.assertEqual(self.get(self.a["id"])["instructions"], WORDS)

    def test_a_day_that_has_passed_is_not_copied(self):
        self.today += datetime.timedelta(days=10)
        self.assertEqual(self.copy(self.a["id"], self.w2["cid"])["due"], "")
        self.assertEqual(self.get(self.a["id"])["due"], self.day(-7))

    def test_it_can_be_copied_to_the_same_class_again_and_an_ended_one_is_copied_open(self):
        self.edit(self.a["id"], {"closed": True})
        b = self.copy(self.a["id"], self.w["cid"])
        self.assertFalse(b["closed"])
        self.assertEqual(b["stats"]["total"], 4)

    def test_the_copy_never_includes_a_student_of_the_first_class(self):
        b = self.copy(self.a["id"], self.w2["cid"])
        mine = set(self.w["students"].values())
        self.assertFalse(mine & set(self.lines(b["id"])))

    def test_a_class_that_is_not_hers_is_not_found_and_nothing_is_made(self):
        c2 = self.second_teacher()
        other = self.world(c=c2, klass="صف آخر", names=("منى",))
        for bad in (other["cid"], 99999, 0, None):
            self.copy(self.a["id"], bad, status=404)
        self.assertEqual(self.tables(), [1, 4])


# ================================================================ taking it away
class Removing(Phase6):
    def setUp(self):
        super().setUp()
        self.w = self.world()
        self.a = self.make(self.w)
        self.b = self.make(self.w)

    def test_deleting_a_homework_takes_its_lines_and_only_its_own(self):
        self.assertEqual(self.api("delete", f"/api/homework/{self.a['id']}").status_code, 200)
        self.assertEqual(self.tables(), [1, 4])
        self.assertEqual(self.c.get(f"/api/homework/{self.a['id']}").status_code, 404)
        self.assertEqual(self.c.get(f"/homework/{self.a['id']}").status_code, 404)
        self.assertEqual(len(self.get(self.b["id"])["students"]), 4)
        self.assertEqual(self.api("delete", f"/api/homework/{self.a['id']}").status_code, 404)

    def test_deleting_a_class_takes_its_homework_with_it(self):
        other = self.world(klass="الصف الثاني", names=("هدى",), sid=self.w["sid"])
        keep = self.make(other)
        self.assertEqual(self.api("delete", f"/api/classes/{self.w['cid']}").status_code, 200)
        self.assertEqual([r["id"] for r in self.rows("SELECT id FROM assignments")], [keep["id"]])
        self.assertEqual(self.tables(), [1, 1])

    def test_deleting_a_subject_keeps_the_homework_without_a_subject(self):
        self.assertEqual(self.api("delete", f"/api/subjects/{self.w['sid']}").status_code, 200)
        r = self.get(self.a["id"])
        self.assertIsNone(r["subject"])
        self.assertEqual(r["title"], "واجب العلوم")
        self.assertEqual(self.tables(), [2, 8])

    def test_deleting_all_the_students_of_the_class_leaves_the_homework_and_its_message(self):
        for sid in self.w["students"].values():
            self.api("delete", f"/api/students/{sid}")
        r = self.get(self.a["id"])
        self.assertEqual(r["stats"]["total"], 0)
        self.assertIn(WORDS, self.share(self.a["id"])["announce"])


# ================================================================ the messages for WhatsApp
class Messages(Phase6):
    def setUp(self):
        super().setUp()
        self.w = self.world()

    def test_the_announcement_says_what_by_when_and_what_is_asked(self):
        a = self.make(self.w, topic="الخلية")
        t = self.share(a["id"])["announce"]
        self.assertEqual(t, f"📚 *واجب العلوم — الخلية* (الصف الأول أ)\n📅 موعد التسليم: الثلاثاء 8 سبتمبر 2026\n\nالمطلوب:\n{WORDS}\n\nوفقكم الله 🌟")

    def test_the_icon_follows_the_kind(self):
        for kind, icon in (("homework", "📚"), ("activity", "🎯"), ("project", "🧩"), ("reading", "📖"), ("review", "🔁")):
            self.assertTrue(self.share(self.make(self.w, kind=kind)["id"])["announce"].startswith(icon + " *"), kind)

    def test_the_lesson_is_a_line_of_its_own_unless_the_title_already_says_it(self):
        a = self.make(self.w, title="واجب الأسبوع", topic="الجهاز الهضمي")
        t = self.share(a["id"])["announce"]
        self.assertIn("📖 الدرس: الجهاز الهضمي", t)
        self.assertEqual(t.count("الجهاز الهضمي"), 1)
        b = self.make(self.w, topic="الخلية")          # the made title holds the topic
        self.assertNotIn("📖 الدرس", self.share(b["id"])["announce"])

    def test_the_class_and_subject_are_named_once(self):
        a = self.make(self.w, title="واجب الأسبوع")
        head = self.share(a["id"])["announce"].splitlines()[0]
        self.assertEqual(head, "📚 *واجب الأسبوع* (العلوم · الصف الأول أ)")

    def test_without_a_day_the_message_has_no_day(self):
        t = self.share(self.make(self.w, due="")["id"])["announce"]
        self.assertNotIn("موعد التسليم", t)
        self.assertIn("المطلوب:", t)

    def test_the_message_names_no_student_and_gives_no_number(self):
        self.api("patch", f"/api/classes/{self.w['cid']}", {"whatsapp": "https://chat.whatsapp.com/AbCdEf123456"})
        a = self.make(self.w, students=[self.w["students"]["سارة"]])
        self.api("put", f"/api/homework/{a['id']}/status", {"items": [{"student_id": self.w["students"]["سارة"], "status": "missing"}]})
        d = self.share(a["id"])
        for key in ("announce", "reminder"):
            for name in NAMES:
                self.assertNotIn(name, d[key])
            self.assertNotIn("لم ينجز", d[key])
            self.assertNotIn("أنجز ", d[key])
            self.assertIsNone(re.search(r"\d{7,}", d[key]), "a long number")

    def test_the_reminder_is_worded_by_how_near_the_day_is(self):
        today = self.make(self.w, due=self.day(0))
        tomorrow = self.make(self.w, due=self.day(1))
        later = self.make(self.w, due=self.day(5))
        none = self.make(self.w, due="")
        got = {k: self.share(a["id"])["reminder"] for k, a in (("today", today), ("tomorrow", tomorrow), ("later", later), ("none", none))}
        self.assertIn("⏰ موعد التسليم اليوم", got["today"])
        self.assertIn("⏰ موعد التسليم غدًا", got["tomorrow"])
        self.assertIn("⏰ موعد التسليم " + later["due_text"], got["later"])
        self.assertNotIn("⏰", got["none"])
        for t in got.values():
            self.assertTrue(t.startswith("🔔 *تذكير: واجب العلوم*"))
            self.assertIn(WORDS, t)
            self.assertTrue(t.endswith("نرجو إنجازه وتسليمه في موعده، وفقكم الله 🌟"))
        self.today += datetime.timedelta(days=9)
        past = self.share(today["id"])["reminder"]
        self.assertIn("⏰ انتهى موعد التسليم (" + today["due_text"] + ")", past)
        self.assertTrue(past.endswith("من لم يسلّمه فليسلّمه في أقرب وقت، وفقكم الله 🌟"))

    def test_a_long_reminder_keeps_the_first_words_and_ends_with_an_ellipsis(self):
        words = " ".join(["كلمة"] * 120)
        a = self.make(self.w, instructions=words)
        r = self.share(a["id"])["reminder"]
        self.assertIn("…", r)
        body = r.split("\n\n")[1]
        self.assertLessEqual(len(body), 302)
        self.assertTrue(body.startswith("كلمة كلمة"))
        self.assertIn(words, self.share(a["id"])["announce"])          # the announcement keeps everything

    def test_the_links_open_whatsapp_with_the_exact_text_already_written(self):
        text = "اكتبي الرمز & والنسبة 50% ثم #الهدف ؟ \"اقتباس\" و'آخر' + معادلة = 3\nسطر ثانٍ 😀 مع سطر‏"
        a = self.make(self.w, instructions=text)
        d = self.share(a["id"])
        for key in ("announce", "reminder"):
            url = d[key + "_wa"]
            self.assertTrue(url.startswith("https://wa.me/?text="), key)
            self.assertEqual(parse_qs(urlparse(url).query)["text"][0], d[key])
        self.assertEqual(d["announce"].count("اكتبي الرمز & والنسبة 50%"), 1)

    def test_a_long_arabic_message_travels_whole_in_the_link(self):
        long = "\n".join(f"{i + 1}. اقرئي الفقرة رقم {i + 1} من الدرس واكتبي ما فهمتِه بأسلوبكِ في دفترك." for i in range(18))
        a = self.make(self.w, instructions=long)
        d = self.share(a["id"])
        self.assertFalse(d["announce_too_long"])
        self.assertEqual(parse_qs(urlparse(d["announce_wa"]).query)["text"][0], d["announce"])
        self.assertIn("18. اقرئي الفقرة رقم 18", d["announce"])

    def test_the_longest_allowed_homework_still_fits_the_link(self):
        a = self.make(self.w, instructions="\n".join(["اكتبي ما تعلمتِه اليوم عن الدرس بكلماتكِ"] * 36)[:homework.MAX_INSTRUCTIONS])
        d = self.share(a["id"])
        self.assertFalse(d["announce_too_long"])
        self.assertEqual(parse_qs(urlparse(d["announce_wa"]).query)["text"][0], d["announce"])

    def test_a_text_too_long_for_a_link_is_flagged_and_the_link_is_cut_with_an_ellipsis(self):
        a = self.make(self.w)
        with mock.patch.object(share, "MAX_TEXT", 80):
            d = self.share(a["id"])
        self.assertTrue(d["announce_too_long"])
        self.assertTrue(d["announce_wa"].endswith("%E2%80%A6"))
        self.assertIn(WORDS, d["announce"])          # the text itself is whole, to copy

    def test_the_group_link_of_the_class_comes_with_it(self):
        a = self.make(self.w)
        self.assertEqual(self.share(a["id"])["group"], "")
        self.assertEqual(self.api("patch", f"/api/classes/{self.w['cid']}", {"whatsapp": "https://chat.whatsapp.com/AbCdEf123456?mode=x"}).status_code, 200)
        self.assertEqual(self.share(a["id"])["group"], "https://chat.whatsapp.com/AbCdEf123456")

    def test_the_page_is_told_when_only_some_of_the_class_is_on_the_homework(self):
        self.assertFalse(self.share(self.make(self.w)["id"])["for_some"])
        some = self.make(self.w, students=[self.w["students"]["سارة"]])
        self.assertTrue(self.share(some["id"])["for_some"])
        self.edit(some["id"], {"students": "all"})
        self.assertFalse(self.share(some["id"])["for_some"])

    def test_the_message_follows_the_edits(self):
        a = self.make(self.w)
        self.edit(a["id"], {"instructions": "تعليمات جديدة تمامًا.", "due": self.day(4), "title": "عنوان آخر"})
        t = self.share(a["id"])["announce"]
        self.assertIn("تعليمات جديدة تمامًا.", t)
        self.assertIn("*عنوان آخر*", t)
        self.assertIn(self.get(a["id"])["due_text"], t)
        self.assertNotIn(WORDS, t)

    def test_angle_brackets_and_markup_are_text_only(self):
        a = self.make(self.w, instructions="<script>alert(1)</script> و<b>غامق</b>", title="<img src=x onerror=alert(1)>")
        page = self.c.get(f"/homework/{a['id']}").get_data(as_text=True)
        self.assertNotIn("<img src=x", page)
        self.assertNotIn("<script>alert", page)
        self.assertEqual(self.get(a["id"])["instructions"], "<script>alert(1)</script> و<b>غامق</b>")          # kept as typed; the page shows it as text


# ================================================================ the home screen
class Hub(Phase6):
    def card(self, c=None):
        page = (c or self.c).get("/dashboard").get_data(as_text=True)
        m = re.search(r'<a class="hub-card h-work" href="([^"]+)"><span class="ico"[^>]*>[^<]*</span><b>([^<]*)</b><small>([^<]*)</small>', page)
        self.assertIsNotNone(m, "the card of the homework is on the home screen")
        return m.group(1), m.group(2), m.group(3)

    def test_the_fourth_card_opens_the_page_of_the_homework(self):
        url, title, hint = self.card()
        self.assertEqual((url, title), ("/homework", "الأنشطة والواجبات"))
        self.assertEqual(hint, "واجبات وأنشطة وإرسالها لمجموعة الفصل")

    def test_the_card_tells_how_many_are_waiting_to_be_checked(self):
        w = self.world()
        a = self.make(w, due=self.day(0))
        self.assertEqual(self.card()[2], "واجب واحد بانتظار تسجيل من أنجز")
        b = self.make(w, due=self.day(0))
        self.assertEqual(self.card()[2], "واجبان بانتظار تسجيل من أنجز")
        for _ in range(3):
            self.make(w, due=self.day(-0))
        self.assertEqual(self.card()[2], "5 واجبات بانتظار تسجيل من أنجز")
        self.api("post", f"/api/homework/{a['id']}/rest", {"status": "done"})
        self.assertEqual(self.card()[2], "4 واجبات بانتظار تسجيل من أنجز")
        self.edit(b["id"], {"closed": True})
        self.assertEqual(self.card()[2], "3 واجبات بانتظار تسجيل من أنجز")

    def test_a_homework_that_is_not_due_yet_does_not_nag(self):
        w = self.world()
        self.make(w, due=self.day(3))
        self.make(w, due="")
        self.assertEqual(self.card()[2], "واجبات وأنشطة وإرسالها لمجموعة الفصل")
        self.today += datetime.timedelta(days=3)
        self.assertEqual(self.card()[2], "واجب واحد بانتظار تسجيل من أنجز")

    def test_a_late_homework_still_waits_until_everyone_is_checked(self):
        w = self.world(names=("سارة",))
        a = self.make(w, due=self.day(0))
        self.today += datetime.timedelta(days=20)
        self.assertEqual(self.card()[2], "واجب واحد بانتظار تسجيل من أنجز")
        self.api("put", f"/api/homework/{a['id']}/status", {"items": [{"student_id": w["students"]["سارة"], "status": "missing"}]})
        self.assertEqual(self.card()[2], "واجبات وأنشطة وإرسالها لمجموعة الفصل")

    def test_the_card_of_one_teacher_does_not_count_the_homework_of_another(self):
        w = self.world()
        self.make(w, due=self.day(0))
        c2 = self.second_teacher()
        self.assertEqual(self.card(c2)[2], "واجبات وأنشطة وإرسالها لمجموعة الفصل")

    def test_the_menu_of_every_page_has_the_link(self):
        for url in ("/dashboard", "/homework", "/students"):
            self.assertIn('href="/homework">الواجبات</a>', self.c.get(url).get_data(as_text=True), url)


# ================================================================ the usual day and the lessons of a class
class Suggestions(Phase6):
    def info(self, cid, sid=None, c=None, status=200):
        r = (c or self.c).get(f"/api/homework/lessons?class_id={cid}" + (f"&subject_id={sid}" if sid else ""))
        self.assertEqual(r.status_code, status, r.get_data(as_text=True))
        return r.get_json()

    def test_the_usual_day_is_the_next_time_the_class_meets_the_subject(self):
        cid, sid, bid = self.scenario()          # Sunday and Tuesday, the term from Sunday 6 September
        self.assertEqual(self.info(cid, sid)["next_lesson"]["date"], self.day(2))          # today is a Sunday: the next one is Tuesday
        self.today += datetime.timedelta(days=2)
        self.assertEqual(self.info(cid, sid)["next_lesson"]["date"], self.day(5))          # Tuesday: the next is Sunday
        self.assertEqual(self.info(cid, sid)["next_lesson"]["text"], share.ar_date(self.day(5)))

    def test_a_holiday_and_a_day_she_is_away_are_skipped(self):
        cid, sid, bid = self.scenario()
        r = self.api("post", "/api/calendar/holidays", {"from": self.day(2), "label": "إجازة"})
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        self.assertEqual(self.info(cid, sid)["next_lesson"]["date"], self.day(7))
        r = self.api("post", "/api/absence", {"from": self.day(7)})
        self.assertIn(r.status_code, (200, 201), r.get_data(as_text=True))
        self.assertEqual(self.info(cid, sid)["next_lesson"]["date"], self.day(9))

    def test_without_a_timetable_a_term_or_a_subject_there_is_no_suggestion(self):
        cid, sid = self.make_class(), self.make_subject()
        self.assertIsNone(self.info(cid, sid)["next_lesson"])          # no term, no timetable
        self.set_term()
        self.assertIsNone(self.info(cid, sid)["next_lesson"])          # a term, no timetable
        self.set_slots([(0, 1, cid, sid)])
        self.assertIsNotNone(self.info(cid, sid)["next_lesson"])
        self.assertIsNone(self.info(cid)["next_lesson"])               # no subject asked
        other = self.make_subject("الفقه")
        self.assertIsNone(self.info(cid, other)["next_lesson"])        # another subject with no periods

    def test_after_the_end_of_the_term_there_is_none(self):
        cid, sid, bid = self.scenario()
        self.today = D(2027, 1, 3)
        self.assertIsNone(self.info(cid, sid)["next_lesson"])

    def test_the_lessons_of_the_book_come_in_its_order_with_the_ones_done_marked_and_exams_left_out(self):
        text = "الوحدة الأولى: الأعداد\nالدرس الأول: المقارنة\nالدرس الثاني: الجمع\nمراجعة الوحدة الأولى\nاختبار الوحدة الأولى\nالوحدة الثانية: الكسور\nالدرس الأول: العادية"
        cid, sid, bid = self.scenario(text=text)
        self.build(cid, sid)
        item = self.plan(cid, sid)["items"][0]
        self.act(item["id"], "done")
        d = self.info(cid, sid)
        self.assertEqual(d["book"]["id"], bid)
        self.assertEqual([l["title"] for l in d["lessons"]], ["الدرس الأول: المقارنة", "الدرس الثاني: الجمع", "مراجعة الوحدة الأولى", "الدرس الأول: العادية"])
        self.assertEqual([l["done"] for l in d["lessons"]], [True, False, False, False])
        self.assertEqual([l["unit"] for l in d["lessons"]], ["الوحدة الأولى: الأعداد"] * 3 + ["الوحدة الثانية: الكسور"])

    def test_a_class_without_a_book_has_no_lessons(self):
        cid, sid = self.make_class(), self.make_subject()
        d = self.info(cid, sid)
        self.assertEqual((d["book"], d["lessons"]), (None, []))

    def test_the_lessons_of_another_teachers_class_or_subject_are_not_found(self):
        cid, sid, bid = self.scenario()
        c2 = self.second_teacher()
        self.info(cid, sid, c=c2, status=404)
        mine = self.world(c=c2, klass="صف آخر", subject="مادة أخرى", names=("منى",))
        self.info(mine["cid"], sid, c=c2, status=404)
        self.info(cid, mine["sid"], status=404)
        self.info(99999, status=404)


# ================================================================ the pages
class Pages(Phase6):
    def test_the_two_pages_open_for_a_signed_in_teacher(self):
        w = self.world()
        a = self.make(w)
        r = self.c.get("/homework")
        self.assertEqual(r.status_code, 200)
        page = r.get_data(as_text=True)
        self.assertIn("الأنشطة والواجبات", page)
        self.assertIn("homework.js", page)
        self.assertIn("homework-common.js", page)
        one = self.c.get(f"/homework/{a['id']}").get_data(as_text=True)
        self.assertIn(f'data-id="{a["id"]}"', one)
        self.assertIn("homework-one.js", one)

    def test_the_pages_obey_the_content_security_policy(self):
        w = self.world()
        a = self.make(w)
        for url in ("/homework", f"/homework/{a['id']}"):
            r = self.c.get(url)
            page = r.get_data(as_text=True)
            self.assertIsNone(re.search(r"<script(?![^>]*\bsrc=)[^>]*>", page), "an inline script")
            self.assertIsNone(re.search(r"\sstyle\s*=", page), "an inline style")
            self.assertIsNone(re.search(r"\son[a-z]+\s*=", page), "an inline handler")
            self.assertIn("no-store", r.headers.get("Cache-Control", ""))

    def test_the_scripts_do_not_use_inline_markup_or_handlers(self):
        import pathlib
        root = pathlib.Path(__file__).resolve().parent.parent / "app" / "static" / "js"
        for name in ("homework.js", "homework-one.js", "homework-common.js"):
            src = (root / name).read_text(encoding="utf-8")
            self.assertNotIn("innerHTML", src, name)
            self.assertNotIn("insertAdjacentHTML", src, name)
            self.assertNotIn("document.write", src, name)
            self.assertNotIn("eval(", src, name)
            self.assertNotIn("setAttribute('style'", src, name)

    def test_the_pages_belong_to_a_signed_in_teacher(self):
        w = self.world()
        a = self.make(w)
        anon = self.client()
        for url in ("/homework", f"/homework/{a['id']}"):
            self.assertEqual(anon.get(url).status_code, 302, url)
            self.assertIn("/login", anon.get(url).headers["Location"])

    def test_the_page_of_a_homework_that_is_not_there_is_not_found(self):
        self.assertEqual(self.c.get("/homework/9999").status_code, 404)
        self.assertEqual(self.c.get("/homework/abc").status_code, 404)

    def test_the_page_of_one_homework_has_the_pieces_the_script_looks_for(self):
        w = self.world()
        page = self.c.get(f"/homework/{self.make(w)['id']}").get_data(as_text=True)
        ids = re.findall(r'\bid="([^"]+)"', page)
        for needed in ("hw1-app", "hw1-head", "hw1-wa", "hw1-students", "hw1-tiles", "hw1-meter", "hw1-rest-done", "hw1-rest-partial", "hw1-rest-missing", "hw1-print", "hw1-sheet",
                       "hw1-form", "hw1-checks", "hw1-who-save", "hw1-close", "hw1-copy-class", "hw1-copy", "hw1-del", "hw1-live", "hw1-err", "hw1-fresh", "hw1-rest-label", "hw1-close-note"):
            self.assertIn(needed, ids, needed)
        self.assertEqual(len(ids), len(set(ids)), "an id used twice")

    def test_every_element_the_scripts_ask_for_is_on_its_page(self):
        import pathlib
        base = pathlib.Path(__file__).resolve().parent.parent / "app"
        for page_name, js_name in (("homework.html", "homework.js"), ("homework_one.html", "homework-one.js")):
            html = (base / "templates" / page_name).read_text(encoding="utf-8")
            have = set(re.findall(r'\bid="([^"]+)"', html))
            src = (base / "static" / "js" / js_name).read_text(encoding="utf-8")
            asked = set(re.findall(r"\$\('([a-z0-9-]+)'\)", src)) | set(re.findall(r"say\('([a-z0-9-]+)'", src)) | {i for i in re.findall(r"for \(const id of \[([^\]]+)\]", src) for i in re.findall(r"'([a-z0-9-]+)'", i)}
            self.assertEqual(sorted(asked - have), [], js_name)


# ================================================================ walls
class Walls(Phase6):
    """Every route of the homework, asked by another teacher, behaves as if it did not exist; every route asked by the same teacher about another class stays inside its class."""

    def setUp(self):
        super().setUp()
        self.w = self.world()
        self.c2 = self.second_teacher()
        self.w2 = self.world(c=self.c2, klass="الصف الأول أ", subject="العلوم", names=NAMES)          # the very same names for a class, a subject and the students
        self.a = self.make(self.w, instructions="SECRET-سر-المعلمة الأولى", title="عنوان سري")
        self.mark(self.a["id"], [(self.w["students"]["سارة"], "missing")])
        self.snapshot = self.picture()

    def calls(self, aid, student, cls, subject):
        return [("get", f"/homework/{aid}", None), ("get", f"/api/homework/{aid}", None), ("patch", f"/api/homework/{aid}", {"instructions": "هجوم هجوم"}),
                ("patch", f"/api/homework/{aid}", {"closed": True}), ("patch", f"/api/homework/{aid}", {"students": [student]}), ("delete", f"/api/homework/{aid}", None),
                ("post", f"/api/homework/{aid}/copy", {"class_id": cls}), ("put", f"/api/homework/{aid}/status", {"items": [{"student_id": student, "status": "done"}]}),
                ("post", f"/api/homework/{aid}/rest", {"status": "done"}), ("get", f"/api/homework/{aid}/share", None)]

    def picture(self):
        """Everything stored about her homework, and what the screens read of it."""
        aid = self.a["id"]
        return (self.get(aid), self.rows("SELECT * FROM assignments WHERE user_id = 1 ORDER BY id"), self.rows("SELECT * FROM assignment_students WHERE user_id = 1 ORDER BY id"),
                self.share(aid), self.listing())

    def unchanged(self):
        self.assertEqual(self.picture(), self.snapshot)

    def test_another_teacher_reads_and_changes_nothing_every_route_is_not_found(self):
        for method, url, data in self.calls(self.a["id"], self.w2["students"]["سارة"], self.w2["cid"], self.w2["sid"]):
            r = getattr(self.c2, method)(url, json=data, headers={"X-CSRF": self.token(self.c2)}) if method != "get" else self.c2.get(url)
            self.assertEqual(r.status_code, 404, (method, url))
            self.assertNotIn("SECRET", r.get_data(as_text=True))
            self.assertNotIn("عنوان سري", r.get_data(as_text=True))
        self.unchanged()
        self.assertEqual(self.tables(), [1, 4])          # and she made nothing for herself either

    def test_another_teacher_sees_only_her_own_homework(self):
        self.assertEqual(self.listing(c=self.c2)["assignments"], [])
        mine = self.make(self.w2, c=self.c2, title="واجبها")
        got = self.listing(c=self.c2)
        self.assertEqual([x["id"] for x in got["assignments"]], [mine["id"]])
        self.assertNotIn("SECRET", str(got))
        self.assertEqual([x["title"] for x in self.listing()["assignments"]], ["عنوان سري"])
        self.unchanged()

    def test_another_teacher_cannot_ask_for_my_class_in_the_list_or_make_a_homework_from_anything_of_mine(self):
        self.assertEqual(self.c2.get(f"/api/homework?class_id={self.w['cid']}").status_code, 404)
        self.assertEqual(self.c2.get(f"/api/homework/lessons?class_id={self.w['cid']}&subject_id={self.w['sid']}").status_code, 404)
        for data in ({"class_id": self.w["cid"]}, {"class_id": self.w2["cid"], "subject_id": self.w["sid"]}, {"class_id": self.w2["cid"], "students": [self.w["students"]["سارة"]]},
                     {"class_id": self.w["cid"], "students": [self.w2["students"]["سارة"]]}):
            r = self.api("post", "/api/homework", {"instructions": WORDS, **data}, self.c2)
            self.assertEqual(r.status_code, 404, data)
        self.assertEqual(self.tables(), [1, 4])
        self.unchanged()

    def test_the_students_of_another_teacher_cannot_be_put_on_my_homework_even_with_the_same_names(self):
        theirs = list(self.w2["students"].values())
        self.assertEqual(self.api("patch", f"/api/homework/{self.a['id']}", {"students": theirs}).status_code, 404)
        self.assertEqual(self.api("put", f"/api/homework/{self.a['id']}/status", {"items": [{"student_id": theirs[0], "status": "done"}]}).status_code, 404)
        self.unchanged()

    def test_the_same_teachers_other_class_cannot_read_or_write_the_homework_of_this_one(self):
        other = self.world(klass="الصف الثاني ب", subject="الرياضيات", names=("هدى", "أمل", "جود"))
        mine_b = self.make(other, instructions="سر الصف الثاني")
        snap_b = (self.get(mine_b["id"]), self.rows("SELECT * FROM assignment_students WHERE assignment_id = ? ORDER BY id", mine_b["id"]))
        aid = self.a["id"]
        in_b = list(other["students"].values())
        # a student of class B on the homework of class A: refused, and nothing of A changed
        self.assertEqual(self.api("put", f"/api/homework/{aid}/status", {"items": [{"student_id": in_b[0], "status": "done"}]}).status_code, 404)
        self.assertEqual(self.api("patch", f"/api/homework/{aid}", {"students": in_b}).status_code, 404)
        self.assertEqual(self.api("patch", f"/api/homework/{aid}", {"students": [self.w["students"]["سارة"], in_b[0]]}).status_code, 404)
        self.assertEqual(self.api("put", f"/api/homework/{mine_b['id']}/status", {"items": [{"student_id": self.w["students"]["سارة"], "status": "done"}]}).status_code, 404)
        self.assertEqual(self.api("post", "/api/homework", {"class_id": other["cid"], "instructions": WORDS, "students": [self.w["students"]["سارة"]]}).status_code, 404)
        self.assertEqual(self.api("post", "/api/homework", {"class_id": self.w["cid"], "instructions": WORDS, "students": [in_b[0]]}).status_code, 404)
        self.assertEqual((self.get(mine_b["id"]), self.rows("SELECT * FROM assignment_students WHERE assignment_id = ? ORDER BY id", mine_b["id"])), snap_b)
        self.assertEqual(self.tables(), [2, 4 + 3])
        # each class lists, and counts, its own
        self.assertEqual([x["id"] for x in self.listing(class_id=self.w["cid"])["assignments"]], [aid])
        self.assertEqual([x["id"] for x in self.listing(class_id=other["cid"])["assignments"]], [mine_b["id"]])
        self.assertEqual(sorted(s["name"] for s in self.get(aid)["students"] + self.get(aid)["others"]), sorted(NAMES))
        self.assertEqual(sorted(s["name"] for s in self.get(mine_b["id"])["students"] + self.get(mine_b["id"])["others"]), sorted(other["students"]))
        self.assertEqual(sorted(self.lines(aid)), sorted(self.w["students"].values()))
        self.assertEqual(sorted(self.lines(mine_b["id"])), sorted(in_b))
        # and the copy makes the homework of the other class for the students of THAT class only
        c = self.api("post", f"/api/homework/{aid}/copy", {"class_id": other["cid"]}).get_json()["assignment"]
        self.assertEqual(sorted(self.lines(c["id"])), sorted(in_b))
        self.assertFalse(set(self.lines(c["id"])) & set(self.w["students"].values()))

    def test_a_row_of_the_wrong_class_cannot_be_written_through_the_api_at_all(self):
        other = self.world(klass="الصف الثاني ب", names=("هدى",), sid=self.w["sid"])
        for sid in other["students"].values():
            self.assertEqual(self.api("put", f"/api/homework/{self.a['id']}/status", {"items": [{"student_id": sid, "status": "done"}]}).status_code, 404)
        self.assertEqual([r["class_id"] for r in self.rows("SELECT DISTINCT class_id FROM assignment_students WHERE assignment_id = ?", self.a["id"])], [self.w["cid"]])

    def test_nothing_works_without_signing_in_or_without_the_form_token(self):
        aid, st = self.a["id"], self.w["students"]["سارة"]
        anon = self.client()
        for method, url, data in self.calls(aid, st, self.w["cid"], self.w["sid"]):
            r = anon.get(url) if method == "get" else getattr(anon, method)(url, json=data, headers={"X-CSRF": self.token(anon)})
            if url.startswith("/api/"):
                self.assertEqual(r.status_code, 401, (method, url))
            else:
                self.assertEqual(r.status_code, 302, (method, url))
        for method, url, data in self.calls(aid, st, self.w["cid"], self.w["sid"]):
            if method in MUTATING:
                r = getattr(self.c, method)(url, json=data)          # signed in, but no token
                self.assertEqual(r.status_code, 403, (method, url))
        for url in ("/api/homework", f"/api/homework/lessons?class_id={self.w['cid']}"):
            self.assertEqual(anon.get(url).status_code, 401, url)
        self.assertEqual(anon.post("/api/homework", json={}, headers={"X-CSRF": self.token(anon)}).status_code, 401)
        self.assertEqual(self.c.post("/api/homework", json={"class_id": self.w["cid"], "instructions": WORDS}).status_code, 403)
        self.unchanged()


# ================================================================ the old database
# ================================================================ the reports carry the homework
class InReports(Phase6):
    """The report of a class and the report of a student tell what was given and how it went (the share is of the students already checked, so a homework she
    has not reached yet does not lower it), by class, subject and the day it was given. Never another teacher's, never another class's."""

    def report(self, cid, c=None, **q):
        r = (c or self.c).get(f"/api/reports/class/{cid}?" + "&".join(f"{k}={v}" for k, v in {"period": "all", **q}.items()))
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def student(self, sid, c=None, **q):
        r = (c or self.c).get(f"/api/reports/student/{sid}?" + "&".join(f"{k}={v}" for k, v in {"period": "all", **q}.items()))
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def csv(self, cid, c=None, **q):
        r = (c or self.c).get(f"/api/reports/class/{cid}/csv?" + "&".join(f"{k}={v}" for k, v in {"period": "all", **q}.items()))
        self.assertEqual(r.status_code, 200)
        return [row.split(",") for row in r.data.decode("utf-8-sig").strip().split("\r\n")]

    def setUp(self):
        super().setUp()
        self.w = self.world()
        self.st = self.w["students"]

    def two(self):
        """Two homework for the whole class with some of it checked: [first, second]."""
        a, b = self.make(self.w), self.make(self.w, due=self.day(3))
        st = self.st
        self.mark(a["id"], [(st["سارة"], "done"), (st["نورة"], "partial"), (st["ليان"], "missing")])
        self.mark(b["id"], [(st["سارة"], "done"), (st["نورة"], "done")])
        return a, b

    # ---------------------------------------------------------------- the class
    def test_a_class_with_no_homework_says_none_was_given(self):
        r = self.report(self.w["cid"])["homework"]
        self.assertEqual((r["given"], r["checked"], r["percent"], r["students"]), (0, 0, None, []))
        self.assertEqual((r["done"], r["partial"], r["missing"], r["pending"]), (0, 0, 0, 0))

    def test_the_class_figures_count_every_line_and_the_share_is_of_those_already_checked(self):
        self.two()
        r = self.report(self.w["cid"])["homework"]
        self.assertEqual(r["given"], 2)
        self.assertEqual((r["done"], r["partial"], r["missing"], r["pending"]), (3, 1, 1, 3))
        self.assertEqual((r["checked"], r["percent"]), (5, 60))          # 3 of the 5 checked, not 3 of the 8 lines

    def test_a_line_for_every_student_who_was_on_a_homework(self):
        self.two()
        by = {x["student_id"]: x for x in self.report(self.w["cid"])["homework"]["students"]}
        self.assertEqual(sorted(by), sorted(self.st.values()))
        got = lambda n: (by[self.st[n]]["done"], by[self.st[n]]["partial"], by[self.st[n]]["missing"], by[self.st[n]]["pending"], by[self.st[n]]["checked"], by[self.st[n]]["percent"])
        self.assertEqual(got("سارة"), (2, 0, 0, 0, 2, 100))
        self.assertEqual(got("نورة"), (1, 1, 0, 0, 2, 50))
        self.assertEqual(got("ليان"), (0, 0, 1, 1, 1, 0))
        self.assertEqual(got("مها"), (0, 0, 0, 2, 0, None))          # nothing checked yet: no share, and not a zero

    def test_a_homework_nobody_was_checked_for_has_no_share(self):
        self.make(self.w)
        r = self.report(self.w["cid"])["homework"]
        self.assertEqual((r["given"], r["pending"], r["checked"], r["percent"]), (1, 4, 0, None))

    def test_ended_homework_still_counts_and_a_deleted_one_does_not(self):
        a, b = self.two()
        self.edit(a["id"], {"closed": True})
        self.assertEqual(self.report(self.w["cid"])["homework"]["given"], 2)
        self.assertEqual(self.api("delete", f"/api/homework/{b['id']}").status_code, 200)
        r = self.report(self.w["cid"])["homework"]
        self.assertEqual((r["given"], r["done"], r["partial"], r["missing"], r["pending"]), (1, 1, 1, 1, 1))

    def test_the_students_taken_off_a_homework_leave_its_figures(self):
        a = self.make(self.w)
        self.mark(a["id"], [(self.st["سارة"], "done"), (self.st["نورة"], "missing")])
        self.edit(a["id"], {"students": [self.st["سارة"], self.st["ليان"]]})
        r = self.report(self.w["cid"])["homework"]
        self.assertEqual((r["done"], r["missing"], r["pending"], r["checked"], r["percent"]), (1, 0, 1, 1, 100))
        self.assertEqual(sorted(x["student_id"] for x in r["students"]), sorted([self.st["سارة"], self.st["ليان"]]))

    def test_a_student_who_joined_later_has_no_line_for_the_old_homework(self):
        self.two()
        self.assertEqual(self.api("post", "/api/students", {"class_id": self.w["cid"], "names": ["هيا"]}).status_code, 201)
        new = {s["name"]: s["id"] for s in self.c.get(f"/api/students?class_id={self.w['cid']}").get_json()["students"]}["هيا"]
        r = self.report(self.w["cid"])
        self.assertNotIn(new, [x["student_id"] for x in r["homework"]["students"]])
        self.assertIn(new, [x["student_id"] for x in r["rows"]])          # (she is in the class report, with no homework)

    def test_only_this_class_is_counted(self):
        self.two()
        other = self.world(klass="الصف الأول ب", names=("ريم", "دانة"), sid=self.w["sid"])
        b = self.make(other)
        self.mark(b["id"], [(other["students"]["ريم"], "done")])
        mine, theirs = self.report(self.w["cid"])["homework"], self.report(other["cid"])["homework"]
        self.assertEqual((mine["given"], mine["done"]), (2, 3))
        self.assertEqual((theirs["given"], theirs["done"], theirs["pending"]), (1, 1, 1))
        self.assertEqual(sorted(x["student_id"] for x in theirs["students"]), sorted(other["students"].values()))

    def test_a_subject_limits_it_and_no_subject_is_counted_with_all(self):
        sci = self.make(self.w)
        maths = self.make_subject("الرياضيات")
        a = self.make(self.w, subject_id=maths)
        b = self.make(self.w, subject_id=None)
        self.mark(sci["id"], [(self.st["سارة"], "done")])
        self.mark(a["id"], [(self.st["سارة"], "missing")])
        self.mark(b["id"], [(self.st["سارة"], "partial")])
        every = self.report(self.w["cid"])["homework"]
        self.assertEqual((every["given"], every["done"], every["missing"], every["partial"]), (3, 1, 1, 1))
        for sid, want in ((self.w["sid"], (1, 1, 0, 0)), (maths, (1, 0, 1, 0))):
            h = self.report(self.w["cid"], subject_id=sid)["homework"]
            self.assertEqual((h["given"], h["done"], h["missing"], h["partial"]), want)
        r = self.report(self.w["cid"], subject_id=self.w["sid"])
        self.assertEqual((r["subject"]["id"], r["answers"]), (self.w["sid"], False))          # (a subject still tells only its points, as before)

    def test_the_period_follows_the_day_it_was_given(self):
        self.make(self.w)                                                        # Sunday 6 September
        self.today += datetime.timedelta(days=1)
        self.make(self.w)                                                        # Monday
        self.today += datetime.timedelta(days=7)
        self.make(self.w)                                                        # the next Monday
        cid = self.w["cid"]
        self.assertEqual(self.report(cid, period="today")["homework"]["given"], 1)
        self.assertEqual(self.report(cid, period="week")["homework"]["given"], 1)          # this week began on the Sunday before
        self.assertEqual(self.report(cid, period="all")["homework"]["given"], 3)
        self.today -= datetime.timedelta(days=7)
        self.assertEqual(self.report(cid, period="week")["homework"]["given"], 2)
        self.assertEqual(self.report(cid, period="today")["homework"]["given"], 1)

    def test_the_term_is_her_current_term(self):
        self.set_term()
        self.make(self.w)
        self.today = D(2026, 12, 20)          # after the term ended: the next term has not begun and the old term is no longer the current one
        self.assertEqual(self.report(self.w["cid"], period="all")["homework"]["given"], 1)

    def test_a_class_report_still_has_everything_else_with_homework_in_it(self):
        self.two()
        self.give(self.st["سارة"], 2)
        r = self.report(self.w["cid"])
        self.assertEqual((r["students"], r["points"], r["ranked"]), (4, 2, 1))
        self.assertEqual(r["homework"]["given"], 2)

    # ---------------------------------------------------------------- the student
    def test_a_student_without_homework_has_none(self):
        h = self.student(self.st["سارة"])["homework"]
        self.assertEqual((h["given"], h["checked"], h["percent"], h["recent"]), (0, 0, None, []))

    def test_the_student_figures_and_how_each_homework_went(self):
        a, b = self.two()
        h = self.student(self.st["نورة"])["homework"]
        self.assertEqual((h["given"], h["done"], h["partial"], h["missing"], h["pending"], h["checked"], h["percent"]), (2, 1, 1, 0, 0, 2, 50))
        self.assertEqual([(x["id"], x["status"]) for x in h["recent"]], [(b["id"], "done"), (a["id"], "partial")])          # the latest given comes first
        top = h["recent"][0]
        self.assertEqual((top["title"], top["icon"], top["status_name"], top["subject"]), (b["title"], "📚", homework.STATUS_NAMES["done"], "العلوم"))
        self.assertEqual(top["due_text"], share.ar_date(self.day(3)))

    def test_a_homework_not_yet_checked_is_told_as_waiting_and_does_not_lower_the_share(self):
        a, b = self.two()
        h = self.student(self.st["ليان"])["homework"]
        self.assertEqual((h["given"], h["missing"], h["pending"], h["checked"], h["percent"]), (2, 1, 1, 1, 0))
        self.assertEqual({x["status"] for x in h["recent"]}, {"missing", "pending"})
        h = self.student(self.st["مها"])["homework"]
        self.assertEqual((h["given"], h["pending"], h["checked"], h["percent"]), (2, 2, 0, None))

    def test_a_student_is_only_counted_on_the_homework_she_was_given(self):
        a = self.make(self.w, students=[self.st["سارة"]])
        self.mark(a["id"], [(self.st["سارة"], "done")])
        self.assertEqual(self.student(self.st["سارة"])["homework"]["given"], 1)
        self.assertEqual(self.student(self.st["نورة"])["homework"]["given"], 0)

    def test_only_the_latest_are_listed_but_the_figures_count_all(self):
        n = 12
        for i in range(n):
            self.today += datetime.timedelta(days=1)
            a = self.make(self.w, due=None, title=f"واجب {i}")
            self.mark(a["id"], [(self.st["سارة"], "done")])
        h = self.student(self.st["سارة"])["homework"]
        self.assertEqual((h["given"], h["done"]), (n, n))
        self.assertEqual(len(h["recent"]), 8)
        self.assertEqual([x["title"] for x in h["recent"]][:3], ["واجب 11", "واجب 10", "واجب 9"])
        self.assertEqual(h["recent"][0]["due_text"], "")

    def test_two_given_on_the_same_day_list_the_newer_first(self):
        a, b = self.make(self.w), self.make(self.w)
        h = self.student(self.st["سارة"])["homework"]
        self.assertEqual([x["id"] for x in h["recent"]], [b["id"], a["id"]])

    def test_the_student_report_follows_subject_and_period(self):
        sci = self.make(self.w)
        maths = self.make_subject("الرياضيات")
        a = self.make(self.w, subject_id=maths)
        self.mark(sci["id"], [(self.st["سارة"], "done")])
        self.mark(a["id"], [(self.st["سارة"], "missing")])
        self.today += datetime.timedelta(days=1)
        late = self.make(self.w)
        self.mark(late["id"], [(self.st["سارة"], "partial")])
        sid = self.st["سارة"]
        self.assertEqual(self.student(sid)["homework"]["given"], 3)
        h = self.student(sid, subject_id=maths)["homework"]
        self.assertEqual((h["given"], h["missing"], [x["id"] for x in h["recent"]]), (1, 1, [a["id"]]))
        h = self.student(sid, period="today")["homework"]
        self.assertEqual((h["given"], h["partial"], [x["id"] for x in h["recent"]]), (1, 1, [late["id"]]))

    def test_a_student_removed_from_the_class_takes_his_homework_with_him(self):
        a = self.make(self.w)
        self.mark(a["id"], [(self.st["سارة"], "done")])
        self.assertEqual(self.api("delete", f"/api/students/{self.st['سارة']}").status_code, 200)
        self.assertEqual(self.report(self.w["cid"])["homework"]["done"], 0)
        self.assertEqual(self.c.get(f"/api/reports/student/{self.st['سارة']}").status_code, 404)

    # ---------------------------------------------------------------- the words for the parent, and the sheet
    def test_the_summary_tells_the_homework_only_when_some_was_checked(self):
        self.assertNotIn("الواجبات", self.student(self.st["سارة"])["text"])          # none given
        a, b = self.two()
        self.assertNotIn("الواجبات", self.student(self.st["مها"])["text"])           # given but not checked
        self.assertIn("الواجبات: أنجز 2 من 2", self.student(self.st["سارة"])["text"])
        self.assertIn("الواجبات: أنجز 1 من 2 · أنجز جزءًا 1", self.student(self.st["نورة"])["text"])
        self.assertIn("الواجبات: أنجز 0 من 1 · لم ينجز 1", self.student(self.st["ليان"])["text"])

    def test_each_part_of_the_summary_line_follows_its_own_figure(self):
        a, b = self.make(self.w), self.make(self.w, due=self.day(3))
        st = self.st
        self.mark(a["id"], [(st["سارة"], "done"), (st["نورة"], "missing"), (st["ليان"], "partial")])
        self.mark(b["id"], [(st["نورة"], "done"), (st["ليان"], "done")])          # (سارة is left unchecked in the second)
        line = lambda n: next(l for l in self.student(st[n])["text"].splitlines() if l.startswith("الواجبات"))
        self.assertEqual(line("سارة"), "الواجبات: أنجز 1 من 1")          # something waiting is not something she did not do
        self.assertEqual(line("نورة"), "الواجبات: أنجز 1 من 2 · لم ينجز 1")
        self.assertEqual(line("ليان"), "الواجبات: أنجز 1 من 2 · أنجز جزءًا 1")

    def test_the_summary_and_its_whatsapp_link_name_only_that_student(self):
        self.two()
        r = self.student(self.st["نورة"])
        for other in ("سارة", "ليان", "مها"):
            self.assertNotIn(other, r["text"])
        self.assertEqual(parse_qs(urlparse(r["wa"]).query)["text"][0], r["text"])

    def test_the_sheet_has_the_two_columns_only_when_homework_was_given(self):
        before = self.csv(self.w["cid"])          # (the first line names the class and the period, the second is the head of the table)
        self.assertEqual({len(r) for r in before[1:]}, {8})          # the head and every student's line: the eight columns of before
        self.assertNotIn("الواجبات المنجزة", before[1])
        self.two()
        rows = self.csv(self.w["cid"])
        self.assertEqual(rows[1][-2:], ["الواجبات المنجزة", "الواجبات المسجّلة"])
        by = {r[1]: r for r in rows[2:]}
        self.assertEqual(by["سارة"][-2:], ["2", "2"])
        self.assertEqual(by["نورة"][-2:], ["1", "2"])
        self.assertEqual(by["مها"][-2:], ["0", "0"])
        self.assertEqual({len(r) for r in rows[1:]}, {len(rows[1])})          # every row as wide as the head

    def test_the_sheet_of_a_subject_has_them_too_and_without_the_answers_columns(self):
        a = self.make(self.w)
        self.mark(a["id"], [(self.st["سارة"], "done")])
        rows = self.csv(self.w["cid"], subject_id=self.w["sid"])
        self.assertEqual(rows[1][-2:], ["الواجبات المنجزة", "الواجبات المسجّلة"])
        self.assertNotIn("الأسئلة", rows[1])
        self.assertEqual({r[1]: r for r in rows[2:]}["سارة"][-2:], ["1", "1"])

    # ---------------------------------------------------------------- walls
    def test_another_teachers_homework_never_enters_my_report(self):
        self.two()
        b = self.second_teacher()
        theirs = self.world(c=b, klass="الصف الأول أ", names=("ريم", "دانة"), subject="العلوم")
        x = self.make(theirs, c=b)
        self.mark(x["id"], [(theirs["students"]["ريم"], "done"), (theirs["students"]["دانة"], "done")], c=b)
        mine = self.report(self.w["cid"])["homework"]
        self.assertEqual((mine["given"], mine["done"]), (2, 3))
        t = self.report(theirs["cid"], c=b)["homework"]
        self.assertEqual((t["given"], t["done"]), (1, 2))
        self.assertEqual(self.student(theirs["students"]["ريم"], c=b)["homework"]["given"], 1)

    def test_nobody_reads_the_homework_figures_of_a_class_or_student_that_is_not_hers(self):
        self.two()
        b = self.second_teacher()
        for url in (f"/api/reports/class/{self.w['cid']}", f"/api/reports/class/{self.w['cid']}/csv", f"/api/reports/student/{self.st['سارة']}"):
            self.assertEqual(b.get(url).status_code, 404, url)
            self.assertEqual(self.client().get(url).status_code, 401, url)

    def test_asking_for_the_report_never_changes_the_homework(self):
        self.two()
        before = (self.tables(), self.rows("SELECT id, status, updated_at FROM assignment_students ORDER BY id"))
        self.report(self.w["cid"])
        self.student(self.st["سارة"])
        self.csv(self.w["cid"])
        self.assertEqual((self.tables(), self.rows("SELECT id, status, updated_at FROM assignment_students ORDER BY id")), before)

    def test_the_reports_page_script_shows_the_homework_figures(self):
        js = self.c.get("/static/js/reports.js").get_data(as_text=True)
        for needle in ("r.homework", "إنجاز الواجبات", "آخر الواجبات", "/homework/"):
            self.assertIn(needle, js)


class Upgrade(unittest.TestCase):
    def seed(self, db):
        db.execute("INSERT INTO users(id, email, name, pass_hash, created_at) VALUES (1, 'a@example.com', 'معلمة', 'x', 1)")
        db.execute("INSERT INTO classes(id, user_id, name, created_at) VALUES (1, 1, 'الصف الأول', 1)")
        db.execute("INSERT INTO students(id, user_id, class_id, name, created_at) VALUES (1, 1, 1, 'سارة', 1)")
        db.execute("INSERT INTO subjects(id, user_id, name, created_at) VALUES (1, 1, 'العلوم', 1)")
        db.execute("INSERT INTO results(user_id, student_id, deck_title, correct, created_at) VALUES (1, 1, 'عرض', 1, 1)")
        db.commit()

    def test_a_database_of_version_4_gets_the_two_tables_and_loses_nothing(self):
        with tempfile.TemporaryDirectory() as tmp:
            app = create_app(INSTANCE=tmp, BACKGROUND=False)
            db = app.db
            self.seed(db)
            for t in ("assignment_students", "assignments"):          # a database as version 4.x or 5.0 left it
                db.execute(f"DROP TABLE {t}")
            db.commit()
            self.assertEqual(db.execute("SELECT COUNT(*) FROM sqlite_master WHERE name LIKE 'assignment%'").fetchone()[0], 0)
            dbm.init(db)
            dbm.init(db)          # and again: nothing is added twice
            self.assertEqual(sorted(r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type = 'table' AND name LIKE 'assignment%'")), ["assignment_students", "assignments"])
            self.assertEqual([db.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in ("users", "classes", "students", "results", "subjects")], [1, 1, 1, 1, 1])
            db.close()

    def test_the_tables_refuse_what_makes_no_sense_and_follow_their_parents(self):
        with tempfile.TemporaryDirectory() as tmp:
            app = create_app(INSTANCE=tmp, BACKGROUND=False)
            db = app.db
            self.seed(db)
            ins = "INSERT INTO assignments(id, user_id, class_id, subject_id, kind, title, instructions, given_date, created_at, updated_at) VALUES (%s, 1, 1, 1, %s, 'ا', 'تعليمات', '2026-09-06', 1, 1)"
            with self.assertRaises(sqlite3.IntegrityError):
                db.execute(ins % ("1", "'quiz'"))
            db.execute(ins % ("1", "'homework'"))
            line = "INSERT INTO assignment_students(assignment_id, user_id, class_id, student_id, status, updated_at) VALUES (%s, 1, 1, 1, %s, 1)"
            with self.assertRaises(sqlite3.IntegrityError):
                db.execute(line % ("1", "'excellent'"))
            db.execute(line % ("1", "'pending'"))
            with self.assertRaises(sqlite3.IntegrityError):          # a student has one line per assignment
                db.execute(line % ("1", "'done'"))
            with self.assertRaises(sqlite3.IntegrityError):          # and the assignment must exist
                db.execute(line % ("77", "'done'"))
            with self.assertRaises(sqlite3.IntegrityError):          # closed is a yes or a no
                db.execute("UPDATE assignments SET closed = 2 WHERE id = 1")
            db.commit()
            db.execute("DELETE FROM subjects WHERE id = 1")
            self.assertIsNone(db.execute("SELECT subject_id FROM assignments WHERE id = 1").fetchone()[0])          # the homework stays without its subject
            db.execute("DELETE FROM students WHERE id = 1")
            self.assertEqual(db.execute("SELECT COUNT(*) FROM assignment_students").fetchone()[0], 0)
            db.execute("DELETE FROM classes WHERE id = 1")
            self.assertEqual(db.execute("SELECT COUNT(*) FROM assignments").fetchone()[0], 0)
            db.close()

    def test_deleting_the_teacher_takes_everything_of_hers(self):
        with tempfile.TemporaryDirectory() as tmp:
            app = create_app(INSTANCE=tmp, BACKGROUND=False)
            db = app.db
            self.seed(db)
            db.execute("INSERT INTO assignments(id, user_id, class_id, kind, title, instructions, given_date, created_at, updated_at) VALUES (1, 1, 1, 'homework', 'ا', 'تعليمات', '2026-09-06', 1, 1)")
            db.execute("INSERT INTO assignment_students(assignment_id, user_id, class_id, student_id, updated_at) VALUES (1, 1, 1, 1, 1)")
            db.commit()
            db.execute("DELETE FROM users WHERE id = 1")
            self.assertEqual([db.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in ("assignments", "assignment_students")], [0, 0])
            db.close()


if __name__ == "__main__":
    unittest.main()
