"""Version 5, phase 1: reading a list from Excel / Word / CSV, finding the names and the classes in it, importing them, subjects, the class's WhatsApp link,
the start screen, the teacher's notes and the home screen."""
import io
import re
import unittest
import zipfile
from urllib.parse import parse_qs, unquote, urlparse

from app import roster, share, tables
from tests import files5 as X
from tests import fixtures as F
from tests.test_app import Base


class ReadingFiles(unittest.TestCase):
    def test_excel_with_shared_strings_numbers_and_a_hidden_sheet(self):
        data = X.xlsx_bytes({"الأول": [["م", "الاسم"], [1, "أحمد"], [2, "سارة"]], "ثان": [["x"]]})
        sheets = tables.read_xlsx(data)
        self.assertEqual([s["name"] for s in sheets], ["الأول", "ثان"])
        self.assertEqual(sheets[0]["rows"], [["م", "الاسم"], ["1", "أحمد"], ["2", "سارة"]])
        # the numbers of identity cards stay whole numbers, not 1.09E+09
        big = tables.read_xlsx(X.xlsx_bytes({"s": [[1090000001, 2.5]]}))
        self.assertEqual(big[0]["rows"], [["1090000001", "2.5"]])

    def test_excel_cells_keep_their_columns_when_some_are_empty(self):
        rows = tables.read_xlsx(X.xlsx_bytes({"s": [["a", "", "c"], ["", "b", ""]]}))[0]["rows"]
        self.assertEqual(rows, [["a", "", "c"], ["", "b"]])

    def test_word_table_paragraphs_and_headings(self):
        blocks = tables.read_docx(X.roster_docx())
        kinds = [b[0] for b in blocks]
        self.assertEqual(kinds, ["p", "p", "table", "p", "table"])
        self.assertEqual(blocks[0][1:3], ("كشف أسماء الطلاب", 1))          # Title style = level 1
        self.assertEqual(blocks[1][1:3], ("الصف الأول أ", 1))
        self.assertEqual(blocks[2][1][0], ["م", "الاسم"])
        sheets = tables.docx_sheets(blocks)
        self.assertEqual([s["name"] for s in sheets], ["الصف الأول أ", "الصف الأول ب", ""])

    def test_csv_in_the_encodings_a_teacher_has(self):
        for enc in ("utf-8-sig", "utf-8", "cp1256", "utf-16"):
            for d in (",", ";", "\t"):
                rows = tables.read_csv(X.csv_bytes(enc, d))[0]["rows"]
                self.assertEqual(rows[0], ["الاسم", "الفصل"], (enc, d))
                self.assertEqual(len(rows), 6)

    def test_kind_is_decided_by_the_name_and_the_first_bytes(self):
        self.assertEqual(tables.kind_of("a.xlsx", b"PK\x03\x04..."), "xlsx")
        self.assertEqual(tables.kind_of("a.docx", b"PK\x03\x04..."), "docx")
        self.assertEqual(tables.kind_of("a.csv", b"a,b"), "csv")
        self.assertEqual(tables.kind_of("a.txt", "أحمد".encode()), "txt")
        self.assertEqual(tables.kind_of("a.pdf", b"%PDF-1.7"), "pdf")
        for name, head in (("a.xlsx", b"%PDF-1.7"), ("a.exe", b"MZ\x90"), ("a.docx", b"hello"), ("a.csv", b"a\x00b")):
            with self.assertRaises(tables.TableError, msg=name):
                tables.kind_of(name, head)
        with self.assertRaises(tables.TableError) as e:
            tables.kind_of("old.xls", b"\xd0\xcf\x11\xe0\xa1\xb1")
        self.assertIn("xlsx", str(e.exception))

    def test_a_file_that_is_not_what_it_says_is_a_sentence_not_a_crash(self):
        for kind, data in (("xlsx", b"PK\x03\x04 not really"), ("docx", b"PK\x03\x04 not really"), ("xlsx", X.docx_bytes("")), ("docx", X.xlsx_bytes({"s": [["a"]]}))):
            with self.assertRaises(tables.TableError, msg=kind):
                tables.read_sheets(kind, data)

    def test_a_zip_that_unpacks_into_a_flood_is_refused(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("xl/workbook.xml", "<workbook/>" + " " * (tables.MAX_PART + 10))
        with self.assertRaises(tables.TableError) as e:
            tables.read_xlsx(buf.getvalue())
        self.assertIn("كبير", str(e.exception))

    def test_xml_with_entities_is_refused(self):
        evil = '<?xml version="1.0"?><!DOCTYPE x [<!ENTITY a "aaaa">]><w:document xmlns:w="%s"><w:body><w:p><w:r><w:t>&a;</w:t></w:r></w:p></w:body></w:document>' % X.W
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            z.writestr("word/document.xml", evil)
        with self.assertRaises(tables.TableError):
            tables.read_docx(buf.getvalue())

    def test_real_files_written_by_libreoffice_are_read_too(self):
        html = "<html dir=rtl><body><p>الصف الأول أ</p><table><tr><td>م</td><td>الاسم</td></tr>" + "".join(f"<tr><td>{i + 1}</td><td>{n}</td></tr>" for i, n in enumerate(X.NAMES)) + "</table></body></html>"
        docx = X.soffice_convert(html, "docx")
        if docx is None:
            self.skipTest("LibreOffice is not installed")
        got = roster.from_sheets(tables.read_sheets("docx", docx))
        self.assertEqual([n for g in got for n in g["names"]], X.NAMES)


class FindingNames(unittest.TestCase):
    def names(self, rows, name=""):
        return roster.from_sheets([{"name": name, "rows": rows}])

    def test_a_heading_row_a_numbering_column_and_identity_numbers(self):
        got = tables.read_xlsx(X.roster_xlsx())
        g = roster.from_sheets(got)
        self.assertEqual(g, [{"class": "الصف الأول أ", "names": X.NAMES}])          # «المجموع» and the numbers are not names; the sheet's name is the class

    def test_without_a_heading_row_the_column_of_names_is_found(self):
        g = roster.from_sheets(tables.read_xlsx(X.roster_xlsx(with_header=False)))
        self.assertEqual(g[0]["names"], X.NAMES)

    def test_a_class_column_makes_one_group_for_each_class(self):
        g = roster.from_sheets(tables.read_csv(X.csv_bytes()))
        self.assertEqual([(x["class"], len(x["names"])) for x in g], [("الأول أ", 3), ("الأول ب", 2)])

    def test_two_tables_in_a_word_file_are_two_classes(self):
        g = roster.from_sheets(tables.read_sheets("docx", X.roster_docx()))
        self.assertEqual([(x["class"], x["names"]) for x in g], [("الصف الأول أ", X.NAMES), ("الصف الأول ب", X.NAMES2)])

    def test_lines_with_numbering_and_class_headings(self):
        g = roster.from_sheets(tables.read_sheets("docx", X.roster_docx_lines()))
        self.assertEqual([(x["class"], x["names"]) for x in g], [("الصف الثاني / ب", X.NAMES), ("الصف الثالث / ج", X.NAMES2)])

    def test_plain_text_one_name_a_line(self):
        text = "قائمة طلاب\n" + "\n".join(f"{i + 1}. {n} {1090000000 + i}" for i, n in enumerate(X.NAMES)) + "\n\nتوقيع المعلمة"
        g = roster.from_sheets(tables.read_sheets("txt", text.encode()))
        self.assertEqual(g, [{"class": "", "names": X.NAMES}])

    def test_headings_footers_numbers_and_sentences_are_not_names(self):
        for bad in ("الاسم", "المجموع", "ملاحظات", "12", "1090000001", "الفصل الدراسي الأول", "a@b.com", "x", "هذا نص طويل جدا لا يمكن ان يكون اسما لطالب في اي فصل ابدا نهائيا"):
            self.assertFalse(roster.is_name(bad), bad)
        for good in ("أحمد", "عبدالله بن سعد", "Sara Ali", "ريم", "منى"):
            self.assertTrue(roster.is_name(good), good)

    def test_one_name_twice_is_one_name_and_spelling_variants_match(self):
        g = self.names([["الاسم"], ["أحمد علي"], ["احمد علي"], ["سارة"], ["سارة "]])
        self.assertEqual(g[0]["names"], ["أحمد علي", "سارة"])

    def test_a_sheet_with_no_names_gives_nothing(self):
        self.assertEqual(self.names([["12", "34"], ["56", "78"]]), [])
        self.assertEqual(roster.from_sheets([]), [])

    def test_the_most_names_one_file_can_give(self):
        rows = [["الاسم"]] + [[f"طالب {chr(0x621 + i % 26)}{chr(0x621 + i // 26 % 26)}{chr(0x621 + i // 676)}"] for i in range(900)]
        got = self.names(rows)
        self.assertLessEqual(sum(len(g["names"]) for g in got), roster.MAX_NAMES)


def link_text(url):
    return parse_qs(urlparse(url).query)["text"][0]


class WhatsAppLinks(unittest.TestCase):
    def test_the_group_link_is_cleaned_or_refused(self):
        ok = "https://chat.whatsapp.com/ABCDEFGHIJ1234567890"
        self.assertEqual(share.clean_group_link(ok), ok)
        self.assertEqual(share.clean_group_link("  " + ok + "?utm_source=x  "), ok)
        self.assertEqual(share.clean_group_link("http://chat.whatsapp.com/ABCDEFGHIJ1234567890"), ok)
        self.assertEqual(share.clean_group_link("chat.whatsapp.com/ABCDEFGHIJ1234567890"), ok)
        self.assertEqual(share.clean_group_link("انضمي لمجموعة الصف الأول: " + ok + " شكرًا"), ok)          # a whole invitation message was pasted
        self.assertEqual(share.clean_group_link(""), "")
        self.assertEqual(share.clean_group_link("   "), "")
        for bad in ("hello", "https://example.com/chat.whatsapp.com/ABCDEFGHIJ", "https://chat.whatsapp.com.evil.com/ABCDEFGHIJ12345", "https://chat.whatsapp.com/x", "javascript:alert(1)", "https://evil.com/?https://chat.whatsapp.com/ABCDEFGHIJ1234"):
            self.assertIsNone(share.clean_group_link(bad), bad)

    def test_a_message_link_carries_the_text_exactly(self):
        text = "*واجب العلوم* — الصف الأول\nالتعليمات: حلّي ص 12 & 13\n100% 🙂"
        url = share.wa_text_url(text)
        self.assertTrue(url.startswith("https://wa.me/?text="))
        self.assertEqual(unquote(url.split("text=", 1)[1]), text)
        self.assertNotIn("\n", url)

    def test_the_date_in_arabic(self):
        self.assertEqual(share.ar_date("2026-11-08"), "الأحد 8 نوفمبر 2026")
        self.assertEqual(share.ar_date("2026-02-28"), "السبت 28 فبراير 2026")
        self.assertEqual(share.ar_date("nope"), "")


class Phase1(Base):
    def setUp(self):
        super().setUp()
        from app import students
        students.import_limit.hits.clear()
        self.c = self.client()
        self.register(self.c)

    def j_(self, method, url, data=None, c=None):
        return self.j(c or self.c, method, url, data)

    def up(self, name, data, c=None):
        c = c or self.c
        return c.post("/api/students/import", data={"file": (io.BytesIO(data), name)}, headers={"X-CSRF": self.token(c)}, content_type="multipart/form-data")

    def classes(self, c=None):
        return (c or self.c).get("/api/classes").get_json()["classes"]

    # -------------------------------------------------------- importing a list
    def test_the_preview_proposes_and_saves_nothing(self):
        r = self.up("ثالث.xlsx", X.roster_xlsx())
        self.assertEqual(r.status_code, 200)
        d = r.get_json()
        self.assertEqual(d["kind"], "xlsx")
        self.assertEqual([(g["label"], g["names"], g["class_id"]) for g in d["groups"]], [("الصف الأول أ", X.NAMES, None)])
        self.assertEqual(self.classes(), [])
        self.assertEqual(self.c.get("/api/students").get_json()["students"], [])

    def test_confirming_makes_the_classes_and_the_students(self):
        d = self.up("w.docx", X.roster_docx()).get_json()
        groups = [{"class_id": None, "class_name": g["label"], "names": g["names"]} for g in d["groups"]]
        r = self.j_("post", "/api/students/import/confirm", {"groups": groups})
        self.assertEqual(r.status_code, 201)
        out = r.get_json()
        self.assertEqual((out["added"], out["classes_made"], out["skipped"]), (8, 2, 0))
        by_class = {c["name"]: c["count"] for c in out["classes"]}
        self.assertEqual(by_class, {"الصف الأول أ": 5, "الصف الأول ب": 3})
        # the second time the same list is recognised: the classes are matched and the names are marked as already there
        again = self.up("w.docx", X.roster_docx()).get_json()
        self.assertTrue(all(g["class_id"] for g in again["groups"]))
        self.assertEqual([len(g["already"]) for g in again["groups"]], [5, 3])
        r2 = self.j_("post", "/api/students/import/confirm", {"groups": [{"class_id": g["class_id"], "names": g["names"]} for g in again["groups"]]})
        self.assertEqual((r2.get_json()["added"], r2.get_json()["skipped"]), (0, 8))

    def test_names_can_be_put_into_an_existing_class_and_edited_first(self):
        cid = self.j_("post", "/api/classes", {"name": "ثالث"}).get_json()["id"]
        r = self.j_("post", "/api/students/import/confirm", {"groups": [{"class_id": cid, "names": ["  أحمد   علي ", "x", "سارة"]}]})
        self.assertEqual((r.get_json()["added"], r.get_json()["skipped"]), (2, 1))
        self.assertEqual(sorted(s["name"] for s in self.c.get("/api/students?class_id=%d" % cid).get_json()["students"]), ["أحمد علي", "سارة"])

    def test_a_name_with_no_class_goes_to_the_first_class(self):
        r = self.j_("post", "/api/students/import/confirm", {"groups": [{"names": ["أحمد علي"]}]})
        self.assertEqual(r.status_code, 201)
        self.assertEqual([c["name"] for c in self.classes()], ["الفصل الأول"])

    def test_every_kind_of_file_the_spec_names(self):
        for name, data, kind in (("a.xlsx", X.roster_xlsx(), "xlsx"), ("a.docx", X.roster_docx_lines(), "docx"), ("a.csv", X.csv_bytes(), "csv"),
                                 ("a.txt", "\n".join(X.NAMES).encode(), "txt")):
            d = self.up(name, data).get_json()
            self.assertEqual(d["kind"], kind)
            self.assertTrue(d["groups"], name)

    def test_a_pdf_list(self):
        pdf = F.pdf_bytes(lines=[f"{i + 1}. {n}" for i, n in enumerate(X.NAMES)], title="قائمة طلاب الصف الأول أ")
        d = self.up("list.pdf", pdf).get_json()
        self.assertEqual(d["kind"], "pdf")
        found = [n for g in d["groups"] for n in g["names"]]
        self.assertEqual(found, X.NAMES)
        self.assertEqual(d["groups"][0]["label"], "الصف الأول أ")

    def test_a_picture_of_a_list(self):
        from app import extract
        try:
            import pytesseract
            if "eng" not in pytesseract.get_languages():
                raise OSError
        except Exception:
            self.skipTest("Tesseract is not installed")
        png = F.png_bytes("1. Ahmed Ali\n2. Sara Omar\n3. Noura Khaled")
        r = self.up("list.png", png)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        found = " ".join(n for g in r.get_json()["groups"] for n in g["names"]).lower()
        for want in ("ahmed", "sara", "noura"):
            self.assertIn(want, found)

    def test_refusals_come_as_sentences(self):
        self.assertEqual(self.up("a.xls", b"\xd0\xcf\x11\xe0 old").status_code, 400)
        self.assertIn("xlsx", self.up("a.xls", b"\xd0\xcf\x11\xe0 old").get_json()["error"])
        self.assertEqual(self.up("a.exe", b"MZ....").status_code, 400)
        self.assertEqual(self.up("a.csv", b"").status_code, 400)
        r = self.up("a.csv", "12,34\n56,78".encode())
        self.assertEqual(r.status_code, 400)
        self.assertIn("لم نجد أسماء", r.get_json()["error"])
        self.assertEqual(self.c.post("/api/students/import", data={}, headers={"X-CSRF": self.token(self.c)}, content_type="multipart/form-data").status_code, 400)

    def test_a_too_big_file_is_refused(self):
        from app import students
        big = b"a" * (students.MAX_IMPORT_MB * 1024 * 1024 + 5)
        r = self.up("a.txt", big)
        self.assertEqual(r.status_code, 400)
        self.assertIn("كبير", r.get_json()["error"])

    def test_upload_rate_limit(self):
        from app import students
        for _ in range(30):
            self.up("a.txt", "أحمد علي".encode())
        self.assertEqual(self.up("a.txt", "أحمد علي".encode()).status_code, 429)
        students.import_limit.hits.clear()

    def test_signed_out_and_without_the_check_token(self):
        anon = self.client()
        r = anon.post("/api/students/import", data={"file": (io.BytesIO(b"x"), "a.txt")}, content_type="multipart/form-data", headers={"X-CSRF": self.token(anon)})
        self.assertEqual(r.status_code, 401)
        r = self.c.post("/api/students/import", data={"file": (io.BytesIO(b"x"), "a.txt")}, content_type="multipart/form-data")
        self.assertEqual(r.status_code, 403)

    def test_confirm_is_all_or_nothing(self):
        from app import students
        old = students.MAX_STUDENTS
        students.MAX_STUDENTS = 3
        try:
            r = self.j_("post", "/api/students/import/confirm", {"groups": [{"class_name": "أ", "names": ["أحمد علي", "سارة علي"]}, {"class_name": "ب", "names": ["نورة علي", "ريم علي"]}]})
        finally:
            students.MAX_STUDENTS = old
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.classes(), [])
        self.assertEqual(self.c.get("/api/students").get_json()["students"], [])

    def test_confirm_refuses_nonsense(self):
        for bad in ({}, {"groups": []}, {"groups": "x"}, {"groups": [1]}, {"groups": [{"names": "x"}]}):
            self.assertEqual(self.j_("post", "/api/students/import/confirm", bad).status_code, 400, bad)

    def test_another_teachers_class_cannot_be_written_to(self):
        other = self.client()
        self.register(other, "b@example.com")
        theirs = self.j_("post", "/api/classes", {"name": "سرّي"}, c=other).get_json()["id"]
        r = self.j_("post", "/api/students/import/confirm", {"groups": [{"class_id": theirs, "names": ["أحمد علي"]}]})
        self.assertEqual(r.status_code, 404)
        self.assertEqual(other.get("/api/students").get_json()["students"], [])
        # and a class name that equals theirs is simply her own new class
        r = self.j_("post", "/api/students/import/confirm", {"groups": [{"class_name": "سرّي", "names": ["أحمد علي"]}]})
        self.assertEqual(r.get_json()["classes_made"], 1)
        self.assertEqual(other.get("/api/students").get_json()["students"], [])

    def test_the_preview_only_matches_her_own_classes(self):
        other = self.client()
        self.register(other, "b@example.com")
        self.j_("post", "/api/classes", {"name": "الصف الأول أ"}, c=other)
        d = self.up("a.xlsx", X.roster_xlsx()).get_json()
        self.assertIsNone(d["groups"][0]["class_id"])

    # -------------------------------------------------------- the class's WhatsApp group
    def test_whatsapp_link_of_a_class(self):
        cid = self.j_("post", "/api/classes", {"name": "الأول"}).get_json()["id"]
        link = "https://chat.whatsapp.com/ABCDEFGHIJ1234567890"
        r = self.j_("patch", f"/api/classes/{cid}", {"whatsapp": f"  {link}?mode=r_c "})
        self.assertEqual((r.status_code, r.get_json()["whatsapp"]), (200, link))
        self.assertEqual(self.classes()[0]["whatsapp"], link)
        self.assertEqual(self.classes()[0]["name"], "الأول")          # saving the link does not touch the name
        self.assertEqual(self.j_("patch", f"/api/classes/{cid}", {"whatsapp": "https://evil.example.com/x"}).status_code, 400)
        self.assertEqual(self.classes()[0]["whatsapp"], link)
        self.assertEqual(self.j_("patch", f"/api/classes/{cid}", {"whatsapp": ""}).get_json()["whatsapp"], "")          # she may remove it: the feature is optional
        self.assertEqual(self.classes()[0]["whatsapp"], "")
        self.assertEqual(self.j_("patch", f"/api/classes/{cid}", {"name": "الأول (أ)"}).status_code, 200)          # renaming still works
        self.assertEqual(self.j_("patch", f"/api/classes/{cid}", {"name": "x"}).status_code, 400)
        self.assertEqual(self.j_("patch", f"/api/classes/{cid}", {}).status_code, 400)

    def test_the_whatsapp_link_is_hers_alone(self):
        cid = self.j_("post", "/api/classes", {"name": "الأول"}).get_json()["id"]
        other = self.client()
        self.register(other, "b@example.com")
        self.assertEqual(self.j_("patch", f"/api/classes/{cid}", {"whatsapp": "https://chat.whatsapp.com/ABCDEFGHIJ1234567890"}, c=other).status_code, 404)
        self.assertEqual(other.get("/api/classes").get_json()["classes"], [])

    # -------------------------------------------------------- subjects
    def test_subjects_and_their_classes(self):
        a = self.j_("post", "/api/classes", {"name": "أول"}).get_json()["id"]
        b = self.j_("post", "/api/classes", {"name": "ثاني"}).get_json()["id"]
        sci = self.j_("post", "/api/subjects", {"name": "العلوم"}).get_json()["id"]
        mat = self.j_("post", "/api/subjects", {"name": "الرياضيات"}).get_json()["id"]
        self.assertEqual(self.j_("post", "/api/subjects", {"name": "العلوم"}).status_code, 409)
        self.assertEqual(self.j_("post", "/api/subjects", {"name": "ع"}).status_code, 400)
        r = self.j_("put", f"/api/classes/{a}/subjects", {"subject_ids": [sci, mat]})
        self.assertEqual(r.status_code, 200)
        self.j_("put", f"/api/classes/{b}/subjects", {"subject_ids": [sci]})
        cl = {c["name"]: [s["name"] for s in c["subjects"]] for c in self.classes()}
        self.assertEqual(cl, {"أول": ["الرياضيات", "العلوم"], "ثاني": ["العلوم"]})
        subs = {s["name"]: sorted(s["classes"]) for s in self.c.get("/api/subjects").get_json()["subjects"]}
        self.assertEqual(subs, {"العلوم": sorted([a, b]), "الرياضيات": [a]})
        self.j_("put", f"/api/classes/{a}/subjects", {"subject_ids": [mat]})          # the list replaces the links of that class only
        cl = {c["name"]: [s["name"] for s in c["subjects"]] for c in self.classes()}
        self.assertEqual(cl, {"أول": ["الرياضيات"], "ثاني": ["العلوم"]})
        self.assertEqual(self.j_("patch", f"/api/subjects/{sci}", {"name": "علوم الحياة"}).status_code, 200)
        self.assertEqual(self.j_("patch", f"/api/subjects/{sci}", {"name": "الرياضيات"}).status_code, 409)
        self.assertEqual(self.j_("delete", f"/api/subjects/{sci}").status_code, 200)
        self.assertEqual({c["name"]: [s["name"] for s in c["subjects"]] for c in self.classes()}, {"أول": ["الرياضيات"], "ثاني": []})
        self.assertEqual(self.c.get("/api/students").get_json()["classes"][0]["name"], "أول")          # classes and students are untouched

    def test_subjects_are_hers_alone(self):
        sci = self.j_("post", "/api/subjects", {"name": "العلوم"}).get_json()["id"]
        other = self.client()
        self.register(other, "b@example.com")
        cid = self.j_("post", "/api/classes", {"name": "ثاني"}, c=other).get_json()["id"]
        self.assertEqual(other.get("/api/subjects").get_json()["subjects"], [])
        self.assertEqual(self.j_("put", f"/api/classes/{cid}/subjects", {"subject_ids": [sci]}, c=other).status_code, 404)
        self.assertEqual(self.j_("patch", f"/api/subjects/{sci}", {"name": "x y"}, c=other).status_code, 404)
        self.assertEqual(self.j_("delete", f"/api/subjects/{sci}", c=other).status_code, 404)
        self.assertEqual(len(self.c.get("/api/subjects").get_json()["subjects"]), 1)
        # the same name is allowed for another teacher
        self.assertEqual(self.j_("post", "/api/subjects", {"name": "العلوم"}, c=other).status_code, 201)

    def test_deleting_a_class_unlinks_its_subjects_only(self):
        a = self.j_("post", "/api/classes", {"name": "أول"}).get_json()["id"]
        sci = self.j_("post", "/api/subjects", {"name": "العلوم"}).get_json()["id"]
        self.j_("put", f"/api/classes/{a}/subjects", {"subject_ids": [sci]})
        self.j_("delete", f"/api/classes/{a}")
        self.assertEqual(len(self.c.get("/api/subjects").get_json()["subjects"]), 1)
        self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM class_subjects").fetchone()[0], 0)

    def test_the_most_subjects(self):
        from app import classroom
        for i in range(classroom.MAX_SUBJECTS):
            self.assertEqual(self.j_("post", "/api/subjects", {"name": f"مادة {i + 10}"}).status_code, 201)
        self.assertEqual(self.j_("post", "/api/subjects", {"name": "مادة زائدة"}).status_code, 400)

    # -------------------------------------------------------- starting a lesson
    def lesson(self, c=None):
        c = c or self.c
        r = self.upload(c, "cell.pptx", F.pptx_bytes())
        return int(re.search(r"/lessons/(\d+)", r.headers["Location"]).group(1))

    def test_the_start_screen_has_her_classes_subjects_and_ready_lessons(self):
        lid = self.lesson()
        cid = self.j_("post", "/api/classes", {"name": "أول"}).get_json()["id"]
        sid = self.j_("post", "/api/subjects", {"name": "العلوم"}).get_json()["id"]
        self.j_("put", f"/api/classes/{cid}/subjects", {"subject_ids": [sid]})
        page = self.c.get("/start")
        self.assertEqual(page.status_code, 200)
        self.assertEqual(page.headers["Cache-Control"], "no-store")
        d = self.c.get("/api/start").get_json()
        self.assertEqual([c["name"] for c in d["classes"]], ["أول"])
        self.assertEqual([s["name"] for s in d["subjects"]], ["العلوم"])
        self.assertEqual([x["id"] for x in d["lessons"]], [lid])
        self.assertGreater(d["lessons"][0]["questions"], 0)

    def test_the_start_screen_shows_only_her_own(self):
        self.lesson()
        other = self.client()
        self.register(other, "b@example.com")
        d = other.get("/api/start").get_json()
        self.assertEqual((d["classes"], d["lessons"], d["subjects"]), ([], [], []))

    def test_start_screen_needs_a_sign_in(self):
        anon = self.client()
        self.assertEqual(anon.get("/start").status_code, 302)
        self.assertEqual(anon.get("/api/start").status_code, 401)

    def test_the_choices_reach_the_stage(self):
        lid = self.lesson()
        r = self.c.get(f"/lessons/{lid}/today?class=7&size=xl&inline=0")
        loc = r.headers["Location"]
        self.assertTrue(re.match(r"/present/\d+\?", loc), loc)
        q = parse_qs(urlparse(loc).query)
        self.assertEqual((q["game"], q["class"], q["size"], q["inline"]), (["today"], ["7"], ["xl"], ["0"]))
        loc2 = self.c.get(f"/lessons/{lid}/today?class=abc&size=huge&inline=2&evil=1").headers["Location"]          # anything else is dropped
        self.assertEqual(parse_qs(urlparse(loc2).query), {"game": ["today"]})
        self.assertEqual(self.c.get(f"/lessons/{lid}/today").headers["Location"].split("?")[1], "game=today")

    def test_the_stage_page_has_the_focus_button_and_the_bar_buttons(self):
        lid = self.lesson()
        deck = re.search(r"/present/(\d+)", self.c.get(f"/lessons/{lid}/today").headers["Location"]).group(1)
        html = self.c.get(f"/present/{deck}").get_data(as_text=True)
        for ident in ("b-focus", "b-unfocus", "b-full", "b-exit", "b-today", "b-menu", "b-pause", "b-score"):
            self.assertIn(f'id="{ident}"', html)

    # -------------------------------------------------------- the teacher's notes
    def test_the_notes_page_and_message(self):
        lid = self.lesson()
        self.assertEqual(self.c.get(f"/lessons/{lid}/notes").status_code, 200)
        d = self.c.get(f"/api/lessons/{lid}/notes").get_json()
        self.assertTrue(d["parts"])
        self.assertIn(d["title"], d["message"])
        self.assertEqual(link_text(d["wa"]), d["message"])
        for p in d["parts"]:
            self.assertIn(p["title"], d["message"])
            for x in p["points"]:
                self.assertIn(x, d["message"])
        self.assertTrue(d["wa"].startswith("https://wa.me/?text="))

    def test_notes_are_hers_alone(self):
        lid = self.lesson()
        other = self.client()
        self.register(other, "b@example.com")
        self.assertEqual(other.get(f"/lessons/{lid}/notes").status_code, 404)
        self.assertEqual(other.get(f"/api/lessons/{lid}/notes").status_code, 404)
        self.assertEqual(self.client().get(f"/lessons/{lid}/notes").status_code, 302)

    # -------------------------------------------------------- the home screen
    def test_the_home_screen_has_the_date_the_start_card_and_the_set_up_cards(self):
        from app import classroom
        html = self.c.get("/dashboard").get_data(as_text=True)
        self.assertIn("اليوم: " + share.ar_date(classroom.today_date().isoformat()), html)
        self.assertIn('class="hub-card h-start"', html)
        self.assertIn("ابدئي بتجهيز بياناتك", html)
        self.assertIn("تحميل قوائم أسماء الطلاب", html)
        self.j_("post", "/api/students", {"names": ["أحمد علي"]})
        html = self.c.get("/dashboard").get_data(as_text=True)
        self.assertTrue('class="setup-card done"' in html or "ابدئي بتجهيز بياناتك" not in html)          # done, or every step done and the whole block gone

    def test_the_dashboard_still_has_everything_it_had(self):
        self.lesson()
        html = self.c.get("/dashboard").get_data(as_text=True)
        for needle in ("رفع درس جديد", "دروسي", "عروضي", "الخصوصية وحسابي", "ابدئي حصة اليوم", "حذف حسابي"):
            self.assertIn(needle, html)


if __name__ == "__main__":
    unittest.main()
