"""Signing up and signing in with a mobile number or an e-mail (version 4.2): whichever the teacher writes, however she writes it, with no code sent and nothing verified.
The old way (an e-mail and a password) must go on working exactly as before, and the manager's pages must show a number where there is no address."""
import os
import re
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock
from urllib.parse import urlencode

from app import api, auth, billing, create_app, db as dbm, identity
from tests import fixtures as F
from tests.test_app import Base

ROOT = Path(__file__).resolve().parent.parent
NUMBER = "0501234567"
PHONE = "966501234567"
PW = "Teacher-pass-1"


class PhoneForms(unittest.TestCase):
    def test_every_way_of_writing_one_number_is_the_same_number(self):
        for how in ("0501234567", "501234567", "966501234567", "+966501234567", "+966 50 123 4567", "00966501234567", "٠٥٠١٢٣٤٥٦٧", "۰۵۰۱۲۳۴۵۶۷",
                    "05-0123-4567", " 050 123 4567 ", "(050) 123.4567", "+966 0501234567", "‎+966 50 123 4567‏", "+٩٦٦ ٥٠ ١٢٣ ٤٥٦٧"):
            self.assertEqual(identity.normalize_phone(how), PHONE, how)

    def test_what_is_not_a_mobile_number(self):
        for bad in ("", "   ", None, "abc", "12345", "050123456", "05012345678", "5012345678", "0112345678", "+966112345678", "966112345678",
                    "0201001234567", "01001234567", "+0501234567", "+", "00", "0501234567x", "05O1234567", "+966 5012 3456 78"):
            self.assertIsNone(identity.normalize_phone(bad), repr(bad))

    def test_another_country_needs_its_plus(self):
        self.assertEqual(identity.normalize_phone("+20 100 123 4567"), "201001234567")
        self.assertEqual(identity.normalize_phone("0020 100 123 4567"), "201001234567")
        self.assertEqual(identity.normalize_phone("+1 (202) 555-0147"), "12025550147")
        self.assertIsNone(identity.normalize_phone("201001234567"))            # without a + it could be anything
        self.assertIsNone(identity.normalize_phone("+123456"))                 # too short to be a number

    def test_classify_an_email_or_a_number(self):
        self.assertEqual(identity.classify(" A@Example.COM "), ("email", "a@example.com"))
        self.assertEqual(identity.classify(NUMBER), ("phone", PHONE))
        for bad in ("a@b", "@example.com", "a b@example.com", "nope", "", None, "966501234567@phone.invalid", "x@phone.invalid"):
            self.assertEqual(identity.classify(bad), (None, ""), repr(bad))

    def test_the_number_is_shown_the_way_people_write_it(self):
        self.assertEqual(identity.local_phone(PHONE), NUMBER)
        self.assertEqual(identity.local_phone("201001234567"), "+201001234567")
        self.assertEqual(identity.local_phone(None), "")
        self.assertEqual(identity.contact({"email": "t@example.com", "phone": None}), "t@example.com")
        self.assertEqual(identity.contact({"email": PHONE + identity.PLACEHOLDER, "phone": PHONE}), NUMBER)
        self.assertEqual(identity.contact({"email": "t@example.com"}), "t@example.com")                # a row without the column at all
        self.assertEqual(identity.contact({"email": PHONE + identity.PLACEHOLDER, "phone": None}), "")  # never the made-up address

    def test_what_a_search_for_a_number_looks_for(self):
        for q, want in (("0501234567", "501234567"), ("+966 50 123 4567", "501234567"), ("00966501234567", "501234567"), ("966501234567", "501234567"),
                        ("4567", "4567"), ("٠٥٠١", "501"), ("05", ""), ("12", ""), ("ahmad", ""), ("a@example.com", ""), ("LP-1001", ""), ("", ""), (None, "")):
            self.assertEqual(identity.search_digits(q), want, repr(q))


class Sign(Base):
    def setUp(self):
        super().setUp()
        api.delete_limit.hits.clear()                              # counted per user number, and every test starts with user number 1

    def join(self, c, who, name="معلمة", pw=PW, field="identifier"):
        auth.register_limit.hits.clear()
        auth.register_day_limit.hits.clear()                      # one test address signs up many times
        return c.post("/register", data={"_csrf": self.token(c), field: who, "name": name, "password": pw, "password2": pw, "terms": "1"})

    def enter(self, c, who, pw=PW, field="identifier"):
        return c.post("/login", data={"_csrf": self.token(c), field: who, "password": pw})

    def users(self):
        return self.app.db.execute("SELECT * FROM users ORDER BY id").fetchall()

    @staticmethod
    def note(r):
        m = re.search(r'<p class="note bad"[^>]*>(.*?)</p>', r.get_data(as_text=True), re.S)
        return m.group(1).strip() if m else ""


class SignUpAndIn(Sign):
    def test_sign_up_with_a_mobile_number_then_sign_in_with_every_way_of_writing_it(self):
        c = self.client()
        r = self.join(c, NUMBER)
        self.assertEqual((r.status_code, r.headers["Location"]), (302, "/dashboard"))
        self.assertEqual(c.get("/dashboard").status_code, 200)
        (row,) = self.users()
        self.assertEqual(row["phone"], PHONE)
        self.assertEqual(row["email"], PHONE + identity.PLACEHOLDER)
        self.assertNotIn(PW, row["pass_hash"])
        for how in ("0501234567", "501234567", "966501234567", "+966501234567", "+966 50 123 4567", "00966501234567", "٠٥٠١٢٣٤٥٦٧", "05-0123-4567", " 050 123 4567 "):
            c2 = self.client()
            r = self.enter(c2, how)
            self.assertEqual((r.status_code, r.headers["Location"]), (302, "/dashboard"), how)
            self.assertEqual(c2.get("/dashboard").status_code, 200, how)

    def test_sign_up_with_an_email_works_as_before_with_either_field_name(self):
        c1, c2 = self.client(), self.client()
        self.assertEqual(self.join(c1, "One@Example.com", field="email").status_code, 302)           # the name the older form used
        self.assertEqual(self.join(c2, "two@example.com", field="identifier").status_code, 302)
        rows = self.users()
        self.assertEqual([(r["email"], r["phone"]) for r in rows], [("one@example.com", None), ("two@example.com", None)])
        for who, field in (("ONE@example.com", "email"), ("one@example.com", "identifier"), ("Two@Example.com", "identifier")):
            r = self.enter(self.client(), who, field=field)
            self.assertEqual((r.status_code, r.headers["Location"]), (302, "/dashboard"), who)

    def test_the_old_register_helper_still_works(self):
        c = self.client()
        self.assertEqual(self.register(c).status_code, 302)           # tests/test_app.Base.register posts «email»
        self.assertEqual(self.enter(self.client(), "a@example.com", field="email").status_code, 302)

    def test_the_same_number_or_email_twice_is_refused(self):
        self.assertEqual(self.join(self.client(), NUMBER).status_code, 302)
        for again in ("+966 50 123 4567", "966501234567", "٠٥٠١٢٣٤٥٦٧"):
            r = self.join(self.client(), again)
            self.assertEqual(r.status_code, 400, again)
            self.assertIn("هذا الرقم مسجل من قبل", r.get_data(as_text=True))
        self.assertEqual(self.join(self.client(), "x@example.com").status_code, 302)
        r = self.join(self.client(), "X@EXAMPLE.com")
        self.assertEqual(r.status_code, 400)
        self.assertIn("هذا البريد مسجل من قبل", r.get_data(as_text=True))
        self.assertEqual(len(self.users()), 2)

    def test_wrong_password_unknown_number_and_unknown_email_get_the_same_answer(self):
        self.join(self.client(), NUMBER)
        self.join(self.client(), "x@example.com")
        answers = []
        for who, pw in ((NUMBER, "wrong-pass-9"), ("0551112222", PW), ("nobody@example.com", PW), ("x@example.com", "wrong-pass-9"), ("junk", PW), ("966501234567@phone.invalid", PW)):
            r = self.enter(self.client(), who, pw=pw)
            self.assertEqual(r.status_code, 400, who)
            answers.append(self.note(r))
        self.assertEqual(len(set(answers)), 1, answers)
        self.assertIn("رقم الجوال أو البريد أو كلمة المرور غير صحيحة", answers[0])
        self.assertIn("البريد أو كلمة المرور غير صحيحة", answers[0])

    def test_a_made_up_address_cannot_be_used_to_sign_up_or_in(self):
        self.join(self.client(), NUMBER)
        r = self.join(self.client(), PHONE + identity.PLACEHOLDER)
        self.assertEqual(r.status_code, 400)
        self.assertIn("بريدًا إلكترونيًا صحيحًا", r.get_data(as_text=True))
        self.assertEqual(self.enter(self.client(), PHONE + identity.PLACEHOLDER).status_code, 400)       # right password, wrong door
        self.assertEqual(len(self.users()), 1)

    def test_the_box_takes_a_number_so_it_is_not_an_email_box(self):
        for path in ("/register", "/login"):
            html = self.client().get(path).get_data(as_text=True)
            box = re.search(r'<input name="identifier"[^>]*>', html).group(0)
            self.assertIn('type="text"', box)
            self.assertNotIn('type="email"', html)
            self.assertIn('autocomplete="username"', box)
            self.assertIn('dir="ltr"', box)
            self.assertIn("رقم الجوال أو البريد الإلكتروني", html)
        self.assertIn("اكتبي أحدهما فقط", self.client().get("/register").get_data(as_text=True))
        self.assertNotIn("اكتبي أحدهما فقط", self.client().get("/login").get_data(as_text=True))

    def test_what_was_typed_comes_back_when_something_is_wrong(self):
        r = self.join(self.client(), "050 123 4567", name="x")
        self.assertEqual(r.status_code, 400)
        html = r.get_data(as_text=True)
        self.assertIn('value="050 123 4567"', html)
        r = self.enter(self.client(), "050 123 4567", pw="wrong-pass-9")
        self.assertIn('value="050 123 4567"', r.get_data(as_text=True))

    def test_tries_are_counted_per_number_however_it_is_written(self):
        self.join(self.client(), NUMBER)
        auth.login_limit.hits.clear()
        spellings = ["0501234567", "+966501234567", "966501234567", "501234567", "٠٥٠١٢٣٤٥٦٧", "00966501234567", "05 0123 4567", "+966 50 123 4567"]
        for how in spellings:
            self.assertEqual(self.enter(self.client(), how, pw="wrong-pass-9").status_code, 400, how)
        r = self.enter(self.client(), "0501234567", pw=PW)                 # even the right password waits: the limit is on the number
        self.assertEqual(r.status_code, 429)
        self.assertEqual(self.enter(self.client(), "x@example.com", pw=PW).status_code, 400)       # another person is not held up by it

    def test_the_messages_for_what_is_not_a_number_or_an_email(self):
        base = dict(name="معلمة")
        r = self.join(self.client(), "a@b", **base)
        self.assertEqual(r.status_code, 400)
        self.assertIn("بريدًا إلكترونيًا صحيحًا", r.get_data(as_text=True))
        for bad in ("12345", "0112345678", "+966112345678", "nope", ""):
            r = self.join(self.client(), bad, **base)
            self.assertEqual(r.status_code, 400, bad)
            self.assertIn("رقم جوال صحيحًا", r.get_data(as_text=True))
        r = self.join(self.client(), NUMBER, name="x")
        self.assertIn("اسمك", r.get_data(as_text=True))
        r = self.join(self.client(), NUMBER, pw="short")
        self.assertIn("8 خانات", r.get_data(as_text=True))
        self.assertEqual(self.users(), [])

    def test_a_number_taken_a_moment_ago_is_a_message_not_a_crash(self):
        self.app.db.execute("INSERT INTO users(email, phone, name, pass_hash, created_at) VALUES (?,?,?,?,1)", (PHONE + identity.PLACEHOLDER, PHONE, "s", "h"))
        self.app.db.commit()
        with mock.patch.object(auth, "_taken", return_value=False):            # the check found nothing, then somebody else was faster
            r = self.join(self.client(), NUMBER)
        self.assertEqual(r.status_code, 400)
        self.assertIn("هذا الرقم مسجل من قبل", r.get_data(as_text=True))
        self.assertEqual(len(self.users()), 1)

    def test_closed_registration_closes_it_for_numbers_too(self):
        dbm.put_setting(self.app.db, "registrations_open", "0")
        r = self.join(self.client(), NUMBER)
        self.assertEqual(r.status_code, 400)
        self.assertIn(auth.CLOSED, r.get_data(as_text=True))
        self.assertEqual(self.users(), [])


class ATeacherWithANumber(Sign):
    def test_she_uses_the_whole_app(self):
        c = self.client()
        self.join(c, NUMBER)
        r = self.upload(c, "cell.pptx", F.pptx_bytes())
        lid = int(re.search(r"/lessons/(\d+)", r.headers["Location"]).group(1))
        self.assertEqual(c.get(f"/lessons/{lid}").status_code, 200)
        self.assertIn("1 من 3 دروس", c.get("/dashboard").get_data(as_text=True))

    def test_deleting_her_account_frees_the_number(self):
        c = self.client()
        self.join(c, NUMBER)
        self.assertEqual(self.j(c, "post", "/api/me/delete", {"password": "wrong-pass-9"}).status_code, 400)
        self.assertEqual(self.j(c, "post", "/api/me/delete", {"password": PW}).status_code, 200)
        self.assertEqual(self.users(), [])
        self.assertEqual(self.join(self.client(), NUMBER).status_code, 302)            # she can come back with the same number

    def test_signing_in_does_not_reveal_whether_a_number_exists_by_timing_or_path(self):
        self.join(self.client(), NUMBER)
        with mock.patch.object(auth, "check_password_hash", wraps=auth.check_password_hash) as chk:
            self.enter(self.client(), "0551112222", pw=PW)           # nobody has it
            self.enter(self.client(), NUMBER, pw="wrong-pass-9")     # somebody has it
        self.assertEqual(chk.call_count, 2)                            # the same hashing work in both cases


class ManagerPages(Sign):
    def setUp(self):
        super().setUp()
        self.boss = self.client()
        self.join(self.boss, "boss@example.com", name="المدير")
        self.app.db.execute("UPDATE users SET is_admin = 1 WHERE email = 'boss@example.com'")
        self.app.db.commit()
        self.by_phone = self.client()
        self.join(self.by_phone, NUMBER, name="سارة")
        self.by_mail = self.client()
        self.join(self.by_mail, "noura@example.com", name="نورة")
        self.uid_phone = self.app.db.execute("SELECT id FROM users WHERE phone = ?", (PHONE,)).fetchone()[0]
        self.uid_mail = self.app.db.execute("SELECT id FROM users WHERE email = 'noura@example.com'").fetchone()[0]
        for uid in (self.uid_phone, self.uid_mail):
            self.app.db.execute("INSERT INTO subscription_requests(user_id, plan_code, period, amount, created_at) VALUES (?,?,?,?,?)", (uid, "monthly", "month", 2900, 1_800_000_000))
        billing.grant_plan(self.app.db, self.uid_phone, "monthly", 5)             # about to end: she is in the «ends soon» list of the overview
        self.app.db.commit()

    def page(self, path):
        r = self.boss.get(path)
        self.assertEqual(r.status_code, 200, path)
        return r.get_data(as_text=True)

    def test_the_pages_show_the_number_where_there_is_no_address(self):
        for path in ("/admin", "/admin/subscriptions", f"/admin/subscriptions/{self.uid_phone}", "/admin/subscriptions?st=active", "/admin/subscriptions?st=free"):
            html = self.page(path)
            self.assertNotIn("phone.invalid", html, path)
        self.assertIn(NUMBER, self.page("/admin/subscriptions"))
        self.assertIn(NUMBER, self.page(f"/admin/subscriptions/{self.uid_phone}"))
        self.assertIn("noura@example.com", self.page("/admin/subscriptions"))
        self.assertIn(NUMBER, self.page("/admin"))                                  # the request waiting for a decision, and the plan that is about to end

    @staticmethod
    def listed(html, uid):
        """Is this person in the results? (the search box always shows an example name, so the person is recognised by her own link)"""
        return f'href="/admin/subscriptions/{uid}"' in html

    def test_search_finds_a_person_by_number_in_any_form_and_by_email_as_before(self):
        for q in ("0501234567", "+966 50 123 4567", "966501234567", "٠٥٠١٢٣٤٥٦٧", "4567", "501234", "سارة"):
            html = self.page("/admin/subscriptions?" + urlencode({"q": q}))
            self.assertTrue(self.listed(html, self.uid_phone), q)
            self.assertFalse(self.listed(html, self.uid_mail), q)
        for q in ("noura@example.com", "noura", "نورة"):
            html = self.page("/admin/subscriptions?" + urlencode({"q": q}))
            self.assertTrue(self.listed(html, self.uid_mail), q)
            self.assertFalse(self.listed(html, self.uid_phone), q)
        html = self.page("/admin/subscriptions?" + urlencode({"q": "0559999999"}))
        self.assertFalse(self.listed(html, self.uid_phone) or self.listed(html, self.uid_mail))

    def test_the_paid_reader_log_takes_a_number_too(self):
        self.app.db.execute("INSERT INTO ai_usage(user_id, lesson_id, model, input_tokens, output_tokens, cost, created_at) VALUES (?, NULL, 'probe-model', 10, 5, 3, ?)", (self.uid_phone, time.time()))
        self.app.db.execute("INSERT INTO ai_usage(user_id, lesson_id, model, input_tokens, output_tokens, cost, created_at) VALUES (?, NULL, 'other-model', 10, 5, 3, ?)", (self.uid_mail, time.time()))
        self.app.db.commit()
        for q, mine in (("0501234567", True), ("+966 50 123 4567", True), ("4567", True), ("0551112222", False), ("", True)):
            html = self.page("/admin/ai?" + urlencode({"q": q, "m": "all"}))
            self.assertEqual("probe-model" in html, mine, q)
        html = self.page("/admin/ai?" + urlencode({"q": "noura@example.com", "m": "all"}))
        self.assertIn("other-model", html)
        self.assertNotIn("probe-model", html)
        self.assertNotIn("phone.invalid", self.page("/admin/ai?m=all"))
        self.page("/admin/subscriptions?q=50")            # too short to be looked up as a number: it is only searched as text

    def test_a_number_that_belongs_to_nobody_finds_nobody(self):
        html = self.page("/admin/subscriptions?q=0551112222")
        self.assertFalse(self.listed(html, self.uid_phone))
        self.assertFalse(self.listed(html, self.uid_mail))


class OldDatabase(unittest.TestCase):
    def test_a_database_made_before_the_phone_column_gets_it_and_loses_nothing(self):
        with tempfile.TemporaryDirectory() as tmp:
            app = create_app(INSTANCE=tmp, BACKGROUND=False)
            db = app.db
            db.execute("INSERT INTO users(email, name, pass_hash, created_at) VALUES ('old@example.com', 'قديمة', 'h', 5)")
            db.commit()
            db.execute("DROP INDEX users_phone")
            db.execute("ALTER TABLE users DROP COLUMN phone")                       # what a database of the earlier version looks like
            db.commit()
            self.assertNotIn("phone", [r[1] for r in db.execute("PRAGMA table_info(users)")])
            dbm.init(db)
            dbm.init(db)                                                            # and again: nothing more happens
            self.assertIn("phone", [r[1] for r in db.execute("PRAGMA table_info(users)")])
            self.assertEqual([tuple(r) for r in db.execute("SELECT email, phone, name, created_at FROM users")], [("old@example.com", None, "قديمة", 5.0)])
            for other in ("x@example.com", "y@example.com"):                        # many accounts without a number are fine
                db.execute("INSERT INTO users(email, name, pass_hash, created_at) VALUES (?, 'n', 'h', 1)", (other,))
            db.execute("INSERT INTO users(email, phone, name, pass_hash, created_at) VALUES ('p@x.co', '966500000001', 'n', 'h', 1)")
            with self.assertRaises(sqlite3.IntegrityError):                         # but one number is one account
                db.execute("INSERT INTO users(email, phone, name, pass_hash, created_at) VALUES ('q@x.co', '966500000001', 'n', 'h', 1)")
            db.rollback()
            db.close()

    def test_an_old_teacher_still_signs_in_with_her_email(self):
        with tempfile.TemporaryDirectory() as tmp:
            app = create_app(INSTANCE=tmp, BACKGROUND=False)
            from werkzeug.security import generate_password_hash
            app.db.execute("INSERT INTO users(email, name, pass_hash, created_at) VALUES ('old@example.com', 'قديمة', ?, 5)", (generate_password_hash(PW),))
            app.db.commit()
            auth.login_limit.hits.clear()
            c = app.test_client()
            t = re.search(r'name="csrf" content="([^"]+)"', c.get("/login").get_data(as_text=True)).group(1)
            r = c.post("/login", data={"_csrf": t, "email": "Old@Example.com", "password": PW})           # the field name and the case of the old form
            self.assertEqual((r.status_code, r.headers["Location"]), (302, "/dashboard"))
            app.db.close()


class Manage(unittest.TestCase):
    def run_manage(self, tmp, *args):
        env = {**os.environ, "INSTANCE_DIR": tmp}
        return subprocess.run([sys.executable, "-W", "ignore", "manage.py", *args], cwd=ROOT, env=env, capture_output=True, text=True, timeout=120)

    def test_a_teacher_is_named_by_email_or_by_number(self):
        with tempfile.TemporaryDirectory() as tmp:
            app = create_app(INSTANCE=tmp, BACKGROUND=False)
            app.db.execute("INSERT INTO users(email, phone, name, pass_hash, created_at) VALUES (?,?,?,?,1)", (PHONE + identity.PLACEHOLDER, PHONE, "س", "h"))
            app.db.execute("INSERT INTO users(email, name, pass_hash, created_at) VALUES ('m@example.com', 'م', 'h', 1)")
            app.db.commit()
            for args in (("make-admin", "+966 50 123 4567"), ("set-plan", "0501234567", "monthly"), ("set-plan", "M@Example.com", "yearly")):
                r = self.run_manage(tmp, *args)
                self.assertEqual((r.returncode, r.stdout.strip()), (0, "done"), (args, r.stdout, r.stderr))
            rows = {r["email"]: (r["is_admin"], r["plan_code"]) for r in app.db.execute("SELECT * FROM users")}
            self.assertEqual(rows, {PHONE + identity.PLACEHOLDER: (1, "monthly"), "m@example.com": (0, "yearly")})
            self.assertEqual(self.run_manage(tmp, "make-admin", "0551112222").stdout.strip(), "no such user")
            r = self.run_manage(tmp, "make-admin", "not a number")
            self.assertNotEqual(r.returncode, 0)
            self.assertIn("mobile number", r.stderr)
            app.db.close()


if __name__ == "__main__":
    unittest.main()
