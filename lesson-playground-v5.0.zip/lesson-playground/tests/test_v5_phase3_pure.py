"""Version 5, phase 3 (the parts that need no server): lessons taught together, and the lessons keeping their place in the row of periods when the periods change."""
import datetime
import unittest

from app import planner

D = datetime.date
START = D(2026, 9, 6)          # a Sunday


def occs(n, slots=((0, 1),), first=None):
    return planner.occurrences(list(slots), START, START + datetime.timedelta(days=7 * n + 7), first=first)[:n]


def item(i, periods=1, status="pending", together=None, kind="lesson"):
    return {"id": i, "periods": periods, "status": status, "together": together, "kind": kind}


def days(plan):
    return {k: (v[0].day.isoformat(), v[1].day.isoformat()) for k, v in plan.items()}


class Together(unittest.TestCase):
    def test_a_lesson_taught_with_the_one_before_it_is_its_follower(self):
        self.assertEqual(planner.merged([item(1), item(2, together=1), item(3)]), {2: 1})

    def test_a_link_that_cannot_hold_is_ignored_and_the_lesson_is_an_ordinary_one(self):
        self.assertEqual(planner.merged([item(1, status="done"), item(2, together=1)]), {})          # the first was already taught
        self.assertEqual(planner.merged([item(1, status="skipped"), item(2, together=1)]), {})
        self.assertEqual(planner.merged([item(1, together=2), item(2)]), {})          # the partner must come before it
        self.assertEqual(planner.merged([item(1), item(2, together=1, status="skipped")]), {})
        self.assertEqual(planner.merged([item(1), item(2, together=1), item(3, together=2)]), {2: 1})          # a follower leads nobody
        self.assertEqual(planner.merged([item(1), item(2, together=99)]), {})

    def test_the_follower_takes_no_period_of_its_own(self):
        items = [item(1), item(2, together=1), item(3)]
        together = planner.merged(items)
        self.assertEqual([planner.periods_of(i, together) for i in items], [1, 0, 1])
        self.assertEqual(planner.periods_of(item(4, periods=3), {}), 3)
        self.assertEqual(planner.periods_of(item(5, periods=0), {}), 1)

    def test_the_two_lessons_share_the_periods_and_the_next_one_gains_a_period(self):
        plan, unplaced = planner.assign([item(1), item(2, together=1), item(3)], occs(4))
        self.assertEqual(unplaced, 0)
        self.assertEqual(plan[1], plan[2])
        self.assertEqual(days(plan), {1: ("2026-09-06", "2026-09-06"), 2: ("2026-09-06", "2026-09-06"), 3: ("2026-09-13", "2026-09-13")})

    def test_two_lessons_that_need_two_periods_each_share_the_leaders_two(self):
        plan, _ = planner.assign([item(1, periods=2), item(2, periods=2, together=1), item(3)], occs(5))
        self.assertEqual(days(plan), {1: ("2026-09-06", "2026-09-13"), 2: ("2026-09-06", "2026-09-13"), 3: ("2026-09-20", "2026-09-20")})

    def test_a_follower_does_not_count_as_a_lesson_that_does_not_fit(self):
        plan, unplaced = planner.assign([item(1), item(2, together=1), item(3)], occs(1))
        self.assertEqual(set(plan), {1, 2})
        self.assertEqual(unplaced, 1)          # only the third lesson is left without a period
        plan, unplaced = planner.assign([item(1), item(2, together=1)], [])
        self.assertEqual((plan, unplaced), ({}, 1))          # nothing is left for the leader, so nothing for the follower, and the follower adds nothing to the shortage

    def test_the_day_a_follower_is_due_is_the_day_its_partner_is_due(self):
        due = planner.baseline([item(1), item(2, together=1), item(3)], occs(4))
        self.assertEqual({k: v.day.isoformat() for k, v in due.items()}, {1: "2026-09-06", 2: "2026-09-06", 3: "2026-09-13"})

    def test_the_summary_counts_the_periods_the_lessons_really_take(self):
        items = [item(1, status="done"), item(2), item(3, together=2), item(4)]
        s = planner.summary(items, occs(2), D(2026, 9, 6))
        self.assertEqual((s["lessons"], s["pending"], s["periods_total"], s["periods_done"], s["periods_needed"], s["spare"]), (4, 3, 3, 1, 2, 0))
        self.assertEqual(s["percent"], 33)
        self.assertEqual(s["current"], 2)

    def test_lessons_already_taught_together_are_not_offered_to_be_merged_again(self):
        items = [item(i) for i in range(1, 6)]
        items[2]["together"] = 2
        self.assertEqual(planner.merge_ideas(items, 3, {1: 5, 2: 1, 3: 1, 4: 1, 5: 1}), [(4, 5)])

    def test_a_review_or_an_exam_is_never_offered_to_be_merged(self):
        items = [item(1), item(2, kind="review"), item(3), item(4, kind="exam"), item(5)]
        self.assertEqual(planner.merge_ideas(items, 2), [])


class KeepingTheirPlace(unittest.TestCase):
    """shift_due: the lesson due in the Nth period from today is due in the Nth period from today after the change."""
    TODAY = START

    def line(self, **kw):
        return planner.occurrences([(0, 1), (2, 2)], START, D(2026, 12, 17), first=self.TODAY, **kw)

    def keys(self, os):
        return [(o.day, o.period) for o in os]

    def test_a_day_off_pushes_every_due_day_to_the_next_period_that_is_left(self):
        before = self.line()
        after = self.line(absent={(D(2026, 9, 6), None)})
        dues = self.keys(before[:4])
        moved = planner.shift_due(dues, before, after, self.TODAY)
        self.assertEqual(moved, self.keys(after[:4]))
        self.assertEqual(moved[0], (D(2026, 9, 8), 2))
        self.assertEqual(moved[3], (D(2026, 9, 20), 1))

    def test_a_day_given_back_pulls_the_due_days_earlier(self):
        before = self.line(holidays={D(2026, 9, 8)})
        after = self.line()
        dues = self.keys(before[:3])
        self.assertEqual(dues[1], (D(2026, 9, 13), 1))
        self.assertEqual(planner.shift_due(dues, before, after, self.TODAY)[:3], self.keys(after[:3]))

    def test_a_lesson_already_late_stays_late(self):
        today = D(2026, 9, 20)
        before = planner.occurrences([(0, 1), (2, 2)], START, D(2026, 12, 17), first=today)
        after = planner.occurrences([(0, 1), (2, 2)], START, D(2026, 12, 17), absent={(D(2026, 9, 20), None)}, first=today)
        late = (D(2026, 9, 13), 1)
        soon = (D(2026, 9, 20), 1)
        self.assertEqual(planner.shift_due([late, soon], before, after, today), [late, (D(2026, 9, 22), 2)])

    def test_a_lesson_that_no_period_is_left_for_has_no_due_day(self):
        before = planner.occurrences([(0, 1)], START, D(2026, 9, 20), first=self.TODAY)
        after = planner.occurrences([(0, 1)], START, D(2026, 9, 20), absent={(D(2026, 9, 6), None)}, first=self.TODAY)
        dues = self.keys(before)
        self.assertEqual(len(before), 3)
        self.assertEqual(planner.shift_due(dues, before, after, self.TODAY), [(D(2026, 9, 13), 1), (D(2026, 9, 20), 1), None])

    def test_a_due_day_beyond_the_periods_known_is_left_as_it_was(self):
        before = self.line()[:2]
        after = self.line(absent={(D(2026, 9, 6), None)})[:2]
        far = (D(2027, 1, 1), 1)
        self.assertEqual(planner.shift_due([far, None], before, after, self.TODAY), [far, None])

    def test_the_same_periods_change_nothing(self):
        line = self.line()
        dues = self.keys(line[:5])
        self.assertEqual(planner.shift_due(dues, line, list(line), self.TODAY), dues)

    def test_a_period_moved_in_the_timetable_carries_its_lesson_with_it(self):
        before = planner.occurrences([(0, 1)], START, D(2026, 12, 17), first=self.TODAY)
        after = planner.occurrences([(0, 3)], START, D(2026, 12, 17), first=self.TODAY)
        moved = planner.shift_due(self.keys(before[:2]), before, after, self.TODAY)
        self.assertEqual(moved, [(D(2026, 9, 6), 3), (D(2026, 9, 13), 3)])


if __name__ == "__main__":
    unittest.main()
