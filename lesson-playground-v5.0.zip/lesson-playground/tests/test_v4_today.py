"""Version 4: «حصة اليوم» and the four activities. The explanation cut into parts from the teacher's own file, a quick question after a part, questions for
the students by name, the lesson's own deck (made by the app, not counted against her), the direct links, the stage's scripts, and the results of the new games."""
import json
import re
import shutil
import subprocess
import unittest
from pathlib import Path

from app import grounding as G
from app import today
from app.lessons import GAMES, PRIMARY
from tests import fixtures as F
from tests.test_app import Base

ROOT = Path(__file__).resolve().parent.parent

STRUCTURED = """مادة الأحياء
الصف الثاني المتوسط

أجزاء الخلية
الخلية هي الوحدة الأساسية للحياة في جميع الكائنات الحية.
النواة: مركز التحكم في الخلية وتحتوي على المادة الوراثية.
• تقوم الميتوكوندريا بإنتاج الطاقة للخلية لأن عملية التنفس الخلوي تحدث داخلها.
• الغشاء الخلوي ينظم دخول المواد وخروجها من الخلية الحية.

الخلية النباتية
تحتوي الخلية النباتية على جدار خلوي يحمي الخلية ويعطيها شكلها الثابت.
البلاستيدات الخضراء تحتوي على الكلوروفيل الذي يمتص ضوء الشمس لصنع الغذاء.
الخلايا الحيوانية لا تحتوي على جدار خلوي ولا على بلاستيدات خضراء في تركيبها.

تابع
الريبوسومات تصنع البروتينات التي تحتاجها الخلية للنمو والإصلاح.
الريبوسومات تصنع البروتينات التي تحتاجها الخلية للنمو والإصلاح.
اسم المعلمة: نورة
صفحة 3
"""
PLANETS = ["عطارد", "الزهرة", "الأرض", "المريخ", "المشتري", "زحل", "أورانوس", "نبتون", "القمر", "الشمس", "المذنبات", "الكويكبات", "الأقمار", "النجوم", "المجرات"]


def q(i, kind, question, answer, evidence="", options=(), clear=True):
    return {"id": i, "kind": kind, "question": question, "answer": answer, "options": list(options), "evidence": evidence, "clear": clear}


class PartsTests(unittest.TestCase):
    def test_headings_become_titles_and_sentences_become_the_points(self):
        parts = today.parts_of(STRUCTURED)
        self.assertEqual([p["title"] for p in parts], ["أجزاء الخلية", "الخلية النباتية", "الخلية النباتية (تابع)"])
        self.assertEqual(len(parts[0]["points"]), 4)
        self.assertEqual(parts[0]["points"][2], "تقوم الميتوكوندريا بإنتاج الطاقة للخلية لأن عملية التنفس الخلوي تحدث داخلها")        # the bullet sign is gone
        self.assertEqual([p["id"] for p in parts], [1, 2, 3])

    def test_the_covers_footers_and_subject_and_grade_never_appear(self):
        shown = json.dumps(today.parts_of(STRUCTURED), ensure_ascii=False)
        for gone in ("مادة الأحياء", "الصف الثاني", "المتوسط", "اسم المعلمة", "صفحة 3"):
            self.assertNotIn(gone, shown)

    def test_the_same_sentence_is_explained_once(self):
        sentence = "الريبوسومات تصنع البروتينات"
        self.assertEqual(sum(p["points"].count(s) for p in today.parts_of(STRUCTURED) for s in p["points"] if s.startswith(sentence)), 1)

    def test_a_definition_is_a_term_of_its_part(self):
        terms = {t["term"]: t["def"] for t in today.parts_of(STRUCTURED)[0]["terms"]}
        self.assertEqual(terms["النواة"], "مركز التحكم في الخلية وتحتوي على المادة الوراثية")
        self.assertIn("الخلية", terms)

    def test_a_continued_heading_takes_the_title_before_it(self):
        self.assertEqual(today.parts_of(STRUCTURED)[-1]["title"], "الخلية النباتية (تابع)")

    def test_a_long_run_is_cut_at_sentence_ends_into_parts_a_class_can_follow(self):
        text = "\n".join(f"{p} جرم سماوي له مدار خاص به وحركة منتظمة حول مركزه كل يوم" for p in PLANETS)
        parts = today.parts_of(text)
        self.assertGreater(len(parts), 1)
        for p in parts:
            self.assertLessEqual(len(p["points"]), today.MAX_POINTS)
            self.assertLessEqual(p["words"], today.MAX_WORDS + 15)
        self.assertEqual(sum(len(p["points"]) for p in parts), len(PLANETS))                    # nothing is lost between the parts
        self.assertEqual(len({p["title"] for p in parts}), len(parts), "two parts share one title")

    def test_a_file_without_headings_still_gives_titled_parts(self):
        parts = today.parts_of("\n".join(f"{p} من الأجرام التي ندرسها في هذا الدرس بالتفصيل" for p in PLANETS[:4]))
        self.assertTrue(parts)
        self.assertTrue(all(p["title"] and p["points"] for p in parts))

    def test_no_text_gives_no_parts(self):
        self.assertEqual(today.parts_of(""), [])
        self.assertEqual(today.parts_of("صفحة 1\n\n\n   \n"), [])


class BuildTests(unittest.TestCase):
    def questions(self):
        from app import aiq, create_app
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            app = create_app(INSTANCE=tmp, BACKGROUND=False)
            try:
                _, items, _ = aiq.make_questions(app.cfg, STRUCTURED, False)
            finally:
                app.db.close()
        return [{**{k: it.get(k) for k in ("kind", "question", "answer", "options", "evidence")}, "id": i, "clear": True} for i, it in enumerate(items, 1)]

    def test_a_quick_question_sits_in_the_part_that_holds_its_sentence(self):
        qs = self.questions()
        res = today.build("الخلية", STRUCTURED, qs)
        self.assertGreaterEqual(res["counts"]["checks"], 2)
        parts = today.parts_of(STRUCTURED)
        for p in res["parts"]:
            body = G.norm(" ".join(next(x for x in parts if x["id"] == p["id"])["points"]))
            for c in p["checks"]:
                self.assertIn(G.norm(c["evidence"]), body)
                self.assertNotEqual(c["kind"], "review")                    # a middle-of-the-lesson question is a light one

    def test_one_sentence_is_asked_once_in_the_whole_lesson(self):
        res = today.build("الخلية", STRUCTURED, self.questions())
        seen = [G.norm(c["evidence"]) for p in res["parts"] for c in p["checks"]] + [G.norm(a["q"]["evidence"]) for a in res["participation"]]
        self.assertEqual(len(seen), len(set(seen)), "a sentence is asked about twice")

    def test_the_participation_is_short_varied_and_in_the_order_of_the_lesson(self):
        res = today.build("الخلية", STRUCTURED, self.questions())
        ask = res["participation"]
        self.assertTrue(3 <= len(ask) <= today.MAX_ASK)
        kinds = [a["q"]["kind"] for a in ask]
        self.assertTrue(all(kinds.count(k) <= 3 for k in set(kinds)))
        self.assertEqual([a["part"] for a in ask], sorted(a["part"] for a in ask))
        self.assertTrue(all(a["part_title"] for a in ask))

    def test_an_answer_is_never_left_out_and_no_unclear_question_is_a_check(self):
        res = today.build("الخلية", STRUCTURED, self.questions())
        every = [c for p in res["parts"] for c in p["checks"]] + [a["q"] for a in res["participation"]]
        self.assertTrue(all(x["answer"] for x in every))
        self.assertEqual(res["counts"], {"parts": 3, "checks": sum(len(p["checks"]) for p in res["parts"]), "participation": len(res["participation"]), "questions": len(self.questions())})

    def test_without_questions_the_explanation_is_still_there(self):
        res = today.build("الخلية", STRUCTURED, [])
        self.assertEqual(res["counts"]["parts"], 3)
        self.assertEqual((res["counts"]["checks"], res["counts"]["participation"]), (0, 0))

    def test_questions_without_text_are_still_asked(self):
        qs = [q(1, "qa", "ما وظيفة النواة؟", "مركز التحكم"), q(2, "qa", "ما وظيفة الغشاء؟", "ينظم المواد"), q(3, "tf", "الخلية وحدة الحياة", "صح"), q(4, "cloze", "النواة _____ الخلية", "تتحكم")]
        res = today.build("درس", "", qs)
        self.assertEqual(res["parts"], [])
        self.assertEqual(len(res["participation"]), 4)
        self.assertTrue(all(a["part_title"] == "من أسئلتك" for a in res["participation"]))

    def test_a_sentence_asked_in_three_shapes_is_still_asked_when_there_are_too_few_questions(self):
        qs = [q(1, "qa", "ما المقصود بـ «النواة»؟", "مركز التحكم", "النواة: مركز التحكم في الخلية"), q(2, "review", "اذكري ما تعرفينه عن «النواة»", "مركز التحكم", "النواة: مركز التحكم في الخلية")]
        res = today.build("درس", "", qs)
        self.assertEqual(len(res["participation"]), 2)                      # not strict: two questions are better than one


class CoverTests(unittest.TestCase):
    def test_a_class_line_with_the_article_is_the_files_cover_and_leaves_the_text(self):
        from app import meta
        for line in ("الصف الثاني المتوسط", "للصف الثالث الثانوي", "بالصف الخامس", "الصف الأول"):
            text, found = meta.split_header(line + "\nالنواة هي مركز التحكم في الخلية وتحتوي على المادة الوراثية")
            self.assertNotIn("الصف", text, line)
            self.assertEqual(found.get("grade"), line)
        self.assertEqual(meta.strip_mentions("تتكون الخلية من النواة في الصف الثاني المتوسط عادة"), "تتكون الخلية من النواة عادة")
        self.assertFalse(meta.mentions("وصف الخلية بالتفصيل"))                     # «وصف» (a description) is not «صف» (a class)


class Lessons(Base):
    def setUp(self):
        super().setUp()
        self.t, self.lid = self.teacher_with_lesson()
        self.db = self.app.db

    def title(self):
        return self.db.execute("SELECT title FROM lessons WHERE id = ?", (self.lid,)).fetchone()[0]

    def deck_of(self, lid=None):
        return self.db.execute("SELECT * FROM decks WHERE lesson_id = ? AND auto = 1", (lid or self.lid,)).fetchall()

    def location(self, r):
        return r.headers["Location"]


class RouteTests(Lessons):
    def test_today_opens_the_lessons_own_deck_and_a_second_visit_reuses_it(self):
        r = self.t.get(f"/lessons/{self.lid}/today")
        self.assertEqual(r.status_code, 302)
        m = re.fullmatch(r"/present/(\d+)\?game=today", self.location(r))
        self.assertTrue(m, self.location(r))
        deck = self.deck_of()[0]
        self.assertEqual(deck["id"], int(m.group(1)))
        lesson = self.db.execute("SELECT * FROM lessons WHERE id = ?", (self.lid,)).fetchone()
        self.assertEqual(deck["title"], lesson["title"])
        self.assertEqual(json.loads(deck["games"]), list(GAMES))
        usable = [r["id"] for r in self.db.execute("SELECT id FROM questions WHERE lesson_id = ? AND (clear = 1 OR manual = 1) ORDER BY position, id", (self.lid,))]
        self.assertTrue(usable)
        self.assertEqual(json.loads(deck["question_ids"]), usable)
        self.t.get(f"/lessons/{self.lid}/today")
        self.t.get(f"/lessons/{self.lid}/play/quiz")
        self.assertEqual(len(self.deck_of()), 1)

    def test_every_activity_has_a_direct_link_and_a_wrong_one_is_not_found(self):
        for key in GAMES:
            r = self.t.get(f"/lessons/{self.lid}/play/{key}")
            self.assertEqual(r.status_code, 302, key)
            self.assertRegex(self.location(r), rf"^/present/\d+\?game={key}$")
        self.assertEqual(self.t.get(f"/lessons/{self.lid}/play/nothing").status_code, 404)
        self.assertEqual(self.t.get(f"/lessons/{self.lid}/play/..%2Fadmin").status_code, 404)

    def test_the_lesson_deck_is_not_one_of_her_decks(self):
        self.t.get(f"/lessons/{self.lid}/today")
        page = self.t.get("/dashboard").get_data(as_text=True)
        deck = self.deck_of()[0]
        self.assertNotIn(f"/api/decks/{deck['id']}", page)                                  # not in «عروضي»
        for i in range(5):                                                                  # the free plan's five decks are all still hers
            r = self.j(self.t, "post", f"/api/lessons/{self.lid}/decks", {"games": ["qa"], "question_ids": [x["id"] for x in self.db.execute("SELECT id FROM questions WHERE lesson_id = ? AND kind IN ('qa','short','review')", (self.lid,))], "title": f"عرض {i}"})
            self.assertEqual(r.status_code, 201, r.get_json())
        self.assertEqual(self.j(self.t, "post", f"/api/lessons/{self.lid}/decks", {"games": ["qa"], "question_ids": [1], "title": "السادس"}).status_code, 403)

    def test_the_deck_follows_her_edits(self):
        self.t.get(f"/lessons/{self.lid}/today")
        r = self.j(self.t, "post", f"/api/lessons/{self.lid}/questions", {"kind": "qa", "question": "ما وظيفة النواة؟", "answer": "مركز التحكم في الخلية"})
        new_id = r.get_json()["question"]["id"]
        self.t.get(f"/lessons/{self.lid}/play/qa")
        self.assertIn(new_id, json.loads(self.deck_of()[0]["question_ids"]))
        gone = json.loads(self.deck_of()[0]["question_ids"])[0]
        self.j(self.t, "delete", f"/api/questions/{gone}")
        self.t.get(f"/lessons/{self.lid}/today")
        self.assertNotIn(gone, json.loads(self.deck_of()[0]["question_ids"]))
        self.j(self.t, "patch", f"/api/lessons/{self.lid}", {"title": "عنوان جديد للدرس"})
        self.t.get(f"/lessons/{self.lid}/today")
        self.assertEqual(self.deck_of()[0]["title"], "عنوان جديد للدرس")

    def test_a_lesson_that_is_not_ready_goes_back_to_its_page(self):
        self.db.execute("UPDATE lessons SET status = 'processing' WHERE id = ?", (self.lid,))
        self.db.commit()
        for url in (f"/lessons/{self.lid}/today", f"/lessons/{self.lid}/play/quiz"):
            r = self.t.get(url)
            self.assertEqual((r.status_code, self.location(r)), (302, f"/lessons/{self.lid}"))
        self.assertEqual(self.deck_of(), [])

    def test_another_teacher_and_a_visitor_get_nothing(self):
        other = self.client()
        self.register(other, "b@example.com", "معلمة أخرى")
        for url in (f"/lessons/{self.lid}/today", f"/lessons/{self.lid}/play/pick", f"/api/lessons/{self.lid}/today"):
            self.assertEqual(other.get(url).status_code, 404, url)
            r = self.client().get(url)
            if url.startswith("/api/"):
                self.assertEqual(r.status_code, 401, url)
            else:
                self.assertEqual(r.status_code, 302, url)
                self.assertIn("/login", r.headers["Location"])
        self.assertEqual(self.deck_of(), [])

    def test_the_data_for_the_stage(self):
        d = self.t.get(f"/api/lessons/{self.lid}/today").get_json()
        self.assertEqual(set(d), {"title", "parts", "participation", "counts"})
        self.assertGreaterEqual(len(d["parts"]), 2)
        for p in d["parts"]:
            self.assertEqual(set(p), {"id", "title", "points", "terms", "words", "checks"})
            self.assertTrue(p["points"])
        for a in d["participation"]:
            self.assertEqual(set(a), {"part", "part_title", "q"})
            self.assertEqual(set(a["q"]), {"id", "kind", "question", "answer", "options", "evidence", "clear"})
        self.assertEqual(d["counts"]["parts"], len(d["parts"]))

    def test_the_subject_and_grade_of_a_file_never_reach_the_class(self):
        lines = ["مادة الأحياء", "الصف الثاني المتوسط"] + F.LESSON[:6]
        r = self.upload(self.t, "cover.pptx", F.pptx_bytes(lines=lines), title="غلاف ومحتوى")
        lid = int(re.search(r"/lessons/(\d+)", r.headers["Location"]).group(1))
        shown = json.dumps(self.t.get(f"/api/lessons/{lid}/today").get_json(), ensure_ascii=False)
        self.assertIn("الخلية", shown)
        for gone in ("مادة الأحياء", "الصف الثاني", "المتوسط"):
            self.assertNotIn(gone, shown)

    def test_a_deck_of_the_stage_says_which_lesson_it_is_and_has_the_new_games(self):
        self.t.get(f"/lessons/{self.lid}/today")
        did = self.deck_of()[0]["id"]
        d = self.t.get(f"/api/decks/{did}/data").get_json()
        self.assertEqual((d["lesson_id"], d["auto"]), (self.lid, True))
        self.assertTrue({"pick", "qa", "live", "quiz"} <= set(d["games"]))
        self.assertEqual(d["game_info"]["live"]["kinds"], ["tf", "mcq", "cloze", "short"])
        self.assertEqual(d["game_info"]["quiz"]["kinds"], ["mcq", "tf", "cloze", "short", "qa"])
        manual = self.j(self.t, "post", f"/api/lessons/{self.lid}/decks", {"games": ["qa"], "question_ids": [d["questions"][0]["id"]], "title": "عرضي"}).get_json()
        self.assertFalse(self.t.get(f"/api/decks/{manual['id']}/data").get_json()["auto"])


class PageTests(Lessons):
    def test_the_dashboard_and_the_lesson_page_show_today_and_the_four_activities(self):
        dash = self.t.get("/dashboard").get_data(as_text=True)
        page = self.t.get(f"/lessons/{self.lid}").get_data(as_text=True)
        for html in (dash, page):
            self.assertIn("حصة اليوم", html)
            self.assertIn(f"/lessons/{self.lid}/today", html)
            for key in PRIMARY:
                self.assertIn(f"/lessons/{self.lid}/play/{key}", html)
        self.assertIn(">عجلة الحظ<", page)
        self.assertIn(">أسئلة تفاعلية<", page)
        self.assertIn(">اختبار قصير<", page)
        self.assertNotIn('class="acts"', page, "the old table-cell class would stop the text from wrapping")

    def test_the_stage_loads_its_scripts_and_they_are_all_served(self):
        self.t.get(f"/lessons/{self.lid}/today")
        did = self.deck_of()[0]["id"]
        html = self.t.get(f"/present/{did}").get_data(as_text=True)
        for name in ("present.js", "stage-today.js", "stage-games.js"):
            self.assertIn(name, html)
            self.assertEqual(self.t.get(f"/static/js/{name}").status_code, 200, name)
        for el_id in ("b-today", "b-menu", "b-class", "b-student", "view", "scoreboard"):
            self.assertIn(f'id="{el_id}"', html)

    def test_no_script_or_style_uses_a_thing_that_breaks_arabic_letters_apart(self):
        for path in list((ROOT / "app/static").rglob("*.css")) + list((ROOT / "app/static").rglob("*.js")) + list((ROOT / "app/templates").rglob("*.html")):
            text = path.read_text(encoding="utf-8")
            self.assertNotRegex(text, r"letter-spacing\s*:\s*[^;}]*[1-9]", f"{path.name}: spacing between letters cuts the joins of Arabic")
            self.assertNotIn("text-transform", text, path.name)

    @unittest.skipUnless(shutil.which("node"), "node is not installed")
    def test_every_script_is_valid_javascript(self):
        for path in sorted((ROOT / "app/static/js").glob("*.js")):
            r = subprocess.run(["node", "--check", str(path)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, f"{path.name}: {r.stderr}")


class PrintTests(Lessons):
    """Printing and «save as PDF»: the browser shapes the Arabic, we only give it a clean page (the PDF itself is checked in the browser test)."""

    def test_the_lesson_page_offers_three_sheets_and_has_a_place_to_build_them(self):
        page = self.t.get(f"/lessons/{self.lid}").get_data(as_text=True)
        for el_id in ("print-answers", "print-blank", "print-today", "print-sheet"):
            self.assertIn(f'id="{el_id}"', page)
        self.assertIn("ورقة الطالبات", page)
        self.assertIn("ورقة الشرح", page)

    def test_the_students_page_prints_a_report_without_its_forms(self):
        page = self.t.get("/students").get_data(as_text=True)
        self.assertIn("data-print", page)
        self.assertIn('class="print-only"', page)
        self.assertIn('class="card noprint"', page)                       # the add-a-class form is not printed

    def test_only_one_script_listens_to_the_print_buttons(self):
        app_js = (ROOT / "app/static/js/app.js").read_text(encoding="utf-8")
        admin_js = (ROOT / "app/static/js/admin.js").read_text(encoding="utf-8")
        self.assertIn("[data-print]", app_js)
        self.assertNotIn("data-print", admin_js, "two listeners would open two print windows")
        self.assertIn("data-print", (ROOT / "app/templates/admin/finance.html").read_text(encoding="utf-8"))

    def test_the_print_rules_only_apply_when_printing(self):
        css = (ROOT / "app/static/css/app.css").read_text(encoding="utf-8")
        head, _, printing = css.partition("@media print{")
        self.assertIn(".print-sheet,.print-only{display:none}", head, "the sheet must stay hidden on screen")
        for rule in ("body.sheet-on #lesson-app>:not(#print-sheet){display:none!important}", ".top,.foot,.btn", "@page{size:A4"):
            self.assertIn(rule, printing)
        self.assertNotIn("body.sheet-on", head)

    def test_the_sheet_scripts_build_from_the_page_s_own_questions(self):
        js = (ROOT / "app/static/js/lesson.js").read_text(encoding="utf-8")
        for needle in ("questionSheet(true)", "questionSheet(false)", "explainSheet()", "'beforeprint'", "'afterprint'", "/today'"):
            self.assertIn(needle, js)


class CountTests(Lessons):
    def test_nouns_agree_with_their_numbers_the_way_arabic_writes_them(self):
        from app import textfmt
        self.assertEqual([textfmt.questions(n) for n in (0, 1, 2, 3, 10, 11, 25)], ["0 أسئلة", "سؤال واحد", "سؤالان", "3 أسئلة", "10 أسئلة", "11 سؤالًا", "25 سؤالًا"])
        self.assertEqual([textfmt.students(n) for n in (1, 2, 6, 30)], ["طالب واحد", "طالبان", "6 طلاب", "30 طالبًا"])
        self.assertEqual(textfmt.questions("x"), "0 أسئلة")

    def test_the_dashboard_counts_a_lesson_s_questions_correctly(self):
        n = self.db.execute("SELECT COUNT(*) FROM questions WHERE lesson_id = ?", (self.lid,)).fetchone()[0]
        from app import textfmt
        self.assertIn(f"· {textfmt.questions(n)}</small>", self.t.get("/dashboard").get_data(as_text=True))

    def test_the_browser_has_the_same_rule(self):
        js = (ROOT / "app/static/js/app.js").read_text(encoding="utf-8")
        for forms in ("['سؤال واحد', 'سؤالان', 'أسئلة', 'سؤالًا']", "['طالب واحد', 'طالبان', 'طلاب', 'طالبًا']"):
            self.assertIn(forms, js)
        for path in ("present.js", "lesson.js", "students.js"):
            text = (ROOT / "app/static/js" / path).read_text(encoding="utf-8")
            self.assertNotRegex(text, r"\+ ' (?:سؤالًا|طالبًا)", f"{path} still glues a number to a fixed form")


class ResultsTests(Lessons):
    def setUp(self):
        super().setUp()
        self.t.get(f"/lessons/{self.lid}/today")
        self.deck = self.deck_of()[0]
        self.ids = json.loads(self.deck["question_ids"])
        cid = self.j(self.t, "post", "/api/classes", {"name": "أول أ"}).get_json()["id"]
        self.j(self.t, "post", "/api/students", {"names": ["سارة", "نورة", "هدى"], "class_id": cid})
        self.students = {s["name"]: s["id"] for s in self.t.get(f"/api/students?class_id={cid}").get_json()["students"]}

    def save(self, name, qid, game, correct, run="", client=None):
        return self.j(client or self.t, "post", "/api/results", {"student_id": self.students[name], "deck_id": self.deck["id"], "question_id": qid, "game": game, "correct": correct, "run": run})

    def results(self, name):
        return self.t.get(f"/api/students/{self.students[name]}/results").get_json()

    def test_a_quiz_is_saved_by_the_students_name_under_the_lessons_title(self):
        for i, qid in enumerate(self.ids[:5]):
            self.assertEqual(self.save("سارة", qid, "quiz", i % 2 == 0, run="qabc").status_code, 200)
        res = self.results("سارة")
        self.assertEqual(len(res["decks"]), 1)
        self.assertEqual((res["decks"][0]["title"], res["decks"][0]["answered"], res["decks"][0]["correct"], res["decks"][0]["percent"]), (self.title(), 5, 3, 60))
        self.assertEqual(self.results("نورة")["decks"], [])                          # not hers

    def test_the_same_run_updates_an_answer_and_a_new_run_adds_one(self):
        qid = self.ids[0]
        self.save("نورة", qid, "quiz", False, run="r1")
        self.save("نورة", qid, "quiz", True, run="r1")
        self.assertEqual(self.results("نورة")["decks"][0]["answered"], 1)
        self.assertEqual(self.results("نورة")["decks"][0]["correct"], 1)
        self.save("نورة", qid, "quiz", False, run="r2")
        self.assertEqual(self.results("نورة")["decks"][0]["answered"], 2)

    def test_today_and_live_questions_are_saved_the_same_way(self):
        self.assertEqual(self.save("هدى", self.ids[0], "today", True, run="x1").status_code, 200)
        self.assertEqual(self.save("هدى", self.ids[1], "live", False, run="x2").status_code, 200)
        self.assertEqual(self.results("هدى")["decks"][0]["answered"], 2)
        games = {r["game"] for r in self.db.execute("SELECT game FROM results")}
        self.assertEqual(games, {"today", "live"})

    def test_a_question_that_is_not_in_the_deck_or_another_teachers_student_is_refused(self):
        self.assertEqual(self.save("سارة", 999999, "quiz", True, run="q").status_code, 400)
        other = self.client()
        self.register(other, "b@example.com", "معلمة أخرى")
        self.assertEqual(self.save("سارة", self.ids[0], "quiz", True, run="q", client=other).status_code, 404)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM results").fetchone()[0], 0)

    def test_the_students_page_lists_the_lesson_by_its_title(self):
        self.save("سارة", self.ids[0], "quiz", True, run="qq")
        recent = self.results("سارة")["recent"]
        self.assertEqual([r["deck"] for r in recent], [self.title()])


if __name__ == "__main__":
    unittest.main()
