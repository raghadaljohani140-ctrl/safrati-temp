"""Version 5, phase 3 through the server: «غائب اليوم», the lessons moved by a day off and the log that says so, and two lessons taught together."""
import datetime
import re
import sqlite3
import tempfile
import unittest

from app import create_app
from app import db as dbm
from tests import test_v5_phase2 as P2

D = datetime.date


class Phase3(P2.Phase2):
    def record(self, c=None, **data):
        return self.api("post", "/api/absence", data, c)

    def preview(self, c=None, **data):
        return self.api("post", "/api/absence/preview", data, c)

    def absences(self, c=None):
        return (c or self.c).get("/api/absence").get_json()

    def cancel(self, ids, c=None):
        return self.api("delete", "/api/absence", {"ids": ids}, c)

    def starts(self, d):
        return [self.where(i)[:2] if i["planned"] else None for i in d["items"]]

    def dues(self, d):
        return [(i["due"]["date"] if i["due"] else None) for i in d["items"]]

    def logs(self, d, kind):
        return [l["text"] for l in d["log"] if l["kind"] == kind]

    def two_pairs(self):
        """Two classes with their own subjects: A has mathematics on Sunday (1) and Tuesday (2), B has science on Sunday (2). Both plans are built."""
        a, b = self.make_class("الصف الأول أ"), self.make_class("الصف الأول ب")
        math, sci = self.make_subject("الرياضيات"), self.make_subject("العلوم")
        self.set_slots([(0, 1, a, math), (0, 2, b, sci), (2, 2, a, math)])
        self.set_term()
        self.confirm(self.outline_book("كتاب الرياضيات"), [a], subject="الرياضيات")
        self.confirm(self.outline_book("كتاب العلوم"), [b], subject="العلوم")
        return a, math, b, sci, self.build(a, math), self.build(b, sci)


# ================================================================ recording an absence
class Absence(Phase3):
    def test_the_preview_shows_what_would_happen_and_changes_nothing(self):
        cid, sid, bid = self.scenario()
        before = self.build(cid, sid)
        logs = self.count("SELECT COUNT(*) FROM plan_log")
        r = self.preview(**{"from": "2026-09-06"})
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        d = r.get_json()
        self.assertEqual((d["count"], d["days"], d["classes"], d["lessons"]), (1, ["2026-09-06"], ["الصف الأول أ"], 1))
        p = d["periods"][0]
        self.assertEqual((p["class_name"], p["subject_name"], p["period"], p["date"], p["lesson"]), ("الصف الأول أ", "الرياضيات", 1, "2026-09-06", before["items"][0]["title"]))
        e = d["effects"][0]
        self.assertEqual((e["class_name"], e["subject_name"], e["moved_count"], e["short"], e["unplaced"]), ("الصف الأول أ", "الرياضيات", 6, 0, 0))
        self.assertEqual(e["moved"][0]["title"], before["items"][0]["title"])
        self.assertEqual((e["moved"][0]["from"]["date"], e["moved"][0]["to"]["date"], e["moved"][0]["to"]["period"]), ("2026-09-06", "2026-09-08", 2))
        self.assertEqual(self.count("SELECT COUNT(*) FROM absences"), 0)
        self.assertEqual(self.count("SELECT COUNT(*) FROM plan_log"), logs)
        self.assertEqual(self.plan(cid, sid)["items"], before["items"])

    def test_recording_an_absence_lays_the_lessons_out_again_and_none_is_lost(self):
        cid, sid, bid = self.scenario()
        before = self.build(cid, sid)
        r = self.record(**{"from": "2026-09-06", "reason": "مرض"})
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        d = self.plan(cid, sid)
        self.assertEqual([i["id"] for i in d["items"]], [i["id"] for i in before["items"]])          # the same lessons in the same order
        self.assertEqual([i["status"] for i in d["items"]], ["pending"] * 6)
        self.assertEqual(self.starts(d), [("2026-09-08", 2), ("2026-09-13", 1), ("2026-09-15", 2), ("2026-09-20", 1), ("2026-09-22", 2), ("2026-09-27", 1)])
        self.assertEqual(self.dues(d), ["2026-09-08", "2026-09-13", "2026-09-15", "2026-09-20", "2026-09-22", "2026-09-27"])          # the due days moved with the lessons
        self.assertEqual(d["summary"]["late"], [])
        self.assertFalse(any(i["late"] or i["shifted"] for i in d["items"]))
        self.assertEqual(self.count("SELECT COUNT(*) FROM plan_items"), 6)
        row = self.app.db.execute("SELECT day, period, reason FROM absences").fetchone()
        self.assertEqual(tuple(row), ("2026-09-06", 0, "مرض"))
        text = self.logs(d, "realign")[0]
        self.assertTrue(text.startswith("غياب الأحد 6 سبتمبر: تأجّل 6 دروس"), text)
        self.assertIn("«الدرس الأول: المقارنة» من الأحد 6 سبتمبر (الحصة 1) إلى الثلاثاء 8 سبتمبر (الحصة 2)", text)

    def test_the_preview_is_what_recording_then_does(self):
        cid, sid, bid = self.scenario()
        self.build(cid, sid)
        shown = self.preview(**{"from": "2026-09-06", "to": "2026-09-08"}).get_json()
        done = self.record(**{"from": "2026-09-06", "to": "2026-09-08"}).get_json()["result"]
        self.assertEqual(done["effects"], shown["effects"])
        self.assertEqual(done["periods"], shown["periods"])
        self.assertEqual((shown["count"], shown["days"]), (2, ["2026-09-06", "2026-09-08"]))
        d = self.plan(cid, sid)
        self.assertEqual(self.starts(d)[0], ("2026-09-13", 1))
        self.assertIn("غياب من الأحد 6 سبتمبر إلى الثلاثاء 8 سبتمبر", self.logs(d, "realign")[0])

    def test_cancelling_an_absence_brings_the_lessons_back_where_they_were(self):
        cid, sid, bid = self.scenario()
        before = self.build(cid, sid)
        got = self.record(**{"from": "2026-09-06"}).get_json()
        ids = got["upcoming"][0]["ids"]
        r = self.cancel(ids)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        out = r.get_json()
        self.assertEqual((out["result"]["cancelled"], out["result"]["effects"][0]["moved_count"], out["upcoming"]), (1, 6, []))
        d = self.plan(cid, sid)
        self.assertEqual(self.starts(d), self.starts(before))
        self.assertEqual(self.dues(d), self.dues(before))
        self.assertEqual(self.count("SELECT COUNT(*) FROM absences"), 0)
        text = self.logs(d, "realign")[0]
        self.assertTrue(text.startswith("إلغاء غياب الأحد 6 سبتمبر: تقدّم 6 دروس"), text)
        self.assertEqual(self.cancel(ids).status_code, 404)          # nothing left to cancel

    def test_several_absences_never_lose_a_lesson_or_change_the_order(self):
        cid, sid, bid = self.scenario()
        before = self.build(cid, sid)
        for day in ("2026-09-06", "2026-09-15", "2026-09-27"):
            self.assertEqual(self.record(**{"from": day}).status_code, 201)
        d = self.plan(cid, sid)
        self.assertEqual([i["id"] for i in d["items"]], [i["id"] for i in before["items"]])
        firsts = [(i["planned"]["first"]["date"], i["planned"]["first"]["period"]) for i in d["items"]]
        self.assertEqual(firsts, sorted(firsts))
        self.assertEqual(len(set(firsts)), 6)
        absent = {("2026-09-06", 1), ("2026-09-15", 2), ("2026-09-27", 1)}
        self.assertFalse(absent & set(firsts))          # no lesson is put in a period she is absent from
        self.assertEqual(len(self.logs(d, "realign")), 3)
        self.assertEqual(d["summary"]["late"], [])

    def test_only_the_periods_she_chose_are_taken_and_only_their_plans_move(self):
        a, math, b, sci, plan_a, plan_b = self.two_pairs()
        r = self.record(**{"from": "2026-09-06", "periods": [2]})
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        got = r.get_json()
        self.assertEqual([(p["class_name"], p["period"]) for p in got["result"]["periods"]], [("الصف الأول ب", 2)])
        self.assertEqual([e["class_name"] for e in got["result"]["effects"]], ["الصف الأول ب"])
        self.assertEqual(self.starts(self.plan(a, math)), self.starts(plan_a))          # A's plan is not touched
        self.assertEqual(self.logs(self.plan(a, math), "realign"), [])
        d = self.plan(b, sci)
        self.assertEqual(self.starts(d)[0], ("2026-09-13", 2))
        self.assertIn("(الحصة 2)", self.logs(d, "realign")[0])
        rows = [tuple(r) for r in self.app.db.execute("SELECT day, period FROM absences")]
        self.assertEqual(rows, [("2026-09-06", 2)])
        self.assertEqual(got["upcoming"][0]["periods"], [2])
        self.assertFalse(got["upcoming"][0]["whole"])

    def test_a_whole_day_takes_in_the_periods_recorded_one_by_one(self):
        a, math, b, sci, plan_a, plan_b = self.two_pairs()
        self.record(**{"from": "2026-09-06", "periods": [2]})
        got = self.record(**{"from": "2026-09-06"}).get_json()
        self.assertEqual([(p["class_name"], p["period"]) for p in got["result"]["periods"]], [("الصف الأول أ", 1)])          # period 2 was already taken
        self.assertEqual([tuple(r) for r in self.app.db.execute("SELECT day, period FROM absences")], [("2026-09-06", 0)])
        self.assertEqual(self.starts(self.plan(a, math))[0], ("2026-09-08", 2))
        self.assertEqual(self.starts(self.plan(b, sci))[0], ("2026-09-13", 2))          # and still only once

    def test_days_that_take_nothing_are_named_and_skipped(self):
        cid, sid, bid = self.scenario()
        self.build(cid, sid)
        self.api("post", "/api/calendar/holidays", {"from": "2026-09-13", "label": "يوم وطني"})
        d = self.preview(**{"from": "2026-09-10", "to": "2026-09-15"}).get_json()          # Thursday to Tuesday
        self.assertEqual([p["date"] for p in d["periods"]], ["2026-09-15"])
        why = {s["date"]: s["why"] for s in d["skipped"]}
        self.assertEqual(why, {"2026-09-10": "لا حصص لك في هذا اليوم", "2026-09-11": "لا حصص لك في هذا اليوم", "2026-09-12": "لا حصص لك في هذا اليوم",
                               "2026-09-13": "يوم وطني", "2026-09-14": "لا حصص لك في هذا اليوم"})
        got = self.record(**{"from": "2026-09-10", "to": "2026-09-15"}).get_json()
        self.assertEqual([tuple(r) for r in self.app.db.execute("SELECT day, period FROM absences")], [("2026-09-15", 0)])          # only the day that holds a period is recorded
        self.assertEqual(len(got["result"]["skipped"]), 5)

    def test_what_cannot_be_kept_is_refused_with_a_sentence(self):
        cid, sid, bid = self.scenario()
        self.build(cid, sid)
        self.api("post", "/api/calendar/holidays", {"from": "2026-09-13", "label": "يوم وطني"})
        self.today = D(2026, 9, 7)
        logged = self.count("SELECT COUNT(*) FROM plan_log WHERE kind = 'realign'")          # (the holiday above moved the lessons once)
        cases = [({"from": "2026-09-06"}, "اختاري اليوم أو يومًا قادمًا"),                      # a day that has passed
                 ({"from": "2026-09-15", "to": "2026-09-08"}, "ألا يسبق"),                      # backwards
                 ({"from": "2026-09-08", "to": "2026-10-20"}, "أطول من 31 يومًا"),
                 ({"from": "2027-01-05"}, "بعد نهاية الفصل"),
                 ({"from": "2026-09-13"}, "يوم وطني"),                                        # a holiday takes nothing
                 ({"from": "2026-09-11"}, "لا حصص لك في هذا اليوم"),                           # a Friday
                 ({"from": "2026-09-08", "to": "2026-09-09", "periods": [2]}, "ليوم واحد"),
                 ({"from": "2026-09-08", "periods": ["x"]}, "حصص غير صحيحة"),
                 ({"from": "2026-09-08", "periods": [99]}, "حصة واحدة على الأقل"),
                 ({"from": "2026-09-08", "periods": [5]}, "ليست في جدولك")]
        for data, word in cases:
            for call in (self.preview, self.record):
                r = call(**data)
                self.assertEqual(r.status_code, 400, (data, r.get_data(as_text=True)))
                self.assertIn(word, r.get_json()["error"], data)
        self.assertEqual(self.count("SELECT COUNT(*) FROM absences"), 0)
        self.assertEqual(self.count("SELECT COUNT(*) FROM plan_log WHERE kind = 'realign'"), logged)          # a refused absence moves nothing and writes nothing

    def test_a_day_recorded_twice_is_not_taken_twice(self):
        cid, sid, bid = self.scenario()
        self.build(cid, sid)
        self.assertEqual(self.record(**{"from": "2026-09-06"}).status_code, 201)
        r = self.record(**{"from": "2026-09-06"})
        self.assertEqual(r.status_code, 400)
        self.assertIn("غيابك مسجَّل لهذا اليوم", r.get_json()["error"])
        self.assertEqual(self.count("SELECT COUNT(*) FROM absences"), 1)
        self.assertEqual(len(self.logs(self.plan(cid, sid), "realign")), 1)

    def test_without_a_term_or_a_timetable_she_is_told_what_to_do(self):
        r = self.record(**{"from": "2026-09-06"})
        self.assertEqual(r.status_code, 400)
        self.assertIn("حدّدي بداية الفصل", r.get_json()["error"])
        self.set_term()
        r = self.record(**{"from": "2026-09-06"})
        self.assertEqual(r.status_code, 400)
        self.assertIn("لا حصص لك في هذا اليوم", r.get_json()["error"])
        self.assertEqual(self.absences()["has_schedule"], False)

    def test_an_absence_belongs_to_one_teacher(self):
        cid, sid, bid = self.scenario()
        before = self.build(cid, sid)
        mine = self.record(**{"from": "2026-09-06"}).get_json()["upcoming"][0]["ids"]
        other = self.client()
        self.register(other, email="b@example.com")
        self.assertEqual(self.absences(other)["upcoming"], [])
        self.assertEqual(self.cancel(mine, other).status_code, 404)
        self.assertEqual(self.count("SELECT COUNT(*) FROM absences"), 1)
        # her absence is not the other teacher's: the same day recorded by the other is her own row
        oc, osub = self.make_class("صف", other), self.make_subject("مادة", other)
        self.set_slots([(0, 1, oc, osub)], other)
        self.set_term(c=other)
        self.assertEqual(self.record(other, **{"from": "2026-09-06"}).status_code, 201)
        self.assertEqual(self.count("SELECT COUNT(*) FROM absences"), 2)
        self.assertNotEqual(self.starts(self.plan(cid, sid)), self.starts(before))          # hers moved
        self.assertEqual(len(self.absences()["upcoming"]), 1)

    def test_lessons_already_late_stay_late_and_the_rest_are_not_made_late(self):
        cid, sid, bid = self.scenario()
        d = self.build(cid, sid)
        ids = [i["id"] for i in d["items"]]
        self.act(ids[0], "done")
        self.today = D(2026, 9, 20)          # the second to fourth lessons were due and not taught
        before = self.plan(cid, sid)
        self.assertEqual(before["summary"]["late"], ids[1:4])
        self.assertEqual(self.dues(before)[:5], ["2026-09-06", "2026-09-08", "2026-09-13", "2026-09-15", "2026-09-20"])
        self.assertEqual(self.record(**{"from": "2026-09-20"}).status_code, 201)
        d = self.plan(cid, sid)
        self.assertEqual(d["summary"]["late"], ids[1:4])          # she is not blamed for the lessons she was late with, nor excused
        self.assertEqual(self.dues(d)[:4], ["2026-09-06", "2026-09-08", "2026-09-13", "2026-09-15"])
        self.assertEqual(self.dues(d)[4], "2026-09-22")          # but the lesson due on the day she is absent moves to the next period
        self.assertFalse(d["items"][4]["late"])          # (it is behind because of the late lessons before it, not because of her absence, so it may still be «shifted»)
        self.assertEqual(self.starts(d)[1], ("2026-09-22", 2))

    def test_a_period_she_is_absent_from_is_shown_as_such_today_and_the_home_card_says_so(self):
        cid, sid = self.make_class(), self.make_subject()
        self.set_slots([(0, 1, cid, sid), (0, 2, cid, sid), (2, 2, cid, sid)])
        self.set_term()
        self.confirm(self.outline_book(), [cid])
        self.build(cid, sid)
        html = self.c.get("/dashboard").get_data(as_text=True)
        self.assertIn('href="/absent"', html)
        self.assertIn("سجّلي غيابك وتُعاد جدولة الدروس", html)
        self.record(**{"from": "2026-09-06", "periods": [2]})
        t = self.c.get("/api/today").get_json()
        self.assertEqual([(p["period"], p["state"]) for p in t["periods"]], [(1, "now"), (2, "absent")])
        self.assertIsNone(t["periods"][1]["lesson"])
        self.assertFalse(t["absent_day"])
        self.assertIn("غيابك اليوم مسجَّل", self.c.get("/dashboard").get_data(as_text=True))
        self.cancel(self.absences()["upcoming"][0]["ids"])
        self.record(**{"from": "2026-09-06"})
        t = self.c.get("/api/today").get_json()
        self.assertEqual([p["state"] for p in t["periods"]], ["absent", "absent"])
        self.assertTrue(t["absent_day"])
        self.assertIsNone(self.c.get("/api/start").get_json()["suggest"])          # nothing is suggested for a period she is absent from

    def test_the_message_for_each_class_says_what_is_cancelled_and_names_no_student(self):
        a, math, b, sci, plan_a, plan_b = self.two_pairs()
        link = "https://chat.whatsapp.com/ABCDEFGH12345678"
        self.assertEqual(self.api("patch", f"/api/classes/{a}", {"whatsapp": link}).status_code, 200)
        self.api("post", "/api/students/import", {})          # (no students are needed: the message never has a name)
        got = self.record(**{"from": "2026-09-06", "reason": "مرض شديد"}).get_json()["result"]
        msgs = {m["class_name"]: m for m in got["messages"]}
        self.assertEqual(sorted(msgs), ["الصف الأول أ", "الصف الأول ب"])
        ma, mb = msgs["الصف الأول أ"], msgs["الصف الأول ب"]
        self.assertTrue(ma["text"].startswith("السلام عليكم ورحمة الله وبركاته\nتنبيه إلى الصف الأول أ:\n• الأحد 6 سبتمبر: الرياضيات (الحصة 1)\n"), ma["text"])
        self.assertIn("• الأحد 6 سبتمبر: العلوم (الحصة 2)", mb["text"])
        self.assertTrue(ma["text"].endswith("لن تُقام الحصة المذكورة أعلاه لغياب المعلمة، وسيُعوَّض الدرس في حصة قادمة بإذن الله."))
        self.assertNotIn("مرض", ma["text"] + mb["text"])          # the reason is hers alone
        self.assertTrue(ma["wa"].startswith("https://wa.me/?text="))
        self.assertNotIn("%D9%85%D8%B1%D8%B6", ma["wa"])
        self.assertEqual((ma["group"], mb["group"]), (link, ""))
        # the same messages are on the page for an absence already recorded
        again = self.absences()["upcoming"][0]["messages"]
        self.assertEqual([m["text"] for m in again], [ma["text"], mb["text"]])

    def test_a_long_absence_writes_every_day_in_the_message(self):
        cid, sid, bid = self.scenario()
        self.build(cid, sid)
        got = self.record(**{"from": "2026-09-06", "to": "2026-09-15"}).get_json()
        text = got["result"]["messages"][0]["text"]
        self.assertEqual(got["result"]["count"], 4)
        for line in ("• الأحد 6 سبتمبر: الرياضيات (الحصة 1)", "• الثلاثاء 8 سبتمبر: الرياضيات (الحصة 2)", "• الأحد 13 سبتمبر: الرياضيات (الحصة 1)", "• الثلاثاء 15 سبتمبر: الرياضيات (الحصة 2)"):
            self.assertIn(line, text)
        self.assertIn("لن تُقام الحصص المذكورة أعلاه", text)
        self.assertEqual(len(got["upcoming"]), 4)          # the days are not neighbours (a day with no period lies between), so each is a line of its own

    def test_neighbouring_days_with_the_same_reason_are_one_line_and_can_be_cancelled_together(self):
        cid, sid, bid = self.scenario(slots=((0, 1), (1, 2)))          # Sunday and Monday
        before = self.build(cid, sid)
        got = self.record(**{"from": "2026-09-06", "to": "2026-09-07", "reason": "دورة"}).get_json()
        self.assertEqual(len(got["upcoming"]), 1)
        line = got["upcoming"][0]
        self.assertEqual((line["from"], line["to"], line["days"], line["whole"], len(line["ids"]), line["reason"]), ("2026-09-06", "2026-09-07", 2, True, 2, "دورة"))
        self.assertEqual(self.record(**{"from": "2026-09-13", "reason": "مرض"}).status_code, 201)
        self.assertEqual(len(self.absences()["upcoming"]), 2)          # another reason, another day
        self.cancel(line["ids"])
        d = self.plan(cid, sid)
        self.assertEqual(self.count("SELECT COUNT(*) FROM absences"), 1)
        self.assertEqual(self.starts(d)[:2], [("2026-09-06", 1), ("2026-09-07", 2)])

    def test_the_page_lists_what_is_coming_and_what_has_passed(self):
        cid, sid, bid = self.scenario()
        self.build(cid, sid)
        self.record(**{"from": "2026-09-06"})
        self.record(**{"from": "2026-09-08", "to": "2026-09-08"})
        self.record(**{"from": "2026-09-13", "reason": "دورة"})
        self.today = D(2026, 9, 9)
        d = self.absences()
        self.assertEqual([(x["from"], x["reason"]) for x in d["upcoming"]], [("2026-09-13", "دورة")])
        self.assertEqual([x["from"] for x in d["history"]], ["2026-09-08", "2026-09-06"])          # the latest first
        self.assertEqual(self.cancel([self.app.db.execute("SELECT id FROM absences WHERE day = '2026-09-06'").fetchone()[0]]).status_code, 404)          # a past day cannot be cancelled
        self.assertEqual((d["today"], d["term"]["starts"]), ("2026-09-09", "2026-09-06"))
        self.assertEqual(sorted(d["week"]), ["0", "2"])
        self.assertEqual(d["week"]["0"][0]["period"], 1)

    def test_a_period_already_over_today_is_not_taken_again(self):
        cid, sid = self.make_class(), self.make_subject()
        self.set_slots([(0, 1, cid, sid), (0, 2, cid, sid), (2, 2, cid, sid)], times={"1": {"starts": "07:00", "ends": "07:45"}, "2": {"starts": "07:45", "ends": "08:30"}})
        self.set_term()
        self.confirm(self.outline_book(), [cid])
        self.build(cid, sid)
        self.clock = datetime.time(7, 50)          # the first period is over
        got = self.record(**{"from": "2026-09-06"}).get_json()["result"]
        self.assertEqual([p["period"] for p in got["periods"]], [2])
        self.clock = datetime.time(9, 0)
        r = self.record(**{"from": "2026-09-06", "periods": [1]})
        self.assertEqual(r.status_code, 400)


# ================================================================ the plans follow a change in the periods
class Realigning(Phase3):
    def test_a_new_period_in_the_timetable_pulls_the_lessons_earlier_and_the_log_says_so(self):
        cid, sid, bid = self.scenario()
        before = self.build(cid, sid)
        self.set_slots([(0, 1, cid, sid), (2, 2, cid, sid), (4, 3, cid, sid)])          # a Thursday period too
        d = self.plan(cid, sid)
        self.assertEqual(self.starts(d)[:4], [("2026-09-06", 1), ("2026-09-08", 2), ("2026-09-10", 3), ("2026-09-13", 1)])
        self.assertEqual(self.dues(d)[2], "2026-09-10")
        self.assertEqual(d["summary"]["late"], [])
        text = self.logs(d, "realign")[0]
        self.assertTrue(text.startswith("تغيّر جدول الحصص: تقدّم 4 دروس"), text)
        self.assertEqual(len(d["items"]), len(before["items"]))

    def test_changing_only_the_clock_times_moves_nothing(self):
        cid, sid, bid = self.scenario()
        self.build(cid, sid)
        self.set_slots([(0, 1, cid, sid), (2, 2, cid, sid)], times={"1": {"starts": "07:00", "ends": "07:45"}})
        self.assertEqual(self.logs(self.plan(cid, sid), "realign"), [])

    def test_a_holiday_added_and_taken_away_again_leaves_the_plan_as_it_was(self):
        cid, sid, bid = self.scenario()
        before = self.build(cid, sid)
        added = self.api("post", "/api/calendar/holidays", {"from": "2026-09-08", "to": "2026-09-14", "label": "إجازة"}).get_json()
        self.assertEqual(added["moved"], 5)          # the screen can say «تحرّك موعد 5 دروس»
        mid = self.plan(cid, sid)
        self.assertNotEqual(self.starts(mid), self.starts(before))
        ids = added["ranges"][0]["ids"]
        gone = self.api("delete", "/api/calendar/holidays", {"ids": ids}).get_json()
        self.assertEqual(gone["moved"], 5)
        d = self.plan(cid, sid)
        self.assertEqual((self.starts(d), self.dues(d)), (self.starts(before), self.dues(before)))
        texts = self.logs(d, "realign")
        self.assertTrue(texts[0].startswith("حذف إجازة: تقدّم 5 دروس"), texts)
        self.assertTrue(texts[1].startswith("إضافة إجازة «إجازة»: تأجّل 5 دروس"), texts)

    def test_a_shorter_term_keeps_every_lesson_and_says_which_no_longer_fit(self):
        cid, sid, bid = self.scenario()
        before = self.build(cid, sid)
        self.set_term(ends="2026-09-20")
        d = self.plan(cid, sid)
        self.assertEqual([i["id"] for i in d["items"]], [i["id"] for i in before["items"]])
        self.assertEqual(d["summary"]["unplaced"], 1)
        self.assertIsNone(d["items"][5]["planned"])
        self.assertIn("لم تعد الحصص تكفي لـدرس واحد", self.logs(d, "realign")[0])

    def test_the_plans_of_another_teacher_are_not_touched_by_my_changes(self):
        cid, sid, bid = self.scenario()
        self.build(cid, sid)
        other = self.client()
        self.register(other, email="b@example.com")
        oc, osub = self.make_class("صف", other), self.make_subject("مادة", other)
        self.set_slots([(0, 1, oc, osub)], other)
        self.set_term(c=other)
        ob = self.outline_book("كتاب", c=other)
        self.confirm(ob, [oc], subject="مادة", c=other)
        mine = self.build(oc, osub, other)
        self.api("post", "/api/calendar/holidays", {"from": "2026-09-06", "to": "2026-09-30", "label": "إجازة"})
        self.record(**{"from": "2026-10-04"})
        theirs = self.plan(oc, osub, other)
        self.assertEqual(self.starts(theirs), self.starts(mine))
        self.assertEqual(self.logs(theirs, "realign"), [])


# ================================================================ lessons taught together
class Merging(Phase3):
    def short(self):
        """Five periods for six lessons: one lesson has no period."""
        cid, sid, bid = self.scenario(term=False)
        self.set_term(ends="2026-09-20")
        d = self.build(cid, sid)
        return cid, sid, d

    def merge(self, first, second, c=None):
        return self.api("post", "/api/plan/merge", {"first": first, "second": second}, c)

    def test_two_neighbouring_lessons_taught_together_win_back_a_period(self):
        cid, sid, d = self.short()
        ids = [i["id"] for i in d["items"]]
        self.assertEqual((d["summary"]["spare"], d["summary"]["unplaced"]), (-1, 1))
        idea = d["ideas"][0]
        self.assertEqual((idea["first"], idea["second"], idea["saves"]), (ids[0], ids[1], 1))
        r = self.merge(idea["first"], idea["second"])
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        d = r.get_json()
        s = d["summary"]
        self.assertEqual((s["spare"], s["unplaced"], s["periods_needed"]), (0, 0, 5))
        self.assertEqual(d["ideas"], [])
        self.assertEqual(self.where(d["items"][0]), self.where(d["items"][1]))          # the same period
        self.assertEqual((d["items"][1]["together"], d["items"][0]["leads"]), (ids[0], ids[1]))
        self.assertEqual([self.where(i)[:2] for i in d["items"][2:]], [("2026-09-08", 2), ("2026-09-13", 1), ("2026-09-15", 2), ("2026-09-20", 1)])          # every other lesson has its period
        self.assertEqual(len(d["items"]), 6)
        self.assertEqual(d["log"][0]["kind"], "merge")
        self.assertIn(d["items"][0]["title"], d["log"][0]["text"])
        self.assertEqual(self.dues(d)[1], self.dues(d)[0])

    def test_taking_the_two_apart_gives_the_second_its_periods_again(self):
        cid, sid, d = self.short()
        ids = [i["id"] for i in d["items"]]
        self.merge(ids[0], ids[1])
        for who in (ids[1], ids[0]):          # either of the two can be used: the second one first, then the first one
            d = self.act(who, "unmerge")
            self.assertEqual((d["items"][1]["together"], d["items"][0]["leads"]), (None, None))
            self.assertEqual((d["summary"]["spare"], d["summary"]["unplaced"]), (-1, 1))
            self.assertEqual(d["log"][0]["kind"], "unmerge")
            self.assertEqual(self.merge(ids[0], ids[1]).status_code, 200)
        self.assertEqual(self.api("post", f"/api/plan/{ids[2]}/unmerge", {}).status_code, 400)          # a lesson that was never merged

    def test_what_cannot_be_merged_is_refused(self):
        cid, sid, d = self.short()
        ids = [i["id"] for i in d["items"]]
        for first, second, word in ((ids[0], ids[2], "متتاليين"), (ids[0], ids[0], "خطة واحدة"), (ids[4], ids[5], "للدروس فقط"), (ids[1], ids[0], "متتاليين"), (0, ids[1], None)):
            r = self.merge(first, second)
            self.assertIn(r.status_code, (400, 404), (first, second))
            if word:
                self.assertIn(word, r.get_json()["error"])
        self.assertEqual(self.count("SELECT COUNT(*) FROM plan_items WHERE together_with IS NOT NULL"), 0)
        self.assertEqual(self.merge(ids[0], ids[1]).status_code, 200)
        for first, second in ((ids[1], ids[2]), (ids[0], ids[2]), (ids[0], ids[1])):
            self.assertEqual(self.merge(first, second).status_code, 400, (first, second))          # one that is merged is not merged again
        self.act(ids[3], "done")
        self.assertEqual(self.merge(ids[2], ids[3]).status_code, 400)          # a lesson already taught
        other = self.client()
        self.register(other, email="b@example.com")
        self.assertEqual(self.merge(ids[2], ids[3], other).status_code, 404)

    def test_marking_the_first_done_marks_the_one_taught_with_it_and_undo_brings_both_back(self):
        cid, sid, d = self.short()
        ids = [i["id"] for i in d["items"]]
        self.merge(ids[0], ids[1])
        d = self.act(ids[0], "done")
        self.assertEqual([i["status"] for i in d["items"][:3]], ["done", "done", "pending"])
        self.assertEqual(d["items"][0]["done_on"], d["items"][1]["done_on"])
        self.assertIn(d["items"][1]["title"], d["log"][0]["text"])
        self.assertEqual(d["summary"]["current"], ids[2])
        self.assertEqual(d["summary"]["percent"], 33)          # two lessons of the six are taught (once taught, the pair counts as two lessons again)
        d = self.act(ids[0], "undo")
        self.assertEqual([i["status"] for i in d["items"][:3]], ["pending", "pending", "pending"])
        self.assertEqual(d["items"][1]["together"], ids[0])          # still taught together
        self.assertEqual(d["summary"]["spare"], 0)

    def test_moving_or_skipping_a_lesson_ends_the_merge(self):
        cid, sid, d = self.short()
        ids = [i["id"] for i in d["items"]]
        self.merge(ids[0], ids[1])
        d = self.act(ids[1], "move", {"dir": "down"})
        self.assertEqual(self.count("SELECT COUNT(*) FROM plan_items WHERE together_with IS NOT NULL"), 0)
        self.assertEqual((d["summary"]["spare"], d["summary"]["unplaced"]), (-1, 1))
        self.merge(ids[0], ids[2])
        d = self.act(ids[0], "skip")
        self.assertEqual(self.count("SELECT COUNT(*) FROM plan_items WHERE together_with IS NOT NULL"), 0)
        self.assertEqual(d["items"][0]["status"], "skipped")
        self.assertEqual(len(d["items"]), 6)

    def test_i_am_here_does_not_leave_a_link_to_a_lesson_that_was_marked_done(self):
        cid, sid, d = self.short()
        ids = [i["id"] for i in d["items"]]
        self.merge(ids[0], ids[1])
        d = self.act(ids[2], "here")
        self.assertEqual([i["status"] for i in d["items"][:3]], ["done", "done", "pending"])
        self.assertEqual(self.count("SELECT COUNT(*) FROM plan_items WHERE together_with IS NOT NULL"), 0)

    def test_a_lesson_that_is_taught_with_a_done_one_is_an_ordinary_lesson_again(self):
        cid, sid, d = self.short()
        ids = [i["id"] for i in d["items"]]
        self.merge(ids[0], ids[1])
        self.app.db.execute("UPDATE plan_items SET status = 'done' WHERE id = ?", (ids[0],))          # the first one was marked done some other way
        self.app.db.commit()
        d = self.plan(cid, sid)
        self.assertEqual(d["items"][1]["together"], None)
        self.assertIsNotNone(d["items"][1]["planned"])

    def test_the_merge_suggestions_never_cross_a_review(self):
        cid, sid, d = self.short()
        for idea in d["ideas"]:
            kinds = {i["id"]: i["kind"] for i in d["items"]}
            self.assertEqual((kinds[idea["first"]], kinds[idea["second"]]), ("lesson", "lesson"))


# ================================================================ the screen
class Screen(Phase3):
    def test_the_absent_screen_opens_for_a_teacher_and_has_no_inline_code(self):
        r = self.c.get("/absent")
        self.assertEqual(r.status_code, 200)
        html = r.get_data(as_text=True)
        self.assertIn("js/absent.js", html)
        self.assertIn("css/plan.css", html)
        self.assertEqual(r.headers["Cache-Control"], "no-store")
        self.assertNotRegex(html, r"\son[a-z]+\s*=")
        self.assertNotRegex(html, r"<[a-z]+[^>]*\sstyle\s*=")
        self.assertNotIn("<script>", html)
        self.assertEqual(self.c.get("/static/js/absent.js").status_code, 200)
        self.assertEqual(self.client().get("/absent").status_code, 302)

    def test_the_api_is_closed_to_a_visitor(self):
        anon = self.client()
        self.assertEqual(anon.get("/api/absence").status_code, 401)
        self.assertEqual(self.j(anon, "post", "/api/absence", {"from": "2026-09-06"}).status_code, 401)
        self.assertEqual(self.j(anon, "post", "/api/absence/preview", {"from": "2026-09-06"}).status_code, 401)
        self.assertEqual(self.j(anon, "delete", "/api/absence", {"ids": [1]}).status_code, 401)
        self.assertEqual(self.j(anon, "post", "/api/plan/merge", {"first": 1, "second": 2}).status_code, 401)

    def test_nothing_is_changed_without_the_csrf_header(self):
        cid, sid, bid = self.scenario()
        self.build(cid, sid)
        r = self.c.post("/api/absence", json={"from": "2026-09-06"})
        self.assertEqual(r.status_code, 403)
        self.assertEqual(self.count("SELECT COUNT(*) FROM absences"), 0)

    def test_the_page_data_without_anything_recorded(self):
        d = self.absences()
        self.assertEqual((d["upcoming"], d["history"], d["term"], d["has_schedule"], d["week"]), ([], [], None, False, {}))
        self.assertEqual(d["today"], "2026-09-06")


# ================================================================ a database of the earlier version
class Upgrade(unittest.TestCase):
    def test_a_database_made_before_phase_3_gets_the_absences_and_the_link_and_loses_nothing(self):
        with tempfile.TemporaryDirectory() as tmp:
            app = create_app(INSTANCE=tmp, BACKGROUND=False)
            db = app.db
            db.execute("INSERT INTO users(email, name, pass_hash, created_at) VALUES ('old@example.com', 'قديمة', 'h', 5)")
            db.execute("INSERT INTO terms(user_id, name, starts, ends, created_at) VALUES (1, 'الفصل', '2026-09-06', '2026-12-17', 1)")
            db.execute("INSERT INTO classes(user_id, name, created_at) VALUES (1, 'ف', 1)")
            db.execute("INSERT INTO subjects(user_id, name, created_at) VALUES (1, 'م', 1)")
            db.execute("INSERT INTO books(user_id, title, kind, status, created_at, updated_at) VALUES (1, 'ك', 'manual', 'ready', 1, 1)")
            db.execute("INSERT INTO book_lessons(user_id, book_id, title, position) VALUES (1, 1, 'درس', 0)")
            db.execute("INSERT INTO plan_items(user_id, term_id, class_id, subject_id, book_lesson_id, created_at, updated_at) VALUES (1, 1, 1, 1, 1, 1, 1)")
            db.commit()
            db.execute("DROP TABLE absences")                       # what a database of the earlier version looks like
            db.execute("PRAGMA foreign_keys = OFF")
            db.execute("ALTER TABLE plan_items RENAME TO plan_items_new")
            cols = [r[1] for r in db.execute("PRAGMA table_info(plan_items_new)") if r[1] != "together_with"]
            db.execute("CREATE TABLE plan_items AS SELECT " + ", ".join(cols) + " FROM plan_items_new")
            db.execute("DROP TABLE plan_items_new")
            db.commit()
            db.execute("PRAGMA foreign_keys = ON")
            self.assertNotIn("together_with", [r[1] for r in db.execute("PRAGMA table_info(plan_items)")])
            self.assertEqual(db.execute("SELECT name FROM sqlite_master WHERE name = 'absences'").fetchone(), None)
            dbm.init(db)
            dbm.init(db)                                            # and again: nothing more happens
            self.assertIn("together_with", [r[1] for r in db.execute("PRAGMA table_info(plan_items)")])
            self.assertIsNotNone(db.execute("SELECT name FROM sqlite_master WHERE name = 'absences'").fetchone())
            self.assertEqual(db.execute("SELECT COUNT(*) FROM plan_items").fetchone()[0], 1)
            self.assertIsNone(db.execute("SELECT together_with FROM plan_items").fetchone()[0])
            db.execute("INSERT INTO absences(user_id, day, period, created_at) VALUES (1, '2026-09-06', 0, 1)")
            with self.assertRaises(sqlite3.IntegrityError):         # a day is recorded once
                db.execute("INSERT INTO absences(user_id, day, period, created_at) VALUES (1, '2026-09-06', 0, 2)")
            db.rollback()
            with self.assertRaises(sqlite3.IntegrityError):         # periods run from 1 to 12 (0 is the whole day)
                db.execute("INSERT INTO absences(user_id, day, period, created_at) VALUES (1, '2026-09-07', 13, 2)")
            db.rollback()
            db.execute("DELETE FROM users WHERE id = 1")            # her absences go with her account
            db.commit()
            self.assertEqual(db.execute("SELECT COUNT(*) FROM absences").fetchone()[0], 0)
            db.close()


if __name__ == "__main__":
    unittest.main()
