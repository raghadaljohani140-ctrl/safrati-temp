"""Small admin commands (a teacher is named by her e-mail or her mobile number):
  python manage.py set-plan teacher@example.com monthly
  python manage.py set-plan 0501234567 monthly
  python manage.py make-admin you@example.com"""
import sys

from app import create_app, identity


def where(who):
    """('email = ?', value) or ('phone = ?', value) for what was typed; None when it is neither."""
    if "@" in who:
        return "email = ?", who.strip().lower()
    phone = identity.normalize_phone(who)
    return ("phone = ?", phone) if phone else None


def main():
    app = create_app()
    if len(sys.argv) == 4 and sys.argv[1] == "set-plan":
        who, plan = where(sys.argv[2]), sys.argv[3]
        if not who:
            sys.exit("write an e-mail address or a mobile number")
        if not app.db.execute("SELECT 1 FROM plans WHERE code = ?", (plan,)).fetchone():
            sys.exit("unknown plan (free, monthly, yearly)")
        n = app.db.execute(f"UPDATE users SET plan_code = ? WHERE {who[0]}", (plan, who[1])).rowcount
        app.db.commit()
        print("done" if n else "no such user")
    elif len(sys.argv) == 3 and sys.argv[1] == "make-admin":
        who = where(sys.argv[2])
        if not who:
            sys.exit("write an e-mail address or a mobile number")
        n = app.db.execute(f"UPDATE users SET is_admin = 1 WHERE {who[0]}", (who[1],)).rowcount
        app.db.commit()
        print("done" if n else "no such user")
    else:
        print(__doc__)


main()
