#!/usr/bin/env bash
# Copies of the site's data, kept on the server, so that a bad day (a deleted volume, a bad update, a full disk) never costs the teachers their work.
# (A teacher's own download from the app, «نسختي الاحتياطية», is a different thing: it is hers, and it is for her account only. These copies are the whole site.)
#
#   bash backup.sh now       one copy of the database now
#   bash backup.sh files     one copy of the uploaded files now (payment receipts, the files of lessons)
#   bash backup.sh install   copies this script to /opt/lessonplay/backup.sh and asks cron for a copy of the database every day at 03:30
#                            and a copy of the files every Friday at 03:50
#   bash backup.sh remove    takes those two lines out of cron (the copies stay where they are)
#   bash backup.sh list      what is saved, when, how big, and whether the newest copy of the database can be read
#
# It only reads from the running site: the database is copied with SQLite's own backup, which is safe while the site is working, and nothing in the
# container, the data volume, Caddy or any other project is changed. Copies are private to root (700 / 600), compressed, and checked after they are made:
# the newest 14 copies of the database and the newest 4 of the files are kept, older ones are removed (copies made by update.sh are not touched).
# Putting a copy back is described in README.md («نسخ الخادم»): it is done by hand, on purpose.
set -u -o pipefail
export PATH="${PATH:-/usr/bin:/bin}:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"          # (cron starts with a short PATH)

NAME=${LP_CONTAINER:-lessonplay-web}
BACKUPS=${LP_BACKUPS:-/opt/lessonplay/backups}
INSTALLED=${LP_INSTALLED:-/opt/lessonplay/backup.sh}
KEEP_DB=${LP_KEEP:-14}
KEEP_FILES=${LP_KEEP_FILES:-4}
MIN_FREE_KB=${LP_MIN_FREE_KB:-300000}
MARK="# lessonplay-backup"
SELF=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/$(basename "${BASH_SOURCE[0]}")

say()  { echo "$(date '+%F %T') $*"; }
fail() { echo "$(date '+%F %T') !! $*" >&2; exit 1; }

ready() {
    command -v docker  >/dev/null || fail "docker not found"
    command -v python3 >/dev/null || fail "python3 not found"
    docker inspect "$NAME" >/dev/null 2>&1 || fail "container $NAME not found"
    [ "$(docker inspect -f '{{.State.Running}}' "$NAME" 2>/dev/null)" = "true" ] || fail "container $NAME is not running"
    umask 077
    mkdir -p "$BACKUPS" && chmod 700 "$BACKUPS" || fail "cannot create $BACKUPS"
    find "$BACKUPS" -maxdepth 1 \( -name '.new-*' -o -name '*.part' \) -mmin +120 -delete 2>/dev/null          # what an earlier run left when it was stopped half way
    local free
    free=$(df -Pk "$BACKUPS" 2>/dev/null | awk 'NR==2 {print $4}')
    if [ -n "${free:-}" ] && [ "$free" -lt "$MIN_FREE_KB" ]; then
        fail "less than $(( MIN_FREE_KB / 1024 )) MB free where $BACKUPS is ($(( free / 1024 )) MB): free some space first (nothing was copied)"
    fi
}

# keep the newest $2 files that match the pattern $1 in $BACKUPS
prune() {
    local pattern=$1 keep=$2 old
    old=$(cd "$BACKUPS" && ls -1t -- $pattern 2>/dev/null | tail -n +"$(( keep + 1 ))")
    [ -z "$old" ] && return 0
    while IFS= read -r f; do
        rm -f -- "$BACKUPS/$f" && say "   removed the old copy $f"
    done <<< "$old"
}

# ---------------------------------------------------------------- the database
do_now() {
    ready
    local stamp tmp copy
    stamp=$(date +%Y%m%d-%H%M%S)
    tmp="/tmp/lp-backup-$stamp.db"
    copy="$BACKUPS/.new-$stamp.db"
    docker exec "$NAME" python -c "
import os, sqlite3
src = sqlite3.connect(os.path.join(os.environ.get('INSTANCE_DIR', '/srv/instance'), 'app.db'))
dst = sqlite3.connect('$tmp')
src.backup(dst)
dst.close()
src.close()" || fail "the copy of the database failed (nothing was saved)"
    docker cp "$NAME:$tmp" "$copy" || { docker exec "$NAME" rm -f "$tmp"; fail "could not take the copy out of the container (nothing was saved)"; }
    docker exec "$NAME" rm -f "$tmp"
    local report
    report=$(python3 -c '
import sqlite3, sys
c = sqlite3.connect(sys.argv[1])
if c.execute("PRAGMA quick_check").fetchone()[0] != "ok":
    sys.exit("the copy does not pass SQLite quick_check")
n = lambda t: c.execute("select count(*) from " + t).fetchone()[0]
print("users %d | lessons %d | students %d | classes %d" % (n("users"), n("lessons"), n("students"), n("classes")))' "$copy") \
        || { rm -f -- "$copy"; fail "the copy of the database cannot be read (nothing was saved)"; }
    local final="$BACKUPS/app-$stamp.db.gz"
    gzip -9 -c -- "$copy" > "$final.part" && gzip -t -- "$final.part" && mv -- "$final.part" "$final" \
        || { rm -f -- "$copy" "$final.part"; fail "could not compress the copy (nothing was saved)"; }
    rm -f -- "$copy"
    chmod 600 "$final"
    say "saved $final ($(du -h -- "$final" | cut -f1)) | $report"
    prune "app-[0-9]*-[0-9]*.db.gz" "$KEEP_DB"
}

# ---------------------------------------------------------------- the uploaded files
do_files() {
    ready
    local stamp tmp copy
    stamp=$(date +%Y%m%d-%H%M%S)
    tmp="/tmp/lp-files-$stamp.tgz"
    copy="$BACKUPS/files-$stamp.tgz"
    local size_mb
    size_mb=$(docker exec "$NAME" python -c "
import os
root = os.path.join(os.environ.get('INSTANCE_DIR', '/srv/instance'), 'uploads')
print(sum(os.path.getsize(os.path.join(d, f)) for d, _, fs in os.walk(root) for f in fs) // 1048576)") || fail "could not measure the uploaded files (nothing was saved)"
    local free
    free=$(df -Pk "$BACKUPS" 2>/dev/null | awk 'NR==2 {print $4}')
    if [ -n "${free:-}" ] && [ "$free" -lt $(( size_mb * 1024 * 2 + MIN_FREE_KB )) ]; then
        fail "the uploaded files are $size_mb MB and there is not enough free disk for a copy (nothing was saved)"
    fi
    docker exec "$NAME" python -c "
import os, tarfile
root = os.path.join(os.environ.get('INSTANCE_DIR', '/srv/instance'), 'uploads')
with tarfile.open('$tmp', 'w:gz') as t:
    t.add(root, arcname='uploads')" || fail "the copy of the files failed (nothing was saved)"
    docker cp "$NAME:$tmp" "$copy.part" || { docker exec "$NAME" rm -f "$tmp"; fail "could not take the files out of the container (nothing was saved)"; }
    docker exec "$NAME" rm -f "$tmp"
    gzip -t -- "$copy.part" && mv -- "$copy.part" "$copy" || { rm -f -- "$copy.part"; fail "the copy of the files cannot be read (nothing was saved)"; }
    chmod 600 "$copy"
    say "saved $copy ($(du -h -- "$copy" | cut -f1), $size_mb MB of files, $(tar -tzf "$copy" | grep -vc '/$') of them)"
    prune "files-[0-9]*-[0-9]*.tgz" "$KEEP_FILES"
}

# ---------------------------------------------------------------- asking cron
do_install() {
    command -v crontab >/dev/null || fail "crontab not found: install cron first (apt-get install cron), nothing was changed"
    mkdir -p "$(dirname "$INSTALLED")" || fail "cannot create $(dirname "$INSTALLED")"
    if [ "$SELF" != "$INSTALLED" ]; then
        cp -- "$SELF" "$INSTALLED" && chmod 700 "$INSTALLED" || fail "could not copy the script to $INSTALLED"
    fi
    mkdir -p "$BACKUPS" && chmod 700 "$BACKUPS"
    local current
    current=$(crontab -l 2>/dev/null | grep -v -F "$MARK" || true)
    {
        [ -n "$current" ] && printf '%s\n' "$current"
        echo "30 3 * * * $INSTALLED now >> $BACKUPS/backup.log 2>&1 $MARK"
        echo "50 3 * * 5 $INSTALLED files >> $BACKUPS/backup.log 2>&1 $MARK"
    } | crontab - || fail "cron did not accept the lines (nothing was changed)"
    say "installed: a copy of the database every day at 03:30 and of the files every Friday at 03:50 (server time), kept in $BACKUPS"
    say "to stop it: bash $INSTALLED remove"
}

do_remove() {
    command -v crontab >/dev/null || fail "crontab not found"
    local current
    current=$(crontab -l 2>/dev/null || true)
    if ! printf '%s\n' "$current" | grep -q -F "$MARK"; then
        say "there is nothing of ours in cron"
        return 0
    fi
    { printf '%s\n' "$current" | grep -v -F "$MARK" || true; } | crontab - || fail "cron did not accept the change"
    say "removed: no more automatic copies. The copies in $BACKUPS stay."
}

do_list() {
    echo "== cron"
    if command -v crontab >/dev/null && crontab -l 2>/dev/null | grep -F "$MARK"; then :; else echo "   not installed (bash $SELF install)"; fi
    echo "== $BACKUPS"
    if [ -d "$BACKUPS" ]; then
        ls -lh --time-style='+%F %T' -- "$BACKUPS" 2>/dev/null | awk 'NR>1 && $NF != "backup.log" {printf "   %s %s  %6s  %s\n", $6, $7, $5, $NF}'
        local newest
        newest=$(cd "$BACKUPS" && ls -1t -- app-[0-9]*-[0-9]*.db.gz 2>/dev/null | head -1)
        if [ -n "$newest" ]; then
            if gzip -t -- "$BACKUPS/$newest" 2>/dev/null; then echo "== the newest copy of the database ($newest) can be read"; else echo "!! the newest copy of the database ($newest) is damaged"; fi
        else
            echo "== no copy of the database yet (bash $SELF now)"
        fi
        if [ -f "$BACKUPS/backup.log" ]; then
            echo "== the end of backup.log"
            tail -n 5 -- "$BACKUPS/backup.log" | sed 's/^/   /'
        fi
    else
        echo "   the folder does not exist yet"
    fi
}

case "${1:-}" in
    now)     do_now ;;
    files)   do_files ;;
    install) do_install ;;
    remove)  do_remove ;;
    list)    do_list ;;
    *)       sed -n '5,10p' "$SELF" | sed 's/^# \{0,1\}//'; exit 2 ;;
esac
