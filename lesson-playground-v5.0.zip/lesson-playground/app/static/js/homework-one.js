// The page of one homework: its words, the messages for the class's WhatsApp group, and who did it (tap a student's state; tap it again to clear it). Everything is kept on the server;
// the page shows what the server says and asks it to change, and a tap is shown at once and saved in order.
(function () {
  const root = document.getElementById('hw1-app'), AID = Number(root.dataset.id), API = '/api/homework/' + AID;
  const $ = id => document.getElementById(id);
  const say = (id, text) => { const n = $(id); n.textContent = text || ''; n.hidden = !text; };
  const btn = (text, cls, fn) => { const b = el('button', {type: 'button', class: 'btn ' + cls, text}); b.addEventListener('click', fn); return b; };
  let A = null, classes = [], shareData = null, queue = Promise.resolve(), inflight = 0, EK = 'homework', rows = new Map(), WHO = new Map(), liveTimer = null;

  // ------------------------------------------------------------ start
  async function start() {
    try {
      const [r, c] = await Promise.all([api('GET', API), api('GET', '/api/classes')]);
      A = r.assignment; classes = c.classes || [];
    } catch (e) { return say('hw1-load-err', e.message); }
    $('hw1-main').hidden = false;
    renderAll(); loadShare();
    $('hw1-form').addEventListener('submit', saveEdit);
    $('hw1-rest-done').addEventListener('click', () => rest('done'));
    $('hw1-rest-partial').addEventListener('click', () => rest('partial'));
    $('hw1-rest-missing').addEventListener('click', () => rest('missing'));
    $('hw1-print').addEventListener('click', printSheet);
    $('hw1-who-all').addEventListener('click', () => { for (const s of WHO.values()) s.on = true; drawWho(true); });
    $('hw1-who-none').addEventListener('click', () => { for (const s of WHO.values()) s.on = false; drawWho(true); });
    $('hw1-who-save').addEventListener('click', saveWho);
    $('hw1-close').addEventListener('click', toggleClosed);
    $('hw1-copy').addEventListener('click', copyTo);
    $('hw1-del').addEventListener('click', remove);
    try {
      const k = 'lp-hw-new-' + AID;
      if (sessionStorage.getItem(k)) { sessionStorage.removeItem(k); say('hw1-fresh', 'تم حفظ الواجب ✓ رسالة واتساب جاهزة في البطاقة التالية: انسخيها أو افتحي واتساب بها، ثم أرسليها بنفسكِ.'); }
    } catch (e) {}
  }
  function renderAll() { drawHead(); drawTrack(); drawEdit(); drawWho(false); drawMore(); drawSheet(); }
  async function reload() {
    try { A = (await api('GET', API)).assignment; renderAll(); if (shareData) drawWa(); } catch (e) { say('hw1-err', e.message); }
  }
  function live(text, bad) {
    const n = $('hw1-live');
    n.textContent = text; n.hidden = !text; n.classList.toggle('bad', !!bad);
    clearTimeout(liveTimer);
    if (text) liveTimer = setTimeout(() => { n.hidden = true; }, 12000);
  }

  // ------------------------------------------------------------ the head
  function drawHead() {
    const meta = [A.class && A.class.name, A.subject && A.subject.name, 'أُعطي ' + A.given_text, A.due ? 'التسليم ' + A.due_text : 'بلا موعد تسليم'].filter(Boolean);
    $('hw1-head').replaceChildren(
      el('div', {class: 'hw-badges'}, el('span', {class: 'badge', text: A.icon + ' ' + A.kind_name}), hw.dueBadge(A), A.closed ? el('span', {class: 'badge st-ok', text: 'منتهٍ'}) : null),
      el('h1', {text: A.title}), el('p', {class: 'hw-meta', text: meta.join(' · ')}),
      el('div', {class: 'hw-instr-box'}, el('h3', {text: 'المطلوب'}), el('p', {class: 'hw-instr', text: A.instructions})));
    document.title = A.title + ' · ملعب الدرس';
  }

  // ------------------------------------------------------------ the messages for WhatsApp
  async function loadShare() {
    try { if (!shareData) shareData = await api('GET', API + '/share'); }
    catch (e) { return $('hw1-wa').replaceChildren(el('p', {class: 'note bad', role: 'alert', text: e.message})); }
    drawWa();
  }
  function drawWa() {
    const d = shareData, host = $('hw1-wa');
    const block = (title, text, wa, note, tooLong) => {
      const copy = btn('📋 نسخ النص', 'ghost small', () => hw.copyText(text, copy));
      return el('div', {class: 'hw-share-box'}, el('h4', {text: title}), el('pre', {class: 'hw-msg', text}),
        note ? el('p', {class: 'muted', text: note}) : null, tooLong ? el('p', {class: 'note warn', text: 'الرسالة أطول من أن تُفتح في رابط واتساب؛ انسخيها والصقيها في المحادثة.'}) : null,
        el('div', {class: 'btn-row'}, copy, wa && !tooLong ? el('a', {class: 'btn small sun', href: wa, target: '_blank', rel: 'noopener noreferrer', text: '💬 فتح واتساب بالنص'}) : null));
    };
    host.replaceChildren(...[
      el('p', {class: 'muted', text: 'لا يُرسل التطبيق شيئًا بنفسه: تنسخين النص أو تفتحين واتساب والنص جاهز، ثم تضغطين «إرسال» بنفسكِ.'}),
      d.for_some ? el('p', {class: 'note warn', text: 'هذا الواجب لبعض طلاب الفصل فقط، والمجموعة كلها ستقرأ الرسالة. إن أردتِ إبلاغهم وحدهم فأرسلي النص لهم على الخاص.'}) : null,
      block('رسالة الإعلان', d.announce, d.announce_wa, 'فيها العنوان والمطلوب والموعد، وليس فيها أسماء طلاب ولا أرقام.', d.announce_too_long),
      A.closed ? null : block('رسالة تذكير', d.reminder, d.reminder_wa, 'ترسلينها قبل الموعد أو بعده لمن لم يسلّم؛ وليس فيها أسماء أيضًا.'),
      d.group ? el('div', {class: 'btn-row'}, el('a', {class: 'btn small ghost', href: d.group, target: '_blank', rel: 'noopener noreferrer', text: 'فتح مجموعة واتساب الفصل'}))
        : el('p', {class: 'muted', text: 'لم يُضَف رابط مجموعة واتساب لهذا الفصل. أضيفيه من صفحة الطلاب فيظهر هنا زر فتح المجموعة.'})].filter(Boolean));          // (replaceChildren would write a null as the word «null»)
  }

  // ------------------------------------------------------------ who did it
  function recount() {
    const s = {total: A.students.length, done: 0, partial: 0, missing: 0, pending: 0};
    for (const st of A.students) s[st.status]++;
    s.checked = s.total - s.pending; s.percent = s.total ? Math.round(100 * s.done / s.total) : null;          // (the half rounds up, as the server does: textfmt.percent)
    A.stats = s;
  }
  function drawTrack() {
    drawSummary();
    const list = $('hw1-students');
    rows = new Map();
    list.replaceChildren(...A.students.map(st => {
      const buttons = hw.ORDER.map(k => {
        const b = el('button', {type: 'button', class: 'hw-st ' + k, text: hw.MARKS[k] + ' ' + hw.SHORT[k]});
        b.addEventListener('click', () => tap(st, k));
        return b;
      });
      const li = el('li', {class: 'hw-student'}, el('span', {class: 'hw-name', text: st.name}), el('div', {class: 'hw-btns', role: 'group', 'aria-label': 'حالة ' + st.name}, ...buttons));
      rows.set(st.student_id, {li, buttons});
      paintRow(st);
      return li;
    }));
  }
  function paintRow(st) {
    const r = rows.get(st.student_id);
    if (!r) return;
    r.li.dataset.status = st.status;
    hw.ORDER.forEach((k, i) => { r.buttons[i].setAttribute('aria-pressed', st.status === k ? 'true' : 'false'); r.buttons[i].setAttribute('aria-label', st.name + ': ' + hw.NAMES[k]); });
  }
  function drawSummary() {
    const s = A.stats, tile = (v, l, n) => el('div', {class: 'stat-tile'}, el('b', {text: String(v)}), el('span', {text: l}), n ? el('small', {text: n}) : null);
    $('hw1-sub').textContent = [A.class && A.class.name, s.total ? arS(s.total) : ''].filter(Boolean).join(' · ');
    $('hw1-nobody').hidden = s.total > 0;
    $('hw1-tiles').hidden = !s.total; $('hw1-meter').hidden = !s.total; $('hw1-legend').hidden = !s.total; $('hw1-rest').hidden = !s.total;
    if (!s.total) return;
    $('hw1-tiles').replaceChildren(tile(s.done, hw.NAMES.done, s.percent != null ? s.percent + '٪ من ' + arS(s.total) : null), tile(s.partial, hw.NAMES.partial),
      tile(s.missing, hw.NAMES.missing), tile(s.pending, hw.NAMES.pending, s.pending ? null : 'سُجّل الجميع'));
    $('hw1-meter').replaceChildren(...hw.meter(s).childNodes); $('hw1-meter').setAttribute('aria-label', hw.statsLine(s));
    for (const id of ['hw1-rest-done', 'hw1-rest-partial', 'hw1-rest-missing']) $(id).disabled = !s.pending;
    $('hw1-rest-label').textContent = s.pending ? 'من لم تسجّلي له بعد (' + s.pending + '):' : 'سُجّلت حالة كل الطلاب.';
  }
  function tap(st, key) {
    const next = st.status === key ? 'pending' : key;
    st.status = next; paintRow(st); recount(); drawSummary(); say('hw1-err', '');
    inflight++;
    queue = queue.then(() => api('PUT', API + '/status', {items: [{student_id: st.student_id, status: next}]})).then(r => {
      inflight--;
      if (!inflight) { A.stats = r.assignment.stats; drawSummary(); drawSheet(); }          // when nothing else is waiting, what the server counted is the figure shown
    }, async e => {
      inflight--;
      say('hw1-err', e.message + ' — أعدنا عرض ما هو محفوظ.');
      await reload();
    });
  }
  async function rest(status) {
    await queue;
    const ids = ['hw1-rest-done', 'hw1-rest-partial', 'hw1-rest-missing'];
    for (const id of ids) $(id).disabled = true;
    say('hw1-err', '');
    try { A = (await api('POST', API + '/rest', {status})).assignment; renderAll(); }
    catch (e) { say('hw1-err', e.message); drawSummary(); }
  }

  // ------------------------------------------------------------ the sheet to print
  function drawSheet() {
    const meta = [A.class && A.class.name, A.subject && A.subject.name, 'أُعطي ' + A.given_text, A.due ? 'التسليم ' + A.due_text : ''].filter(Boolean).join(' · ');
    const head = el('tr', {}, el('th', {text: '#'}), el('th', {class: 'nm', text: 'الطالب'}), ...hw.ORDER.map(k => el('th', {text: hw.NAMES[k]})));
    const body = A.students.map((st, i) => el('tr', {}, el('td', {text: String(i + 1)}), el('td', {class: 'nm', text: st.name}), ...hw.ORDER.map(k => el('td', {class: 'bx'}, el('span', {class: 'hw-box', text: st.status === k ? '✓' : ''})))));
    $('hw1-sheet').replaceChildren(...[el('h1', {text: A.icon + ' ' + A.title}), el('p', {class: 'sheet-sub', text: meta}), el('p', {class: 'hw-sheet-instr', text: A.instructions}),
      A.students.length ? el('table', {class: 'hw-sheet-table'}, el('thead', {}, head), el('tbody', {}, ...body)) : null].filter(Boolean));
  }
  function printSheet() {
    document.body.classList.add('print-hw');
    const done = () => { document.body.classList.remove('print-hw'); window.removeEventListener('afterprint', done); };
    window.addEventListener('afterprint', done);
    window.print();
    setTimeout(done, 1500);
  }

  // ------------------------------------------------------------ changing it
  function drawEdit() {
    EK = A.kind;
    drawEditKinds();
    $('hw1-title').value = A.title; $('hw1-topic').value = A.topic || ''; $('hw1-text').value = A.instructions; $('hw1-due').value = A.due || ''; $('hw1-due').min = A.given;
  }
  function drawEditKinds() { $('hw1-kinds').replaceChildren(...A.kinds.map(k => hw.chip(k.icon + ' ' + k.name, k.key === EK, () => { EK = k.key; drawEditKinds(); }))); }
  async function saveEdit(ev) {
    ev.preventDefault();
    say('hw1-edit-err', '');
    const go = ev.target.querySelector('button[type=submit]');
    go.disabled = true;
    try {
      await queue;
      A = (await api('PATCH', API, {kind: EK, title: $('hw1-title').value, topic: $('hw1-topic').value, instructions: $('hw1-text').value, due: $('hw1-due').value})).assignment;
      shareData = null; renderAll(); loadShare();
      go.textContent = 'تم الحفظ ✓'; setTimeout(() => { go.textContent = 'حفظ التعديل'; }, 2200);
    } catch (e) { say('hw1-edit-err', e.message); }
    go.disabled = false;
  }

  // the students it is for
  function drawWho(keep) {
    if (!keep) {
      const all = [...A.students.map(s => ({id: s.student_id, name: s.name, on: true, status: s.status})), ...A.others.map(s => ({id: s.id, name: s.name, on: false, status: 'pending'}))];
      all.sort((a, b) => a.name.localeCompare(b.name, 'ar'));
      WHO = new Map(all.map(s => [s.id, s]));
    }
    $('hw1-checks').replaceChildren(...[...WHO.values()].map(s => {
      const box = el('input', {type: 'checkbox', value: String(s.id)});
      box.checked = s.on;
      box.addEventListener('change', () => { s.on = box.checked; paintWho(); });
      return el('li', {}, el('label', {}, box, el('span', {text: s.name}), s.on && s.status !== 'pending' ? el('small', {class: 'muted', text: hw.NAMES[s.status]}) : null));
    }));
    paintWho();
  }
  function paintWho() { $('hw1-who-n').textContent = 'تم اختيار ' + [...WHO.values()].filter(s => s.on).length + ' من ' + WHO.size; }
  async function saveWho() {
    say('hw1-who-err', '');
    const on = [...WHO.values()].filter(s => s.on), losing = [...WHO.values()].filter(s => !s.on && s.status !== 'pending');
    if (!on.length) return say('hw1-who-err', 'اختاري طالبًا واحدًا على الأقل.');
    if (losing.length && !confirm('إزالة ' + arS(losing.length) + ' من الواجب تحذف ما سجّلتِه لهم فيه. متابعة؟')) return;
    try { await queue; A = (await api('PATCH', API, {students: on.map(s => s.id)})).assignment; renderAll(); live('تم حفظ قائمة الطلاب ✓'); }
    catch (e) { say('hw1-who-err', e.message); }
  }

  // ------------------------------------------------------------ ending, copying, deleting
  function drawMore() {
    $('hw1-close').textContent = A.closed ? '↩ إعادة فتح الواجب' : '✔ إنهاء الواجب';
    $('hw1-close-note').textContent = A.closed ? 'الواجب المنتهي لا يظهر في «الحالية» ولا ينبَّه إليه في الشاشة الرئيسية، وحالات طلابه محفوظة.' : 'عند إنهائه يخرج من «الحالية» ولا ينبَّه إليه في الشاشة الرئيسية، وتبقى حالات طلابه محفوظة ويمكن إعادة فتحه.';
    const sel = $('hw1-copy-class'), keep = sel.value;
    sel.replaceChildren(...classes.map(c => el('option', {value: String(c.id), text: c.name + (A.class && c.id === A.class.id ? ' (هذا الفصل)' : '')})));
    const other = classes.find(c => !A.class || c.id !== A.class.id);
    sel.value = keep && classes.some(c => String(c.id) === keep) ? keep : String(other ? other.id : (A.class ? A.class.id : ''));
  }
  async function toggleClosed() {
    const b = $('hw1-close');
    b.disabled = true;
    try { await queue; A = (await api('PATCH', API, {closed: !A.closed})).assignment; renderAll(); if (shareData) drawWa(); }
    catch (e) { live(e.message, true); }
    b.disabled = false;
  }
  async function copyTo() {
    const b = $('hw1-copy'), cid = Number($('hw1-copy-class').value);
    if (!cid) return;
    b.disabled = true;
    try {
      const r = (await api('POST', API + '/copy', {class_id: cid})).assignment, n = $('hw1-live');
      n.replaceChildren('تم إنشاء نسخة للفصل «' + (r.class ? r.class.name : '') + '». ', el('a', {class: 'btn small', href: '/homework/' + r.id, text: 'فتح الواجب الجديد'}));
      n.hidden = false; n.classList.remove('bad');
    } catch (e) { live(e.message, true); }
    b.disabled = false;
  }
  async function remove() {
    if (!confirm('حذف «' + A.title + '» مع حالات طلابه؟ لا يمكن التراجع عن ذلك.')) return;
    const b = $('hw1-del');
    b.disabled = true;
    try { await queue; await api('DELETE', API); location.href = '/homework'; }
    catch (e) { b.disabled = false; live(e.message, true); }
  }

  start();
})();
