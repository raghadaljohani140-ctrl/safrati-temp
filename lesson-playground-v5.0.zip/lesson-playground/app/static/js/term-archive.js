// The page of a term that was closed: its summary exactly as it was that day (kept in the archive, so it does not change when her classes do), to read, print or export.
(function () {
  const T = window.TM, $ = id => document.getElementById(id), id = document.getElementById('tm-root').dataset.archive;
  api('GET', '/api/term/archives/' + id).then(a => {
    $('tm-loading').hidden = true;
    const s = a.summary;
    if (!s || !s.classes) return T.say('tm-err', 'ملخص هذا الفصل غير متاح.');
    $('tm-sum-title').textContent = 'حصيلة ' + a.name;
    $('tm-sum-range').textContent = a.starts_text + ' ← ' + a.ends_text;
    $('tm-closed').textContent = 'أُنهي هذا الفصل في ' + a.closed_text + '.';
    $('tm-print-line').textContent = 'ملعب الدرس · حصيلة ' + a.name + ' (مؤرشف) · ' + a.starts_text + ' ← ' + a.ends_text;
    T.mount($('tm-summary'), s, {csv: '/api/term/archives/' + a.id + '/csv'});
    $('tm-csv').href = '/api/term/archives/' + a.id + '/csv';
    $('tm-summary-card').hidden = false;
  }).catch(e => { $('tm-loading').hidden = true; T.say('tm-err', e.message); });
})();
