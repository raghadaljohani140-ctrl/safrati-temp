// shared helpers: fetch with the form-check token
window.api = async function (method, url, data) {
  const token = document.querySelector('meta[name=csrf]').content;
  const res = await fetch(url, {method, headers: {'Content-Type': 'application/json', 'X-CSRF': token}, body: data === undefined ? undefined : JSON.stringify(data), credentials: 'same-origin'});
  let json = {};
  try { json = await res.json(); } catch (e) {}
  if (!res.ok) { const err = new Error(json.error || 'حدث خطأ، حاولي مرة أخرى'); err.status = res.status; throw err; }
  return json;
};
// a file goes up as a form (the browser sets the boundary itself), with the same check token
window.apiUpload = async function (url, file, extra) {
  const token = document.querySelector('meta[name=csrf]').content, fd = new FormData();
  fd.append('file', file);
  for (const [k, v] of Object.entries(extra || {})) fd.append(k, v);
  const res = await fetch(url, {method: 'POST', headers: {'X-CSRF': token}, body: fd, credentials: 'same-origin'});
  let json = {};
  try { json = await res.json(); } catch (e) {}
  if (!res.ok) { const err = new Error(json.error || 'حدث خطأ، حاولي مرة أخرى'); err.status = res.status; throw err; }
  return json;
};
window.el = function (tag, attrs, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === 'class') n.className = v; else if (k === 'text') n.textContent = v; else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
    else if (v === true) n.setAttribute(k, ''); else if (v !== false && v != null) n.setAttribute(k, v);
  }
  for (const kid of kids.flat()) if (kid != null) n.append(kid.nodeType ? kid : document.createTextNode(kid));
  return n;
};
// counting in Arabic: سؤال واحد، سؤالان، 3 أسئلة، 11 سؤالًا (forms: [one, two, few, many]; the same rule as app/textfmt.py)
window.arCount = function (n, forms) { n = Number(n) || 0; return n === 1 ? forms[0] : n === 2 ? forms[1] : (n >= 3 && n <= 10) || n === 0 ? n + ' ' + forms[2] : n + ' ' + forms[3]; };
window.arQ = n => window.arCount(n, ['سؤال واحد', 'سؤالان', 'أسئلة', 'سؤالًا']);
window.arS = n => window.arCount(n, ['طالب واحد', 'طالبان', 'طلاب', 'طالبًا']);
window.arP = n => window.arCount(n, ['نقطة واحدة', 'نقطتان', 'نقاط', 'نقطة']);
// marks the way a paper says them: درجة واحدة، درجتان، 3 درجات، درجة ونصف، نصف درجة (the same rule as textfmt.marks)
window.arMarks = function (x) { x = Number(x) || 0; const w = Math.floor(x), half = x - w >= 0.5; if (!half) return window.arCount(w, ['درجة واحدة', 'درجتان', 'درجات', 'درجة']); return w === 0 ? 'نصف درجة' : window.arCount(w, ['درجة', 'درجتان', 'درجات', 'درجة']) + ' ونصف'; };
// «طباعة / حفظ PDF» buttons (the pages forbid inline handlers): the browser prints, and it shapes the Arabic itself, so the letters stay joined in the PDF
document.addEventListener('click', e => { if (e.target.closest && e.target.closest('[data-print]')) window.print(); });
// a small − 3 + control for a count (periods of a lesson, periods in a day): on(value) is told each change
window.stepper = function (value, min, max, on, label) {
  let v = Math.min(max, Math.max(min, Number(value) || min));
  const out = el('output', {class: 'stp-v', text: String(v)});
  const minus = el('button', {type: 'button', class: 'ib', text: '−', 'aria-label': 'أقل'}), plus = el('button', {type: 'button', class: 'ib', text: '+', 'aria-label': 'أكثر'});
  const paint = () => { out.textContent = String(v); minus.disabled = v <= min; plus.disabled = v >= max; };
  const set = n => { v = Math.min(max, Math.max(min, n)); paint(); on(v); };
  minus.addEventListener('click', () => set(v - 1)); plus.addEventListener('click', () => set(v + 1)); paint();
  return el('span', {class: 'stepper', role: 'group', 'aria-label': label || 'العدد'}, minus, out, plus);
};
