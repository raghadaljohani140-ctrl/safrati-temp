(function () {
  const hj = document.getElementById('hub-hijri');
  if (hj) { try { hj.textContent = '· ' + new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', {day: 'numeric', month: 'long', year: 'numeric'}).format(new Date()); } catch (e) {} }
  // today's periods from her timetable, each with the lesson her plan puts in it
  const dayCard = document.getElementById('day-card');
  if (dayCard) api('GET', '/api/today').then(d => {
    if (!d.periods.length) return;
    const list = document.getElementById('day-list'), sub = document.getElementById('day-sub');
    const when = t => t ? [el('bdi', {class: 'tm', text: t}), ' · '] : [];          // the clock times read left to right even inside an Arabic line
    sub.textContent = d.off ? 'اليوم «' + d.off + '»: لا دروس تُحتسب في الخطة.' : d.absent_day ? 'سجّلتِ غيابك اليوم: لا دروس تُحتسب في الخطة، وأُعيد توزيعها على الحصص القادمة.'
      : arCount(d.periods.length, ['حصة واحدة', 'حصتان', 'حصص', 'حصة']) + ' في جدولك اليوم.';
    d.periods.forEach(p => {
      const q = '?class=' + p.class_id + '&subject=' + p.subject_id, who = el('div', {class: 'who'}, el('b', {text: p.class_name + ' · ' + p.subject_name}));
      const acts = el('div', {class: 'acts'});
      const l = p.lesson;
      if (p.state === 'done' && l) { who.append(el('small', {text: 'أُنجز: ' + l.title + ' ✓'})); acts.append(el('a', {class: 'btn small ghost', href: '/plan' + q, text: 'الخطة'})); }
      else if (p.state === 'past') who.append(el('small', {}, ...when(p.time), 'انتهت'));
      else if (p.state === 'absent') { who.append(el('small', {}, ...when(p.time), '🚪 غياب مسجَّل · لن تُقام')); acts.append(el('a', {class: 'btn small ghost', href: '/absent', text: 'غياباتي'})); }
      else if (l) {
        who.append(el('small', {}, ...when(p.time), '📖 ' + l.title + (l.late ? ' (متأخر)' : '')));
        acts.append(l.lesson_id ? el('a', {class: 'btn small sun', href: '/start' + q + '&lesson=' + l.lesson_id, text: 'ابدئي ▶'}) : el('a', {class: 'btn small', href: '/plan' + q, text: 'افتحي الخطة'}));
      } else {
        who.append(el('small', {}, ...when(p.time), d.off ? d.off : 'لا درس مخطَّط لهذه الحصة'));
        if (!d.off) acts.append(el('a', {class: 'btn small ghost', href: '/plan' + q, text: 'الخطة'}));
      }
      list.append(el('li', {class: 'day-p ' + p.state}, el('span', {class: 'no', text: String(p.period)}), who, acts));
    });
    dayCard.hidden = false;
  }).catch(() => {});
  const file = document.getElementById('lesson-file');
  const form = document.querySelector('.upload-form');
  if (file) {
    file.addEventListener('change', () => {
      const f = file.files[0];
      if (!f) return;
      const max = Number(form.dataset.maxMb) * 1024 * 1024;
      document.getElementById('drop-name').textContent = f.name;
      if (f.size > max) { alert('الملف كبير، الحد الأقصى ' + form.dataset.maxMb + ' ميجابايت'); file.value = ''; document.getElementById('drop-name').textContent = 'اختاري ملف الدرس من جهازك'; }
    });
    form.addEventListener('submit', () => { const b = document.getElementById('upload-btn'); b.disabled = true; b.textContent = 'جارٍ الرفع…'; });
  }
  document.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', async () => {
    if (!confirm(b.dataset.ask)) return;
    try { await api('DELETE', b.dataset.del); location.reload(); } catch (e) { alert(e.message); }
  }));
  const consent = document.getElementById('ai-consent');
  if (consent) consent.addEventListener('change', async () => { try { await api('POST', '/api/me/consent', {ai_consent: consent.checked}); } catch (e) { alert(e.message); } });
  const del = document.getElementById('del-account');
  if (del) del.addEventListener('submit', async ev => {
    ev.preventDefault();
    if (!confirm('سيُحذف حسابك وكل ما فيه نهائيًا. متأكدة؟')) return;
    try { await api('POST', '/api/me/delete', {password: del.password.value}); location.href = '/'; }
    catch (e) { const n = document.getElementById('del-err'); n.textContent = e.message; n.hidden = false; }
  });
})();
