// «الأنشطة والواجبات»: what she gave her classes, and the quick form that makes a new one (class, subject, kind, what is asked, the day it is due, who it is for).
// The message for the class's WhatsApp group and the ticks of who did it are on the assignment's own page (homework-one.js). Everything is kept on the server.
(function () {
  const $ = id => document.getElementById(id);
  const say = (id, text) => { const n = $(id); n.textContent = text || ''; n.hidden = !text; };
  const MAX_TEXT = 1500;
  let classes = [], items = [], kinds = [], today = '', maxDays = 400, attention = 0, tab = 'open', filter = 0, students = null, infoToken = 0, lessons = [];
  const F = {cls: 0, sub: 0, kind: 'homework', due: '', dueTouched: false, who: 'all', picked: new Set(), next: null};
  const classOf = id => classes.find(c => c.id === id) || null;
  const chip = hw.chip;

  // ------------------------------------------------------------ start
  async function start() {
    try {
      const [c, l] = await Promise.all([api('GET', '/api/classes'), api('GET', '/api/homework')]);
      classes = c.classes || []; items = l.assignments || []; kinds = l.kinds || []; today = l.today; maxDays = l.max_days || 400; attention = l.attention || 0;
    } catch (e) { return say('hw-load-err', e.message); }
    if (!classes.length) { $('hw-none').hidden = false; return; }
    $('hw-main').hidden = false;
    $('hw-due').min = today; $('hw-due').max = hw.addDays(today, maxDays);
    drawTabs(); drawList();
    $('hw-new').addEventListener('click', () => ($('hw-form').hidden ? openForm() : closeForm()));
    $('hw-cancel').addEventListener('click', closeForm);
    $('hw-form').addEventListener('submit', submit);
    $('hw-form').addEventListener('input', () => say('hw-err', ''));
    $('hw-form').addEventListener('click', e => { if (e.target.closest('.chip-btn, input[type=checkbox], .btn')) say('hw-err', ''); });
    $('hw-text').addEventListener('input', countText);
    $('hw-due').addEventListener('change', () => { F.due = $('hw-due').value; F.dueTouched = true; drawDue(); });
    $('hw-pick-all').addEventListener('click', () => { F.picked = new Set(studentsOf(F.cls).map(s => s.id)); drawChecks(); });
    $('hw-pick-none').addEventListener('click', () => { F.picked.clear(); drawChecks(); });
    $('hw-lesson').addEventListener('change', () => { const o = $('hw-lesson').selectedOptions[0]; if (o && o.value) $('hw-topic').value = o.dataset.title || ''; });
    const q = new URLSearchParams(location.search);
    if (q.get('new') || q.get('class_id') || !items.length) openForm(Number(q.get('class_id')) || 0, Number(q.get('subject_id')) || 0);
  }

  // ------------------------------------------------------------ the list
  function drawTabs() {
    const open = items.filter(a => !a.closed).length, closed = items.length - open;
    $('hw-tabs').replaceChildren(chip('الحالية (' + open + ')', tab === 'open', () => { tab = 'open'; drawTabs(); drawList(); }),
      chip('المنتهية (' + closed + ')', tab === 'closed', () => { tab = 'closed'; drawTabs(); drawList(); }));
    const withItems = classes.filter(c => items.some(a => a.class && a.class.id === c.id)), host = $('hw-filter');
    host.hidden = withItems.length < 2;
    host.replaceChildren(...(withItems.length < 2 ? [] : [chip('كل الفصول', !filter, () => { filter = 0; drawTabs(); drawList(); }),
      ...withItems.map(c => chip(c.name, filter === c.id, () => { filter = c.id; drawTabs(); drawList(); }))]));
    const due = items.filter(a => a.needs_review).length;
    say('hw-attn', due ? arCount(due, ['واجب واحد حلّ موعده ولم تسجّلي من أنجزه', 'واجبان حلّ موعدهما ولم تسجّلي من أنجزهما', 'واجبات حلّ موعدها ولم تسجّلي من أنجزها', 'واجبًا حلّ موعدها ولم تسجّلي من أنجزها']) : '');
  }
  function drawList() {
    $('hw-listcard').hidden = !items.length && !$('hw-form').hidden;          // the first time, the form alone: an empty list under it says nothing
    const shown = items.filter(a => (tab === 'closed') === a.closed && (!filter || (a.class && a.class.id === filter)));
    const empty = $('hw-empty');
    empty.hidden = shown.length > 0;
    empty.textContent = tab === 'closed' ? 'لا توجد واجبات منتهية بعد. الواجب الذي تنهينه من صفحته يظهر هنا.' : 'لا توجد واجبات حالية. اضغطي «+ جديد» لإعطاء أول واجب.';
    $('hw-list').replaceChildren(...shown.map(item));
  }
  function item(a) {
    const bits = [a.class && a.class.name, a.subject && a.subject.name, a.due ? 'التسليم ' + a.due_text : 'أُعطي ' + a.given_text].filter(Boolean);
    return el('li', {class: 'hw-item' + (a.needs_review ? ' needs' : '')},
      el('div', {class: 'hw-main'},
        el('div', {class: 'hw-title-line'}, el('a', {href: '/homework/' + a.id, text: a.icon + ' ' + a.title}), hw.dueBadge(a), a.closed ? el('span', {class: 'badge st-ok', text: 'منتهٍ'}) : null),
        el('small', {text: bits.join(' · ')}), a.stats.total ? hw.meter(a.stats) : null, el('small', {text: hw.statsLine(a.stats)})),
      el('div', {class: 'hw-acts'}, el('a', {class: 'btn small' + (a.needs_review ? ' sun' : ''), href: '/homework/' + a.id, text: a.needs_review ? 'سجّلي من أنجز' : 'فتح'})));
  }

  // ------------------------------------------------------------ the new one
  function openForm(cls, sub) {
    const f = $('hw-form');
    f.hidden = false;
    const last = items[0] && items[0].class ? items[0].class.id : 0;
    F.cls = classOf(cls) ? cls : (classOf(filter) ? filter : (classOf(F.cls) ? F.cls : (classOf(last) ? last : classes[0].id)));
    const subs = classOf(F.cls).subjects, prev = items.find(a => a.class && a.class.id === F.cls && a.subject);
    F.sub = sub && subs.some(s => s.id === sub) ? sub : (subs.some(s => s.id === F.sub) ? F.sub : (prev && subs.some(s => s.id === prev.subject.id) ? prev.subject.id : (subs[0] ? subs[0].id : 0)));
    if (!kinds.some(k => k.key === F.kind)) F.kind = 'homework';
    F.picked = new Set(); F.who = 'all';
    if (!F.dueTouched) F.due = hw.addDays(today, 1);
    drawPick(); drawKinds(); drawDue(); drawWho(); countText(); loadInfo();
    drawList();
    if (items.length) f.scrollIntoView({behavior: 'smooth', block: 'start'});
    $('hw-text').focus({preventScroll: true});
  }
  function closeForm() { $('hw-form').hidden = true; say('hw-err', ''); drawList(); }
  function countText() {
    const n = $('hw-text').value.length;
    $('hw-count').textContent = n ? n + ' من ' + MAX_TEXT + ' حرفًا' : '';
  }
  function drawPick() {
    const c = classOf(F.cls);
    $('hw-classes').replaceChildren(...classes.map(x => chip(x.name, x.id === F.cls, () => {
      if (x.id === F.cls) return;
      F.cls = x.id; F.sub = x.subjects[0] ? x.subjects[0].id : 0; F.picked = new Set(); F.next = null;
      drawPick(); drawWho(); loadInfo();
    })));
    const subs = c.subjects;
    $('hw-subjects').replaceChildren(...(subs.length ? subs.map(s => chip(s.name, s.id === F.sub, () => { F.sub = s.id; drawPick(); loadInfo(); })) : []),
      chip('بلا مادة', !F.sub, () => { F.sub = 0; drawPick(); loadInfo(); }));
  }
  function drawKinds() {
    $('hw-kinds').replaceChildren(...kinds.map(k => chip(k.icon + ' ' + k.name, k.key === F.kind, () => { F.kind = k.key; drawKinds(); })));
  }
  // the day it is due: the next lesson of the class (when the timetable knows it), tomorrow, in two days, in a week, or no day
  function drawDue() {
    const opts = [{label: 'غدًا', date: hw.addDays(today, 1)}, {label: 'بعد يومين', date: hw.addDays(today, 2)}, {label: 'بعد أسبوع', date: hw.addDays(today, 7)}];
    if (F.next) { const i = opts.findIndex(o => o.date === F.next.date); if (i >= 0) opts.splice(i, 1); opts.unshift({label: 'الحصة القادمة', date: F.next.date, small: F.next.text}); }
    opts.push({label: 'بلا موعد', date: ''});
    $('hw-due-chips').replaceChildren(...opts.map(o => chip(o.label, F.due === o.date, () => { F.due = o.date; F.dueTouched = true; drawDue(); }, o.small)));
    $('hw-due').value = F.due;
  }
  async function loadInfo() {
    const t = ++infoToken;
    let r = {lessons: [], book: null, next_lesson: null};
    try { r = await api('GET', '/api/homework/lessons?class_id=' + F.cls + (F.sub ? '&subject_id=' + F.sub : '')); } catch (e) {}
    if (t !== infoToken) return;                     // she changed the class again while this was coming
    F.next = r.next_lesson;
    if (!F.dueTouched) F.due = F.next ? F.next.date : hw.addDays(today, 1);
    lessons = r.lessons || [];
    drawDue(); drawLessons(r);
  }
  function drawLessons(r) {
    const sel = $('hw-lesson'), has = lessons.length > 0;
    sel.disabled = !has;
    const opts = [el('option', {value: '', text: has ? '— بلا درس محدد —' : 'لا كتاب لهذه المادة في هذا الفصل بعد'})];
    const groups = new Map();
    for (const l of lessons) { const k = l.unit || ''; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(l); }
    for (const [unit, list] of groups) {
      const os = list.map(l => el('option', {value: String(l.id), 'data-title': l.title, text: l.title + (l.done ? ' ✓' : '')}));
      opts.push(unit ? el('optgroup', {label: unit}, os) : os);
    }
    sel.replaceChildren(...opts.flat());
  }

  // the students: all of the class, or the ones she ticks
  const studentsOf = cid => (students || []).filter(s => s.class_id === cid);
  async function drawWho() {
    if (!students) {
      try { students = (await api('GET', '/api/students')).students || []; } catch (e) { students = []; }
    }
    const n = studentsOf(F.cls).length;
    $('hw-who').replaceChildren(chip('كل الفصل (' + n + ')', F.who === 'all', () => { F.who = 'all'; drawWho(); }), chip('طلاب محددون', F.who === 'some', () => { F.who = 'some'; drawWho(); }));
    $('hw-pick').hidden = F.who !== 'some';
    $('hw-nostudents').hidden = n > 0;
    if (F.who === 'some') drawChecks();
  }
  function drawChecks() {
    const list = studentsOf(F.cls);
    $('hw-checks').replaceChildren(...list.map(s => {
      const box = el('input', {type: 'checkbox', value: String(s.id)});
      box.checked = F.picked.has(s.id);
      box.addEventListener('change', () => { box.checked ? F.picked.add(s.id) : F.picked.delete(s.id); paintPicked(); });
      return el('li', {}, el('label', {}, box, el('span', {text: s.name})));
    }));
    paintPicked();
  }
  function paintPicked() { $('hw-picked').textContent = 'تم اختيار ' + F.picked.size + ' من ' + studentsOf(F.cls).length; }

  async function submit(ev) {
    ev.preventDefault();
    say('hw-err', '');
    const text = $('hw-text').value;
    if (text.trim().length < 3) { say('hw-err', 'اكتبي المطلوب من الطلاب'); $('hw-text').focus(); return; }
    if (F.who === 'some' && !F.picked.size) { say('hw-err', 'اختاري طالبًا واحدًا على الأقل، أو اختاري كل الفصل'); return; }
    const go = $('hw-go');
    go.disabled = true;
    try {
      const r = await api('POST', '/api/homework', {class_id: F.cls, subject_id: F.sub || null, kind: F.kind, instructions: text, due: F.due, topic: $('hw-topic').value, title: $('hw-title').value,
        students: F.who === 'all' ? 'all' : [...F.picked]});
      try { sessionStorage.setItem('lp-hw-new-' + r.assignment.id, '1'); } catch (e) {}
      location.href = '/homework/' + r.assignment.id;
    } catch (err) { say('hw-err', err.message); go.disabled = false; }
  }

  start();
})();
