// «المنهج»: the books she teaches from. A file is read in the background (the list shows how far it has come); a book is opened to be reviewed and confirmed.
(function () {
  const $ = id => document.getElementById(id);
  const app = $('cur-app');
  const maxMb = Number(app.dataset.maxMb) || 60;
  const say = (id, text) => { const n = $(id); n.textContent = text || ''; n.hidden = !text; };
  const KIND = {pdf: 'PDF', docx: 'Word', pptx: 'PowerPoint', image: 'صورة', manual: 'فهرس كتبتِه'};
  const lessons = n => arCount(n, ['درس واحد', 'درسان', 'دروس', 'درسًا']);
  let timer = null;

  function status(b) {
    if (b.status === 'processing') return {cls: 'wait', text: b.pages ? 'جارٍ القراءة · ' + b.progress + ' من ' + b.pages + ' صفحة' : 'جارٍ القراءة…'};
    if (b.status === 'failed') return {cls: 'bad', text: 'تعذرت القراءة'};
    return b.confirmed ? {cls: 'ok', text: 'معتمد ✓'} : {cls: 'warn', text: 'بانتظار مراجعتك'};
  }
  function row(b) {
    const st = status(b);
    const meta = [b.subject, b.grade, KIND[b.kind] || '', b.status === 'ready' ? lessons(b.lessons) : '', b.classes.length ? 'الفصول: ' + b.classes.join('، ') : ''].filter(Boolean).join(' · ');
    const main = el('a', {class: 'row-main', href: '/curriculum/' + b.id}, el('b', {text: b.title}), el('small', {text: meta || 'كتاب'}));
    const bits = [main, el('span', {class: 'badge st-' + st.cls, text: st.text})];
    if (b.status === 'processing' && b.pages) bits.splice(1, 0, el('progress', {max: b.pages, value: b.progress, 'aria-label': 'تقدم القراءة'}));
    bits.push(el('a', {class: 'btn small' + (b.confirmed ? ' ghost' : ' sun'), href: '/curriculum/' + b.id, text: b.confirmed ? 'فتح' : b.status === 'ready' ? 'مراجعة الكتاب' : 'فتح'}));
    const del = el('button', {class: 'btn ghost small', type: 'button', text: 'حذف'});
    del.addEventListener('click', async () => {
      if (!confirm('حذف كتاب «' + b.title + '» وخطط الفصول المبنية عليه؟ الدروس التفاعلية التي أنشأتِها منه تبقى.')) return;
      try { await api('DELETE', '/api/books/' + b.id); load(); } catch (e) { alert(e.message); }
    });
    bits.push(del);
    return el('li', {class: 'row bk', 'data-book': b.id}, ...bits);
  }
  async function load() {
    clearTimeout(timer);
    try {
      const d = await api('GET', '/api/books');
      const box = $('book-list'); box.replaceChildren(...d.books.map(row));
      $('book-none').hidden = !!d.books.length;
      if (d.books.some(b => b.status === 'processing')) timer = setTimeout(load, 2000);
    } catch (e) { $('book-none').textContent = e.message; $('book-none').hidden = false; }
  }

  $('up-file').addEventListener('change', () => {
    const f = $('up-file').files[0]; say('up-err', '');
    if (!f) return;
    $('up-name').textContent = f.name;
    if (f.size > maxMb * 1024 * 1024) { say('up-err', 'الملف كبير، الحد الأقصى ' + maxMb + ' ميجابايت'); $('up-file').value = ''; $('up-name').textContent = 'اختاري ملف الكتاب من جهازك'; }
  });
  $('up-form').addEventListener('submit', async e => {
    e.preventDefault(); say('up-err', '');
    const f = $('up-file').files[0]; if (!f) return;
    const b = $('up-go'); b.disabled = true; b.textContent = 'جارٍ الرفع…';
    try { const r = await apiUpload('/api/books', f, {title: $('up-title').value}); location.href = '/curriculum/' + r.id; }
    catch (x) { say('up-err', x.message); b.disabled = false; b.textContent = 'رفع الكتاب وقراءته'; }
  });
  $('man-form').addEventListener('submit', async e => {
    e.preventDefault(); say('man-err', '');
    try { const r = await api('POST', '/api/books/outline', {title: $('man-title').value, text: $('man-text').value}); location.href = '/curriculum/' + r.id; }
    catch (x) { say('man-err', x.message); }
  });
  load();
})();
