// «غائب اليوم»: she records her own absence, sees what it does to every plan BEFORE she confirms, and the lessons are laid out again over the periods that are left.
(function () {
  const $ = id => document.getElementById(id);
  const say = (id, text) => { const n = $(id); n.textContent = text || ''; n.hidden = !text; };
  const lessonsW = n => arCount(n, ['درس واحد', 'درسان', 'دروس', 'درسًا']);
  const moreLessonsW = n => arCount(n, ['درس واحد آخر', 'درسان آخران', 'دروس أخرى', 'درسًا آخر']);
  const periodsW = n => arCount(n, ['حصة واحدة', 'حصتان', 'حصص', 'حصة']);
  const daysW = n => arCount(n, ['يوم واحد', 'يومان', 'أيام', 'يومًا']);
  const DAYS = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];          // getDay(): Sunday 0, like her timetable
  const MONTHS = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
  const parse = iso => { const [y, m, d] = iso.split('-').map(Number); return new Date(y, m - 1, d); };
  const isoOf = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const addDays = (iso, n) => { const d = parse(iso); d.setDate(d.getDate() + n); return isoOf(d); };
  const short = text => String(text || '').replace(/ \d{4}$/, '');
  const arDate = iso => { const d = parse(iso); return DAYS[d.getDay()] + ' ' + d.getDate() + ' ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear(); };
  const place = w => w ? short(w.text) + ' (الحصة ' + w.period + ')' : 'بلا موعد';

  let A = null, when = 'today', shown = null, busy = false;
  const picked = new Set();

  function toast(text, bad) {
    const t = el('div', {class: 'toast' + (bad ? ' bad' : ''), role: bad ? 'alert' : 'status', text});
    document.body.append(t); setTimeout(() => t.remove(), 4500);
  }
  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text);
    return new Promise((ok, no) => {
      const t = el('textarea', {'aria-hidden': 'true'}); t.value = text; document.body.append(t); t.select();
      try { document.execCommand('copy') ? ok() : no(new Error('copy')); } catch (e) { no(e); } finally { t.remove(); }
    });
  }

  // ---------------------------------------------------------------- the form
  const scope = () => (document.querySelector('input[name=ab-scope]:checked') || {}).value || 'whole';
  function range() {
    const from = when === 'today' ? A.today : when === 'tomorrow' ? addDays(A.today, 1) : ($('ab-from').value || A.today);
    const to = when === 'other' ? ($('ab-to').value || from) : from;
    return {from, to: to < from ? from : to};
  }
  function stale() { $('ab-prev').hidden = true; shown = null; say('ab-err', ''); }
  function drawDay() {
    const {from, to} = range(), one = from === to;
    $('ab-day-line').textContent = one ? (from === A.today ? 'اليوم · ' : '') + arDate(from) : 'من ' + arDate(from) + ' إلى ' + arDate(to) + ' (' + daysW((parse(to) - parse(from)) / 864e5 + 1) + ')';
    const some = document.querySelector('input[name=ab-scope][value=some]');
    some.disabled = !one;
    if (!one && scope() === 'some') document.querySelector('input[name=ab-scope][value=whole]').checked = true;
    const box = $('ab-periods'); box.replaceChildren();
    box.hidden = !(one && scope() === 'some');
    if (box.hidden) return;
    const slots = (A.week[String(parse(from).getDay())] || []);
    if (!slots.length) { box.append(el('p', {class: 'muted', text: 'لا حصص لك في هذا اليوم بحسب جدولك.'})); return; }
    slots.forEach(s => {
      const on = picked.has(s.period);
      const b = el('button', {type: 'button', class: 'chip-btn' + (on ? ' on' : ''), 'aria-pressed': on ? 'true' : 'false'}, el('b', {text: 'الحصة ' + s.period}),
        el('small', {text: s.class_name + ' · ' + s.subject_name}), s.time ? el('small', {}, el('bdi', {class: 'tm', text: s.time})) : null);
      b.addEventListener('click', () => { if (picked.has(s.period)) picked.delete(s.period); else picked.add(s.period); stale(); drawDay(); });
      box.append(b);
    });
  }
  function setWhen(w) {
    when = w; picked.clear();
    document.querySelectorAll('#ab-when .chip-btn').forEach(b => { const on = b.dataset.when === w; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); });
    $('ab-dates').hidden = w !== 'other';
    if (w === 'other') { $('ab-from').value = $('ab-from').value || A.today; $('ab-to').value = $('ab-to').value || $('ab-from').value; }
    stale(); drawDay();
  }
  function request() {
    const {from, to} = range(), data = {from, to, reason: $('ab-reason').value.trim()};
    if (scope() === 'some') {
      if (!picked.size) throw new Error('اختاري حصة واحدة على الأقل، أو اختاري «اليوم كاملًا»');
      data.periods = [...picked].sort((a, b) => a - b);
    }
    return data;
  }

  // ---------------------------------------------------------------- what an absence does to the plans
  // what happened to the lessons of one plan, in a sentence (past: it has been done; otherwise it is what would happen)
  function movedText(e, past) {
    const parts = [];
    if (e.later) parts.push((past ? 'تأجّلت مواعيد ' : 'تتأجّل مواعيد ') + lessonsW(e.later));
    if (e.earlier) parts.push((past ? 'تقدّمت مواعيد ' : 'تتقدّم مواعيد ') + lessonsW(e.earlier));
    if (e.gained) parts.push((past ? 'صار لـ' : 'يصير لـ') + lessonsW(e.gained) + ' موعد');
    if (e.lost) parts.push((past ? 'لم يبقَ موعد لـ' : 'لا يبقى موعد لـ') + lessonsW(e.lost));
    return parts.join('، ');
  }
  const SHOWN = 3;          // examples listed for a plan (the log of the plan has them all)
  function effectBox(e, past, brief) {
    const box = el('div', {class: 'ab-eff' + (brief ? ' brief' : '')}, el('div', {class: 'ab-eff-h'}, el('b', {text: e.class_name + ' · ' + e.subject_name}),
      el('a', {class: 'btn small ghost', href: '/plan?class=' + e.class_id + '&subject=' + e.subject_id, text: 'فتح الخطة'})));
    box.append(el('p', {text: movedText(e, past)}));
    if (!brief) {
      box.append(el('ul', {class: 'ab-moves'}, ...e.moved.slice(0, SHOWN).map(m => el('li', {}, el('b', {text: '«' + m.title + '»'}), ' من ' + place(m.from) + ' إلى ' + place(m.to)))));
      if (e.moved_count > SHOWN) box.append(el('p', {class: 'muted', text: 'و' + moreLessonsW(e.moved_count - SHOWN) + '. التفاصيل كلها في «سجل تغييرات الخطة».'}));
    }
    if (e.short > 0) {
      box.append(el('p', {class: 'note warn', text: 'تنقصك ' + periodsW(e.short) + ' لتغطية الدروس الباقية قبل نهاية الفصل (لا يتّسع الوقت لـ' + periodsW(e.unplaced) + '). لا يُحذف درس: ما لا يتّسع يبقى في الخطة بلا موعد.'}));
      if (e.ideas && e.ideas.length) box.append(el('p', {class: 'muted'}, 'ويمكنك دمج درسين متجاورين في حصة واحدة من صفحة الخطة، مثل «' + e.ideas[0].first_title + '» و«' + e.ideas[0].second_title + '».'));
    }
    return box;
  }
  function effects(into, list, past) {
    into.replaceChildren();
    if (!list.length) { into.append(el('p', {class: 'note', text: 'لا يتغير موعد أي درس: ليس في هذه الحصص درس مخطَّط في الخطة (أو لم تُبنَ خطة لهذه المادة بعد).'})); return; }
    list.forEach(e => into.append(effectBox(e, past, past)));          // once it is done, a line for each plan is enough: she saw the examples before she confirmed
  }
  function periodsList(into, periods) {
    into.replaceChildren();
    const days = [];
    periods.forEach(p => { let d = days.find(x => x.date === p.date); if (!d) { d = {date: p.date, text: p.text, items: []}; days.push(d); } d.items.push(p); });
    days.forEach(d => into.append(el('h3', {class: 'ab-dayh', text: d.text}), el('ul', {class: 'ab-pl'}, ...d.items.map(p => el('li', {}, el('span', {class: 'no', text: String(p.period)}),
      el('div', {class: 'who'}, el('b', {text: p.class_name + ' · ' + p.subject_name}), el('small', {}, ...(p.time ? [el('bdi', {class: 'tm', text: p.time}), ' · '] : []), p.lesson ? 'كان فيها: «' + p.lesson + '»' : 'لا درس مخطَّط في هذه الحصة')))))));
  }
  function skipped(id, list) {
    const n = $(id); n.hidden = !list.length; n.replaceChildren();
    const by = []; list.forEach(s => { let g = by.find(x => x.why === s.why); if (!g) { g = {why: s.why, days: []}; by.push(g); } g.days.push(short(s.text)); });
    if (by.length) n.append('لم تُحتسب: ' + by.map(g => g.why + ' (' + g.days.join('، ') + ')').join(' · ') + '.');
  }

  async function doPreview() {
    if (busy) return;
    let data; try { data = request(); } catch (e) { say('ab-err', e.message); return; }
    busy = true; $('ab-preview').disabled = true; say('ab-err', ''); $('ab-done').hidden = true;
    try {
      const d = await api('POST', '/api/absence/preview', data); shown = data;
      $('ab-prev-sum').replaceChildren('ستُلغى ', el('b', {text: periodsW(d.count)}), ' في ' + d.classes.join('، ') + '. ' + (d.lessons ? 'المخطَّط فيها: ' + lessonsW(d.lessons) + '.' : 'ولا دروس مخطَّطة فيها.'));
      periodsList($('ab-prev-periods'), d.periods); skipped('ab-prev-skipped', d.skipped); effects($('ab-prev-effects'), d.effects, false);
      say('ab-save-err', ''); $('ab-prev').hidden = false; $('ab-prev').scrollIntoView({behavior: 'smooth', block: 'start'});
    } catch (e) { say('ab-err', e.message); }
    finally { busy = false; $('ab-preview').disabled = false; }
  }
  async function doSave() {
    if (busy || !shown) return;
    busy = true; $('ab-save').disabled = true; say('ab-save-err', '');
    try {
      const d = await api('POST', '/api/absence', shown); A = d; stale();
      done('✓ سُجّل غيابك', d.result, false);
      $('ab-reason').value = ''; picked.clear(); drawDay(); drawList();
    } catch (e) { say('ab-save-err', e.message); }
    finally { busy = false; $('ab-save').disabled = false; }
  }

  // ---------------------------------------------------------------- the result and the messages for the classes
  function messages(into, list) {
    into.replaceChildren();
    if (!list || !list.length) return;
    into.append(el('h3', {text: 'رسائل جاهزة للفصول'}), el('p', {class: 'muted', text: 'تُرسَل من واتساب نفسه: اضغطي «إرسال عبر واتساب» فيفتح والرسالة مكتوبة، ثم اختاري المجموعة وأرسلي. لا يرسل التطبيق شيئًا بنفسه، وليس فيها اسم أحد من الطلاب ولا سبب الغياب.'}));
    list.forEach(m => {
      const copy = el('button', {type: 'button', class: 'btn small ghost', text: 'نسخ النص'});
      copy.addEventListener('click', () => copyText(m.text).then(() => toast('نُسخت الرسالة'), () => toast('تعذّر النسخ، حدّدي النص وانسخيه', true)));
      into.append(el('div', {class: 'ab-msg'}, el('b', {text: m.class_name}), el('pre', {class: 'msg-text', dir: 'auto', text: m.text}),
        el('div', {class: 'btn-row'}, el('a', {class: 'btn small sun', href: m.wa, target: '_blank', rel: 'noopener noreferrer', text: 'إرسال عبر واتساب'}), copy,
          m.group ? el('a', {class: 'btn small ghost', href: m.group, target: '_blank', rel: 'noopener noreferrer', text: 'فتح مجموعة الفصل'}) : null)));
    });
  }
  function done(title, r, cancelled) {
    $('ab-done-h').textContent = title;
    $('ab-done-sum').textContent = cancelled ? 'عادت ' + periodsW(r.cancelled) + ' إلى جدول تدريسك' + (r.effects.length ? ' وتقدّمت الدروس إلى مواعيدها.' : '.')
      : 'خرجت ' + periodsW(r.count) + ' من خططك' + (r.days.length > 1 ? ' في ' + daysW(r.days.length) : '') + '، وأُعيد توزيع الدروس بترتيبها نفسه دون حذف أي درس.';
    effects($('ab-done-effects'), r.effects, true);
    messages($('ab-done-msgs'), r.messages);
    $('ab-done').hidden = false; $('ab-done').scrollIntoView({behavior: 'smooth', block: 'start'}); $('ab-done').focus({preventScroll: true});
  }

  // ---------------------------------------------------------------- what is recorded
  function scopeText(x) { return x.whole ? 'اليوم كاملًا' : (x.periods.length === 1 ? 'الحصة ' + x.periods[0] : 'الحصص ' + x.periods.join(' و')); }
  function when_(x) { return x.from === x.to ? x.from_text : 'من ' + x.from_text + ' إلى ' + x.to_text + ' (' + daysW(x.days) + ')'; }
  function item(x, upcoming) {
    const li = el('li', {class: 'ab-item' + (upcoming ? '' : ' past')}, el('div', {class: 'ab-main'}, el('b', {text: (x.from === A.today && upcoming ? 'اليوم · ' : '') + when_(x)}),
      el('small', {class: 'muted', text: [scopeText(x), x.reason].filter(Boolean).join(' · ')})));
    if (!upcoming) return li;
    const acts = el('div', {class: 'acts'}), box = el('div', {class: 'ab-msgs', hidden: true});
    if (x.messages && x.messages.length) {
      const b = el('button', {type: 'button', class: 'btn small ghost', text: 'رسائل الفصول', 'aria-expanded': 'false'});
      b.addEventListener('click', () => { const open = box.hidden; box.hidden = !open; b.setAttribute('aria-expanded', open ? 'true' : 'false'); if (open && !box.childNodes.length) messages(box, x.messages); });
      acts.append(b);
    }
    const cancel = el('button', {type: 'button', class: 'btn small ghost bad-t', text: 'إلغاء الغياب'});
    cancel.addEventListener('click', () => doCancel(x, cancel));
    acts.append(cancel); li.append(acts, box);
    return li;
  }
  function drawList() {
    const up = $('ab-list'), hist = $('ab-hist-list'); up.replaceChildren(); hist.replaceChildren();
    A.upcoming.forEach(x => up.append(item(x, true))); A.history.forEach(x => hist.append(item(x, false)));
    $('ab-none').hidden = !!A.upcoming.length; $('ab-hist').hidden = !A.history.length;
    $('ab-list-card').hidden = !(A.upcoming.length || A.history.length);
  }
  async function doCancel(x, btn) {
    if (busy) return;
    if (!confirm('إلغاء غيابك ' + (x.from === x.to ? 'في ' : 'من ') + when_(x).replace(/^من /, '') + '؟ تعود الحصص إلى جدول تدريسك وتتقدّم مواعيد الدروس.')) return;
    busy = true; btn.disabled = true;
    try { const d = await api('DELETE', '/api/absence', {ids: x.ids}); A = d; done('↩ أُلغي الغياب', d.result, true); drawList(); }
    catch (e) { toast(e.message, true); btn.disabled = false; }
    finally { busy = false; }
  }

  // ---------------------------------------------------------------- start
  (async function init() {
    try { A = await api('GET', '/api/absence'); } catch (e) { const n = $('ab-need'); n.textContent = e.message; n.hidden = false; return; }
    const need = $('ab-need');
    if (!A.term) { need.replaceChildren('حدّدي بداية الفصل الدراسي ونهايته أولًا من ', el('a', {href: '/calendar', text: 'التقويم'}), ' ليعرف التطبيق أيام الدراسة.'); need.hidden = false; }
    else if (!A.has_schedule) { need.replaceChildren('أضيفي حصصك إلى ', el('a', {href: '/schedule', text: 'الجدول'}), ' ليعرف التطبيق الحصص التي تتأثر بغيابك.'); need.hidden = false; }
    else {
      $('ab-form-card').hidden = false;
      ['ab-from', 'ab-to'].forEach(id => { $(id).min = A.today; $(id).max = A.term.ends; });
      if (addDays(A.today, 1) > A.term.ends) document.querySelector('[data-when=tomorrow]').disabled = true;
      document.querySelectorAll('#ab-when .chip-btn').forEach(b => b.addEventListener('click', () => setWhen(b.dataset.when)));
      ['ab-from', 'ab-to'].forEach(id => $(id).addEventListener('change', () => { if ($('ab-to').value && $('ab-to').value < $('ab-from').value) $('ab-to').value = $('ab-from').value; picked.clear(); stale(); drawDay(); }));
      document.querySelectorAll('input[name=ab-scope]').forEach(r => r.addEventListener('change', () => { stale(); drawDay(); }));
      $('ab-reason').addEventListener('input', stale);
      $('ab-preview').addEventListener('click', doPreview);
      $('ab-save').addEventListener('click', doSave);
      $('ab-edit').addEventListener('click', () => { stale(); $('ab-form-card').scrollIntoView({behavior: 'smooth', block: 'start'}); });
      drawDay();
    }
    drawList();
  })();
})();
