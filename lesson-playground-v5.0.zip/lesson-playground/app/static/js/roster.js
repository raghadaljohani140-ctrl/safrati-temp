// Importing a list of students from a file: the server reads the file and PROPOSES the classes and names; she checks them here, then confirms.
(function () {
  const form = document.getElementById('import-form');
  if (!form) return;
  const box = document.getElementById('import-preview'), err = document.getElementById('import-err'), btn = document.getElementById('import-go');
  const NEW = 'new';

  form.addEventListener('submit', async e => {
    e.preventDefault(); err.hidden = true; box.hidden = true;
    const f = document.getElementById('import-file').files[0];
    if (!f) return;
    btn.disabled = true; btn.textContent = 'جارٍ قراءة الملف…';
    try { draw(await apiUpload('/api/students/import', f)); }
    catch (x) { err.textContent = x.message; err.hidden = false; }
    finally { btn.disabled = false; btn.textContent = 'قراءة الملف'; }
  });

  function draw(d) {
    const state = d.groups.map(g => ({
      label: g.label, classId: g.class_id || (d.classes.length === 1 && !g.label ? d.classes[0].id : null), newName: g.label || '',
      rows: g.names.map(n => ({name: n, on: !g.already.includes(n), dup: g.already.includes(n)})),
    }));
    const total = state.reduce((a, g) => a + g.rows.length, 0);
    box.replaceChildren(el('h3', {text: 'وجدنا ' + arS(total) + (state.length > 1 ? ' في ' + state.length + ' فصول' : '')}),
      el('p', {class: 'muted', text: 'راجعي الأسماء، عدّلي أي اسم أو ألغي تحديده، واختاري الفصل الذي تُضاف إليه.'}));
    const counter = el('b', {class: 'imp-count'});
    const save = el('button', {class: 'btn sun', type: 'button'});
    const refresh = () => {
      const n = state.reduce((a, g) => a + g.rows.filter(r => r.on && r.name.trim()).length, 0);
      counter.textContent = arS(n); save.textContent = 'إضافة الأسماء المحددة (' + n + ')'; save.disabled = !n;
    };
    state.forEach(g => box.append(group(g, d.classes, refresh)));
    const msg = el('p', {class: 'note bad', role: 'alert', hidden: true});
    const cancel = el('button', {class: 'btn ghost', type: 'button', text: 'إلغاء'});
    cancel.addEventListener('click', () => { box.hidden = true; form.reset(); });
    save.addEventListener('click', async () => {
      const groups = state.map(g => ({class_id: g.classId, class_name: g.classId ? '' : g.newName, names: g.rows.filter(r => r.on && r.name.trim()).map(r => r.name.trim())})).filter(g => g.names.length);
      if (groups.some(g => !g.class_id && !g.class_name.trim())) { msg.textContent = 'اختاري فصلًا أو اكتبي اسمًا للفصل الجديد لكل قائمة'; msg.hidden = false; return; }
      save.disabled = true; msg.hidden = true;
      try {
        const r = await api('POST', '/api/students/import/confirm', {groups});
        box.replaceChildren(el('p', {class: 'note', role: 'status', text: '✓ أضفنا ' + arS(r.added) + (r.classes_made ? ' وأنشأنا ' + r.classes_made + ' فصل جديد' : '') + (r.skipped ? ' (تجاوزنا ' + r.skipped + ' مكرر)' : '')}));
        form.reset(); if (window.LPStudents) window.LPStudents.reload();
      } catch (x) { msg.textContent = x.message; msg.hidden = false; save.disabled = false; }
    });
    box.append(el('div', {class: 'imp-foot'}, el('span', {}, 'المحدد: ', counter), save, cancel), msg);
    refresh(); box.hidden = false; box.scrollIntoView({behavior: 'smooth', block: 'nearest'});
  }

  function group(g, classes, refresh) {
    const card = el('div', {class: 'imp-group'});
    const sel = el('select', {'aria-label': 'الفصل الذي تُضاف إليه هذه الأسماء'}, ...classes.map(c => el('option', {value: c.id, text: c.name})), el('option', {value: NEW, text: '+ فصل جديد'}));
    const nn = el('input', {value: g.newName, maxlength: 60, placeholder: 'اسم الفصل الجديد', 'aria-label': 'اسم الفصل الجديد'});
    const sync = () => { g.classId = sel.value === NEW ? null : Number(sel.value); nn.hidden = sel.value !== NEW; };
    sel.value = g.classId ? String(g.classId) : NEW;
    sel.addEventListener('change', sync); nn.addEventListener('input', () => { g.newName = nn.value; });
    sync();
    card.append(el('div', {class: 'imp-head'}, el('b', {text: g.label ? 'من الملف: ' + g.label : 'أسماء بلا اسم فصل'}), sel, nn));
    const list = el('div', {class: 'imp-names'});
    g.rows.forEach(r => {
      const on = el('input', {type: 'checkbox', checked: r.on, 'aria-label': 'إضافة ' + r.name});
      const nm = el('input', {value: r.name, maxlength: 60, 'aria-label': 'الاسم'});
      on.addEventListener('change', () => { r.on = on.checked; refresh(); });
      nm.addEventListener('input', () => { r.name = nm.value; refresh(); });
      list.append(el('label', {class: 'imp-row' + (r.dup ? ' dup' : '')}, on, nm, r.dup ? el('small', {text: 'موجود في الفصل'}) : null));
    });
    card.append(list);
    return card;
  }
})();
