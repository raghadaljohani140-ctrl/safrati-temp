// What the two homework pages share: the colour of a due day, the line that says who did it, the bar, the buttons that pick one thing, and copying a message.
window.hw = (function () {
  const NAMES = {pending: 'لم يُراجَع', done: 'أنجز', partial: 'أنجز جزءًا', missing: 'لم ينجز'};
  const MARKS = {done: '✓', partial: '◐', missing: '✗'};
  const SHORT = {done: 'أنجز', partial: 'جزئيًا', missing: 'لم ينجز'};          // on the buttons; the full name («أنجز جزءًا») is what is read aloud and shown in the figures
  const ORDER = ['done', 'partial', 'missing'];
  const hwW = n => arCount(n, ['واجب واحد', 'واجبان', 'واجبات', 'واجبًا']);

  // «موعده غدًا»: what the day means, in words, with the colour of how near it is
  function dueBadge(a) {
    if (a.closed) return null;
    if (a.due_state === 'none') return el('span', {class: 'badge', text: 'بلا موعد'});
    if (a.due_state === 'today') return el('span', {class: 'badge st-warn', text: 'موعده اليوم'});
    if (a.due_state === 'past') return el('span', {class: 'badge ' + (a.needs_review ? 'st-bad' : ''), text: 'موعده كان ' + a.due_label});
    return el('span', {class: 'badge st-wait', text: 'موعده ' + a.due_label});
  }
  // «أنجز 12 من 20 · لم ينجز 3 · لم يُراجَع 5»
  function statsLine(s) {
    if (!s.total) return 'لا طلاب على هذا الواجب';
    const bits = ['أنجز ' + s.done + ' من ' + s.total];
    for (const k of ['partial', 'missing', 'pending']) if (s[k]) bits.push(NAMES[k] + ' ' + s[k]);
    return bits.join(' · ');
  }
  // the bar: done, part, not done, not checked yet (the numbers are spelled out beside it, so the colours never carry the meaning alone)
  function meter(s) {
    const box = el('div', {class: 'hw-meter', role: 'img', 'aria-label': statsLine(s)});
    for (const k of ['done', 'partial', 'missing', 'pending']) {
      if (!s[k] || !s.total) continue;
      const seg = el('span', {class: 'seg ' + k}); seg.style.width = (100 * s[k] / s.total) + '%'; box.append(seg);
    }
    return box;
  }
  const chip = (label, sel, fn, small) => {
    const b = el('button', {type: 'button', class: 'chip-btn' + (sel ? ' on' : ''), 'aria-pressed': sel ? 'true' : 'false'}, label, small ? el('small', {text: small}) : null);
    b.addEventListener('click', fn);
    return b;
  };
  async function copyText(text, button) {
    try { await navigator.clipboard.writeText(text); }
    catch (e) {
      const ta = el('textarea', {'aria-hidden': 'true', readonly: true}); ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.append(ta); ta.select();
      try { document.execCommand('copy'); } catch (e2) {} ta.remove();
    }
    if (button) { const old = button.textContent; button.textContent = 'تم النسخ ✓'; setTimeout(() => { button.textContent = old; }, 2200); }
  }
  const addDays = (iso, n) => { const d = new Date(iso + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
  return {NAMES, MARKS, SHORT, ORDER, hwW, dueBadge, statsLine, meter, chip, copyText, addDays};
})();
