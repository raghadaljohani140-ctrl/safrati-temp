// The manager's pages: ask before an action that changes something, fill a quick value (the print button is handled in app.js). No inline handlers (the page forbids them).
document.addEventListener("submit", (e) => {
  const text = e.target.getAttribute && e.target.getAttribute("data-confirm");
  if (text && !window.confirm(text)) e.preventDefault();
});
document.addEventListener("click", (e) => {
  const fill = e.target.closest && e.target.closest("[data-fill]");
  if (fill) {
    const input = fill.closest("form").querySelector('[name="' + fill.dataset.fill + '"]');
    if (input) { input.value = fill.dataset.value; input.focus(); }
    return;
  }
});
