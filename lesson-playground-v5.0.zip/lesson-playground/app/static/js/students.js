(function () {
  const holder = document.getElementById('classes'), none = document.getElementById('no-classes'), detail = document.getElementById('detail');
  let openId = null, subjects = [];
  const fmt = t => new Date(t * 1000).toLocaleDateString('ar-SA', {day: 'numeric', month: 'short'});

  async function load() {
    const [d, sj] = await Promise.all([api('GET', '/api/students'), api('GET', '/api/subjects')]);
    subjects = sj.subjects;
    holder.replaceChildren(); none.hidden = !!d.classes.length;
    d.classes.forEach(c => holder.append(classCard(c, d.students.filter(s => s.class_id === c.id))));
    drawSubjects();
    if (openId && !d.students.some(s => s.id === openId)) { openId = null; detail.hidden = true; }
  }
  window.LPStudents = {reload: () => load().catch(() => {})};

  // ----- her subjects: a chip for each, with a way to remove it (her lessons and students stay)
  function drawSubjects() {
    const box = document.getElementById('subjects'); box.replaceChildren();
    if (!subjects.length) box.append(el('p', {class: 'muted', text: 'لم تضيفي مواد بعد.'}));
    subjects.forEach(s => {
      const name = el('input', {value: s.name, maxlength: 40, class: 'chip-in', 'aria-label': 'اسم المادة'});
      name.addEventListener('change', async () => { try { await api('PATCH', '/api/subjects/' + s.id, {name: name.value}); load(); } catch (e) { alert(e.message); name.value = s.name; } });
      const del = el('button', {class: 'chip-x', type: 'button', 'aria-label': 'حذف المادة ' + s.name, text: '×'});
      del.addEventListener('click', async () => { if (!confirm('حذف المادة «' + s.name + '»؟ دروسك وطلابك لا يتأثرون.')) return; await api('DELETE', '/api/subjects/' + s.id); load(); });
      box.append(el('span', {class: 'subj-chip'}, name, del));
    });
  }
  document.getElementById('add-subject').addEventListener('submit', async e => {
    e.preventDefault(); const err = document.getElementById('subject-err'); err.hidden = true; const input = document.getElementById('subject-name');
    try { await api('POST', '/api/subjects', {name: input.value}); input.value = ''; load(); } catch (x) { err.textContent = x.message; err.hidden = false; }
  });

  function classCard(c, list) {
    const card = el('section', {class: 'card class-card', 'data-class': c.id});
    const name = el('input', {value: c.name, maxlength: 60, class: 'cell-in class-title', 'aria-label': 'اسم الفصل'}); const saved = el('span', {class: 'saved'});
    name.addEventListener('change', async () => { try { await api('PATCH', '/api/classes/' + c.id, {name: name.value}); saved.textContent = 'تم الحفظ ✓'; } catch (e) { saved.textContent = e.message; name.value = c.name; } });
    const del = el('button', {class: 'btn ghost small danger', type: 'button', text: 'حذف الفصل'});
    del.addEventListener('click', async () => { if (!confirm('حذف «' + c.name + '» وكل طلابه ونتائجهم ونقاطهم؟ لا يمكن التراجع.')) return; await api('DELETE', '/api/classes/' + c.id); load(); });
    card.append(el('div', {class: 'class-head'}, name, saved, el('small', {class: 'muted', text: arS(list.length)}), del));

    // the class's own WhatsApp group (optional): homework and exams are sent to it from here
    const wa = el('input', {type: 'text', dir: 'ltr', value: c.whatsapp || '', placeholder: 'https://chat.whatsapp.com/…', 'aria-label': 'رابط مجموعة واتساب هذا الفصل', maxlength: 300});
    const waSaved = el('span', {class: 'saved'}), waOpen = el('a', {class: 'btn ghost small', target: '_blank', rel: 'noopener', text: 'فتح المجموعة', hidden: !c.whatsapp, href: c.whatsapp || '#'});
    wa.addEventListener('change', async () => {
      try { const r = await api('PATCH', '/api/classes/' + c.id, {whatsapp: wa.value}); wa.value = r.whatsapp; c.whatsapp = r.whatsapp; waOpen.hidden = !r.whatsapp; waOpen.href = r.whatsapp || '#'; waSaved.textContent = r.whatsapp ? 'تم حفظ الرابط ✓' : 'أُزيل الرابط'; }
      catch (e) { waSaved.textContent = e.message; }
    });
    card.append(el('div', {class: 'wa-row'}, el('label', {}, '💬 مجموعة واتساب الفصل (اختياري)', wa), el('div', {class: 'wa-act'}, waSaved, waOpen)));

    // the subjects she teaches this class
    if (subjects.length) {
      const have = new Set(c.subjects.map(x => x.id));
      const row = el('div', {class: 'chips-row'}, el('b', {text: 'المواد: '}));
      subjects.forEach(s => {
        const cb = el('input', {type: 'checkbox', checked: have.has(s.id)});
        cb.addEventListener('change', async () => {
          cb.checked ? have.add(s.id) : have.delete(s.id);
          try { await api('PUT', '/api/classes/' + c.id + '/subjects', {subject_ids: [...have]}); } catch (e) { alert(e.message); }
        });
        row.append(el('label', {class: 'subj-pick'}, cb, s.name));
      });
      card.append(row);
    }

    const area = el('textarea', {rows: 3, maxlength: 6000, placeholder: 'اكتبي اسم طالب في كل سطر', 'aria-label': 'أسماء الطلاب'});
    const add = el('button', {class: 'btn', type: 'submit', text: 'إضافة الأسماء إلى ' + c.name}); const err = el('p', {class: 'note bad', role: 'alert', hidden: true});
    const form = el('form', {class: 'stack'}, el('label', {}, 'الأسماء تحت هذا الفصل', area), add, err);
    form.addEventListener('submit', async e => {
      e.preventDefault(); err.hidden = true;
      try { await api('POST', '/api/students', {class_id: c.id, names: area.value.split('\n').map(x => x.trim()).filter(Boolean)}); load(); }
      catch (x) { err.textContent = x.message; err.hidden = false; }
    });
    card.append(form);

    if (!list.length) card.append(el('p', {class: 'muted', text: 'لا توجد أسماء في هذا الفصل بعد.'}));
    else {
      const tb = el('tbody'); list.forEach(s => tb.append(row(s)));
      card.append(el('div', {class: 'tbl-wrap'}, el('table', {class: 'tbl'}, el('thead', {}, el('tr', {}, ...['الاسم', 'النقاط', 'الأسئلة', 'الصحيحة', 'النسبة', 'المستوى', ''].map(t => el('th', {text: t})))), tb)));
    }
    return card;
  }

  function row(s) {
    const tr = el('tr'); const name = el('input', {value: s.name, maxlength: 60, 'aria-label': 'اسم الطالب', class: 'cell-in'}); const saved = el('span', {class: 'saved'});
    name.addEventListener('change', async () => {
      try { await api('PATCH', '/api/students/' + s.id, {name: name.value}); saved.textContent = 'تم الحفظ ✓'; setTimeout(load, 600); }
      catch (e) { saved.textContent = e.message; name.value = s.name; }
    });
    const show = el('button', {class: 'btn ghost small', type: 'button', text: 'النتائج'}); show.addEventListener('click', () => openDetail(s.id));
    const del = el('button', {class: 'btn ghost small danger', type: 'button', text: 'حذف'});
    del.addEventListener('click', async () => { if (!confirm('حذف ' + s.name + ' ونتائجه ونقاطه؟')) return; await api('DELETE', '/api/students/' + s.id); load(); });
    const rep = el('a', {class: 'btn ghost small', href: '/reports?student=' + s.id, text: 'التقرير', 'aria-label': 'تقرير ' + s.name});
    tr.append(el('td', {}, name, saved), el('td', {text: s.points || 0}), el('td', {text: s.answered}), el('td', {text: s.correct}), el('td', {text: s.percent == null ? '—' : s.percent + '%'}),
      el('td', {}, s.level ? el('span', {class: 'lvl l' + (s.percent >= 85 ? 'a' : s.percent >= 65 ? 'b' : 'c'), text: s.level}) : '—'), el('td', {class: 'acts'}, show, rep, del));
    return tr;
  }

  async function openDetail(id) {
    openId = id; const d = await api('GET', '/api/students/' + id + '/results');
    document.getElementById('d-name').textContent = 'نتائج ' + d.name;
    const decks = document.getElementById('d-decks'); decks.replaceChildren();
    if (!d.decks.length) decks.append(el('tr', {}, el('td', {colspan: 4, class: 'muted', text: 'لا توجد نتائج بعد. اختاري هذا الطالب أثناء العرض.'})));
    d.decks.forEach(x => decks.append(el('tr', {}, el('td', {text: x.title}), el('td', {text: x.answered}), el('td', {text: x.correct}), el('td', {text: x.percent + '%'}))));
    const list = document.getElementById('d-recent'); list.replaceChildren();
    d.recent.forEach(x => list.append(el('li', {}, el('b', {text: x.correct ? '✔ ' : '✘ '}), x.question, el('small', {class: 'muted', text: ' · ' + x.deck + ' · ' + fmt(x.at)}))));
    detail.hidden = false; detail.scrollIntoView({behavior: 'smooth', block: 'nearest'});
  }
  document.getElementById('d-clear').addEventListener('click', async () => {
    if (!openId || !confirm('مسح كل نتائج هذا الطالب؟ لا يمكن التراجع.')) return;
    await api('DELETE', '/api/students/' + openId + '/results'); await load(); openDetail(openId);
  });
  document.getElementById('add-class').addEventListener('submit', async e => {
    e.preventDefault(); const err = document.getElementById('class-err'); err.hidden = true; const input = document.getElementById('class-name');
    try { await api('POST', '/api/classes', {name: input.value}); input.value = ''; load(); } catch (x) { err.textContent = x.message; err.hidden = false; }
  });
  load().catch(e => { none.hidden = false; none.textContent = e.message; });
})();
