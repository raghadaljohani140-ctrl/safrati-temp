// Participation points on the stage: a right answer gives the student a point (how many is hers to set), and she can give points by hand to any student of the class.
// The points are kept on the server (points.py). A point is written on this device first and sent after, so a weak school network never loses one: each carries a key,
// and the server writes a point with the same key once, however many times it is sent. The panel shows the class, the first three places, today's points of everyone,
// and a way to take back the last point.
(function () {
  const L = window.LPStage = window.LPStage || {screens: {}};
  const QKEY = 'lp-points-queue', MAX_QUEUE = 1000, RETRY_MS = 15000, MEDALS = ['🥇', '🥈', '🥉'];
  let c = null, settings = {correct: 1, try: 0, limits: {correct: [0, 5], try: [0, 3]}}, queue = [], sending = false, retry = null;
  const given = [];                                         // what she gave in this sitting, oldest first: {key, id, student_id, name, amount}
  let panel = null, period = 'today', bySubject = false, amount = 1, today = {}, ranked = null, toastTimer = null, lastError = '';
  const dayNo = () => Math.floor((Date.now() + 3 * 3600e3) / 86400e3);          // her day is the Saudi day; it only has to change when her day does
  const mkKey = (...parts) => parts.map(x => String(x == null ? '' : x).replace(/[^A-Za-z0-9_.-]/g, '')).join(':').slice(-64);          // what the server accepts as a key
  const nameOf = id => ((c && c.students.find(s => s.id === id)) || {}).name || '';

  // ------------------------------------------------------------ the points waiting on this device
  function loadQueue() { try { const q = JSON.parse(localStorage.getItem(QKEY) || '[]'); queue = Array.isArray(q) ? q.filter(p => p && p.key && p.student_id) : []; } catch (e) { queue = []; } }
  function saveQueue() { try { localStorage.setItem(QKEY, JSON.stringify(queue.slice(-MAX_QUEUE))); } catch (e) {} }
  function status() {
    const bar = document.querySelector('.bar'); if (!bar) return;
    let b = document.getElementById('pts-queue');
    if (!b) { b = el('span', {id: 'pts-queue', class: 'pts-queue', role: 'status'}); const t = bar.querySelector('.deck-title'); t ? t.after(b) : bar.prepend(b); }
    b.hidden = !queue.length;
    b.textContent = queue.length ? '⏳ ' + arP(queue.length) + ' لم تُرسل بعد' : '';
    b.title = 'حُفظت على هذا الجهاز وتُرسل وحدها عند عودة الاتصال';
  }
  async function flush() {
    if (sending || !queue.length) return;
    sending = true; clearTimeout(retry); retry = null;
    let sent = 0;
    try {
      while (queue.length) {
        const p = queue[0];
        try {
          const r = await api('POST', '/api/points', p);
          const rec = given.find(x => x.key === p.key); if (rec) rec.id = r.id;
          today[p.student_id] = r.today; queue.shift(); saveQueue(); sent++;
        } catch (e) {
          if (!e.status || e.status >= 500 || e.status === 429) { retry = setTimeout(flush, RETRY_MS); break; }          // no connection or a busy server: keep it and try again
          queue.shift(); saveQueue();                                                                                  // refused (the student is gone, say): it can never be sent
        }
      }
    } finally { sending = false; status(); }
    if (sent && panel && !panel.hidden) { paintGrid(); paintUndo(); loadRanking(); }
  }
  window.addEventListener('online', flush);

  // ------------------------------------------------------------ giving a point
  function give(st, n, extra) {
    const p = Object.assign({student_id: st.id, amount: n, source: 'manual', subject_id: c.S.sub || null, at: Date.now() / 1000,
      key: mkKey('m', Date.now().toString(36) + Math.random().toString(36).slice(2, 8), st.id)}, extra || {});
    if (queue.some(x => x.key === p.key) || given.some(x => x.key === p.key)) return null;          // the same answer twice
    queue.push(p); saveQueue();
    const rec = {key: p.key, id: null, student_id: st.id, name: st.name, amount: n};
    given.push(rec); status();
    today[st.id] = (today[st.id] || 0) + n;                    // shown at once; the server's own number replaces it when it answers
    flush();
    return rec;
  }
  function answered(st, correct, info) {
    if (!c || !st) return;
    const n = correct ? settings.correct : settings.try;
    if (!n) return;
    const rec = give(st, n, {source: 'game', game: info.game, ref: c.deck_title || '', key: mkKey('g', dayNo(), info.run, info.game, info.q.id, st.id)});
    if (rec) toast('⭐ ' + (n > 0 ? '+' : '') + n + ' ' + st.name, rec);
    if (rec && panel && !panel.hidden) { paintGrid(); paintUndo(); }
  }
  async function undo(rec) {
    const i = queue.findIndex(x => x.key === rec.key);
    if (i >= 0) { queue.splice(i, 1); saveQueue(); status(); }                 // it never left this device
    else if (rec.id) {
      try { await api('DELETE', '/api/points/' + rec.id); } catch (e) { if (e.status !== 404) { toast('تعذّر التراجع الآن (' + e.message + ')'); return false; } }
    } else return false;
    const j = given.indexOf(rec); if (j >= 0) given.splice(j, 1);
    today[rec.student_id] = Math.max(0, (today[rec.student_id] || 0) - rec.amount);
    if (panel && !panel.hidden) { paintGrid(); paintUndo(); loadRanking(); }
    return true;
  }

  // ------------------------------------------------------------ the little message after a point
  function toast(text, rec) {
    let t = document.getElementById('pts-toast');
    if (!t) { t = el('div', {id: 'pts-toast', class: 'pts-toast', role: 'status'}); document.getElementById('stage').append(t); }
    t.replaceChildren(el('span', {text}));
    if (rec) { const b = el('button', {type: 'button', class: 'btn small', text: '↩ تراجع'}); b.addEventListener('click', async () => { if (await undo(rec)) t.hidden = true; }); t.append(b); }
    t.hidden = false; clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.hidden = true; }, rec ? 7000 : 4000);
  }

  // ------------------------------------------------------------ the first three places
  function podium(top, more, big) {
    const places = [1, 2, 3].map(r => top.filter(x => x.rank === r)).map((list, i) => ({list, i})).filter(x => x.list.length);
    if (!places.length) return el('p', {class: 'muted pts-none', text: 'لم تُعطَ نقاط بعد في هذه الفترة.'});
    const col = ({list, i}) => el('div', {class: 'pod p' + (i + 1)}, el('div', {class: 'pod-names'}, list.map(x => el('div', {class: 'pod-who'}, el('b', {text: x.name}), el('span', {class: 'pod-pts', text: arP(x.points)})))),
      el('div', {class: 'pod-step'}, el('span', {class: 'medal', 'aria-hidden': 'true', text: MEDALS[i]}), el('span', {class: 'pod-n', text: 'المركز ' + (i + 1)})));
    const order = [places.find(x => x.i === 1), places.find(x => x.i === 0), places.find(x => x.i === 2)].filter(Boolean);          // the first place in the middle
    const box = el('div', {class: 'podium' + (big ? ' big' : ''), role: 'list', 'aria-label': 'أفضل ثلاثة'}, order.map(col));
    return more ? el('div', {}, box, el('p', {class: 'muted pts-more', text: 'وهناك ' + arS(more) + ' آخرون بالمراكز نفسها لم يتّسع لهم الصف.'})) : box;
  }
  function showPodium() {
    const old = document.getElementById('pts-big'); if (old) old.remove();
    const close = el('button', {type: 'button', class: 'btn big sun', text: 'إغلاق'});
    const body = el('div', {class: 'pts-big-body'}, el('h2', {text: '🏆 أفضل ثلاثة · ' + ((c.classes.find(x => x.id === c.S.cls) || {}).name || '')}), podium(ranked ? ranked.top : [], ranked ? ranked.more : 0, true), close);
    const box = el('div', {id: 'pts-big', class: 'pts-big', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'أفضل ثلاثة'}, body);
    close.addEventListener('click', () => { box.remove(); });
    box.addEventListener('keydown', e => { if (e.key === 'Escape') box.remove(); });
    document.getElementById('stage').append(box); close.focus();
  }

  // ------------------------------------------------------------ the panel
  const className = () => (c.classes.find(x => x.id === c.S.cls) || {}).name || '';
  const subjectName = () => ((c.classes.find(x => x.id === c.S.cls) || {subjects: []}).subjects.find(x => x.id === c.S.sub) || {}).name || '';
  function build() {
    panel = el('aside', {id: 'pts-panel', class: 'pts-panel', role: 'dialog', 'aria-label': 'نقاط الطلاب', hidden: true});
    document.getElementById('stage').append(panel);
    panel.addEventListener('keydown', e => { if (e.key === 'Escape') hide(); });
  }
  function chips(values, current, on, fmt) {
    return el('div', {class: 'chips'}, values.map(v => { const b = el('button', {type: 'button', class: 'chip' + (v === current ? ' sel' : ''), text: fmt ? fmt(v) : String(v), 'aria-pressed': v === current ? 'true' : 'false'}); b.addEventListener('click', () => on(v)); return b; }));
  }
  function paint() {
    if (!panel) return;
    const cls = c.classes.find(x => x.id === c.S.cls), subj = subjectName();
    const close = el('button', {type: 'button', class: 'btn ghost small pts-x', text: '✕ إغلاق', 'aria-label': 'إغلاق لوحة النقاط'}); close.addEventListener('click', hide);
    const head = el('div', {class: 'pts-head'}, el('h2', {text: '⭐ نقاط الطلاب'}), close);
    if (!cls) { panel.replaceChildren(head, el('p', {class: 'pts-need', text: 'اختاري الفصل من أعلى الشاشة ليظهر طلابه.'})); return; }
    const where = el('p', {class: 'pts-where'}, el('b', {text: cls.name}), subj ? ' · ' + subj : '', c.classes.find(x => x.id === c.S.cls).subjects.length > 1 && !subj ? el('small', {class: 'pts-warn', text: ' — اختاري المادة من أعلى الشاشة لتُحسب النقاط لها'}) : '');
    if (!c.students.length) { panel.replaceChildren(head, where, el('p', {class: 'pts-need'}, 'لا توجد أسماء في هذا الفصل بعد. ', el('a', {href: '/students', target: '_blank', rel: 'noopener', text: 'أضيفي الطلاب'}))); return; }
    const amounts = el('div', {class: 'pts-amounts'}, el('b', {text: 'عدد النقاط:'}), chips([1, 2, 3, 5], amount, v => { amount = v; paint(); paintGrid(); }, v => '+' + v));
    const grid = el('div', {class: 'pts-grid', id: 'pts-grid', role: 'group', 'aria-label': 'اضغطي على اسم طالب لإعطائه النقاط'});
    const undoRow = el('div', {class: 'pts-undo', id: 'pts-undo'});
    const periods = [['today', 'اليوم'], ['week', 'الأسبوع'], ['term', 'الفصل']];
    const scope = c.S.sub && subj ? chips([false, true], bySubject, v => { bySubject = v; paint(); loadRanking(); }, v => (v ? subj : 'كل المواد')) : null;
    const top = el('div', {id: 'pts-top', class: 'pts-top'}, el('p', {class: 'muted', text: 'جارٍ التحميل…'}));
    const big = el('button', {type: 'button', class: 'btn ghost small', text: '🏆 اعرضي المتصدرين على الشاشة'}); big.addEventListener('click', showPodium);
    const set = el('details', {class: 'pts-set'}, el('summary', {text: '⚙ كم نقطة تُعطى تلقائيًا؟'}),
      el('p', {class: 'pts-set-l'}, el('b', {text: 'عند الإجابة الصحيحة'}), chips(range(settings.limits.correct), settings.correct, v => saveSettings({correct: v}))),
      el('p', {class: 'pts-set-l'}, el('b', {text: 'لمن حاول ولم يُصب'}), chips(range(settings.limits.try), settings.try, v => saveSettings({try: v}))),
      el('p', {class: 'muted', text: 'تُعطى النقطة تلقائيًا حين تسجّلين إجابة طالب، ويمكنك التراجع عنها بضغطة.'}));
    panel.replaceChildren(head, where, amounts, grid, undoRow, el('h3', {text: 'أفضل ثلاثة'}), chips(periods.map(x => x[0]), period, v => { period = v; paint(); loadRanking(); }, v => periods.find(x => x[0] === v)[1]), scope, top,
      el('div', {class: 'btn-row'}, big, el('a', {class: 'btn ghost small', href: '/points', target: '_blank', rel: 'noopener', text: '📒 السجل والتقارير'})), set);
    paintGrid(); paintUndo();
  }
  const range = ([a, b]) => Array.from({length: b - a + 1}, (_, i) => a + i);
  function paintGrid() {
    const grid = document.getElementById('pts-grid'); if (!grid) return;
    grid.replaceChildren(...c.students.map(s => {
      const n = today[s.id] || 0;
      const b = el('button', {type: 'button', class: 'pts-stu' + (n > 0 ? ' has' : ''), 'aria-label': s.name + (n ? '، اليوم ' + arP(n) : '') + '، إعطاء ' + arP(amount)}, el('span', {class: 'pts-name', text: s.name}), n ? el('span', {class: 'pts-today', text: '⭐ ' + n}) : null);
      b.addEventListener('click', () => { const rec = give(s, amount); if (rec) { toast('⭐ +' + amount + ' ' + s.name, rec); paintGrid(); paintUndo(); } });
      return b;
    }));
  }
  function paintUndo() {
    const row = document.getElementById('pts-undo'); if (!row) return;
    const last = given[given.length - 1];
    row.replaceChildren(); if (!last) return;
    const b = el('button', {type: 'button', class: 'btn ghost small', text: '↩ تراجع عن آخر نقطة (' + last.name + ' ' + (last.amount > 0 ? '+' : '') + last.amount + ')'}); b.addEventListener('click', () => undo(last));
    row.append(b);
  }
  async function loadToday() {
    if (!c.S.cls) return;
    try { const d = await api('GET', '/api/points/board?class_id=' + c.S.cls + '&period=today'); today = {}; d.rows.forEach(r => { today[r.student_id] = r.points; }); }
    catch (e) { lastError = e.message; }
    queue.forEach(p => { if (c.students.some(s => s.id === p.student_id) && !given.some(g => g.key === p.key)) today[p.student_id] = (today[p.student_id] || 0) + p.amount; });          // left from an earlier sitting and not sent yet
    paintGrid();
  }
  async function loadRanking() {
    const box = document.getElementById('pts-top'); if (!box || !c.S.cls) return;
    try {
      ranked = await api('GET', '/api/points/board?class_id=' + c.S.cls + '&period=' + period + (bySubject && c.S.sub ? '&subject_id=' + c.S.sub : ''));
      box.replaceChildren(podium(ranked.top, ranked.more, false));
    } catch (e) { box.replaceChildren(el('p', {class: 'muted', text: 'تعذّر تحميل الترتيب: ' + e.message})); }
  }
  async function saveSettings(patch) {
    try { const r = await api('PUT', '/api/points/settings', patch); settings = Object.assign(settings, r); } catch (e) { toast(e.message); }
    const open = panel && panel.querySelector('.pts-set') && panel.querySelector('.pts-set').open; paint(); const d = panel.querySelector('.pts-set'); if (d && open) d.open = true;
  }
  // the panel starts under the bar, so the buttons of the bar (pause, focus, full screen) stay within reach while it is open
  function place() {
    if (!panel) return;
    const bar = document.querySelector('#stage .bar');
    panel.style.top = (bar && bar.offsetParent !== null ? Math.max(0, Math.round(bar.getBoundingClientRect().bottom)) : 0) + 'px';
  }
  window.addEventListener('resize', place);
  function show() { if (!panel) build(); panel.hidden = false; place(); paint(); loadToday().then(loadRanking); const x = panel.querySelector('.pts-x'); if (x) x.focus(); }
  function hide() { if (panel) panel.hidden = true; const b = document.getElementById('b-points'); if (b) b.focus(); }

  L.points = {
    init(ctx) {
      c = ctx; loadQueue(); status();
      api('GET', '/api/points/settings').then(s => { settings = Object.assign(settings, s); }).catch(() => {});
      flush();
    },
    answered,
    toggle() { if (!c) return; if (panel && !panel.hidden) hide(); else show(); },
    context() { if (c && panel && !panel.hidden) { place(); paint(); loadToday().then(loadRanking); } },
  };
})();
