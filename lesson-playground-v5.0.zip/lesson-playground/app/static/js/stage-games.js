// Two activities on the stage: «أسئلة تفاعلية» (choose who answers, run a timer, reveal) and «اختبار قصير» (5 / 10 / 15 questions, a score, saved by the student's name).
// They use the stage's own pieces (question card, fair round of students, saving a result), handed over in `c` by present.js.
(function () {
  const L = window.LPStage;

  // ------------------------------------------------------------------ interactive questions
  function timerBox(c) {
    const {S, el} = c;
    S.liveSecs = S.liveSecs || 20;
    let left = S.liveSecs, t = null;
    const clock = el('div', {class: 'clock', role: 'timer', 'aria-label': 'المؤقت', text: String(left)});
    const stop = () => { if (t) { clearInterval(t); t = null; } };
    const chips = el('div', {class: 'chips'}, [10, 20, 30, 45, 60].map(n => {
      const b = el('button', {class: 'chip' + (n === S.liveSecs ? ' sel' : ''), type: 'button', text: n + ' ث'});
      b.addEventListener('click', () => { S.liveSecs = n; c.save(); stop(); left = n; clock.textContent = String(n); clock.classList.remove('up'); chips.querySelectorAll('.chip').forEach(x => x.classList.toggle('sel', x === b)); });
      return b;
    }));
    const go = el('button', {class: 'btn ghost small', type: 'button', text: '⏱ ابدئي المؤقت'});
    go.addEventListener('click', () => {
      stop(); left = S.liveSecs; clock.textContent = String(left); clock.classList.remove('up');
      t = setInterval(() => {
        if (!document.body.contains(clock)) return stop();                    // the question changed: the timer goes with it
        left--; clock.textContent = String(Math.max(left, 0));
        if (left > 0 && left <= 5) c.beep(660, .08, .06);
        if (left <= 0) { stop(); clock.classList.add('up'); clock.textContent = '⏰ 0'; c.beep(440, .6, .09, 'sawtooth'); }
      }, 1000);
    });
    return el('div', {class: 'timerbox'}, clock, chips, go);
  }

  L.screens.live = function (c, first) {
    const {S, view, el} = c;
    let q = first && S.screen.qid ? c.byId(S.screen.qid) : null;
    if (!q) {
      const pool = c.unused('live');
      if (!pool.length) return c.finished('live');
      q = pool[c.fair(pool.length)];
      c.usedOf('live').push(q.id); S.screen.qid = q.id; S.screen.revealed = false; S.round.current = null; c.save();
    }
    const total = c.poolOf('live').length;
    const who = el('div', {class: 'whobox'});
    const paintWho = () => {
      const st = c.students.find(x => x.id === S.round.current);
      who.replaceChildren(st ? el('p', {class: 'picked small'}, el('small', {text: 'دور الطالبة'}), st.name) : el('p', {class: 'muted center', text: c.students.length ? 'اختاري من تجيب، أو اتركيه للصف كله' : 'السؤال للصف كله (أضيفي أسماء الطالبات لتسجيل النتائج)'}));
    };
    const choose = el('button', {class: 'btn big sun', type: 'button', text: '🎲 اختاري طالبة'});
    const all = el('button', {class: 'btn big ghost', type: 'button', text: '👥 الصف كله'});
    choose.hidden = all.hidden = !c.students.length || !c.present().length;
    choose.addEventListener('click', () => { c.pickStudent(); paintWho(); });
    all.addEventListener('click', () => { S.round.current = null; c.save(); paintWho(); });
    paintWho();
    const card = c.questionCard(q, 'live', ctrl => {
      choose.disabled = all.disabled = true;                                   // the answer is shown: who answered is fixed
      if (S.board) ctrl.before(c.awardRow());
      ctrl.append(c.nextBtn('live'));
    });
    view.replaceChildren(el('p', {class: 'progress', text: 'السؤال ' + Math.min(c.usedOf('live').length, total) + ' من ' + total}),
      el('div', {class: 'live-tools'}, timerBox(c), el('div', {class: 'live-who'}, who, el('div', {class: 'ctrl'}, choose, all))), card,
      c.students.length ? c.rosterPanel(() => L.screens.live(c, true)) : null);
    c.drawBoard();
  };

  // ------------------------------------------------------------------ the short quiz
  const level = pct => (pct >= 90 ? 'ممتاز 🌟' : pct >= 75 ? 'جيد جدًا 👏' : pct >= 60 ? 'جيد 👍' : 'يحتاج إلى مراجعة 📚');
  const shuffle = (a, c) => { const r = a.slice(); for (let i = r.length - 1; i > 0; i--) { const j = c.fair(i + 1); [r[i], r[j]] = [r[j], r[i]]; } return r; };
  const filled = q => (q.kind === 'cloze' ? q.question.split('_____').join('«' + q.answer + '»') : q.question);

  L.screens.quiz = function (c) {
    const Q = c.S.quiz;
    if (Q && Q.active && Q.ids.length && Q.ids.every(id => c.byId(id))) return run(c);
    if (Q && Q.done && Q.ids.length && Q.ids.every(id => c.byId(id))) return summary(c);
    return setup(c);
  };

  function setup(c) {
    const {S, view, el} = c;
    const pool = c.poolOf('quiz');
    if (pool.length < 2) {
      return view.replaceChildren(el('div', {class: 'qcard center'}, el('h2', {text: 'لا توجد أسئلة كافية للاختبار 📝'}), el('p', {class: 'qtext', text: 'نحتاج إلى سؤالين على الأقل من الأنواع: اختيار من متعدد، صح أو خطأ، أكمل الفراغ، سؤال قصير، سؤال وجواب.'}),
        el('div', {class: 'ctrl'}, el('a', {class: 'btn big sun', href: '/lessons/' + c.deck.lesson_id, text: 'أضيفي أسئلة'}), el('button', {class: 'btn big ghost', type: 'button', text: 'الأنشطة', onclick: c.menu}))));
    }
    const sizes = [5, 10, 15].filter(n => n <= pool.length);
    if (!sizes.length) sizes.push(pool.length);
    if (pool.length > sizes[sizes.length - 1] && pool.length <= 40) sizes.push(pool.length);
    let size = sizes.includes((S.quiz || {}).size) ? S.quiz.size : sizes[Math.min(1, sizes.length - 1)];
    const chips = el('div', {class: 'chips big'}, sizes.map(n => {
      const all = n === pool.length && ![5, 10, 15].includes(n);          // the last chip takes every question the lesson has; the others say how many, in correct Arabic («10 أسئلة»، «14 سؤالًا»)
      const b = el('button', {class: 'chip' + (n === size ? ' sel' : ''), type: 'button', text: all ? 'كل الأسئلة (' + n + ')' : window.arQ(n)});
      b.addEventListener('click', () => { size = n; chips.querySelectorAll('.chip').forEach(x => x.classList.toggle('sel', x === b)); }); return b;
    }));
    const pick = el('select', {'aria-label': 'من تؤدي الاختبار؟'}, el('option', {value: '', text: 'بدون اسم (لا تُحفظ النتيجة)'}), ...c.students.map(x => el('option', {value: x.id, text: x.name})));
    const prevSid = (S.quiz || {}).sid; if (prevSid && c.students.some(x => x.id === prevSid)) pick.value = prevSid;
    const hint = c.classes.length > 1 && !S.cls ? el('p', {class: 'muted', text: 'اختاري الفصل من أعلى الصفحة لتظهر أسماء طالباته.'}) : (!c.students.length ? el('p', {class: 'muted'}, 'لا توجد أسماء بعد. ', el('a', {href: '/students', target: '_blank', rel: 'noopener', text: 'أضيفي الفصول والطلاب'}), ' لتُحفظ النتائج بأسمائهم.') : null);
    const go = el('button', {class: 'btn big sun', type: 'button', text: 'ابدئي الاختبار ▶'});
    go.addEventListener('click', () => {
      const seen = new Set(), ids = [];
      for (const q of shuffle(pool, c)) { const k = q.evidence || String(q.id); if (!seen.has(k)) { seen.add(k); ids.push(q.id); } if (ids.length >= size) break; }          // one question per sentence
      S.quiz = {active: true, done: false, ids, i: 0, answers: {}, sid: pick.value ? Number(pick.value) : null, size, run: 'q' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6)};
      S.screen = {game: 'quiz', qid: null, revealed: false}; c.save(); c.toTop(); run(c);
    });
    view.replaceChildren(el('div', {class: 'qcard quiz-setup'}, el('h2', {class: 'center', text: 'اختبار قصير 📝'}),
      el('p', {class: 'center muted', text: 'الأسئلة من ملف الدرس فقط. أسئلة الاختيار وصح/خطأ تُصحَّح تلقائيًا، والباقي تصحّحينه بضغطة.'}),
      el('b', {text: 'عدد الأسئلة'}), chips, el('label', {}, el('b', {text: 'من تؤدي الاختبار؟'}), pick), hint, el('div', {class: 'ctrl'}, go)));
  }

  function run(c) {
    const {S, view, el} = c, Q = S.quiz;
    if (Q.i >= Q.ids.length) { Q.active = false; Q.done = true; c.save(); return summary(c); }
    const q = c.byId(Q.ids[Q.i]);
    const st = c.students.find(x => x.id === Q.sid) || null;
    const right = Object.values(Q.answers).filter(Boolean).length;
    const advance = () => el('button', {class: 'btn big', type: 'button', text: Q.i + 1 < Q.ids.length ? 'السؤال التالي ➜' : 'إنهاء الاختبار ✔', onclick: () => { Q.i++; S.screen = {game: 'quiz', qid: null, revealed: false}; c.save(); c.toTop(); run(c); }});
    const mark = (qq, game, out, picked) => {
      const box = el('div', {class: 'marks'}); out.append(box);
      const shown = correct => box.replaceChildren(el('p', {class: 'marked', text: (correct ? '✔ إجابة صحيحة' : '✘ إجابة غير صحيحة') + (st ? ' — سُجّلت باسم ' + st.name : '')}), advance());
      const record = async correct => {
        Q.answers[qq.id] = correct; c.save();
        if (st) { try { await c.saveResult(qq, 'quiz', st, correct, Q.run); } catch (e) { out.append(el('p', {class: 'marked', text: 'تعذر حفظ النتيجة: ' + e.message})); } }
        shown(correct);
      };
      if (Q.answers[qq.id] !== undefined) return shown(Q.answers[qq.id]);       // she came back to a question she already answered
      if (picked !== null) return record(picked);
      const ok = el('button', {class: 'btn ok', type: 'button', text: '✔ أجابت صحيحًا'}), no = el('button', {class: 'btn no', type: 'button', text: '✘ لم تجب صحيحًا'});
      ok.addEventListener('click', () => record(true)); no.addEventListener('click', () => record(false));
      box.append(el('div', {class: 'mark'}, ok, no));
    };
    view.replaceChildren(
      el('div', {class: 'quiz-head'}, el('span', {text: 'السؤال ' + (Q.i + 1) + ' من ' + Q.ids.length}), el('b', {text: st ? '👤 ' + st.name : 'بدون اسم'}), el('span', {text: '✔ ' + right})),
      el('progress', {class: 'qprog', max: Q.ids.length, value: Q.i, 'aria-label': 'تقدم الاختبار'}),
      c.questionCard(q, 'quiz', null, mark));
    c.drawBoard();
  }

  function summary(c) {
    const {S, view, el} = c, Q = S.quiz;
    c.toTop();
    const n = Q.ids.length, right = Q.ids.filter(id => Q.answers[id]).length, pct = Math.round(100 * right / n);
    const missed = Q.ids.map(id => c.byId(id)).filter(q => Q.answers[q.id] === false);
    const st = c.students.find(x => x.id === Q.sid) || null;
    const again = el('button', {class: 'btn big sun', type: 'button', text: 'طالبة أخرى ▶'});
    again.addEventListener('click', () => { S.quiz = {active: false, done: false, ids: [], size: Q.size, sid: null}; c.save(); setup(c); });
    const same = el('button', {class: 'btn big ghost', type: 'button', text: '↻ الأسئلة نفسها'});
    same.addEventListener('click', () => { S.quiz = Object.assign({}, Q, {active: true, done: false, i: 0, answers: {}, run: 'q' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6)}); S.screen = {game: 'quiz', qid: null, revealed: false}; c.save(); c.toTop(); run(c); });
    const home = el('button', {class: 'btn big ghost', type: 'button', text: '🏠 الأنشطة', onclick: c.menu});
    view.replaceChildren(el('div', {class: 'qcard center sumcard'},
      el('h2', {text: 'نتيجة الاختبار' + (st ? ' — ' + st.name : '')}),
      el('p', {class: 'bignum', text: right + ' / ' + n}), el('p', {class: 'qtext', text: pct + '٪ · ' + level(pct)}),
      el('p', {class: 'muted', text: st ? '✔ حُفظت نتيجة كل سؤال في ملف ' + st.name + ' (صفحة الطلاب).' : 'لم تُحفظ النتيجة في ملف طالبة لأنكِ لم تختاري اسمًا. اختاريه في المرة القادمة.'}),
      missed.length ? el('div', {class: 'missed'}, el('b', {text: 'أسئلة تحتاج مراجعة (' + missed.length + ')'}), el('ul', {}, missed.map(q => el('li', {}, filled(q), el('small', {text: 'الإجابة: ' + q.answer}))))) : el('p', {class: 'answer', text: 'أجابت عن كل الأسئلة بشكل صحيح 🎉'}),
      el('div', {class: 'ctrl'}, again, same, home)));
    c.drawBoard();
  }
})();
