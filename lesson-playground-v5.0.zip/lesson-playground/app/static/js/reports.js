// «التقارير»: one report for a class (points, answers, who has not taken part, where the plan stands) and one for a student (with a short summary she may copy or send by WhatsApp herself).
(function () {
  const F = window.LPFollow, $ = id => document.getElementById(id);
  const lessonsW = n => arCount(n, ['درس واحد', 'درسان', 'دروس', 'درسًا']), timesW = n => arCount(n, ['مرة واحدة', 'مرتين', 'مرات', 'مرة']);
  const hwW = n => arCount(n, ['واجب واحد', 'واجبان', 'واجبات', 'واجبًا']);
  const HW_BADGE = {done: 'st-ok', partial: 'st-warn', missing: 'st-bad', pending: 'st-wait'};
  let token = 0, view = {student: null};
  const say = (id, text) => { const n = $(id); n.textContent = text || ''; n.hidden = !text; };
  const tile = (value, label, note) => el('div', {class: 'stat-tile'}, el('b', {text: String(value)}), el('span', {text: label}), note ? el('small', {text: note}) : null);
  const lvl = p => (p >= 85 ? 'a' : p >= 65 ? 'b' : 'c');
  const rangeText = r => {
    if (!r.first) return r.period_name + (r.period === 'term' ? ' (كل النقاط)' : '');
    return r.first === r.last ? r.first_text : r.period_name + ': ' + r.first_text + ' ← ' + r.last_text;
  };
  const queryNoClass = () => { const q = new URLSearchParams(F.query()); q.delete('class_id'); return q.toString(); };
  const studentOf = id => F.students.find(s => s.id === id) || null;

  // ------------------------------------------------------------ start
  async function start() {
    try { await F.load(); } catch (e) { return say('rp-err', e.message); }
    pending(await F.flushPending().catch(() => ({left: F.waiting()})));
    if (!F.classes.length) { $('rp-none').hidden = false; $('rp-pick').hidden = true; return; }
    syncFromUrl();
    $('rp-body').hidden = false;
    const mounted = F.mount({classes: 'rp-classes', subjects: 'rp-subjects', periods: 'rp-periods', subjectRow: 'rp-subject-row'}, state => {
      const st = view.student && studentOf(view.student);
      if (st && st.class_id !== state.cls) { view.student = null; history.replaceState(null, '', '/reports'); }
      show();
    });
    show();
    window.addEventListener('popstate', () => { syncFromUrl(); mounted.redraw(); show(); });
    window.addEventListener('online', async () => { pending(await F.flushPending().catch(() => ({left: F.waiting()}))); show(); });
  }
  function pending(r) {
    say('rp-pending', r && r.left ? '⏳ ' + arP(r.left) + ' أعطيتِها أثناء العرض ولم تصل إلى حسابك بعد لأن الاتصال غير متاح، فلا تظهر في الأرقام الآتية. تُرسل وحدها عند عودته.' : '');
  }
  // ?student=12 opens that student's report, in her class
  function syncFromUrl() {
    const id = Number(new URLSearchParams(location.search).get('student')), st = id ? studentOf(id) : null;
    view.student = st ? st.id : null;
    if (st && st.class_id && F.state.cls !== st.class_id) { F.state.cls = st.class_id; F.state.sub = null; F.save(); }
  }
  function show() { view.student ? showStudent(view.student) : showClass(); }
  function openStudent(id) { history.pushState(null, '', '/reports?student=' + id); view.student = id; show(); window.scrollTo({top: 0}); }
  function closeStudent() { history.pushState(null, '', '/reports'); view.student = null; show(); }

  // ------------------------------------------------------------ the report of a class
  async function showClass() {
    const my = ++token;
    $('rp-class').hidden = false; $('rp-student').hidden = true;
    try {
      const r = await api('GET', '/api/reports/class/' + F.state.cls + '?' + F.query());
      if (my !== token) return;
      say('rp-err', ''); drawClass(r);
    } catch (e) { if (my === token) say('rp-err', e.message); }
  }
  function drawClass(r) {
    const title = 'تقرير ' + r.class.name + (r.subject ? ' · ' + r.subject.name : '');
    $('rp-title').textContent = title; $('rp-range').textContent = rangeText(r);
    $('rp-print-line').textContent = 'ملعب الدرس · ' + title + ' · ' + rangeText(r);
    $('rp-term-note').hidden = !(r.period === 'term' && !r.first);
    const tiles = [tile(r.students, 'طلاب الفصل'), tile(r.points, 'مجموع النقاط', 'أُعطيت ' + timesW(r.awards)), tile(r.ranked + ' من ' + r.students, 'حصلوا على نقاط')];
    if (r.answers) {
      const n = r.rows.reduce((a, x) => a + (x.answered || 0), 0), ok = r.rows.reduce((a, x) => a + (x.correct || 0), 0);
      tiles.push(n ? tile(ok + ' من ' + n, 'إجابات صحيحة', Math.round(100 * ok / n) + '٪') : tile(0, 'أسئلة أُجيب عنها'));
    }
    const hw = r.homework;
    if (hw && hw.given) tiles.push(hw.percent == null ? tile('—', 'إنجاز الواجبات', hwW(hw.given) + ' · لم تُسجَّل حالات بعد') : tile(hw.percent + '٪', 'إنجاز الواجبات', hwW(hw.given) + ' · ممن سُجّلت حالتهم'));
    $('rp-tiles').replaceChildren(...tiles);
    $('rp-podium').replaceChildren(F.podium(r.top, r.more, false));
    $('rp-chart-box').hidden = r.days.length < 2;
    if (r.days.length > 1) F.chart($('rp-chart'), r.days, 'النقاط في كل يوم لفصل ' + r.class.name);
    drawTable(r);
    $('rp-silent').hidden = !r.silent.length;
    if (r.silent.length) $('rp-silent').textContent = 'لم يشارك بعد في هذه الفترة (لا نقاط ولا أسئلة): ' + r.silent.join('، ') + '.';
    drawPlans(r);
    $('rp-csv').href = '/api/reports/class/' + r.class.id + '/csv?' + F.query();
  }
  function drawTable(r) {
    $('rp-no-students').hidden = !!r.rows.length;
    $('rp-answers-note').hidden = r.answers || !r.rows.length;
    const table = $('rp-table'); table.hidden = !r.rows.length;
    const hwOn = !!(r.homework && r.homework.given), hwBy = new Map(hwOn ? r.homework.students.map(x => [x.student_id, x]) : []);
    const heads = ['#', 'الطالب', 'النقاط', 'المرات'].concat(r.answers ? ['الأسئلة', 'الصحيحة', 'النسبة', 'المستوى'] : [], hwOn ? ['الواجبات'] : [], ['آخر مشاركة', '']);
    const body = el('tbody', {}, r.rows.map(x => {
      const open = el('button', {type: 'button', class: 'btn ghost small noprint', text: 'تقرير الطالب', 'aria-label': 'تقرير ' + x.name});
      open.addEventListener('click', () => openStudent(x.student_id));
      const cells = [el('td', {class: 'num'}, el('span', {class: 'rank-n sm' + (x.rank && x.rank <= 3 ? ' r' + x.rank : ''), text: x.rank ? String(x.rank) : '–'})), el('td', {}, el('b', {text: x.name})), el('td', {class: 'num', text: String(x.points)}), el('td', {class: 'num', text: String(x.awards)})];
      if (r.answers) cells.push(el('td', {class: 'num', text: String(x.answered)}), el('td', {class: 'num', text: String(x.correct)}), el('td', {class: 'num', text: x.percent == null ? '—' : x.percent + '٪'}),
        el('td', {}, x.level ? el('span', {class: 'lvl l' + lvl(x.percent), text: x.level}) : '—'));
      if (hwOn) { const h = hwBy.get(x.student_id); cells.push(el('td', {class: 'num', text: h && h.checked ? 'أنجز ' + h.done + ' من ' + h.checked : '—'})); }
      cells.push(el('td', {text: x.last_day ? F.dayText(x.last_day) : '—'}), el('td', {class: 'acts'}, open));
      return el('tr', {class: x.points <= 0 && !x.answered ? 'quiet' : ''}, cells);
    }));
    table.replaceChildren(el('thead', {}, el('tr', {}, heads.map(h => el('th', {scope: 'col', text: h})))), body);
    tableHint();
  }
  // on a narrow screen the table is wider than the card: say so, so nobody thinks the columns on the far side are missing
  function tableHint() { const w = $('rp-tbl-wrap'); $('rp-tbl-hint').hidden = $('rp-table').hidden || !(w.scrollWidth > w.clientWidth + 2); }
  window.addEventListener('resize', () => requestAnimationFrame(tableHint));
  function drawPlans(r) {
    $('rp-plans-box').hidden = !r.plans.length;
    $('rp-plans').replaceChildren(...r.plans.map(p => {
      const head = el('div', {class: 'pb-head'}, el('b', {text: p.subject_name}), p.book ? el('span', {class: 'muted', text: p.book}) : null);
      if (p.need) return el('div', {class: 'plan-bar'}, head, el('p', {class: 'muted'}, 'لم تُبنَ خطة هذه المادة بعد. ', el('a', {href: '/plan', text: 'فتح الخطة'}), '.'));
      return el('div', {class: 'plan-bar'}, head,
        el('div', {class: 'pb-line'}, el('progress', {max: '100', value: String(p.percent), 'aria-label': 'نسبة الإنجاز'}), el('b', {text: p.percent + '٪'}),
          el('span', {class: 'rp-tag ' + (p.late ? 'late' : 'ok'), text: p.late ? 'تأخر ' + lessonsW(p.late) : 'في موعدها'})),
        p.current ? el('small', {class: 'muted', text: 'الدرس الحالي: ' + p.current}) : null);
    }));
  }

  // ------------------------------------------------------------ the report of a student
  async function showStudent(id) {
    const my = ++token;
    $('rp-class').hidden = true; $('rp-student').hidden = false;
    try {
      const r = await api('GET', '/api/reports/student/' + id + '?' + queryNoClass());
      if (my !== token) return;
      say('rp-err', ''); drawStudent(r);
    } catch (e) { if (my === token) say('rp-err', e.message); }
  }
  async function copyText(text, btn) {
    try { await navigator.clipboard.writeText(text); }
    catch (e) { const ta = el('textarea', {class: 'sr-only', 'aria-hidden': 'true', tabindex: '-1'}); ta.value = text; document.body.append(ta); ta.select(); try { document.execCommand('copy'); } catch (x) {} ta.remove(); }
    const old = btn.textContent; btn.textContent = 'تم النسخ ✓'; setTimeout(() => { btn.textContent = old; }, 2200);
  }
  function drawStudent(r) {
    const s = r.student, range = rangeText(r), back = el('button', {type: 'button', class: 'btn ghost small noprint', text: '← تقرير ' + s.class_name});
    back.addEventListener('click', closeStudent);
    const tiles = [tile(r.points, 'نقاطه', 'أُعطيت ' + timesW(r.awards)), tile(r.rank ? r.rank + ' من ' + r.classmates : '—', 'مركزه في الفصل', r.rank ? null : 'لا نقاط بعد')];
    if (r.answers) tiles.push(r.answers.answered ? tile(r.answers.correct + ' من ' + r.answers.answered, 'إجابات صحيحة', r.answers.percent + '٪ · ' + r.answers.level) : tile(0, 'أسئلة أُجيب عنها'));
    const hw = r.homework;
    if (hw && hw.given) tiles.push(hw.checked ? tile(hw.done + ' من ' + hw.checked, 'واجبات أنجزها', hw.percent + '٪') : tile('—', 'الواجبات', hwW(hw.given) + ' · لم تُراجَع بعد'));
    const kids = [back,
      el('div', {class: 'sum-head'}, el('h2', {text: 'تقرير الطالب: ' + s.name}), el('span', {class: 'muted', text: s.class_name + (r.subject ? ' · ' + r.subject.name : '') + ' · ' + range})),
      el('p', {class: 'print-only', text: 'ملعب الدرس · تقرير الطالب ' + s.name + ' · ' + s.class_name + ' · ' + range}),
      el('div', {class: 'stat-tiles'}, tiles)];

    if (r.by_subject.length > 1 || (r.by_subject.length === 1 && !r.subject)) {
      const max = Math.max(1, ...r.by_subject.map(x => x.points));
      kids.push(el('h3', {text: 'حسب المادة'}), el('ul', {class: 'sub-bars'}, r.by_subject.map(x => el('li', {}, el('span', {text: x.name}), el('progress', {max: String(max), value: String(Math.max(0, x.points)), 'aria-hidden': 'true'}), el('b', {text: String(x.points)})))));
    }
    if (r.days.length > 1) { const box = el('div', {class: 'chart'}); kids.push(el('h3', {text: 'نقاطه في كل يوم'}), box); setTimeout(() => F.chart(box, r.days, 'نقاط ' + s.name + ' في كل يوم'), 0); }

    kids.push(el('h3', {text: 'آخر النقاط'}));
    if (!r.recent.length) kids.push(el('p', {class: 'muted', text: 'لم يحصل على نقاط في هذه الفترة.'}));
    else kids.push(el('ul', {class: 'plog'}, r.recent.map(e => el('li', {class: 'pl ro'},
      el('span', {class: 'pl-amt' + (e.amount < 0 ? ' neg' : ''), text: (e.amount > 0 ? '+' : '−') + Math.abs(e.amount)}),
      el('div', {class: 'pl-main'}, el('b', {text: e.day_text}), el('small', {text: [e.subject, e.label, e.source === 'game' && e.ref ? '«' + e.ref + '»' : '', e.note ? 'ملاحظة: ' + e.note : ''].filter(Boolean).join(' · ')}))))));

    if (hw && hw.recent.length) kids.push(el('h3', {text: 'آخر الواجبات'}), el('div', {class: 'tbl-wrap'}, el('table', {class: 'tbl'},
      el('thead', {}, el('tr', {}, ['الواجب', 'موعد التسليم', 'الحالة'].map(h => el('th', {scope: 'col', text: h})))),
      el('tbody', {}, hw.recent.map(x => el('tr', {}, el('td', {}, el('a', {href: '/homework/' + x.id, text: x.icon + ' ' + x.title}), x.subject ? el('small', {class: 'muted', text: ' · ' + x.subject}) : null),
        el('td', {text: x.due_text || '—'}), el('td', {}, el('span', {class: 'badge ' + HW_BADGE[x.status], text: x.status_name}))))))));

    if (r.answers && r.decks.length) kids.push(el('h3', {text: 'نتائج الأسئلة حسب العرض'}), el('div', {class: 'tbl-wrap'}, el('table', {class: 'tbl'},
      el('thead', {}, el('tr', {}, ['العرض', 'الأسئلة', 'الصحيحة', 'النسبة'].map(h => el('th', {scope: 'col', text: h})))),
      el('tbody', {}, r.decks.map(d => el('tr', {}, el('td', {text: d.title}), el('td', {class: 'num', text: String(d.answered)}), el('td', {class: 'num', text: String(d.correct)}), el('td', {class: 'num', text: d.percent == null ? '—' : d.percent + '٪'})))))));

    const copy = el('button', {type: 'button', class: 'btn ghost small', text: '📋 نسخ النص'}); copy.addEventListener('click', () => copyText(r.text, copy));
    kids.push(el('div', {class: 'noprint rp-share'}, el('h3', {text: 'ملخص يمكنك إرساله'}), el('pre', {class: 'rp-msg', text: r.text}),
      el('p', {class: 'muted', text: 'لا يرسل التطبيق شيئًا: يفتح واتساب والنص مكتوب، وتختارين أنتِ المستلم وتضغطين إرسال.'}),
      el('div', {class: 'btn-row'}, copy, el('a', {class: 'btn ghost small', href: r.wa, target: '_blank', rel: 'noopener', text: '💬 فتح واتساب بالنص'}), el('button', {type: 'button', class: 'btn ghost small', 'data-print': '', text: '🖨 طباعة / حفظ PDF'}))));
    $('rp-student').replaceChildren(...kids);
  }

  start();
})();
