// «الاختبارات»: the list of her exams and the form that builds a new one from the lessons she ticks. The questions come from the text of the book itself;
// editing them, approving the exam, the paper and the marks are on the exam's own page (exam.js).
(function () {
  const $ = id => document.getElementById(id);
  const say = (id, text) => { const n = $(id); n.textContent = text || ''; n.hidden = !text; };
  const lessonsW = n => arCount(n, ['درس واحد', 'درسان', 'دروس', 'درسًا']);
  const TOTALS = [10, 20, 30, 40, 50];
  let classes = [], exams = [], filter = 0, srcToken = 0;
  const W = {cls: 0, sub: 0, src: null, lessons: new Set(), uploads: new Set(), counts: null, kinds: [], headerSet: false};
  const classOf = id => classes.find(c => c.id === id) || null;
  const chip = (label, sel, fn) => { const b = el('button', {type: 'button', class: 'chip-btn' + (sel ? ' on' : ''), 'aria-pressed': sel ? 'true' : 'false', text: label}); b.addEventListener('click', fn); return b; };

  // ------------------------------------------------------------ start
  async function start() {
    try {
      const [c, l] = await Promise.all([api('GET', '/api/classes'), api('GET', '/api/exams')]);
      classes = c.classes || []; exams = l.exams || [];
    } catch (e) { return say('ex-load-err', e.message); }
    if (!classes.length) { $('ex-none').hidden = false; return; }
    $('ex-main').hidden = false;
    drawFilter(); drawList();
    $('ex-new').addEventListener('click', () => ($('ex-form').hidden ? openForm() : closeForm()));
    $('ex-cancel').addEventListener('click', closeForm);
    $('ex-form').addEventListener('submit', submit);
    $('ex-q-done').addEventListener('click', () => pickWhere(l => l.done && l.has_text, 'لا توجد دروس منجزة لها نص في خطة هذا الفصل بعد.'));
    $('ex-q-all').addEventListener('click', () => pickWhere(l => l.has_text, 'لا توجد دروس لها نص.'));
    $('ex-q-none').addEventListener('click', () => { W.lessons.clear(); W.uploads.clear(); drawTree(); });
    $('ex-total-chips').replaceChildren(...TOTALS.map(n => { const b = el('button', {type: 'button', class: 'chip-btn', text: String(n)}); b.addEventListener('click', () => { $('ex-total').value = String(n); }); return b; }));
    if (!exams.length) openForm();
  }

  // ------------------------------------------------------------ the list
  function drawFilter() {
    const host = $('ex-filter'), withExams = classes.filter(c => exams.some(e => e.class && e.class.id === c.id));
    host.hidden = withExams.length < 2;
    host.replaceChildren(...(withExams.length < 2 ? [] : [chip('كل الفصول', !filter, () => { filter = 0; drawFilter(); drawList(); }),
      ...withExams.map(c => chip(c.name, filter === c.id, () => { filter = c.id; drawFilter(); drawList(); }))]));
  }
  function drawList() {
    const shown = exams.filter(e => !filter || (e.class && e.class.id === filter));
    $('ex-empty').hidden = shown.length > 0;
    $('ex-list').replaceChildren(...shown.map(item));
  }
  function item(e) {
    const approved = e.status === 'approved';
    const bits = [e.class && e.class.name, e.subject && e.subject.name, e.date_text, arQ(e.count), e.count ? arMarks(e.total) : ''].filter(Boolean);
    const sc = e.scores && e.scores.entered ? 'سُجّلت درجات ' + e.scores.entered + ' من ' + e.scores.students + (e.scores.average != null ? ' · المتوسط ' + e.scores.average + (e.scores.percent != null ? ' (' + e.scores.percent + '٪)' : '') : '') : (approved ? 'لم تُسجَّل درجات بعد' : '');
    const del = el('button', {type: 'button', class: 'btn ghost small danger', text: 'حذف'});
    del.addEventListener('click', async () => {
      if (!confirm('حذف «' + e.title + '» مع أسئلته ودرجات طلابه؟ لا يمكن التراجع عن ذلك.')) return;
      del.disabled = true;
      try { await api('DELETE', '/api/exams/' + e.id); exams = exams.filter(x => x.id !== e.id); drawFilter(); drawList(); say('ex-load-err', ''); }
      catch (err) { del.disabled = false; say('ex-load-err', err.message); }
    });
    return el('li', {class: 'ex-item'},
      el('div', {class: 'ex-main'},
        el('div', {class: 'ex-title-line'}, el('a', {href: '/exams/' + e.id, text: e.title}), el('span', {class: 'badge ' + (approved ? 'st-ok' : 'st-wait'), text: e.status_text})),
        el('small', {text: bits.join(' · ')}), sc ? el('small', {text: sc}) : null),
      el('div', {class: 'ex-acts'}, el('a', {class: 'btn small', href: '/exams/' + e.id, text: 'فتح'}), del));
  }

  // ------------------------------------------------------------ the new exam
  function openForm() {
    const f = $('ex-form');
    f.hidden = false;
    if (!W.cls || !classOf(W.cls)) {
      const last = exams[0] && exams[0].class ? exams[0].class.id : 0;
      W.cls = classOf(filter) ? filter : (classOf(last) ? last : classes[0].id);
      const prev = exams.find(e => e.class && e.class.id === W.cls && e.subject);
      const subs = classOf(W.cls).subjects;
      W.sub = prev && subs.some(s => s.id === prev.subject.id) ? prev.subject.id : (subs[0] ? subs[0].id : 0);
    }
    drawPick(); loadSources();
    if (exams.length) f.scrollIntoView({behavior: 'smooth', block: 'start'});
  }
  function closeForm() { $('ex-form').hidden = true; say('ex-err', ''); }
  function drawPick() {
    const subs = classOf(W.cls).subjects;
    $('ex-classes').replaceChildren(...classes.map(c => chip(c.name, c.id === W.cls, () => {
      if (c.id === W.cls) return;
      W.cls = c.id; W.sub = c.subjects[0] ? c.subjects[0].id : 0; W.lessons.clear(); W.uploads.clear(); drawPick(); loadSources();
    })));
    $('ex-subject-row').hidden = !subs.length;
    $('ex-nosubject').hidden = subs.length > 0;
    $('ex-subjects').replaceChildren(...subs.map(s => chip(s.name, s.id === W.sub, () => {
      if (s.id === W.sub) return;
      W.sub = s.id; W.lessons.clear(); W.uploads.clear(); drawPick(); loadSources();
    })));
  }
  async function loadSources() {
    const my = ++srcToken, host = $('ex-tree');
    host.replaceChildren(el('p', {class: 'muted', text: 'جارٍ تحميل الدروس…'}));
    try {
      const d = await api('GET', '/api/exams/sources?class_id=' + W.cls + '&subject_id=' + (W.sub || 0));
      if (my !== srcToken) return;
      W.src = d; W.kinds = d.kinds;
      if (!W.counts) { W.counts = {}; d.kinds.forEach(k => { W.counts[k.key] = k.count; }); }
      if (!W.headerSet) { $('ex-header').value = d.header || ''; W.headerSet = true; }
      drawTree(); drawCounts();
    } catch (e) { if (my === srcToken) host.replaceChildren(el('p', {class: 'note bad', role: 'alert', text: e.message})); }
  }

  // the lessons: by unit, with a box for the whole unit; a lesson without a text cannot give questions, and says so
  function pickWhere(test, none) {
    let n = 0;
    (W.src ? W.src.units : []).forEach(u => u.lessons.forEach(l => { if (test(l)) { W.lessons.add(l.id); n++; } }));
    drawTree();
    if (!n) $('ex-picked').textContent = none;
  }
  function drawTree() {
    const d = W.src, host = $('ex-tree');
    if (!d) return;
    $('ex-book-line').textContent = d.book ? 'كتاب المادة: ' + d.book.title : (W.sub ? 'لم تربطي كتابًا بهذه المادة في هذا الفصل بعد؛ اربطيه من صفحة «المنهج»، أو اختاري من دروسك أدناه.' : 'اختاري من دروسك التي رفعتِها.');
    $('ex-quick').hidden = !d.units.length;
    const syncs = [];
    const sync = () => syncs.forEach(f => f());
    const kids = d.units.map((u, ui) => {
      const pickable = u.lessons.filter(l => l.has_text);
      const all = el('input', {type: 'checkbox', 'aria-label': 'كل دروس هذه الوحدة'});
      all.disabled = !pickable.length;
      all.addEventListener('change', () => { pickable.forEach(l => (all.checked ? W.lessons.add(l.id) : W.lessons.delete(l.id))); drawTree(); });
      const boxes = u.lessons.map(l => {
        const box = el('input', {type: 'checkbox'});
        box.disabled = !l.has_text; box.checked = W.lessons.has(l.id);
        box.addEventListener('change', () => { (box.checked ? W.lessons.add(l.id) : W.lessons.delete(l.id)); sync(); countPicked(); });
        return el('li', {}, el('label', {class: 'ex-lesson' + (l.has_text ? '' : ' off'), title: l.has_text ? '' : 'لا نص لهذا الدرس في الكتاب. الصقي نصه من صفحة «الخطة» ليدخل في الاختبار.'}, box, el('span', {class: 't', text: l.title}),
          l.kind === 'review' ? el('span', {class: 'badge', text: 'مراجعة'}) : null, l.done ? el('span', {class: 'badge st-ok', text: 'منجز'}) : null, l.has_text ? null : el('span', {class: 'badge st-warn', text: 'بلا نص'})));
      });
      syncs.push(() => {
        const n = pickable.filter(l => W.lessons.has(l.id)).length;
        all.checked = pickable.length > 0 && n === pickable.length; all.indeterminate = n > 0 && n < pickable.length;
      });
      const picked = u.lessons.filter(l => W.lessons.has(l.id)).length;
      return el('details', {class: 'ex-unit', open: d.units.length <= 3 || picked > 0 || ui === 0},
        el('summary', {}, el('span', {text: u.title || 'دروس بلا وحدة'}), el('small', {text: lessonsW(u.lessons.length)})),
        el('ul', {class: 'ex-lessons'}, el('li', {}, el('label', {class: 'ex-lesson all'}, all, el('span', {class: 't', text: 'كل دروس الوحدة التي لها نص'}))), ...boxes));
    });
    if (d.uploads.length) {
      const boxes = d.uploads.map(u => {
        const box = el('input', {type: 'checkbox'}); box.checked = W.uploads.has(u.id);
        box.addEventListener('change', () => { (box.checked ? W.uploads.add(u.id) : W.uploads.delete(u.id)); countPicked(); });
        return el('li', {}, el('label', {class: 'ex-lesson'}, box, el('span', {class: 't', text: u.title}), u.subject ? el('span', {class: 'badge', text: u.subject}) : null));
      });
      kids.push(el('details', {class: 'ex-unit', open: !d.units.length}, el('summary', {}, el('span', {text: 'دروسي التفاعلية (من الملفات التي رفعتِها)'}), el('small', {text: lessonsW(d.uploads.length)})), el('ul', {class: 'ex-lessons'}, ...boxes)));
    }
    if (!kids.length) kids.push(el('p', {class: 'empty', text: 'لا توجد دروس لهذا الاختيار بعد. أضيفي كتاب المادة من «المنهج»، أو ارفعي درسًا من «لوحتي».'}));
    host.replaceChildren(...kids);
    sync(); countPicked();
  }
  function countPicked() {
    const a = W.lessons.size, b = W.uploads.size;
    $('ex-picked').textContent = a + b ? 'اخترتِ ' + lessonsW(a + b) + (a && b ? ' (' + a + ' من الكتاب و' + b + ' من ملفاتك)' : '') + '.' : 'لم تختاري دروسًا بعد.';
  }

  // how many questions of each kind
  function drawCounts() {
    if (!W.counts) return;
    const rows = W.kinds.map(k => {
      const row = el('div', {class: 'ex-count' + (W.counts[k.key] ? ' on' : '')}, el('b', {text: k.name}), el('small', {text: 'درجة السؤال عادةً: ' + arMarks(k.marks)}),
        stepper(W.counts[k.key] || 0, 0, 40, v => { W.counts[k.key] = v; row.classList.toggle('on', v > 0); sumCounts(); }, 'عدد أسئلة «' + k.name + '»'));
      return row;
    });
    $('ex-counts').replaceChildren(...rows);
    sumCounts();
  }
  function sumCounts() {
    const n = Object.values(W.counts || {}).reduce((a, b) => a + b, 0);
    $('ex-count-sum').textContent = n ? 'المجموع: ' + arQ(n) + (n > 100 ? ' — الحد الأقصى 100 سؤال في الاختبار الواحد.' : '.') : 'لم تختاري عدد أي نوع بعد.';
  }

  async function submit(ev) {
    ev.preventDefault(); say('ex-err', '');
    const fail = t => { say('ex-err', t); $('ex-err').scrollIntoView({behavior: 'smooth', block: 'center'}); };
    if (!W.lessons.size && !W.uploads.size) return fail('اختاري درسًا واحدًا على الأقل من الدروس التي لها نص.');
    const wanted = {};
    let n = 0;
    W.kinds.forEach(k => { const c = W.counts[k.key] || 0; if (c) { wanted[k.key] = c; n += c; } });
    if (!n) return fail('اختاري عدد الأسئلة من نوع واحد على الأقل.');
    if (n > 100) return fail('الاختبار الواحد لا يتسع لأكثر من 100 سؤال.');
    const body = {class_id: W.cls, subject_id: W.sub || 0, lessons: [...W.lessons], uploads: [...W.uploads], wanted, title: $('ex-title').value, date: $('ex-date').value,
      minutes: Number($('ex-minutes').value) || 0, header: $('ex-header').value, notes: $('ex-notes').value};
    const total = $('ex-total').value.trim();
    if (total) body.total = total;
    const go = $('ex-go');
    go.disabled = true; $('ex-wait').hidden = false;
    try {
      const r = await api('POST', '/api/exams', body);
      try { if (r.skipped && r.skipped.length) sessionStorage.setItem('lp-exam-skipped-' + r.exam.id, JSON.stringify(r.skipped)); } catch (e) {}
      location.href = '/exams/' + r.exam.id;
    } catch (e) { go.disabled = false; $('ex-wait').hidden = true; fail(e.message); }
  }

  start();
})();
