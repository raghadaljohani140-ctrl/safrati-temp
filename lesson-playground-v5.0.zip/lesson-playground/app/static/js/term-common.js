// «نهاية الفصل» and the page of an archived term share this: the summary of a term drawn from the numbers the server worked out (a row of tiles for the whole term, then a block for
// each class: the first three, every student's line, the homework, the marks of the exams, where each plan stands). Everything here only reads: nothing on these pages changes a term.
(function () {
  const F = window.LPFollow, T = window.TM = {};
  const $ = id => document.getElementById(id);
  const timesW = n => arCount(n, ['مرة واحدة', 'مرتين', 'مرات', 'مرة']);
  const lessonsW = n => arCount(n, ['درس واحد', 'درسان', 'دروس', 'درسًا']);
  const hwW = n => arCount(n, ['واجب واحد', 'واجبان', 'واجبات', 'واجبًا']);
  const daysW = n => arCount(n, ['يوم واحد', 'يومان', 'أيام', 'يومًا']);
  const weeksW = n => arCount(n, ['أسبوع واحد', 'أسبوعان', 'أسابيع', 'أسبوعًا']);
  const examsW = n => arCount(n, ['اختبار واحد', 'اختباران', 'اختبارات', 'اختبارًا']);
  const pct = (a, b) => (b ? Math.round(100 * a / b) : null);
  Object.assign(T, {timesW, lessonsW, hwW, daysW, weeksW, examsW, pct});

  T.say = (id, text) => { const n = $(id); if (!n) return; n.textContent = text || ''; n.hidden = !text; };
  T.tile = (value, label, note) => el('div', {class: 'stat-tile'}, el('b', {text: String(value)}), el('span', {text: label}), note ? el('small', {text: note}) : null);
  T.rangeText = t => t.starts_text + ' ← ' + t.ends_text;
  T.csvOf = (base, name) => base + (name ? '?class=' + encodeURIComponent(name) : '');
  T.lvl = p => (p >= 85 ? 'a' : p >= 65 ? 'b' : 'c');
  // an exam mark the way it is written on the sheet: nothing yet, absent, or the mark
  T.markCell = v => (v == null ? '—' : v === 'غ' ? 'غ' : String(v));

  // ------------------------------------------------------------ the whole term
  T.totalsTiles = function (t) {
    const tiles = [T.tile(t.classes, 'فصولك', arS(t.students)), T.tile(t.points, 'مجموع النقاط', 'أُعطيت ' + timesW(t.awards))];
    tiles.push(t.answered ? T.tile(t.correct + ' من ' + t.answered, 'إجابات صحيحة', pct(t.correct, t.answered) + '٪') : T.tile(0, 'أسئلة أُجيب عنها'));
    const lessonNote = [t.lessons_pending ? 'بقي ' + t.lessons_pending : '', t.lessons_skipped ? 'استُبعد ' + t.lessons_skipped : ''].filter(Boolean).join(' · ');
    tiles.push(T.tile(t.lessons_done, 'دروس أُنجزت', lessonNote || null));
    if (t.homework_given) tiles.push(t.homework_percent == null ? T.tile('—', 'إنجاز الواجبات', hwW(t.homework_given) + ' · لم تُسجَّل حالات بعد') : T.tile(t.homework_percent + '٪', 'إنجاز الواجبات', hwW(t.homework_given)));
    if (t.exams) tiles.push(T.tile(t.exams, 'اختبارات معتمدة'));
    if (t.absence_days) tiles.push(T.tile(t.absence_days, 'أيام غياب', 'سجّلتِها في «غائب اليوم»'));
    if (t.holidays) tiles.push(T.tile(t.holidays, 'أيام إجازة', 'في التقويم'));
    return el('div', {class: 'stat-tiles tm-totals'}, tiles);
  };

  // ------------------------------------------------------------ one class
  function studentsTable(c) {
    const answers = c.answered > 0, hw = c.homework.given > 0;
    const heads = [{t: '#'}, {t: 'الطالب'}, {t: 'النقاط'}];
    if (answers) heads.push({t: 'الأسئلة'});
    if (hw) heads.push({t: 'الواجبات'});
    c.exams.forEach(e => heads.push({t: e.title, s: 'من ' + e.total_text}));
    if (c.exams.length) heads.push({t: 'متوسط الاختبارات'});
    const body = c.rows.map(r => {
      const cells = [el('td', {class: 'num'}, el('span', {class: 'rank-n sm' + (r.rank && r.rank <= 3 ? ' r' + r.rank : ''), text: r.rank ? String(r.rank) : '–'})), el('td', {}, el('b', {text: r.name})),
        el('td', {class: 'num', text: String(r.points)})];
      if (answers) cells.push(el('td', {class: 'num', text: r.answered ? r.correct + ' من ' + r.answered + (r.percent == null ? '' : ' (' + r.percent + '٪)') : '—'}));
      if (hw) cells.push(el('td', {class: 'num', text: r.hw_checked ? 'أنجز ' + r.hw_done + ' من ' + r.hw_checked : '—'}));
      r.scores.forEach(v => cells.push(el('td', {class: 'num' + (v === 'غ' ? ' abs' : ''), title: v === 'غ' ? 'غائب عن الاختبار' : null, text: T.markCell(v)})));
      if (c.exams.length) cells.push(el('td', {class: 'num', text: r.exam_percent == null ? '—' : r.exam_percent + '٪'}));
      return el('tr', {class: r.points <= 0 && !r.answered ? 'quiet' : ''}, cells);
    });
    const table = el('table', {class: 'tbl rep-tbl tm-tbl'}, el('thead', {}, el('tr', {}, heads.map(h => el('th', {scope: 'col'}, h.t, h.s ? el('small', {class: 'tm-th-s', text: h.s}) : null)))), el('tbody', {}, body));
    const wrap = el('div', {class: 'tbl-wrap', tabindex: '0', role: 'region', 'aria-label': 'طلاب ' + c.name}, table);
    const hint = el('p', {class: 'muted tbl-hint noprint', hidden: true, text: 'اسحبي الجدول جانبيًا لرؤية بقية الأعمدة.'});
    T.hints.push(() => { hint.hidden = !(wrap.scrollWidth > wrap.clientWidth + 2); });
    return [wrap, hint];
  }
  function examsTable(c) {
    if (!c.exams.length) return null;
    const heads = ['الاختبار', 'اليوم', 'الدرجة', 'سُجّلت درجاتهم', 'المتوسط', 'الأعلى', 'الأدنى', 'بلغوا نصف الدرجة'];
    const num = x => (x == null ? '—' : String(x));
    const rows = c.exams.map(e => el('tr', {},
      el('td', {}, el('b', {text: e.title}), e.subject ? el('small', {class: 'muted', text: ' · ' + e.subject}) : null),
      el('td', {text: e.date ? F.shortDay(e.date) : '—'}), el('td', {class: 'num', text: e.total_text}),
      el('td', {class: 'num', text: e.entered + ' من ' + e.students + (e.absent ? ' · غائب ' + e.absent : '')}),
      el('td', {class: 'num', text: e.average == null ? '—' : e.average + (e.percent == null ? '' : ' (' + e.percent + '٪)')}),
      el('td', {class: 'num', text: num(e.highest)}), el('td', {class: 'num', text: num(e.lowest)}), el('td', {class: 'num', text: e.entered ? e.passed + ' من ' + e.entered : '—'})));
    return el('div', {class: 'tbl-wrap', tabindex: '0', role: 'region', 'aria-label': 'اختبارات ' + c.name}, el('table', {class: 'tbl tm-exams'},
      el('thead', {}, el('tr', {}, heads.map(h => el('th', {scope: 'col', text: h})))), el('tbody', {}, rows)));
  }
  function plansList(c) {
    if (!c.plans.length) return null;
    return el('div', {}, c.plans.map(p => {
      const head = el('div', {class: 'pb-head'}, el('b', {text: p.subject}), p.book ? el('span', {class: 'muted', text: p.book}) : null);
      if (p.need) return el('div', {class: 'plan-bar'}, head, el('p', {class: 'muted', text: 'لم تُبنَ خطة هذه المادة في هذا الفصل الدراسي.'}));
      const counts = ['أُنجز ' + p.done, 'بقي ' + p.pending].concat(p.skipped ? ['استُبعد ' + p.skipped] : []).join(' · ');
      return el('div', {class: 'plan-bar'}, head,
        el('div', {class: 'pb-line'}, el('progress', {max: '100', value: String(p.percent), 'aria-label': 'نسبة الإنجاز'}), el('b', {text: p.percent + '٪'}),
          el('span', {class: 'rp-tag ' + (p.late ? 'late' : 'ok'), text: p.late ? 'تأخر ' + lessonsW(p.late) : 'في موعدها'})),
        el('small', {class: 'muted', text: counts}));
    }));
  }
  T.classBlock = function (c, opts) {
    const hw = c.homework, tiles = [T.tile(c.points, 'النقاط', 'أُعطيت ' + timesW(c.awards)), T.tile(c.ranked + ' من ' + c.students, 'حصلوا على نقاط')];
    if (c.answered) tiles.push(T.tile(c.correct + ' من ' + c.answered, 'إجابات صحيحة', pct(c.correct, c.answered) + '٪'));
    if (hw.given) tiles.push(hw.percent == null ? T.tile('—', 'إنجاز الواجبات', hwW(hw.given) + ' · لم تُراجَع') : T.tile(hw.percent + '٪', 'إنجاز الواجبات', hwW(hw.given)));
    if (c.exams.length) tiles.push(T.tile(c.exams.length, 'اختبارات معتمدة'));
    const kids = [el('div', {class: 'stat-tiles'}, tiles)];
    if (c.top.length) kids.push(el('h3', {text: 'أفضل ثلاثة'}), F.podium(c.top, 0, false));
    if (c.silent) kids.push(el('p', {class: 'note', text: arS(c.silent) + ' لم يحصلوا على نقاط ولم يجيبوا عن أسئلة في هذا الفصل الدراسي.'}));
    kids.push(el('h3', {text: 'الطلاب'}));
    if (c.rows.length) kids.push(...studentsTable(c)); else kids.push(el('p', {class: 'muted', text: 'لا توجد أسماء في هذا الفصل.'}));
    const exams = examsTable(c);
    if (exams) kids.push(el('h3', {text: 'الاختبارات'}), exams);
    const plans = plansList(c);
    if (plans) kids.push(el('h3', {text: 'أين وصلت الخطة'}), plans);
    kids.push(el('div', {class: 'btn-row noprint'}, el('a', {class: 'btn ghost small', href: T.csvOf(opts.csv, c.name), text: '⬇ جدول هذا الفصل (CSV)'})));
    return el('details', {class: 'tm-class', open: !!opts.open},
      el('summary', {}, el('b', {class: 'tm-cname', text: c.name}), el('span', {class: 'muted tm-cfig', text: arS(c.students) + ' · ' + arP(c.points)})),
      el('div', {class: 'tm-cbody'}, kids));
  };

  // ------------------------------------------------------------ the summary on a page
  T.hints = [];
  T.mount = function (host, s, opts) {
    T.hints.length = 0;
    const kids = [T.totalsTiles(s.totals)];
    if (!s.classes.length) kids.push(el('p', {class: 'empty', text: 'لا توجد فصول في حسابك بعد، فليس في الملخص ما يُعرض.'}));
    else {
      kids.push(el('h3', {text: s.classes.length === 1 ? 'فصلك' : 'فصولك'}));
      s.classes.forEach((c, i) => kids.push(T.classBlock(c, {csv: opts.csv, open: s.classes.length === 1 || i === 0})));
    }
    host.replaceChildren(...kids);
    host.querySelectorAll('details.tm-class').forEach(d => d.addEventListener('toggle', T.checkHints));
    T.checkHints();
  };
  // on a narrow screen a table is wider than its card: say so, so nobody thinks the columns on the far side are missing
  T.checkHints = () => requestAnimationFrame(() => T.hints.forEach(f => f()));
  window.addEventListener('resize', T.checkHints);

  // every class is opened for the paper and put back as it was after
  const was = new Map();
  window.addEventListener('beforeprint', () => document.querySelectorAll('details.tm-class').forEach(d => { was.set(d, d.open); d.open = true; }));
  window.addEventListener('afterprint', () => { was.forEach((v, d) => { d.open = v; }); was.clear(); });
})();
