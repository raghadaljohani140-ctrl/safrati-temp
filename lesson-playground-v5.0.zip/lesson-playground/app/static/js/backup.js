// «نسختي الاحتياطية»: download a copy of the account, look inside a copy before it is put back, put it back, and go back to the account as it was before the last restore.
// Nothing here decides anything: the server reads the file, tries it, and writes it all or not at all; this page shows what it said and asks before every step that replaces data.
(function () {
  const $ = id => document.getElementById(id), root = $('bk-root'), MAX_MB = Number(root.dataset.maxMb) || 40;
  const ROWS = [['classes', 'الفصول'], ['students', 'الطلاب'], ['subjects', 'المواد'], ['books', 'الكتب'], ['book_lessons', 'دروس الكتب'], ['lessons', 'الدروس المرفوعة'], ['questions', 'الأسئلة'],
    ['decks', 'العروض'], ['points', 'تسجيلات النقاط'], ['results', 'إجابات الطلاب في الألعاب'], ['assignments', 'الواجبات'], ['exams', 'الاختبارات'], ['plan_items', 'دروس الخطة'],
    ['terms', 'الفصول الدراسية'], ['term_archives', 'الفصول المؤرشفة']];
  const TILES = [['classes', 'الفصول'], ['students', 'الطلاب'], ['lessons', 'الدروس'], ['decks', 'العروض'], ['books', 'الكتب'], ['exams', 'الاختبارات'], ['assignments', 'الواجبات'], ['term_archives', 'فصول مؤرشفة']];
  const FORMS = {classes: ['فصل واحد', 'فصلان', 'فصول', 'فصلًا'], students: null, lessons: ['درس واحد', 'درسان', 'دروس', 'درسًا'], decks: ['عرض واحد', 'عرضان', 'عروض', 'عرضًا'],
    books: ['كتاب واحد', 'كتابان', 'كتب', 'كتابًا'], exams: ['اختبار واحد', 'اختباران', 'اختبارات', 'اختبارًا'], assignments: ['واجب واحد', 'واجبان', 'واجبات', 'واجبًا'],
    term_archives: ['فصل مؤرشف', 'فصلان مؤرشفان', 'فصول مؤرشفة', 'فصلًا مؤرشفًا']};
  let S = null, chosen = null, preview = null, busy = false, undoing = false;

  const say = (id, text) => { const n = $(id); n.textContent = text || ''; n.hidden = !text; };
  const factsOf = counts => Object.keys(FORMS).filter(k => (counts || {})[k] > 0).map(k => k === 'students' ? arS(counts[k]) : arCount(counts[k], FORMS[k]));
  const total = counts => Object.values(counts || {}).reduce((a, b) => a + (Number(b) || 0), 0);
  const sizeText = n => n < 1048576 ? Math.max(1, Math.round(n / 1024)) + ' كيلوبايت' : (n / 1048576).toFixed(1) + ' ميجابايت';

  // ------------------------------------------------------------ what she has now, and the safety copy
  async function load() {
    try { S = await api('GET', '/api/backup'); say('bk-err', ''); }
    catch (e) { $('bk-loading').hidden = true; return say('bk-err', e.message); }
    $('bk-now').replaceChildren(...TILES.map(([k, label]) => el('div', {class: 'stat-tile'}, el('b', {text: String(S.current[k] || 0)}), el('span', {text: label}))));
    drawSafety();
  }

  function drawSafety() {
    const s = S && S.safety, card = $('bk-safety'), body = $('bk-safety-body');
    card.hidden = !s;
    if (!s) return;
    const facts = factsOf(s.counts);
    const go = el('button', {class: 'btn ghost small', type: 'button', id: 'bk-undo', text: '↩ الرجوع إلى حسابي كما كان'});
    go.addEventListener('click', () => { undoing = true; drawSafety(); });
    body.replaceChildren(
      el('p', {text: 'قبل آخر استعادة حفظنا لكِ حسابك كما كان في ' + s.created_text + (facts.length ? ': ' + facts.join('، ') : '') + '. إن لم تعجبك نتيجة الاستعادة فارجعي إليه.'}),
      el('p', {class: 'muted', text: 'تُحفظ نسخة أمان واحدة، وتحل محلها الجديدة عند أي استعادة أخرى. وتُحذف مع حسابك إن حذفتِه.'}),
      undoing ? undoBox() : el('div', {class: 'btn-row'}, go));
  }

  function undoBox() {
    const yes = el('button', {class: 'btn bad small', type: 'button', id: 'bk-undo-yes', text: 'نعم، أرجع إلى حسابي القديم'}), no = el('button', {class: 'btn ghost small', type: 'button', id: 'bk-undo-no', text: 'إلغاء'}),
      err = el('p', {class: 'note bad', role: 'alert', hidden: true});
    no.addEventListener('click', () => { undoing = false; drawSafety(); });
    yes.addEventListener('click', async () => {
      if (busy) return;
      busy = true; yes.disabled = true; err.hidden = true;
      try {
        const r = await api('POST', '/api/backup/undo', {confirm: true});
        undoing = false; await load(); showDone(r, true);
      } catch (x) { err.textContent = x.message; err.hidden = false; yes.disabled = false; }
      finally { busy = false; }
    });
    return el('div', {class: 'bk-undo'}, el('p', {text: 'سنستبدل حسابك الحالي بحسابك كما كان قبل الاستعادة. وما في حسابك الآن يُحفظ في نسخة الأمان بدلًا منه، فتستطيعين الرجوع مرة أخرى.'}),
      el('div', {class: 'btn-row'}, yes, no), err);
  }

  // ------------------------------------------------------------ downloading
  async function download() {
    if (busy) return;
    const btn = $('bk-download');
    busy = true; btn.disabled = true; say('bk-err', ''); say('bk-dl-done', '');
    try {
      const res = await fetch('/api/backup/download', {credentials: 'same-origin'});
      if (!res.ok) {
        let j = {};
        try { j = await res.json(); } catch (e) {}
        throw new Error(j.error || 'تعذّر تجهيز النسخة، جرّبي مرة أخرى');
      }
      const blob = await res.blob(), name = (/filename="([^"]+)"/.exec(res.headers.get('Content-Disposition') || '') || [])[1] || 'lessonplay-backup.zip';
      const url = URL.createObjectURL(blob), a = el('a', {href: url, download: name});
      document.body.append(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 15000);
      const note = $('bk-dl-done');          // (the name is written in Latin letters: it is set apart so that it neither breaks in the middle nor pulls the sentence around it)
      note.replaceChildren('✅ نزّلنا ', el('bdi', {class: 'bk-fname', dir: 'ltr', text: name}), ' (' + sizeText(blob.size) + '). احفظيه في مكان آمن، وانقليه إلى بريدك أو جوالك إن شئتِ.');
      note.hidden = false;
    } catch (e) { say('bk-err', e.message); }
    finally { busy = false; btn.disabled = false; }
  }

  // ------------------------------------------------------------ looking inside a copy
  function resetChoice(keepName) {
    chosen = null; preview = null;
    $('bk-preview').replaceChildren(); $('bk-preview').hidden = true;
    say('bk-file-err', '');
    if (!keepName) { $('bk-file').value = ''; $('bk-file-name').textContent = 'اختاري ملف النسخة الاحتياطية من جهازك'; }
  }

  async function choose() {
    const f = $('bk-file').files[0];
    resetChoice(true); $('bk-done').hidden = true;
    if (!f) return resetChoice();
    $('bk-file-name').textContent = f.name;
    if (f.size > MAX_MB * 1048576) { say('bk-file-err', 'هذا الملف أكبر من ' + MAX_MB + ' ميجابايت، فليس نسخة نزّلتِها من هنا.'); return; }
    if (busy) return;
    busy = true; $('bk-checking').hidden = false;
    try { preview = await apiUpload('/api/backup/preview', f); chosen = f; if (S) { S.safety = preview.safety; S.current = preview.current; } drawPreview(); }
    catch (e) { say('bk-file-err', e.message); }
    finally { busy = false; $('bk-checking').hidden = true; }
  }

  function drawPreview() {
    const f = preview.file, now = preview.current, box = $('bk-preview');
    const body = ROWS.filter(([k]) => (now[k] || 0) || (f.counts[k] || 0)).map(([k, label]) => {
      const a = now[k] || 0, b = f.counts[k] || 0, cls = b > a ? 'bk-up' : b < a ? 'bk-down' : '';
      return el('tr', {class: cls}, el('th', {scope: 'row', text: label}), el('td', {class: 'n', text: String(a)}),
        el('td', {class: 'n f'}, el('b', {text: String(b)}), cls ? el('small', {text: b > a ? '↑ أكثر' : '↓ أقل'}) : null));
    });
    const sure = el('input', {type: 'checkbox', id: 'bk-sure'}), go = el('button', {class: 'btn bk-go', type: 'button', id: 'bk-go', text: 'استعادة حسابي من هذه النسخة'}),
      cancel = el('button', {class: 'btn ghost', type: 'button', id: 'bk-cancel', text: 'إلغاء'}), err = el('p', {class: 'note bad', id: 'bk-go-err', role: 'alert', hidden: true});
    cancel.addEventListener('click', () => resetChoice());
    go.addEventListener('click', () => restore(sure, go, err));
    const facts = factsOf(f.counts), empty = total(f.counts) === 0, hadSome = total(now) > 0;
    box.replaceChildren(el('div', {class: 'bk-pre'},
      el('h3', {text: 'ما في هذه النسخة'}),
      el('p', {class: 'muted', text: (f.created_text ? 'أُخذت في ' + f.created_text + '. ' : '') + (facts.length ? 'فيها ' + facts.join('، ') + '.' : 'لا شيء فيها.')}),
      el('table', {class: 'bk-compare', id: 'bk-compare'}, el('thead', {}, el('tr', {}, el('th', {scope: 'col', text: ''}), el('th', {scope: 'col', class: 'n', text: 'حسابك الآن'}), el('th', {scope: 'col', class: 'n', text: 'النسخة'}))),
        el('tbody', {}, body)),
      empty && hadSome ? el('p', {class: 'note warn', text: 'هذه النسخة فارغة: إن استعدتِها فسيُفرَّغ حسابك مما فيه الآن. ولن تفقديه نهائيًا، فنسخة الأمان تحفظه لتعودي إليه.'}) : null,
      f.notes.map(n => el('p', {class: 'note warn', text: n})),
      el('p', {class: 'muted', text: 'الاستعادة تستبدل بيانات حسابك الحالية بمحتوى النسخة، ولا يتأثر بريدك ولا كلمة مرورك ولا اشتراكك. قبل أن نستبدل شيئًا نحفظ حسابك الحالي في نسخة أمان تستطيعين الرجوع إليها'
        + (preview.safety ? '، وتحل محل نسخة الأمان السابقة (' + preview.safety.created_text + ').' : '.')}),
      el('label', {class: 'check bk-sure'}, sure, el('span', {text: 'أفهم أن بيانات حسابي الحالية ستُستبدل ببيانات هذه النسخة'})),
      el('div', {class: 'btn-row'}, go, cancel), err));
    box.hidden = false;
  }

  // ------------------------------------------------------------ putting it back
  async function restore(sure, go, err) {
    err.hidden = true;
    if (!sure.checked) { err.textContent = 'ضعي علامة على «أفهم…» أولًا لتأكيد الاستعادة.'; err.hidden = false; return; }
    if (busy || !chosen) return;
    busy = true; go.disabled = true; go.textContent = 'جارٍ الاستعادة…';
    try {
      const r = await apiUpload('/api/backup/restore', chosen, {confirm: 'yes'});
      resetChoice(); await load(); showDone(r, false);
    } catch (x) { err.textContent = x.message; err.hidden = false; go.disabled = false; go.textContent = 'استعادة حسابي من هذه النسخة'; }
    finally { busy = false; }
  }

  function showDone(r, back) {
    const box = $('bk-done'), facts = factsOf(r.file.counts);
    box.replaceChildren(el('h3', {text: back ? '✅ رجعتِ إلى حسابك كما كان' : '✅ تمت الاستعادة'}),
      el('p', {text: facts.length ? 'في حسابك الآن ' + facts.join('، ') + '.' : 'حسابك الآن فارغ.'}),
      r.file.notes.map(n => el('p', {class: 'note warn', text: n})),
      el('p', {class: 'muted', text: 'حسابك قبل هذه الخطوة محفوظ في «نسخة الأمان» أسفل الصفحة، إن أردتِ الرجوع إليه.'}),
      el('div', {class: 'btn-row'}, el('a', {class: 'btn', href: '/dashboard', text: 'لوحتي'}), el('a', {class: 'btn ghost', href: '/students', text: 'الطلاب'}), el('a', {class: 'btn ghost', href: '/plan', text: 'الخطة'})));
    box.hidden = false; box.focus(); box.scrollIntoView({block: 'start'});
  }

  $('bk-download').addEventListener('click', download);
  $('bk-file').addEventListener('change', choose);
  load();
})();
