// Shared by «النقاط» and «التقارير»: which class, subject and period she is looking at (kept on this device so the two pages agree), the podium of the first three,
// and the little chart of points per day (drawn as SVG, with the same numbers as a table for whoever cannot see the bars).
(function () {
  const KEY = 'lp-follow';
  const PERIODS = [['today', 'اليوم'], ['week', 'هذا الأسبوع'], ['term', 'الفصل الدراسي'], ['all', 'كل الفترات']];
  const MEDALS = ['🥇', '🥈', '🥉'];
  const F = window.LPFollow = {PERIODS, classes: [], students: [], state: {cls: null, sub: null, period: 'term'}};

  // ------------------------------------------------------------ what she is looking at
  const store = {
    get() { try { const s = JSON.parse(localStorage.getItem(KEY) || '{}'); return s && typeof s === 'object' ? s : {}; } catch (e) { return {}; } },
    put(s) { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) {} },
  };
  F.save = () => store.put(F.state);
  F.classOf = id => F.classes.find(c => c.id === id) || null;
  F.studentsOf = cid => F.students.filter(s => s.class_id === cid).sort((a, b) => a.name.localeCompare(b.name, 'ar'));
  F.subjectsOf = cid => (F.classOf(cid) || {subjects: []}).subjects || [];
  F.query = (extra) => {          // what the API asks for: ?class_id=…&subject_id=…&period=…
    const q = new URLSearchParams();
    if (F.state.cls) q.set('class_id', F.state.cls);
    if (F.state.sub) q.set('subject_id', F.state.sub);
    q.set('period', F.state.period);
    for (const [k, v] of Object.entries(extra || {})) if (v != null && v !== '') q.set(k, v);
    return q.toString();
  };
  // today in her country (the day the server counts in), as 2026-11-08
  F.today = () => new Intl.DateTimeFormat('en-CA', {timeZone: 'Asia/Riyadh', year: 'numeric', month: '2-digit', day: '2-digit'}).format(new Date());
  F.dayText = iso => {
    const d = new Date(iso + 'T12:00:00Z');
    return isNaN(d) ? '' : d.toLocaleDateString('ar-SA-u-nu-latn', {day: 'numeric', month: 'long', weekday: 'long', timeZone: 'UTC'});
  };
  F.shortDay = iso => {            // «7 نوفمبر»: for the rows where the long form would wrap (the year is added only for another year than this one)
    const d = new Date(iso + 'T12:00:00Z');
    if (isNaN(d)) return '';
    const other = String(iso).slice(0, 4) !== F.today().slice(0, 4);
    return d.toLocaleDateString('ar-SA-u-nu-latn', other ? {day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC'} : {day: 'numeric', month: 'long', timeZone: 'UTC'});
  };
  F.timeText = secs => new Date(secs * 1000).toLocaleTimeString('ar-SA-u-nu-latn', {hour: 'numeric', minute: '2-digit', timeZone: 'Asia/Riyadh'});
  F.pointsW = n => arP(Math.abs(n));

  // her classes (with their subjects) and students; the saved choice is kept only if it still exists
  F.load = async function () {
    const d = await api('GET', '/api/students');
    F.classes = d.classes || []; F.students = d.students || [];
    const saved = store.get(), s = F.state;
    s.cls = F.classes.some(c => c.id === saved.cls) ? saved.cls : (F.classes[0] ? F.classes[0].id : null);
    s.sub = s.cls && F.subjectsOf(s.cls).some(x => x.id === saved.sub) ? saved.sub : null;
    s.period = PERIODS.some(p => p[0] === saved.period) ? saved.period : 'term';
    return F;
  };

  // the points the stage kept on this device while the connection was down (stage-points.js) are sent from here too, so a board never misses a point she gave.
  // Each carries its key, so one that the stage sends at the same moment is still written once. Returns how many were sent and how many still wait.
  const QKEY = 'lp-points-queue';
  const readQueue = () => { try { const q = JSON.parse(localStorage.getItem(QKEY) || '[]'); return Array.isArray(q) ? q : []; } catch (e) { return []; } };
  F.waiting = () => readQueue().length;
  F.flushPending = async function () {
    let sent = 0;
    for (const p of readQueue()) {
      let done = false;
      try { await api('POST', '/api/points', p); done = true; sent++; }
      catch (e) { if (!e.status || e.status >= 500 || e.status === 429) break; done = true; }          // no connection or a busy server: stays; refused for good: it can never be sent
      if (done) { try { localStorage.setItem(QKEY, JSON.stringify(readQueue().filter(x => x.key !== p.key))); } catch (e) {} }
    }
    return {sent, left: readQueue().length};
  };

  // the three rows of choices: the class, the subject (only if the class has any), the period. on(state) is told each change.
  F.mount = function (ids, on) {
    const hosts = {cls: document.getElementById(ids.classes), sub: document.getElementById(ids.subjects), per: document.getElementById(ids.periods)}, subRow = document.getElementById(ids.subjectRow);
    const chip = (label, sel, fn) => { const b = el('button', {type: 'button', class: 'chip-btn' + (sel ? ' on' : ''), 'aria-pressed': sel ? 'true' : 'false', text: label}); b.addEventListener('click', fn); return b; };
    const set = patch => { Object.assign(F.state, patch); F.save(); draw(); on(F.state); };
    function draw() {
      const s = F.state, subs = F.subjectsOf(s.cls);
      hosts.cls.replaceChildren(...F.classes.map(c => chip(c.name, c.id === s.cls, () => c.id !== s.cls && set({cls: c.id, sub: null}))));
      subRow.hidden = !subs.length;
      hosts.sub.replaceChildren(chip('كل المواد', !s.sub, () => set({sub: null})), ...subs.map(x => chip(x.name, x.id === s.sub, () => set({sub: x.id}))));
      hosts.per.replaceChildren(...PERIODS.map(p => chip(p[1], p[0] === s.period, () => set({period: p[0]}))));
    }
    draw();
    return {redraw: draw, select: patch => set(patch)};
  };

  // ------------------------------------------------------------ the first three places (the same picture as on the stage)
  F.podium = function (top, more, big) {
    const places = [1, 2, 3].map((r, i) => ({i, list: (top || []).filter(x => x.rank === r)})).filter(x => x.list.length);
    if (!places.length) return el('p', {class: 'muted pts-none', text: 'لم تُعطَ نقاط بعد في هذه الفترة.'});
    const col = ({list, i}) => el('div', {class: 'pod p' + (i + 1), role: 'listitem'},
      el('div', {class: 'pod-names'}, list.map(x => el('div', {class: 'pod-who'}, el('b', {text: x.name}), el('span', {class: 'pod-pts', text: arP(x.points)})))),
      el('div', {class: 'pod-step'}, el('span', {class: 'medal', 'aria-hidden': 'true', text: MEDALS[i]}), el('span', {class: 'pod-n', text: 'المركز ' + (i + 1)})));
    const order = [places.find(x => x.i === 1), places.find(x => x.i === 0), places.find(x => x.i === 2)].filter(Boolean);          // the first place in the middle
    const box = el('div', {class: 'podium' + (big ? ' big' : ''), role: 'list', 'aria-label': 'أفضل ثلاثة'}, order.map(col));
    return more ? el('div', {}, box, el('p', {class: 'muted pts-more', text: 'وهناك ' + arS(more) + ' آخرون بالمراكز نفسها لم يتّسع لهم الصف.'})) : box;
  };

  // ------------------------------------------------------------ points per day
  const niceStep = x => { const p = Math.pow(10, Math.floor(Math.log10(x))), f = x / p; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * p; };
  const charts = [];
  F.chart = function (host, days, label) {
    host.replaceChildren(); host._chart = {days, label};
    if (!charts.includes(host)) charts.push(host);
    if (!days || !days.length) { host.append(el('p', {class: 'muted', text: 'لا توجد أيام لعرضها في هذه الفترة.'})); return; }
    const NS = 'http://www.w3.org/2000/svg';
    const sv = (tag, attrs, text) => { const n = document.createElementNS(NS, tag); for (const [k, v] of Object.entries(attrs || {})) n.setAttribute(k, v); if (text != null) n.textContent = text; return n; };
    const W = Math.max(260, Math.round(host.clientWidth || 600)), H = 200, padT = 24, padB = 28, padL = 8, padR = 34;
    const n = days.length, pw = W - padL - padR, ph = H - padT - padB, sw = pw / n, bw = Math.max(6, Math.min(30, sw * .62));
    const peak = Math.max(1, ...days.map(d => d.points)), step = niceStep(peak / 3), top = Math.max(step, Math.ceil(peak / step) * step);
    const y = v => padT + ph - (ph * v) / top, base = padT + ph;
    const svg = sv('svg', {viewBox: `0 0 ${W} ${H}`, width: W, height: H, class: 'chart-svg', role: 'img', 'aria-label': (label || 'النقاط في كل يوم') + ' — الأرقام في الجدول أسفل المخطط'});
    for (let v = 0; v <= top; v += step) { svg.append(sv('line', {x1: padL, x2: W - padR, y1: y(v), y2: y(v), class: v === 0 ? 'ax' : 'gr'})); svg.append(sv('text', {x: W - padR + 6, y: y(v) + 4, class: 'tk'}, String(v))); }
    const every = sw >= 22 ? 1 : sw >= 13 ? 2 : 4;          // how often a day number fits under the bars
    const maxAt = days.reduce((m, d, i) => (d.points > 0 && d.points >= (days[m] ? days[m].points : 0) ? i : m), -1);
    const tip = el('div', {class: 'chart-tip', role: 'status', hidden: true});
    let hideTimer = null;
    const show = (i, xc, yv) => {
      const d = days[i]; tip.textContent = d.text + ' — ' + (d.points ? arP(d.points) : 'بلا نقاط'); tip.hidden = false;
      tip.style.maxWidth = Math.max(120, W - 8) + 'px';          // never wider than the chart: it wraps instead of leaving the card
      const tw = tip.offsetWidth, th = tip.offsetHeight;
      tip.style.left = Math.min(W - tw / 2 - 4, Math.max(tw / 2 + 4, xc)) + 'px'; tip.style.top = Math.max(0, yv - th - 8) + 'px';
      clearTimeout(hideTimer); hideTimer = setTimeout(() => { tip.hidden = true; }, 3500);
    };
    days.forEach((d, i) => {
      const xc = padL + pw - (i + .5) * sw, x0 = xc - bw / 2, v = d.points, g = sv('g', {class: 'slot'});          // the oldest day on the right, as the page reads
      g.append(sv('rect', {x: xc - sw / 2, y: padT - 6, width: sw, height: ph + padB + 6, class: 'hit'}));
      if (v > 0) { const t = y(v), r = Math.min(4, bw / 2, base - t); g.append(sv('path', {d: `M${x0},${base} V${t + r} Q${x0},${t} ${x0 + r},${t} H${x0 + bw - r} Q${x0 + bw},${t} ${x0 + bw},${t + r} V${base} Z`, class: 'bar' + (i === maxAt ? ' top' : '')})); }
      if (i === maxAt) g.append(sv('text', {x: xc, y: y(v) - 6, class: 'val'}, String(v)));
      if ((n - 1 - i) % every === 0) g.append(sv('text', {x: xc, y: H - 9, class: 'tk mid'}, String(Number(d.day.slice(8)))));
      g.addEventListener('pointerenter', () => show(i, xc, y(Math.max(v, 0)))); g.addEventListener('pointerdown', () => show(i, xc, y(Math.max(v, 0))));
      g.addEventListener('pointerleave', e => { if (e.pointerType === 'mouse') tip.hidden = true; });
      svg.append(g);
    });
    const rows = days.slice().reverse().map(d => el('tr', {}, el('td', {text: d.text}), el('td', {class: 'num', text: String(d.points)})));
    host.append(el('div', {class: 'chart-box'}, svg, tip),
      el('p', {class: 'chart-cap muted', text: 'من ' + days[0].text + ' إلى ' + days[n - 1].text}),
      el('details', {class: 'chart-data noprint'}, el('summary', {text: 'عرض الأرقام كجدول'}), el('div', {class: 'tbl-wrap'}, el('table', {class: 'tbl'}, el('thead', {}, el('tr', {}, el('th', {text: 'اليوم'}), el('th', {text: 'النقاط'}))), el('tbody', {}, rows)))));
  };
  let resizeTimer = null, lastW = window.innerWidth;
  window.addEventListener('resize', () => {
    if (window.innerWidth === lastW) return;          // a phone's address bar moving is not a new width
    lastW = window.innerWidth; clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => charts.forEach(h => { if (document.body.contains(h) && h._chart && h.clientWidth) F.chart(h, h._chart.days, h._chart.label); }), 150);
  });
})();
