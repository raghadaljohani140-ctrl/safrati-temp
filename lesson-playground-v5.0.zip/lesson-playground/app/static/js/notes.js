// «شرح الدرس للمعلمة»: the lesson's explanation in parts, for the teacher to read before the class, copy, print or keep in her own WhatsApp.
(function () {
  const root = document.getElementById('notes-app'), box = document.getElementById('n-parts'), done = document.getElementById('n-done');
  let text = '';
  const say = t => { done.textContent = t; clearTimeout(say.t); say.t = setTimeout(() => { done.textContent = ''; }, 3000); };

  api('GET', '/api/lessons/' + root.dataset.id + '/notes').then(d => {
    text = d.message;
    document.getElementById('n-sub').textContent = d.title + (d.subject ? ' · ' + d.subject : '') + (d.grade ? ' · ' + d.grade : '');
    const wa = document.getElementById('n-wa'); wa.href = d.wa; wa.hidden = !d.parts.length;
    box.replaceChildren();
    if (!d.parts.length) { box.append(el('p', {class: 'empty', text: 'لم نجد نصًا كافيًا لتقسيمه إلى أجزاء. افتحي الدرس وأضيفي ما تحتاجينه.'})); return; }
    d.parts.forEach((p, i) => {
      const card = el('section', {class: 'card note-part'}, el('h2', {text: (i + 1) + '. ' + p.title}), el('ul', {class: 'tpoints-plain'}, p.points.map(x => el('li', {text: x}))));
      if (p.terms.length) card.append(el('dl', {class: 'note-terms'}, p.terms.flatMap(t => [el('dt', {text: t.term}), el('dd', {text: t.def})])));
      p.checks.forEach(q => card.append(el('details', {class: 'note-q'}, el('summary', {text: 'سؤال سريع: ' + q.question}), el('p', {text: 'الإجابة: ' + q.answer}))));
      box.append(card);
    });
  }).catch(e => { box.replaceChildren(el('p', {class: 'note bad', text: e.message})); });

  document.getElementById('n-copy').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(text); say('تم النسخ ✓'); }
    catch (e) {
      const t = el('textarea', {class: 'sr-only', 'aria-hidden': 'true'}); t.value = text; document.body.append(t); t.select();
      try { document.execCommand('copy'); say('تم النسخ ✓'); } catch (x) { say('تعذر النسخ، حدّدي النص وانسخيه'); }
      t.remove();
    }
  });
})();
