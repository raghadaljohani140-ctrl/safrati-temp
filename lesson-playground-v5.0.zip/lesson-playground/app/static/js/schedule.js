// «جدول المعلمة»: the grid of days × periods, the editor of one cell, and reading a timetable she already has (shown cell by cell before anything is saved).
(function () {
  const $ = id => document.getElementById(id);
  const say = (id, text) => { const n = $(id); n.textContent = text || ''; n.hidden = !text; };
  const MAXP = 12, NEW = 'new';
  let D = null, S = null, sel = null, last = {class_id: null, subject_id: null};
  const key = (d, p) => d + '-' + p;
  const dayName = d => (D.day_names || [])[d] || '';
  const cls = id => D.classes.find(c => c.id === id);
  const subj = id => D.subjects.find(s => s.id === id);
  const slotsWord = n => arCount(n, ['حصة واحدة', 'حصتان', 'حصص', 'حصة']);

  function fromData(d) {
    D = d;
    S = {days: d.days.slice(), periods: d.periods, cells: {}, times: {}};
    d.slots.forEach(s => { S.cells[key(s.day, s.period)] = {class_id: s.class_id, subject_id: s.subject_id}; });
    Object.entries(d.times || {}).forEach(([p, t]) => { S.times[p] = {starts: t.starts || '', ends: t.ends || ''}; });
  }

  // ---------------------------------------------------------------- the grid
  function cellBtn(d, p) {
    const c = S.cells[key(d, p)], on = sel && sel.day === d && sel.period === p;
    const klass = c && cls(c.class_id), sub = c && subj(c.subject_id);
    const label = dayName(d) + '، الحصة ' + p + (c ? '، ' + (klass ? klass.name : '') + '، ' + (sub ? sub.name : '') : '، فارغة');
    const b = el('button', {type: 'button', class: 'sch-cell' + (c ? ' filled sj-' + ((c.subject_id || 0) % 8) : '') + (on ? ' sel' : ''), 'aria-label': label + '. اضغطي للتعديل'},
      c ? [el('b', {text: klass ? klass.name : '؟'}), el('small', {text: sub ? sub.name : ''})] : el('span', {class: 'plus', 'aria-hidden': 'true', text: '+'}));
    b.addEventListener('click', () => openEditor(d, p));
    return b;
  }
  function drawGrid() {
    const t = $('sch-grid'); t.replaceChildren();
    t.append(el('thead', {}, el('tr', {}, el('th', {class: 'corner', scope: 'col', text: 'الحصة'}), ...S.days.map(d => el('th', {scope: 'col', text: dayName(d)})))));
    const body = el('tbody');
    for (let p = 1; p <= S.periods; p++) {
      const tm = S.times[p];
      const head = el('th', {scope: 'row'}, el('b', {text: String(p)}), tm && (tm.starts || tm.ends) ? el('small', {class: 'tm-stack', dir: 'ltr'}, el('span', {text: tm.starts || '…'}), el('span', {text: tm.ends || '…'})) : null);
      body.append(el('tr', {}, head, ...S.days.map(d => el('td', {}, cellBtn(d, p)))));
    }
    t.append(body);
    t.style.minWidth = (S.days.length * 50 + 46) + 'px';          // narrower than this the grid scrolls sideways instead of squeezing the cells
  }
  function drawTools() {
    const box = $('sch-days'); box.replaceChildren();
    for (let d = 0; d < 7; d++) {
      const on = S.days.includes(d);
      const b = el('button', {type: 'button', class: 'chip-btn' + (on ? ' on' : ''), 'aria-pressed': on ? 'true' : 'false', text: dayName(d)});
      b.addEventListener('click', () => toggleDay(d)); box.append(b);
    }
    $('sch-periods').replaceChildren(stepper(S.periods, 1, MAXP, setPeriods, 'عدد الحصص في اليوم'));
  }
  function toggleDay(d) {
    if (S.days.includes(d)) {
      if (S.days.length === 1) return;
      const mine = Object.keys(S.cells).filter(k => Number(k.split('-')[0]) === d);
      if (mine.length && !confirm('سيُحذف من الجدول ما في يوم ' + dayName(d) + ' (' + slotsWord(mine.length) + '). متابعة؟')) return;
      mine.forEach(k => delete S.cells[k]);
      S.days = S.days.filter(x => x !== d);
    } else S.days = [...S.days, d].sort((a, b) => a - b);
    closeEditor(); drawTools(); drawGrid();
  }
  function setPeriods(n) {
    const beyond = Object.keys(S.cells).filter(k => Number(k.split('-')[1]) > n);
    if (beyond.length && !confirm('سيُحذف من الجدول ما بعد الحصة ' + n + ' (' + slotsWord(beyond.length) + '). متابعة؟')) { drawTools(); return; }
    beyond.forEach(k => delete S.cells[k]);
    S.periods = n; closeEditor(); drawTimes(); drawGrid();
  }
  function drawTimes() {
    const box = $('times-list'); box.replaceChildren();
    for (let p = 1; p <= S.periods; p++) {
      const t = S.times[p] || (S.times[p] = {starts: '', ends: ''});
      const a = el('input', {type: 'time', value: t.starts, 'aria-label': 'بداية الحصة ' + p}), b = el('input', {type: 'time', value: t.ends, 'aria-label': 'نهاية الحصة ' + p});
      a.addEventListener('change', () => { t.starts = a.value; drawGrid(); });
      b.addEventListener('change', () => { t.ends = b.value; drawGrid(); });
      box.append(el('div', {class: 'time-row'}, el('b', {text: 'الحصة ' + p}), el('label', {}, 'من', a), el('label', {}, 'إلى', b)));
    }
  }

  // ---------------------------------------------------------------- the editor of one cell
  function fill(select, list, value) {
    select.replaceChildren(...list.map(x => el('option', Object.assign({value: String(x.id), text: x.name}, x.id === value ? {selected: true} : {}))));
  }
  function openEditor(d, p) {
    sel = {day: d, period: p};
    const c = S.cells[key(d, p)], none = !D.classes.length || !D.subjects.length;
    $('ed-h').textContent = dayName(d) + ' · الحصة ' + p;
    fill($('ed-class'), D.classes, c ? c.class_id : last.class_id);
    fill($('ed-subject'), D.subjects, c ? c.subject_id : last.subject_id);
    $('ed-none').hidden = !none; $('ed-ok').disabled = none; $('ed-clear').hidden = !c;
    $('ed').hidden = false; drawGrid();
    $('ed').scrollIntoView({block: 'nearest', behavior: 'smooth'}); $('ed-class').focus({preventScroll: true});
  }
  function closeEditor() { sel = null; $('ed').hidden = true; drawGrid(); }
  $('ed-ok').addEventListener('click', () => {
    const cid = Number($('ed-class').value), sid = Number($('ed-subject').value);
    if (!cid || !sid) return;
    S.cells[key(sel.day, sel.period)] = {class_id: cid, subject_id: sid}; last = {class_id: cid, subject_id: sid};
    markDirty(); closeEditor();
  });
  $('ed-clear').addEventListener('click', () => { delete S.cells[key(sel.day, sel.period)]; markDirty(); closeEditor(); });
  $('ed-close').addEventListener('click', closeEditor);
  const markDirty = () => { $('sch-saved').textContent = 'لم تُحفظ التعديلات بعد'; };

  // ---------------------------------------------------------------- saving
  $('sch-save').addEventListener('click', async () => {
    say('sch-err', '');
    const slots = Object.entries(S.cells).map(([k, c]) => { const [d, p] = k.split('-').map(Number); return {day: d, period: p, class_id: c.class_id, subject_id: c.subject_id}; });
    const times = {}; Object.entries(S.times).forEach(([p, t]) => { if (t.starts || t.ends) times[p] = t; });
    const b = $('sch-save'); b.disabled = true;
    try { const d = await api('PUT', '/api/schedule', {days: S.days, periods: S.periods, slots, times}); fromData(d); redraw(); $('sch-saved').textContent = 'تم حفظ الجدول ✓ (' + slotsWord(d.slots.length) + ')'; }
    catch (x) { say('sch-err', x.message); }
    finally { b.disabled = false; }
  });
  function redraw() { closeEditor(); drawTools(); drawTimes(); drawGrid(); }

  // ---------------------------------------------------------------- reading a file she already has
  $('imp-form').addEventListener('submit', async e => {
    e.preventDefault(); say('imp-err', ''); $('imp-preview').hidden = true;
    const f = $('imp-file').files[0]; if (!f) return;
    const btn = $('imp-go'); btn.disabled = true; btn.textContent = 'جارٍ قراءة الجدول…';
    try { preview(await apiUpload('/api/schedule/import', f)); }
    catch (x) { say('imp-err', x.message); }
    finally { btn.disabled = false; btn.textContent = 'قراءة الجدول'; }
  });
  function pick(list, value, onChange, newText) {
    const sel = el('select', {}, ...list.map(x => el('option', Object.assign({value: String(x.id), text: x.name}, x.id === value ? {selected: true} : {}))),
      el('option', Object.assign({value: NEW, text: newText}, value ? {} : {selected: true})));
    sel.addEventListener('change', () => onChange(sel.value === NEW ? null : Number(sel.value))); return sel;
  }
  function preview(d) {
    const box = $('imp-preview');
    const rows = d.cells.map(c => ({day: c.day, period: c.period, cid: c.class_id, cname: c.class_name || '', sid: c.subject_id, sname: c.subject_name || '', raw: c.raw || '', on: true}));
    const newCount = () => rows.filter(r => r.on && (!r.cid || !r.sid)).length;
    const info = el('p', {class: 'muted'}), err = el('p', {class: 'note bad', role: 'alert', hidden: true});
    const list = el('div', {class: 'imp-cells'});
    const save = el('button', {class: 'btn sun', type: 'button'});
    const count = () => rows.filter(r => r.on).length;
    const refresh = () => {
      info.textContent = 'وجدنا ' + slotsWord(count()) + (newCount() ? '، منها ' + newCount() + ' فيها فصل أو مادة جديدة سننشئها عند الحفظ (راجعي أسماءها).' : '، وكلها مطابقة لفصولك ومواداتك.');
      save.textContent = 'حفظ هذا الجدول (' + count() + ')'; save.disabled = !count();
      list.querySelectorAll('.imp-cell').forEach((n, i) => { n.classList.toggle('off', !rows[i].on); n.classList.toggle('new', rows[i].on && (!rows[i].cid || !rows[i].sid)); });
    };
    rows.forEach(r => {
      const cs = pick(d.classes, r.cid, v => { r.cid = v; cname.hidden = v !== null; refresh(); }, 'فصل جديد…');
      const cname = el('input', {value: r.cname, maxlength: 60, placeholder: 'اسم الفصل الجديد', 'aria-label': 'اسم الفصل الجديد', hidden: !!r.cid}); cname.addEventListener('input', () => { r.cname = cname.value; });
      const ss = pick(d.subjects, r.sid, v => { r.sid = v; sname.hidden = v !== null; refresh(); }, 'مادة جديدة…');
      const sname = el('input', {value: r.sname, maxlength: 40, placeholder: 'اسم المادة الجديدة', 'aria-label': 'اسم المادة الجديدة', hidden: !!r.sid}); sname.addEventListener('input', () => { r.sname = sname.value; });
      const off = el('button', {class: 'ib bad', type: 'button', text: '✕', 'aria-label': 'تجاهل هذه الحصة'}); off.addEventListener('click', () => { r.on = !r.on; off.textContent = r.on ? '✕' : '↺'; refresh(); });
      list.append(el('div', {class: 'imp-cell'}, el('div', {class: 'imp-when'}, el('b', {text: dayName(r.day) + ' · الحصة ' + r.period}), r.raw ? el('small', {class: 'muted', text: 'في الملف: ' + r.raw}) : null),
        el('div', {class: 'imp-pick'}, cs, cname), el('div', {class: 'imp-pick'}, ss, sname), off));
    });
    save.addEventListener('click', async () => {
      err.hidden = true;
      const used = rows.filter(r => r.on);
      const bad = used.find(r => (!r.cid && r.cname.trim().length < 2) || (!r.sid && r.sname.trim().length < 2));
      if (bad) { err.textContent = 'اكتبي اسم الفصل واسم المادة في كل حصة جديدة (' + dayName(bad.day) + ' · الحصة ' + bad.period + ')، أو تجاهلي الحصة.'; err.hidden = false; return; }
      if (Object.keys(S.cells).length && !confirm('سيحل هذا الجدول محل جدولك الحالي. متابعة؟')) return;
      save.disabled = true;
      try {
        const cells = used.map(r => ({day: r.day, period: r.period, class_id: r.cid, class_name: r.cname, subject_id: r.sid, subject_name: r.sname}));
        const out = await api('POST', '/api/schedule/import/confirm', {cells, times: d.times, periods: d.periods, days: [...new Set(used.map(r => r.day))]});
        fromData(out); redraw(); box.hidden = true; $('sch-saved').textContent = 'تم حفظ الجدول ✓ (' + slotsWord(out.slots.length) + ')';
        $('grid-card').scrollIntoView({behavior: 'smooth', block: 'start'});
      } catch (x) { err.textContent = x.message; err.hidden = false; save.disabled = false; }
    });
    const cancel = el('button', {class: 'btn ghost', type: 'button', text: 'إلغاء'}); cancel.addEventListener('click', () => { box.hidden = true; });
    box.replaceChildren(el('h3', {text: 'راجعي ما قرأناه'}), info, list, err, el('div', {class: 'btn-row'}, save, cancel));
    box.hidden = false; refresh(); box.scrollIntoView({behavior: 'smooth', block: 'start'});
  }

  api('GET', '/api/schedule').then(d => { fromData(d); redraw(); }).catch(e => say('sch-err', e.message));
})();
