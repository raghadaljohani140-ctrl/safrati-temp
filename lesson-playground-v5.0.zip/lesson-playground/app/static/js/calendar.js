// «التقويم الدراسي»: the first and last day of the term and the days nobody teaches.
(function () {
  const $ = id => document.getElementById(id);
  let D = null;
  const days = n => arCount(n, ['يوم واحد', 'يومان', 'أيام', 'يومًا']);
  const weeks = n => arCount(n, ['أسبوع واحد', 'أسبوعان', 'أسابيع', 'أسبوعًا']);
  const say = (id, text) => { const n = $(id); n.textContent = text || ''; n.hidden = !text; };

  function drawTerm() {
    const t = D.term;
    if (t) { $('t-name').value = t.name; $('t-starts').value = t.starts; $('t-ends').value = t.ends; }
    sum();
  }
  function sum() {
    const t = D.term;
    $('t-end').hidden = !t;
    $('t-sum').textContent = t ? 'من ' + t.starts_text + ' إلى ' + t.ends_text + ' · ' + weeks(t.weeks) : 'لم يُحدَّد الفصل بعد. اكتبي أول يوم دراسة وآخر يوم ثم احفظي.';
  }
  function drawHolidays() {
    const t = D.term;
    $('hol-card').hidden = !t;
    if (!t) return;
    ['h-from', 'h-to'].forEach(id => { $(id).min = t.starts; $(id).max = t.ends; });
    const box = $('h-list'); box.replaceChildren();
    $('h-none').hidden = !!D.ranges.length;
    D.ranges.forEach(r => {
      const range = r.days > 1 ? 'من ' + r.from_text + ' إلى ' + r.to_text : r.from_text;
      const del = el('button', {class: 'btn ghost small del', type: 'button', text: 'حذف', 'aria-label': 'حذف ' + r.label});
      del.addEventListener('click', async () => {
        if (!confirm('حذف «' + r.label + '» (' + days(r.days) + ')؟ ستُحسب هذه الأيام أيام دراسة في الخطة.')) return;
        try { D = await api('DELETE', '/api/calendar/holidays', {ids: r.ids}); drawHolidays(); } catch (e) { say('h-err', e.message); }
      });
      box.append(el('li', {class: 'row'}, el('div', {class: 'row-main'}, el('b', {text: r.label}), el('small', {text: range + ' · ' + days(r.days)})), del));
    });
  }

  $('term-form').addEventListener('submit', async e => {
    e.preventDefault(); say('t-err', '');
    const b = $('t-save'); b.disabled = true;
    try {
      D = await api('PUT', '/api/calendar/term', {name: $('t-name').value, starts: $('t-starts').value, ends: $('t-ends').value});
      drawTerm(); drawHolidays();
      b.textContent = 'تم الحفظ ✓'; setTimeout(() => { b.textContent = 'حفظ الفصل'; }, 2000);
    } catch (x) { say('t-err', x.message); }
    finally { b.disabled = false; }
  });
  $('hol-form').addEventListener('submit', async e => {
    e.preventDefault(); say('h-err', '');
    try {
      D = await api('POST', '/api/calendar/holidays', {label: $('h-label').value, from: $('h-from').value, to: $('h-to').value || $('h-from').value});
      $('h-from').value = $('h-to').value = ''; drawHolidays();
    } catch (x) { say('h-err', x.message); }
  });
  api('GET', '/api/calendar').then(d => { D = d; drawTerm(); drawHolidays(); }).catch(e => say('t-err', e.message));
})();
