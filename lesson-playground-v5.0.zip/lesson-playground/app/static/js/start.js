// «بدء الحصة»: the class, the subject, the lesson, and how the stage should look; then the stage opens with full screen ready.
(function () {
  let D = null, cls = null, subj = null, want = null;
  const KEY = 'lp-start';
  const mem = () => { try { return JSON.parse(localStorage.getItem(KEY) || '{}'); } catch (e) { return {}; } };
  const keep = patch => { try { localStorage.setItem(KEY, JSON.stringify(Object.assign(mem(), patch))); } catch (e) {} };
  const $ = id => document.getElementById(id);
  const norm = s => (s || '').replace(/[ً-ٰٟـ]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/\s+/g, ' ').trim();

  function chip(text, on, fn, extra) {
    const b = el('button', {type: 'button', class: 'chip-btn' + (on ? ' on' : ''), 'aria-pressed': on ? 'true' : 'false'}, text, extra ? el('small', {text: extra}) : null);
    b.addEventListener('click', fn); return b;
  }
  function drawClasses() {
    const box = $('s-classes'); box.replaceChildren();
    $('s-noclass').hidden = !!D.classes.length;
    D.classes.forEach(c => box.append(chip(c.name, cls === c.id, () => { cls = c.id; subj = null; keep({cls}); paint(); }, arS(c.count))));
  }
  function drawSubjects() {
    const list = cls ? (D.classes.find(c => c.id === cls) || {subjects: []}).subjects : D.subjects;
    $('s-subject-card').hidden = !list.length;
    const box = $('s-subjects'); box.replaceChildren();
    if (!list.some(x => x.id === subj)) subj = null;
    box.append(chip('كل المواد', subj === null, () => { subj = null; paint(); }));
    list.forEach(s => box.append(chip(s.name, subj === s.id, () => { subj = s.id; paint(); })));
  }
  function size() { return (document.querySelector('input[name=size]:checked') || {}).value || 'lg'; }
  function go(l) {
    const q = new URLSearchParams(); if (cls) { q.set('class', cls); if (subj) q.set('subject', subj); }          // the subject goes with the class: the points she gives are kept in it
    q.set('size', size()); q.set('inline', $('o-inline').checked ? '1' : '0');
    location.href = '/lessons/' + l.id + '/today?' + q;
  }
  function drawLessons() {
    const box = $('s-lessons'); box.replaceChildren();
    const subjName = subj ? norm((D.subjects.find(x => x.id === subj) || {}).name) : '';
    let list = D.lessons.filter(l => l.id === want || !subjName || !norm(l.subject) || norm(l.subject).includes(subjName) || subjName.includes(norm(l.subject)));
    list = list.filter(l => l.id === want).concat(list.filter(l => l.id !== want));          // the lesson her plan chose comes first
    $('s-nolesson').hidden = !!list.length;
    const need = D.classes.length > 0 && !cls; $('s-need-class').hidden = !need;
    list.forEach(l => {
      const start = el('button', {class: 'btn sun', type: 'button', text: 'ابدئي ▶', disabled: need}); start.addEventListener('click', () => go(l));
      box.append(el('li', {class: 'row' + (l.id === want ? ' row-want' : '')}, el('div', {class: 'row-main'}, el('b', {text: l.title}), el('small', {text: [l.subject, arQ(l.questions)].filter(Boolean).join(' · ')})),
        el('a', {class: 'btn ghost small', href: '/lessons/' + l.id + '/notes', text: 'شرح للمعلمة'}), start));
    });
  }
  function paint() { drawClasses(); drawSubjects(); drawLessons(); }

  const m = mem();
  const sz = document.querySelector('input[name=size][value="' + (m.size || 'lg') + '"]'); if (sz) sz.checked = true;
  $('o-inline').checked = m.inline !== false;
  document.querySelectorAll('input[name=size]').forEach(r => r.addEventListener('change', () => keep({size: size()})));
  $('o-inline').addEventListener('change', () => keep({inline: $('o-inline').checked}));

  api('GET', '/api/start').then(d => {
    D = d;
    cls = (d.classes.some(c => c.id === m.cls) ? m.cls : null) || (d.classes.length === 1 ? d.classes[0].id : null);
    // opened from her plan or the home screen: the class, the subject and the lesson come with the link
    const q = new URLSearchParams(location.search), qc = Number(q.get('class')), qs = Number(q.get('subject')), ql = Number(q.get('lesson'));
    if (qc && d.classes.some(c => c.id === qc)) { cls = qc; subj = qs || null; }
    if (ql && d.lessons.some(l => l.id === ql)) want = ql;
    // or the period that is on now in her timetable
    const sg = d.suggest;
    if (sg && !want && d.lessons.some(l => l.id === sg.lesson_id)) {
      $('s-suggest-text').replaceChildren(el('b', {text: sg.class_name + ' · ' + sg.subject_name}), el('br'), 'الحصة ' + sg.period, sg.time ? ' · ' : '', sg.time ? el('bdi', {class: 'tm', text: sg.time}) : '', el('br'), '📖 ' + sg.title);
      $('s-suggest-go').addEventListener('click', () => { cls = sg.class_id; subj = sg.subject_id || null; go(d.lessons.find(l => l.id === sg.lesson_id)); });
      $('s-suggest').hidden = false;
    }
    paint();
  }).catch(e => { $('s-nolesson').hidden = false; $('s-nolesson').textContent = e.message; });
})();
