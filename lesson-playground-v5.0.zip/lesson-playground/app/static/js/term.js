// «نهاية الفصل»: how the term went (every class, student by student), closing it and starting the next one, and the terms already closed. Closing is confirmed here, in the page, and
// the last closing can be taken back from the list below.
(function () {
  const T = window.TM, F = window.LPFollow, $ = id => document.getElementById(id);
  let D = null, busy = false, undoing = null;
  const dayAfter = iso => { const d = new Date(iso + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + 1); return d.toISOString().slice(0, 10); };
  const badge = (cls, text) => el('span', {class: 'badge ' + cls, text});

  async function load(keepDone) {
    try { D = await api('GET', '/api/term'); T.say('tm-err', ''); }
    catch (e) { $('tm-loading').hidden = true; return T.say('tm-err', e.message); }
    $('tm-loading').hidden = true;
    if (!keepDone) $('tm-done').hidden = true;
    drawTerm(); drawSummary(); drawClose(); drawArchives();
  }

  // ------------------------------------------------------------ the term she is in
  function stateLine() {
    if (D.state === 'before') return [badge('st-wait', 'لم يبدأ بعد'), ' يبدأ بعد ' + T.daysW(D.days)];
    if (D.state === 'ended') return [badge('st-warn', 'انتهى'), D.days === 1 ? ' انتهى أمس' : ' انتهى قبل ' + T.daysW(D.days)];
    return [badge('st-ok', 'جارٍ'), D.days === 0 ? ' اليوم آخر يوم دراسة' : ' بقي على نهايته ' + T.daysW(D.days)];
  }
  function drawTerm() {
    const box = $('tm-term'), t = D.term;
    box.hidden = false;
    if (!t) {
      box.replaceChildren(el('h2', {text: 'لم يُحدَّد الفصل الدراسي بعد'}), el('p', {class: 'muted', text: D.why}), el('p', {}, el('a', {class: 'btn', href: '/calendar', text: 'فتح التقويم الدراسي'})));
      return;
    }
    box.replaceChildren(el('div', {class: 'sum-head'}, el('h2', {text: t.name}), el('span', {class: 'tm-state'}, stateLine())),
      el('p', {class: 'muted', text: 'من ' + t.starts_text + ' إلى ' + t.ends_text + ' · ' + T.weeksW(t.weeks)}),
      el('p', {class: 'noprint btn-row'}, D.can_close ? el('a', {class: 'btn small', href: '#tm-close-card', text: 'إنهاء الفصل وبدء فصل جديد ↓'}) : null, el('a', {class: 'btn ghost small', href: '/calendar', text: 'تعديل التاريخين والإجازات من التقويم'})));
  }

  // ------------------------------------------------------------ the summary
  function drawSummary() {
    const card = $('tm-summary-card');
    card.hidden = !D.summary;
    if (!D.summary) return;
    const t = D.term, s = D.summary;
    $('tm-sum-title').textContent = 'حصيلة ' + t.name;
    $('tm-sum-range').textContent = D.early ? 'من ' + t.starts_text + ' حتى اليوم ' + D.closes_text : T.rangeText(t);
    $('tm-print-line').textContent = 'ملعب الدرس · حصيلة ' + t.name + ' · ' + (D.early ? 'من ' + t.starts_text + ' حتى ' + D.closes_text : T.rangeText(t));
    T.mount($('tm-summary'), s, {csv: '/api/term/csv'});
    $('tm-csv').href = '/api/term/csv';
  }

  // ------------------------------------------------------------ closing it
  function drawClose() {
    const card = $('tm-close-card'), body = $('tm-close-body');
    card.hidden = !D.term;
    if (!D.term) return;
    if (!D.can_close) {
      body.replaceChildren(el('p', {class: 'muted', text: D.why}), D.state === 'before' ? el('a', {class: 'btn ghost small', href: '/calendar', text: 'تعديل التاريخين من التقويم'}) : null);
      return;
    }
    const t = D.term;
    const name = el('input', {id: 'tm-name', maxlength: '60', autocomplete: 'off', value: D.suggest.name}),
      starts = el('input', {id: 'tm-starts', type: 'date', required: true, min: dayAfter(D.closes_on)}),
      ends = el('input', {id: 'tm-ends', type: 'date', required: true}),
      carry = el('input', {id: 'tm-carry', type: 'checkbox', checked: true}),
      sure = el('input', {id: 'tm-sure', type: 'checkbox'}),
      go = el('button', {class: 'btn', type: 'submit', id: 'tm-go', text: 'إنهاء «' + t.name + '» وبدء الفصل الجديد'}),
      err = el('p', {class: 'note bad', id: 'tm-close-err', role: 'alert', hidden: true});
    starts.addEventListener('change', () => { if (starts.value) ends.min = dayAfter(starts.value); });
    const form = el('form', {class: 'tm-form', id: 'tm-close-form', novalidate: true},
      el('p', {class: 'muted', text: D.early
        ? 'لم ينتهِ «' + t.name + '» بعد (آخر يوم دراسة فيه ' + t.ends_text + '). إن أنهيتِه الآن فسيُغلق اليوم، ولن يُحسب فيه إلا ما سُجّل حتى هذه اللحظة.'
        : 'انتهى «' + t.name + '» (آخر يوم دراسة فيه ' + t.ends_text + ').'}),
      el('div', {class: 'grid-form'},
        el('label', {}, 'اسم الفصل الجديد', name),
        el('label', {}, 'أول يوم دراسة فيه', starts),
        el('label', {}, 'آخر يوم دراسة فيه', ends)),
      el('label', {class: 'check'}, carry, el('span', {text: 'استبعاد الدروس التي أنجزتِها في هذا الفصل من خطة الفصل الجديد، فتبدأ الخطة مما بقي (تبقى قابلة للإرجاع واحدًا واحدًا)'})),
      el('div', {class: 'tm-will'}, el('b', {text: 'ماذا سيحدث عند الإنهاء؟'}), el('ul', {},
        el('li', {text: 'يُغلق «' + t.name + '» ويكون آخر يوم فيه ' + D.closes_text + '، ويُحفظ ملخصه كما تقرئينه أعلاه في الأرشيف.'}),
        el('li', {text: 'يبدأ الفصل الجديد بلا إجازات، فتضيفينها من التقويم، وتُوزَّع الدروس على أيامه.'}),
        el('li', {text: 'تبقى فصولك وطلابك وكتبك وجدولك كما هي.'}),
        el('li', {text: 'لا يُحذف شيء: نقاطك وواجباتك واختباراتك وغيابك تبقى في حسابك مرتبطة بأيامها، وتُحتسب في «كل الفترات».'}),
        el('li', {text: 'يمكنك التراجع بعد الإنهاء مباشرة من قائمة الفصول المؤرشفة أسفل الصفحة.'}))),
      el('p', {class: 'muted'}, 'يُستحسن تنزيل ', el('a', {href: '/backup', text: 'نسخة احتياطية من حسابك'}), ' قبل الإنهاء.'),
      el('label', {class: 'check tm-sure'}, sure, el('span', {text: 'أفهم أن «' + t.name + '» سيُغلق وأن فصلًا جديدًا سيبدأ'})),
      go, err);
    form.addEventListener('submit', async e => {
      e.preventDefault();
      T.say('tm-close-err', '');
      if (!starts.value || !ends.value) return T.say('tm-close-err', 'اكتبي أول يوم دراسة في الفصل الجديد وآخر يوم فيه.');
      if (!sure.checked) return T.say('tm-close-err', 'ضعي علامة على «أفهم…» أولًا لتأكيد الإنهاء.');
      if (busy) return;
      busy = true; go.disabled = true;
      try {
        const r = await api('POST', '/api/term/close', {confirm: true, name: name.value, starts: starts.value, ends: ends.value, carry: carry.checked});
        await load(true);
        done(r, t);
      } catch (x) { T.say('tm-close-err', x.message); }
      finally { busy = false; go.disabled = false; }
    });
    body.replaceChildren(form);
  }
  function done(r, old) {
    const box = $('tm-done'), n = r.term;
    box.replaceChildren(el('h2', {text: '✅ تم إنهاء «' + old.name + '»'}),
      el('p', {text: 'بدأ «' + n.name + '» من ' + n.starts_text + ' إلى ' + n.ends_text + '.' + (r.carried ? ' واستُبعد من خطته ' + T.lessonsW(r.carried) + ' كنتِ أنجزتِها.' : '')}),
      el('p', {class: 'muted', text: 'أضيفي إجازات الفصل الجديد من التقويم، وراجعي خطة كل مادة لتتأكد من توزيع الدروس.'}),
      el('div', {class: 'btn-row'}, el('a', {class: 'btn', href: '/term/' + r.archive_id, text: 'فتح ملخص «' + old.name + '» المؤرشف'}), el('a', {class: 'btn ghost', href: '/calendar', text: 'التقويم'}), el('a', {class: 'btn ghost', href: '/plan', text: 'الخطة'})));
    box.hidden = false; box.focus(); box.scrollIntoView({block: 'start'});
  }

  // ------------------------------------------------------------ the terms already closed
  function drawArchives() {
    $('tm-archives-card').hidden = !D.archives.length;
    $('tm-archives').replaceChildren(...D.archives.map(a => {
      const t = a.totals || {}, facts = [];
      if (t.points != null) facts.push(arP(t.points));
      if (t.exams) facts.push(T.examsW(t.exams));
      if (t.homework_percent != null) facts.push('إنجاز الواجبات ' + t.homework_percent + '٪');
      const acts = el('div', {class: 'tm-arch-acts'}, el('a', {class: 'btn small', href: '/term/' + a.id, text: 'فتح الملخص'}), el('a', {class: 'btn ghost small', href: '/api/term/archives/' + a.id + '/csv', text: '⬇ CSV'}));
      if (a.can_reopen) {
        const undo = el('button', {class: 'btn ghost small', type: 'button', text: '↩ تراجع عن الإنهاء'});
        undo.addEventListener('click', () => { undoing = a.id; drawArchives(); });
        acts.append(undo);
      }
      const li = el('li', {class: 'tm-arch'}, el('div', {class: 'tm-arch-main'}, el('b', {text: a.name}), el('small', {class: 'muted', text: a.starts_text + ' ← ' + a.ends_text + ' · أُنهي في ' + a.closed_text}),
        facts.length ? el('small', {class: 'muted', text: facts.join(' · ')}) : null), acts);
      if (undoing === a.id) li.append(undoBox(a));
      return li;
    }));
  }
  function undoBox(a) {
    const yes = el('button', {class: 'btn bad small', type: 'button', text: 'نعم، أتراجع عن الإنهاء'}), no = el('button', {class: 'btn ghost small', type: 'button', text: 'إلغاء'}),
      err = el('p', {class: 'note bad', role: 'alert', hidden: true});
    no.addEventListener('click', () => { undoing = null; drawArchives(); });
    yes.addEventListener('click', async () => {
      yes.disabled = true; err.hidden = true;
      try { await api('POST', '/api/term/archives/' + a.id + '/reopen', {confirm: true}); undoing = null; await load(); }
      catch (x) { err.textContent = x.message; err.hidden = false; yes.disabled = false; }
    });
    return el('div', {class: 'tm-undo'}, el('p', {text: 'سيُحذف الفصل الجديد الذي بدأ بعد «' + a.name + '» بإجازاته وخطته، ويعود «' + a.name + '» مفتوحًا كما كان. لا يتأثر شيء من نقاطك وواجباتك واختباراتك.'}),
      el('div', {class: 'btn-row'}, yes, no), err);
  }

  load();
})();
