// «النقاط»: the board of a class (the first three and everyone after), points given by hand, the log of every point (correct it or take it back), and how many points an answer gives.
(function () {
  const F = window.LPFollow, $ = id => document.getElementById(id);
  const PAGE = 40, timesW = n => arCount(n, ['مرة واحدة', 'مرتين', 'مرات', 'مرة']);
  let board = null, logRows = [], logTotal = 0, logSum = 0, token = 0, logToken = 0, amount = 1, editing = null;
  const say = (id, text) => { const n = $(id); n.textContent = text || ''; n.hidden = !text; };
  const signed = n => (n > 0 ? '+' : '−') + Math.abs(n);
  const minDay = iso => { const d = new Date(iso + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() - 400); return d.toISOString().slice(0, 10); };
  const keyOf = () => 'p:' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

  // ------------------------------------------------------------ start
  async function start() {
    try { await F.load(); } catch (e) { say('pt-load-err', e.message); return; }
    pending(await F.flushPending().catch(() => ({left: F.waiting()})));
    if (!F.classes.length) { $('pt-none').hidden = false; $('pt-pick').hidden = true; return; }
    $('pt-body').hidden = false;
    F.mount({classes: 'pt-classes', subjects: 'pt-subjects', periods: 'pt-periods', subjectRow: 'pt-subject-row'}, () => { editing = null; refresh(); });
    $('pt-amt').replaceChildren(stepper(amount, 1, 10, v => { amount = v; }, 'عدد النقاط'));
    $('pt-lstu').addEventListener('change', () => loadLog(true));
    drawSettings();
    refresh();
    window.addEventListener('online', async () => { pending(await F.flushPending().catch(() => ({left: F.waiting()}))); refresh(); });
  }
  function pending(r) {
    say('pt-pending', r && r.left ? '⏳ ' + arP(r.left) + ' أعطيتِها أثناء العرض ولم تصل إلى حسابك بعد لأن الاتصال غير متاح. حُفظت على هذا الجهاز وتُرسل وحدها عند عودته.' : '');
  }

  // ------------------------------------------------------------ the board
  async function refresh() {
    const my = ++token;
    fillForm();
    try {
      const b = await api('GET', '/api/points/board?' + F.query());
      if (my !== token) return;
      board = b; say('pt-load-err', ''); drawBoard(b); loadLog(true);
    } catch (e) { if (my === token) say('pt-load-err', e.message); }
  }
  function rangeText(b) {
    if (!b.first) return b.period_name + (b.period === 'term' ? ' (كل النقاط)' : '');
    return b.first === b.last ? F.dayText(b.first) : b.period_name + ': ' + F.dayText(b.first) + ' ← ' + F.dayText(b.last);
  }
  function drawBoard(b) {
    $('pt-title').textContent = 'لوحة ' + b.class.name + (b.subject ? ' · ' + b.subject.name : '');
    $('pt-range').textContent = rangeText(b);
    $('pt-term-note').hidden = !(b.period === 'term' && !b.first);
    $('pt-podium').replaceChildren(F.podium(b.top, b.more, false));
    $('pt-no-students').hidden = !!b.rows.length;
    $('pt-sum').hidden = !b.rows.length;
    $('pt-sum').textContent = 'المجموع: ' + arP(b.total) + ' · أُعطيت ' + timesW(b.awards);
    const max = Math.max(1, ...b.rows.map(r => r.points));
    $('pt-rank').replaceChildren(...b.rows.map(r => {
      const give = el('button', {type: 'button', class: 'btn ghost small noprint', text: '＋ نقاط', 'aria-label': 'إعطاء نقاط لـ ' + r.name});
      give.addEventListener('click', () => { $('pt-stu').value = String(r.student_id); $('pt-add').scrollIntoView({behavior: 'smooth', block: 'center'}); $('pt-note').focus({preventScroll: true}); });
      return el('li', {class: 'rank-item' + (r.rank && r.rank <= 3 ? ' r' + r.rank : '') + (r.points <= 0 ? ' zero' : '')},
        el('span', {class: 'rank-n', text: r.rank ? String(r.rank) : '–', title: r.rank ? 'المركز ' + r.rank : 'بلا مركز بعد'}),
        el('div', {class: 'rank-who'}, el('b', {text: r.name}), el('small', {text: r.awards ? 'آخر مشاركة: ' + F.shortDay(r.last_day) : 'لم يشارك في هذه الفترة'})),
        el('div', {class: 'rank-pts'}, el('b', {text: String(r.points)}), el('small', {text: r.points === 1 ? 'نقطة' : 'نقاط'})),
        give,
        el('progress', {max: String(max), value: String(Math.max(0, r.points)), 'aria-hidden': 'true'}));
    }));
  }

  // ------------------------------------------------------------ giving points by hand
  function fillForm() {
    const list = F.studentsOf(F.state.cls), sel = $('pt-stu'), keep = sel.value;
    sel.replaceChildren(...list.map(s => el('option', {value: s.id, text: s.name})));
    if (list.some(s => String(s.id) === keep)) sel.value = keep;
    $('pt-add').hidden = !list.length;
    const subs = F.subjectsOf(F.state.cls), sub = $('pt-sub');
    sub.replaceChildren(el('option', {value: '', text: 'بلا مادة'}), ...subs.map(x => el('option', {value: x.id, text: x.name})));
    sub.value = F.state.sub ? String(F.state.sub) : (subs.length === 1 ? String(subs[0].id) : '');
    const day = $('pt-day'), t = F.today(); day.max = t; day.min = minDay(t); if (!day.value) day.value = t;
    const lf = $('pt-lstu'), lkeep = lf.value;
    lf.replaceChildren(el('option', {value: '', text: 'كل طلاب الفصل'}), ...list.map(s => el('option', {value: s.id, text: s.name})));
    lf.value = list.some(s => String(s.id) === lkeep) ? lkeep : '';
  }
  $('pt-form').addEventListener('submit', async e => {
    e.preventDefault(); say('pt-err', ''); $('pt-ok').hidden = true;
    const sid = Number($('pt-stu').value);
    if (!sid) return say('pt-err', 'اختاري الطالب');
    const go = $('pt-go'); go.disabled = true;
    const body = {student_id: sid, amount, source: 'manual', day: $('pt-day').value, note: $('pt-note').value, key: keyOf()}, sub = Number($('pt-sub').value);
    if (sub) body.subject_id = sub;
    try {
      const r = await api('POST', '/api/points', body), name = $('pt-stu').selectedOptions[0].textContent;
      const undo = el('button', {type: 'button', class: 'btn ghost small', text: '↩ تراجع'});
      undo.addEventListener('click', async () => {
        try { await api('DELETE', '/api/points/' + r.id); say('pt-ok', 'تم التراجع.'); refresh(); } catch (x) { say('pt-err', x.message); }
      });
      $('pt-ok').replaceChildren('أُعطيت ' + arP(amount) + ' لـ ' + name + '. ', undo); $('pt-ok').hidden = false;
      $('pt-note').value = '';
      refresh();
    } catch (x) { say('pt-err', x.message); } finally { go.disabled = false; }
  });

  // ------------------------------------------------------------ the log
  async function loadLog(reset) {
    if (!board) return;
    const my = ++logToken;
    if (reset) { logRows = []; editing = null; }
    const q = F.query({student_id: $('pt-lstu').value, from: board.first, to: board.last, limit: PAGE, offset: logRows.length});
    try {
      const d = await api('GET', '/api/points/log?' + q);
      if (my !== logToken) return;
      logRows = logRows.concat(d.entries); logTotal = d.total; logSum = d.sum; drawLog();
    } catch (e) { if (my === logToken) say('pt-load-err', e.message); }
  }
  $('pt-more').addEventListener('click', () => loadLog(false));
  function drawLog() {
    const box = $('pt-log');
    $('pt-lempty').hidden = !!logRows.length;
    $('pt-lsum').textContent = logTotal ? arP(logSum) + ' · ' + timesW(logTotal) : '';
    $('pt-more').hidden = logRows.length >= logTotal;
    let last = null; const out = [];
    logRows.forEach(e => {
      if (e.day !== last) { last = e.day; out.push(el('li', {class: 'pl-day', text: e.day_text})); }
      out.push(editing === e.id ? editItem(e) : item(e));
    });
    box.replaceChildren(...out);
  }
  function item(e) {
    const meta = [e.subject, e.label, e.source === 'game' && e.ref ? '«' + e.ref + '»' : '', e.note ? 'ملاحظة: ' + e.note : '', F.timeText(e.at) + (e.edited ? ' · عُدّلت' : '')].filter(Boolean).join(' · ');
    const edit = el('button', {type: 'button', class: 'btn ghost small', text: 'تعديل', 'aria-label': 'تعديل نقاط ' + e.student}), del = el('button', {type: 'button', class: 'btn ghost small danger', text: 'حذف', 'aria-label': 'حذف نقاط ' + e.student});
    edit.addEventListener('click', () => { editing = e.id; drawLog(); const f = document.querySelector('.pl.editing select'); if (f) f.focus(); });
    del.addEventListener('click', async () => {
      if (!confirm('حذف هذه النقاط؟\n' + e.student + ' · ' + signed(e.amount) + ' · ' + e.day_text + '\nيمكنك إعطاؤها من جديد يدويًا.')) return;
      try { await api('DELETE', '/api/points/' + e.id); refresh(); } catch (x) { say('pt-load-err', x.message); }
    });
    return el('li', {class: 'pl', 'data-id': e.id},
      el('span', {class: 'pl-amt' + (e.amount < 0 ? ' neg' : ''), text: signed(e.amount), title: arP(Math.abs(e.amount))}),
      el('div', {class: 'pl-main'}, el('b', {text: e.student}), el('small', {text: meta})),
      el('div', {class: 'pl-act noprint'}, edit, del));
  }
  function editItem(e) {
    const stu = el('select', {}, ...F.studentsOf(e.class_id).map(s => el('option', {value: s.id, text: s.name}))); stu.value = String(e.student_id);
    let amt = e.amount;
    const stp = stepper(amt, e.amount < 0 ? -50 : 1, 50, v => { amt = v; }, 'عدد النقاط');
    const day = el('input', {type: 'date', value: e.day, max: F.today(), min: minDay(F.today())});
    const sub = el('select', {}, el('option', {value: '', text: 'بلا مادة'}), ...F.subjectsOf(e.class_id).map(x => el('option', {value: x.id, text: x.name}))); sub.value = e.subject_id ? String(e.subject_id) : '';
    const note = el('input', {value: e.note, maxlength: 80, placeholder: 'السبب (اختياري)'});
    const err = el('p', {class: 'note bad pl-err', role: 'alert', hidden: true});
    const save = el('button', {type: 'button', class: 'btn small', text: 'حفظ التعديل'}), cancel = el('button', {type: 'button', class: 'btn ghost small', text: 'إلغاء'});
    cancel.addEventListener('click', () => { editing = null; drawLog(); });
    save.addEventListener('click', async () => {
      const patch = {};
      if (Number(stu.value) !== e.student_id) patch.student_id = Number(stu.value);
      if (amt !== e.amount) patch.amount = amt;
      if (day.value && day.value !== e.day) patch.day = day.value;
      if ((Number(sub.value) || null) !== (e.subject_id || null)) patch.subject_id = Number(sub.value) || null;
      if (note.value !== e.note) patch.note = note.value;
      if (!Object.keys(patch).length) { editing = null; return drawLog(); }
      save.disabled = true;
      try { await api('PATCH', '/api/points/' + e.id, patch); editing = null; refresh(); }
      catch (x) { err.textContent = x.message; err.hidden = false; save.disabled = false; }
    });
    return el('li', {class: 'pl editing', 'data-id': e.id},
      el('div', {class: 'pl-edit'}, el('label', {}, 'الطالب', stu), el('div', {class: 'fld'}, el('b', {text: 'عدد النقاط'}), stp), el('label', {}, 'اليوم', day), el('label', {}, 'المادة', sub), el('label', {class: 'wide'}, 'السبب', note)),
      err, el('div', {class: 'btn-row'}, save, cancel));
  }

  // ------------------------------------------------------------ how many points an answer gives
  async function drawSettings(s) {
    try { s = s || await api('GET', '/api/points/settings'); } catch (e) { return say('pt-s-err', e.message); }
    [['correct', 'pt-s-correct'], ['try', 'pt-s-try']].forEach(([k, id]) => {
      const [lo, hi] = s.limits[k];
      $(id).replaceChildren(...Array.from({length: hi - lo + 1}, (_, i) => lo + i).map(v => {
        const on = v === s[k], b = el('button', {type: 'button', class: 'chip-btn' + (on ? ' on' : ''), 'aria-pressed': on ? 'true' : 'false', text: v === 0 ? 'لا شيء' : String(v)});
        b.addEventListener('click', async () => {
          try { const r = await api('PUT', '/api/points/settings', {[k]: v}); say('pt-s-err', ''); drawSettings(r); } catch (e) { say('pt-s-err', e.message); }
        });
        return b;
      }));
    });
  }

  start();
})();
