// «حصة اليوم» on the stage: the explanation in short parts, a quick question after a part, questions for the students by name, then the activities.
// Everything comes from /api/lessons/<id>/today (made from the teacher's own file); this file only shows it and keeps the place she reached.
(function () {
  const L = window.LPStage;
  let T = null;

  // inline: the quick question of a part is shown on the part's own slide (a button under the points) instead of a screen of its own
  function stepsOf(data, inline) {
    const out = [];
    data.parts.forEach((p, i) => { out.push({t: 'part', i}); if (!inline) p.checks.forEach((q, j) => out.push({t: 'check', i, j})); });
    if (data.participation.length) out.push({t: 'ask'});
    out.push({t: 'done'});
    return out;
  }

  L.screens.today = async function (c, first) {
    const {S, view, el} = c;
    S.today = S.today || {at: 0, k: 0};
    if (!T) {
      view.replaceChildren(el('p', {class: 'center muted', text: 'جارٍ تجهيز حصة اليوم…'}));
      try { T = await api('GET', '/api/lessons/' + c.deck.lesson_id + '/today'); }
      catch (e) { return view.replaceChildren(el('div', {class: 'qcard center'}, el('h2', {text: 'تعذر تجهيز حصة اليوم'}), el('p', {class: 'qtext', text: e.message}))); }
    }
    show(c, first);
  };

  function show(c, first) {
    const {S, view, el} = c;
    const inline = S.inline !== false;
    const steps = stepsOf(T, inline);
    S.today.at = Math.max(0, Math.min(S.today.at || 0, steps.length - 1));
    const step = steps[S.today.at];
    const go = (n, k) => {
      S.today.at = Math.max(0, Math.min(n, steps.length - 1)); S.today.k = k || 0; S.round.current = null;
      S.screen = {game: 'today', qid: null, revealed: false}; c.save(); show(c, false);
    };
    const firstOf = (t, i) => steps.findIndex(s => s.t === t && (i === undefined || s.i === i));
    const prev = S.today.at > 0 ? el('button', {class: 'btn big ghost', type: 'button', text: '➜ السابق'}) : null;
    if (prev) prev.addEventListener('click', () => go(S.today.at - 1, steps[S.today.at - 1].t === 'ask' ? T.participation.length - 1 : 0));
    const forward = label => { const b = el('button', {class: 'btn big', type: 'button', text: label}); b.addEventListener('click', () => go(S.today.at + 1)); return b; };
    L.nav = {next: () => (step.t === 'done' ? null : go(S.today.at + 1)), prev: () => (S.today.at > 0 ? go(S.today.at - 1) : null)};

    // the way through the lesson: one dot for every part, then the questions, then the activities
    const endOfParts = steps.findIndex(s => s.t === 'ask' || s.t === 'done');
    const dots = el('div', {class: 'tdots', role: 'list', 'aria-label': 'مراحل الحصة'});
    T.parts.forEach((p, i) => {
      const a = firstOf('part', i), b = (i + 1 < T.parts.length ? firstOf('part', i + 1) : endOfParts) - 1;
      const d = el('button', {class: 'tdot' + (S.today.at > b ? ' past' : S.today.at >= a ? ' on' : ''), type: 'button', title: p.title, 'aria-label': 'الجزء ' + (i + 1) + ': ' + p.title, role: 'listitem', text: i + 1});
      d.addEventListener('click', () => go(a)); dots.append(d);
    });
    if (T.participation.length) { const d = el('button', {class: 'tdot wide' + (step.t === 'ask' ? ' on' : step.t === 'done' ? ' past' : ''), type: 'button', role: 'listitem', text: '❓ مشاركة'}); d.addEventListener('click', () => go(firstOf('ask'))); dots.append(d); }
    { const d = el('button', {class: 'tdot wide' + (step.t === 'done' ? ' on' : ''), type: 'button', role: 'listitem', text: '🎮 الأنشطة'}); d.addEventListener('click', () => go(firstOf('done'))); dots.append(d); }

    const body = [];

    if (step.t === 'part') {
      const p = T.parts[step.i];
      const next = !inline && p.checks.length ? 'سؤال سريع ❓' : (step.i + 1 < T.parts.length ? 'الشريحة التالية ➜' : (T.participation.length ? 'أسئلة المشاركة ➜' : 'الأنشطة ➜'));
      body.push(el('div', {class: 'tpart'},
        el('p', {class: 'progress', text: 'الشريحة ' + (step.i + 1) + ' من ' + T.parts.length}),
        el('h2', {class: 'ttitle', text: p.title}),
        el('ul', {class: 'tpoints'}, p.points.map(x => el('li', {text: x}))),
        p.terms.length ? el('div', {class: 'tterms'}, el('b', {text: 'مصطلحات الجزء'}), el('dl', {}, p.terms.flatMap(t => [el('dt', {text: t.term}), el('dd', {text: t.def})]))) : null,
        inline && p.checks.length ? slideQuestion(c, p) : null));
      body.push(el('div', {class: 'ctrl'}, prev, forward(next)));
    } else if (step.t === 'check') {
      const p = T.parts[step.i], q = p.checks[step.j];
      const isLast = steps[S.today.at + 1] && steps[S.today.at + 1].t === 'part';
      body.push(el('p', {class: 'progress', text: 'سؤال سريع بعد الجزء ' + (step.i + 1) + ': ' + p.title}));
      body.push(c.questionCard(q, 'quick', ctrl => ctrl.append(forward(isLast ? 'الجزء التالي ➜' : (T.participation.length ? 'أسئلة المشاركة ➜' : 'الأنشطة ➜')))));
      body.push(el('div', {class: 'ctrl'}, prev));
    } else if (step.t === 'ask') {
      askView(c, body, go, prev, forward);
    } else {
      const grid = el('div', {class: 'menu primary'}, ['pick', 'qa', 'live', 'quiz'].filter(g => c.deck.games.includes(g)).map(g => {
        const info = c.deck.game_info[g];
        const b = el('button', {class: 'tile-btn g-' + g, type: 'button'}, el('span', {class: 'ico', text: info.icon}), info.name, el('small', {text: info.hint}));
        b.addEventListener('click', () => c.start(g)); return b;
      }));
      const again = el('button', {class: 'btn big ghost', type: 'button', text: '↻ أعيدي الحصة من البداية'}); again.addEventListener('click', () => go(0));
      const all = el('button', {class: 'btn big ghost', type: 'button', text: '🏠 كل الأنشطة'}); all.addEventListener('click', c.menu);
      body.push(el('div', {class: 'qcard center'}, el('h2', {text: T.parts.length ? 'أحسنتِ! انتهى الشرح والأسئلة 🎉' : 'لا يوجد شرح مقسّم لهذا الدرس'}),
        el('p', {class: 'qtext', text: T.parts.length ? 'ثبّتي الدرس بنشاط:' : 'لم نجد نصًا كافيًا نقسّمه إلى أجزاء. ابدئي بأحد الأنشطة:'})));
      body.push(grid, el('div', {class: 'ctrl'}, prev, again, all));
    }
    view.replaceChildren(dots, ...body);
    c.drawBoard();
    view.scrollTop = 0;
  }

  // the question that belongs to this slide: a button under the points opens it right there, so the class never leaves the slide
  function slideQuestion(c, p) {
    const box = el('div', {class: 'slide-q'});
    const open = el('button', {class: 'btn big sun', type: 'button', text: '❓ سؤال على هذه الشريحة'});
    open.addEventListener('click', () => { open.hidden = true; box.append(...p.checks.map(q => c.questionCard(q, 'quick', null))); box.scrollIntoView({behavior: 'smooth', block: 'nearest'}); });
    box.append(open);
    return box;
  }

  // questions for the students to answer by name: the next student comes from the same fair round as the wheel
  function askView(c, body, go, prev, forward) {
    const {S, el} = c;
    const A = T.participation, k = Math.max(0, Math.min(S.today.k || 0, A.length - 1)), item = A[k];
    S.today.k = k;
    const last = k + 1 >= A.length;
    const who = el('div', {class: 'whobox'});
    const paintWho = () => {
      const st = c.students.find(x => x.id === S.round.current);
      who.replaceChildren(st ? el('p', {class: 'picked small'}, el('small', {text: 'دور الطالبة'}), st.name) : el('p', {class: 'muted center', text: c.students.length ? 'اختاري من تجيب، أو اتركيه للصف كله' : 'أضيفي أسماء الطالبات لتسجيل مشاركاتهن'}));
    };
    const choose = el('button', {class: 'btn big sun', type: 'button', text: '🎲 اختاري طالبة'});
    choose.hidden = !c.students.length || !c.present().length;
    choose.addEventListener('click', () => { c.pickStudent(); paintWho(); });
    body.push(el('p', {class: 'progress', text: 'سؤال المشاركة ' + (k + 1) + ' من ' + A.length + ' · من جزء: ' + item.part_title}));
    body.push(el('div', {class: 'live-who solo'}, who, el('div', {class: 'ctrl'}, choose)));          // the one who answers is chosen above the question, before it is read
    paintWho();
    const nextLabel = last ? 'الأنشطة ➜' : 'سؤال المشاركة التالي ➜';
    const card = c.questionCard(item.q, 'today', ctrl => {
      choose.disabled = true;                                   // the answer is known: who answered is already fixed
      const b = el('button', {class: 'btn big', type: 'button', text: nextLabel});
      b.addEventListener('click', () => (last ? go(S.today.at + 1) : go(S.today.at, k + 1)));
      ctrl.append(b);
    });
    body.push(card);
    if (prev) body.push(el('div', {class: 'ctrl'}, prev));
    body.push(c.rosterPanel(() => { S.screen = {game: 'today', qid: null, revealed: false}; show(c, false); }));
  }

  document.addEventListener('keydown', e => {                   // the arrows move through the parts (in a right-to-left page «next» is the left arrow)
    const tag = document.activeElement && document.activeElement.tagName;
    if (!L.nav || /^(INPUT|SELECT|TEXTAREA)$/.test(tag || '') || !document.querySelector('.tdots')) return;
    if (e.key === 'ArrowLeft' || e.key === 'PageDown') L.nav.next(); else if (e.key === 'ArrowRight' || e.key === 'PageUp') L.nav.prev();          // a presenter's clicker sends PageDown / PageUp
  });
})();
