// «الخطة»: the lessons of one class in one subject, in the book's order, with where each stands and when it falls on her timetable.
(function () {
  const $ = id => document.getElementById(id);
  const say = (id, text) => { const n = $(id); n.textContent = text || ''; n.hidden = !text; };
  const KEY = 'lp-plan';
  const mem = () => { try { return JSON.parse(localStorage.getItem(KEY) || '{}'); } catch (e) { return {}; } };
  const keep = patch => { try { localStorage.setItem(KEY, JSON.stringify(Object.assign(mem(), patch))); } catch (e) {} };
  const lessonsW = n => arCount(n, ['درس واحد', 'درسان', 'دروس', 'درسًا']);
  const periodsW = n => arCount(n, ['حصة واحدة', 'حصتان', 'حصص', 'حصة']);
  const weeksW = n => arCount(n, ['أسبوع واحد', 'أسبوعان', 'أسابيع', 'أسبوعًا']);
  let pairs = [], cur = null, P = null, busy = false, textFor = null;
  const open = new Set();

  function toast(text, bad) {
    const t = el('div', {class: 'toast' + (bad ? ' bad' : ''), role: bad ? 'alert' : 'status', text});
    document.body.append(t); setTimeout(() => t.remove(), 4500);
  }

  // ---------------------------------------------------------------- the class and subject chooser
  function pairNote(p) {
    if (p.need === 'term') return 'حدّدي الفصل';
    if (p.need === 'book') return 'بلا كتاب';
    if (p.need === 'build' && !p.percent) return 'لم تُبنَ';
    return p.percent + '%' + (p.late ? ' · ' + p.late + ' متأخر' : '');
  }
  function drawPairs() {
    const box = $('pairs'); box.replaceChildren();
    pairs.forEach(p => {
      const on = cur && cur.class_id === p.class_id && cur.subject_id === p.subject_id;
      const b = el('button', {type: 'button', class: 'chip-btn' + (on ? ' on' : ''), 'aria-pressed': on ? 'true' : 'false'}, el('span', {class: 'pc', text: p.class_name}), el('span', {class: 'ps', text: p.subject_name}), el('small', {text: pairNote(p)}));
      b.addEventListener('click', () => { if (on) return; cur = p; keep({class_id: p.class_id, subject_id: p.subject_id}); drawPairs(); loadPlan(); });
      box.append(b);
    });
  }
  function syncPair() {
    if (!cur || !P) return;
    cur.need = P.need; cur.percent = P.summary ? P.summary.percent : 0; cur.late = P.summary ? P.summary.late.length : 0; drawPairs();
  }

  // ---------------------------------------------------------------- doing something to the plan
  const url = (path, q) => '/api/plan' + path + (q ? '?' + new URLSearchParams(q) : '');
  const ids = () => ({class_id: cur.class_id, subject_id: cur.subject_id});
  async function run(fn, done) {
    if (busy) return; busy = true; document.body.classList.add('busy');
    try { P = await fn(); syncPair(); paint(); if (done) done(); } catch (e) { toast(e.message, true); }
    finally { busy = false; document.body.classList.remove('busy'); }
  }
  const post = (path, data) => () => api('POST', url(path), data || {});
  const patch = (id, data) => () => api('PATCH', url('/' + id), data);

  // ---------------------------------------------------------------- one lesson of the plan
  function whenText(it) {
    if (it.status === 'done') return 'أُنجز' + (it.done_text ? ' · ' + it.done_text : '');
    if (it.status === 'skipped') return 'مستبعد من خطة هذا الفصل ولم يُحذف';
    const pl = it.planned;
    if (!pl) return P.has_slots ? 'لا تتّسع له حصص الجدول حتى نهاية الفصل' : 'بلا موعد بعد: أضيفي حصص المادة إلى الجدول';
    const a = pl.first, b = pl.last, one = a.date === b.date && a.period === b.period;
    return 'الموعد: ' + a.text + ' · الحصة ' + a.period + (one ? '' : ' ← ' + (a.date === b.date ? 'الحصة ' + b.period : b.text + ' · الحصة ' + b.period));
  }
  function tag(text, cls) { return el('span', {class: 'tag ' + (cls || ''), text}); }
  function btn(text, cls, fn, label) {
    const b = el('button', {type: 'button', class: 'btn small ' + (cls || 'ghost'), text}); if (label) b.setAttribute('aria-label', label); b.addEventListener('click', fn); return b;
  }
  function makeLesson(it) {
    run(async () => {
      try {
        const r = await api('POST', url('/' + it.id + '/lesson'));
        location.href = '/lessons/' + r.lesson_id; return new Promise(() => {});
      } catch (e) {
        if (e.status === 400 && /الصقي نصه/.test(e.message)) { textFor = it; $('ts-text').value = ''; say('ts-err', ''); $('text-sheet').hidden = false; $('ts-text').focus(); return P; }
        throw e;
      }
    });
  }
  function startHref(it) { return '/start?class=' + cur.class_id + '&subject=' + cur.subject_id + (it.lesson_id ? '&lesson=' + it.lesson_id : ''); }

  function itemRow(it, now, index) {
    const isNow = it.id === now && it.status === 'pending';
    const mark = it.status === 'done' ? '✓' : it.status === 'skipped' ? '⏸' : isNow ? '●' : '○';
    const title = el('b', {class: 'pi-t', text: it.title});
    const tags = [];
    if (isNow) tags.push(tag('الدرس الحالي', 'now'));
    if (it.kind === 'review') tags.push(tag('مراجعة'));
    if (it.kind === 'exam') tags.push(tag('اختبار'));
    if (it.late) tags.push(tag('متأخر', 'late')); else if (it.shifted) tags.push(tag('تأجّل موعده', 'shift'));
    if (it.lesson_id) tags.push(tag('له درس تفاعلي', 'ok'));
    let meta = whenText(it);
    if ((it.late || it.shifted) && it.due) meta += ' · كان موعده ' + it.due.text;
    const extra = [it.pages ? 'ص ' + it.pages[0] + (it.pages[1] > it.pages[0] ? '–' + it.pages[1] : '') : '', it.periods > 1 && !it.together ? periodsW(it.periods) : ''].filter(Boolean).join(' · ');
    const mate = P.items.find(x => x.id === (it.together || it.leads));
    const main = el('div', {class: 'pi-main'}, el('div', {class: 'pi-line'}, title, ...tags), el('small', {class: 'pi-when', text: meta}), extra ? el('small', {class: 'muted', text: extra}) : null,
      mate ? el('small', {class: 'pi-mate', text: '🔗 يُدرَّس في حصة واحدة مع «' + mate.title + '»' + (it.together ? ' (لا يأخذ حصة من عنده)' : '')}) : null,
      it.note ? el('small', {class: 'pi-note', text: '📝 ' + it.note}) : null);

    const acts = el('div', {class: 'pi-act'});
    if (it.status === 'pending') {
      acts.append(btn('تم ✓', 'sun', () => run(post('/' + it.id + '/done'))));
      if (isNow) acts.append(it.lesson_id ? el('a', {class: 'btn small', href: startHref(it), text: 'ابدئي الحصة ▶'}) : btn('تحويل إلى درس', '', () => makeLesson(it)));
      acts.append(btn('أنا هنا', 'ghost', () => {
        const before = P.items.filter(x => x.position < it.position && x.status === 'pending').length;
        if (before && !confirm('سيُعتبر ' + lessonsW(before) + ' قبل «' + it.title + '» منجزًا، ويُعاد توزيع الباقي من اليوم. متابعة؟')) return;
        run(post('/' + it.id + '/here'));
      }));
    } else if (it.status === 'done') acts.append(btn('تراجع', 'ghost', () => run(post('/' + it.id + '/undo'))));
    else acts.append(btn('إعادته إلى الخطة', 'ghost', () => run(post('/' + it.id + '/restore'))));
    if (it.status === 'pending' && mate) acts.append(btn('فكّ الدمج', 'ghost', () => run(post('/' + it.id + '/unmerge'))));
    const more = btn(open.has(it.id) ? 'إخفاء' : 'المزيد', 'ghost', () => { if (open.has(it.id)) open.delete(it.id); else open.add(it.id); paint(); });
    more.setAttribute('aria-expanded', open.has(it.id) ? 'true' : 'false'); acts.append(more);

    const li = el('li', {class: 'pi st-' + it.status + (isNow ? ' now' : '') + (it.late ? ' late' : ''), 'data-item': it.id}, el('span', {class: 'pi-mark', 'aria-hidden': 'true', text: mark}), main, acts);
    if (open.has(it.id)) li.append(morePanel(it, index));
    return li;
  }
  function morePanel(it, index) {
    const p = el('div', {class: 'pi-more'});
    if (it.status === 'pending') {
      p.append(el('label', {class: 'pm-row'}, 'عدد حصص هذا الدرس', stepper(it.periods, 1, 6, v => { if (v !== it.periods) run(patch(it.id, {periods: v})); }, 'عدد الحصص')));
      p.append(el('div', {class: 'pm-row'}, el('span', {text: 'مكانه في الخطة'}),
        btn('▲ أبكر', 'ghost', () => run(post('/' + it.id + '/move', {dir: 'up'}))), btn('▼ أبعد', 'ghost', () => run(post('/' + it.id + '/move', {dir: 'down'})))));
      const day = el('input', {type: 'date', max: P.today, 'aria-label': 'يوم الإنجاز'});
      p.append(el('div', {class: 'pm-row'}, el('span', {text: 'أنجزتُه في يوم سابق'}), day, btn('تسجيل', 'ghost', () => { if (!day.value) { toast('اختاري اليوم أولًا', true); return; } run(post('/' + it.id + '/done', {date: day.value})); })));
      const next = P.items.slice(index + 1).find(x => x.status === 'pending');
      if (next && it.kind === 'lesson' && next.kind === 'lesson' && !it.together && !it.leads && !next.together && !next.leads)
        p.append(el('div', {class: 'pm-row'}, btn('تدريسه مع «' + next.title + '» في حصة واحدة', 'ghost', () => run(post('/merge', {first: it.id, second: next.id}))),
          el('small', {class: 'muted', text: 'يوفّر ' + periodsW(next.periods) + '، ويمكنك فكّ الدمج لاحقًا.'})));
      p.append(el('div', {class: 'pm-row'}, btn('استبعاده من خطة هذا الفصل', 'ghost', () => { if (confirm('استبعاد «' + it.title + '» من خطة هذا الفصل؟ يبقى في القائمة ويمكنك إعادته.')) run(post('/' + it.id + '/skip')); })));
    }
    const note = el('input', {value: it.note || '', maxlength: 200, placeholder: 'ملاحظتك على هذا الدرس', 'aria-label': 'ملاحظة على الدرس'});
    note.addEventListener('change', () => run(patch(it.id, {note: note.value})));
    p.append(el('label', {class: 'pm-row'}, 'ملاحظة', note));
    if (it.lesson_id) p.append(el('div', {class: 'pm-row'}, el('a', {class: 'btn small ghost', href: '/lessons/' + it.lesson_id, text: 'فتح الدرس التفاعلي'}), el('a', {class: 'btn small', href: startHref(it), text: 'ابدئي الحصة ▶'})));
    else p.append(el('div', {class: 'pm-row'}, btn(it.has_text ? 'تحويل إلى درس تفاعلي' : 'تحويل إلى درس (الصقي نصه)', '', () => makeLesson(it))));
    return p;
  }

  // ---------------------------------------------------------------- the whole screen
  function drawNeed() {
    const card = $('need-card'), go = $('need-go'), build = $('need-build'); say('need-err', '');
    card.hidden = !P.need; go.hidden = true; build.hidden = true;
    if (!P.need) return;
    if (P.need === 'term') { $('need-h').textContent = 'حدّدي بداية الفصل الدراسي ونهايته'; $('need-p').textContent = 'تحتاج الخطة إلى أول يوم دراسة وآخر يوم لتوزّع عليهما الدروس.'; go.href = '/calendar'; go.textContent = 'فتح التقويم'; go.hidden = false; }
    else if (P.need === 'book') { $('need-h').textContent = 'اربطي كتابًا بهذا الفصل'; $('need-p').textContent = 'اختاري كتاب ' + P.subject.name + ' الذي يدرسه فصل ' + P.class.name + ' من صفحة المنهج.'; go.href = '/curriculum'; go.textContent = 'فتح المنهج'; go.hidden = false; }
    else {
      const first = !P.items.length;
      $('need-h').textContent = first ? 'جاهزة لبناء الخطة' : 'أضيفت دروس جديدة إلى الكتاب';
      $('need-p').textContent = first ? 'نرتّب دروس «' + P.book.title + '» على حصص جدولك من اليوم حتى نهاية الفصل. لا يتغير شيء في كتابك.' : 'اضغطي لتدخل الدروس الجديدة في الخطة في مكانها من الكتاب، ولا يتغير ما أنجزتِه.';
      build.textContent = first ? 'بناء الخطة' : 'إضافة الدروس الجديدة'; build.hidden = false;
    }
  }
  function drawSummary() {
    const s = P.summary, has = !!s && P.items.length > 0;
    $('sum-card').hidden = !has;
    if (!has) return;
    $('sum-title').textContent = P.class.name + ' · ' + P.subject.name;
    $('sum-today').textContent = 'اليوم: ' + P.today_text + ' · ' + P.book.title;
    $('sum-prog').value = s.percent;
    const now = P.items.find(i => i.id === s.current);
    $('sum-line').replaceChildren(el('b', {text: s.percent + '%'}), ' من الخطة أُنجز · ' + lessonsW(s.done) + ' منجز و' + lessonsW(s.pending) + ' باقٍ' + (s.skipped ? ' · ' + s.skipped + ' مستبعد' : ''),
      now ? el('span', {}, ' · الدرس الحالي: ', el('b', {text: now.title})) : (s.pending ? '' : ' · انتهت دروس الكتاب 🎉'));
    say('sum-late', s.late.length ? lessonsW(s.late.length) + ' متأخر عن موعده الأصلي. اضغطي «أنا هنا» عند الدرس الذي وصلتِ إليه، أو «إعادة توزيع الدروس من اليوم» لتبدئي العدّ من جديد.' : '');
    const sp = $('sum-space'), left = s.periods_left, need = s.periods_needed;
    if (!P.has_slots) { sp.hidden = true; }
    else {
      sp.hidden = false; sp.classList.toggle('warn', s.spare < 0);
      const wk = s.weeks_left != null ? ' (تبقّى ' + weeksW(s.weeks_left) + ' من الفصل)' : '';
      sp.textContent = s.spare < 0 ? 'ينقصك ' + periodsW(-s.spare) + ': تبقّى لك ' + periodsW(left) + ' في الجدول وتحتاج الدروس الباقية ' + periodsW(need) + wk + '.'
        : 'تبقّى لك ' + periodsW(left) + ' والدروس الباقية تحتاج ' + periodsW(need) + (s.spare ? ' — فائض ' + periodsW(s.spare) + ' للمراجعة' : '') + wk + '.';
    }
    $('sum-slots').hidden = P.has_slots;
    const ideas = $('sum-ideas'); ideas.hidden = !P.ideas.length || s.spare >= 0; ideas.replaceChildren();
    if (!ideas.hidden) {
      ideas.append(el('b', {text: 'أفكار لتغطية النقص (القرار لكِ، ولا يتغير شيء قبل موافقتك):'}),
        el('ul', {class: 'ideas'}, ...P.ideas.map(i => el('li', {}, el('span', {text: 'درّسي «' + i.first_title + '» و«' + i.second_title + '» معًا في حصة واحدة (توفّر ' + periodsW(i.saves) + ').'}),
          btn('ادمجيهما', 'sun', () => run(post('/merge', {first: i.first, second: i.second}))))), el('li', {text: 'أو اختصري حصة مراجعة، أو اطلبي حصص تعويضية.'})));
    }
    $('b-spread').disabled = !P.has_slots || !s.pending;
  }
  function drawItems() {
    const box = $('items-box'); box.replaceChildren();
    if (!P.items.length) return;
    const now = P.summary ? P.summary.current : null;
    const groups = [];
    P.items.forEach((it, i) => { const g = groups[groups.length - 1]; if (g && g.unit === it.unit) g.items.push([it, i]); else groups.push({unit: it.unit, items: [[it, i]]}); });
    groups.forEach(g => {
      const done = g.items.filter(([it]) => it.status === 'done').length;
      box.append(el('section', {class: 'card unit-plan'}, el('div', {class: 'up-head'}, el('h3', {text: g.unit || (groups.length > 1 ? 'دروس بلا وحدة' : 'الدروس')}), el('small', {class: 'muted', text: done + ' من ' + g.items.length})),
        el('ul', {class: 'pi-list'}, ...g.items.map(([it, i]) => itemRow(it, now, i)))));
    });
  }
  function drawLog() {
    const box = $('log-list'); box.replaceChildren();
    $('log-card').hidden = !P.log.length;
    P.log.forEach(l => box.append(el('li', {}, el('small', {class: 'muted', text: new Date(l.at * 1000).toLocaleString('ar', {day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit'})}), ' ', l.text)));
  }
  function paint() {
    $('plan-body').hidden = false; $('spread-box').hidden = true; say('sum-err', '');
    drawNeed(); drawSummary(); drawItems(); drawLog();
  }
  async function loadPlan() {
    $('plan-body').hidden = true;
    try { P = await api('GET', url('', ids())); syncPair(); paint(); } catch (e) { $('plan-body').hidden = false; $('need-card').hidden = true; $('sum-card').hidden = false; say('sum-err', e.message); }
  }

  // ---------------------------------------------------------------- the buttons of the summary
  $('need-build').addEventListener('click', () => run(post('/build', ids())));
  $('b-rebuild').addEventListener('click', () => {
    if (!confirm('ستُوزَّع الدروس غير المنجزة من جديد على الحصص القادمة ابتداءً من اليوم، ويزول بذلك وصف «متأخر». لا يُحذف شيء. متابعة؟')) return;
    run(post('/rebuild', ids()));
  });
  $('b-spread').addEventListener('click', async () => {
    const box = $('spread-box'); say('sum-err', '');
    try {
      const d = await api('GET', url('/spread', ids()));
      const apply = btn('تطبيق هذا التوزيع', 'sun', () => { run(post('/spread', ids())); }), cancel = btn('إلغاء', 'ghost', () => { box.hidden = true; });
      const line = d.spare > 0 ? 'تبقّى لك ' + periodsW(d.total) + '؛ يُعطى للدروس ' + periodsW(d.assigned) + ' ويبقى ' + periodsW(d.spare) + ' حرة للمراجعة والاختبارات.'
        : d.spare === 0 ? 'تبقّى لك ' + periodsW(d.total) + '، وكلها تُوزَّع على الدروس.'
        : 'تبقّى لك ' + periodsW(d.total) + ' وأقل ما تحتاجه الدروس ' + periodsW(d.assigned) + ' (حصة لكل درس): لا يكفي الوقت، ويمكنك دمج درسين في حصة واحدة.';
      box.replaceChildren(el('h3', {text: 'اقتراح توزيع الحصص حسب حجم كل درس'}), el('p', {class: 'muted', text: line}),
        el('ul', {class: 'spread'}, ...d.items.map(i => el('li', {}, el('span', {text: i.title}), el('b', {text: i.from === i.to ? i.to + ' (بلا تغيير)' : i.from + ' ← ' + i.to})))),
        el('p', {class: 'muted', text: 'يتغير عدد حصص الدروس غير المنجزة فقط، ولا يُحذف درس.'}), el('div', {class: 'btn-row'}, apply, cancel));
      box.hidden = false; box.scrollIntoView({behavior: 'smooth', block: 'nearest'});
    } catch (e) { say('sum-err', e.message); }
  });

  // ---------------------------------------------------------------- pasting the text of a lesson the book has no text for
  const closeSheet = () => { $('text-sheet').hidden = true; textFor = null; };
  $('ts-close').addEventListener('click', closeSheet);
  $('text-sheet').addEventListener('keydown', e => { if (e.key === 'Escape') closeSheet(); });
  $('ts-go').addEventListener('click', async () => {
    if (!textFor) return; say('ts-err', '');
    const b = $('ts-go'); b.disabled = true;
    try { const r = await api('POST', url('/' + textFor.id + '/lesson'), {text: $('ts-text').value}); location.href = '/lessons/' + r.lesson_id; }
    catch (e) { say('ts-err', e.message); b.disabled = false; }
  });

  // ---------------------------------------------------------------- start
  (async function init() {
    try {
      pairs = (await api('GET', '/api/plan/pairs')).pairs;
      $('no-pairs').hidden = !!pairs.length;
      if (!pairs.length) return;
      const q = new URLSearchParams(location.search), m = mem();
      const c = Number(q.get('class')) || m.class_id, s = Number(q.get('subject')) || m.subject_id;
      cur = pairs.find(p => p.class_id === c && p.subject_id === s) || pairs.find(p => p.class_id === c && !p.need) || pairs.find(p => p.class_id === c) || pairs.find(p => !p.need) || pairs[0];
      drawPairs(); await loadPlan();
    } catch (e) { $('no-pairs').textContent = e.message; $('no-pairs').hidden = false; }
  })();
})();
