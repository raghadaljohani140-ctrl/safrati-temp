// The page of one exam: its questions (edit, replace from the spares, add, move, marks), approval, the paper and the key, the messages for WhatsApp,
// and the marks of her students. Everything is kept on the server; the page only shows what the server says and asks it to change.
(function () {
  const root = document.getElementById('exam-app'), EID = Number(root.dataset.eid), API = '/api/exams/' + EID;
  const $ = id => document.getElementById(id);
  const say = (id, text) => { const n = $(id); n.textContent = text || ''; n.hidden = !text; };
  const fmt = x => String(Number(x));
  const altW = n => arCount(n, ['بديل واحد', 'بديلان', 'بدائل', 'بديلًا']);
  const approved = () => E.status === 'approved';
  let E = null, editing = 0, scoreData = null, shareData = null, liveTimer = null;
  const marksTimers = new Map();
  const ib = (text, label, fn, cls) => { const b = el('button', {type: 'button', class: 'ib' + (cls ? ' ' + cls : ''), text, 'aria-label': label}); if (fn) b.addEventListener('click', fn); return b; };
  const btn = (text, cls, fn) => { const b = el('button', {type: 'button', class: 'btn ' + cls, text}); b.addEventListener('click', fn); return b; };
  const kindName = k => (E.kinds.find(x => x.key === k) || {name: k}).name;

  async function copyText(text, button) {
    try { await navigator.clipboard.writeText(text); }
    catch (e) {
      const ta = el('textarea', {'aria-hidden': 'true', readonly: true}); ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.append(ta); ta.select();
      try { document.execCommand('copy'); } catch (e2) {} ta.remove();
    }
    if (button) { const old = button.textContent; button.textContent = 'تم النسخ ✓'; setTimeout(() => { button.textContent = old; }, 2200); }
  }
  function live(text, bad) {
    const n = $('ex-live');
    n.textContent = text; n.hidden = !text; n.classList.toggle('bad', !!bad);
    clearTimeout(liveTimer);
    if (text) liveTimer = setTimeout(() => { n.hidden = true; }, 9000);
  }

  // ------------------------------------------------------------ start
  async function start() {
    try { E = (await api('GET', API)).exam; } catch (e) { $('ex-loading').hidden = true; return say('ex-err', e.message); }
    $('ex-loading').hidden = true; $('ex-body').hidden = false;
    fillDetails(); renderAll(); drawAddForm(); drawCopy();
    $('ed-save').addEventListener('click', saveDetails);
    $('ex-spread').addEventListener('submit', spread);
    $('ex-del').addEventListener('click', removeExam);
    $('cp-go').addEventListener('click', copyExam);
    $('ad-go').addEventListener('click', addManual);
    $('ad-kind').addEventListener('change', drawAddForm);
    $('sc-save').addEventListener('click', saveScores);
    $('sc-print').addEventListener('click', printScores);
    try {
      const k = 'lp-exam-skipped-' + EID, raw = sessionStorage.getItem(k);
      if (raw) { sessionStorage.removeItem(k); const list = JSON.parse(raw); if (list.length) say('ex-skipped', 'لم تدخل هذه الدروس في الاختبار: ' + list.join(' — ')); }
    } catch (e) {}
  }
  function renderAll() { drawHead(); drawQuestions(); drawBar(); drawOutputs(); drawScores(); }

  // ------------------------------------------------------------ the head and the details of the paper
  function drawHead() {
    const meta = [E.class && E.class.name, E.subject && E.subject.name, E.date_text, E.minutes ? E.minutes + ' دقيقة' : '', arQ(E.count), E.count ? arMarks(E.total) : ''].filter(Boolean);
    $('ex-headcard').replaceChildren(el('div', {class: 'ex-head'}, el('div', {class: 'ex-head-line'}, el('span', {class: 'badge ' + (approved() ? 'st-ok' : 'st-wait'), text: E.status_text})),
      el('h1', {text: E.title}), el('p', {class: 'ex-meta', text: meta.join(' · ')})));
    document.title = E.title + ' · ملعب الدرس';
  }
  function fillDetails() {
    $('ed-title').value = E.title; $('ed-date').value = E.date || ''; $('ed-minutes').value = E.minutes || ''; $('ed-header').value = E.header || ''; $('ed-notes').value = E.notes || '';
  }
  async function saveDetails() {
    const b = $('ed-save'); b.disabled = true; $('ed-msg').textContent = '';
    try {
      const r = await api('PATCH', API, {title: $('ed-title').value, date: $('ed-date').value, minutes: Number($('ed-minutes').value) || 0, header: $('ed-header').value, notes: $('ed-notes').value});
      E = r.exam; shareData = null;
      fillDetails(); drawHead(); drawOutputs(); $('ed-msg').textContent = 'تم الحفظ ✓';
    } catch (e) { $('ed-msg').textContent = e.message; }
    b.disabled = false;
  }

  // ------------------------------------------------------------ the questions
  function totalsNow() { return E.questions.reduce((a, q) => a + q.marks, 0); }
  function refreshTotals() {
    E.total = totalsNow(); E.total_text = fmt(E.total);
    $('ex-qsum').textContent = arQ(E.count) + ' · المجموع ' + arMarks(E.total);
    E.kinds.forEach(k => { const n = $('exs-m-' + k.key); if (n) n.textContent = sectionNote(k.key); });
    const meta = document.querySelector('#ex-headcard .ex-meta');
    if (meta) meta.textContent = [E.class && E.class.name, E.subject && E.subject.name, E.date_text, E.minutes ? E.minutes + ' دقيقة' : '', arQ(E.count), E.count ? arMarks(E.total) : ''].filter(Boolean).join(' · ');
  }
  function sectionNote(kind) {
    const marks = E.questions.filter(q => q.kind === kind).reduce((a, q) => a + q.marks, 0);
    return (marks ? 'درجات القسم: ' + fmt(marks) : '') + (!approved() ? (marks ? ' · ' : '') + 'البدائل المتبقية: ' + (E.spares[kind] || 0) : '');
  }
  function drawQuestions() {
    const lock = $('ex-lockmsg');
    lock.hidden = !approved();
    lock.textContent = '🔒 الاختبار معتمد، فلا تتغيّر أسئلته ولا درجة كل سؤال. ألغي الاعتماد من الأسفل إن أردتِ التعديل (درجات الطلاب المسجّلة لا تُحذف).';
    const lacking = Object.entries(E.short || {}).filter(([k]) => (E.counts[k] || 0) < (E.wanted[k] || 0));
    say('ex-short', !approved() && lacking.length ? 'لم يتّسع نص الدروس لكل ما طلبتِه: ' + lacking.map(([k]) => '«' + kindName(k) + '» المطلوب ' + E.wanted[k] + ' والموجود ' + (E.counts[k] || 0)).join('، ') + '. أضيفي الباقي بيدك، أو اختاري دروسًا أكثر في اختبار جديد.' : '');
    $('ex-spread-box').hidden = approved() || !E.count;
    $('ex-addbox').hidden = approved();
    $('ex-qsum').textContent = arQ(E.count) + ' · المجموع ' + arMarks(E.total);
    const kids = E.kinds.map(section).filter(Boolean);
    const others = approved() ? [] : E.kinds.filter(k => !E.questions.some(q => q.kind === k.key) && (E.spares[k.key] || 0) > 0);
    if (others.length) kids.push(el('div', {class: 'exs exs-others'}, el('p', {class: 'muted', text: kids.length ? 'أنواع أخرى يمكن إضافتها إلى الاختبار من البدائل:' : 'ابدئي بإضافة أسئلة من البدائل:'}),
      el('div', {class: 'exs-tools'}, others.map(k => btn('+ ' + k.name + ' (' + altW(E.spares[k.key]) + ')', 'ghost small', ev => addFromSpare(k.key, ev.currentTarget))))));
    $('ex-sections').replaceChildren(...kids);
    $('ex-noq').hidden = kids.length > 0;
  }
  function section(k) {
    const qs = E.questions.filter(q => q.kind === k.key), spares = E.spares[k.key] || 0;
    if (!qs.length) return null;
    const head = el('div', {class: 'exs-head'}, el('h3', {text: k.name + (qs.length ? ' (' + qs.length + ')' : '')}), el('span', {class: 'muted', id: 'exs-m-' + k.key, text: sectionNote(k.key)}));
    const kids = [head];
    if (!approved()) {
      const tools = el('div', {class: 'exs-tools'});
      tools.append(btn('+ سؤال آخر من هذا النوع' + (spares ? ' (' + altW(spares) + ')' : ''), 'ghost small', ev => addFromSpare(k.key, ev.currentTarget)));
      if (E.can_ask_ai) tools.append(btn('⚡ بدائل من القارئ الذكي', 'ghost small', ev => moreAI(k.key, ev.currentTarget)));
      kids.push(tools);
    }
    qs.forEach((q, i) => kids.push(editing === q.id ? editCard(q, i) : card(q, i, qs.length)));
    return el('section', {class: 'exs', 'data-kind': k.key, 'aria-label': k.name}, ...kids);
  }

  function marksCtl(q) {
    const out = el('output', {class: 'stp-v', text: fmt(q.marks)}), minus = ib('−', 'أنقصي نصف درجة'), plus = ib('+', 'زيدي نصف درجة');
    const paint = () => { out.textContent = fmt(q.marks); minus.disabled = q.marks <= 0.5; plus.disabled = q.marks >= 50; };
    const set = v => {
      q.marks = Math.round(Math.min(50, Math.max(0.5, v)) * 2) / 2; paint(); refreshTotals();
      clearTimeout(marksTimers.get(q.id));
      marksTimers.set(q.id, setTimeout(async () => {
        marksTimers.delete(q.id);
        try { const r = await api('PATCH', API + '/questions/' + q.id, {marks: q.marks}); E.total = r.exam.total; E.total_text = r.exam.total_text; refreshTotals(); }
        catch (e) { live(e.message, true); }
      }, 450));
    };
    minus.addEventListener('click', () => set(q.marks - 0.5)); plus.addEventListener('click', () => set(q.marks + 0.5)); paint();
    return el('div', {class: 'exq-marks'}, el('span', {text: 'الدرجة'}), el('span', {class: 'stepper', role: 'group', 'aria-label': 'درجة السؤال'}, minus, out, plus));
  }
  function body(q) {
    const kids = [];
    if (q.kind === 'mcq') {
      kids.push(el('ul', {class: 'exq-opts'}, q.options.map((o, i) => el('li', {class: o === q.answer ? 'right' : ''}, (o === q.answer ? '✓ ' : '') + 'أبجدهوزح'[i] + '- ' + o))));
    } else if (q.kind === 'tf') {
      kids.push(el('p', {class: 'exq-ans'}, 'الإجابة: ', el('b', {text: q.answer})));
    } else {
      kids.push(el('p', {class: 'exq-ans'}, (q.kind === 'cloze' ? 'الكلمة: ' : 'الإجابة النموذجية: '), el('b', {text: q.answer})));
    }
    return kids;
  }
  function card(q, i, n) {
    const busy = editing && editing !== q.id;
    const c = el('article', {class: 'exq' + (q.clear ? '' : ' unclear'), 'data-id': q.id});
    const top = el('div', {class: 'exq-top'}, el('span', {class: 'exq-n', text: String(i + 1)}), el('span', {class: 'exq-kind', text: kindName(q.kind)}));
    c.append(top);
    c.append(approved() ? el('p', {class: 'exq-marks-ro', text: 'الدرجة: ' + arMarks(q.marks)}) : marksCtl(q));
    c.append(el('p', {class: 'exq-text', text: q.question}), ...body(q));
    const tags = [];
    if (q.source) tags.push(q.source === 'سؤالك' ? '✍️ سؤالك' : q.source === 'القارئ الذكي' ? '⚡ القارئ الذكي' : '📖 ' + q.source);
    if (q.edited) tags.push('عدّلتِه');
    if (tags.length) c.append(el('div', {class: 'exq-tags'}, el('small', {text: tags.join(' · ')})));
    if (!q.clear) c.append(el('p', {class: 'exq-warn', text: '⚠️ لا توجد إجابة واضحة في النص — راجعي الإجابة قبل الاعتماد'}));
    if (!approved()) {
      const spares = E.spares[q.kind] || 0;
      const acts = el('div', {class: 'exq-acts'});
      const edit = btn('✎ تعديل', 'ghost small', () => { editing = q.id; drawQuestions(); });
      const rep = el('button', {type: 'button', class: 'btn ghost small exq-rep'}, el('span', {text: '⟳ استبدال'}), el('small', {text: spares ? altW(spares) : 'لا بدائل'}));
      rep.addEventListener('click', () => replace(q, c, rep));
      const up = ib('↑', 'حرّكي السؤال إلى أعلى', () => move(q, -1)), down = ib('↓', 'حرّكي السؤال إلى أسفل', () => move(q, 1));
      up.dataset.act = 'up'; down.dataset.act = 'down'; up.disabled = i === 0; down.disabled = i === n - 1;
      const del = btn('🗑 حذف', 'ghost small danger', () => remove(q, del));
      [edit, rep, up, down, del].forEach(b => { if (busy) b.disabled = true; });
      top.append(el('span', {class: 'exq-move', role: 'group', 'aria-label': 'ترتيب السؤال'}, up, down));
      acts.append(edit, rep, del);
      c.append(acts);
    }
    return c;
  }

  // editing one question in place
  function mcqEditor(options, answer) {
    const host = el('fieldset', {}, el('legend', {text: 'الخيارات — اختاري الدائرة بجانب الإجابة الصحيحة'}));
    const group = 'ans' + Math.random().toString(36).slice(2), rows = [];
    const list = el('div', {class: 'ex-opts-edit'}), add = btn('+ خيار', 'ghost small', () => { if (rows.length < 6) { addRow('', false); redraw(); } });
    function addRow(text, right) {
      const radio = el('input', {type: 'radio', name: group, 'aria-label': 'هذا هو الصحيح'}), input = el('input', {maxlength: '200', placeholder: 'نص الخيار', 'aria-label': 'نص الخيار'});
      radio.checked = !!right; input.value = text;
      const row = {radio, input, node: el('div', {class: 'ex-opt-edit'}, radio, input)}; rows.push(row);
    }
    function redraw() { list.replaceChildren(...rows.map(r => r.node)); add.disabled = rows.length >= 6; }
    (options.length ? options : ['', '', '', '']).forEach(o => addRow(o, o !== '' && o === answer));
    if (!rows.some(r => r.radio.checked)) rows[0].radio.checked = true;
    redraw();
    host.append(list, add);
    return {node: host, get() { const picked = rows.find(r => r.radio.checked), opts = rows.map(r => r.input.value.trim()).filter(Boolean); return {options: opts, answer: picked ? picked.input.value.trim() : ''}; }};
  }
  function fields(kind, q, idp) {
    // the inputs for a question of this kind; get() gives what the server takes
    const text = el('textarea', {rows: '3', maxlength: '600', id: idp + '-q', 'aria-label': 'نص السؤال'}); text.value = q.question || '';
    const wrap = el('div', {class: 'exq-form'}, el('label', {}, 'نص السؤال', text));
    if (kind === 'cloze') wrap.append(el('p', {class: 'muted', text: 'ضعي _____ مكان الكلمة الناقصة، واكتبي الكلمة في خانة الإجابة.'}));
    let get;
    if (kind === 'mcq') {
      const m = mcqEditor(q.options || [], q.answer || ''); wrap.append(m.node);
      get = () => ({question: text.value, ...m.get()});
    } else if (kind === 'tf') {
      const sel = el('select', {'aria-label': 'الإجابة'}, el('option', {value: 'صح', text: 'صح'}), el('option', {value: 'خطأ', text: 'خطأ'}));
      sel.value = q.answer === 'خطأ' ? 'خطأ' : 'صح'; wrap.append(el('label', {}, 'الإجابة', sel));
      get = () => ({question: text.value, answer: sel.value});
    } else {
      const ans = kind === 'cloze' ? el('input', {maxlength: '600'}) : el('textarea', {rows: '3', maxlength: '600'});
      ans.value = q.answer || ''; wrap.append(el('label', {}, kind === 'cloze' ? 'الكلمة الناقصة' : 'الإجابة النموذجية', ans));
      get = () => ({question: text.value, answer: ans.value});
    }
    return {node: wrap, get, focus: () => text.focus()};
  }
  function editCard(q, i) {
    const f = fields(q.kind, q, 'ed' + q.id), err = el('p', {class: 'note bad', role: 'alert', hidden: true});
    const save = btn('حفظ', '', async () => {
      err.hidden = true; save.disabled = true;
      try { const r = await api('PATCH', API + '/questions/' + q.id, f.get()); E = r.exam; editing = 0; drawQuestions(); drawBar(); focusCard(q.id); live('حُفظ تعديل السؤال ✓'); }
      catch (e) { save.disabled = false; err.textContent = e.message; err.hidden = false; }
    });
    const cancel = btn('إلغاء', 'ghost', () => { editing = 0; drawQuestions(); focusCard(q.id); });
    const c = el('article', {class: 'exq editing', 'data-id': q.id}, el('div', {class: 'exq-top'}, el('span', {class: 'exq-n', text: String(i + 1)}), el('span', {class: 'exq-kind', text: 'تعديل سؤال «' + kindName(q.kind) + '»'})), f.node, err, el('div', {class: 'btn-row'}, save, cancel));
    setTimeout(() => f.focus(), 0);
    return c;
  }

  function focusCard(id, flash) {
    const c = document.querySelector('.exq[data-id="' + id + '"]');
    if (!c) return;
    c.scrollIntoView({block: 'nearest', behavior: 'smooth'});
    if (flash) { c.classList.add('fresh'); setTimeout(() => c.classList.remove('fresh'), 2600); }
    const b = c.querySelector('button:not(:disabled)'); if (b) b.focus({preventScroll: true});
  }

  async function replace(q, c, b) {
    if (editing) return;
    b.disabled = true;
    try {
      const r = await api('POST', API + '/questions/' + q.id + '/replace');
      E = r.exam; drawQuestions(); drawBar(); focusCard(r.question.id, true);
      live('استُبدل السؤال بسؤال عن جزء آخر من الدرس. ' + (r.spares ? 'بقي ' + altW(r.spares) + ' من هذا النوع.' : 'لا بدائل أخرى من هذا النوع.'));
    } catch (e) {
      b.disabled = false;
      if (e.status !== 409) return live(e.message, true);
      c.querySelector('.exq-nosp') && c.querySelector('.exq-nosp').remove();
      const box = el('div', {class: 'exq-nosp', role: 'status'}, el('p', {text: e.message + '.'}));
      const row = el('div', {class: 'btn-row'}, btn('✍️ أضيفي سؤالًا بيدك', 'small', () => openAdd(q.kind)));
      if (E.can_ask_ai) row.append(btn('⚡ اطلبي من القارئ الذكي', 'ghost small', ev => moreAI(q.kind, ev.currentTarget)));
      box.append(row); c.append(box);
    }
  }
  async function move(q, dir) {
    if (editing) return;
    try {
      const r = await api('POST', API + '/questions/' + q.id + '/move', {dir});
      E = r.exam; drawQuestions();
      const c = document.querySelector('.exq[data-id="' + q.id + '"]');
      if (c) { c.scrollIntoView({block: 'nearest', behavior: 'smooth'}); const same = c.querySelector('[data-act=' + (dir < 0 ? 'up' : 'down') + ']'), other = c.querySelector('[data-act=' + (dir < 0 ? 'down' : 'up') + ']'); (same && !same.disabled ? same : other).focus({preventScroll: true}); }
    } catch (e) { live(e.message, true); }
  }
  async function remove(q, b) {
    if (editing) return;
    if (!confirm('حذف هذا السؤال من الاختبار؟\n' + q.question.slice(0, 120))) return;
    b.disabled = true;
    try { const r = await api('DELETE', API + '/questions/' + q.id); E = r.exam; drawQuestions(); drawBar(); live('حُذف السؤال. المجموع الآن ' + arMarks(E.total) + '.'); }
    catch (e) { b.disabled = false; live(e.message, true); }
  }
  async function addFromSpare(kind, b) {
    if (editing) return;
    b.disabled = true;
    try {
      const r = await api('POST', API + '/spare', {kind});
      E = r.exam; drawQuestions(); drawBar(); focusCard(r.question.id, true); live('أُضيف سؤال من نوع «' + kindName(kind) + '». ' + (r.spares ? 'بقي ' + altW(r.spares) + '.' : 'لا بدائل أخرى من هذا النوع.'));
    } catch (e) { b.disabled = false; live(e.message, true); }
  }
  async function moreAI(kind, b) {
    b.disabled = true; const old = b.textContent; b.textContent = 'جارٍ طلب الأسئلة…';
    try {
      const r = await api('POST', API + '/more', {kind});
      E = r.exam; drawQuestions(); drawBar();
      live(r.added ? 'أضاف القارئ الذكي ' + altW(r.added) + ' من نوع «' + kindName(kind) + '». استبدلي بها أو أضيفيها من «سؤال آخر من هذا النوع».' : 'لم يقدّم القارئ الذكي بدائل جديدة لهذا النوع من هذه الدروس.');
    } catch (e) { b.disabled = false; b.textContent = old; live(e.message, true); }
  }
  async function spread(ev) {
    ev.preventDefault();
    const v = $('ex-spread-total').value.trim();
    if (!v) return live('اكتبي الدرجة الكلية المطلوبة، مثل 20.', true);
    try { const r = await api('POST', API + '/marks', {total: v}); E = r.exam; drawQuestions(); drawBar(); live('وُزّعت الدرجات: المجموع الآن ' + arMarks(E.total) + '.'); }
    catch (e) { live(e.message, true); }
  }

  // ------------------------------------------------------------ her own question
  function openAdd(kind) {
    const box = $('ex-addbox');
    box.open = true; if (kind) { $('ad-kind').value = kind; drawAddForm(); }
    box.scrollIntoView({behavior: 'smooth', block: 'center'}); setTimeout(() => $('ad-q').focus({preventScroll: true}), 250);
  }
  let adder = null, adMarks = 1;
  function drawAddForm() {
    const sel = $('ad-kind');
    if (!sel.options.length) E.kinds.forEach(k => sel.append(el('option', {value: k.key, text: k.name})));
    const kind = sel.value || E.kinds[0].key, box = $('ad-opts'), ans = $('ad-ans-l'), prev = $('ad-q').value;
    box.replaceChildren(); ans.hidden = false;
    adder = null;
    if (kind === 'mcq') { adder = mcqEditor([], ''); box.append(adder.node); ans.hidden = true; }
    else if (kind === 'tf') {
      const s = el('select', {id: 'ad-tf', 'aria-label': 'الإجابة'}, el('option', {value: 'صح', text: 'صح'}), el('option', {value: 'خطأ', text: 'خطأ'}));
      adder = {get: () => ({answer: s.value})}; box.append(el('label', {}, 'الإجابة', s)); ans.hidden = true;
    }
    $('ad-ans-l').firstChild.textContent = kind === 'cloze' ? 'الكلمة الناقصة' : 'الإجابة النموذجية';
    $('ad-q').placeholder = kind === 'cloze' ? 'مثال: تُنتج النباتات غذاءها بعملية _____' : '';
    $('ad-q').value = prev;
    adMarks = (E.kinds.find(k => k.key === kind) || {marks: 1}).marks;
    const stepperHost = $('ad-marks');
    const out = el('output', {class: 'stp-v', text: fmt(adMarks)}), minus = ib('−', 'أنقصي نصف درجة'), plus = ib('+', 'زيدي نصف درجة');
    const paint = () => { out.textContent = fmt(adMarks); minus.disabled = adMarks <= 0.5; plus.disabled = adMarks >= 50; };
    minus.addEventListener('click', () => { adMarks = Math.max(0.5, adMarks - 0.5); paint(); }); plus.addEventListener('click', () => { adMarks = Math.min(50, adMarks + 0.5); paint(); }); paint();
    stepperHost.replaceChildren(el('span', {class: 'stepper', role: 'group', 'aria-label': 'درجة السؤال'}, minus, out, plus));
  }
  async function addManual() {
    const kind = $('ad-kind').value, b = $('ad-go');
    say('ad-err', '');
    const data = {kind, question: $('ad-q').value, marks: adMarks};
    if (adder) Object.assign(data, adder.get()); else data.answer = $('ad-ans').value;
    b.disabled = true;
    try {
      const r = await api('POST', API + '/questions', data);
      E = r.exam; $('ad-q').value = ''; $('ad-ans').value = ''; drawAddForm(); drawQuestions(); drawBar(); focusCard(r.question.id, true); live('أُضيف سؤالك إلى قسم «' + kindName(kind) + '».');
    } catch (e) { say('ad-err', e.message); }
    b.disabled = false;
  }

  // ------------------------------------------------------------ approving
  function drawBar() {
    const bar = $('ex-bar'), unclear = E.questions.filter(q => !q.clear).length;
    bar.classList.toggle('ok', approved());
    if (approved()) {
      const un = btn('إلغاء الاعتماد للتعديل', 'ghost small', async () => {
        if (!confirm('سيعود الاختبار مسودة لتعدّلي أسئلته، وتبقى الدرجات المسجّلة محفوظة. متابعة؟')) return;
        un.disabled = true;
        try { const r = await api('POST', API + '/unapprove'); E = r.exam; shareData = null; scoreData = null; renderAll(); window.scrollTo({top: 0, behavior: 'smooth'}); }
        catch (e) { un.disabled = false; live(e.message, true); }
      });
      $('ex-bar-hint').textContent = '';
      bar.replaceChildren(el('b', {class: 'grow', text: '✅ الاختبار معتمد'}), un);
      return;
    }
    const go = btn('✓ اعتماد الاختبار', 'sun big', async () => {
      if (!E.count) return live('أضيفي سؤالًا واحدًا على الأقل قبل الاعتماد.', true);
      if (unclear && !confirm(arQ(unclear) + ' لم نجد لإجاباتها دعمًا واضحًا في النص، وستظهر في مفتاح الإجابة كما هي. تأكدي منها أولًا إن أمكن. اعتماد الاختبار مع ذلك؟')) return;
      go.disabled = true;
      try { const r = await api('POST', API + '/approve'); E = r.exam; shareData = null; scoreData = null; renderAll(); $('ex-outcard').scrollIntoView({behavior: 'smooth', block: 'start'}); }
      catch (e) { go.disabled = false; live(e.message, true); }
    });
    go.disabled = !E.count;
    $('ex-bar-hint').textContent = unclear ? '⚠️ ' + arQ(unclear) + ' بلا دعم واضح في النص — راجعيها قبل الاعتماد.' : 'بعد الاعتماد تُفتح الورقة والمفتاح وتسجيل الدرجات، ويمكنك إلغاء الاعتماد وتعديل الأسئلة متى شئتِ.';
    bar.replaceChildren(go);
  }

  // ------------------------------------------------------------ the paper, the key, WhatsApp
  function drawOutputs() {
    const ok = approved();
    $('ex-out-h').textContent = ok ? 'الورقة والمفتاح والواتساب' : 'معاينة الورقة والمفتاح';
    $('ex-out-links').replaceChildren(
      el('a', {class: 'btn ' + (ok ? 'sun' : 'ghost'), href: '/exams/' + EID + '/print', target: '_blank', rel: 'noopener', text: ok ? '🖨 ورقة الاختبار (A4)' : '👁 معاينة الورقة (مسودة)'}),
      el('a', {class: 'btn ghost', href: '/exams/' + EID + '/key', target: '_blank', rel: 'noopener', text: ok ? '🔑 مفتاح الإجابة' : '👁 معاينة المفتاح'}));
    $('ex-share').hidden = !ok;
    if (ok) loadShare();
  }
  async function loadShare() {
    const host = $('ex-share-list');
    try {
      if (!shareData) shareData = await api('GET', API + '/share');
    } catch (e) { return host.replaceChildren(el('p', {class: 'note bad', role: 'alert', text: e.message})); }
    const d = shareData;
    const block = (title, text, wa, extra, note) => {
      const copy = btn('📋 نسخ النص', 'ghost small', () => copyText(text, copy));
      return el('div', {class: 'ex-share-box'}, el('h4', {text: title}), el('pre', {class: 'ex-msg', text}),
        note ? el('p', {class: 'muted', text: note}) : null,
        el('div', {class: 'btn-row'}, copy, wa ? el('a', {class: 'btn small sun', href: wa, target: '_blank', rel: 'noopener noreferrer', text: '💬 فتح واتساب بالنص'}) : null, extra));
    };
    host.replaceChildren(
      block('رسالة إعلان الاختبار', d.announce, d.announce_wa, d.group ? el('a', {class: 'btn small ghost', href: d.group, target: '_blank', rel: 'noopener noreferrer', text: 'فتح مجموعة الفصل'}) : null,
        'ليس فيها أسئلة ولا أسماء طلاب: موعد الاختبار ودروسه ودرجته الكلية.'),
      block('نص الأسئلة (بلا إجابات)', d.text, d.text_too_long ? '' : d.text_wa, null, d.text_too_long ? 'النص أطول من أن يُفتح في رابط واتساب؛ انسخيه والصقيه في المحادثة، أو أرسلي الورقة ملف PDF.' : null));
  }

  // ------------------------------------------------------------ the marks of the students
  async function drawScores() {
    const card = $('ex-scores-card');
    card.hidden = !approved();
    if (!approved()) return;
    $('sc-csv').href = API + '/scores/csv';
    if (!scoreData) {
      try { scoreData = await api('GET', API + '/scores'); } catch (e) { return say('sc-err', e.message); }
    }
    paintScores();
  }
  function paintScores() {
    const d = scoreData, total = E.total, list = $('sc-list');
    $('sc-sub').textContent = (E.class ? E.class.name + ' · ' : '') + 'الدرجة الكلية ' + fmt(total);
    $('sc-none').hidden = d.students.length > 0; $('sc-acts').hidden = !d.students.length;
    const s = d.stats, tile = (v, l, n) => el('div', {class: 'stat-tile'}, el('b', {text: String(v)}), el('span', {text: l}), n ? el('small', {text: n}) : null);
    const tiles = [tile(s.entered + ' من ' + s.students, 'سُجّلت درجاتهم', s.absent ? 'غائبون: ' + s.absent : (s.missing ? 'بلا درجة: ' + s.missing : null))];
    if (s.entered) tiles.push(tile(s.average, 'المتوسط من ' + fmt(total), s.percent != null ? s.percent + '٪' : null), tile(fmt(s.highest), 'الأعلى'), tile(fmt(s.lowest), 'الأدنى'), tile(s.passed, 'حصلوا على 50٪ فأكثر'));
    $('sc-tiles').replaceChildren(...tiles);
    list.replaceChildren(...d.students.map(r => {
      const score = el('input', {type: 'number', inputmode: 'decimal', min: '0', max: String(total), step: '0.5', 'aria-label': 'درجة ' + r.name, placeholder: '—'}),
        abs = el('input', {type: 'checkbox', 'aria-label': r.name + ' غائب'}), note = el('input', {maxlength: '100', placeholder: 'ملاحظة', 'aria-label': 'ملاحظة عن ' + r.name}), pct = el('span', {class: 'sc-pct'});
      score.value = r.score == null ? '' : fmt(r.score); abs.checked = r.absent; note.value = r.note || '';
      const paint = () => { score.disabled = abs.checked; row.classList.toggle('gone', abs.checked); const v = parseFloat(score.value); pct.textContent = !abs.checked && !isNaN(v) && total ? Math.round(100 * v / total) + '٪' : ''; };
      const row = el('li', {class: 'sc-row', 'data-id': r.student_id}, el('span', {class: 'sc-name', text: r.name}), el('span', {}, score, pct), el('label', {class: 'sc-abs'}, abs, 'غائب'), el('span', {class: 'sc-note'}, note));
      row._get = () => ({student_id: r.student_id, score: score.value.trim(), absent: abs.checked, note: note.value});
      score.addEventListener('input', paint); abs.addEventListener('change', paint); paint();
      return row;
    }));
  }
  async function saveScores() {
    say('sc-err', ''); $('sc-msg').textContent = '';
    const rows = [...document.querySelectorAll('#sc-list .sc-row')].map(r => r._get());
    for (const r of rows) {
      if (r.absent || r.score === '') continue;
      const v = Number(r.score);
      if (isNaN(v) || v < 0 || v > E.total) return say('sc-err', 'درجة غير صحيحة عند «' + (scoreData.students.find(s => s.student_id === r.student_id) || {}).name + '»: الدرجة بين 0 و' + fmt(E.total) + '.');
    }
    const b = $('sc-save'); b.disabled = true;
    try { scoreData = await api('PUT', API + '/scores', {scores: rows}); paintScores(); $('sc-msg').textContent = 'حُفظت الدرجات ✓'; setTimeout(() => { $('sc-msg').textContent = ''; }, 3000); }
    catch (e) { say('sc-err', e.message); }
    b.disabled = false;
  }
  function printScores() {
    document.body.classList.add('print-scores');
    const done = () => { document.body.classList.remove('print-scores'); window.removeEventListener('afterprint', done); };
    window.addEventListener('afterprint', done);
    window.print();
    setTimeout(done, 1500);
  }

  // ------------------------------------------------------------ copying and deleting
  async function drawCopy() {
    const sel = $('cp-class');
    try {
      const c = (await api('GET', '/api/classes')).classes.filter(x => !E.class || x.id !== E.class.id);
      if (!c.length) { $('cp-go').disabled = true; sel.replaceChildren(el('option', {value: '', text: 'لا فصل آخر عندك'})); return; }
      sel.replaceChildren(...c.map(x => el('option', {value: String(x.id), text: x.name})));
    } catch (e) { $('cp-go').disabled = true; }
  }
  async function copyExam() {
    const id = Number($('cp-class').value);
    if (!id) return;
    say('cp-err', ''); $('cp-go').disabled = true;
    try { const r = await api('POST', API + '/copy', {class_id: id}); location.href = '/exams/' + r.exam.id; }
    catch (e) { $('cp-go').disabled = false; say('cp-err', e.message); }
  }
  async function removeExam() {
    if (!confirm('حذف «' + E.title + '» مع أسئلته ودرجات طلابه؟ لا يمكن التراجع عن ذلك.')) return;
    $('ex-del').disabled = true;
    try { await api('DELETE', API); location.href = '/exams'; }
    catch (e) { $('ex-del').disabled = false; say('cp-err', e.message); }
  }

  start();
})();
