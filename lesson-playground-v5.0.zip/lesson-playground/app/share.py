"""Sharing through WhatsApp without the WhatsApp API and without any subscription.

Two links are all it takes. A class's group invite (https://chat.whatsapp.com/…) opens that group; https://wa.me/?text=… opens WhatsApp with a message already
written, and the teacher picks the chat (or the class group) herself and presses send. Nothing is sent from here, nothing is stored at WhatsApp, and no
phone number or student name is ever put in a link: the messages are about the work (the homework, the exam), not about a student.
"""
import datetime
import re
from urllib.parse import quote

AR_DAYS = ("الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد")          # datetime.weekday(): Monday is 0
AR_MONTHS = ("يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر")
BAD_LINK = "رابط مجموعة واتساب غير صحيح. هو يبدأ عادةً بـ https://chat.whatsapp.com/ وتجدينه في معلومات المجموعة ثم «دعوة عبر رابط»"
_URL = re.compile(r"https?://[^\s<>\"']+|(?:chat\.whatsapp\.com|wa\.me|whatsapp\.com)/[^\s<>\"']+", re.I)
_OK = re.compile(r"^https://(?:chat\.whatsapp\.com/(?:invite/)?[A-Za-z0-9_-]{8,64}|whatsapp\.com/channel/[A-Za-z0-9_-]{8,64}|wa\.me/(?:message/|channel/)?[A-Za-z0-9_+-]{3,64})/?$")
MAX_TEXT = 3500          # WhatsApp opens a link of a few thousand characters without trouble; a longer message is cut with a note


def clean_group_link(raw):
    """The link of a WhatsApp group in its clean form, '' for an empty box, or None when what was pasted is not a WhatsApp link.
    A whole invitation message may be pasted: the link is picked out of it, and tracking parameters are dropped."""
    text = str(raw or "").strip()
    if not text:
        return ""
    m = _URL.search(text)
    if not m:
        return None
    url = m.group(0).rstrip(".,،؛)»")
    if url.lower().startswith("http://"):
        url = "https://" + url[7:]
    elif not url.lower().startswith("https://"):
        url = "https://" + url
    url = url.split("?")[0].split("#")[0]
    return url if _OK.match(url) else None


def wa_text_url(text: str) -> str:
    """https://wa.me/?text=… : WhatsApp opens with this text written and asks the teacher whom to send it to."""
    text = str(text or "")
    if len(text) > MAX_TEXT:
        text = text[:MAX_TEXT].rstrip() + "…"
    return "https://wa.me/?text=" + quote(text, safe="")


def ar_date(iso) -> str:
    """'الأحد 9 نوفمبر 2026' from '2026-11-08'; '' when it is not a date."""
    try:
        d = datetime.date.fromisoformat(str(iso))
    except ValueError:
        return ""
    return f"{AR_DAYS[d.weekday()]} {d.day} {AR_MONTHS[d.month - 1]} {d.year}"


def _lines(*parts) -> str:
    return "\n".join(p for p in parts if p is not None).strip()


def notes_message(title: str, subject: str, parts) -> str:
    """The teacher's own copy of a lesson's explanation: the parts, their points and the terms, as a short message she can keep in her own chat."""
    out = [f"*{title}*" + (f" — {subject}" if subject else ""), ""]
    for i, p in enumerate(parts, 1):
        out.append(f"*{i}. {p['title']}*")
        out.extend(f"• {x}" for x in p.get("points", []))
        for t in p.get("terms", []):
            out.append(f"◦ {t['term']}: {t['def']}")
        out.append("")
    return _lines(*out)


def _meta(e) -> str:
    """«المادة · الفصل» when the title of the exam does not already say them."""
    title = e.get("title") or ""
    parts = [(e.get("subject") or {}).get("name", ""), (e.get("class") or {}).get("name", "")]
    return " · ".join(x for x in parts if x and x not in title)


def exam_announcement(e) -> str:
    """The message for a class's group before an exam: what it is, when, how long, how many marks, which lessons. No question, no student's name."""
    head = f"📝 *{e['title']}*" + (f" ({_meta(e)})" if _meta(e) else "")
    lessons = [s.get("label", "") for s in e.get("sources", []) if s.get("label")]
    shown = "، ".join(lessons[:8]) + (f" (و{len(lessons) - 8} دروس أخرى)" if len(lessons) > 8 else "")
    return _lines(head, f"📅 الموعد: {e['date_text']}" if e.get("date_text") else None, f"⏱ الزمن: {e['minutes']} دقيقة" if e.get("minutes") else None,
                  f"🔢 الدرجة الكلية: {e['total_text']}", f"📚 المقرر: {shown}" if shown else None, "", "بالتوفيق للجميع 🌟")


def exam_plain_text(e) -> str:
    """The questions of an exam as one text (no answers) for the teacher to copy; the sections in order with their marks."""
    out = [f"*{e['title']}*" + (f" ({_meta(e)})" if _meta(e) else ""), f"الدرجة الكلية: {e['total_text']}"]
    for sec in e.get("sections", []):
        out += ["", f"*السؤال {sec['ordinal']}: {sec['title']}* ({sec['marks_word']})"]
        for q in sec["items"]:
            text = q["question"].replace("_____", "........")
            if q["kind"] == "tf":
                text = "( ) " + text
            out.append(f"{q['n']}) {text} [{q['marks_text']}]")          # [2]: the number alone, the word is in the heading of the section
            if q["kind"] == "mcq":
                out.append("   " + "   ".join(f"{l}) {o}" for l, o in zip(q["letters"], q["options"])))
    return _lines(*out)


def homework_announcement(a) -> str:
    """The message for a class's group when a homework, an activity, a project, a reading or a revision is given: what it is, what is asked and by when.
    No student's name and no phone number (the message is about the work, not about anybody)."""
    head = f"{a['icon']} *{a['title']}*" + (f" ({_meta(a)})" if _meta(a) else "")
    topic = a.get("topic") or ""
    return _lines(head, f"📖 الدرس: {topic}" if topic and topic not in a["title"] else None, f"📅 موعد التسليم: {a['due_text']}" if a.get("due_text") else None,
                  "", "المطلوب:", a["instructions"], "", "وفقكم الله 🌟")


def homework_reminder(a) -> str:
    """A short reminder for the group, worded by how near (or past) the day is. It names nobody: who has not done it is for the teacher alone."""
    state, when = a.get("due_state"), a.get("due_text") or ""
    line = {"today": "⏰ موعد التسليم اليوم", "tomorrow": "⏰ موعد التسليم غدًا", "past": f"⏰ انتهى موعد التسليم ({when})" if when else None,
            "later": f"⏰ موعد التسليم {when}" if when else None}.get(state)
    text = a["instructions"]
    short = text if len(text) <= 300 else text[:300].rsplit(" ", 1)[0].rstrip("،,.؛ ") + "…"
    tail = "من لم يسلّمه فليسلّمه في أقرب وقت، وفقكم الله 🌟" if state == "past" else "نرجو إنجازه وتسليمه في موعده، وفقكم الله 🌟"
    return _lines(f"🔔 *تذكير: {a['title']}*", line, "", short, "", tail)
