"""The rule of the app: every question and answer must come from the uploaded file. Each question carries a quotation (`evidence`) from the file;
a question whose quotation is not really in the file, or whose answer is not in that quotation, is not trusted."""
import re

_DIAC = re.compile(r"[ً-ٰٟـ]")
_PUNCT = re.compile(r"[^\w\s]", re.UNICODE)
_TRANS = str.maketrans({"أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا", "ى": "ي", "ة": "ه", "ؤ": "و", "ئ": "ي",
                        **{chr(0x660 + i): str(i) for i in range(10)}})
UNCLEAR = "لا توجد إجابة واضحة في الملف"


def norm(text: str) -> str:
    text = _DIAC.sub("", text or "").translate(_TRANS).lower()
    return re.sub(r"\s+", " ", _PUNCT.sub(" ", text)).strip()


def words(text: str) -> list[str]:
    return [w for w in norm(text).split() if len(w) > 1]


def in_text(snippet: str, text_norm: str) -> bool:
    s = norm(snippet)
    return len(s) >= 3 and s in text_norm


def verify(q: dict, text_norm: str, strict: bool = True) -> bool:
    """True when the question is backed by the file."""
    ev = q.get("evidence") or ""
    if not in_text(ev, text_norm):
        return False
    kind = q.get("kind")
    ans = q.get("answer") or ""
    if not ans.strip() or ans.strip() == UNCLEAR:
        return False
    if kind in ("tf",):
        return ans.strip() in ("صح", "خطأ")
    ev_n = norm(ev)
    if strict:
        return norm(ans) in ev_n
    aw = words(ans)
    return bool(aw) and sum(1 for w in aw if w in ev_n) / len(aw) >= 0.6
