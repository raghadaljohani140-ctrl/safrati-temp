"""«نسختي الاحتياطية»: the teacher's own data in one file she keeps, and back from that file.

What goes in the file is what SHE made: her classes and students, their points, answers, homework and exam marks, her books and their outlines, her timetable and calendar and plans,
the terms she closed, her lessons with their questions and games. What stays out is what is not hers to carry: the account itself (e-mail, mobile, password), the plan and what she paid,
the meters of the reader (AI use, lessons counted), and the files she uploaded (the PDF / Word originals), because only their text and questions are kept.

The file is a ZIP: `manifest.json` (what it holds, with a fingerprint of every table) and one `tables/<name>.jsonl` per table (a line is a row). Reading it never trusts it:
sizes are checked before anything is unpacked, every table is checked against its fingerprint, every value against the type of its column, every reference against the rows that
are in the file, and a name of a stored file is never taken from it (the server makes its own), so a made-up file can neither reach the disk nor another teacher.

Restoring REPLACES her data with the file's, all or nothing: the whole file is first tried in a scratch database in memory, then written in ONE transaction on a connection of its own
(`BEGIN IMMEDIATE`, so nothing else writes meanwhile); any problem rolls everything back and her account is exactly as it was. Just before it, a safety copy of what she had is kept
(one per teacher, in `user_backups`, which goes with the account), and she can go back to it. Every row gets a new id, so a file from another account or another server fits as well;
the references between rows (and the ids written inside the JSON of a deck or an exam) are carried to the new ids. A plan's limit on lessons and decks is kept: a restore never gives an
account more than it could hold before."""
import hashlib
import io
import json
import logging
import re
import sqlite3
import threading
import time
import uuid
import zipfile
import zlib
from datetime import datetime

from flask import Blueprint, Response, current_app, g, jsonify, render_template, request

from . import billing, classroom, db as dbm
from .security import Limiter, login_required
from .students import body

log = logging.getLogger(__name__)
bp = Blueprint("backup", __name__)
download_limit = Limiter(10, 3600)
preview_limit = Limiter(15, 3600)
restore_limit = Limiter(6, 3600)

FORMAT = "lessonplay-backup"
VERSION = 1
MAX_FILE_MB = 40                    # what she may upload (compressed)
MAX_FILE = MAX_FILE_MB * 1024 * 1024
MAX_MEMBER = 120 * 1024 * 1024      # one table, unpacked
MAX_TOTAL = 150 * 1024 * 1024       # all of them, unpacked
MAX_LINE = 8 * 1024 * 1024          # one row
MAX_ROWS = 600_000
TEXT_MAX = 2_000_000                # a long text (a lesson, a book's lesson)
DATA_MAX = 6_000_000                # the frozen summary of a closed term
SHORT_MAX = 300                     # a name, a title, a label, a day
INT_MAX = 2 ** 53

# the tables that hold what a teacher made, parents before children (a table points only at tables above it). tests/test_v5_phase7.py checks that every table of the database is
# in this list or in EXCLUDED, so a table added later can not be forgotten here.
ORDER = ("teacher_settings", "subjects", "classes", "students", "books", "book_units", "book_lessons", "class_subjects", "schedule_times", "schedule_slots", "terms", "calendar_days",
         "absences", "lessons", "questions", "decks", "plan_items", "plan_log", "points", "results", "assignments", "assignment_students", "exams", "exam_questions", "exam_scores",
         "term_archives")
EXCLUDED = {"users": "the account", "plans": "the site's plans", "settings": "the site's settings", "expenses": "the site's costs", "subscription_requests": "what she paid",
            "ai_usage": "the meter of the reader", "lesson_usage": "the meter of the lessons", "plan_events": "the manager's notes on her plan", "user_backups": "the safety copy itself"}
SKIP = {"lessons": ("stored_name",), "books": ("stored_name",)}          # names of files on the server: never written to the file, never read from it
SOFT = {"plan_log": {"class_id": "classes", "subject_id": "subjects", "term_id": "terms"}, "results": {"question_id": "questions"}}          # ids no FOREIGN KEY guards
DROP_ORPHANS = {"plan_log"}          # a line of the plan's log about something that is gone is left out; a result keeps its text and loses only the link
SHORT = {"name", "title", "subject", "grade", "original_name", "whatsapp", "kind", "status", "source", "game", "ref", "note", "label", "reason", "day", "starts", "ends", "exam_date",
         "given_date", "due_date", "done_on", "closed_on", "orig_ends", "client_key", "run", "deck_title", "origin", "state", "period"}
LESSON_STATES = ("processing", "ready", "failed")
KIND = re.compile(r"^[a-z0-9_]{1,16}$")
SAFE_FILE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,120}$")

NOT_BACKUP = "هذا الملف ليس نسخة احتياطية من ملعب الدرس. اختاري الملف الذي نزّلتِه من هذه الصفحة (امتداده zip)"
CORRUPT = "الملف تالف أو عُدّل بعد تنزيله، فلا يمكن استعادته. لم يتغير شيء في حسابك"
NEWER = "أُخذت هذه النسخة من إصدار أحدث من التطبيق ولا يمكن قراءتها هنا. لم يتغير شيء في حسابك"
TOO_BIG = "النسخة أكبر مما يمكن قراءته هنا. لم يتغير شيء في حسابك"
BUSY = "هناك استعادة أخرى لحسابك قيد التنفيذ، انتظري حتى تنتهي"
_ZIP_ERRORS = (zipfile.BadZipFile, zlib.error, EOFError, RuntimeError, NotImplementedError, OSError, ValueError, OverflowError)
_running = {}          # user ids whose restore is running now (in this process)
_running_lock = threading.Lock()


class BackupError(Exception):
    """A file that can not be used. The text is for her; `detail` (the table and the row) is for the log."""

    def __init__(self, message, detail=""):
        super().__init__(message)
        self.message, self.detail = message, detail


def corrupt(table="", line=0, why=""):
    return BackupError(CORRUPT, f"{table}:{line} {why}".strip())


def _no_constant(name):
    raise ValueError(name)


# ---------------------------------------------------------------- the database, as the backup sees it
def connect(path):
    """A connection of its own (not the one the pages share), in autocommit so that the transaction is exactly what is written here."""
    conn = sqlite3.connect(str(path), timeout=15, isolation_level=None, check_same_thread=False)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def scratch():
    """A database in memory with the same tables and one account, where a file is tried before it is written for real."""
    conn = sqlite3.connect(":memory:", isolation_level=None)
    conn.execute("PRAGMA foreign_keys = ON")
    dbm.init(conn)
    conn.execute("INSERT INTO users(id, email, name, pass_hash, created_at) VALUES (1, 'scratch@invalid', '-', '-', 0)")
    return conn


def columns(conn, table) -> list:
    return [{"name": r[1], "type": (r[2] or "").upper(), "notnull": bool(r[3]), "pk": bool(r[5])} for r in conn.execute(f"PRAGMA table_info({table})")]


def parents(conn, table) -> dict:
    """{column: (the table it points at, what happens to the row when that one goes)} for the foreign keys of a table, without the owner. A reference that is cleared when its parent goes
    (SET NULL) may be missing from a file; one that goes with its parent (CASCADE) may not."""
    return {r[3]: (r[2], r[6]) for r in conn.execute(f"PRAGMA foreign_key_list({table})") if r[2] != "users"}


# ---------------------------------------------------------------- writing the file
def export_zip(conn, uid, created=None) -> tuple:
    """(the ZIP as bytes, its manifest) for one teacher. The caller holds a read transaction so that every table is seen as of one moment."""
    created = created or time.time()
    out, tables, total = io.BytesIO(), {}, 0
    stamp = time.gmtime(created)[:6]
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for name in ORDER:
            cols = [c["name"] for c in columns(conn, name) if c["name"] != "user_id" and c["name"] not in SKIP.get(name, ())]
            order = " ORDER BY id" if "id" in cols else ""
            digest, buf, n = hashlib.sha256(), io.BytesIO(), 0
            for row in conn.execute(f"SELECT {', '.join(cols)} FROM {name} WHERE user_id = ?{order}", (uid,)):
                line = (json.dumps(dict(zip(cols, tuple(row))), ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")
                digest.update(line)
                buf.write(line)
                n += 1
            total += n
            tables[name] = {"rows": n, "sha256": digest.hexdigest()}
            info = zipfile.ZipInfo(f"tables/{name}.jsonl", date_time=stamp)
            info.compress_type = zipfile.ZIP_DEFLATED
            zf.writestr(info, buf.getvalue())
        manifest = {"format": FORMAT, "version": VERSION, "created_at": created, "rows": total, "tables": tables, "counts": counts_of(conn, uid),
                    "note": "ملف نسخة احتياطية من ملعب الدرس: لا يحتوي بيانات الحساب ولا كلمة المرور ولا الملفات الأصلية المرفوعة"}
        info = zipfile.ZipInfo("manifest.json", date_time=stamp)
        info.compress_type = zipfile.ZIP_DEFLATED
        zf.writestr(info, json.dumps(manifest, ensure_ascii=False, indent=1))
    return out.getvalue(), manifest


def counts_of(conn, uid) -> dict:
    """How much she has of each thing, in the words the screens use."""
    one = lambda sql: conn.execute(sql, (uid,)).fetchone()[0]
    c = {t: one(f"SELECT COUNT(*) FROM {t} WHERE user_id = ?") for t in ("classes", "students", "subjects", "books", "book_lessons", "lessons", "questions", "points", "results",
                                                                          "assignments", "exams", "term_archives", "plan_items", "terms")}
    c["decks"] = one("SELECT COUNT(*) FROM decks WHERE user_id = ? AND auto = 0")
    return c


# ---------------------------------------------------------------- reading a file
def open_zip(raw: bytes) -> tuple:
    """(the ZipFile, the manifest) of a file that looks like a backup of this version or an older one; BackupError otherwise. Nothing is unpacked to disk, ever."""
    if not raw or raw[:4] != b"PK\x03\x04":
        raise BackupError(NOT_BACKUP)
    if len(raw) > MAX_FILE:
        raise BackupError(f"الملف أكبر من المسموح ({MAX_FILE_MB} ميجابايت). لم يتغير شيء في حسابك")
    try:
        zf = zipfile.ZipFile(io.BytesIO(raw))
        infos = zf.infolist()
    except Exception:
        raise BackupError(NOT_BACKUP)
    names = [i.filename for i in infos]
    want = {"manifest.json"} | {f"tables/{t}.jsonl" for t in ORDER}
    if len(names) != len(set(names)) or len(names) > len(want) + 8:
        raise corrupt(why="member names")
    if "manifest.json" not in names:
        raise BackupError(NOT_BACKUP)
    if sum(i.file_size for i in infos) > MAX_TOTAL or any(i.file_size > MAX_MEMBER for i in infos):
        raise BackupError(TOO_BIG)
    if any(i.flag_bits & 0x1 or i.is_dir() or i.filename not in want for i in infos):
        raise corrupt(why="member kind")
    try:
        with zf.open("manifest.json") as f:
            head = f.read(2 * 1024 * 1024 + 1)
        if len(head) > 2 * 1024 * 1024:
            raise BackupError(TOO_BIG)
        manifest = json.loads(head, parse_constant=_no_constant)
    except BackupError:
        raise
    except Exception:
        raise corrupt(why="manifest")
    if not isinstance(manifest, dict) or manifest.get("format") != FORMAT:
        raise BackupError(NOT_BACKUP)
    version = manifest.get("version")
    if isinstance(version, bool) or not isinstance(version, int) or version < 1:
        raise corrupt(why="version")
    if version > VERSION:
        raise BackupError(NEWER)
    meta = manifest.get("tables")
    if not isinstance(meta, dict) or set(meta) != set(ORDER):
        raise corrupt(why="tables")
    rows = 0
    for t, m in meta.items():
        if (not isinstance(m, dict) or isinstance(m.get("rows"), bool) or not isinstance(m.get("rows"), int) or m["rows"] < 0
                or not isinstance(m.get("sha256"), str) or not re.fullmatch(r"[0-9a-f]{64}", m["sha256"]) or f"tables/{t}.jsonl" not in names):
            raise corrupt(t, why="table entry")
        rows += m["rows"]
    if rows > MAX_ROWS:
        raise BackupError(TOO_BIG)
    created = manifest.get("created_at")
    if isinstance(created, bool) or not isinstance(created, (int, float)) or created != created or abs(created) > 4e9:
        manifest["created_at"] = 0
    return zf, manifest


def read_rows(zf, manifest, name):
    """The rows of one table, one dict at a time. When the last one has been given, the table has been checked against its fingerprint and its count; a caller must read to the end."""
    meta = manifest["tables"][name]
    digest, n = hashlib.sha256(), 0
    try:
        with zf.open(f"tables/{name}.jsonl") as f:
            while True:
                line = f.readline(MAX_LINE + 1)
                if not line:
                    break
                if len(line) > MAX_LINE:
                    raise BackupError(TOO_BIG)
                digest.update(line)
                n += 1
                if n > meta["rows"]:
                    raise corrupt(name, n, "more rows than the manifest says")
                try:
                    row = json.loads(line, parse_constant=_no_constant)
                except (ValueError, RecursionError):
                    raise corrupt(name, n, "not json")
                if not isinstance(row, dict):
                    raise corrupt(name, n, "not an object")
                yield row
    except BackupError:
        raise
    except _ZIP_ERRORS:
        raise corrupt(name, n, "unreadable")
    if n != meta["rows"] or digest.hexdigest() != meta["sha256"]:
        raise corrupt(name, n, "fingerprint")


def value_of(table, col, meta, v, line):
    """A value of the file as the column of the database wants it, or BackupError."""
    if v is None:
        return None
    kind = meta["type"]
    if "INT" in kind:
        if isinstance(v, bool) or not isinstance(v, int) or abs(v) > INT_MAX:
            raise corrupt(table, line, f"{col} is not an integer")
        return v
    if kind in ("REAL", "FLOAT", "DOUBLE"):
        if isinstance(v, bool) or not isinstance(v, (int, float)) or v != v or abs(v) > 1e300:
            raise corrupt(table, line, f"{col} is not a number")
        return v
    if not isinstance(v, str):
        raise corrupt(table, line, f"{col} is not text")
    v = v.replace("\x00", "")
    limit = SHORT_MAX if col in SHORT else DATA_MAX if col == "data" else TEXT_MAX
    if len(v) > limit:
        if col in SHORT:
            return v[:limit]
        raise corrupt(table, line, f"{col} is too long")
    return v


# ---------------------------------------------------------------- the ids inside the JSON of a deck and of an exam
def _json_list(text):
    try:
        v = json.loads(text) if isinstance(text, str) and text else []
    except (ValueError, RecursionError):
        return []
    return v if isinstance(v, list) else []


def _question_ids(text, ids):
    """decks.question_ids: the questions of the deck, by their new ids (one that is not in the file is left out)."""
    known = ids.get("questions", {})
    return json.dumps([known[q] for q in _json_list(text) if isinstance(q, int) and not isinstance(q, bool) and q in known])


def _sources(text, ids):
    """exams.sources: the lessons an exam was made from ({t: 'bl', id} a lesson of a book, {t: 'up', id} a lesson she uploaded), by their new ids."""
    out = []
    for ref in _json_list(text):
        if not isinstance(ref, dict) or isinstance(ref.get("id"), bool) or not isinstance(ref.get("id"), int):
            continue
        table = {"bl": "book_lessons", "up": "lessons"}.get(ref.get("t"))
        new = ids.get(table, {}).get(ref["id"]) if table else None
        if new:
            out.append({**{k: v for k, v in ref.items() if k in ("t", "label") and isinstance(v, str)}, "id": new})
    return json.dumps(out, ensure_ascii=False)


JSON_IDS = {"decks": ("question_ids", _question_ids), "exams": ("sources", _sources)}


# ---------------------------------------------------------------- putting a file in a database
class Restorer:
    """Writes the rows of a file for one account, table by table, parents first. It writes into whatever connection it is given (the scratch one to try, the real one to restore)."""

    def __init__(self, conn, uid, zf, manifest, caps=None, keep_files=None):
        self.conn, self.uid, self.zf, self.manifest = conn, uid, zf, manifest
        self.caps = caps or {}
        self.keep = keep_files or {}          # {(table, kind, original_name, created_at): stored_name} of what she has now: a lesson that is still hers keeps its file
        self.cols = {t: columns(conn, t) for t in ORDER}
        self.fks = {t: parents(conn, t) for t in ORDER}
        self.ids, self.left = {}, {t: set() for t in ORDER}
        self.counts, self.reused, self.manual_decks, self.cut = {}, set(), 0, {"lessons": 0, "decks": 0}
        self.wanted = {p for t in ORDER for p, _ in self.fks[t].values()} | {p for s in SOFT.values() for p in s.values()} | {"questions", "book_lessons", "lessons"}

    # ---- which lessons and decks a plan can hold
    def trim(self):
        cap_l, cap_d = self.caps.get("lessons"), self.caps.get("decks")
        if cap_l is None and cap_d is None:
            return
        lessons = []
        for i, row in enumerate(read_rows(self.zf, self.manifest, "lessons"), 1):
            lessons.append((self.number(row, "created_at", "lessons", i), self.ident(row, "lessons", i)))
        keep = {i for _, i in sorted(lessons, reverse=True)[:cap_l]} if cap_l is not None else {i for _, i in lessons}          # the newest ones stay
        self.left["lessons"] = {i for _, i in lessons} - keep
        self.cut["lessons"] = len(self.left["lessons"])
        decks = []
        for i, row in enumerate(read_rows(self.zf, self.manifest, "decks"), 1):
            if row.get("auto"):
                continue          # the deck the app keeps for a lesson is not one of hers: it goes only with its lesson
            lesson = row.get("lesson_id")
            if isinstance(lesson, bool) or not isinstance(lesson, int):
                raise corrupt("decks", i, "lesson_id")          # (a deck of no lesson; the table itself says more when it is written)
            if lesson in keep:
                decks.append((self.number(row, "updated_at", "decks", i), self.ident(row, "decks", i)))
            else:
                self.cut["decks"] += 1
        if cap_d is not None:
            over = {i for _, i in sorted(decks, reverse=True)[cap_d:]}
            self.left["decks"] = over
            self.cut["decks"] += len(over)

    @staticmethod
    def number(row, col, table, line):
        v = row.get(col)
        if isinstance(v, bool) or not isinstance(v, (int, float)) or v != v:
            raise corrupt(table, line, f"{col} is not a number")
        return v

    @staticmethod
    def ident(row, table, line):
        v = row.get("id")
        if isinstance(v, bool) or not isinstance(v, int) or not 1 <= v <= INT_MAX:
            raise corrupt(table, line, "id")
        return v

    # ---- the tables
    def run(self) -> dict:
        self.trim()
        for name in ORDER:
            self.table(name)
        return {"counts": dict(self.counts), "manual_decks": self.manual_decks, "left_out": {t: n for t, n in self.cut.items() if n}}

    def table(self, name):
        cols = {c["name"]: c for c in self.cols[name]}
        own = "id" in cols
        allowed = [c for c in cols if c not in ("id", "user_id") and c not in SKIP.get(name, ())]
        fks = {c: p for c, p in self.fks[name].items() if c in cols}
        soft = SOFT.get(name, {})
        base = self.conn.execute(f"SELECT COALESCE(MAX(id), 0) FROM {name}").fetchone()[0] if own else 0
        made, seen, later, sqls = 0, set(), [], {}
        new_ids = self.ids.setdefault(name, {}) if name in self.wanted else None
        for line, row in enumerate(read_rows(self.zf, self.manifest, name), 1):
            old = None
            if own:
                old = self.ident(row, name, line)
                if old in seen:
                    raise corrupt(name, line, "id twice")
                seen.add(old)
            if name == "lessons" and old in self.left["lessons"] or name == "decks" and old in self.left["decks"]:
                continue
            vals = {c: value_of(name, c, cols[c], row[c], line) for c in allowed if c in row}
            dropped, to_self = False, []
            for c, (p, on_delete) in fks.items():
                v = vals.get(c)
                if v is None:
                    continue
                if p == name:
                    to_self.append((c, old, v))          # a row that points at a row of its own table (two lessons taught together): set when the table is written
                    vals[c] = None
                    continue
                new = self.ids.get(p, {}).get(v) if isinstance(v, int) else None
                if new is not None:
                    vals[c] = new
                elif on_delete != "SET NULL":
                    if v in self.left.get(p, ()):
                        dropped = True          # its parent was left out for the plan's limit: so is it
                        break
                    raise corrupt(name, line, f"{c} points at nothing")
                else:
                    vals[c] = None          # a link that is cleared when what it points at goes (a result whose deck is gone)
            if not dropped:
                for c, p in soft.items():
                    v = vals.get(c)
                    if v is None:
                        continue
                    new = self.ids.get(p, {}).get(v) if isinstance(v, int) else None
                    if new is None and name in DROP_ORPHANS:
                        dropped = True
                        break
                    vals[c] = new
            if dropped:
                if own:
                    self.left[name].add(old)
                continue
            later += to_self
            if name in JSON_IDS:
                c, fn = JSON_IDS[name]
                if c in vals:
                    vals[c] = fn(vals[c], self.ids)
            self.special(name, vals, row)
            if name == "decks" and not vals.get("auto"):
                self.manual_decks += 1
            made += 1
            if own:
                vals["id"] = base + made
                if new_ids is not None:
                    new_ids[old] = vals["id"]
            vals["user_id"] = self.uid
            present = tuple(vals)
            if present not in sqls:
                sqls[present] = f"INSERT INTO {name}({', '.join(present)}) VALUES ({', '.join('?' * len(present))})"
            try:
                self.conn.execute(sqls[present], tuple(vals[c] for c in present))
            except (sqlite3.Error, UnicodeError, OverflowError) as exc:
                raise corrupt(name, line, f"{type(exc).__name__}: {exc}")
        for c, old, target in later:
            new = new_ids.get(target) if new_ids is not None else None
            if new is not None:
                self.conn.execute(f"UPDATE {name} SET {c} = ? WHERE id = ?", (new, new_ids[old]))
        self.counts[name] = made

    def special(self, name, vals, row):
        """What a row of these tables needs besides its values: the name of its file (made here, never read), and a reading that never finished."""
        if name == "lessons":
            key = ("lessons", vals.get("kind"), vals.get("original_name"), vals.get("created_at"))
            kept = self.keep.get(key)
            if kept in self.reused:
                kept = None
            if kept:
                self.reused.add(kept)
            vals["stored_name"] = kept or "restored-" + uuid.uuid4().hex
            if not KIND.match(str(vals.get("kind") or "")):
                vals["kind"] = "txt"
            if vals.get("status") not in LESSON_STATES:
                vals["status"] = "failed"
            if vals["status"] == "processing":
                vals["status"], vals["error"] = "failed", "لم تكتمل قراءة هذا الدرس قبل أخذ النسخة. أعيدي رفع ملفه"
        elif name == "books":
            key = ("books", vals.get("kind"), vals.get("original_name"), vals.get("created_at"))
            kept = self.keep.get(key)
            if kept in self.reused:
                kept = None
            if kept:
                self.reused.add(kept)
            vals["stored_name"] = kept or ""
            if vals.get("status") == "processing":
                vals["status"], vals["error"] = "failed", "لم تكتمل قراءة هذا الكتاب قبل أخذ النسخة. أعيدي رفع ملفه"
        elif name == "teacher_settings":
            try:
                data = json.loads(vals.get("data") or "{}")
            except (ValueError, RecursionError):
                data = {}
            vals["data"] = json.dumps(data if isinstance(data, dict) else {}, ensure_ascii=False)


def purge(conn, uid):
    """Everything of hers the backup holds, children first (the database would cascade anyway; this says it)."""
    for name in reversed(ORDER):
        conn.execute(f"DELETE FROM {name} WHERE user_id = ?", (uid,))


def files_of(conn, uid) -> tuple:
    """({(table, kind, original_name, created_at): stored_name}, every stored name) of the lessons and books she has now."""
    keep, every = {}, set()
    for table in ("lessons", "books"):
        for kind, original, created, stored in conn.execute(f"SELECT kind, original_name, created_at, stored_name FROM {table} WHERE user_id = ?", (uid,)):
            every.add(stored)
            if stored and SAFE_FILE.match(stored) and not stored.startswith(("restored-", "book-")):
                keep[(table, kind, original, created)] = stored
    return keep, every


def caps_for(db, user) -> dict:
    """The most lessons and decks a restore may leave her with: never more than her plan keeps, and never fewer than she already keeps (a plan that ended leaves her lessons)."""
    plan = billing.plan_of(db, user)
    lessons, decks = billing.usage(db, user["id"])
    free = billing.effective_code(user) == "free"
    return {"lessons": max(plan["max_lessons"], lessons) if free else None, "decks": max(plan["max_decks"], decks)}


# ---------------------------------------------------------------- the two things a route does
def trial(raw, uid_caps) -> tuple:
    """Try the file in a scratch database. Returns (the report, the manifest). Nothing real is touched."""
    zf, manifest = open_zip(raw)
    conn = scratch()
    try:
        conn.execute("BEGIN")
        report = Restorer(conn, 1, zf, manifest, uid_caps).run()
        conn.execute("ROLLBACK")
    finally:
        conn.close()
    return report, manifest


def restore(app, uid, raw, caps) -> dict:
    """Replace her data with the file's. Everything or nothing. Returns the report; BackupError when the file can not be used; other errors when the server could not do it (nothing changed then too)."""
    with _running_lock:
        if uid in _running:
            raise BackupError(BUSY)
        _running[uid] = True
    try:
        report, manifest = trial(raw, caps)          # the whole file is read and tried before the real tables are touched
        zf, manifest = open_zip(raw)
        conn = connect(app.cfg.db_path)
        old_files, committed = set(), False
        try:
            conn.execute("BEGIN IMMEDIATE")
            conn.execute("PRAGMA defer_foreign_keys = ON")
            keep, old_files = files_of(conn, uid)
            safety, summary = export_zip(conn, uid)
            if len(safety) > MAX_FILE:
                raise BackupError("بياناتك الحالية كبيرة جدًا لحفظ نسخة أمان قبل الاستعادة. نزّلي نسخة احتياطية منها أولًا، ثم تواصلي معنا")
            purge(conn, uid)
            rs = Restorer(conn, uid, zf, manifest, caps, keep)
            report = rs.run()
            conn.execute("INSERT INTO user_backups(user_id, data, summary, created_at) VALUES (?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET data = excluded.data, summary = excluded.summary, "
                         "created_at = excluded.created_at", (uid, safety, json.dumps(summary["counts"]), time.time()))
            conn.execute("COMMIT")
            committed = True
        except BaseException:
            if not committed:
                try:
                    conn.execute("ROLLBACK")
                except sqlite3.Error:
                    pass
            raise
        finally:
            conn.close()
        forget_files(app, old_files - rs.reused)          # the originals of what is no longer hers (after the commit, like deleting a lesson)
        return report
    finally:
        with _running_lock:
            _running.pop(uid, None)


def forget_files(app, names):
    for name in names:
        if name and SAFE_FILE.match(name):
            try:
                (app.cfg.upload_dir / name).unlink()
            except OSError:
                pass


def read_current(app, uid) -> dict:
    """What she has now and what a restore would keep for her, read in a snapshot of its own."""
    conn = connect(app.cfg.db_path)
    try:
        conn.execute("BEGIN")
        return counts_of(conn, uid)
    finally:
        conn.close()


def safety_of(app, uid):
    row = app.db.execute("SELECT summary, created_at, LENGTH(data) AS size FROM user_backups WHERE user_id = ?", (uid,)).fetchone()
    if not row:
        return None
    try:
        counts = json.loads(row["summary"])
    except ValueError:
        counts = {}
    return {"created_at": row["created_at"], "created_text": when_text(row["created_at"]), "counts": counts, "size": row["size"]}


def when_text(ts) -> str:
    d = datetime.fromtimestamp(ts, billing.RIYADH)
    return f"{billing.ar_day(ts)} الساعة {d.strftime('%H:%M')}"


def notes_for(report, caps) -> list:
    out = []
    gone = report["left_out"]
    if gone.get("lessons"):
        out.append(f"باقتك الحالية تحفظ {caps['lessons']} من الدروس المرفوعة، فستُستعاد أحدث {caps['lessons']} فقط ويبقى {gone['lessons']} في ملف النسخة لتستعيديها بعد ترقية الباقة.")
    if gone.get("decks"):
        out.append(f"باقتك الحالية تحفظ {caps['decks']} من العروض، فستُستعاد أحدث {caps['decks']} فقط ويبقى {gone['decks']} في ملف النسخة.")
    return out


def view(report, caps, manifest) -> dict:
    counts = {t: report["counts"].get(t, 0) for t in ("classes", "students", "subjects", "books", "book_lessons", "lessons", "questions", "points", "results", "assignments", "exams",
                                                    "term_archives", "plan_items", "terms")}
    counts["decks"] = report["manual_decks"]
    return {"counts": counts, "left_out": report["left_out"], "notes": notes_for(report, caps), "created_at": manifest.get("created_at") or 0,
            "created_text": when_text(manifest["created_at"]) if manifest.get("created_at") else ""}


# ---------------------------------------------------------------- routes
def read_upload():
    f = request.files.get("file")
    if not f or not f.filename:
        raise BackupError("اختاري ملف النسخة الاحتياطية أولًا")
    raw = f.read(MAX_FILE + 1)
    if len(raw) > MAX_FILE:
        raise BackupError(f"الملف أكبر من المسموح ({MAX_FILE_MB} ميجابايت)")
    return raw


@bp.get("/backup")
@login_required
def page():
    return render_template("backup.html", max_mb=MAX_FILE_MB)


@bp.get("/api/backup")
@login_required
def status():
    uid = g.user["id"]
    return jsonify(current=read_current(current_app, uid), safety=safety_of(current_app, uid), max_mb=MAX_FILE_MB)


@bp.get("/api/backup/download")
@login_required
def download():
    uid = g.user["id"]
    if not download_limit.allow(uid):
        return jsonify(error="نزّلتِ نسخًا كثيرة خلال ساعة، جرّبي بعد قليل"), 429
    conn = connect(current_app.cfg.db_path)
    try:
        conn.execute("BEGIN")
        data, _ = export_zip(conn, uid)
    except Exception:
        log.exception("making a backup failed")
        return jsonify(error="تعذّر تجهيز النسخة، جرّبي مرة أخرى"), 500
    finally:
        conn.close()
    name = f"lessonplay-backup-{classroom.today_date().isoformat()}.zip"
    return Response(data, mimetype="application/zip", headers={"Content-Disposition": f'attachment; filename="{name}"', "Content-Length": str(len(data)), "Cache-Control": "no-store"})


@bp.post("/api/backup/preview")
@login_required
def preview():
    uid = g.user["id"]
    if not preview_limit.allow(uid):
        return jsonify(error="جرّبتِ ملفات كثيرة خلال ساعة، انتظري قليلًا"), 429
    try:
        raw = read_upload()
        caps = caps_for(current_app.db, g.user)
        report, manifest = trial(raw, caps)
    except BackupError as exc:
        if exc.detail:
            log.info("backup file refused: %s", exc.detail)
        return jsonify(error=exc.message), 400
    return jsonify(file=view(report, caps, manifest), current=read_current(current_app, uid), safety=safety_of(current_app, uid))


@bp.post("/api/backup/restore")
@login_required
def restore_route():
    uid = g.user["id"]
    if request.form.get("confirm") != "yes":
        return jsonify(error="أكّدي أولًا أنك تريدين استبدال بياناتك الحالية بمحتوى النسخة"), 400
    if not restore_limit.allow(uid):
        return jsonify(error="محاولات كثيرة، انتظري قليلًا"), 429
    try:
        raw = read_upload()
        caps = caps_for(current_app.db, g.user)
        report = restore(current_app, uid, raw, caps)
    except BackupError as exc:
        if exc.detail:
            log.info("backup file refused: %s", exc.detail)
        return jsonify(error=exc.message), 400
    except Exception:
        log.exception("restoring a backup failed")
        return jsonify(error="تعذّرت الاستعادة ولم يتغير شيء في حسابك. جرّبي مرة أخرى"), 500
    manifest = {"created_at": 0}
    return jsonify(ok=True, file=view(report, caps, manifest), safety=safety_of(current_app, uid))


@bp.post("/api/backup/undo")
@login_required
def undo():
    """Go back to what she had just before the last restore (the safety copy), which keeps what she had just before this in its place."""
    uid = g.user["id"]
    if body().get("confirm") is not True:
        return jsonify(error="أكّدي أولًا أنك تريدين الرجوع إلى حسابك قبل الاستعادة"), 400
    row = current_app.db.execute("SELECT data FROM user_backups WHERE user_id = ?", (uid,)).fetchone()
    if not row:
        return jsonify(error="لا توجد نسخة أمان لحسابك"), 404
    if not restore_limit.allow(uid):
        return jsonify(error="محاولات كثيرة، انتظري قليلًا"), 429
    try:
        report = restore(current_app, uid, bytes(row["data"]), {})          # her own data of a moment ago: no limit applies
    except BackupError as exc:
        if exc.detail:
            log.warning("the safety copy was refused: %s", exc.detail)
        return jsonify(error=exc.message), 400
    except Exception:
        log.exception("going back to the safety copy failed")
        return jsonify(error="تعذّر الرجوع ولم يتغير شيء في حسابك. جرّبي مرة أخرى"), 500
    return jsonify(ok=True, file=view(report, {}, {"created_at": 0}), safety=safety_of(current_app, uid))
