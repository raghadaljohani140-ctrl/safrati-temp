"""The questions of a formal exam: what a lesson's text can give, how many of each kind an exam takes, and what is kept as spares.

The questions of a lesson (aiq.py) are picked so that nothing is asked twice and a short lesson gives few. An exam is different: the teacher says how many questions of
each kind she wants, from which lessons, so the whole pool of a lesson is built first (`pool_of`), the exam takes from it (`allocate`) what its sections need, and everything
else stays as spares to replace a question with. A sentence of the book is asked ONCE in an exam, whatever the kind, and two questions that read alike are never both in it.
Nothing here touches the database; exams.py stores the result."""
import random

from . import aiq, grounding as G

KINDS = ("mcq", "tf", "cloze", "qa", "short", "essay")          # also the order of the sections on the paper
NAMES = {"mcq": "اختيار من متعدد", "tf": "صح أو خطأ", "cloze": "أكمل الفراغ", "qa": "سؤال وجواب", "short": "أكمل الجملة", "essay": "مقالي"}
DEFAULT_MARKS = {"mcq": 1, "tf": 1, "cloze": 1, "qa": 2, "short": 2, "essay": 4}          # what a question of each kind is worth when she has not said
DEFAULT_COUNTS = {"mcq": 5, "tf": 5, "cloze": 3, "qa": 2, "short": 0, "essay": 1}
MAX_PER_KIND = 40
MAX_QUESTIONS = 100
MAX_SPARES = 400
SPARES_PER_KIND = 80
MAX_TEXT = 30000          # characters of one lesson that are read for an exam
MARK_STEP = 0.5


# ---------------------------------------------------------------- the pool of one lesson
def essay_candidates(text: str) -> list[dict]:
    """Open questions the text answers: «اشرحي المقصود بـ» for a definition and «علّلي» for a statement with its reason. The model answer is the sentence itself."""
    sents = [st for st in map(aiq.standalone, aiq.split_sentences(text)) if st]
    out = []
    for s in sents:
        m = aiq.DEF_RE.match(s) or aiq.COLON_RE.match(s)
        if m and len(m["term"].split()) <= 4:
            out.append(dict(kind="essay", question=f"اشرحي المقصود بـ «{m['term'].strip()}» موضّحةً ما تعرفينه عنه.", answer=m["def"].strip(), evidence=s))
    for s in sents:
        m = aiq.CAUSE_RE.search(s)
        if m and len(s[:m.start()].split()) >= 3 and len(s[m.end():].split()) >= 2:
            out.append(dict(kind="essay", question=f"علّلي: {s[:m.start()].strip()}.", answer=(m.group(1) + " " + s[m.end():]).strip(), evidence=s))
    return out


def pool_of(text: str, rng=None) -> dict:
    """{kind: [question, ...]} for every kind of an exam, from one lesson's text. Each question carries `evidence` (the sentence of the text it comes from) and
    `clear` (1 when the text backs the answer). «سؤال مراجعة» of the lessons is the open question of an exam."""
    text = (text or "")[:MAX_TEXT]
    raw = aiq.OfflineProvider().candidates(text, rng or random.Random(7))
    by_kind = {k: list(raw.get(k, [])) for k in ("mcq", "tf", "cloze", "qa", "short")}
    by_kind["essay"] = essay_candidates(text) + [{**q, "kind": "essay"} for q in raw.get("review", [])]          # «اشرحي» and «علّلي» first, «اذكري ما تعرفينه» after them
    pool = {}
    for kind, items in by_kind.items():          # cleaned one kind at a time: a blank sentence is both a cloze and a multiple choice, and an exam may need either
        pool[kind] = [q for q in aiq.clean_items(items, text, True) if q["kind"] == kind]
    return {k: pool.get(k, []) for k in KINDS}


# ---------------------------------------------------------------- what an exam takes from the pools
def similar(a: str, b: str) -> bool:
    """Two questions that read alike (the same sentence asked in another way is not a different question)."""
    return aiq._similar(a, b)


def _free(q: dict, used_evidence: set, used_text: list) -> bool:
    """A question may join the exam when its sentence is not asked yet and no question that reads like it is there."""
    ev = G.norm(q.get("evidence") or "")
    if ev and ev in used_evidence:
        return False
    return not any(similar(q["question"], t) for t in used_text)


def allocate(sources: list, wanted: dict):
    """`sources` is [(label, pool)] in the order of the book, `wanted` is {kind: how many}. Returns (chosen, spares, short):
    chosen  the exam's questions in the order of the paper (the sections in order, and inside a section the lessons in the order of the book), each with its `source`;
    spares  every other question the pools hold, kept for replacing one (at most SPARES_PER_KIND of a kind, MAX_SPARES in all);
    short   {kind: how many are missing} where the lessons could not give what she asked for.
    The kind with the fewest candidates chooses first, and each kind takes from the lessons in turn, so one long lesson does not fill the whole exam."""
    used_ev: set = set()
    used_text: list = []
    taken: set = set()
    picked: dict = {k: [] for k in KINDS}
    order = sorted((k for k in KINDS if wanted.get(k)), key=lambda k: (sum(len(p.get(k, [])) for _, p in sources), KINDS.index(k)))
    for kind in order:
        want = max(0, min(int(wanted[kind]), MAX_PER_KIND))
        lists = [sorted(enumerate(p.get(kind, [])), key=lambda t: (not t[1].get("clear", 1), t[0])) for _, p in sources]          # the questions the text backs come first
        cursor = [0] * len(sources)
        progress = True
        while len(picked[kind]) < want and progress:
            progress = False
            for si, lst in enumerate(lists):
                if len(picked[kind]) >= want:
                    break
                while cursor[si] < len(lst):
                    idx, q = lst[cursor[si]]
                    cursor[si] += 1
                    if _free(q, used_ev, used_text):
                        used_ev.add(G.norm(q.get("evidence") or ""))
                        used_text.append(q["question"])
                        taken.add((si, kind, idx))
                        picked[kind].append((si, idx, {**q, "source": sources[si][0]}))
                        progress = True
                        break
    chosen = []
    for kind in KINDS:
        chosen.extend(q for _, _, q in sorted(picked[kind], key=lambda t: (t[0], t[1])))
    spares, per_kind = [], {k: 0 for k in KINDS}
    for si, (label, pool) in enumerate(sources):
        for kind in KINDS:
            for idx, q in enumerate(pool.get(kind, [])):
                if (si, kind, idx) in taken or per_kind[kind] >= SPARES_PER_KIND or len(spares) >= MAX_SPARES:
                    continue
                per_kind[kind] += 1
                spares.append({**q, "source": label})
    short = {k: int(wanted[k]) - len(picked[k]) for k in KINDS if wanted.get(k) and int(wanted[k]) > len(picked[k])}
    return chosen, spares, short


def next_spare(spares: list, used: list):
    """The first spare that can take a place in the exam as it stands now (its sentence not asked, nothing like it there), or None.
    `spares` and `used` are question dicts; the order of `spares` is the order they will be offered in."""
    ev = {G.norm(q.get("evidence") or "") for q in used if q.get("evidence")}
    texts = [q["question"] for q in used]
    return next((q for q in spares if _free(q, ev, texts)), None)


def spares_left(spares: list, used: list) -> int:
    """How many questions of this kind could still be swapped in one after the other: each one taken is counted against the next (two spares from one
    sentence are one alternative, not two)."""
    ev = {G.norm(q.get("evidence") or "") for q in used if q.get("evidence")}
    texts = [q["question"] for q in used]
    n = 0
    for q in spares:
        if _free(q, ev, texts):
            n += 1
            if q.get("evidence"):
                ev.add(G.norm(q["evidence"]))
            texts.append(q["question"])
    return n


# ---------------------------------------------------------------- marks
def fmt_marks(x) -> str:
    """1 → «1», 1.5 → «1.5»."""
    x = float(x or 0)
    return str(int(x)) if x == int(x) else f"{x:g}"


def clean_marks(value, default=1.0):
    """A question's marks: half a mark to 50, in steps of half a mark. None when it is not a number in that range."""
    try:
        x = float(value)
    except (TypeError, ValueError):
        return None
    if x != x or x < MARK_STEP or x > 50:
        return None
    return round(x * 2) / 2


def distribute(total, kinds: list):
    """Marks for questions of these kinds that add up to exactly `total` (a multiple of half a mark). Questions of one kind are worth the same, and a kind is worth more
    or less by its weight (DEFAULT_MARKS); only when the total cannot be shared evenly does one question or two differ by half a mark. None when the total cannot be
    shared at all (fewer half marks than questions)."""
    try:
        units = int(round(float(total) * 2))
    except (TypeError, ValueError):
        return None
    n = len(kinds)
    if n == 0 or units < n or units > 2000:
        return None
    counts = {k: kinds.count(k) for k in KINDS if k in kinds}
    sw = sum(DEFAULT_MARKS[k] * c for k, c in counts.items())
    unit = {k: max(1, round(units * DEFAULT_MARKS[k] / sw)) for k in counts}          # half marks a question of the kind gets
    diff = units - sum(c * unit[k] for k, c in counts.items())
    while diff:
        step = 1 if diff > 0 else -1
        fits = [k for k in counts if counts[k] <= abs(diff) and (step > 0 or unit[k] > 1)]
        if not fits:
            break
        k = max(fits, key=lambda k: (unit[k], DEFAULT_MARKS[k]))          # the change that is smallest next to what the question is worth
        unit[k] += step
        diff -= step * counts[k]
    marks = [unit[k] for k in kinds]
    if diff:                                                          # less than any kind's count is left: a few single questions differ by half a mark
        step = 1 if diff > 0 else -1
        for i in sorted(range(n), key=lambda i: (-marks[i], i)):
            if not diff:
                break
            if step > 0 or marks[i] > 1:
                marks[i] += step
                diff -= step
        if diff:
            return None
    return [m / 2 for m in marks]


def letters(n: int) -> list[str]:
    return list("أبجدهوزح")[:n]
