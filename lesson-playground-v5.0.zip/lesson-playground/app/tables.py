"""Reading a list or a table out of a file the teacher already has: Excel (.xlsx), Word (.docx), CSV and plain text.

No library is needed: an .xlsx and a .docx are zip files of XML, and this reads only the few parts that hold the text. Every limit below exists because the
file comes from outside: a zip may claim to be small and unpack to gigabytes, and XML may carry entities that grow. Nothing here ever writes a file or opens
a link; it only returns text.

What comes back is always the same shape, so the rest of the app does not care where a list came from:
    sheets  = [{"name": "الصف الأول", "rows": [["1", "أحمد"], ["2", "سارة"]]}, ...]          (read_sheets)
    blocks  = [("p", "text", heading_level, bold), ("table", rows), ...]                 (read_docx, for a book)
"""
import csv
import io
import posixpath
import re
import zipfile
from xml.etree import ElementTree as ET

MAX_PART = 40 * 1024 * 1024       # the most one XML part may hold once unpacked (a big book as .docx can be many megabytes of XML)
MAX_ROWS = 20000
MAX_COLS = 60
MAX_SHEETS = 40
MAX_CELL = 600
MAX_BLOCKS = 200000
OLD_OFFICE = b"\xd0\xcf\x11\xe0"   # .xls / .doc of the old Office: not readable without a library

_M = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
_R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
_PKG_REL = "{http://schemas.openxmlformats.org/package/2006/relationships}"


class TableError(Exception):
    """A message the teacher can read."""


BAD_ZIP = "تعذرت قراءة الملف، قد يكون تالفًا أو ليس بالصيغة التي ينتهي بها اسمه"
OLD_MSG = "هذه صيغة Office القديمة (xls أو doc). احفظيه من Excel أو Word بصيغة xlsx أو docx، أو ارفعيه PDF أو صورة"


def kind_of(filename: str, head: bytes) -> str:
    """xlsx, docx, csv, txt, pdf or image by the extension AND the first bytes; anything else is refused with a sentence the teacher understands."""
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if head[:4] == OLD_OFFICE:
        raise TableError(OLD_MSG)
    if ext in ("xlsx", "xlsm") and head[:4] == b"PK\x03\x04":
        return "xlsx"
    if ext == "docx" and head[:4] == b"PK\x03\x04":
        return "docx"
    if ext == "pdf" and head[:5] == b"%PDF-":
        return "pdf"
    if ext in ("jpg", "jpeg", "png") and (head[:3] == b"\xff\xd8\xff" or head[:8] == b"\x89PNG\r\n\x1a\n"):
        return "image"
    if ext in ("csv", "tsv", "txt") and b"\x00" not in head:
        return "csv" if ext in ("csv", "tsv") else "txt"
    raise TableError("نوع الملف غير مدعوم. ارفعي Excel (xlsx) أو Word (docx) أو CSV أو نصًا أو PDF أو صورة")


# ---------------------------------------------------------------- the zip and its XML
def _open_zip(data: bytes):
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except (zipfile.BadZipFile, ValueError, OSError):
        raise TableError(BAD_ZIP)
    if len(zf.infolist()) > 5000:
        raise TableError(BAD_ZIP)
    return zf


def _part(zf, name: str, limit: int = MAX_PART):
    """The bytes of one part of the zip, or None when it is not there. The size is checked both as the zip declares it and as it really unpacks."""
    try:
        info = zf.getinfo(name)
    except KeyError:
        return None
    if info.file_size > limit:
        raise TableError("الملف كبير جدًا بعد فك ضغطه")
    try:
        with zf.open(info) as fh:
            raw = fh.read(limit + 1)
    except (zipfile.BadZipFile, RuntimeError, OSError, ValueError):
        raise TableError(BAD_ZIP)            # a password-protected or damaged part
    if len(raw) > limit:
        raise TableError("الملف كبير جدًا بعد فك ضغطه")
    if b"<!ENTITY" in raw or b"<!DOCTYPE" in raw:
        raise TableError("الملف يحوي محتوى غير مقبول")           # Office files never carry a DTD; a file that does is trying something
    return raw


def _parse(raw: bytes):
    try:
        return ET.fromstring(raw)
    except ET.ParseError:
        raise TableError(BAD_ZIP)


def _local(tag) -> str:
    return tag.rsplit("}", 1)[-1] if isinstance(tag, str) else ""


# ---------------------------------------------------------------- Excel
def _col(ref: str) -> int:
    n = 0
    for ch in ref:
        if "A" <= ch <= "Z":
            n = n * 26 + ord(ch) - 64
        elif "a" <= ch <= "z":
            n = n * 26 + ord(ch) - 96
        else:
            break
    return n - 1


def _shared_strings(zf):
    raw = _part(zf, "xl/sharedStrings.xml")
    if raw is None:
        return []
    out = []
    for ev, el in ET.iterparse(io.BytesIO(raw), events=("end",)):
        if el.tag == _M + "si":
            out.append("".join((t.text or "") for t in _text_nodes(el)))
            el.clear()
            if len(out) > 400000:
                break
    return out


def _text_nodes(el):
    """The <t> nodes of a shared string or an inline string, without the phonetic guide (rPh) that East-Asian files carry."""
    for child in el:
        if child.tag == _M + "t":
            yield child
        elif child.tag == _M + "r":
            for t in child:
                if t.tag == _M + "t":
                    yield t
        elif child.tag == _M + "is":
            yield from _text_nodes(child)


def _number(text: str) -> str:
    text = (text or "").strip()
    try:
        f = float(text)
    except ValueError:
        return text
    if f == int(f) and abs(f) < 1e15:
        return str(int(f))
    return repr(f)


def _cell(c, shared) -> str:
    t = c.get("t")
    v = c.find(_M + "v")
    if t == "inlineStr":
        return "".join((x.text or "") for x in _text_nodes(c)).strip()
    if v is None or v.text is None:
        return ""
    if t == "s":
        try:
            return shared[int(v.text)].strip()
        except (ValueError, IndexError):
            return ""
    if t == "b":
        return "1" if v.text.strip() == "1" else "0"
    if t in ("str", "e"):
        return v.text.strip()
    return _number(v.text)


def _sheet_rows(raw: bytes, shared):
    rows = []
    for ev, el in ET.iterparse(io.BytesIO(raw), events=("end",)):
        if el.tag != _M + "row":
            continue
        cells = {}
        for c in el:
            if c.tag == _M + "c":
                ref = c.get("r") or ""
                idx = _col(ref) if ref else len(cells)
                if 0 <= idx < MAX_COLS:
                    value = _cell(c, shared)
                    if value:
                        cells[idx] = value[:MAX_CELL]
        rows.append([cells.get(i, "") for i in range(max(cells) + 1)] if cells else [])
        el.clear()
        if len(rows) >= MAX_ROWS:
            break
    while rows and not rows[-1]:
        rows.pop()
    return rows


def read_xlsx(data: bytes):
    """[{"name", "rows"}] for every visible sheet that holds something."""
    zf = _open_zip(data)
    wb_raw = _part(zf, "xl/workbook.xml")
    if wb_raw is None:
        raise TableError(BAD_ZIP)
    wb = _parse(wb_raw)
    rels = {}
    rel_raw = _part(zf, "xl/_rels/workbook.xml.rels")
    if rel_raw is not None:
        for r in _parse(rel_raw).iter(_PKG_REL + "Relationship"):
            rels[r.get("Id")] = r.get("Target") or ""
    shared = _shared_strings(zf)
    out = []
    sheets = wb.find(_M + "sheets")
    for s in (list(sheets) if sheets is not None else [])[:MAX_SHEETS]:
        if s.get("state") in ("hidden", "veryHidden"):
            continue
        target = rels.get(s.get(_R + "id"), "")
        if not target:
            continue
        path = target[1:] if target.startswith("/") else posixpath.normpath(posixpath.join("xl", target))
        raw = _part(zf, path)
        if raw is None:
            continue
        rows = _sheet_rows(raw, shared)
        if any(any(c for c in r) for r in rows):
            out.append({"name": (s.get("name") or "").strip(), "rows": rows})
    return out


# ---------------------------------------------------------------- Word
_HEADING = re.compile(r"^(?:heading|عنوان)\s*(\d)$", re.I)


def _style_levels(zf) -> dict:
    """styleId -> the heading level the style stands for (1 is the biggest), read from styles.xml; 0 for a style that is not a heading."""
    raw = _part(zf, "word/styles.xml")
    levels = {}
    if raw is None:
        return levels
    for st in _parse(raw).iter(_W + "style"):
        sid = st.get(_W + "styleId")
        name = st.find(_W + "name")
        name = (name.get(_W + "val") if name is not None else "") or ""
        lvl = 0
        m = _HEADING.match(name.strip())
        if m:
            lvl = int(m.group(1))
        elif name.strip().lower() == "title":
            lvl = 1
        else:
            ppr = st.find(_W + "pPr")
            ol = ppr.find(_W + "outlineLvl") if ppr is not None else None
            if ol is not None and (ol.get(_W + "val") or "").isdigit() and int(ol.get(_W + "val")) < 9:
                lvl = int(ol.get(_W + "val")) + 1
        if sid:
            levels[sid] = lvl
    return levels


def _para(p, levels) -> tuple:
    """(text, heading level, bold) of one paragraph. The text keeps the line breaks the writer typed inside the paragraph."""
    parts = []
    bold = None
    for node in p.iter():
        tag = node.tag
        if tag == _W + "t":
            if node.text:
                parts.append(node.text)
        elif tag == _W + "tab":
            parts.append("\t")
        elif tag in (_W + "br", _W + "cr"):
            if node.get(_W + "type") != "page":
                parts.append("\n")
        elif tag == _W + "noBreakHyphen":
            parts.append("-")
        elif tag == _W + "r" and bold is None:
            rpr = node.find(_W + "rPr")
            has_text = any(x.tag == _W + "t" and (x.text or "").strip() for x in node)
            if has_text:
                b = rpr.find(_W + "b") if rpr is not None else None
                bold = b is not None and (b.get(_W + "val") or "1") not in ("0", "false")
    level = 0
    ppr = p.find(_W + "pPr")
    if ppr is not None:
        ol = ppr.find(_W + "outlineLvl")
        ps = ppr.find(_W + "pStyle")
        if ol is not None and (ol.get(_W + "val") or "").isdigit() and int(ol.get(_W + "val")) < 9:
            level = int(ol.get(_W + "val")) + 1
        elif ps is not None:
            level = levels.get(ps.get(_W + "val"), 0)
    text = "".join(parts)
    text = re.sub(r"[ \t]+", " ", text).strip()
    return text, level, bool(bold)


def read_docx(data: bytes):
    """Blocks in reading order: ("p", text, heading_level, bold) for a paragraph and ("table", rows) for a table. Paragraphs of nested tables are skipped."""
    zf = _open_zip(data)
    raw = _part(zf, "word/document.xml")
    if raw is None:
        raise TableError(BAD_ZIP)
    levels = _style_levels(zf)
    blocks = []
    depth = 0
    table = row = cell = None
    try:
        for ev, el in ET.iterparse(io.BytesIO(raw), events=("start", "end")):
            tag = el.tag
            if ev == "start":
                if tag == _W + "tbl":
                    depth += 1
                    if depth == 1:
                        table = []
                elif tag == _W + "tr" and depth == 1:
                    row = []
                elif tag == _W + "tc" and depth == 1:
                    cell = []
                continue
            if tag == _W + "p":
                text, level, bold = _para(el, levels)
                if depth == 0:
                    if text:
                        blocks.append(("p", text, level, bold))
                elif depth == 1 and cell is not None and text:
                    cell.append(text)
                el.clear()
            elif tag == _W + "tc" and depth == 1:
                row.append(" ".join(cell).strip()[:MAX_CELL])
                cell = None
            elif tag == _W + "tr" and depth == 1:
                if any(row):
                    table.append(row[:MAX_COLS])
                row = None
            elif tag == _W + "tbl":
                if depth == 1 and table:
                    blocks.append(("table", table[:MAX_ROWS]))
                depth -= 1
            if len(blocks) > MAX_BLOCKS:
                break
    except ET.ParseError:
        raise TableError(BAD_ZIP)
    return blocks


def docx_sheets(blocks):
    """The same blocks as sheets: every table is a sheet named by the short line written just above it, and the loose lines are one sheet of single cells."""
    sheets, loose, label = [], [], ""
    for b in blocks:
        if b[0] == "p":
            for line in b[1].split("\n"):
                line = line.strip()
                if line:
                    loose.append([line])
                    label = line if len(line) <= 60 else ""
        else:
            sheets.append({"name": label, "rows": b[1]})
            label = ""
    if loose:
        sheets.append({"name": "", "rows": loose})
    return sheets


def docx_text(blocks) -> str:
    out = []
    for b in blocks:
        if b[0] == "p":
            out.append(b[1])
        else:
            out.extend(" | ".join(c for c in r if c) for r in b[1])
    return "\n".join(out)


# ---------------------------------------------------------------- CSV and text
def decode_text(data: bytes) -> str:
    for enc in ("utf-8-sig", "utf-16", "cp1256"):
        if enc == "utf-16" and data[:2] not in (b"\xff\xfe", b"\xfe\xff"):
            continue
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("latin-1")


def read_csv(data: bytes):
    text = decode_text(data[:20 * 1024 * 1024])
    sample = text[:4096]
    delim = max(",;\t|", key=lambda d: sample.count(d)) if any(d in sample for d in ",;\t|") else ","
    csv.field_size_limit(1 << 20)
    rows = []
    for rec in csv.reader(io.StringIO(text), delimiter=delim):
        rows.append([c.strip()[:MAX_CELL] for c in rec[:MAX_COLS]])
        if len(rows) >= MAX_ROWS:
            break
    while rows and not any(rows[-1]):
        rows.pop()
    return [{"name": "", "rows": rows}] if rows else []


def read_text(data: bytes):
    lines = [[ln.strip()[:MAX_CELL]] for ln in decode_text(data[:20 * 1024 * 1024]).splitlines()[:MAX_ROWS]]
    return [{"name": "", "rows": lines}] if any(c[0] for c in lines) else []


def read_sheets(kind: str, data: bytes):
    """Sheets from a file that is already a table or a list (xlsx, docx, csv, txt)."""
    if kind == "xlsx":
        return read_xlsx(data)
    if kind == "docx":
        return docx_sheets(read_docx(data))
    if kind == "csv":
        return read_csv(data)
    if kind == "txt":
        return read_text(data)
    raise TableError("نوع الملف غير مدعوم")


def sheets_from_text(text: str):
    """A reader of PDFs and pictures gives plain text: its lines are one sheet of single cells."""
    lines = [[ln.strip()[:MAX_CELL]] for ln in text.splitlines()[:MAX_ROWS]]
    return [{"name": "", "rows": lines}] if any(c[0] for c in lines) else []
