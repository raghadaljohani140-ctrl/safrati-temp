import json
import sqlite3
import threading
import time

SCHEMA = """
CREATE TABLE IF NOT EXISTS plans(
  code TEXT PRIMARY KEY, name TEXT NOT NULL, max_lessons INTEGER NOT NULL, max_decks INTEGER NOT NULL,
  price_month INTEGER NOT NULL DEFAULT 0, price_year INTEGER NOT NULL DEFAULT 0, purchasable INTEGER NOT NULL DEFAULT 0,
  ai_quota INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, email TEXT NOT NULL UNIQUE, name TEXT NOT NULL, pass_hash TEXT NOT NULL,
  plan_code TEXT NOT NULL DEFAULT 'free' REFERENCES plans(code),
  ai_consent INTEGER NOT NULL DEFAULT 0, created_at REAL NOT NULL, plan_expires REAL NOT NULL DEFAULT 0, is_admin INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS lessons(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL, original_name TEXT NOT NULL, stored_name TEXT NOT NULL, kind TEXT NOT NULL,
  text TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'processing', error TEXT NOT NULL DEFAULT '',
  engine TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL, updated_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS lessons_user ON lessons(user_id);
CREATE TABLE IF NOT EXISTS questions(
  id INTEGER PRIMARY KEY, lesson_id INTEGER NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('qa','mcq','tf','cloze','short','review')),
  question TEXT NOT NULL, answer TEXT NOT NULL DEFAULT '', options TEXT NOT NULL DEFAULT '[]',
  evidence TEXT NOT NULL DEFAULT '', clear INTEGER NOT NULL DEFAULT 1, manual INTEGER NOT NULL DEFAULT 0,
  position INTEGER NOT NULL DEFAULT 0, created_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS questions_lesson ON questions(lesson_id);
CREATE TABLE IF NOT EXISTS decks(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  lesson_id INTEGER NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  title TEXT NOT NULL, games TEXT NOT NULL DEFAULT '[]', question_ids TEXT NOT NULL DEFAULT '[]',
  created_at REAL NOT NULL, updated_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS decks_user ON decks(user_id);
CREATE TABLE IF NOT EXISTS classes(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL, created_at REAL NOT NULL, UNIQUE(user_id, name));
CREATE TABLE IF NOT EXISTS students(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  class_id INTEGER REFERENCES classes(id) ON DELETE CASCADE,
  name TEXT NOT NULL, created_at REAL NOT NULL, UNIQUE(class_id, name));
CREATE TABLE IF NOT EXISTS results(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  deck_id INTEGER REFERENCES decks(id) ON DELETE SET NULL, deck_title TEXT NOT NULL DEFAULT '',
  question_id INTEGER, question TEXT NOT NULL DEFAULT '', game TEXT NOT NULL DEFAULT '', kind TEXT NOT NULL DEFAULT '',
  correct INTEGER NOT NULL CHECK (correct IN (0,1)), run TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL,
  UNIQUE(student_id, deck_id, question_id, run));
CREATE INDEX IF NOT EXISTS results_student ON results(student_id);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS subscription_requests(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan_code TEXT NOT NULL REFERENCES plans(code), period TEXT NOT NULL CHECK (period IN ('month','year')),
  amount INTEGER NOT NULL, ref_code TEXT NOT NULL DEFAULT '', payer_name TEXT NOT NULL DEFAULT '', transfer_date TEXT NOT NULL DEFAULT '',
  receipt TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','confirmed','rejected')),
  note TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL, decided_at REAL NOT NULL DEFAULT 0, starts_at REAL NOT NULL DEFAULT 0, ends_at REAL NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS subreq_user ON subscription_requests(user_id);
CREATE TABLE IF NOT EXISTS ai_usage(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, lesson_id INTEGER, model TEXT NOT NULL,
  input_tokens INTEGER NOT NULL, output_tokens INTEGER NOT NULL, cost INTEGER NOT NULL, created_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS aiusage_user ON ai_usage(user_id, created_at);
CREATE TABLE IF NOT EXISTS expenses(
  id INTEGER PRIMARY KEY, kind TEXT NOT NULL CHECK (kind IN ('fixed','variable')), title TEXT NOT NULL, amount INTEGER NOT NULL,
  month TEXT NOT NULL, ended_month TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL);
CREATE TABLE IF NOT EXISTS plan_events(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, kind TEXT NOT NULL CHECK (kind IN ('extend','grant','stop')),
  plan_code TEXT NOT NULL DEFAULT '', days INTEGER NOT NULL DEFAULT 0, note TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS planevents_user ON plan_events(user_id);
CREATE TABLE IF NOT EXISTS lesson_usage(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  lesson_id INTEGER, file_key TEXT NOT NULL, used_at REAL NOT NULL, UNIQUE(user_id, file_key));
CREATE INDEX IF NOT EXISTS lessonusage_user ON lesson_usage(user_id, used_at);
CREATE TABLE IF NOT EXISTS subjects(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL, created_at REAL NOT NULL, UNIQUE(user_id, name));
CREATE TABLE IF NOT EXISTS class_subjects(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  created_at REAL NOT NULL, UNIQUE(class_id, subject_id));
CREATE INDEX IF NOT EXISTS classsubjects_user ON class_subjects(user_id);
CREATE TABLE IF NOT EXISTS terms(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL, starts TEXT NOT NULL, ends TEXT NOT NULL, archived INTEGER NOT NULL DEFAULT 0, created_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS terms_user ON terms(user_id);
CREATE TABLE IF NOT EXISTS calendar_days(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  term_id INTEGER NOT NULL REFERENCES terms(id) ON DELETE CASCADE, day TEXT NOT NULL, label TEXT NOT NULL DEFAULT '', UNIQUE(term_id, day));
CREATE TABLE IF NOT EXISTS books(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL, subject TEXT NOT NULL DEFAULT '', grade TEXT NOT NULL DEFAULT '',
  original_name TEXT NOT NULL DEFAULT '', stored_name TEXT NOT NULL DEFAULT '', kind TEXT NOT NULL DEFAULT 'manual',
  pages INTEGER NOT NULL DEFAULT 0, progress INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'processing', error TEXT NOT NULL DEFAULT '', warn TEXT NOT NULL DEFAULT '', confirmed INTEGER NOT NULL DEFAULT 0,
  created_at REAL NOT NULL, updated_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS books_user ON books(user_id);
CREATE TABLE IF NOT EXISTS book_units(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE, title TEXT NOT NULL, position INTEGER NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS bookunits_book ON book_units(book_id);
CREATE TABLE IF NOT EXISTS book_lessons(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE, unit_id INTEGER REFERENCES book_units(id) ON DELETE SET NULL,
  title TEXT NOT NULL, position INTEGER NOT NULL DEFAULT 0, first_page INTEGER NOT NULL DEFAULT 0, last_page INTEGER NOT NULL DEFAULT 0,
  periods INTEGER NOT NULL DEFAULT 1, kind TEXT NOT NULL DEFAULT 'lesson', text TEXT NOT NULL DEFAULT '');
CREATE INDEX IF NOT EXISTS booklessons_book ON book_lessons(book_id);
CREATE TABLE IF NOT EXISTS schedule_slots(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  day INTEGER NOT NULL CHECK (day BETWEEN 0 AND 6), period INTEGER NOT NULL CHECK (period BETWEEN 1 AND 12),
  class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE, subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  UNIQUE(user_id, day, period));
CREATE TABLE IF NOT EXISTS schedule_times(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  period INTEGER NOT NULL CHECK (period BETWEEN 1 AND 12), starts TEXT NOT NULL DEFAULT '', ends TEXT NOT NULL DEFAULT '', UNIQUE(user_id, period));
CREATE TABLE IF NOT EXISTS teacher_settings(user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, data TEXT NOT NULL DEFAULT '{}');
CREATE TABLE IF NOT EXISTS plan_items(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  term_id INTEGER NOT NULL REFERENCES terms(id) ON DELETE CASCADE,
  class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE, subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
  book_lesson_id INTEGER NOT NULL REFERENCES book_lessons(id) ON DELETE CASCADE,
  position INTEGER NOT NULL DEFAULT 0, periods INTEGER NOT NULL DEFAULT 1,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','done','skipped')), done_on TEXT NOT NULL DEFAULT '',
  due_date TEXT NOT NULL DEFAULT '', due_period INTEGER NOT NULL DEFAULT 0, lesson_id INTEGER REFERENCES lessons(id) ON DELETE SET NULL, note TEXT NOT NULL DEFAULT '',
  created_at REAL NOT NULL, updated_at REAL NOT NULL, UNIQUE(term_id, class_id, subject_id, book_lesson_id));
CREATE INDEX IF NOT EXISTS planitems_pair ON plan_items(user_id, class_id, subject_id);
CREATE TABLE IF NOT EXISTS plan_log(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  class_id INTEGER, subject_id INTEGER, term_id INTEGER, kind TEXT NOT NULL, text TEXT NOT NULL, created_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS planlog_user ON plan_log(user_id, created_at);
CREATE TABLE IF NOT EXISTS absences(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  day TEXT NOT NULL, period INTEGER NOT NULL DEFAULT 0 CHECK (period BETWEEN 0 AND 12), reason TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL,
  UNIQUE(user_id, day, period));
CREATE INDEX IF NOT EXISTS absences_user ON absences(user_id, day);
CREATE TABLE IF NOT EXISTS points(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE, student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL, day TEXT NOT NULL,
  amount INTEGER NOT NULL CHECK (amount BETWEEN -50 AND 50 AND amount != 0), source TEXT NOT NULL DEFAULT 'manual' CHECK (source IN ('game','manual')),
  game TEXT NOT NULL DEFAULT '', ref TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '', client_key TEXT NOT NULL DEFAULT '',
  created_at REAL NOT NULL, edited_at REAL NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS points_class ON points(user_id, class_id, day);
CREATE INDEX IF NOT EXISTS points_student ON points(student_id, day);
CREATE UNIQUE INDEX IF NOT EXISTS points_key ON points(user_id, client_key) WHERE client_key != '';
CREATE TABLE IF NOT EXISTS exams(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE, subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
  title TEXT NOT NULL, exam_date TEXT NOT NULL DEFAULT '', minutes INTEGER NOT NULL DEFAULT 0, total REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','approved')), sources TEXT NOT NULL DEFAULT '[]', wanted TEXT NOT NULL DEFAULT '{}',
  short TEXT NOT NULL DEFAULT '{}', header TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '',
  created_at REAL NOT NULL, updated_at REAL NOT NULL, approved_at REAL NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS exams_class ON exams(user_id, class_id);
CREATE TABLE IF NOT EXISTS exam_questions(
  id INTEGER PRIMARY KEY, exam_id INTEGER NOT NULL REFERENCES exams(id) ON DELETE CASCADE, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('mcq','tf','cloze','qa','short','essay')), question TEXT NOT NULL, answer TEXT NOT NULL DEFAULT '', options TEXT NOT NULL DEFAULT '[]',
  evidence TEXT NOT NULL DEFAULT '', source TEXT NOT NULL DEFAULT '', marks REAL NOT NULL DEFAULT 1, position INTEGER NOT NULL DEFAULT 0,
  state TEXT NOT NULL DEFAULT 'spare' CHECK (state IN ('used','spare','dropped')), origin TEXT NOT NULL DEFAULT 'auto' CHECK (origin IN ('auto','manual','ai')),
  clear INTEGER NOT NULL DEFAULT 1, edited INTEGER NOT NULL DEFAULT 0, created_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS examq_exam ON exam_questions(exam_id, state, position);
CREATE TABLE IF NOT EXISTS exam_scores(
  id INTEGER PRIMARY KEY, exam_id INTEGER NOT NULL REFERENCES exams(id) ON DELETE CASCADE, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE, student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  score REAL, absent INTEGER NOT NULL DEFAULT 0, note TEXT NOT NULL DEFAULT '', updated_at REAL NOT NULL, UNIQUE(exam_id, student_id));
CREATE INDEX IF NOT EXISTS examscores_student ON exam_scores(student_id);
CREATE TABLE IF NOT EXISTS assignments(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE, subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
  kind TEXT NOT NULL DEFAULT 'homework' CHECK (kind IN ('homework','activity','project','reading','review')),
  title TEXT NOT NULL, topic TEXT NOT NULL DEFAULT '', instructions TEXT NOT NULL, given_date TEXT NOT NULL, due_date TEXT NOT NULL DEFAULT '',
  closed INTEGER NOT NULL DEFAULT 0 CHECK (closed IN (0,1)), created_at REAL NOT NULL, updated_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS assignments_class ON assignments(user_id, class_id, closed, due_date);
CREATE TABLE IF NOT EXISTS assignment_students(
  id INTEGER PRIMARY KEY, assignment_id INTEGER NOT NULL REFERENCES assignments(id) ON DELETE CASCADE, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE, student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','done','partial','missing')), updated_at REAL NOT NULL, UNIQUE(assignment_id, student_id));
CREATE INDEX IF NOT EXISTS assignstu_student ON assignment_students(student_id);
CREATE TABLE IF NOT EXISTS term_archives(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  term_id INTEGER NOT NULL UNIQUE REFERENCES terms(id) ON DELETE CASCADE, new_term_id INTEGER REFERENCES terms(id) ON DELETE SET NULL,
  name TEXT NOT NULL, starts TEXT NOT NULL, ends TEXT NOT NULL, orig_ends TEXT NOT NULL, closed_on TEXT NOT NULL,
  data TEXT NOT NULL DEFAULT '{}', created_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS termarch_user ON term_archives(user_id, id);
CREATE TABLE IF NOT EXISTS user_backups(
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, data BLOB NOT NULL, summary TEXT NOT NULL DEFAULT '{}', created_at REAL NOT NULL);
"""

PLANS = [  # prices are in halalas (100 = 1 riyal), VAT included. Paid by bank transfer, confirmed by the manager. Only used to FILL a missing plan: what the manager edits is kept.
    ("free", "مجانية", 3, 5, 0, 0, 0, 0, ""),
    ("monthly", "شهرية", 30, 100, 2900, 0, 1, 40, "month"),
    ("yearly", "سنوية", 400, 2000, 0, 24900, 1, 40, "year"),
]
ADDED = (("lessons", "subject", "TEXT NOT NULL DEFAULT ''"), ("lessons", "grade", "TEXT NOT NULL DEFAULT ''"), ("plans", "ai_quota", "INTEGER NOT NULL DEFAULT 0"),
         ("users", "plan_expires", "REAL NOT NULL DEFAULT 0"), ("users", "is_admin", "INTEGER NOT NULL DEFAULT 0"), ("plans", "period", "TEXT NOT NULL DEFAULT ''"),
         ("ai_usage", "cost_nano", "INTEGER NOT NULL DEFAULT 0"), ("decks", "auto", "INTEGER NOT NULL DEFAULT 0"),
         ("users", "plan_started", "REAL NOT NULL DEFAULT 0"), ("users", "phone", "TEXT"),
         ("classes", "whatsapp", "TEXT NOT NULL DEFAULT ''"), ("class_subjects", "book_id", "INTEGER REFERENCES books(id) ON DELETE SET NULL"),
         ("plan_items", "together_with", "INTEGER REFERENCES plan_items(id) ON DELETE SET NULL"))


class Rows:
    """The answer to one statement, read to the end while the connection was held, so no other thread can touch it half way.
    It is used the way a cursor is: fetchone / fetchall / fetchmany, a for-loop, lastrowid and rowcount."""
    __slots__ = ("_rows", "_i", "lastrowid", "rowcount", "description")

    def __init__(self, cur, rows):
        self._rows, self._i = rows, 0
        self.lastrowid = getattr(cur, "lastrowid", None)
        self.rowcount = getattr(cur, "rowcount", -1)
        self.description = getattr(cur, "description", None)

    def fetchone(self):
        if self._i >= len(self._rows):
            return None
        self._i += 1
        return self._rows[self._i - 1]

    def fetchall(self):
        rows, self._i = self._rows[self._i:], len(self._rows)
        return rows

    def fetchmany(self, size=1):
        rows = self._rows[self._i:self._i + size]
        self._i += len(rows)
        return rows

    def __iter__(self):
        return iter(self.fetchall())


class SafeConn:
    """One SQLite connection that several threads can share without breaking each other.

    The server runs 2 processes x 4 threads, and every request asks the same question first (who is signed in), so two threads often ran the very same
    statement on the same connection at the same moment. Python's sqlite3 then fails now and then with "bad parameter or other API misuse" (measured:
    about 2 calls in 100 with 8 threads), which showed up as a page whose stylesheet or script came back as an error. Every statement now runs, and is
    read to its end, while one lock is held. Statements are short, so waiting for the lock costs nothing you can feel; nothing about the data, the tables
    or the way commits work changes."""

    def __init__(self, conn):
        self._c = conn
        self._lock = threading.RLock()

    def execute(self, sql, params=()):
        with self._lock:
            cur = self._c.execute(sql, params)
            return Rows(cur, cur.fetchall())

    def executemany(self, sql, seq):
        with self._lock:
            cur = self._c.executemany(sql, seq)
            return Rows(cur, [])

    def executescript(self, script):
        with self._lock:
            cur = self._c.executescript(script)
            return Rows(cur, [])

    def commit(self):
        with self._lock:
            self._c.commit()

    def rollback(self):
        with self._lock:
            self._c.rollback()

    def close(self):
        with self._lock:
            self._c.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        with self._lock:
            return self._c.__exit__(*exc)

    def __getattr__(self, name):                       # in_transaction, total_changes, ... read straight from the real connection
        return getattr(self._c, name)


def connect(path):
    conn = sqlite3.connect(str(path), timeout=15, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return SafeConn(conn)


def init(conn):
    conn.executescript(SCHEMA)
    added = []
    for table, col, ddl in ADDED:
        if col not in [r[1] for r in conn.execute(f"PRAGMA table_info({table})")]:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {ddl}")        # a database made by an earlier version
            added.append((table, col))
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS users_phone ON users(phone) WHERE phone IS NOT NULL")      # one account for one mobile number; accounts made with an e-mail have none
    _classes_for_old_students(conn)
    conn.executemany("INSERT OR IGNORE INTO plans(code, name, max_lessons, max_decks, price_month, price_year, purchasable, ai_quota, period) VALUES (?,?,?,?,?,?,?,?,?)", PLANS)
    for code, *_, quota, period in PLANS:
        if ("plans", "ai_quota") in added:
            conn.execute("UPDATE plans SET ai_quota = ? WHERE code = ?", (quota, code))
        conn.execute("UPDATE plans SET period = ? WHERE code = ? AND period = ''", (period, code))          # the plan's period was never stored before
    _usage_for_old_lessons(conn)
    conn.commit()


def _usage_for_old_lessons(conn):
    """The lessons a teacher has read in a cycle are counted in a log of their own (lesson_usage), so deleting a lesson never gives its place back.
    Lessons that were already here when the log was made are written into it once, on the day they were uploaded. Nothing is changed or removed in any
    other table, and running this again adds nothing that is already in the log (a lesson that was deleted before is simply not there to be added)."""
    conn.execute("INSERT OR IGNORE INTO lesson_usage(user_id, lesson_id, file_key, used_at) SELECT user_id, id, stored_name, created_at FROM lessons WHERE status = 'ready'")


def _classes_for_old_students(conn):
    """Version 3 had one list of students per teacher. Put that list into a first class («الفصل الأول») so nothing is lost, and let the same name live in two classes."""
    cols = [r[1] for r in conn.execute("PRAGMA table_info(students)")]
    if "class_id" in cols:
        return
    conn.commit()
    conn.execute("PRAGMA foreign_keys = OFF")           # the old table is replaced while its results still point at the students' ids
    try:
        conn.executescript("""
BEGIN;
CREATE TABLE students_new(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  class_id INTEGER REFERENCES classes(id) ON DELETE CASCADE,
  name TEXT NOT NULL, created_at REAL NOT NULL, UNIQUE(class_id, name));
INSERT INTO classes(user_id, name, created_at) SELECT DISTINCT user_id, 'الفصل الأول', strftime('%s','now') FROM students;
INSERT INTO students_new(id, user_id, class_id, name, created_at)
  SELECT s.id, s.user_id, (SELECT c.id FROM classes c WHERE c.user_id = s.user_id AND c.name = 'الفصل الأول'), s.name, s.created_at FROM students s;
DROP TABLE students;
ALTER TABLE students_new RENAME TO students;
COMMIT;""")
    finally:
        conn.execute("PRAGMA foreign_keys = ON")


def setting(conn, key, default=""):
    row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    return row[0] if row else default


def put_setting(conn, key, value):
    conn.execute("INSERT INTO settings(key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value", (key, str(value)))
    conn.commit()


def now():
    return time.time()


def jload(text, default):
    try:
        return json.loads(text)
    except (TypeError, ValueError):
        return default
