"""The manager's charts, drawn on the server as plain SVG. Only attributes and classes are used (the page forbids inline styles and scripts), so they scale to any
screen, print as they are, and need no library. Colours come from the stylesheet (.s1 .s2 .s3 .sg); every chart has a legend, a hover title on each mark and a table
with the exact numbers beside it, so no meaning rests on colour alone. The time axis runs from the right (oldest) to the left (newest), the way the page reads."""
import math

from markupsafe import Markup, escape

W, H = 420, 230
SHORT = ["ينا", "فبر", "مار", "أبر", "ماي", "يون", "يول", "أغس", "سبت", "أكت", "نوف", "ديس"]


def short_month(key: str) -> str:
    return SHORT[int(key[5:7]) - 1]


LRI, PDI = "\u2066", "\u2069"          # a number stays one left-to-right piece inside right-to-left text, so a minus sign stands on its left


def _ticks(low: float, top: float, want: int = 4, integer: bool = False):
    """Round tick values that cover [low, top] and include zero: (list of ticks, step). A chart with nothing in it still gets an axis (0 to 4)."""
    if top == low == 0:
        top = 4
    span = top - low
    raw = span / want
    mag = 10 ** math.floor(math.log10(raw))
    step = next(m * mag for m in (1, 2, 2.5, 5, 10) if m * mag >= raw)
    if integer and step < 1:
        step = 1
    lo, hi = math.floor(low / step) * step, math.ceil(top / step) * step
    return [round(lo + i * step, 6) for i in range(round((hi - lo) / step) + 1)], step


def _fmt(v: float, step: float = 1, integer: bool = False) -> str:
    """A number for an axis or a bar: whole numbers when the step is whole, otherwise just enough decimals. A negative one keeps its sign on the left."""
    if integer or step >= 1:
        txt = f"{round(v):,}"
    else:
        txt = f"{v:,.{1 if round(step * 10, 6) == int(round(step * 10, 6)) else 2}f}"
    return f"{LRI}{txt}{PDI}" if txt.startswith("-") else txt


def _val(v: float, integer: bool = False) -> str:
    """A bar's own number: up to two decimals, no trailing zeros."""
    txt = f"{round(v):,}" if integer else f"{v:,.2f}".rstrip("0").rstrip(".")
    return f"{LRI}{txt}{PDI}" if txt.startswith("-") else txt


def _round_top(x, y, w, h, r):
    """A bar standing on the baseline with its free end rounded (h > 0 goes up from y, h < 0 goes down)."""
    r = max(0, min(r, w / 2, abs(h)))
    if h >= 0:
        return f"M{x:.1f},{y:.1f}V{y - h + r:.1f}Q{x:.1f},{y - h:.1f} {x + r:.1f},{y - h:.1f}H{x + w - r:.1f}Q{x + w:.1f},{y - h:.1f} {x + w:.1f},{y - h + r:.1f}V{y:.1f}Z"
    return f"M{x:.1f},{y:.1f}V{y - h - r:.1f}Q{x:.1f},{y - h:.1f} {x + r:.1f},{y - h:.1f}H{x + w - r:.1f}Q{x + w:.1f},{y - h:.1f} {x + w:.1f},{y - h - r:.1f}V{y:.1f}Z"


def table(headers, rows) -> Markup:
    head = "".join(f"<th>{escape(h)}</th>" for h in headers)
    body = "".join("<tr>" + "".join(f"<td>{escape(c)}</td>" for c in r) + "</tr>" for r in rows)
    return Markup(f'<div class="tscroll"><table class="tbl"><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>')


def legend(items) -> Markup:
    """items: [(class, name)]"""
    return Markup('<ul class="legend">' + "".join(f'<li><i class="sw {c}"></i>{escape(n)}</li>' for c, n in items) + "</ul>")


def figure(title, svg, items=None, headers=None, rows=None, note="") -> Markup:
    parts = [f'<figure class="fig"><figcaption>{escape(title)}</figcaption>', str(svg)]
    if items and len(items) > 1:
        parts.append(str(legend(items)))
    if note:
        parts.append(f'<p class="muted small">{escape(note)}</p>')
    if headers and rows:
        parts.append(f'<details class="numbers"><summary>عرض الأرقام</summary>{table(headers, rows)}</details>')
    parts.append("</figure>")
    return Markup("".join(parts))


def bars(labels, series, unit="ريال", height=H, name="", integer=False) -> Markup:
    """Vertical bars, one group per label. series: [{"name", "cls", "values"}] in halalas-free units (already in the unit shown). Values may be negative."""
    n, k = len(labels), len(series)
    top = max([0] + [v for s in series for v in s["values"]])
    low = min([0] + [v for s in series for v in s["values"]])
    ticks, step = _ticks(low, top, integer=integer)
    ymin, ymax = ticks[0], ticks[-1]
    pad_l, pad_r, pad_t, pad_b = 8, 44, 18, 26                       # the value axis stands on the right, where an Arabic page starts
    plot_w, plot_h = W - pad_l - pad_r, height - pad_t - pad_b
    scale = plot_h / (ymax - ymin)
    y0 = pad_t + ymax * scale
    out = ['<g class="grid">']
    for v in ticks:
        y = pad_t + (ymax - v) * scale
        out.append(f'<line x1="{pad_l}" x2="{W - pad_r}" y1="{y:.1f}" y2="{y:.1f}"/>')
        out.append(f'<text class="ax" x="{W - pad_r + 6}" y="{y + 4:.1f}" text-anchor="start">{_fmt(v, step, integer)}</text>')
    out.append("</g>")
    group = plot_w / max(n, 1)
    gap = min(10, group * 0.3)
    bw = max(3, min(26, (group - gap) / k - 2))
    for gi, lab in enumerate(labels):
        gx_right = W - pad_r - gi * group                              # the oldest group is the right-most
        for si, s in enumerate(series):
            v = s["values"][gi]
            x = gx_right - gap / 2 - (si + 1) * (bw + 2) + 2
            h = v * scale
            if abs(h) >= 0.5:
                out.append(f'<path class="{s["cls"]}" d="{_round_top(x, y0, bw, h, 4)}"><title>{escape(lab)} — {escape(s["name"])}: {_val(v, integer)} {escape(unit)}</title></path>')
            if gi == n - 1 and abs(h) >= 0.5:                          # the latest group is labelled; the others show their number on hover and in the table
                ty = y0 - h - 5 if h >= 0 else y0 - h + 14
                out.append(f'<text class="val" x="{x + bw / 2:.1f}" y="{ty:.1f}" text-anchor="middle">{_val(v, integer)}</text>')
        out.append(f'<text class="ax" x="{gx_right - group / 2:.1f}" y="{height - 8}" text-anchor="middle">{escape(lab)}</text>')
    out.append(f'<line class="axis" x1="{pad_l}" x2="{W - pad_r}" y1="{y0:.1f}" y2="{y0:.1f}"/>')
    label = name or "رسم بياني"
    return Markup(f'<svg class="chart" viewBox="0 0 {W} {height}" role="img" aria-label="{escape(label)}">' + "".join(out) + "</svg>")


def stacked(parts, name="") -> Markup:
    """One horizontal bar split into parts. parts: [{"name", "cls", "value"}]; zero parts are not drawn."""
    total = sum(p["value"] for p in parts) or 1
    pad = 8
    plot = W - 2 * pad
    gap = 2
    shown = [p for p in parts if p["value"] > 0]
    x_right = W - pad
    out = []
    for p in shown:
        w = max(4, plot * p["value"] / total - (gap if len(shown) > 1 else 0))
        x = x_right - w
        out.append(f'<rect class="{p["cls"]}" x="{x:.1f}" y="10" width="{w:.1f}" height="30" rx="4"><title>{escape(p["name"])}: {p["value"]}</title></rect>')
        if w >= 26:
            out.append(f'<text class="on" x="{x + w / 2:.1f}" y="30" text-anchor="middle">{p["value"]}</text>')
        x_right = x - gap
    if not shown:
        out.append(f'<rect class="sg" x="{pad}" y="10" width="{plot}" height="30" rx="4"/>')
    return Markup(f'<svg class="chart slim" viewBox="0 0 {W} 50" role="img" aria-label="{escape(name or "توزيع")}">' + "".join(out) + "</svg>")


def gauge_state(used, cap):
    """('ok' | 'warn' | 'stop', percent used). Amber from 80% of the cap, red at the cap (or when no money is allowed at all)."""
    pct = 0 if cap <= 0 else min(100, used * 100 / cap)
    return ("stop" if cap <= 0 or used >= cap else "warn" if pct >= 80 else "ok"), pct


def gauge(used, cap, name="") -> Markup:
    """How much of a cap is used: a bar with the 80% mark; the words beside it say the same as the colour."""
    state, pct = gauge_state(used, cap)
    pad, plot = 8, W - 16
    fill = plot * pct / 100
    out = [f'<rect class="track" x="{pad}" y="12" width="{plot}" height="18" rx="9"/>']
    if fill > 0:
        out.append(f'<rect class="fill {state}" x="{W - pad - fill:.1f}" y="12" width="{max(fill, 6):.1f}" height="18" rx="9"/>')
    mark = W - pad - plot * 0.8
    out.append(f'<line class="mark" x1="{mark:.1f}" x2="{mark:.1f}" y1="7" y2="35"/><text class="ax" x="{mark:.1f}" y="48" text-anchor="middle">80%</text>')
    return Markup(f'<svg class="chart slim {state}" viewBox="0 0 {W} 54" role="img" aria-label="{escape(name or "السقف")}">' + "".join(out) + "</svg>")
