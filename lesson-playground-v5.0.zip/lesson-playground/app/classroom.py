"""The teacher's day: her subjects, the screen she starts a lesson from, the explanation she keeps for herself, and the summary on the home screen.

Everything here belongs to ONE teacher and, inside her, to ONE class at a time: a class is the unit the whole app is organised by (students.py), and a subject is
linked to the classes she teaches it in. Nothing in this file reads or writes another teacher's rows (every lookup is by user_id)."""
import datetime

from flask import Blueprint, abort, current_app, g, jsonify, redirect, render_template, request, url_for
from werkzeug.routing import BuildError

from . import meta, roster, share, textfmt
from .db import now
from .lessons import mine
from .security import login_required
from .students import class_row, classes_list, clean_name, toint, body

bp = Blueprint("classroom", __name__)
MAX_SUBJECTS = 30


# ---------------------------------------------------------------- subjects
def subjects_list():
    db = current_app.db
    uid = g.user["id"]
    links = {}
    for r in db.execute("SELECT subject_id, class_id FROM class_subjects WHERE user_id = ?", (uid,)):
        links.setdefault(r["subject_id"], []).append(r["class_id"])
    return [{"id": r["id"], "name": r["name"], "classes": links.get(r["id"], [])}
            for r in db.execute("SELECT id, name FROM subjects WHERE user_id = ? ORDER BY name", (uid,))]


def subject_row(sid):
    row = current_app.db.execute("SELECT * FROM subjects WHERE id = ? AND user_id = ?", (sid, g.user["id"])).fetchone()
    if not row:
        abort(404)
    return row


def ensure_subject(name: str):
    """The id of her subject with this name, made if it is new (None when the name is not usable or she has too many)."""
    name = clean_name(name)[:40]
    if len(name) < 2:
        return None
    db = current_app.db
    row = db.execute("SELECT id FROM subjects WHERE user_id = ? AND name = ?", (g.user["id"], name)).fetchone()
    if row:
        return row["id"]
    if db.execute("SELECT COUNT(*) FROM subjects WHERE user_id = ?", (g.user["id"],)).fetchone()[0] >= MAX_SUBJECTS:
        return None
    return db.execute("INSERT INTO subjects(user_id, name, created_at) VALUES (?,?,?)", (g.user["id"], name, now())).lastrowid


@bp.get("/api/subjects")
@login_required
def subjects():
    return jsonify(subjects=subjects_list())


@bp.post("/api/subjects")
@login_required
def add_subject():
    name = clean_name(body().get("name"))[:40]
    if len(name) < 2:
        return jsonify(error="اكتبي اسم المادة (حرفان على الأقل)"), 400
    db = current_app.db
    if db.execute("SELECT 1 FROM subjects WHERE user_id = ? AND name = ?", (g.user["id"], name)).fetchone():
        return jsonify(error="هذه المادة موجودة"), 409
    sid = ensure_subject(name)
    if sid is None:
        return jsonify(error=f"الحد الأقصى {MAX_SUBJECTS} مادة"), 400
    db.commit()
    return jsonify(id=sid, subjects=subjects_list()), 201


@bp.patch("/api/subjects/<int:sid>")
@login_required
def rename_subject(sid):
    subject_row(sid)
    name = clean_name(body().get("name"))[:40]
    if len(name) < 2:
        return jsonify(error="اكتبي اسم المادة"), 400
    try:
        current_app.db.execute("UPDATE subjects SET name = ? WHERE id = ?", (name, sid))
        current_app.db.commit()
    except Exception:
        return jsonify(error="هذه المادة موجودة"), 409
    return jsonify(saved=True)


@bp.delete("/api/subjects/<int:sid>")
@login_required
def delete_subject(sid):
    subject_row(sid)
    current_app.db.execute("DELETE FROM subjects WHERE id = ?", (sid,))          # only the link to her classes goes; her lessons and her students stay
    current_app.db.commit()
    return jsonify(ok=True)


@bp.put("/api/classes/<int:cid>/subjects")
@login_required
def set_class_subjects(cid):
    """The subjects she teaches this class, as one list (the ones not in the list are unlinked, the others are kept)."""
    class_row(cid)
    wanted = {toint(x) for x in (body().get("subject_ids") or []) if isinstance(x, int)}
    db = current_app.db
    mine_ids = {r["id"] for r in db.execute("SELECT id FROM subjects WHERE user_id = ?", (g.user["id"],))}
    if wanted - mine_ids:
        return jsonify(error="مادة غير موجودة"), 404
    have = {r["subject_id"] for r in db.execute("SELECT subject_id FROM class_subjects WHERE class_id = ?", (cid,))}
    for sid in have - wanted:
        db.execute("DELETE FROM class_subjects WHERE class_id = ? AND subject_id = ?", (cid, sid))
    for sid in wanted - have:
        db.execute("INSERT INTO class_subjects(user_id, class_id, subject_id, created_at) VALUES (?,?,?,?)", (g.user["id"], cid, sid, now()))
    db.commit()
    return jsonify(classes=classes_list(), subjects=subjects_list())


# ---------------------------------------------------------------- the home screen
TZ = datetime.timezone(datetime.timedelta(hours=3))          # the teacher's day is the Saudi day, wherever the server clock is set


def now_local() -> datetime.datetime:
    return datetime.datetime.now(TZ)


def today_date() -> datetime.date:
    return now_local().date()


HUB_CARDS = (          # the four sections of the home screen; a card appears when its page exists
    ("start", "▶", "بدء الحصة", "اختاري الفصل والدرس وابدئي العرض", "classroom.start_page"),
    ("absent", "🚪", "غائب اليوم", "سجّلي غيابك وتُعاد جدولة الدروس", "absence.page"),
    ("exams", "📝", "الاختبارات", "أنشئي اختبارًا من المنهج واطبعيه", "exams.page"),
    ("work", "📚", "الأنشطة والواجبات", "واجبات وأنشطة وإرسالها لمجموعة الفصل", "homework.page"),
)
SETUP_CARDS = (          # the three cards of the first run
    ("book", "📖", "تحميل المنهج (الكتاب)", "curriculum.page"),
    ("schedule", "🗓", "تحميل جدول المعلمة", "schedule.page"),
    ("students", "👥", "تحميل قوائم أسماء الطلاب", "students.page"),
)


def _link(endpoint):
    try:
        return url_for(endpoint)
    except BuildError:
        return None


def _count(db, table, uid) -> int:
    try:
        return db.execute(f"SELECT COUNT(*) FROM {table} WHERE user_id = ?", (uid,)).fetchone()[0]
    except Exception:
        return 0


def hub_data(db, uid) -> dict:
    """What the home screen needs: today's date, the four sections, and how far the set-up is (the three first cards)."""
    today = today_date()
    data = {"classes": _count(db, "classes", uid), "students": _count(db, "students", uid), "subjects": _count(db, "subjects", uid),
            "lessons": db.execute("SELECT COUNT(*) FROM lessons WHERE user_id = ? AND status = 'ready'", (uid,)).fetchone()[0],
            "today_iso": today.isoformat(), "today_text": share.ar_date(today.isoformat())}
    done = {"book": _count(db, "books", uid) > 0, "schedule": _count(db, "schedule_slots", uid) > 0, "students": data["students"] > 0}
    data["setup_cards"] = [{"key": k, "icon": i, "title": t, "url": _link(e), "done": done[k]} for k, i, t, e in SETUP_CARDS if _link(e)]
    data["setup_done"] = all(c["done"] for c in data["setup_cards"])
    data["cards"] = [{"key": k, "icon": i, "title": t, "hint": h, "url": _link(e)} for k, i, t, h, e in HUB_CARDS if _link(e)]
    data["absent_today"] = bool(db.execute("SELECT 1 FROM absences WHERE user_id = ? AND day = ?", (uid, today.isoformat())).fetchone())
    if data["absent_today"]:
        for c in data["cards"]:
            if c["key"] == "absent":
                c["hint"] = "غيابك اليوم مسجَّل · اضغطي للتفاصيل أو الإلغاء"
    for c in data["cards"]:
        if c["key"] == "work":
            from . import homework          # here and not above: the homework page itself needs this module
            waiting = homework.attention(db, uid, today.isoformat())
            if waiting:
                c["hint"] = f"{textfmt.assignments(waiting)} بانتظار تسجيل من أنجز"
    from . import termend
    data["term_note"] = termend.note(db, uid, today)          # her term is over (or nearly): where to close it
    return data


# ---------------------------------------------------------------- starting a lesson
@bp.get("/start")
@login_required
def start_page():
    return render_template("start.html")


@bp.get("/api/start")
@login_required
def start_data():
    db = current_app.db
    uid = g.user["id"]
    counts = {r["lesson_id"]: r["n"] for r in db.execute("SELECT lesson_id, COUNT(*) AS n FROM questions WHERE user_id = ? GROUP BY lesson_id", (uid,))}
    lessons = [{"id": r["id"], "title": r["title"], "subject": r["subject"], "grade": r["grade"], "questions": counts.get(r["id"], 0)}
               for r in db.execute("SELECT id, title, subject, grade FROM lessons WHERE user_id = ? AND status = 'ready' ORDER BY id DESC", (uid,))]
    return jsonify(classes=classes_list(), subjects=subjects_list(), lessons=lessons, suggest=suggestion(db, uid))


def suggestion(db, uid):
    """The lesson her timetable and plan put in the period that is on now (the first period of today not over and not taught yet that has a lesson of the app). None when there is none."""
    from . import plan
    try:
        today = plan.today_plan(db, uid)
    except Exception:
        return None
    for p in today["periods"]:
        l = p["lesson"]
        if p["state"] == "now" and l and l["lesson_id"]:
            ok = db.execute("SELECT 1 FROM lessons WHERE id = ? AND user_id = ? AND status = 'ready'", (l["lesson_id"], uid)).fetchone()
            if ok:
                return {"period": p["period"], "class_id": p["class_id"], "class_name": p["class_name"], "subject_id": p["subject_id"], "subject_name": p["subject_name"],
                        "title": l["title"], "lesson_id": l["lesson_id"], "time": p["time"]}
    return None


# ---------------------------------------------------------------- the explanation for the teacher herself
@bp.get("/lessons/<int:lid>/notes")
@login_required
def notes_page(lid):
    lesson = mine("lessons", lid)
    if lesson["status"] != "ready":
        return redirect(url_for("lessons.lesson", lid=lid))
    return render_template("notes.html", lesson=lesson)


@bp.get("/api/lessons/<int:lid>/notes")
@login_required
def notes_data(lid):
    """The lesson's explanation in parts (the same parts «حصة اليوم» shows), the quick questions with their answers, and the message to keep in WhatsApp."""
    from . import today
    lesson = mine("lessons", lid)
    db = current_app.db
    questions = [today.q_dict(r) for r in today.lesson_questions(db, lid, g.user["id"])]
    built = today.build(lesson["title"], lesson["text"] or "", questions)
    msg = share.notes_message(lesson["title"], lesson["subject"], built["parts"])
    return jsonify(title=lesson["title"], subject=lesson["subject"], grade=lesson["grade"], parts=built["parts"], message=msg, wa=share.wa_text_url(msg))
