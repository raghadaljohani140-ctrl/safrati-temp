import functools
import re
import secrets
import time

from flask import abort, g, jsonify, redirect, request, session, url_for

EMAIL = re.compile(r"^[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9.-]{1,190}\.[A-Za-z]{2,24}$")


def csrf_token() -> str:
    if "csrf" not in session:
        session["csrf"] = secrets.token_urlsafe(24)
    return session["csrf"]


def check_csrf():
    sent = request.headers.get("X-CSRF") or request.form.get("_csrf") or ""
    if not sent or not secrets.compare_digest(sent, session.get("csrf", "")):
        abort(403)


class Limiter:
    """A few tries per window from one key (an address, an e-mail)."""
    def __init__(self, tries, seconds):
        self.tries, self.seconds, self.hits = tries, seconds, {}

    def allow(self, key) -> bool:
        now = time.time()
        recent = [t for t in self.hits.get(key, []) if now - t < self.seconds]
        self.hits[key] = recent
        if len(recent) >= self.tries:
            return False
        recent.append(now)
        return True

    def reset(self, key):
        self.hits.pop(key, None)


def login_required(view):
    @functools.wraps(view)
    def wrapped(*a, **kw):
        if not g.user:
            if request.path.startswith("/api/"):
                return jsonify(error="سجّلي دخولك أولًا"), 401
            return redirect(url_for("auth.login"))
        return view(*a, **kw)
    return wrapped


def admin_required(view):
    @functools.wraps(view)
    def wrapped(*a, **kw):
        if not g.user:
            return redirect(url_for("auth.login"))
        if not g.user["is_admin"]:
            abort(404)                    # the manager's pages do not exist for anyone else
        return view(*a, **kw)
    return wrapped
