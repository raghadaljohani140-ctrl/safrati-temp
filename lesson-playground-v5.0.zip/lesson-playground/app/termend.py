"""The end of a term. A teacher sees how the term went (every class: points, answers, homework, exams, where each plan stands), then closes it: the term is archived for reading and
exporting and a new one begins, with her classes, her students, her books and her timetable where they were.

Nothing of the old term is deleted. What she gave in it (points, homework, exams, absences) stays where it is, tied to its days; what the app worked out is kept as a frozen
snapshot in `term_archives`, so the old term can still be read and exported after her classes change. The only things written when a term is closed are: the old term is marked
archived (and ends today if it had not ended), the new term is made, the lessons she already taught can be set aside in the new plan (never deleted, she can bring them back), and
the snapshot. The last closing can be taken back (`reopen`): the new term it made goes, the old one is open again, as it was."""
import csv
import datetime
import io
import json
import logging

from flask import Blueprint, Response, abort, current_app, g, jsonify, render_template, request, url_for

from . import classroom, exams, plan, reports, share, terms, textfmt
from .db import now
from .planner import parse_day
from .security import Limiter, login_required
from .students import body, clean_name

log = logging.getLogger(__name__)
bp = Blueprint("termend", __name__)
close_limit = Limiter(10, 3600)
MAX_ARCHIVES = 40
MAX_TERM_DAYS = terms.MAX_TERM_DAYS
SNAPSHOT_VERSION = 1


# ---------------------------------------------------------------- what the term holds
def day_of(ts) -> str:
    return datetime.datetime.fromtimestamp(ts, classroom.TZ).date().isoformat()


def exam_lines(db, uid, cid, lo, hi) -> list:
    """The approved exams of a class that fall in the term, by the day of the exam (an exam with no day by the day it was made), with how the class did."""
    out = []
    for e in db.execute("SELECT * FROM exams WHERE user_id = ? AND class_id = ? AND status = 'approved' ORDER BY exam_date, id", (uid, cid)).fetchall():
        day = e["exam_date"] or day_of(e["created_at"])
        if not lo <= day <= hi:
            continue
        st = exams.score_stats(db, e)
        subject = db.execute("SELECT name FROM subjects WHERE id = ?", (e["subject_id"],)).fetchone() if e["subject_id"] else None
        scores = {r["student_id"]: {"score": r["score"], "absent": bool(r["absent"])} for r in db.execute("SELECT student_id, score, absent FROM exam_scores WHERE exam_id = ?", (e["id"],))}
        out.append({"title": e["title"], "subject": subject["name"] if subject else "", "date": e["exam_date"], "date_text": share.ar_date(e["exam_date"]) if e["exam_date"] else "",
                    "total": e["total"], "total_text": exams.mark_text(e["total"]), "students": st["students"], "entered": st["entered"], "absent": st["absent"], "missing": st["missing"],
                    "average": st["average"], "percent": st["percent"], "highest": st["highest"], "lowest": st["lowest"], "passed": st["passed"], "scores": scores})
    return out


def plan_counts(db, uid, term_id) -> dict:
    """{(class, subject): {"done": n, "pending": n, "skipped": n}} for the plans of a term."""
    out = {}
    for r in db.execute("SELECT class_id, subject_id, status, COUNT(*) AS n FROM plan_items WHERE user_id = ? AND term_id = ? GROUP BY class_id, subject_id, status", (uid, term_id)):
        out.setdefault((r["class_id"], r["subject_id"]), {})[r["status"]] = r["n"]
    return out


def class_summary(db, uid, cls, lo, hi, today, pairs, counts) -> dict:
    rep = reports.class_report(db, uid, cls, None, "term", lo, hi, today, pairs=pairs)
    hw = rep["homework"]
    hw_by = {x["student_id"]: x for x in hw["students"]}
    lines = exam_lines(db, uid, cls["id"], lo, hi)
    rows = []
    for r in rep["rows"]:
        h = hw_by.get(r["student_id"], {})
        mine = [e["scores"].get(r["student_id"]) for e in lines]
        shown = [None if s is None else ("غ" if s["absent"] else s["score"]) for s in mine]
        pcts = [100 * s["score"] / e["total"] for s, e in zip(mine, lines) if s and not s["absent"] and s["score"] is not None and e["total"]]
        rows.append({"name": r["name"], "points": r["points"], "awards": r["awards"], "rank": r["rank"], "answered": r["answered"], "correct": r["correct"], "percent": r["percent"],
                     "level": r["level"], "hw_done": h.get("done", 0), "hw_checked": h.get("checked", 0), "scores": shown,
                     "exam_percent": textfmt.percent(sum(pcts), 100 * len(pcts)) if pcts else None, "exam_count": len(pcts)})
    plans = []
    for p in pairs:
        if p["class_id"] != cls["id"]:
            continue
        c = counts.get((p["class_id"], p["subject_id"]), {})
        plans.append({"subject": p["subject_name"], "book": p["book"], "need": p["need"], "percent": p["percent"], "late": p["late"],
                      "done": c.get("done", 0), "pending": c.get("pending", 0), "skipped": c.get("skipped", 0)})
    for e in lines:
        e.pop("scores")          # (they are in the rows, student by student)
    return {"name": cls["name"], "students": len(rep["rows"]), "points": rep["points"], "awards": rep["awards"], "ranked": rep["ranked"], "silent": len(rep["silent"]),
            "top": [{"name": t["name"], "points": t["points"], "rank": t["rank"]} for t in rep["top"]],
            "answered": sum(r["answered"] or 0 for r in rep["rows"]), "correct": sum(r["correct"] or 0 for r in rep["rows"]),
            "homework": {k: hw[k] for k in ("given", "done", "partial", "missing", "pending", "checked", "percent")}, "plans": plans, "exams": lines, "rows": rows}


def summary(db, uid, term, today, last=None) -> dict:
    """How a term went, worked out from what she entered in it: the whole of it, class by class. `last` is the last day counted (the day she closes it if that comes first)."""
    lo, hi = term["starts"], last or term["ends"]
    pairs = plan.pairs(db, uid, today)
    counts = plan_counts(db, uid, term["id"])
    classes = [class_summary(db, uid, c, lo, hi, today, pairs, counts) for c in db.execute("SELECT id, name FROM classes WHERE user_id = ? ORDER BY id", (uid,)).fetchall()]
    done, checked = sum(c["homework"]["done"] for c in classes), sum(c["homework"]["checked"] for c in classes)
    done_l, pending_l, skipped_l = (sum(v.get(k, 0) for v in counts.values()) for k in ("done", "pending", "skipped"))
    totals = {"classes": len(classes), "students": sum(c["students"] for c in classes), "points": sum(c["points"] for c in classes), "awards": sum(c["awards"] for c in classes),
              "answered": sum(c["answered"] for c in classes), "correct": sum(c["correct"] for c in classes),
              "lessons_done": done_l, "lessons_pending": pending_l, "lessons_skipped": skipped_l,
              "homework_given": sum(c["homework"]["given"] for c in classes), "homework_done": done, "homework_checked": checked, "homework_percent": textfmt.percent(done, checked),
              "exams": sum(len(c["exams"]) for c in classes),
              "absence_days": db.execute("SELECT COUNT(DISTINCT day) FROM absences WHERE user_id = ? AND day BETWEEN ? AND ?", (uid, lo, hi)).fetchone()[0],
              "holidays": db.execute("SELECT COUNT(*) FROM calendar_days WHERE term_id = ? AND day BETWEEN ? AND ?", (term["id"], lo, hi)).fetchone()[0]}
    return {"version": SNAPSHOT_VERSION, "term": terms.term_dict({"id": term["id"], "name": term["name"], "starts": lo, "ends": hi}), "totals": totals, "classes": classes}


# ---------------------------------------------------------------- the sheet she can open in Excel
def csv_rows(s, class_name=None) -> list:
    """The sheet of a summary. All the classes: a line per student with the class beside it. One class: the same, with a column for each exam of the class."""
    out = []
    for c in s["classes"]:
        if class_name is not None and c["name"] != class_name:
            continue
        if class_name is not None:
            out.append(["الترتيب", "الطالب", "النقاط", "مرات المنح", "الأسئلة", "الصحيحة", "النسبة", "الواجبات المنجزة", "الواجبات المسجّلة"]
                       + [f"{e['title']} (من {e['total_text']})" for e in c["exams"]] + ["متوسط الاختبارات %"])
        for r in c["rows"]:
            hw, pct, exam_pct = [r["hw_done"], r["hw_checked"]], "" if r["percent"] is None else r["percent"], "" if r["exam_percent"] is None else r["exam_percent"]
            if class_name is not None:
                out.append([r["rank"] or "", reports.safe(r["name"]), r["points"], r["awards"], r["answered"], r["correct"], pct] + hw + ["" if x is None else x for x in r["scores"]] + [exam_pct])
            else:
                out.append([reports.safe(c["name"]), reports.safe(r["name"]), r["points"], r["awards"], r["rank"] or "", r["answered"], r["correct"], pct] + hw + [r["exam_count"], exam_pct])
    return out


def csv_response(s, name, filename, class_name=None) -> Response:
    out = io.StringIO()
    w = csv.writer(out, lineterminator="\r\n")
    t = s["term"]
    w.writerow([f"{name}" + (f" - {class_name}" if class_name else ""), f"{t['starts']} - {t['ends']}"])
    if class_name is None:
        w.writerow(["الفصل", "الطالب", "النقاط", "مرات المنح", "المركز", "الأسئلة", "الصحيحة", "النسبة", "الواجبات المنجزة", "الواجبات المسجّلة", "الاختبارات المسجّلة", "متوسط الاختبارات %"])
    for row in csv_rows(s, class_name):
        w.writerow(row)
    return Response("﻿" + out.getvalue(), mimetype="text/csv", headers={"Content-Disposition": f'attachment; filename="{filename}"', "Cache-Control": "no-store"})


# ---------------------------------------------------------------- the state of the term
def term_state(term, today) -> dict:
    """Where today is in her term: not begun, running (with the days left), or over (with the days since)."""
    a, b = parse_day(term["starts"]), parse_day(term["ends"])
    if today < a:
        return {"state": "before", "days": (a - today).days}
    if today > b:
        return {"state": "ended", "days": (today - b).days}
    return {"state": "running", "days": (b - today).days}


def next_name(name: str) -> str:
    for old, new in (("الأول", "الثاني"), ("الثاني", "الثالث"), ("الثالث", "الأول")):
        if old in name:
            return name.replace(old, new, 1)
    return "الفصل الدراسي الجديد"


def note(db, uid, today):
    """The line the home screen shows when her term is over or about to be: where to go to close it. None the rest of the time."""
    term = terms.current(db, uid, today)
    if not term:
        return None
    st = term_state(term, today)
    if st["state"] == "ended":
        return {"text": f"انتهى «{term['name']}» {textfmt.day_offset(-st['days'])}. لخّصيه وابدئي فصلًا جديدًا دون أن يضيع شيء.", "url": url_for("termend.page"), "state": "ended"}
    if st["state"] == "running" and st["days"] <= 14:
        return {"text": f"ينتهي «{term['name']}» {textfmt.day_offset(st['days'])}. اطّلعي على ملخصه من الآن.", "url": url_for("termend.page"), "state": "soon"}
    return None


def archive_dict(row, latest_id=None, full=False) -> dict:
    data = json.loads(row["data"] or "{}")
    out = {"id": row["id"], "name": row["name"], "starts": row["starts"], "ends": row["ends"], "starts_text": share.ar_date(row["starts"]), "ends_text": share.ar_date(row["ends"]),
           "closed_on": row["closed_on"], "closed_text": share.ar_date(row["closed_on"]), "totals": data.get("totals", {}), "latest": row["id"] == latest_id,
           "can_reopen": row["id"] == latest_id and bool(row["new_term_id"])}          # (only the last closing can be taken back, and only while the term it began is there)
    if full:
        out["summary"] = data
    return out


def archive_row(aid):
    row = current_app.db.execute("SELECT * FROM term_archives WHERE id = ? AND user_id = ?", (aid, g.user["id"])).fetchone()
    if not row:
        abort(404)
    return row


def archives_of(db, uid) -> list:
    rows = db.execute("SELECT * FROM term_archives WHERE user_id = ? ORDER BY id DESC", (uid,)).fetchall()
    return [archive_dict(r, latest_id=rows[0]["id"]) for r in rows]


# ---------------------------------------------------------------- pages and the data they read
@bp.get("/term")
@login_required
def page():
    return render_template("term.html")


@bp.get("/term/<int:aid>")
@login_required
def archive_page(aid):
    row = archive_row(aid)
    return render_template("term_archive.html", archive={"id": row["id"], "name": row["name"]})


@bp.get("/api/term")
@login_required
def data():
    db, uid, today = current_app.db, g.user["id"], classroom.today_date()
    term = terms.current(db, uid, today)
    out = {"today": today.isoformat(), "today_text": share.ar_date(today.isoformat()), "term": terms.term_dict(term), "archives": archives_of(db, uid), "summary": None, "can_close": False, "why": ""}
    if not term:
        out["why"] = "لم تحدّدي الفصل الدراسي بعد. حدّديه من صفحة التقويم."
        return jsonify(out)
    out.update(term_state(term, today))
    out["suggest"] = {"name": next_name(term["name"])}
    if out["state"] == "before":
        out["why"] = "لم يبدأ هذا الفصل بعد. إن كان تاريخاه خطأ فعدّليهما من صفحة التقويم."
    else:
        eff = min(parse_day(term["ends"]), today)          # the last day it counts: its own, or today if it has not ended
        out.update(closes_on=eff.isoformat(), closes_text=share.ar_date(eff.isoformat()), early=eff < parse_day(term["ends"]))
        out["can_close"] = len(out["archives"]) < MAX_ARCHIVES
        out["why"] = "" if out["can_close"] else f"وصلتِ إلى الحد الأقصى ({MAX_ARCHIVES} فصلًا مؤرشفًا)."
        out["summary"] = summary(db, uid, term, today, last=eff.isoformat())
    return jsonify(out)


@bp.get("/api/term/csv")
@login_required
def live_csv():
    db, uid, today = current_app.db, g.user["id"], classroom.today_date()
    term = terms.current(db, uid, today)
    if not term or term_state(term, today)["state"] == "before":
        abort(404)
    s = summary(db, uid, term, today, last=min(parse_day(term["ends"]), today).isoformat())
    return csv_response(s, term["name"], "term-now.csv", _class_arg(s))


def _class_arg(s):
    """The name of the class asked for in ?class= (None for all of them). 404 when the term has no class of that name."""
    name = (request.args.get("class") or "").strip()
    if not name:
        return None
    if name not in [c["name"] for c in s["classes"]]:
        abort(404)
    return name


@bp.get("/api/term/archives/<int:aid>")
@login_required
def archive_data(aid):
    row = archive_row(aid)
    latest = current_app.db.execute("SELECT MAX(id) FROM term_archives WHERE user_id = ?", (g.user["id"],)).fetchone()[0]
    return jsonify(archive_dict(row, latest_id=latest, full=True))


@bp.get("/api/term/archives/<int:aid>/csv")
@login_required
def archive_csv(aid):
    row = archive_row(aid)
    s = json.loads(row["data"] or "{}")
    if not s:
        abort(404)
    return csv_response(s, row["name"], f"term-{row['id']}.csv", _class_arg(s))


# ---------------------------------------------------------------- closing a term
def carry_plans(db, uid, old_id, new_term, today) -> int:
    """The lessons she taught in the old term are set aside in the new plans (status «skipped», with a note; she can bring any of them back), so the new term plans only what is left.
    Only for her classes and subjects that had a plan in the old term, and only for lessons of the book that is linked now. Returns how many were set aside."""
    carried = 0
    pairs = db.execute("SELECT DISTINCT p.class_id, p.subject_id, cs.book_id FROM plan_items p JOIN class_subjects cs ON cs.class_id = p.class_id AND cs.subject_id = p.subject_id "
                       "WHERE p.user_id = ? AND p.term_id = ? AND cs.book_id IS NOT NULL", (uid, old_id)).fetchall()
    old = db.execute("SELECT name FROM terms WHERE id = ?", (old_id,)).fetchone()["name"]
    for pr in pairs:
        plan.sync_items(db, uid, pr["class_id"], pr["subject_id"], new_term["id"], pr["book_id"])
        taught = [r["book_lesson_id"] for r in db.execute(
            "SELECT p.book_lesson_id FROM plan_items p JOIN book_lessons bl ON bl.id = p.book_lesson_id WHERE p.user_id = ? AND p.term_id = ? AND p.class_id = ? AND p.subject_id = ? "
            "AND p.status = 'done' AND bl.book_id = ?", (uid, old_id, pr["class_id"], pr["subject_id"], pr["book_id"]))]
        for bl in taught:
            carried += db.execute("UPDATE plan_items SET status = 'skipped', note = ?, updated_at = ? WHERE user_id = ? AND term_id = ? AND class_id = ? AND subject_id = ? AND book_lesson_id = ? "
                                  "AND status = 'pending'", (f"أُنجز في «{old}»"[:200], now(), uid, new_term["id"], pr["class_id"], pr["subject_id"], bl)).rowcount
        plan.rebase(db, uid, pr["class_id"], pr["subject_id"], new_term, today)
        plan.note(db, uid, pr["class_id"], pr["subject_id"], new_term["id"], "term",
                  f"بدأ «{new_term['name']}»: استُبعدت من خطته الدروس التي أُنجزت في «{old}»، وبقي {len(taught)} منها قابلًا للإرجاع" if taught else f"بدأ «{new_term['name']}»")
    return carried


@bp.post("/api/term/close")
@login_required
def close():
    """Close the term she is in and begin the next one. Asks to be confirmed; checks everything before it writes anything."""
    d = body()
    db, uid, today = current_app.db, g.user["id"], classroom.today_date()
    if d.get("confirm") is not True:
        return jsonify(error="أكّدي أولًا أنك تريدين إنهاء الفصل الحالي وأرشفته"), 400
    term = terms.current(db, uid, today)
    if not term:
        return jsonify(error="لا يوجد فصل دراسي لإنهائه. حدّديه من صفحة التقويم"), 400
    first, last = parse_day(term["starts"]), parse_day(term["ends"])
    if today < first:
        return jsonify(error=f"لم يبدأ «{term['name']}» بعد. إن كان تاريخاه خطأ فعدّليهما من صفحة التقويم بدل أرشفته"), 400
    name = clean_name(d.get("name"))[:60] or next_name(term["name"])
    a, b = parse_day(d.get("starts")), parse_day(d.get("ends"))
    if not a or not b:
        return jsonify(error="اكتبي يوم بداية الفصل الجديد ويوم نهايته"), 400
    if b <= a:
        return jsonify(error="يجب أن تكون نهاية الفصل الجديد بعد بدايته"), 400
    if (b - a).days > MAX_TERM_DAYS:
        return jsonify(error="الفصل الدراسي أطول من المعتاد، راجعي التاريخين"), 400
    eff = min(last, today)          # a term closed before its last day ends today
    if a <= eff:
        return jsonify(error=f"يجب أن يبدأ الفصل الجديد بعد نهاية «{term['name']}» ({share.ar_date(eff.isoformat())})"), 400
    for o in db.execute("SELECT name, starts, ends FROM terms WHERE user_id = ? AND id != ?", (uid, term["id"])).fetchall():
        if a.isoformat() <= o["ends"] and b.isoformat() >= o["starts"]:
            return jsonify(error=f"يتداخل الفصل الجديد مع «{o['name']}» ({share.ar_date(o['starts'])} - {share.ar_date(o['ends'])})"), 400
    if db.execute("SELECT COUNT(*) FROM term_archives WHERE user_id = ?", (uid,)).fetchone()[0] >= MAX_ARCHIVES:
        return jsonify(error=f"وصلتِ إلى الحد الأقصى ({MAX_ARCHIVES} فصلًا مؤرشفًا)"), 400
    if not close_limit.allow(uid):
        return jsonify(error="محاولات كثيرة، انتظري قليلًا"), 429
    snap = summary(db, uid, term, today, last=eff.isoformat())          # worked out first, while the term is still the current one
    try:
        db.execute("UPDATE terms SET archived = 1, ends = ? WHERE id = ? AND user_id = ?", (eff.isoformat(), term["id"], uid))
        aid = db.execute("INSERT INTO term_archives(user_id, term_id, name, starts, ends, orig_ends, closed_on, data, created_at) VALUES (?,?,?,?,?,?,?,?,?)",
                         (uid, term["id"], term["name"], term["starts"], eff.isoformat(), term["ends"], today.isoformat(), json.dumps(snap, ensure_ascii=False), now())).lastrowid
        new_id = db.execute("INSERT INTO terms(user_id, name, starts, ends, created_at) VALUES (?,?,?,?,?)", (uid, name, a.isoformat(), b.isoformat(), now())).lastrowid
        db.execute("UPDATE term_archives SET new_term_id = ? WHERE id = ?", (new_id, aid))
        carried = 0
        if d.get("carry", True) is not False:
            carried = carry_plans(db, uid, term["id"], db.execute("SELECT * FROM terms WHERE id = ?", (new_id,)).fetchone(), today)
        db.commit()
    except Exception:
        db.rollback()
        log.exception("closing a term failed")
        return jsonify(error="تعذّرت أرشفة الفصل ولم يتغير شيء. جرّبي مرة أخرى"), 500
    return jsonify(ok=True, archive_id=aid, term=terms.term_dict(db.execute("SELECT * FROM terms WHERE id = ?", (new_id,)).fetchone()), carried=carried)


@bp.post("/api/term/archives/<int:aid>/reopen")
@login_required
def reopen(aid):
    """Take back the last closing: the term it began goes (with its holidays and its plans), the old term is open again with its last day as it was, and the snapshot is dropped.
    Only the latest archive can be taken back, and only while the term it began is still there."""
    arc = archive_row(aid)
    db, uid = current_app.db, g.user["id"]
    if body().get("confirm") is not True:
        return jsonify(error="أكّدي أولًا أنك تريدين التراجع عن الأرشفة"), 400
    if arc["id"] != db.execute("SELECT MAX(id) FROM term_archives WHERE user_id = ?", (uid,)).fetchone()[0]:
        return jsonify(error="يمكن التراجع عن آخر أرشفة فقط"), 409
    new = db.execute("SELECT * FROM terms WHERE id = ? AND user_id = ? AND archived = 0", (arc["new_term_id"], uid)).fetchone() if arc["new_term_id"] else None
    if not new:
        return jsonify(error="لا يمكن التراجع: الفصل الذي بدأ بعد هذه الأرشفة لم يعد موجودًا"), 409
    try:
        db.execute("DELETE FROM plan_log WHERE user_id = ? AND term_id = ?", (uid, new["id"]))
        db.execute("DELETE FROM terms WHERE id = ? AND user_id = ?", (new["id"], uid))          # its holidays and its plan items follow
        db.execute("UPDATE terms SET archived = 0, ends = ? WHERE id = ? AND user_id = ?", (arc["orig_ends"], arc["term_id"], uid))
        db.execute("DELETE FROM term_archives WHERE id = ?", (arc["id"],))
        db.commit()
    except Exception:
        db.rollback()
        log.exception("taking back a closing failed")
        return jsonify(error="تعذّر التراجع ولم يتغير شيء. جرّبي مرة أخرى"), 500
    return jsonify(ok=True)
