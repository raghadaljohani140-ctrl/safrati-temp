"""«غائب اليوم»: the teacher says on which day (or days, or which periods of one day) she cannot teach.

Her own absence is the one thing the app cannot find out by itself, so she records it here. From her timetable the app finds the periods that will not be held, shows her
BEFORE she confirms what that does to every plan (which lessons are put off, and to when), and when she confirms the plans are laid out again over the periods that are left:
the lessons keep their order, none is deleted, and each plan's change log (plan.py) says what moved. Cancelling an absence brings the lessons back to where they were. For
every class that loses a period she gets a message ready to send through WhatsApp (no student's name in it), and the class's group link when she gave one.

An absence is a whole day (stored with period 0) or a single period of a day. Only today and the days to come can be recorded: a day that has passed changes nothing in a plan
(a lesson not marked done is simply still to come).
"""
import datetime

from flask import Blueprint, current_app, g, jsonify, render_template

from . import classroom, plan, planner, share, terms, timetable
from .db import now
from .planner import parse_day
from .security import Limiter, login_required
from .students import body, clean_name, toint

bp = Blueprint("absence", __name__)
MAX_DAYS = 31          # the longest absence recorded at once
MAX_REASON = 60
HISTORY = 15           # how many past absences the page lists
busy_limit = Limiter(240, 3600)


class Bad(ValueError):
    """A request the teacher can fix: the message is shown to her."""


# ---------------------------------------------------------------- what the plans read
def absent_periods(db, uid, term) -> set:
    """The periods she cannot teach in a term: {(day, period)} for a single period and {(day, None)} for a whole day (the form planner.occurrences takes)."""
    out = set()
    if term:
        for r in db.execute("SELECT day, period FROM absences WHERE user_id = ? AND day >= ? AND day <= ?", (uid, term["starts"], term["ends"])):
            d = parse_day(r["day"])
            if d:
                out.add((d, r["period"] or None))
    return out


# ---------------------------------------------------------------- her timetable
def timetable_by_day(db, uid) -> dict:
    """{weekday (Sunday 0): [{period, time, class_id, class_name, subject_id, subject_name}]}: her periods with the clock times she gave them."""
    times = {r["period"]: (r["starts"], r["ends"]) for r in db.execute("SELECT period, starts, ends FROM schedule_times WHERE user_id = ?", (uid,))}
    out = {}
    for r in db.execute("""SELECT s.day, s.period, s.class_id, s.subject_id, c.name AS class_name, sub.name AS subject_name FROM schedule_slots s
                           JOIN classes c ON c.id = s.class_id JOIN subjects sub ON sub.id = s.subject_id WHERE s.user_id = ? ORDER BY s.day, s.period""", (uid,)):
        t = times.get(r["period"])
        out.setdefault(r["day"], []).append({"period": r["period"], "time": f"{t[0]}–{t[1]}" if t and t[0] and t[1] else "", "class_id": r["class_id"], "class_name": r["class_name"],
                                             "subject_id": r["subject_id"], "subject_name": r["subject_name"]})
    return out


def take(db, uid, term, today, a, b, wanted=None):
    """The periods an absence from day `a` to day `b` takes out of her timetable, and the days that take none with the reason. `wanted`: the periods asked for when only some of
    one day's are. A holiday, a day outside the term, a day she is already absent, a period that is over already: none of them is taken again."""
    start, end = parse_day(term["starts"]), parse_day(term["ends"])
    holidays = terms.holidays_of(db, term["id"])
    have = absent_periods(db, uid, term)
    week = timetable_by_day(db, uid)
    over = plan.past_periods(db, uid, today)
    periods, skipped = [], []
    day = a
    while day <= b:
        iso = day.isoformat()
        slots = week.get(planner.sun0(day), [])
        why = ""
        if not start <= day <= end:
            why = "خارج الفصل الدراسي"
        elif day in holidays:
            why = holidays[day]
        elif (day, None) in have:
            why = "غيابك مسجَّل لهذا اليوم"
        elif not slots:
            why = "لا حصص لك في هذا اليوم"
        else:
            chosen = [s for s in slots if wanted is None or s["period"] in wanted]
            fresh = [s for s in chosen if (day, s["period"]) not in have]
            live = [s for s in fresh if not (day == today and s["period"] in over)]
            periods.extend(dict(s, date=iso, text=share.ar_date(iso)) for s in live)
            if not chosen:
                why = "الحصص المختارة ليست في جدولك هذا اليوم"
            elif not fresh:
                why = "غيابك مسجَّل لهذه الحصص"
            elif not live:
                why = "انتهت حصص هذا اليوم"
        if why:
            skipped.append({"date": iso, "text": share.ar_date(iso), "why": why})
        day += datetime.timedelta(days=1)
    return periods, skipped


def lesson_in(before, p):
    """The title of the lesson her plan had in this period, '' when none."""
    st = before["pairs"].get((p["class_id"], p["subject_id"]))
    if not st:
        return ""
    item = next((i for i in st["items"] if i["status"] == "pending" and plan._covers(i, p["date"], p["period"])), None)
    return item["title"] if item else ""


# ---------------------------------------------------------------- the message for each class
def class_messages(db, uid, periods) -> list:
    """One ready message for every class that loses a period: what is cancelled and that it will be made up. No student's name, no reason. [{class_id, class_name, text, wa, group}]"""
    links = {r["id"]: r["whatsapp"] for r in db.execute("SELECT id, whatsapp FROM classes WHERE user_id = ?", (uid,))}
    classes = {}
    for p in periods:
        c = classes.setdefault(p["class_id"], {"name": p["class_name"], "days": {}})
        c["days"].setdefault(p["date"], {"text": plan.short_date(p["text"]), "items": []})["items"].append(p)
    out = []
    for cid in sorted(classes, key=lambda i: classes[i]["name"]):
        c = classes[cid]
        lines, count = [], 0
        for iso in sorted(c["days"]):
            d = c["days"][iso]
            lines.append(f"• {d['text']}: " + " و".join(f"{i['subject_name']} (الحصة {i['period']})" for i in sorted(d["items"], key=lambda i: i["period"])))
            count += len(d["items"])
        closing = "لن تُقام الحصة المذكورة أعلاه لغياب المعلمة، وسيُعوَّض الدرس في حصة قادمة بإذن الله." if count == 1 \
            else "لن تُقام الحصص المذكورة أعلاه لغياب المعلمة، وسيُعوَّض ما فات في حصص قادمة بإذن الله."
        text = "\n".join(["السلام عليكم ورحمة الله وبركاته", f"تنبيه إلى {c['name']}:", *lines, closing])
        out.append({"class_id": cid, "class_name": c["name"], "count": count, "text": text, "wa": share.wa_text_url(text), "group": links.get(cid) or ""})
    return out


# ---------------------------------------------------------------- the lines of the page
def entries(rows) -> list:
    """Her absences as lines: neighbouring whole days with the same reason are one line, and the periods of one day are one line."""
    out = []
    for r in rows:
        whole = r["period"] == 0
        d = parse_day(r["day"])
        last = out[-1] if out else None
        if whole and last and last["whole"] and last["reason"] == r["reason"] and d == parse_day(last["to"]) + datetime.timedelta(days=1):
            last["to"], last["ids"] = r["day"], last["ids"] + [r["id"]]
        elif not whole and last and not last["whole"] and last["from"] == r["day"]:
            last["periods"], last["ids"] = last["periods"] + [r["period"]], last["ids"] + [r["id"]]
        else:
            out.append({"from": r["day"], "to": r["day"], "whole": whole, "periods": [] if whole else [r["period"]], "reason": r["reason"], "ids": [r["id"]]})
    for x in out:
        x["from_text"], x["to_text"] = share.ar_date(x["from"]), share.ar_date(x["to"])
        x["days"] = (parse_day(x["to"]) - parse_day(x["from"])).days + 1
    return out


def periods_of_rows(db, uid, rows, today) -> list:
    """The periods of her timetable that these absence rows take (for the message of an absence already recorded)."""
    week = timetable_by_day(db, uid)
    over = plan.past_periods(db, uid, today)
    out = []
    for r in rows:
        d = parse_day(r["day"])
        if not d:
            continue
        for s in week.get(planner.sun0(d), []):
            if (r["period"] == 0 or r["period"] == s["period"]) and not (d == today and s["period"] in over):
                out.append(dict(s, date=r["day"], text=share.ar_date(r["day"])))
    return out


def page_data(db, uid, today) -> dict:
    """Everything the screen shows: the term, her timetable by weekday (for choosing periods), her coming absences with their messages, and the latest past ones."""
    term = terms.current(db, uid, today)
    rows = db.execute("SELECT * FROM absences WHERE user_id = ? ORDER BY day, period", (uid,)).fetchall()
    iso = today.isoformat()
    coming, past = [r for r in rows if r["day"] >= iso], [r for r in rows if r["day"] < iso]
    upcoming = entries(coming)
    by_id = {r["id"]: r for r in coming}
    for x in upcoming:
        x["messages"] = class_messages(db, uid, periods_of_rows(db, uid, [by_id[i] for i in x["ids"]], today))
    return {"today": iso, "today_text": share.ar_date(iso), "term": terms.term_dict(term), "has_schedule": bool(timetable_by_day(db, uid)),
            "week": {str(k): v for k, v in timetable_by_day(db, uid).items()}, "upcoming": upcoming, "history": list(reversed(entries(past)))[:HISTORY]}


def why_of(days, wanted) -> str:
    """The cause written in the change log of a plan: «غياب الأحد 8 نوفمبر», «غياب من … إلى …», «غياب … (الحصة 2)»."""
    first, last = plan.short_date(share.ar_date(days[0])), plan.short_date(share.ar_date(days[-1]))
    if len(days) > 1:
        return f"غياب من {first} إلى {last}"
    if wanted:
        ps = sorted(wanted)
        return f"غياب {first} (الحصة {ps[0]})" if len(ps) == 1 else f"غياب {first} (الحصص {' و'.join(str(p) for p in ps)})"
    return f"غياب {first}"


# ---------------------------------------------------------------- reading a request
def read_request(db, uid, today):
    """(term, from, to, wanted, reason) from what she sent, or Bad with what to fix."""
    data = body()
    term = terms.current(db, uid, today)
    if not term:
        raise Bad("حدّدي بداية الفصل الدراسي ونهايته أولًا من صفحة التقويم")
    a = parse_day(data.get("from")) or today
    b = parse_day(data.get("to")) or a
    if a < today:
        raise Bad("اختاري اليوم أو يومًا قادمًا: الغياب في يوم مضى لا يغيّر الخطة")
    if b < a:
        raise Bad("يجب ألا يسبق آخر يوم من الغياب أوله")
    if (b - a).days >= MAX_DAYS:
        raise Bad(f"الفترة أطول من {MAX_DAYS} يومًا")
    end = parse_day(term["ends"])
    if a > end:
        raise Bad("هذا اليوم بعد نهاية الفصل الدراسي")
    b = min(b, end)
    raw = data.get("periods")
    wanted = None
    if raw:
        if not isinstance(raw, list) or any(not isinstance(p, int) or isinstance(p, bool) for p in raw):
            raise Bad("حصص غير صحيحة")
        wanted = {p for p in raw if 1 <= p <= timetable.MAX_PERIODS}
        if not wanted:
            raise Bad("اختاري حصة واحدة على الأقل، أو اختاري اليوم كاملًا")
        if a != b:
            raise Bad("اختيار حصص محددة يكون ليوم واحد")
    return term, a, b, wanted, clean_name(data.get("reason"))[:MAX_REASON]


def outline(db, uid, term, today, a, b, wanted):
    """What the absence would take and do, nothing changed: (periods, skipped, effects, extra) where `extra` is what the plans are laid out without."""
    periods, skipped = take(db, uid, term, today, a, b, wanted)
    if not periods:
        why = "؛ ".join(sorted({s["why"] for s in skipped})) or "لا حصص"
        raise Bad("لا توجد حصص تتأثر بهذا الغياب (" + why + ")")
    days = sorted({p["date"] for p in periods})
    extra = {(parse_day(d), None) for d in days} if wanted is None else {(parse_day(p["date"]), p["period"]) for p in periods}
    before = plan.snapshot(db, uid, today)
    effects = plan.effects_of(db, uid, before, plan.snapshot(db, uid, today, extra))
    for p in periods:
        p["lesson"] = lesson_in(before, p)
    return periods, skipped, effects, days


def outline_json(periods, skipped, effects, days):
    return {"periods": periods, "skipped": skipped, "effects": effects, "days": days, "count": len(periods),
            "classes": sorted({p["class_name"] for p in periods}), "lessons": sum(1 for p in periods if p["lesson"])}


# ---------------------------------------------------------------- pages and API
@bp.get("/absent")
@login_required
def page():
    return render_template("absent.html")


@bp.get("/api/absence")
@login_required
def data():
    return jsonify(page_data(current_app.db, g.user["id"], classroom.today_date()))


@bp.post("/api/absence/preview")
@login_required
def preview():
    """What recording this absence would do to her plans, without recording it."""
    if not busy_limit.allow(g.user["id"]):
        return jsonify(error="محاولات كثيرة. حاولي بعد قليل"), 429
    db, uid, today = current_app.db, g.user["id"], classroom.today_date()
    try:
        term, a, b, wanted, _reason = read_request(db, uid, today)
        periods, skipped, effects, days = outline(db, uid, term, today, a, b, wanted)
    except Bad as e:
        return jsonify(error=str(e)), 400
    return jsonify(outline_json(periods, skipped, effects, days))


@bp.post("/api/absence")
@login_required
def record():
    """Record the absence: the periods it takes are left out of the plans, the lessons are laid out again over the periods left, and the change is written in each plan's log."""
    if not busy_limit.allow(g.user["id"]):
        return jsonify(error="محاولات كثيرة. حاولي بعد قليل"), 429
    db, uid, today = current_app.db, g.user["id"], classroom.today_date()
    try:
        term, a, b, wanted, reason = read_request(db, uid, today)
        periods, skipped, _effects, days = outline(db, uid, term, today, a, b, wanted)
    except Bad as e:
        return jsonify(error=str(e)), 400
    try:
        with plan.realigning(db, uid, why_of(days, wanted), today) as res:
            if wanted is None:
                for d in days:
                    db.execute("DELETE FROM absences WHERE user_id = ? AND day = ?", (uid, d))          # the whole day takes in the periods recorded one by one
                    db.execute("INSERT INTO absences(user_id, day, period, reason, created_at) VALUES (?,?,0,?,?)", (uid, d, reason, now()))
            else:
                for p in periods:
                    db.execute("INSERT OR IGNORE INTO absences(user_id, day, period, reason, created_at) VALUES (?,?,?,?,?)", (uid, p["date"], p["period"], reason, now()))
        db.commit()
    except Exception:
        db.rollback()
        raise
    out = outline_json(periods, skipped, res["effects"], days)
    out["messages"] = class_messages(db, uid, periods)
    return jsonify(result=out, **page_data(db, uid, today)), 201


@bp.delete("/api/absence")
@login_required
def cancel():
    """Cancel absences that have not passed: the periods are teachable again, so the lessons come back to where they were."""
    db, uid, today = current_app.db, g.user["id"], classroom.today_date()
    ids = [i for i in (body().get("ids") or []) if isinstance(i, int) and not isinstance(i, bool)][:120]
    rows = []
    if ids:
        rows = db.execute(f"SELECT * FROM absences WHERE user_id = ? AND day >= ? AND id IN ({','.join('?' * len(ids))}) ORDER BY day, period", [uid, today.isoformat(), *ids]).fetchall()
    if not rows:
        return jsonify(error="لا يوجد غياب مسجَّل لإلغائه"), 404
    days = sorted({r["day"] for r in rows})
    wanted = {r["period"] for r in rows if r["period"]} if len(days) == 1 and all(r["period"] for r in rows) else None
    try:
        with plan.realigning(db, uid, "إلغاء " + why_of(days, wanted), today) as res:
            db.execute(f"DELETE FROM absences WHERE user_id = ? AND id IN ({','.join('?' * len(rows))})", [uid, *[r["id"] for r in rows]])
        db.commit()
    except Exception:
        db.rollback()
        raise
    return jsonify(result={"cancelled": len(rows), "effects": res["effects"]}, **page_data(db, uid, today))
