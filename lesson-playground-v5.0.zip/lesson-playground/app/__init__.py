from flask import Flask, g, jsonify, render_template, request, session

from . import db as dbm
from .config import Config
from .security import csrf_token


def create_app(**over):
    cfg = Config(**over)
    app = Flask(__name__)
    app.config.update(SECRET_KEY=cfg.secret, MAX_CONTENT_LENGTH=(cfg.max_upload_mb + 1) * 1024 * 1024, SESSION_COOKIE_HTTPONLY=True,
                      SESSION_COOKIE_SAMESITE="Lax", SESSION_COOKIE_SECURE=cfg.cookie_secure, JSON_AS_ASCII=False, TEMPLATES_AUTO_RELOAD=False)
    app.cfg = cfg
    app.db = dbm.connect(cfg.db_path)
    dbm.init(app.db)

    from .auth import bp as auth_bp
    from .lessons import bp as lessons_bp
    from .api import bp as api_bp
    app.register_blueprint(auth_bp)
    app.register_blueprint(lessons_bp)
    app.register_blueprint(api_bp)
    from .subscribe import bp as subscribe_bp
    from .admin import bp as admin_bp
    from .students import bp as students_bp
    from .today import bp as today_bp
    from .classroom import bp as classroom_bp
    from .curriculum import bp as curriculum_bp
    from .terms import bp as terms_bp
    from .schedule import bp as schedule_bp
    from .plan import bp as plan_bp
    from .absence import bp as absence_bp
    from .points import bp as points_bp
    from .reports import bp as reports_bp
    from .exams import bp as exams_bp
    from .homework import bp as homework_bp
    from .termend import bp as termend_bp
    from .backup import bp as backup_bp
    app.register_blueprint(students_bp)
    app.register_blueprint(today_bp)
    app.register_blueprint(classroom_bp)
    app.register_blueprint(curriculum_bp)
    app.register_blueprint(terms_bp)
    app.register_blueprint(schedule_bp)
    app.register_blueprint(plan_bp)
    app.register_blueprint(absence_bp)
    app.register_blueprint(points_bp)
    app.register_blueprint(reports_bp)
    app.register_blueprint(exams_bp)
    app.register_blueprint(homework_bp)
    app.register_blueprint(termend_bp)
    app.register_blueprint(backup_bp)
    app.register_blueprint(subscribe_bp)
    app.register_blueprint(admin_bp)

    @app.before_request
    def load_user():
        uid = session.get("uid")
        g.user = app.db.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone() if uid else None
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            if request.path == "/api/books" and request.method == "POST":
                request.max_content_length = (cfg.max_book_mb + 1) * 1024 * 1024          # a textbook is bigger than a lesson file (set before the form is read)
            elif request.path in ("/api/backup/preview", "/api/backup/restore") and request.method == "POST":
                from .backup import MAX_FILE_MB
                request.max_content_length = (MAX_FILE_MB + 1) * 1024 * 1024          # so is the file of a backup
            from .security import check_csrf
            check_csrf()

    @app.after_request
    def headers(resp):
        resp.headers["Content-Security-Policy"] = ("default-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; "
                                                    "img-src 'self' data:; script-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Referrer-Policy"] = "same-origin"
        if request.path.startswith(("/api/", "/lessons", "/dashboard", "/present", "/subscribe", "/admin", "/students", "/start", "/curriculum", "/schedule", "/calendar", "/plan", "/absent", "/points", "/reports", "/exams", "/homework", "/term", "/backup")):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    from . import identity, textfmt
    app.jinja_env.filters["ar_questions"] = textfmt.questions
    app.jinja_env.filters["ar_students"] = textfmt.students
    app.jinja_env.filters["ar_points"] = textfmt.points
    app.jinja_env.filters["contact"] = identity.contact

    @app.context_processor
    def inject():
        return {"csrf": csrf_token(), "user": g.get("user")}

    @app.errorhandler(403)
    def e403(e):
        return render_template("error.html", code=403, msg="انتهت صلاحية الصفحة، حدّثي الصفحة وأعيدي المحاولة"), 403

    @app.errorhandler(404)
    def e404(e):
        return render_template("error.html", code=404, msg="الصفحة غير موجودة"), 404

    @app.errorhandler(413)
    def e413(e):
        from .backup import MAX_FILE_MB
        limit = cfg.max_book_mb if request.path == "/api/books" else MAX_FILE_MB if request.path.startswith("/api/backup") else cfg.max_upload_mb          # a book, a backup: bigger than a lesson file
        msg = f"الملف كبير، الحد الأقصى {limit} ميجابايت"
        if request.path.startswith("/api/"):
            return jsonify(error=msg), 413
        return render_template("error.html", code=413, msg=msg), 413

    return app
