"""The term plan: which lesson is taught in which period.

A plan is built from four facts the teacher already gave the app: the lessons of her book in order (and how many periods each needs), the periods the
timetable gives this class in this subject, the days of the term, and the days nobody teaches (holidays, her own absences). The lessons are laid over the
periods in order. Nothing is stored about WHERE a lesson falls: it is worked out again whenever the plan is shown, so a lesson she marks done, a day she is
absent or a holiday added later moves everything after it by itself, in the same order, and no lesson is ever dropped.

What is stored is only what she said (the order, the periods, done or not) and the day each lesson was due when the plan was made; a lesson is late when that
day has passed and it is not done. Everything here is plain Python on dates and numbers, so it can be tested without a database.
"""
import bisect
import datetime
from typing import NamedTuple

from . import textfmt


class Occ(NamedTuple):
    """One teaching period: a day and the period's number in the school day."""
    day: datetime.date
    period: int


def sun0(day: datetime.date) -> int:
    """The weekday the way a Saudi timetable counts it: Sunday 0 ... Saturday 6."""
    return (day.weekday() + 1) % 7


def parse_day(text) -> datetime.date | None:
    try:
        return datetime.date.fromisoformat(str(text)[:10])
    except ValueError:
        return None


def occurrences(slots, start: datetime.date, end: datetime.date, holidays=(), absent=(), first: datetime.date | None = None):
    """The periods of one class in one subject from `first` (the start of the term when not given) to the end of the term, in order.
    slots: (weekday, period) pairs of the timetable. holidays: days nobody teaches. absent: (day, period) pairs the teacher cannot teach, or (day, None) for a whole day."""
    begin = max(start, first) if first else start
    if end < begin:
        return []
    by_day = {}
    for d, p in slots:
        by_day.setdefault(int(d), []).append(int(p))
    off = set(holidays)
    gone = set(absent)
    out, day = [], begin
    while day <= end:
        if day not in off and (day, None) not in gone:
            for p in sorted(by_day.get(sun0(day), ())):
                if (day, p) not in gone:
                    out.append(Occ(day, p))
        day += datetime.timedelta(days=1)
    return out


def merged(items) -> dict:
    """{follower id: leader id} for the lessons taught together with the pending lesson just before them: the follower takes no period of its own. A lesson whose partner is
    not pending (done, skipped, or not before it in the order) is an ordinary lesson again, and a lesson that leads one cannot follow another."""
    place = {it["id"]: n for n, it in enumerate(items)}
    pending = {it["id"] for it in items if it["status"] == "pending"}
    out = {}
    for it in items:
        lead = it.get("together")
        if lead is None or lead not in pending or it["status"] == "skipped":
            continue
        if place[lead] >= place[it["id"]] or lead in out:
            continue
        out[it["id"]] = lead
    return out


def periods_of(it, together) -> int:
    """The periods a lesson takes from the timetable: its own, or none when it is taught together with the lesson before it."""
    return 0 if it["id"] in together else max(1, int(it["periods"]))


def assign(items, occs):
    """Lay the pending lessons over the periods in order. items: dicts with id, periods, status (and `together`, the lesson it is taught with). Returns
    ({id: (first Occ, last Occ)}, unplaced) where `unplaced` is the number of periods that no period of the term is left for (the lessons that do not fit, in order,
    are not given a date)."""
    plan, i = {}, 0
    unplaced = 0
    together = merged(items)
    for it in items:
        if it["status"] != "pending":
            continue
        lead = together.get(it["id"])
        if lead is not None:
            if lead in plan:
                plan[it["id"]] = plan[lead]          # the same periods as the lesson it is taught with
            continue
        need = max(1, int(it["periods"]))
        if i + need <= len(occs):
            plan[it["id"]] = (occs[i], occs[i + need - 1])
            i += need
        else:
            unplaced += need
            i = len(occs)
    return plan, unplaced


def baseline(items, occs):
    """The day every lesson is due when the plan is made: all the lessons that are not skipped, in order, over the periods from the start. {id: Occ of its last period}."""
    due, i = {}, 0
    together = merged(items)
    for it in items:
        if it["status"] == "skipped":
            continue
        lead = together.get(it["id"])
        if lead is not None:
            if lead in due:
                due[it["id"]] = due[lead]
            continue
        need = max(1, int(it["periods"]))
        if i + need <= len(occs):
            due[it["id"]] = occs[i + need - 1]
            i += need
        else:
            break
    return due


def summary(items, occs_ahead, today: datetime.date, term_end: datetime.date | None = None):
    """Where the plan stands: done / pending / skipped lessons, the share done (by periods), the lessons that should be done by now, and whether the periods left are
    enough for the lessons left."""
    counted = [it for it in items if it["status"] != "skipped"]
    together = merged(items)
    total = sum(periods_of(it, together) for it in counted)
    done = sum(periods_of(it, together) for it in counted if it["status"] == "done")
    pending = [it for it in counted if it["status"] == "pending"]
    need = sum(periods_of(it, together) for it in pending)
    late = [it for it in pending if it.get("due") and it["due"] < today]
    left = len(occs_ahead)
    weeks = None
    if term_end is not None:
        weeks = max(0, -(-((term_end - today).days + 1) // 7))
    return {"lessons": len(counted), "done": sum(1 for it in counted if it["status"] == "done"), "pending": len(pending),
            "skipped": len(items) - len(counted), "periods_total": total, "periods_done": done,
            "percent": textfmt.percent(done, total) or 0, "late": [it["id"] for it in late],
            "periods_left": left, "periods_needed": need, "spare": left - need, "weeks_left": weeks,
            "current": pending[0]["id"] if pending else None}


MAX_SHARED_PERIODS = 4          # sharing the periods out never gives one lesson more than this (she can give a lesson up to 6 herself)


def suggest_periods(weights, total: int, cap=None):
    """How many periods each lesson could take so that the lessons fill `total` periods: in proportion to the weights (pages), every lesson at least one, the
    rest given by the largest remainder. When there are not enough periods even for one each, every lesson gets one. With `cap` no lesson gets more than that,
    so plenty of periods are not poured into a few lessons: what is left over stays free for revision and exams."""
    n = len(weights)
    if n == 0:
        return []
    if total <= n:
        return [1] * n
    top = max(1, int(cap)) if cap else None
    w = [max(0.0, float(x)) for x in weights]
    s = sum(w)
    if s <= 0:
        w, s = [1.0] * n, float(n)
    spare = total - n
    raw = [spare * x / s for x in w]
    out = [1 + int(r) for r in raw]
    if top:
        out = [min(top, v) for v in out]
    left = total - sum(out)
    order = sorted(range(n), key=lambda i: raw[i] - int(raw[i]), reverse=True)
    while left > 0:
        gave = False
        for i in order:
            if left <= 0:
                break
            if top is None or out[i] < top:
                out[i] += 1
                left -= 1
                gave = True
        if not gave:
            break
    return out


def merge_ideas(items, shortage: int, weights=None):
    """Pairs of neighbouring pending lessons that could be taught together, the shortest first, to win back `shortage` periods. [(id, id), ...] without any lesson
    appearing twice. The teacher decides; nothing is changed here."""
    together = merged(items)
    taken = set(together) | set(together.values())
    pend = [it for it in items if it["status"] == "pending"]          # neighbours in the plan: a review or an exam between two lessons keeps them apart
    if shortage <= 0 or len(pend) < 2:
        return []
    weights = weights or {}
    ok = lambda it: it.get("kind", "lesson") == "lesson" and it["id"] not in taken
    pairs = [(float(weights.get(a["id"], 1)) + float(weights.get(b["id"], 1)), a["id"], b["id"]) for a, b in zip(pend, pend[1:]) if ok(a) and ok(b)]
    used, out = set(), []
    for _w, a, b in sorted(pairs):
        if a in used or b in used:
            continue
        out.append((a, b))
        used.update((a, b))
        if len(out) >= shortage:
            break
    return out


def shift_due(dues, before, after, today: datetime.date):
    """When the periods of the term change (a day she is absent, a holiday, a new timetable), the lessons keep their place in the row of periods: the lesson that was due in the
    5th period from today is due in the 5th period from today after the change. dues: [(date, period) or None]; before / after: the Occ lists from today, before and after.
    Returns the new [(date, period) or None]: a lesson that was already late (due before today) is left as it was, and one that no period is left for gets None."""
    keys = [(o.day, o.period) for o in before]
    out = []
    for d in dues:
        if d is None or d[0] < today:
            out.append(d)
            continue
        p = bisect.bisect_left(keys, (d[0], d[1] or 0))
        if p >= len(before):
            out.append(d)
        elif p < len(after):
            out.append((after[p].day, after[p].period))
        else:
            out.append(None)
    return out
