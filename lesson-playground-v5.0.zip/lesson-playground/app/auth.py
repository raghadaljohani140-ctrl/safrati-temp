import sqlite3

from flask import Blueprint, current_app, g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from . import identity
from .db import now, setting
from .security import Limiter, login_required

bp = Blueprint("auth", __name__)
login_limit = Limiter(8, 600)
register_limit = Limiter(5, 3600)
register_day_limit = Limiter(20, 86400)
DUMMY = generate_password_hash("not-a-real-password")


def _page(template, **kw):
    return render_template(template, **kw)


@bp.get("/")
def home():
    if g.user:
        return redirect(url_for("lessons.dashboard"))
    return _page("home.html")


CLOSED = "التسجيل الجديد متوقف مؤقتًا. جرّبي لاحقًا"


def registrations_open() -> bool:
    return setting(current_app.db, "registrations_open", "1") != "0"          # the manager can close new sign-ups from the platform settings


@bp.get("/register")
def register():
    return _page("auth.html", mode="register", error="" if registrations_open() else CLOSED, form={})


TAKEN = {"email": "هذا البريد مسجل من قبل، سجّلي دخولك", "phone": "هذا الرقم مسجل من قبل، سجّلي دخولك"}


def _taken(kind, who) -> bool:
    col = "email" if kind == "email" else "phone"
    return bool(current_app.db.execute(f"SELECT 1 FROM users WHERE {col} = ?", (who,)).fetchone())


@bp.post("/register")
def register_post():
    f = request.form
    name, pw = f.get("name", "").strip()[:60], f.get("password", "")
    raw = (f.get("identifier") or f.get("email") or "").strip()            # a mobile number or an e-mail in the one box («email» is the name the older form used)
    kind, who = identity.classify(raw)
    err = ""
    if not registrations_open():
        err = CLOSED
    elif not (register_limit.allow(request.remote_addr) and register_day_limit.allow(request.remote_addr)):
        err = "محاولات كثيرة، جرّبي لاحقًا"
    elif len(name) < 2:
        err = "اكتبي اسمك"
    elif not kind:
        err = identity.BAD_EMAIL if "@" in raw else identity.BAD_ANY
    elif len(pw) < 8:
        err = "كلمة المرور 8 خانات على الأقل"
    elif pw != f.get("password2", pw):
        err = "كلمتا المرور غير متطابقتين"
    elif f.get("terms") != "1":
        err = "لازم توافقين على الشروط والخصوصية"
    elif _taken(kind, who):
        err = TAKEN[kind]
    cur = None
    if not err:
        email, phone = (who, None) if kind == "email" else (identity.placeholder_email(who), who)
        try:
            cur = current_app.db.execute("INSERT INTO users(email, phone, name, pass_hash, created_at) VALUES (?,?,?,?,?)",
                                         (email, phone, name, generate_password_hash(pw), now()))
            current_app.db.commit()
        except sqlite3.IntegrityError:                    # the same number or address was taken a moment ago by someone else
            current_app.db.rollback()
            err = TAKEN[kind]
    if err:
        return _page("auth.html", mode="register", error=err, form={"name": name, "identifier": raw}), 400
    session.clear()
    session["uid"] = cur.lastrowid
    return redirect(url_for("lessons.dashboard"))


@bp.get("/login")
def login():
    return _page("auth.html", mode="login", error="", form={})


def _who(raw: str) -> str:
    """What was typed at sign-in as one key: an e-mail (anything with an @) in lower case, or a mobile number in its one shape, so 0501234567 and +966 50 123 4567 are the same."""
    raw = raw.strip()
    return raw.lower() if "@" in raw else (identity.normalize_phone(raw) or raw.lower())


def _find(who: str):
    if "@" in who:
        return None if who.endswith(identity.PLACEHOLDER) else current_app.db.execute("SELECT * FROM users WHERE email = ?", (who,)).fetchone()
    return current_app.db.execute("SELECT * FROM users WHERE phone = ?", (who,)).fetchone()


@bp.post("/login")
def login_post():
    raw, pw = (request.form.get("identifier") or request.form.get("email") or "").strip(), request.form.get("password", "")
    who = _who(raw)
    key = (request.remote_addr, who)
    if not login_limit.allow(key):
        return _page("auth.html", mode="login", error="محاولات كثيرة، انتظري 10 دقائق ثم أعيدي", form={"identifier": raw}), 429
    row = _find(who)
    ok = check_password_hash(row["pass_hash"] if row else DUMMY, pw)       # the same work whether or not the number or e-mail exists
    if not (row and ok):
        return _page("auth.html", mode="login", error="رقم الجوال أو البريد أو كلمة المرور غير صحيحة", form={"identifier": raw}), 400
    login_limit.reset(key)
    session.clear()
    session["uid"] = row["id"]
    return redirect(url_for("lessons.dashboard"))


@bp.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("auth.home"))


@bp.get("/terms")
def terms():
    return _page("terms.html")
