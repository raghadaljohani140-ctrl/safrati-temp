"""Signing up and signing in with a mobile number or an e-mail, whichever the teacher writes.

Nothing is verified: no code is sent, no message goes out and no outside service is used. The number is only a name to sign in with.
A mobile number is kept in one shape (966501234567) however it was typed, so «0501234567», «+966 50 123 4567» and «٠٥٠١٢٣٤٥٦٧» are the same account.
"""
import re

from .security import EMAIL

PLACEHOLDER = "@phone.invalid"      # the e-mail column cannot be empty: an account made with a mobile number keeps an address on a domain that can never exist («.invalid»)
BAD_EMAIL = "اكتبي بريدًا إلكترونيًا صحيحًا"
BAD_ANY = "اكتبي رقم جوال صحيحًا (مثل 0501234567) أو بريدًا إلكترونيًا صحيحًا"

_DIGITS = {ord(a): str(i % 10) for i, a in enumerate("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹")}          # Arabic-Indic and Persian digits
_NOISE = re.compile(r"[\s().\-‎‏‪-‮⁦-⁩]")                 # spaces, dashes, dots, brackets and the invisible direction marks a phone adds
_SAUDI = re.compile(r"5\d{8}")                                                          # a Saudi mobile number without its 0 or its country code
_OTHER = re.compile(r"[1-9]\d{7,14}")                                                   # any other country: its code and the number, 8 to 15 digits (E.164)


def digits(text) -> str:
    """The digits of a text and nothing else, Arabic-Indic ones turned into 0-9."""
    return re.sub(r"\D", "", (text or "").translate(_DIGITS))


def normalize_phone(text):
    """966501234567 for every way of writing that number, or None when it is not a mobile number.
    A Saudi number may be written 05…, 5…, 966… or with + / 00 in front; a number from another country needs the + (or 00) and its country code."""
    s = _NOISE.sub("", (text or "").translate(_DIGITS))
    plus = s.startswith("+")
    s = s.lstrip("+")
    if not (s.isascii() and s.isdigit()):
        return None
    if s.startswith("00"):
        plus, s = True, s[2:]
    if not plus:
        if len(s) == 10 and s.startswith("05"):
            s = "966" + s[1:]
        elif len(s) == 9 and s.startswith("5"):
            s = "966" + s
        elif not s.startswith("966"):
            return None                                  # without a + a number can only be a Saudi one
    if s.startswith("966"):
        rest = s[3:]
        rest = rest[1:] if rest.startswith("0") else rest          # «+966 0501234567»: the 0 does not belong there
        return "966" + rest if _SAUDI.fullmatch(rest) else None    # in Saudi Arabia a mobile number only, never a landline
    return s if _OTHER.fullmatch(s) else None


def classify(text):
    """('email', 'a@b.co') or ('phone', '966501234567') for what a teacher wrote to sign up, or (None, '') when it is neither.
    Anything with an @ is an e-mail and anything else must be a mobile number."""
    t = (text or "").strip()
    if "@" in t:
        e = t.lower()
        return ("email", e) if EMAIL.match(e) and not e.endswith(PLACEHOLDER) else (None, "")
    p = normalize_phone(t)
    return ("phone", p) if p else (None, "")


def placeholder_email(phone: str) -> str:
    return phone + PLACEHOLDER


def local_phone(phone) -> str:
    """966501234567 is shown 0501234567; a number from another country keeps its +."""
    if re.fullmatch(r"9665\d{8}", phone or ""):
        return "0" + phone[3:]
    return "+" + phone if phone else ""


def contact(who) -> str:
    """What the manager's pages show for a person: the e-mail, or the mobile number when she signed up with that (a row or a dict with email and phone)."""
    def pick(key):
        try:
            return who[key]
        except (KeyError, IndexError):
            return None
    email, phone = pick("email") or "", pick("phone") or ""
    if email and not email.endswith(PLACEHOLDER):
        return email
    return local_phone(phone) if phone else ""


def search_digits(q) -> str:
    """The part of a search that can be looked for inside mobile numbers: 0501234567, +966 50 123 4567 and 4567 all find 966501234567.
    Nothing when the search is not number-like or too short to mean anything."""
    t = (q or "").translate(_DIGITS)
    if re.search(r"[^\d\s+\-().]", t):
        return ""                                        # words and e-mail addresses are searched as they are
    d = digits(t)
    for lead in ("00966", "966", "0"):
        if d.startswith(lead):
            d = d[len(lead):]
            break
    return d if len(d) >= 3 else ""
