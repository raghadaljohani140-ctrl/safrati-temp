"""Reports for one class and for one student: the points, the answers they gave in the questions of the lessons, and where the plan of the class stands.

Nothing is kept here: everything is added up when the page asks, from what the other screens keep (points.py, the results of the questions, plan.py). The class and the subject
are checked as hers first, and the numbers of a class never include a student of another class."""
import csv
import datetime
import io

from flask import Blueprint, Response, current_app, g, jsonify, render_template, request

from . import classroom, homework, plan, points, scoring, share, textfmt
from .security import login_required
from .students import class_row, level, student_row

bp = Blueprint("reports", __name__)
DAYS_SHOWN = 14          # the days of the little chart of points
HOMEWORK_SHOWN = 8       # the latest homework told in a student's report


def day_start(day: str) -> float:
    """The moment (epoch seconds) her day begins; the answers are kept with their moment, the points with their day."""
    return datetime.datetime.combine(datetime.date.fromisoformat(day), datetime.time.min, classroom.TZ).timestamp()


def percent(correct, answered):
    return textfmt.percent(correct, answered)


def window(lo, hi, today, n=DAYS_SHOWN) -> list:
    """The days of the chart: the last n days of the period (fewer when the period is shorter), the last one being today or the end of the period."""
    end = min(datetime.date.fromisoformat(hi), today) if hi else today
    start = end - datetime.timedelta(days=n - 1)
    if lo and datetime.date.fromisoformat(lo) > start:
        start = datetime.date.fromisoformat(lo)
    return [(start + datetime.timedelta(days=i)).isoformat() for i in range((end - start).days + 1)] if start <= end else []


def series(db, uid, days, where, args) -> list:
    """Points per day over `days` ([{day, text, points}]), for the extra condition given (a class, or a student)."""
    if not days:
        return []
    got = {r["day"]: r["n"] for r in db.execute(f"SELECT p.day, SUM(p.amount) AS n FROM points p WHERE p.user_id = ? AND {where} AND p.day BETWEEN ? AND ? GROUP BY p.day", [uid, *args, days[0], days[-1]])}
    return [{"day": d, "text": share.ar_date(d), "points": got.get(d, 0)} for d in days]


def answers_sql(where, args, lo, hi):
    """The answers (the results of the questions) of the students picked by `where`, in the period: (sql tail, params)."""
    sql, out = f" WHERE {where}", list(args)
    if lo:
        sql += " AND r.created_at >= ?"
        out.append(day_start(lo))
    if hi:
        sql += " AND r.created_at < ?"
        out.append(day_start(hi) + 86400)
    return sql, out


def point_filter(subject):
    return (" AND p.subject_id = ?", [subject["id"]]) if subject else ("", [])


def homework_where(uid, class_id, subject, lo, hi):
    """The homework a report counts: what she gave this class (in this subject, between these days) by the day it was given."""
    cond, args = "a.user_id = ? AND a.class_id = ?", [uid, class_id]
    if subject:
        cond, args = cond + " AND a.subject_id = ?", args + [subject["id"]]
    if lo:
        cond, args = cond + " AND a.given_date >= ?", args + [lo]
    if hi:
        cond, args = cond + " AND a.given_date <= ?", args + [hi]
    return cond, args


def homework_figures(rows) -> dict:
    """The figures of a set of lines (done, partial, missing, pending): the share is of the students she has already checked, so a homework she has not reached yet does not lower it."""
    done, partial, missing, pending = (sum(r[k] or 0 for r in rows) for k in ("done", "partial", "missing", "pending"))
    checked = done + partial + missing
    return {"done": done, "partial": partial, "missing": missing, "pending": pending, "checked": checked, "percent": textfmt.percent(done, checked)}


SUM_STATUS = "SUM(s.status = 'done') AS done, SUM(s.status = 'partial') AS partial, SUM(s.status = 'missing') AS missing, SUM(s.status = 'pending') AS pending"


def class_homework(db, uid, cls, subject, lo, hi) -> dict:
    """What she gave the class in the period and how it went: totals, and a line per student (only the students of this class can be on its homework)."""
    cond, args = homework_where(uid, cls["id"], subject, lo, hi)
    given = db.execute(f"SELECT COUNT(*) FROM assignments a WHERE {cond}", args).fetchone()[0]
    per = [dict(r) for r in db.execute(f"SELECT s.student_id, {SUM_STATUS} FROM assignments a JOIN assignment_students s ON s.assignment_id = a.id WHERE {cond} GROUP BY s.student_id", args)]
    for r in per:
        r.update(homework_figures([r]))
    return {"given": given, **homework_figures(per), "students": per}


def student_homework(db, uid, st, subject, lo, hi) -> dict:
    """The same for one student, with her latest ones and how each went."""
    cond, args = homework_where(uid, st["class_id"], subject, lo, hi)
    cond, args = cond + " AND s.student_id = ?", args + [st["id"]]
    base = f"FROM assignments a JOIN assignment_students s ON s.assignment_id = a.id WHERE {cond}"
    given = db.execute(f"SELECT COUNT(*) {base}", args).fetchone()[0]
    tot = db.execute(f"SELECT {SUM_STATUS} {base}", args).fetchone()
    recent = [{"id": r["id"], "title": r["title"], "icon": homework.KINDS[r["kind"]][1], "due_text": share.ar_date(r["due_date"]) if r["due_date"] else "", "given_text": share.ar_date(r["given_date"]),
               "status": r["status"], "status_name": homework.STATUS_NAMES[r["status"]], "subject": r["subject"] or ""} for r in db.execute(
        f"SELECT a.id, a.title, a.kind, a.due_date, a.given_date, s.status, (SELECT name FROM subjects sj WHERE sj.id = a.subject_id) AS subject {base} ORDER BY a.given_date DESC, a.id DESC LIMIT ?", [*args, HOMEWORK_SHOWN])]
    return {"given": given, **homework_figures([dict(tot)]), "recent": recent}


# ---------------------------------------------------------------- a class
def class_report(db, uid, cls, subject, period, lo, hi, today, pairs=None) -> dict:
    sid = subject["id"] if subject else None
    rows = scoring.standings(points.totals_by_student(db, uid, cls["id"], sid, lo, hi))
    if subject:
        for r in rows:          # the answers to the questions are not sorted by subject: next to a subject only the points are told
            r.update(answered=None, correct=None, percent=None, level=None)
    else:
        sql, args = answers_sql("s.class_id = ? AND s.user_id = ?", [cls["id"], uid], lo, hi)
        got = {r["student_id"]: r for r in db.execute(f"SELECT r.student_id, COUNT(*) AS answered, COALESCE(SUM(r.correct), 0) AS correct FROM results r JOIN students s ON s.id = r.student_id{sql} GROUP BY r.student_id", args)}
        for r in rows:
            a = got.get(r["student_id"])
            n, ok = (a["answered"], a["correct"]) if a else (0, 0)
            r.update(answered=n, correct=ok, percent=percent(ok, n), level=level(percent(ok, n)))
    for r in rows:
        r["last_text"] = share.ar_date(r["last_day"]) if r["last_day"] else ""
    top, more = scoring.podium(rows)
    silent = [r["name"] for r in rows if r["points"] <= 0 and not r["answered"]]
    days = window(lo, hi, today)
    plans = [p for p in (plan.pairs(db, uid, today) if pairs is None else pairs) if p["class_id"] == cls["id"] and (not subject or p["subject_id"] == subject["id"])]          # (the end-of-term summary works out every plan once and hands them in)
    return {"class": {"id": cls["id"], "name": cls["name"]}, "subject": {"id": subject["id"], "name": subject["name"]} if subject else None, "period": period, "period_name": scoring.NAMES[period],
            "first": lo, "last": hi, "first_text": share.ar_date(lo) if lo else "", "last_text": share.ar_date(hi) if hi else "", "answers": not subject,
            "students": len(rows), "points": sum(r["points"] for r in rows), "awards": sum(r["awards"] for r in rows), "ranked": sum(1 for r in rows if r["rank"]),
            "rows": rows, "top": top, "more": more, "silent": silent, "days": series(db, uid, days, "p.class_id = ?", [cls["id"]]) if sid is None else
            series(db, uid, days, "p.class_id = ? AND p.subject_id = ?", [cls["id"], sid]),
            "plans": [{k: p[k] for k in ("subject_id", "subject_name", "percent", "late", "current", "need", "book")} for p in plans],
            "homework": class_homework(db, uid, cls, subject, lo, hi)}


@bp.get("/reports")
@login_required
def page():
    return render_template("reports.html")


@bp.get("/api/reports/class/<int:cid>")
@login_required
def class_api(cid):
    cls, subject, period, lo, hi = points.scope({**request.args, "class_id": cid})
    return jsonify(class_report(current_app.db, g.user["id"], cls, subject, period, lo, hi, classroom.today_date()))


@bp.get("/api/reports/class/<int:cid>/csv")
@login_required
def class_csv(cid):
    """The report of the class as a sheet that Excel opens (UTF-8 with its mark, so the Arabic is not broken)."""
    cls, subject, period, lo, hi = points.scope({**request.args, "class_id": cid})
    rep = class_report(current_app.db, g.user["id"], cls, subject, period, lo, hi, classroom.today_date())
    out = io.StringIO()
    w = csv.writer(out, lineterminator="\r\n")
    w.writerow([f"{rep['class']['name']}" + (f" - {rep['subject']['name']}" if rep["subject"] else ""), rep["period_name"] + (f" ({rep['first']} - {rep['last']})" if rep["first"] else "")])
    hw = rep["homework"]
    by = {x["student_id"]: x for x in hw["students"]}
    head = ["الترتيب", "الطالب", "النقاط", "مرات المنح", "آخر مشاركة"] + (["الأسئلة", "الصحيحة", "النسبة"] if rep["answers"] else []) + (["الواجبات المنجزة", "الواجبات المسجّلة"] if hw["given"] else [])
    w.writerow(head)
    for r in rep["rows"]:
        x = by.get(r["student_id"], {"done": 0, "checked": 0})          # (the sheet only has the columns of the homework when there was some in the period)
        w.writerow([r["rank"] or "", safe(r["name"]), r["points"], r["awards"], r["last_day"]] + ([r["answered"], r["correct"], "" if r["percent"] is None else r["percent"]] if rep["answers"] else [])
                   + ([x["done"], x["checked"]] if hw["given"] else []))
    return Response("﻿" + out.getvalue(), mimetype="text/csv", headers={"Content-Disposition": f'attachment; filename="class-{cls["id"]}-{period}.csv"', "Cache-Control": "no-store"})


def safe(text) -> str:
    """A cell that starts with = + - or @ would be run as a formula by a spreadsheet: it is made plain text."""
    text = str(text)
    return "'" + text if text[:1] in ("=", "+", "-", "@", "\t", "\r") else text


# ---------------------------------------------------------------- one student
def student_report(db, uid, st, subject, period, lo, hi, today) -> dict:
    sid = subject["id"] if subject else None
    cls = db.execute("SELECT id, name FROM classes WHERE id = ? AND user_id = ?", (st["class_id"], uid)).fetchone()
    board = scoring.standings(points.totals_by_student(db, uid, st["class_id"], sid, lo, hi))
    me = next((r for r in board if r["student_id"] == st["id"]), {"points": 0, "awards": 0, "rank": None})
    cond, extra = point_filter(subject)
    day_cond = (" AND p.day >= ?" if lo else "") + (" AND p.day <= ?" if hi else "")
    bounds = [x for x in (lo, hi) if x]
    by_subject = [{"subject_id": r["subject_id"], "name": r["name"] or "بلا مادة", "points": r["n"], "awards": r["awards"]} for r in db.execute(
        f"SELECT p.subject_id, sj.name AS name, SUM(p.amount) AS n, COUNT(*) AS awards FROM points p LEFT JOIN subjects sj ON sj.id = p.subject_id WHERE p.user_id = ? AND p.student_id = ?{cond}{day_cond} GROUP BY p.subject_id ORDER BY n DESC",
        [uid, st["id"], *extra, *bounds])]
    recent = db.execute(f"{points.ENTRY} WHERE p.user_id = ? AND p.student_id = ?{cond}{day_cond} ORDER BY p.day DESC, p.created_at DESC, p.id DESC LIMIT 15", [uid, st["id"], *extra, *bounds]).fetchall()
    answers, decks = None, []
    if not subject:
        sql, args = answers_sql("r.student_id = ? AND r.user_id = ?", [st["id"], uid], lo, hi)
        n, ok = db.execute(f"SELECT COUNT(*), COALESCE(SUM(r.correct), 0) FROM results r{sql}", args).fetchone()
        answers = {"answered": n, "correct": ok, "percent": percent(ok, n), "level": level(percent(ok, n))}
        decks = [{"title": r["deck_title"], "answered": r["n"], "correct": r["ok"], "percent": percent(r["ok"], r["n"])} for r in db.execute(
            f"SELECT r.deck_title, COUNT(*) AS n, SUM(r.correct) AS ok, MAX(r.created_at) AS last FROM results r{sql} GROUP BY COALESCE(r.deck_id, r.deck_title) ORDER BY last DESC LIMIT 20", args)]
    days = window(lo, hi, today)
    where, wargs = ("p.student_id = ?" + cond, [st["id"], *extra])
    rep = {"student": {"id": st["id"], "name": st["name"], "class_id": st["class_id"], "class_name": cls["name"] if cls else ""},
           "subject": {"id": subject["id"], "name": subject["name"]} if subject else None, "period": period, "period_name": scoring.NAMES[period],
           "first": lo, "last": hi, "first_text": share.ar_date(lo) if lo else "", "last_text": share.ar_date(hi) if hi else "",
           "points": me["points"], "awards": me["awards"], "rank": me["rank"], "ranked": sum(1 for r in board if r["rank"]), "classmates": len(board),
           "by_subject": by_subject, "days": series(db, uid, days, where, wargs), "recent": [points.entry(r) for r in recent], "answers": answers, "decks": decks,
           "homework": student_homework(db, uid, st, subject, lo, hi)}
    rep["text"] = summary_text(rep)
    rep["wa"] = share.wa_text_url(rep["text"])
    return rep


def summary_text(rep) -> str:
    """A few lines about one student that the teacher may copy or send by WhatsApp herself (the app sends nothing)."""
    lines = [f"ملخص الطالب {rep['student']['name']} · {rep['student']['class_name']}"]
    span = f" ({rep['first_text']} - {rep['last_text']})" if rep["first"] and rep["last"] and rep["first"] != rep["last"] else (f" ({rep['first_text']})" if rep["first"] else "")
    lines.append(f"الفترة: {rep['period_name']}{span}")
    if rep["subject"]:
        lines.append(f"المادة: {rep['subject']['name']}")
    lines.append(f"النقاط: {textfmt.points(rep['points'])}" + (f" · المركز {rep['rank']} من {rep['classmates']}" if rep["rank"] else ""))
    a = rep["answers"]
    if a and a["answered"]:
        lines.append(f"الأسئلة: {a['correct']} صحيحة من {a['answered']} ({a['percent']}٪) · {a['level']}")
    h = rep.get("homework")
    if h and h["checked"]:
        lines.append(f"الواجبات: أنجز {h['done']} من {h['checked']}" + (f" · أنجز جزءًا {h['partial']}" if h["partial"] else "") + (f" · لم ينجز {h['missing']}" if h["missing"] else ""))
    return "\n".join(lines)


@bp.get("/api/reports/student/<int:sid>")
@login_required
def student_api(sid):
    st = student_row(sid)
    cls, subject, period, lo, hi = points.scope(request.args, need_class=False)
    return jsonify(student_report(current_app.db, g.user["id"], st, subject, period, lo, hi, classroom.today_date()))
