"""The school calendar of the teacher: the term (its first and last day) and the days nobody teaches (holidays, exam weeks). She enters them once; the plan reads them."""
import datetime

from flask import Blueprint, current_app, g, jsonify, render_template

from . import classroom, share
from .db import now
from .planner import parse_day
from .security import login_required
from .students import body, clean_name, toint

bp = Blueprint("terms", __name__)
MAX_TERM_DAYS = 250
MAX_RANGE_DAYS = 100


def current(db, uid, today=None):
    """Her term now: the one that holds today, else the nearest one that has not started, else the latest that ended (archived terms are never current)."""
    today = (today or classroom.today_date()).isoformat()
    rows = db.execute("SELECT * FROM terms WHERE user_id = ? AND archived = 0 ORDER BY starts DESC, id DESC", (uid,)).fetchall()
    for r in rows:
        if r["starts"] <= today <= r["ends"]:
            return r
    ahead = [r for r in rows if r["starts"] > today]
    if ahead:
        return ahead[-1]
    return rows[0] if rows else None


def holidays_of(db, term_id) -> dict:
    """{date: label} of the days nobody teaches in a term."""
    out = {}
    for r in db.execute("SELECT day, label FROM calendar_days WHERE term_id = ?", (term_id,)):
        d = parse_day(r["day"])
        if d:
            out[d] = r["label"]
    return out


def term_dict(r):
    if not r:
        return None
    a, b = parse_day(r["starts"]), parse_day(r["ends"])
    return {"id": r["id"], "name": r["name"], "starts": r["starts"], "ends": r["ends"], "starts_text": share.ar_date(r["starts"]), "ends_text": share.ar_date(r["ends"]),
            "weeks": max(1, -(-((b - a).days + 1) // 7)) if a and b else 0}


def ranges_of(rows):
    """The holidays as ranges: neighbouring days with the same name are one line («إجازة الخريف · من … إلى …»)."""
    out = []
    for r in sorted(rows, key=lambda r: r["day"]):
        d = parse_day(r["day"])
        last = out[-1] if out else None
        if last and last["label"] == r["label"] and d == parse_day(last["to"]) + datetime.timedelta(days=1):
            last["to"], last["ids"] = r["day"], last["ids"] + [r["id"]]
        else:
            out.append({"label": r["label"], "from": r["day"], "to": r["day"], "ids": [r["id"]]})
    for x in out:
        x["days"] = len(x["ids"])
        x["from_text"], x["to_text"] = share.ar_date(x["from"]), share.ar_date(x["to"])
    return out


def moved_in(effects) -> int:
    """How many lessons of her plans a change moved (for the line shown after she saves)."""
    return sum(e["moved_count"] for e in effects)


def calendar_data(db, uid):
    term = current(db, uid)
    days = db.execute("SELECT id, day, label FROM calendar_days WHERE term_id = ? ORDER BY day", (term["id"],)).fetchall() if term else []
    today = classroom.today_date()
    return {"term": term_dict(term), "ranges": ranges_of(days), "holidays": len(days), "today": today.isoformat(), "today_text": share.ar_date(today.isoformat())}


@bp.get("/calendar")
@login_required
def page():
    return render_template("calendar.html")


@bp.get("/api/calendar")
@login_required
def data():
    return jsonify(calendar_data(current_app.db, g.user["id"]))


@bp.put("/api/calendar/term")
@login_required
def save_term():
    """The first and last day of the term she is in (made the first time, changed after that; the holidays she entered are kept)."""
    data = body()
    db = current_app.db
    uid = g.user["id"]
    name = clean_name(data.get("name"))[:60] or "الفصل الدراسي"
    a, b = parse_day(data.get("starts")), parse_day(data.get("ends"))
    if not a or not b:
        return jsonify(error="اكتبي يوم بداية الفصل ويوم نهايته"), 400
    if b <= a:
        return jsonify(error="يجب أن تكون نهاية الفصل بعد بدايته"), 400
    if (b - a).days > MAX_TERM_DAYS:
        return jsonify(error="الفصل الدراسي أطول من المعتاد، راجعي التاريخين"), 400
    from . import plan
    term = current(db, uid)
    with plan.realigning(db, uid, "تعديل تاريخي الفصل الدراسي") as res:          # the lessons keep their place in the row of periods when the term changes
        if term:
            db.execute("UPDATE terms SET name = ?, starts = ?, ends = ? WHERE id = ?", (name, a.isoformat(), b.isoformat(), term["id"]))
            db.execute("DELETE FROM calendar_days WHERE term_id = ? AND (day < ? OR day > ?)", (term["id"], a.isoformat(), b.isoformat()))      # a holiday outside the term means nothing
        else:
            db.execute("INSERT INTO terms(user_id, name, starts, ends, created_at) VALUES (?,?,?,?,?)", (uid, name, a.isoformat(), b.isoformat(), now()))
    db.commit()
    return jsonify(**calendar_data(db, uid), moved=moved_in(res["effects"]))


@bp.post("/api/calendar/holidays")
@login_required
def add_holidays():
    """Days nobody teaches, from one day to another (one day when only the first is given). Days outside the term are left out."""
    data = body()
    db = current_app.db
    uid = g.user["id"]
    term = current(db, uid)
    if not term:
        return jsonify(error="حدّدي بداية الفصل الدراسي ونهايته أولًا"), 400
    a = parse_day(data.get("from"))
    b = parse_day(data.get("to")) or a
    if not a or not b or b < a:
        return jsonify(error="اكتبي اليوم، أو من يوم إلى يوم"), 400
    if (b - a).days >= MAX_RANGE_DAYS:
        return jsonify(error=f"الفترة أطول من {MAX_RANGE_DAYS} يومًا"), 400
    label = clean_name(data.get("label"))[:60] or "إجازة"
    start, end = parse_day(term["starts"]), parse_day(term["ends"])
    if b < start or a > end:
        return jsonify(error="هذه الأيام خارج الفصل الدراسي"), 400
    from . import plan
    day, added = a, 0
    with plan.realigning(db, uid, f"إضافة إجازة «{label}»") as res:          # nobody teaches those days: the lessons move to the periods after them
        while day <= b:
            if start <= day <= end:
                cur = db.execute("INSERT INTO calendar_days(user_id, term_id, day, label) VALUES (?,?,?,?) ON CONFLICT(term_id, day) DO UPDATE SET label = excluded.label",
                                 (uid, term["id"], day.isoformat(), label))
                added += cur.rowcount
            day += datetime.timedelta(days=1)
    db.commit()
    return jsonify(**calendar_data(db, uid), moved=moved_in(res["effects"]))


@bp.delete("/api/calendar/holidays")
@login_required
def remove_holidays():
    ids = [toint(x) for x in (body().get("ids") or []) if isinstance(x, int)][:400]
    db = current_app.db
    from . import plan
    with plan.realigning(db, g.user["id"], "حذف إجازة") as res:          # the days are teaching days again: the lessons come back to them
        for hid in ids:
            db.execute("DELETE FROM calendar_days WHERE id = ? AND user_id = ?", (hid, g.user["id"]))
    db.commit()
    return jsonify(**calendar_data(db, g.user["id"]), moved=moved_in(res["effects"]))
