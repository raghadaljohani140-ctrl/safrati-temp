"""«حصة اليوم»: the lesson for the class, made only from the teacher's own file. Nothing is sent anywhere and nothing is paid for.

 * the explanation: the file's text cut into short parts (a heading, a handful of sentences, the key terms the part defines)
 * a quick question after a part, taken from the questions that came from that very part
 * questions for the students to answer by name, from the questions that are left
 * the activities, one tap away

The lesson page, the dashboard and the stage open all of it through ONE deck that the app keeps for the lesson (decks.auto = 1). The teacher never
builds it, it never counts against her deck limit, and it follows her edits: every time she enters, the deck is refreshed with the lesson's questions.
Nothing about the subject or the class of the lesson is ever shown (meta.py), and the cover and footer lines of a file are left out (aiq.is_noise)."""
import json
import re

from flask import Blueprint, abort, current_app, g, jsonify, redirect, request, url_for

from . import aiq, grounding as G, meta as lesson_meta
from .db import now
from .lessons import GAMES, PRIMARY, mine, q_dict
from .security import login_required

bp = Blueprint("today", __name__)

MIN_WORDS = 12                                    # a part shorter than this joins the one before it
MAX_WORDS = 95                                    # a part longer than this is cut at a sentence end
MAX_POINTS = 7
CHECK_ORDER = ("tf", "cloze", "mcq", "short", "qa", "review")            # the lightest question first: it is asked in the middle of the explanation
ASK_ORDER = ("qa", "review", "short", "mcq", "cloze", "tf")              # for the students to answer by name: open questions first
MAX_ASK = 8
CONTINUED = {"تابع", "تتمه", "تكمله", "يتبع", "بقيه", "للمتابعه", "تابع الدرس"}
_END = re.compile(r"[.!؟?؛،,…]$")
_BULLET = re.compile(r"^[\s•\-–—*·●▪◦]+|^\s*\d{1,2}[\).]\s+")
_SENTENCE_END = re.compile(r"(?<=[.!؟?؛])\s+")


# ---------------------------------------------------------------- the file's text -> parts
def _clean_line(line: str) -> str:
    line = _BULLET.sub("", line).strip()
    return re.sub(r"\s{2,}", " ", line)


def _usable(line: str) -> bool:
    return bool(line) and not aiq.is_noise(line)


def _words(s: str) -> int:
    return len(aiq.WORD.findall(s))


def _is_heading(line: str, nxt: str, first: bool) -> bool:
    """A short line that names what follows: the first line of a slide or a page, or a short line above a longer one. A short bullet among bullets is not a heading."""
    w = _words(line)
    if not 1 <= w <= 6 or (_END.search(line) and not line.endswith(":")):
        return False
    if aiq.DEF_RE.match(line) or aiq.COLON_RE.match(line):          # a definition is a sentence of the lesson, not its title
        return False
    return first or (bool(nxt) and _words(nxt) >= max(8, 2 * w))


def _sentences(lines: list[str]) -> list[str]:
    out = []
    for line in lines:
        for s in _SENTENCE_END.split(line):
            s = s.strip().rstrip(".").strip()
            if _words(s) < 3:
                continue
            s = lesson_meta.strip_mentions(s) if lesson_meta.mentions(s) else s
            if _words(s) >= 3 and not lesson_meta.mentions(s) and not aiq.is_noise(s):
                out.append(s)
    return out


def _lines_of(raw: str) -> list[str]:
    """The usable lines of one block. A line that is only the subject or the class («مادة الأحياء», «الصف الثاني المتوسط») is the file's cover, never a heading or a point."""
    out = []
    for x in raw.split("\n"):
        line = _clean_line(x)
        if line and lesson_meta.mentions(line):
            line = lesson_meta.strip_mentions(line)
            if _words(line) < 2:
                continue
        if _usable(line):
            out.append(line)
    return out


def _sections(text: str) -> list[dict]:
    """[{heading, sentences}] in the order of the file. A heading starts a section; so does a new slide or page that has no heading."""
    sections, cur = [], None
    for raw in re.split(r"\n\s*\n", text):
        lines = _lines_of(raw)
        for i, line in enumerate(lines):
            if _is_heading(line, lines[i + 1] if i + 1 < len(lines) else "", first=i == 0):
                cur = {"heading": line.rstrip(":").strip(), "lines": []}
                sections.append(cur)
            else:
                if cur is None:
                    cur = {"heading": "", "lines": []}
                    sections.append(cur)
                cur["lines"].append(line)
        if cur is not None and cur["lines"]:
            cur = None                       # a blank line ends a section that has its text (a heading alone waits for the text that follows)
    out = []
    for s in sections:
        sents = _sentences(s["lines"])
        if sents:
            out.append({"heading": s["heading"], "sentences": sents})
    return out


def _chunks(sentences: list[str]) -> list[list[str]]:
    """Cut a long run of sentences at sentence ends into pieces a class can follow in one go."""
    chunks, cur, n = [], [], 0
    for s in sentences:
        w = _words(s)
        if cur and (n + w > MAX_WORDS or len(cur) >= MAX_POINTS):
            chunks.append(cur)
            cur, n = [], 0
        cur.append(s)
        n += w
    if cur:
        chunks.append(cur)
    return chunks


def _terms(sentences: list[str]) -> list[dict]:
    out = []
    for s in sentences:
        m = aiq.DEF_RE.match(s) or aiq.COLON_RE.match(s)
        if m and len(m["term"].split()) <= 4:
            definition = " ".join(m["def"].split()[:28])
            out.append({"term": m["term"].strip(), "def": definition})
    return out[:4]


def parts_of(text: str) -> list[dict]:
    """The explanation: parts with a title, their sentences (the points) and the terms they define."""
    secs = _sections(text)
    raw, seen = [], set()
    for sec in secs:
        sents = []
        for s in sec["sentences"]:
            k = G.norm(s)
            if k not in seen:                                  # the same sentence is never explained twice
                seen.add(k)
                sents.append(s)
        for i, chunk in enumerate(_chunks(sents)):
            raw.append({"heading": sec["heading"] if i == 0 else (sec["heading"] + " (تابع)" if sec["heading"] else ""), "sentences": chunk})
    merged: list[dict] = []
    for p in raw:                                              # a very short run of sentences with no heading of its own joins the part before it
        w = sum(_words(x) for x in p["sentences"])
        if merged and not p["heading"] and w < MIN_WORDS and len(merged[-1]["sentences"]) + len(p["sentences"]) <= MAX_POINTS:
            merged[-1]["sentences"] += p["sentences"]
        else:
            merged.append(p)
    if len(merged) > 1 and not merged[0]["heading"] and sum(_words(x) for x in merged[0]["sentences"]) < MIN_WORDS and len(merged[0]["sentences"]) + len(merged[1]["sentences"]) <= MAX_POINTS:
        merged[1] = {"heading": merged[1]["heading"], "sentences": merged[0]["sentences"] + merged[1]["sentences"]}
        merged.pop(0)
    parts, last_title = [], ""
    for i, p in enumerate(merged, 1):
        terms = _terms(p["sentences"])
        title = p["heading"]
        if title and G.norm(title) in CONTINUED:
            title = (last_title + " (تابع)") if last_title else ""
        title = title or (terms[0]["term"] if terms else f"الجزء {i}")
        last_title = re.sub(r"\s*\(تابع\)$", "", title)
        parts.append({"id": i, "title": title[:80], "points": p["sentences"], "terms": terms, "words": sum(_words(s) for s in p["sentences"]),
                      "norm": G.norm(" ".join(p["sentences"]))})
    return parts


# ---------------------------------------------------------------- questions -> the parts they belong to
def _rank(order, kind):
    return order.index(kind) if kind in order else len(order)


def build(title: str, text: str, questions: list[dict]) -> dict:
    parts = parts_of(text)
    used: set = set()                                          # questions already placed
    asked: set = set()                                         # sentences already asked about: one sentence is asked once in the whole lesson, not in three shapes

    def ev_key(q):
        return G.norm(q.get("evidence") or "")

    def home(q):
        ev = ev_key(q)
        return next((p for p in parts if ev and ev in p["norm"]), None)

    homes = {q["id"]: home(q) for q in questions}
    for p in parts:
        mine_q = sorted((q for q in questions if homes[q["id"]] is p), key=lambda q: (_rank(CHECK_ORDER, q["kind"]), q["id"]))
        want = 2 if p["words"] >= 70 and len(mine_q) >= 4 else 1
        p["checks"] = []
        for q in mine_q:
            if len(p["checks"]) < want and q["kind"] != "review" and ev_key(q) not in asked:
                used.add(q["id"])
                asked.add(ev_key(q))
                p["checks"].append(_client(q))
    order = {p["id"]: i for i, p in enumerate(parts)}
    where = lambda q: order[homes[q["id"]]["id"]] if homes[q["id"]] else 999
    rest = sorted((q for q in questions if q["id"] not in used), key=lambda q: (_rank(ASK_ORDER, q["kind"]), where(q), q["id"]))
    chosen: list = []
    per_kind: dict = {}
    for strict in (True, False):                               # first without repeating a sentence; only if that leaves too few, allow it
        for q in rest:
            if len(chosen) >= MAX_ASK or q in chosen or per_kind.get(q["kind"], 0) >= 3:
                continue
            if strict and ev_key(q) and ev_key(q) in asked:
                continue
            chosen.append(q)
            asked.add(ev_key(q))
            per_kind[q["kind"]] = per_kind.get(q["kind"], 0) + 1
        if len(chosen) >= 3:
            break
    chosen.sort(key=lambda q: (where(q), _rank(ASK_ORDER, q["kind"]), q["id"]))
    ask = [{"part": homes[q["id"]]["id"] if homes[q["id"]] else 0, "part_title": homes[q["id"]]["title"] if homes[q["id"]] else "من أسئلتك", "q": _client(q)} for q in chosen]
    for p in parts:
        p.pop("norm", None)
    return {"title": title, "parts": parts, "participation": ask,
            "counts": {"parts": len(parts), "checks": sum(len(p["checks"]) for p in parts), "participation": len(ask), "questions": len(questions)}}


def _client(q: dict) -> dict:
    return {k: q[k] for k in ("id", "kind", "question", "answer", "options", "evidence", "clear")}


# ---------------------------------------------------------------- the lesson's own deck
def lesson_questions(db, lesson_id: int, user_id: int) -> list:
    """The questions a class can be asked: those the file backs, and the teacher's own."""
    return db.execute("SELECT * FROM questions WHERE lesson_id = ? AND user_id = ? AND (clear = 1 OR manual = 1) ORDER BY position, id", (lesson_id, user_id)).fetchall()


def ensure_deck(db, user_id: int, lesson) -> int:
    """The deck the app keeps for this lesson: every game, every usable question, the lesson's title."""
    ids = json.dumps([r["id"] for r in lesson_questions(db, lesson["id"], user_id)])
    games = json.dumps(list(GAMES))
    row = db.execute("SELECT id FROM decks WHERE lesson_id = ? AND user_id = ? AND auto = 1 ORDER BY id LIMIT 1", (lesson["id"], user_id)).fetchone()
    if row:
        db.execute("UPDATE decks SET title = ?, games = ?, question_ids = ?, updated_at = ? WHERE id = ?", (lesson["title"], games, ids, now(), row["id"]))
        deck_id = row["id"]
    else:
        deck_id = db.execute("INSERT INTO decks(user_id, lesson_id, title, games, question_ids, auto, created_at, updated_at) VALUES (?,?,?,?,?,1,?,?)",
                             (user_id, lesson["id"], lesson["title"], games, ids, now(), now())).lastrowid
    db.commit()
    return deck_id


# ---------------------------------------------------------------- pages and data
def stage_args() -> dict:
    """What she chose on the start screen and the stage should start with: the class, the subject, the size of the text, the question on the slide itself."""
    out = {}
    cid = request.args.get("class", "")
    if cid.isdigit():
        out["class"] = cid
    sid = request.args.get("subject", "")
    if sid.isdigit():
        out["subject"] = sid          # the points she gives on the stage are kept in this subject
    if request.args.get("size") in ("md", "lg", "xl"):
        out["size"] = request.args["size"]
    if request.args.get("inline") in ("0", "1"):
        out["inline"] = request.args["inline"]
    return out


@bp.get("/lessons/<int:lid>/today")
@login_required
def today(lid):
    lesson = mine("lessons", lid)
    if lesson["status"] != "ready":
        return redirect(url_for("lessons.lesson", lid=lid))
    return redirect(url_for("lessons.present", did=ensure_deck(current_app.db, g.user["id"], lesson), game="today", **stage_args()))


@bp.get("/lessons/<int:lid>/play/<game>")
@login_required
def play(lid, game):
    lesson = mine("lessons", lid)
    if game not in GAMES:
        abort(404)
    if lesson["status"] != "ready":
        return redirect(url_for("lessons.lesson", lid=lid))
    return redirect(url_for("lessons.present", did=ensure_deck(current_app.db, g.user["id"], lesson), game=game))


@bp.get("/api/lessons/<int:lid>/today")
@login_required
def data(lid):
    lesson = mine("lessons", lid)
    db = current_app.db
    questions = [q_dict(r) for r in lesson_questions(db, lid, g.user["id"])]
    return jsonify(build(lesson["title"], lesson["text"] or "", questions))
