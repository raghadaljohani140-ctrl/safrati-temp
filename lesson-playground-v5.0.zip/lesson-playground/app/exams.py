"""Formal exams: the teacher picks a class, a subject, the lessons or units the exam covers and how many questions of each kind she wants; the app builds the exam from the
lessons' text (examq.py), she edits it, replaces any question (the spares are counted for her), adds her own, and approves it. An approved exam has its A4 paper in Arabic (the
browser prints it or saves it as PDF), its answer key on separate paper, a message for the class's WhatsApp group, and a sheet for the marks of her students.

Everything is the teacher's own: an exam belongs to one of her classes, the marks are kept per student of THAT class, and a question, a lesson or a student of anyone else is
treated as if it did not exist. Nothing is sent from here; the messages are only written for her to copy or open in WhatsApp."""
import csv
import datetime
import io
import json
import logging

from flask import Blueprint, Response, abort, current_app, g, jsonify, redirect, render_template, request, url_for

from . import aiq, billing, examq, share, textfmt
from .classroom import subject_row
from .db import jload, now
from .grounding import norm
from .schedule import put_settings, settings
from .security import Limiter, login_required
from .students import body, class_row, clean_name, toint

log = logging.getLogger(__name__)
bp = Blueprint("exams", __name__)
build_limit = Limiter(30, 3600)          # making an exam reads every lesson she picked: not unlimited
MAX_EXAMS = 300
MAX_SOURCES = 25
MAX_TITLE = 80
STATUS_TEXT = {"draft": "مسودة", "approved": "معتمد"}
ORDINALS = ("الأول", "الثاني", "الثالث", "الرابع", "الخامس", "السادس")
PAPER_TITLES = {          # the sentence at the head of each section of the paper
    "mcq": "اختاري الإجابة الصحيحة فيما يأتي",
    "tf": "ضعي علامة (✓) أمام العبارة الصحيحة وعلامة (✗) أمام العبارة الخاطئة",
    "cloze": "أكملي الفراغات الآتية بما يناسبها",
    "qa": "أجيبي عن الأسئلة الآتية",
    "short": "أكملي الجمل الآتية",
    "essay": "أجيبي عن الآتي بالتفصيل",
}


# ---------------------------------------------------------------- what is hers
def exam_row(eid):
    row = current_app.db.execute("SELECT * FROM exams WHERE id = ? AND user_id = ?", (eid, g.user["id"])).fetchone()
    if not row:
        abort(404)                     # another teacher's exam looks exactly like one that does not exist
    return row


def question_row(exam, qid):
    row = current_app.db.execute("SELECT * FROM exam_questions WHERE id = ? AND exam_id = ? AND user_id = ?", (qid, exam["id"], g.user["id"])).fetchone()
    if not row:
        abort(404)
    return row


def need_draft(exam):
    """An approved exam is not changed under her feet: she takes the approval back first (the questions and their marks are what the papers were printed from)."""
    if exam["status"] == "approved":
        return jsonify(error="الاختبار معتمد. ألغي الاعتماد أولًا إن أردتِ تعديل أسئلته"), 409
    return None


def mark_text(x) -> str:
    return examq.fmt_marks(x)


# ---------------------------------------------------------------- reading an exam
def q_dict(r) -> dict:
    return {"id": r["id"], "kind": r["kind"], "kind_name": examq.NAMES[r["kind"]], "question": r["question"], "answer": r["answer"], "options": jload(r["options"], []),
            "evidence": r["evidence"], "source": r["source"], "marks": r["marks"], "marks_text": mark_text(r["marks"]), "position": r["position"],
            "origin": r["origin"], "clear": bool(r["clear"]), "edited": bool(r["edited"])}


def used_rows(db, eid):
    return db.execute("SELECT * FROM exam_questions WHERE exam_id = ? AND state = 'used' ORDER BY position, id", (eid,)).fetchall()


def spare_counts(db, eid, used) -> dict:
    """How many alternatives are left for each kind: what could still be swapped in, one after the other, without asking the same sentence twice."""
    used_dicts = [{"question": r["question"], "evidence": r["evidence"]} for r in used]
    out = {}
    for kind in examq.KINDS:
        rows = db.execute("SELECT question, evidence FROM exam_questions WHERE exam_id = ? AND state = 'spare' AND kind = ? ORDER BY id", (eid, kind)).fetchall()
        out[kind] = examq.spares_left([{"question": r["question"], "evidence": r["evidence"]} for r in rows], used_dicts)
    return out


def score_stats(db, exam) -> dict:
    rows = db.execute("SELECT score, absent FROM exam_scores WHERE exam_id = ?", (exam["id"],)).fetchall()
    got = [r["score"] for r in rows if r["score"] is not None and not r["absent"]]
    total = exam["total"] or 0
    n_class = db.execute("SELECT COUNT(*) FROM students WHERE class_id = ? AND user_id = ?", (exam["class_id"], exam["user_id"])).fetchone()[0]
    out = {"students": n_class, "entered": len(got), "absent": sum(1 for r in rows if r["absent"]), "average": None, "percent": None, "highest": None, "lowest": None, "passed": 0}
    if got:
        avg = sum(got) / len(got)
        out.update(average=round(avg, 2), percent=textfmt.percent(avg, total), highest=max(got), lowest=min(got), passed=sum(1 for x in got if total and x >= total / 2))
    out["missing"] = max(0, n_class - len(got) - out["absent"])
    return out


def exam_dict(db, row, full=True) -> dict:
    cls = db.execute("SELECT id, name, whatsapp FROM classes WHERE id = ?", (row["class_id"],)).fetchone()
    subj = db.execute("SELECT id, name FROM subjects WHERE id = ?", (row["subject_id"],)).fetchone() if row["subject_id"] else None
    used = used_rows(db, row["id"])
    counts = {k: sum(1 for r in used if r["kind"] == k) for k in examq.KINDS}
    out = {"id": row["id"], "title": row["title"], "status": row["status"], "status_text": STATUS_TEXT[row["status"]], "date": row["exam_date"], "date_text": share.ar_date(row["exam_date"]) if row["exam_date"] else "",
           "minutes": row["minutes"], "total": row["total"], "total_text": mark_text(row["total"]), "total_word": textfmt.marks(row["total"]), "header": row["header"], "notes": row["notes"],
           "class": {"id": cls["id"], "name": cls["name"], "whatsapp": cls["whatsapp"]} if cls else None, "subject": {"id": subj["id"], "name": subj["name"]} if subj else None,
           "sources": jload(row["sources"], []), "wanted": jload(row["wanted"], {}), "short": jload(row["short"], {}), "counts": counts, "count": len(used),
           "created_at": row["created_at"], "approved_at": row["approved_at"]}
    if full:
        out["questions"] = [q_dict(r) for r in used]
        out["spares"] = spare_counts(db, row["id"], used)
        out["kinds"] = [{"key": k, "name": examq.NAMES[k], "marks": examq.DEFAULT_MARKS[k]} for k in examq.KINDS]
        out["can_ask_ai"] = row["status"] != "approved" and ai_available(db)
    if row["status"] == "approved":
        out["scores"] = score_stats(db, row)
    return out


def refresh_total(db, eid):
    total = db.execute("SELECT COALESCE(SUM(marks), 0) FROM exam_questions WHERE exam_id = ? AND state = 'used'", (eid,)).fetchone()[0]
    db.execute("UPDATE exams SET total = ?, updated_at = ? WHERE id = ?", (total, now(), eid))
    return total


def renumber(db, eid):
    """The questions in the order of the paper: the sections in their order, and inside a section the order she gave."""
    rows = used_rows(db, eid)
    order = sorted(rows, key=lambda r: (examq.KINDS.index(r["kind"]), r["position"], r["id"]))
    for pos, r in enumerate(order, 1):
        if r["position"] != pos:
            db.execute("UPDATE exam_questions SET position = ? WHERE id = ?", (pos, r["id"]))


def insert_question(db, exam, q: dict, state: str, position: int, origin: str, marks: float):
    return db.execute("INSERT INTO exam_questions(exam_id, user_id, kind, question, answer, options, evidence, source, marks, position, state, origin, clear, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (exam["id"], exam["user_id"], q["kind"], q["question"][:600], q.get("answer", "")[:600], json.dumps(q.get("options") or [], ensure_ascii=False), q.get("evidence", "")[:800],
                       q.get("source", "")[:100], marks, position, state, origin, int(q.get("clear", 1)), now())).lastrowid


# ---------------------------------------------------------------- the lessons an exam may cover
def lesson_text(db, uid, bl) -> str:
    """The text of a book lesson: what was kept from the book, or else the text of the lesson she made from it."""
    text = (bl["text"] or "").strip()
    if len(text) >= 40:
        return text
    row = db.execute("""SELECT l.text FROM plan_items pi JOIN lessons l ON l.id = pi.lesson_id WHERE pi.book_lesson_id = ? AND pi.user_id = ? AND l.user_id = ? AND l.status = 'ready'
                        AND LENGTH(l.text) >= 40 ORDER BY pi.id DESC LIMIT 1""", (bl["id"], uid, uid)).fetchone()
    return (row["text"] or "").strip() if row else ""


def gather_sources(db, uid, d):
    """([(label, text, ref)], [what was left out and why]) for the lessons, the units and the lessons of her own files that she ticked, in the order of the book."""
    skipped, found, seen = [], [], set()
    lesson_ids = [toint(x) for x in (d.get("lessons") or []) if toint(x)]
    unit_ids = [toint(x) for x in (d.get("units") or []) if toint(x)]
    upload_ids = [toint(x) for x in (d.get("uploads") or []) if toint(x)]
    if len(lesson_ids) + len(unit_ids) + len(upload_ids) > 400:
        return [], ["الاختيار كبير جدًا"]
    if unit_ids:
        for u in unit_ids:
            if not db.execute("SELECT 1 FROM book_units WHERE id = ? AND user_id = ?", (u, uid)).fetchone():
                abort(404)
        marks = ",".join("?" * len(unit_ids))
        lesson_ids += [r["id"] for r in db.execute(f"SELECT id FROM book_lessons WHERE user_id = ? AND unit_id IN ({marks}) ORDER BY position, id", (uid, *unit_ids))]
    rows = []
    for bid in dict.fromkeys(lesson_ids):
        bl = db.execute("SELECT bl.*, b.title AS book_title FROM book_lessons bl JOIN books b ON b.id = bl.book_id WHERE bl.id = ? AND bl.user_id = ?", (bid, uid)).fetchone()
        if not bl:
            abort(404)
        rows.append(bl)
    rows.sort(key=lambda r: (r["book_id"], r["position"], r["id"]))
    for bl in rows:
        if bl["kind"] == "exam":
            continue                         # «اختبار الوحدة» is a line of the book, not a lesson with a text
        text = lesson_text(db, uid, bl)
        if len(text) < 40:
            skipped.append(f"«{bl['title']}»: لا يوجد نص لهذا الدرس في الكتاب (الصقي نصه من «الخطة»)")
            continue
        if ("bl", bl["id"]) not in seen:
            seen.add(("bl", bl["id"]))
            found.append((bl["title"], text, {"t": "bl", "id": bl["id"], "label": bl["title"]}))
    for lid in dict.fromkeys(upload_ids):
        les = db.execute("SELECT id, title, text, status FROM lessons WHERE id = ? AND user_id = ?", (lid, uid)).fetchone()
        if not les:
            abort(404)
        if les["status"] != "ready" or len((les["text"] or "").strip()) < 40:
            skipped.append(f"«{les['title']}»: الملف لم يُقرأ بعد أو لا نص فيه")
            continue
        found.append((les["title"], les["text"], {"t": "up", "id": les["id"], "label": les["title"]}))
    return found, skipped


def clean_wanted(raw):
    """{kind: how many} from what the screen sent (0 for a kind she does not want). None when nothing is wanted or the whole is too big."""
    out = {}
    if not isinstance(raw, dict):
        return None
    for k in examq.KINDS:
        n = toint(raw.get(k))
        if n < 0 or n > examq.MAX_PER_KIND:
            return None
        if n:
            out[k] = n
    return out if out and sum(out.values()) <= examq.MAX_QUESTIONS else None


def clean_date(value):
    v = str(value or "").strip()
    if not v:
        return ""
    try:
        return datetime.date.fromisoformat(v).isoformat()
    except ValueError:
        return None


def clean_lines(value, limit=3):
    """A few short lines of text for the head of the paper (the school, the department, …)."""
    lines = [" ".join(str(x).split())[:100] for x in str(value or "").replace("\r", "").split("\n")]
    return "\n".join([x for x in lines if x][:limit])


# ---------------------------------------------------------------- the pages
@bp.get("/exams")
@login_required
def page():
    return render_template("exams.html")


@bp.get("/exams/<int:eid>")
@login_required
def exam_page(eid):
    exam_row(eid)
    return render_template("exam.html", eid=eid)


def paper_data(db, exam) -> dict:
    """What the paper and the key are made of: the exam, and its questions grouped in sections with the letters of the options."""
    d = exam_dict(db, exam, full=False)
    used = [q_dict(r) for r in used_rows(db, exam["id"])]
    sections = []
    for kind in examq.KINDS:
        items = [q for q in used if q["kind"] == kind]
        if not items:
            continue
        for i, q in enumerate(items, 1):
            q["n"] = i
            q["letters"] = examq.letters(len(q["options"]))
            q["lines"] = {"qa": 1 if q["marks"] <= 1 else 2, "short": 1 if q["marks"] <= 1 else 2, "essay": max(4, min(10, int(q["marks"] * 2)))}.get(kind, 0)          # ruled lines left for the answer
            longest = max((len(o) for o in q["options"]), default=0)
            q["cols"] = 4 if len(q["options"]) <= 4 and longest <= 14 else 2 if longest <= 42 else 1          # the options side by side when they are short
            q["parts"] = q["question"].split(aiq.BLANK) if kind == "cloze" else None          # the text around the blanks of a cloze
            q["correct_letter"] = q["letters"][q["options"].index(q["answer"])] if kind == "mcq" and q["answer"] in q["options"] else ""
        sec_marks = sum(q["marks"] for q in items)
        for q in items:
            q["marks_word"] = textfmt.marks(q["marks"])
        sections.append({"kind": kind, "ordinal": ORDINALS[len(sections)] if len(sections) < len(ORDINALS) else str(len(sections) + 1), "title": PAPER_TITLES[kind] if not (kind == "essay" and len(items) == 1) else "أجيبي عن السؤال الآتي بالتفصيل",
                         "marks": sec_marks, "marks_text": mark_text(sec_marks), "marks_word": textfmt.marks(sec_marks), "items": items})
    d["sections"] = sections
    d["header_lines"] = [x for x in (exam["header"] or "").split("\n") if x]
    d["draft"] = exam["status"] != "approved"
    return d


@bp.get("/exams/<int:eid>/print")
@login_required
def paper(eid):
    exam = exam_row(eid)
    return render_template("exam_paper.html", e=paper_data(current_app.db, exam))


@bp.get("/exams/<int:eid>/key")
@login_required
def key(eid):
    exam = exam_row(eid)
    return render_template("exam_key.html", e=paper_data(current_app.db, exam))


# ---------------------------------------------------------------- the list, what she can choose from, making an exam
@bp.get("/api/exams")
@login_required
def listing():
    db = current_app.db
    cid = toint(request.args.get("class_id"))
    sql, args = "SELECT * FROM exams WHERE user_id = ?", [g.user["id"]]
    if cid:
        class_row(cid)
        sql, args = sql + " AND class_id = ?", args + [cid]
    rows = db.execute(sql + " ORDER BY id DESC LIMIT 200", args).fetchall()
    return jsonify(exams=[exam_dict(db, r, full=False) for r in rows])


@bp.get("/api/exams/sources")
@login_required
def sources():
    """What an exam of this class and subject may cover: the lessons of the book she teaches the class (by unit, which are done in the plan, which have a text), and her own lessons."""
    db = current_app.db
    uid = g.user["id"]
    cid, sid = toint(request.args.get("class_id")), toint(request.args.get("subject_id"))
    class_row(cid)
    if sid:
        subject_row(sid)
    link = db.execute("SELECT book_id FROM class_subjects WHERE user_id = ? AND class_id = ? AND subject_id = ?", (uid, cid, sid)).fetchone() if sid else None
    book = db.execute("SELECT id, title FROM books WHERE id = ? AND user_id = ?", (link["book_id"], uid)).fetchone() if link and link["book_id"] else None
    units, done = [], set()
    if book:
        if sid:
            done = {r["book_lesson_id"] for r in db.execute("SELECT book_lesson_id FROM plan_items WHERE user_id = ? AND class_id = ? AND subject_id = ? AND status = 'done'", (uid, cid, sid))}
        by_unit = {r["id"]: {"id": r["id"], "title": r["title"], "lessons": []} for r in db.execute("SELECT id, title FROM book_units WHERE book_id = ? ORDER BY position, id", (book["id"],))}
        loose = {"id": None, "title": "", "lessons": []}
        for r in db.execute("SELECT id, unit_id, title, kind, text FROM book_lessons WHERE book_id = ? AND user_id = ? ORDER BY position, id", (book["id"], uid)):
            if r["kind"] == "exam":
                continue
            has_text = len((r["text"] or "").strip()) >= 40 or bool(lesson_text(db, uid, r))
            (by_unit.get(r["unit_id"]) or loose)["lessons"].append({"id": r["id"], "title": r["title"], "kind": r["kind"], "has_text": has_text, "done": r["id"] in done})
        units = ([loose] if loose["lessons"] else []) + [u for u in by_unit.values() if u["lessons"]]
    uploads = [{"id": r["id"], "title": r["title"], "subject": r["subject"]} for r in db.execute(
        "SELECT id, title, subject FROM lessons WHERE user_id = ? AND status = 'ready' AND LENGTH(text) >= 40 ORDER BY id DESC LIMIT 100", (uid,))]
    return jsonify(book=dict(book) if book else None, units=units, uploads=uploads, kinds=[{"key": k, "name": examq.NAMES[k], "marks": examq.DEFAULT_MARKS[k], "count": examq.DEFAULT_COUNTS[k]} for k in examq.KINDS],
                   header=settings(db, uid).get("exam_header", ""))


@bp.post("/api/exams")
@login_required
def create():
    db = current_app.db
    uid = g.user["id"]
    d = body()
    cls = class_row(toint(d.get("class_id")))
    sid = toint(d.get("subject_id")) or None
    subject = subject_row(sid) if sid else None
    if db.execute("SELECT COUNT(*) FROM exams WHERE user_id = ?", (uid,)).fetchone()[0] >= MAX_EXAMS:
        return jsonify(error=f"وصلتِ إلى الحد الأقصى ({MAX_EXAMS} اختبار). احذفي اختبارًا قديمًا أولًا"), 400
    wanted = clean_wanted(d.get("wanted"))
    if not wanted:
        return jsonify(error=f"اختاري عدد الأسئلة من نوع واحد على الأقل (حتى {examq.MAX_PER_KIND} من كل نوع و{examq.MAX_QUESTIONS} في الاختبار)"), 400
    day = clean_date(d.get("date"))
    if day is None:
        return jsonify(error="تاريخ الاختبار غير صحيح"), 400
    minutes = toint(d.get("minutes"))
    if minutes < 0 or minutes > 600:
        return jsonify(error="زمن الاختبار بالدقائق بين 0 و600"), 400
    found, skipped = gather_sources(db, uid, d)
    if len(found) > MAX_SOURCES:
        return jsonify(error=f"اختاري حتى {MAX_SOURCES} درسًا للاختبار الواحد"), 400
    if not found:
        why = (" · ".join(skipped[:3]) + ".") if skipped else ""
        return jsonify(error="اختاري درسًا واحدًا على الأقل له نص. " + why, skipped=skipped), 400
    if not build_limit.allow(uid):
        return jsonify(error="أنشأتِ اختبارات كثيرة خلال ساعة، جرّبي بعد قليل"), 429
    total = None
    if str(d.get("total") or "").strip():
        try:
            total = float(d.get("total"))
        except (TypeError, ValueError):
            total = -1
        if not (0.5 <= total <= 1000):
            return jsonify(error="الدرجة الكلية بين نصف درجة و1000"), 400
    pools = [(label, examq.pool_of(text)) for label, text, _ in found]
    chosen, spares, short = examq.allocate(pools, wanted)
    marks = examq.distribute(total, [q["kind"] for q in chosen]) if total and chosen else None
    if total and chosen and marks is None:
        return jsonify(error=f"الدرجة الكلية {examq.fmt_marks(total)} لا تكفي لـ {len(chosen)} سؤالًا (أقل درجة للسؤال نصف درجة)"), 400
    title = clean_name(d.get("title"))[:MAX_TITLE] or ("اختبار " + (subject["name"] + " — " if subject else "") + cls["name"])
    header = clean_lines(d.get("header")) if "header" in d else settings(db, uid).get("exam_header", "")
    cur = db.execute("INSERT INTO exams(user_id, class_id, subject_id, title, exam_date, minutes, status, sources, wanted, short, header, notes, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                     (uid, cls["id"], sid, title, day, minutes, "draft", json.dumps([ref for _, _, ref in found], ensure_ascii=False), json.dumps(wanted), json.dumps(short),
                      header, clean_lines(d.get("notes"), 2), now(), now()))
    exam = db.execute("SELECT * FROM exams WHERE id = ?", (cur.lastrowid,)).fetchone()
    for i, q in enumerate(chosen):
        insert_question(db, exam, q, "used", i + 1, "auto", marks[i] if marks else examq.DEFAULT_MARKS[q["kind"]])
    for q in spares:
        insert_question(db, exam, q, "spare", 0, "auto", examq.DEFAULT_MARKS[q["kind"]])
    refresh_total(db, exam["id"])
    if "header" in d:
        put_settings(db, uid, {"exam_header": header})
    db.commit()
    out = exam_dict(db, db.execute("SELECT * FROM exams WHERE id = ?", (exam["id"],)).fetchone())
    return jsonify(exam=out, skipped=skipped), 201


@bp.get("/api/exams/<int:eid>")
@login_required
def detail(eid):
    return jsonify(exam=exam_dict(current_app.db, exam_row(eid)))


@bp.patch("/api/exams/<int:eid>")
@login_required
def edit(eid):
    """The title, the day, the time and the head of the paper may change at any time; they are not what the paper was approved for."""
    db = current_app.db
    exam = exam_row(eid)
    d = body()
    patch = {}
    if "title" in d:
        t = clean_name(d.get("title"))[:MAX_TITLE]
        if len(t) < 2:
            return jsonify(error="اكتبي عنوانًا للاختبار"), 400
        patch["title"] = t
    if "date" in d:
        day = clean_date(d.get("date"))
        if day is None:
            return jsonify(error="تاريخ الاختبار غير صحيح"), 400
        patch["exam_date"] = day
    if "minutes" in d:
        m = toint(d.get("minutes"))
        if m < 0 or m > 600:
            return jsonify(error="زمن الاختبار بالدقائق بين 0 و600"), 400
        patch["minutes"] = m
    if "header" in d:
        patch["header"] = clean_lines(d.get("header"))
    if "notes" in d:
        patch["notes"] = clean_lines(d.get("notes"), 2)
    if patch:
        sets = ", ".join(f"{k} = ?" for k in patch)
        db.execute(f"UPDATE exams SET {sets}, updated_at = ? WHERE id = ?", (*patch.values(), now(), eid))
        if "header" in patch:
            put_settings(db, g.user["id"], {"exam_header": patch["header"]})
        db.commit()
    return jsonify(exam=exam_dict(db, exam_row(eid)))


@bp.delete("/api/exams/<int:eid>")
@login_required
def delete(eid):
    exam_row(eid)
    db = current_app.db
    db.execute("DELETE FROM exams WHERE id = ? AND user_id = ?", (eid, g.user["id"]))          # its questions and its marks go with it
    db.commit()
    return jsonify(ok=True)


@bp.post("/api/exams/<int:eid>/copy")
@login_required
def copy(eid):
    """The same questions for another class of hers (a draft: she looks at it and approves it again)."""
    db = current_app.db
    uid = g.user["id"]
    exam = exam_row(eid)
    cls = class_row(toint(body().get("class_id")))
    if db.execute("SELECT COUNT(*) FROM exams WHERE user_id = ?", (uid,)).fetchone()[0] >= MAX_EXAMS:
        return jsonify(error=f"وصلتِ إلى الحد الأقصى ({MAX_EXAMS} اختبار). احذفي اختبارًا قديمًا أولًا"), 400
    title = (exam["title"] + " (" + cls["name"] + ")")[:MAX_TITLE]
    cur = db.execute("INSERT INTO exams(user_id, class_id, subject_id, title, exam_date, minutes, status, sources, wanted, short, header, notes, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                     (uid, cls["id"], exam["subject_id"], title, "", exam["minutes"], "draft", exam["sources"], exam["wanted"], "{}", exam["header"], exam["notes"], now(), now()))
    new = db.execute("SELECT * FROM exams WHERE id = ?", (cur.lastrowid,)).fetchone()
    for r in used_rows(db, eid):
        insert_question(db, new, {**dict(r), "options": jload(r["options"], [])}, "used", r["position"], r["origin"], r["marks"])
    refresh_total(db, new["id"])
    db.commit()
    return jsonify(exam=exam_dict(db, db.execute("SELECT * FROM exams WHERE id = ?", (new["id"],)).fetchone())), 201


# ---------------------------------------------------------------- her questions
def clean_question(d: dict, existing=None):
    """(question fields, error). The same rules as the questions of a lesson, for the kinds of an exam."""
    kind = d.get("kind", existing["kind"] if existing else "")
    if kind not in examq.KINDS:
        return None, "نوع السؤال غير صحيح"
    question = str(d.get("question", existing["question"] if existing else "")).strip()[:600]
    answer = str(d.get("answer", existing["answer"] if existing else "")).strip()[:600]
    options = d.get("options", jload(existing["options"], []) if existing else [])
    options = [str(o).strip()[:200] for o in options if str(o).strip()][:6] if isinstance(options, list) else []
    if len(question) < 3:
        return None, "اكتبي نص السؤال"
    if kind == "tf" and answer not in ("صح", "خطأ"):
        return None, "إجابة صح أو خطأ يجب أن تكون «صح» أو «خطأ»"
    if kind == "mcq":
        if len(options) < 2 or len(set(options)) != len(options) or answer not in options:
            return None, "اكتبي خيارين على الأقل مختلفين، ولازم تكون الإجابة أحدها"
    if kind == "cloze" and aiq.BLANK not in question:
        return None, "ضعي مكان الكلمة الناقصة فراغًا هكذا: _____"
    if kind != "tf" and not answer:
        return None, "اكتبي الإجابة النموذجية"
    return {"kind": kind, "question": question, "answer": answer, "options": options if kind == "mcq" else []}, ""


@bp.post("/api/exams/<int:eid>/questions")
@login_required
def add_question(eid):
    db = current_app.db
    exam = exam_row(eid)
    stop = need_draft(exam)
    if stop:
        return stop
    d = body()
    q, err = clean_question(d)
    if not q:
        return jsonify(error=err), 400
    if db.execute("SELECT COUNT(*) FROM exam_questions WHERE exam_id = ? AND state = 'used'", (eid,)).fetchone()[0] >= examq.MAX_QUESTIONS:
        return jsonify(error=f"الاختبار لا يتسع لأكثر من {examq.MAX_QUESTIONS} سؤالًا"), 400
    marks = examq.clean_marks(d.get("marks")) if d.get("marks") not in (None, "") else float(examq.DEFAULT_MARKS[q["kind"]])
    if marks is None:
        return jsonify(error="درجة السؤال بين نصف درجة و50"), 400
    qid = insert_question(db, exam, {**q, "source": "سؤالك"}, "used", 10 ** 6, "manual", marks)
    renumber(db, eid)
    refresh_total(db, eid)
    db.commit()
    return jsonify(question=q_dict(db.execute("SELECT * FROM exam_questions WHERE id = ?", (qid,)).fetchone()), exam=exam_dict(db, exam_row(eid))), 201


@bp.patch("/api/exams/<int:eid>/questions/<int:qid>")
@login_required
def edit_question(eid, qid):
    db = current_app.db
    exam = exam_row(eid)
    stop = need_draft(exam)
    if stop:
        return stop
    row = question_row(exam, qid)
    if row["state"] != "used":
        abort(404)
    d = body()
    marks = row["marks"]
    if "marks" in d:
        marks = examq.clean_marks(d.get("marks"))
        if marks is None:
            return jsonify(error="درجة السؤال بين نصف درجة و50"), 400
    if any(k in d for k in ("question", "answer", "options")):
        q, err = clean_question({**d, "kind": row["kind"]}, existing=row)
        if not q:
            return jsonify(error=err), 400
        db.execute("UPDATE exam_questions SET question = ?, answer = ?, options = ?, marks = ?, clear = 1, edited = 1 WHERE id = ?",
                   (q["question"], q["answer"], json.dumps(q["options"], ensure_ascii=False), marks, qid))          # her own wording is her decision: no warning stays on it
    else:
        db.execute("UPDATE exam_questions SET marks = ? WHERE id = ?", (marks, qid))          # only the marks changed: the question, and any warning on it, stay as they were
    refresh_total(db, eid)
    db.commit()
    return jsonify(question=q_dict(db.execute("SELECT * FROM exam_questions WHERE id = ?", (qid,)).fetchone()), exam=exam_dict(db, exam_row(eid)))


@bp.delete("/api/exams/<int:eid>/questions/<int:qid>")
@login_required
def remove_question(eid, qid):
    """Takes the question out of the exam. It does not come back as a spare: she did not want it."""
    db = current_app.db
    exam = exam_row(eid)
    stop = need_draft(exam)
    if stop:
        return stop
    row = question_row(exam, qid)
    if row["state"] != "used":
        abort(404)
    db.execute("UPDATE exam_questions SET state = 'dropped', position = 0 WHERE id = ?", (qid,))
    renumber(db, eid)
    refresh_total(db, eid)
    db.commit()
    return jsonify(exam=exam_dict(db, exam_row(eid)))


@bp.post("/api/exams/<int:eid>/questions/<int:qid>/replace")
@login_required
def replace_question(eid, qid):
    """Swaps the question for the next spare of its kind (one that asks about another sentence of the book). The new question takes the place and the marks of the old one.
    When there is none left, it says so and what she can do (a question of her own, or the smart reader when it is on for her)."""
    db = current_app.db
    exam = exam_row(eid)
    stop = need_draft(exam)
    if stop:
        return stop
    row = question_row(exam, qid)
    if row["state"] != "used":
        abort(404)
    used = used_rows(db, eid)
    spare_rows = db.execute("SELECT * FROM exam_questions WHERE exam_id = ? AND state = 'spare' AND kind = ? ORDER BY id", (eid, row["kind"])).fetchall()
    as_dict = lambda r: {"id": r["id"], "question": r["question"], "evidence": r["evidence"]}
    pick = examq.next_spare([as_dict(r) for r in spare_rows], [as_dict(r) for r in used])          # the old question still counts: the new one must be about something else
    if not pick:
        return jsonify(error=f"لا توجد بدائل متبقية من نوع «{examq.NAMES[row['kind']]}». أضيفي سؤالك بيدك" + ("، أو اطلبي أسئلة من القارئ الذكي" if ai_available(db) else ""),
                       spares=0, can_ask_ai=ai_available(db)), 409
    db.execute("UPDATE exam_questions SET state = 'dropped', position = 0 WHERE id = ?", (qid,))
    db.execute("UPDATE exam_questions SET state = 'used', position = ?, marks = ? WHERE id = ?", (row["position"], row["marks"], pick["id"]))
    refresh_total(db, eid)
    db.commit()
    fresh = exam_dict(db, exam_row(eid))
    return jsonify(question=q_dict(db.execute("SELECT * FROM exam_questions WHERE id = ?", (pick["id"],)).fetchone()), replaced=qid, spares=fresh["spares"][row["kind"]], exam=fresh)


@bp.post("/api/exams/<int:eid>/spare")
@login_required
def add_from_spare(eid):
    """One more question of a kind, taken from the spares (for a kind she has none of, or wants a few more): it goes to the end of its section with the usual marks of the kind."""
    db = current_app.db
    exam = exam_row(eid)
    stop = need_draft(exam)
    if stop:
        return stop
    kind = body().get("kind")
    if kind not in examq.KINDS:
        return jsonify(error="نوع السؤال غير صحيح"), 400
    used = used_rows(db, eid)
    if len(used) >= examq.MAX_QUESTIONS:
        return jsonify(error=f"الاختبار لا يتسع لأكثر من {examq.MAX_QUESTIONS} سؤالًا"), 400
    as_dict = lambda r: {"id": r["id"], "question": r["question"], "evidence": r["evidence"]}
    spare_rows = db.execute("SELECT * FROM exam_questions WHERE exam_id = ? AND state = 'spare' AND kind = ? ORDER BY id", (eid, kind)).fetchall()
    pick = examq.next_spare([as_dict(r) for r in spare_rows], [as_dict(r) for r in used])
    if not pick:
        return jsonify(error=f"لا توجد بدائل متبقية من نوع «{examq.NAMES[kind]}». أضيفي سؤالك بيدك" + ("، أو اطلبي أسئلة من القارئ الذكي" if ai_available(db) else "")), 409
    db.execute("UPDATE exam_questions SET state = 'used', position = ?, marks = ? WHERE id = ?", (10 ** 6, float(examq.DEFAULT_MARKS[kind]), pick["id"]))
    renumber(db, eid)
    refresh_total(db, eid)
    db.commit()
    fresh = exam_dict(db, exam_row(eid))
    return jsonify(question=q_dict(db.execute("SELECT * FROM exam_questions WHERE id = ?", (pick["id"],)).fetchone()), spares=fresh["spares"][kind], exam=fresh), 201


@bp.post("/api/exams/<int:eid>/questions/<int:qid>/move")
@login_required
def move_question(eid, qid):
    """One place up or down inside its section."""
    db = current_app.db
    exam = exam_row(eid)
    stop = need_draft(exam)
    if stop:
        return stop
    row = question_row(exam, qid)
    if row["state"] != "used":
        abort(404)
    step = -1 if toint(body().get("dir")) < 0 else 1
    mates = [r for r in used_rows(db, eid) if r["kind"] == row["kind"]]
    i = next(k for k, r in enumerate(mates) if r["id"] == qid)
    j = i + step
    if 0 <= j < len(mates):
        a, b = mates[i], mates[j]
        db.execute("UPDATE exam_questions SET position = ? WHERE id = ?", (b["position"], a["id"]))
        db.execute("UPDATE exam_questions SET position = ? WHERE id = ?", (a["position"], b["id"]))
        db.execute("UPDATE exams SET updated_at = ? WHERE id = ?", (now(), eid))
        db.commit()
    return jsonify(exam=exam_dict(db, exam_row(eid)))


@bp.post("/api/exams/<int:eid>/marks")
@login_required
def spread_marks(eid):
    """The marks of all the questions made to add up to the total she wants (20, 30, 40 …), the same for the questions of one kind."""
    db = current_app.db
    exam = exam_row(eid)
    stop = need_draft(exam)
    if stop:
        return stop
    rows = used_rows(db, eid)
    if not rows:
        return jsonify(error="لا أسئلة في الاختبار بعد"), 400
    try:
        total = float(body().get("total"))
    except (TypeError, ValueError):
        return jsonify(error="اكتبي الدرجة الكلية رقمًا"), 400
    marks = examq.distribute(total, [r["kind"] for r in rows])
    if marks is None:
        return jsonify(error=f"الدرجة الكلية لا تكفي لـ {len(rows)} سؤالًا، فأقل درجة للسؤال نصف درجة ({examq.fmt_marks(len(rows) / 2)} على الأقل)"), 400
    for r, m in zip(rows, marks):
        db.execute("UPDATE exam_questions SET marks = ? WHERE id = ?", (m, r["id"]))
    refresh_total(db, eid)
    db.commit()
    return jsonify(exam=exam_dict(db, exam_row(eid)))


# ---------------------------------------------------------------- approving
@bp.post("/api/exams/<int:eid>/approve")
@login_required
def approve(eid):
    db = current_app.db
    exam = exam_row(eid)
    rows = used_rows(db, eid)
    if not rows:
        return jsonify(error="أضيفي سؤالًا واحدًا على الأقل قبل الاعتماد"), 400
    total = refresh_total(db, eid)
    top = db.execute("SELECT MAX(score) FROM exam_scores WHERE exam_id = ?", (eid,)).fetchone()[0]
    if top is not None and top > total:
        return jsonify(error=f"سبق أن سُجّلت درجة {examq.fmt_marks(top)} وهي أكبر من مجموع الاختبار الآن ({examq.fmt_marks(total)})"), 409
    db.execute("UPDATE exams SET status = 'approved', approved_at = ?, updated_at = ? WHERE id = ?", (now(), now(), eid))
    db.commit()
    out = exam_dict(db, exam_row(eid))
    out["unclear"] = sum(1 for q in out["questions"] if not q["clear"])
    return jsonify(exam=out)


@bp.post("/api/exams/<int:eid>/unapprove")
@login_required
def unapprove(eid):
    db = current_app.db
    exam_row(eid)
    db.execute("UPDATE exams SET status = 'draft', approved_at = 0, updated_at = ? WHERE id = ?", (now(), eid))
    db.commit()
    return jsonify(exam=exam_dict(db, exam_row(eid)))


# ---------------------------------------------------------------- more questions from the smart reader (only when it is on for her, and within her usual allowance)
def ai_available(db) -> bool:
    cfg = current_app.cfg
    return cfg.ai_provider == "claude" and bool(cfg.anthropic_key) and bool(g.user["ai_consent"]) and billing.ai_switch_on(db)


@bp.post("/api/exams/<int:eid>/more")
@login_required
def more_questions(eid):
    db = current_app.db
    uid = g.user["id"]
    exam = exam_row(eid)
    stop = need_draft(exam)
    if stop:
        return stop
    d = body()
    kind = d.get("kind")
    if kind not in examq.KINDS:
        return jsonify(error="نوع السؤال غير صحيح"), 400
    if not ai_available(db):
        return jsonify(error="القارئ الذكي غير مفعّل لحسابك. أضيفي أسئلتك بيدك"), 409
    if not build_limit.allow(uid):
        return jsonify(error="طلبتِ أسئلة كثيرة خلال ساعة، جرّبي بعد قليل"), 429
    sources = jload(exam["sources"], [])
    texts = []
    for ref in sources:
        if ref.get("t") == "bl":
            bl = db.execute("SELECT * FROM book_lessons WHERE id = ? AND user_id = ?", (toint(ref.get("id")), uid)).fetchone()
            t = lesson_text(db, uid, bl) if bl else ""
        else:
            les = db.execute("SELECT text FROM lessons WHERE id = ? AND user_id = ? AND status = 'ready'", (toint(ref.get("id")), uid)).fetchone()
            t = les["text"] if les else ""
        if t:
            texts.append(t)
    text = "\n\n".join(texts)[:60000]
    if len(text) < 40:
        return jsonify(error="لم نجد نصًا لدروس هذا الاختبار"), 400
    with billing.paid_slot(db, g.user, len(text)) as allowed:
        if not allowed:
            return jsonify(error="لا تتسع حصة القارئ الذكي لطلب جديد الآن (حصتك الشهرية أو سقف التكلفة). أضيفي سؤالك بيدك"), 409
        engine, items, used = aiq.make_questions(current_app.cfg, text, True, total=24)
        if used:
            billing.log_ai(db, uid, None, used["model"], used["input"], used["output"])
    if engine != "claude":
        return jsonify(error="تعذّر الحصول على أسئلة من القارئ الذكي الآن. أضيفي سؤالك بيدك أو جرّبي لاحقًا"), 502
    have = [{"question": r["question"], "evidence": r["evidence"]} for r in db.execute("SELECT question, evidence FROM exam_questions WHERE exam_id = ? AND state != 'dropped'", (eid,))]
    added = 0
    for q in items:
        k = "essay" if q["kind"] == "review" else q["kind"]
        if k != kind or any(examq.similar(q["question"], h["question"]) for h in have):
            continue
        if k == "cloze" and aiq.BLANK not in q["question"]:
            continue
        insert_question(db, exam, {**q, "kind": k, "source": "القارئ الذكي"}, "spare", 0, "ai", float(examq.DEFAULT_MARKS[k]))
        have.append({"question": q["question"], "evidence": q.get("evidence", "")})
        added += 1
    db.commit()
    return jsonify(added=added, exam=exam_dict(db, exam_row(eid)))


# ---------------------------------------------------------------- the marks of her students
def students_of(db, exam):
    return db.execute("SELECT id, name FROM students WHERE class_id = ? AND user_id = ?", (exam["class_id"], exam["user_id"])).fetchall()


def scores_payload(db, exam) -> dict:
    got = {r["student_id"]: r for r in db.execute("SELECT * FROM exam_scores WHERE exam_id = ?", (exam["id"],))}
    rows = []
    for s in sorted(students_of(db, exam), key=lambda s: s["name"]):
        r = got.get(s["id"])
        rows.append({"student_id": s["id"], "name": s["name"], "score": r["score"] if r else None, "absent": bool(r and r["absent"]), "note": r["note"] if r else ""})
    return {"exam": exam_dict(db, exam, full=False), "students": rows, "stats": score_stats(db, exam)}


@bp.get("/api/exams/<int:eid>/scores")
@login_required
def get_scores(eid):
    db = current_app.db
    return jsonify(scores_payload(db, exam_row(eid)))


@bp.put("/api/exams/<int:eid>/scores")
@login_required
def put_scores(eid):
    """Marks for some or all of the students of the exam's class. Nothing is saved unless every line is right; a student of another class is refused."""
    db = current_app.db
    exam = exam_row(eid)
    if exam["status"] != "approved":
        return jsonify(error="اعتمدي الاختبار أولًا ثم سجّلي الدرجات"), 409
    lines = body().get("scores")
    if not isinstance(lines, list) or not lines or len(lines) > 500:
        return jsonify(error="لا درجات لحفظها"), 400
    ok_ids = {s["id"] for s in students_of(db, exam)}
    total = exam["total"]
    clean = []
    for ln in lines:
        if not isinstance(ln, dict):
            return jsonify(error="درجة غير صالحة"), 400
        sid = toint(ln.get("student_id"))
        if sid not in ok_ids:
            return jsonify(error="طالبة ليست في فصل هذا الاختبار"), 404
        absent = bool(ln.get("absent"))
        score = ln.get("score")
        if absent or score is None or str(score).strip() == "":
            score = None
        else:
            try:
                score = round(float(score), 2)
            except (TypeError, ValueError):
                return jsonify(error="الدرجة تُكتب رقمًا"), 400
            if score != score or score < 0 or score > total:
                return jsonify(error=f"الدرجة بين 0 و{examq.fmt_marks(total)}"), 400
        clean.append((sid, score, int(absent), str(ln.get("note") or "").strip()[:100]))
    for sid, score, absent, note in clean:
        db.execute("""INSERT INTO exam_scores(exam_id, user_id, class_id, student_id, score, absent, note, updated_at) VALUES (?,?,?,?,?,?,?,?)
                      ON CONFLICT(exam_id, student_id) DO UPDATE SET score = excluded.score, absent = excluded.absent, note = excluded.note, updated_at = excluded.updated_at""",
                   (exam["id"], exam["user_id"], exam["class_id"], sid, score, absent, note, now()))
    db.commit()
    return jsonify(scores_payload(db, exam_row(eid)))


@bp.get("/api/exams/<int:eid>/scores/csv")
@login_required
def scores_csv(eid):
    """The marks as a sheet Excel opens with its Arabic (a byte-order mark; a name that starts like a formula is written as text)."""
    db = current_app.db
    exam = exam_row(eid)
    data = scores_payload(db, exam)
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow([exam["title"], data["exam"]["class"]["name"], "الدرجة الكلية: " + mark_text(exam["total"])])
    w.writerow(["الطالبة", "الدرجة", "النسبة", "غائبة", "ملاحظة"])
    safe = lambda t: ("'" + t) if t and t[0] in "=+-@\t\r" else t
    for r in data["students"]:
        pct = textfmt.percent(r["score"], exam["total"]) if r["score"] is not None and exam["total"] else ""
        w.writerow([safe(r["name"]), "" if r["score"] is None else mark_text(r["score"]), pct, "نعم" if r["absent"] else "", safe(r["note"])])
    return Response("﻿" + out.getvalue(), mimetype="text/csv; charset=utf-8", headers={"Content-Disposition": f'attachment; filename="exam-{eid}-scores.csv"'})


# ---------------------------------------------------------------- the messages for WhatsApp
@bp.get("/api/exams/<int:eid>/share")
@login_required
def share_texts(eid):
    db = current_app.db
    exam = exam_row(eid)
    data = paper_data(db, exam)
    announce = share.exam_announcement(data)
    plain = share.exam_plain_text(data)
    return jsonify(announce=announce, announce_wa=share.wa_text_url(announce), text=plain, text_wa=share.wa_text_url(plain) if len(plain) <= share.MAX_TEXT else "",
                   text_too_long=len(plain) > share.MAX_TEXT, group=data["class"]["whatsapp"] if data["class"] else "")
