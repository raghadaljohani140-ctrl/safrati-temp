"""The cost report's arithmetic, in one place that anyone can re-run:  python3 -m app.costmodel   (add --json for the raw figures).

It uses the SAME functions the site uses to count a real call (billing.cost_nano: the official prices of the pinned model, the long-prompt rule, the
riyal at 3.75 to the dollar), so the report and the admin page can never disagree. It makes no network call and needs no key: the paid reader is OFF.

Every figure carries its kind:
  official   a price or a rate published by the provider or the state (checked 4 Nov 2026, see aimodel.py)
  measured   read from this code or produced by running it here (a size in characters, a limit, the worst call)
  estimated  an assumption (how many tokens an Arabic character takes, how long a teacher's file is). The ranges are shown, and ONE controlled call after
             the owner's approval would replace the token estimates with measured tokens (the answer carries `usage`)."""
import json
import sys

from . import aimodel, aiq, billing

SAR = billing.USD_SAR                                                  # official: the riyal is fixed at 3.75 to the dollar
VAT = billing.VAT                                                      # official: 15 % (the price a teacher pays includes it)
MONTHLY_SAR, YEARLY_SAR = 29.0, 249.0                                  # the plans' prices, VAT included (db.PLANS)
QUOTA = 40                                                             # AI lessons per teacher per month in both paid plans (db.PLANS)
FIXED_SAR = float(billing.DEFAULT_FIXED_SAR)                           # estimated: hosting, domain and tools per month (the manager edits it in the admin page)
FIXED_PER_TEACHER = 0.30                                               # estimated: extra storage, bandwidth, backups and mail for every paying teacher (SAR a month)

# ---- estimated: how many tokens a character of Arabic takes, and how long a teacher's file is
TOKENS_PER_CHAR = {"low": 0.40, "central": 0.55, "high": 0.75}
LESSON_CHARS = {"small": 3_000, "typical": 9_000, "large": 25_000, "cap": aimodel.MAX_TEXT_CHARS}
QUESTIONS_PER_CALL = 24                                                # measured: the default the site asks for (aiq.make_questions total=24)
OUT_SIZE = {"low": 0.8, "central": 1.0, "high": 1.5}                   # estimated: how much longer or shorter the reader's answer is than the free generator's

SAMPLE_LESSON = """الجهاز الهضمي
يتكون الجهاز الهضمي من مجموعة من الأعضاء التي تعمل معًا لتحويل الطعام إلى مواد بسيطة يستفيد منها الجسم.
الهضم هو عملية تحويل الطعام إلى مواد صغيرة تمتصها الأمعاء وينقلها الدم إلى أنحاء الجسم.
أعضاء الجهاز الهضمي
الفم هو أول أجزاء الجهاز الهضمي وفيه تبدأ عملية مضغ الطعام وخلطه باللعاب.
المريء أنبوب عضلي ينقل الطعام من الفم إلى المعدة بحركة تشبه الموج.
المعدة كيس عضلي تفرز عصارات حمضية تساعد على تفتيت الطعام وقتل الجراثيم.
الأمعاء الدقيقة هي المكان الرئيسي لامتصاص الغذاء لأن جدارها مليء بنتوءات صغيرة كثيرة.
الأمعاء الغليظة تمتص الماء من الفضلات ثم تخرج الفضلات من الجسم.
العناية بالجهاز الهضمي
مضغ الطعام جيدًا يساعد المعدة على الهضم بسهولة.
شرب الماء بكثرة يمنع الإمساك ويحافظ على صحة الأمعاء.
تناول الخضروات والفواكه يوفر الألياف التي تنشط حركة الأمعاء.
غسل اليدين قبل الأكل يحمي الجسم من الجراثيم والأمراض.
"""


def measured() -> dict:
    """What can be read from the code or by running it here."""
    items = aiq.clean_items(aiq.OfflineProvider().generate(SAMPLE_LESSON, QUESTIONS_PER_CALL), SAMPLE_LESSON, True)
    sizes = [len(json.dumps({k: v for k, v in q.items() if k != "clear"}, ensure_ascii=False)) for q in items]
    return {
        "instructions_chars": len(aiq.ClaudeProvider.RULES) + len("أعدي نحو 24 سؤالًا متنوعًا من هذا الدرس:\n\n"),
        "max_text_chars": aimodel.MAX_TEXT_CHARS, "max_out_tokens": aimodel.MAX_OUT_TOKENS, "model": aimodel.MODEL,
        "thinking": "disabled in every request (aiq.ClaudeProvider)", "worst_call_halalas": billing.worst_call_halalas(),
        "sample_questions": len(items), "answer_chars_per_question": round(sum(sizes) / max(len(sizes), 1)),
    }


MEASURED = measured()


def call(chars: int, ratio: str = "central", out: str = "central") -> dict:
    """One call to the paid reader for a file of `chars` characters. Tokens are ESTIMATED from characters; the price arithmetic is the site's own."""
    r = TOKENS_PER_CHAR[ratio]
    t_in = round((min(chars, aimodel.MAX_TEXT_CHARS) + MEASURED["instructions_chars"]) * r)
    t_out = min(round(QUESTIONS_PER_CALL * MEASURED["answer_chars_per_question"] * r * OUT_SIZE[out]), aimodel.MAX_OUT_TOKENS)
    nano = billing.cost_nano(aimodel.MODEL, t_in, t_out)
    return {"tokens_in": t_in, "tokens_out": t_out, "usd": nano / 1e9, "sar": nano * SAR / 1e9, "halalas": billing.nano_to_halalas(nano)}


def lesson_table() -> dict:
    return {size: {"chars": c, "central": call(c), "low": call(c, "low", "low"), "high": call(c, "high", "high")} for size, c in LESSON_CHARS.items()}


def teacher_month(lessons: int, size: str = "typical", ratio: str = "central", out: str = "central") -> float:
    """SAR a teacher's AI use costs in a month."""
    return lessons * call(LESSON_CHARS[size], ratio, out)["sar"]


def fleet(teachers: int, lessons: int, size: str = "typical", ratio: str = "central", out: str = "central") -> float:
    return teachers * teacher_month(lessons, size, ratio, out)


def fixed_for(teachers: int) -> float:
    """The shop's fixed costs for a month with this many paying teachers (ESTIMATED: the default base plus a little for every teacher)."""
    return FIXED_SAR + FIXED_PER_TEACHER * teachers


def unit(plan: str, lessons: int, vat_registered: bool = True, ratio: str = "central") -> dict:
    """One paying teacher's month, before any fixed cost: what she brings in, what her AI lessons cost, what is left."""
    rev = revenue(plan, vat_registered)["net"]
    ai = teacher_month(lessons, ratio=ratio, out=ratio)
    return {"net_revenue": rev, "ai": ai, "left": rev - ai, "margin_pct": 100 * (rev - ai) / rev}


def teachers_under_cap(cap_sar: float, lessons: int, ratio: str = "central") -> int:
    """How many paying teachers can each use `lessons` AI lessons a month before the month's spend reaches the cap (the paid reader then stops by itself)."""
    per = teacher_month(lessons, ratio=ratio, out=ratio)
    return int(cap_sar // per) if per else 0


def revenue(plan: str, vat_registered: bool = True) -> dict:
    """What one paying teacher brings in a month (the price includes VAT; a registered shop hands the VAT on)."""
    gross = MONTHLY_SAR if plan == "monthly" else YEARLY_SAR / 12
    vat = gross * VAT / (1 + VAT) if vat_registered else 0.0
    return {"gross": gross, "vat": vat, "net": gross - vat}


def margin(plan: str, teachers: int, lessons: int, vat_registered: bool = True, ratio: str = "central", size: str = "typical", fixed=None) -> dict:
    """The month of a shop with `teachers` paying teachers who each use `lessons` AI lessons (before marketing, income tax or zakat, and support time)."""
    fixed = fixed_for(teachers) if fixed is None else fixed
    rev = revenue(plan, vat_registered)["net"] * teachers
    ai = fleet(teachers, lessons, size, ratio, ratio if ratio != "low" else "low")
    profit = rev - ai - fixed
    return {"net_revenue": rev, "ai": ai, "fixed": fixed, "profit": profit, "margin_pct": 100 * profit / rev if rev else 0.0, "ai_pct_of_revenue": 100 * ai / rev if rev else 0.0}


def break_even(plan: str, lessons: int, vat_registered: bool = True, fixed: float = FIXED_SAR) -> float:
    """How many paying teachers cover the base fixed costs (the per-teacher extras are already inside each teacher's own month)."""
    per = revenue(plan, vat_registered)["net"] - teacher_month(lessons) - FIXED_PER_TEACHER
    return fixed / per if per > 0 else float("inf")


def worst_cases() -> dict:
    """The three worst cases, from likely-bad to impossible-to-exceed. Each is per teacher per month, in SAR."""
    cap_call = call(LESSON_CHARS["cap"], "high", "high")
    bound = billing.worst_call_halalas() / 100
    return {
        "heavy_use": {"per_call": call(LESSON_CHARS["large"], "high", "high"), "per_teacher_month": teacher_month(QUOTA, "large", "high", "high")},
        "every_file_at_the_cap": {"per_call": cap_call, "per_teacher_month": QUOTA * cap_call["sar"]},
        "absolute_bound": {"per_call_sar": bound, "per_teacher_month": QUOTA * bound,
                           "why": "one token for every BYTE of a 60,000-character file (an Arabic letter is two bytes) and the longest answer allowed, at the dearer long-prompt price"},
    }


def cap_advice(net_revenue_month: float) -> dict:
    """The monthly cap the manager sets in the admin page (`ai_cap_sar`): at most a tenth of what the month brings in, never under the floor that keeps the
    reader usable while the shop is small. The site then stops calling the paid reader by itself once the month's spend reaches it."""
    pct, floor = 10, 50
    return {"cap_sar": max(floor, round(net_revenue_month * pct / 100)), "rule": f"{pct} % of the month's net revenue, never under {floor} SAR"}


def report() -> dict:
    sizes = (10, 20, 40)
    return {
        "official": {"model": aimodel.MODEL, "usd_per_mtok": aimodel.PRICE_USD[aimodel.MODEL], "usd_per_mtok_long_prompt": aimodel.LONG_PRICE_USD[aimodel.MODEL],
                     "long_prompt_tokens": aimodel.LONG_PROMPT, "sar_per_usd": SAR, "vat": VAT, "monthly_sar": MONTHLY_SAR, "yearly_sar": YEARLY_SAR},
        "measured": MEASURED,
        "estimated": {"tokens_per_char": TOKENS_PER_CHAR, "lesson_chars": LESSON_CHARS, "questions_per_call": QUESTIONS_PER_CALL, "fixed_sar_per_month": FIXED_SAR,
                      "fixed_per_teacher_sar": FIXED_PER_TEACHER},
        "one_lesson": lesson_table(),
        "per_teacher_month": {n: {"central": teacher_month(n), "high": teacher_month(n, ratio="high", out="high")} for n in sizes},
        "fleet": {t: {n: {"central": fleet(t, n), "high": fleet(t, n, ratio="high", out="high")} for n in sizes} for t in (100, 500, 1000)},
        "worst": worst_cases(),
        "revenue": {p: {"registered": revenue(p, True), "unregistered": revenue(p, False)} for p in ("monthly", "yearly")},
        "unit": {p: {n: {"registered": unit(p, n, True), "unregistered": unit(p, n, False), "high_registered": unit(p, n, True, "high")} for n in sizes} for p in ("monthly", "yearly")},
        "default_cap_covers": {n: {"central": teachers_under_cap(50, n), "high": teachers_under_cap(50, n, "high")} for n in sizes},
        "margin": {p: {t: {n: margin(p, t, n) for n in sizes} for t in (100, 500, 1000)} for p in ("monthly", "yearly")},
        "break_even_teachers": {p: {n: break_even(p, n) for n in sizes} for p in ("monthly", "yearly")},
        "cap_advice": {t: cap_advice(revenue("yearly")["net"] * t) for t in (100, 500, 1000)},
    }


def main(argv=None) -> None:
    r = report()
    if "--json" in (argv if argv is not None else sys.argv[1:]):
        print(json.dumps(r, ensure_ascii=False, indent=1, default=str))
        return
    o, m = r["official"], r["measured"]
    print(f"النموذج المثبّت: {o['model']} · السعر الرسمي: {o['usd_per_mtok'][0]} دولار/مليون رمز إدخال و{o['usd_per_mtok'][1]} إخراج (للطلب حتى {o['long_prompt_tokens']:,} رمز)")
    print(f"سعر الصرف {o['sar_per_usd']} ريال للدولار · الضريبة {int(o['vat'] * 100)}٪ · أسوأ استدعاء مسموح: {m['worst_call_halalas']} هللة")
    print("\nدرس واحد (مقدَّر الرموز):")
    for size, v in r["one_lesson"].items():
        c = v["central"]
        print(f"  {size:8} {v['chars']:>6,} حرف  إدخال {c['tokens_in']:>6,} + إخراج {c['tokens_out']:>5,} رمز = {c['sar']:.4f} ريال ({c['halalas']} هللة) · الأعلى {v['high']['sar']:.4f}")
    print("\nلكل معلمة في الشهر (درس نموذجي):")
    for n, v in r["per_teacher_month"].items():
        print(f"  {n} دروس: {v['central']:.3f} ريال (الأعلى {v['high']:.3f})")
    print("\nلكل المعلمات:")
    for t, row in r["fleet"].items():
        print(f"  {t:>5} معلمة: " + " · ".join(f"{n} دروس = {v['central']:,.1f} ريال" for n, v in row.items()))
    print("\nالأسوأ (لكل معلمة في الشهر):")
    for k, v in r["worst"].items():
        print(f"  {k}: {v['per_teacher_month']:.2f} ريال")


if __name__ == "__main__":
    main()
