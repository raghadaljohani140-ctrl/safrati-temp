import contextlib
import logging
import sqlite3
import time
import os
import threading
import uuid
from pathlib import Path

from flask import Blueprint, abort, current_app, g, redirect, render_template, request, url_for

from . import aiq, billing, db as dbm, extract
from .db import jload, now
from .security import Limiter, login_required

upload_limit = Limiter(20, 3600)
log = logging.getLogger(__name__)

bp = Blueprint("lessons", __name__)
GAMES = {                  # the first four are the activities every teacher sees first; the rest are extra games
    "pick": ("عجلة الحظ", "🎡", "تختار طالبًا بالدور ثم تسأله، ويشارك الجميع قبل أن يتكرر أحد"),
    "qa": ("سؤال وجواب", "💬", "اكشفي الإجابة عند الضغط"),
    "live": ("أسئلة تفاعلية", "🙋", "اختاري من يجيب، وابدئي المؤقت، ثم اكشفي الإجابة"),
    "quiz": ("اختبار قصير", "📝", "5 أو 10 أو 15 سؤالًا، ونتيجة محفوظة باسم كل طالب"),
    "wheel": ("عجلة الأسئلة", "🎰", "تدور العجلة وتختار سؤالًا"),
    "tf": ("صح أو خطأ", "✅", "الطالبات يقررن، ثم تظهر الإجابة"),
    "mcq": ("اختاري الصحيحة", "🎯", "عدة خيارات وإجابة واحدة"),
    "cloze": ("أكملي الفراغ", "✏️", "كلمة ناقصة في الجملة"),
    "teams": ("تحدي الفريقين", "🏆", "فريقان ونقاط وأدوار"),
    "random": ("سؤال عشوائي", "🎲", "يختار التطبيق سؤالًا لكِ"),
}
PRIMARY = ("pick", "qa", "live", "quiz")
GAME_KINDS = {"pick": aiq.KINDS, "qa": ("qa", "short", "review"), "live": ("tf", "mcq", "cloze", "short"), "quiz": ("mcq", "tf", "cloze", "short", "qa"),
              "wheel": aiq.KINDS, "tf": ("tf",), "mcq": ("mcq",), "cloze": ("cloze",), "teams": aiq.KINDS, "random": aiq.KINDS}


def mine(table, row_id):
    row = current_app.db.execute(f"SELECT * FROM {table} WHERE id = ? AND user_id = ?", (row_id, g.user["id"])).fetchone()
    if not row:
        abort(404)                     # another teacher's file looks exactly like a file that does not exist
    return row


def q_dict(r):
    return {"id": r["id"], "kind": r["kind"], "question": r["question"], "answer": r["answer"], "options": jload(r["options"], []),
            "evidence": r["evidence"], "clear": bool(r["clear"]), "manual": bool(r["manual"])}


def process(app, lesson_id: int):
    """Read the file and make the questions (runs in a worker thread with its own database connection)."""
    conn = dbm.connect(app.cfg.db_path)
    try:
        lesson = conn.execute("SELECT * FROM lessons WHERE id = ?", (lesson_id,)).fetchone()
        if not lesson:
            return
        user = conn.execute("SELECT * FROM users WHERE id = ?", (lesson["user_id"],)).fetchone()
        try:
            if lesson["kind"] == "book":                  # made from a lesson of a book (plan.py): the text was kept with the book, there is no file
                text, details = lesson["text"] or "", {"subject": lesson["subject"], "grade": lesson["grade"]}
                if len(text.strip()) < extract.MIN_CHARS:
                    raise extract.ExtractError("لا يوجد نص كافٍ لهذا الدرس في الكتاب. افتحي «الخطة» والصقي نصه")
            else:
                data = (app.cfg.upload_dir / lesson["stored_name"]).read_bytes()
                text, details = extract.read(lesson["kind"], data)
            # her consent + her plan's allowance + the site's monthly cost cap (the most this call can cost is held against the cap while it runs)
            with (billing.paid_slot(conn, user, len(text)) if user["ai_consent"] else contextlib.nullcontext(False)) as allowed:
                engine, items, used = aiq.make_questions(app.cfg, text, allowed)
                if used:
                    billing.log_ai(conn, user["id"], lesson_id, used["model"], used["input"], used["output"])
            conn.execute("DELETE FROM questions WHERE lesson_id = ? AND manual = 0", (lesson_id,))
            for i, q in enumerate(items):
                conn.execute("INSERT INTO questions(lesson_id, user_id, kind, question, answer, options, evidence, clear, position, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                             (lesson_id, user["id"], q["kind"], q["question"], q["answer"], __import__("json").dumps(q["options"], ensure_ascii=False),
                              q["evidence"], q["clear"], i, now()))
            note = details.get("warn", "")                 # the reader doubts the direction of the letters
            if not items:
                note = (note + " " if note else "") + "قرأنا الملف لكن لم نستطع صياغة أسئلة واضحة منه. أضيفي أسئلتك يدويًا أو جرّبي ملفًا فيه جمل كاملة"
            conn.execute("UPDATE lessons SET text = ?, status = 'ready', error = ?, engine = ?, subject = ?, grade = ?, updated_at = ? WHERE id = ?",
                         (text, note, engine, details.get("subject", "")[:80], details.get("grade", "")[:80], now(), lesson_id))
            try:
                billing.count_lesson(conn, lesson)           # the file was read: it counts towards her plan, once, and deleting it later will not take it back
            except sqlite3.Error:
                log.exception("could not write lesson %s in the usage log", lesson_id)          # the lesson itself is fine; the next start writes it in the log
        except extract.ExtractError as exc:
            conn.execute("UPDATE lessons SET status = 'failed', error = ?, updated_at = ? WHERE id = ?", (str(exc), now(), lesson_id))
        except Exception:
            conn.execute("UPDATE lessons SET status = 'failed', error = ?, updated_at = ? WHERE id = ?", ("حدث خطأ أثناء المعالجة، أعيدي رفع الملف", now(), lesson_id))
        conn.commit()
    finally:
        conn.close()


def start(app, lesson_id):
    if app.cfg.background:
        threading.Thread(target=process, args=(app, lesson_id), daemon=True).start()
    else:
        process(app, lesson_id)


def _renew(user):
    left = billing.days_left(user)
    return left if left is not None and 0 <= left <= billing.RENEW_WARN_DAYS and user["plan_code"] != "free" else None


@bp.get("/dashboard")
@login_required
def dashboard():
    from . import classroom          # imported here: classroom itself needs this module (mine)
    db = current_app.db
    uid = g.user["id"]
    lessons = db.execute("SELECT * FROM lessons WHERE user_id = ? ORDER BY id DESC", (uid,)).fetchall()
    decks = db.execute("SELECT d.*, l.title AS lesson_title FROM decks d JOIN lessons l ON l.id = d.lesson_id WHERE d.user_id = ? AND d.auto = 0 ORDER BY d.updated_at DESC", (uid,)).fetchall()
    counts = {r["lesson_id"]: r["n"] for r in db.execute("SELECT lesson_id, COUNT(*) AS n FROM questions WHERE user_id = ? GROUP BY lesson_id", (uid,))}
    plan = billing.plan_of(db, g.user)
    allow = billing.lesson_allowance(db, g.user)
    used_d = billing.usage(db, uid)[1]
    latest = next((l for l in lessons if l["status"] == "ready"), None)          # her newest lesson that is ready: «حصة اليوم» opens it
    return render_template("dashboard.html", lessons=lessons, decks=decks, counts=counts, plan=plan, used_l=allow["used"], allow=allow, ar_day=billing.ar_day, used_d=used_d, games=GAMES, primary=PRIMARY, latest=latest,
                           ai_used=billing.ai_used(db, uid), renew=_renew(g.user), lapsed=g.user["plan_code"] != "free" and g.user["plan_expires"] and g.user["plan_expires"] < time.time(),
                           hub=classroom.hub_data(db, uid), msg=request.args.get("msg", ""), max_mb=billing.upload_limit_mb(db, current_app.cfg.max_upload_mb),
                           ai_on=current_app.cfg.ai_provider == "claude" and bool(current_app.cfg.anthropic_key))


@bp.post("/lessons/upload")
@login_required
def upload():
    db = current_app.db
    f = request.files.get("lesson")
    if not f or not f.filename:
        return redirect(url_for("lessons.dashboard", msg="اختاري ملف الدرس أولًا"))
    if not upload_limit.allow(g.user["id"]):
        return redirect(url_for("lessons.dashboard", msg="رفعتِ ملفات كثيرة خلال ساعة، جرّبي بعد قليل"))
    allow = billing.lesson_allowance(db, g.user)
    if allow["left"] <= 0:
        return redirect(url_for("lessons.dashboard", msg=billing.lesson_limit_msg(allow)))
    data = f.read()
    limit_mb = billing.upload_limit_mb(db, current_app.cfg.max_upload_mb)
    if len(data) > limit_mb * 1024 * 1024:
        return redirect(url_for("lessons.dashboard", msg=f"الملف كبير، الحد الأقصى {limit_mb} ميجابايت"))
    try:
        kind = extract.detect(f.filename, data[:16])
    except extract.ExtractError as exc:
        return redirect(url_for("lessons.dashboard", msg=str(exc)))
    if not data:
        return redirect(url_for("lessons.dashboard", msg="الملف فارغ"))
    ext = f.filename.rsplit(".", 1)[-1].lower()
    stored = uuid.uuid4().hex + "." + ext
    (current_app.cfg.upload_dir / stored).write_bytes(data)
    title = (request.form.get("title", "").strip() or Path(f.filename).stem)[:100]
    cur = db.execute("INSERT INTO lessons(user_id, title, original_name, stored_name, kind, created_at, updated_at) VALUES (?,?,?,?,?,?,?)",
                     (g.user["id"], title, f.filename[:200], stored, kind, now(), now()))
    db.commit()
    start(current_app._get_current_object(), cur.lastrowid)
    return redirect(url_for("lessons.lesson", lid=cur.lastrowid))


@bp.get("/lessons/<int:lid>")
@login_required
def lesson(lid):
    row = mine("lessons", lid)
    return render_template("lesson.html", lesson=row, games=GAMES, primary=PRIMARY, game_kinds=GAME_KINDS, kind_names=aiq.KIND_NAMES, unclear=aiq.G.UNCLEAR)


@bp.get("/present/<int:did>")
@login_required
def present(did):
    deck = mine("decks", did)
    return render_template("present.html", deck=deck, games=GAMES)


def remove_lesson_files(app, rows):
    for r in rows:
        try:
            (app.cfg.upload_dir / r["stored_name"]).unlink()
        except OSError:
            pass
