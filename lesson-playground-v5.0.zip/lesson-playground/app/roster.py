"""Student names (and the class each belongs to) out of a list the teacher already has: an Excel sheet, a Word table or list, a CSV, a PDF or a photo of a printed sheet.

Nothing is asked of the teacher up front. The file is read the way a person reads it: look for a heading row («الاسم»), else for the column that holds names,
leave out the numbering and the identity numbers, and notice where a new class begins («الصف الأول أ» above a block of names, a «الفصل» column, a sheet of its own).
What comes out is only a proposal: the teacher sees it, fixes it and confirms it (students.py), so a wrong guess costs one tap, not a wrong list.
"""
import re
import unicodedata

from . import meta

MAX_NAMES = 600

_DIAC = re.compile("[ً-ٰٟـ]")
_LETTERS = "ء-يٱ-ۓA-Za-z"
_NAME = re.compile(rf"^[{_LETTERS}][{_LETTERS}ً-ٰٟـ '’.\-]*$")
_TRANS = str.maketrans({"أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا", "ى": "ي", "ة": "ه", "ؤ": "و", "ئ": "ي"})

# words that make a cell a heading or a footer, never a name
_NOT_NAME_WORDS = """م مسلسل رقم الرقم ملاحظات ملاحظه المجموع الاجمالي اجمالي الجوال جوال الهويه هويه السجل المدني الصف الفصل الشعبه شعبه المدرسه مدرسه كشف قائمه قوائم
الطلاب الطالبات طلاب طالبات الطالب الطالبه الاسم اسم المعلم المعلمه المرحله العام الدراسي التاريخ الحضور الغياب الدرجه الدرجات المادة
الجنسيه الميلاد تاريخ العنوان ولي الامر وليالامر الاب الام التوقيع توقيع الحاله الصحيه الدور الجلوس جلوس بيان بيانات اجمالي اخصائي مشرف مدير وكيل
name student students class section no number id total notes"""
_NAME_HEADS = ("الاسم", "اسم الطالب", "اسم الطالبه", "الطالب", "الطالبه", "اسم", "الاسم الكامل", "اسم الدارس", "name", "student", "student name", "full name")
_CLASS_HEADS = ("الفصل", "الشعبه", "الصف", "الصف والشعبه", "الصف/الشعبه", "الفصل/الشعبه", "class", "section", "grade")
_GENERIC_SHEET = re.compile(r"^(?:sheet|ورقه|ورقة|صفحه|صفحة|جدول|table|document|page)\s*\d*$", re.I)
_LEAD_NUM = re.compile(r"^[\s‏‎•·*\-–—.()\[\]/|:]*(?:[0-9٠-٩۰-۹]+\s*[\-–—.)\]/|:]*)?\s*")
_HEAD_WORDS = "كشف قائمة قوائم بيان أسماء اسماء اسم طلاب طالبات الطلاب الطالبات الطلبة بيانات"


def key(s: str) -> str:
    """A spelling for comparing: no marks, one alef, one yeh, one heh, single spaces."""
    s = unicodedata.normalize("NFKC", str(s or ""))
    s = _DIAC.sub("", s).translate(_TRANS)
    return re.sub(r"\s+", " ", s).strip().lower()


_NOT_NAME = frozenset(key(w) for w in _NOT_NAME_WORDS.split())
_HEAD_SET = frozenset(key(w) for w in _HEAD_WORDS.split())          # the words that open a title («كشف أسماء طلاب …»)
_NAME_HEADS = tuple(key(h) for h in _NAME_HEADS)
_CLASS_HEADS = tuple(key(h) for h in _CLASS_HEADS)


def clean_name(value) -> str:
    return " ".join(unicodedata.normalize("NFKC", str(value or "")).replace("‏", "").replace("‎", "").replace(" ", " ").split())[:60]


def is_name(value, lone_ok: bool = True) -> bool:
    """True when the text can be a student's name: letters and spaces, one to seven words, and not a heading such as «الاسم» or «المجموع»."""
    s = clean_name(value)
    if len(s) < 2 or not _NAME.match(s):
        return False
    words = s.split()
    if len(words) > 7 or (len(words) == 1 and not lone_ok):
        return False
    if sum(ch.isalpha() for ch in s) < 2:
        return False
    keys = [key(w).strip(".'-’") for w in words]
    if any(k in _NOT_NAME for k in keys):
        return False
    if len(words) >= 2 and key(s) in _NOT_NAME:
        return False
    return True


def _strip_heads(raw: str) -> str:
    toks = raw.split()
    while toks and key(toks[0]) in _HEAD_SET:
        toks.pop(0)
    return " ".join(toks)


def _is_class_label(line: str) -> str:
    """The class named by a heading line («الصف الأول / أ», «الفصل: 3/2», «كشف طلاب الصف الثالث المتوسط»), or ''."""
    raw = clean_name(line)
    if not raw or len(raw) > 70:
        return ""
    k = key(raw)
    if "الدراسي" in k or "العام" in k:
        return ""
    first = key(raw.split()[0])
    if re.match(r"^(?:ال)?(?:فصل|صف|شعبه)\b\s*[:：\-–]?\s*\S", k) or (meta.GRADE.search(raw) and (first in _HEAD_SET or re.match(r"^(?:ال)?صف\b", k))):
        return _strip_heads(raw).strip(" :：-–—()[]")[:40]
    return ""


def _cells_to_name(cells) -> str:
    for c in cells:
        if is_name(c):
            return clean_name(c)
    return ""


def name_from_line(line: str) -> list:
    """The name(s) one line holds. Numbering in front and identity numbers behind are cut off: «12- أحمد محمد العتيبي 1098765432» is «أحمد محمد العتيبي»."""
    line = clean_name(line)
    if not line:
        return []
    if any(sep in line for sep in ("\t", "|", ";")):
        for part in re.split(r"[\t|;]", line):
            n = name_from_line(part)
            if n:
                return n[:1]
        return []
    if re.search(r"[،,]", line):
        parts = [p for p in re.split(r"[،,]", line) if p.strip()]
        if len(parts) >= 3 and all(is_name(clean_name(_LEAD_NUM.sub("", p)).strip()) and len(clean_name(p).split()) <= 3 for p in parts):
            return [clean_name(_LEAD_NUM.sub("", p)) for p in parts]
    line = _LEAD_NUM.sub("", line)
    line = " ".join(t for t in line.split() if not re.fullmatch(r"[0-9٠-٩۰-۹+\-/.]+", t))          # identity numbers, phone numbers, dates
    return [line] if is_name(line) else []


# ---------------------------------------------------------------- one sheet
def _width(rows):
    return max((len([c for c in r if c]) for r in rows), default=0)


def _from_lines(lines):
    groups, cur = [], {"class": "", "names": []}
    for line in lines:
        line = clean_name(line)
        if not line:
            continue
        label = _is_class_label(line)
        if label:
            if cur["names"] or cur["class"]:
                groups.append(cur)
            cur = {"class": label, "names": []}
            continue
        cur["names"].extend(name_from_line(line))
    groups.append(cur)
    return [g for g in groups if g["names"]]


def _head_cell(cell, heads) -> bool:
    k = key(cell)
    return bool(k) and (k in heads or any(k.startswith(h + " ") or k.endswith(" " + h) for h in heads if len(h) > 3))


def _title_label(rows, upto) -> str:
    for r in rows[:upto]:
        for c in r:
            if c and meta.GRADE.search(c) and len(c) <= 70:
                return _is_class_label(c) or ""
    return ""


def _from_table(sheet):
    rows = sheet["rows"]
    head_at = name_col = class_col = None
    for i, r in enumerate(rows[:12]):
        for j, c in enumerate(r):
            if name_col is None and _head_cell(c, _NAME_HEADS):
                head_at, name_col = i, j
            elif class_col is None and _head_cell(c, _CLASS_HEADS) and (head_at is None or i == head_at):
                class_col = j
        if name_col is not None:
            class_col = next((j for j, c in enumerate(r) if j != name_col and _head_cell(c, _CLASS_HEADS)), class_col if head_at == i else None)
            break
    body_start = head_at + 1 if head_at is not None else 0
    if name_col is None:
        best, best_col = 0, None
        width = max(len(r) for r in rows)
        for c in range(width):
            vals = [r[c] for r in rows[body_start:] if c < len(r) and r[c]]
            good = [v for v in vals if is_name(v)]
            distinct = len({key(v) for v in good})
            score = len(good) if distinct >= max(2, 0.5 * len(good)) else len(good) * 0.3
            if score > best:
                best, best_col = score, c
        if best_col is None or best < 1:
            return []
        name_col = best_col
    label = ""
    if class_col is None:
        label = "" if _GENERIC_SHEET.match(sheet["name"] or "") else clean_name(sheet["name"])[:40]
        label = label or _title_label(rows, body_start if head_at is not None else 3)
    groups = {}
    order = []
    for r in rows[body_start:]:
        if name_col >= len(r):
            continue
        cell = r[name_col]
        nm = name_from_line(cell) if cell else []
        if not nm:
            continue
        lab = clean_name(r[class_col]) if class_col is not None and class_col < len(r) and r[class_col] else label
        if lab not in groups:
            groups[lab] = []
            order.append(lab)
        groups[lab].extend(nm)
    return [{"class": lab, "names": groups[lab]} for lab in order if groups[lab]]


def from_sheets(sheets):
    """[{"class": label or "", "names": [unique names]}], the groups in the order they appear in the file."""
    found = []
    for sh in sheets:
        rows = [r for r in sh["rows"] if any(r)]
        if not rows:
            continue
        if _width(rows) <= 1:
            groups = _from_lines([next((c for c in r if c), "") for r in rows])
            if sh["name"] and not _GENERIC_SHEET.match(sh["name"]):
                for g in groups:
                    g["class"] = g["class"] or clean_name(sh["name"])[:40]
        else:
            groups = _from_table(dict(sh, rows=rows))
        found.extend(groups)
    merged, index = [], {}
    total = 0
    for g in found:
        lab = clean_name(g["class"])
        slot = index.get(key(lab))
        if slot is None:
            slot = {"class": lab, "names": [], "_seen": set()}
            index[key(lab)] = slot
            merged.append(slot)
        for n in g["names"]:
            if key(n) not in slot["_seen"] and total < MAX_NAMES:
                slot["_seen"].add(key(n))
                slot["names"].append(n)
                total += 1
    return [{"class": s["class"], "names": s["names"]} for s in merged if s["names"]]
