"""Participation points: a point (or a few) given to ONE student of her class, in a subject, on a day.

They live on the server, never only in the browser. Every point is a line of a log she can read, correct and take back; the boards and the reports are added up from that log
(scoring.py). A student belongs to one class, so a point is always in the class of its student: two classes can never share or mix a point, and every lookup here is by her
user id first (another teacher's student, class or point looks exactly like one that does not exist).

A page that could not reach the server keeps the points it gave and sends them later (stage-points.js). Each one carries a key made by the page, so sending the same point twice
(the answer was lost on the way back) writes it once."""
import datetime
import re
import sqlite3

from flask import Blueprint, abort, current_app, g, jsonify, render_template, request

from . import classroom, scoring, share, terms
from .classroom import subject_row
from .db import now
from .lessons import GAMES
from .planner import parse_day
from .schedule import put_settings, settings
from .security import Limiter, login_required
from .students import body, class_row, clean_name, student_row, toint

bp = Blueprint("points", __name__)
MAX_AMOUNT = 50
MAX_LATE = 7 * 86400            # a point given while the connection was down keeps the day it was given when it is sent later, up to a week
MAX_BACK_DAYS = 400             # how far back a point can be written by hand
MAX_PAGE = 200
award_limit = Limiter(1500, 3600)
KEY = re.compile(r"^[A-Za-z0-9:_.-]{1,64}$")
GAME_LABELS = {**{k: v[0] for k, v in GAMES.items()}, "today": "حصة اليوم"}
DEFAULTS = {"correct": 1, "try": 0}          # points for a right answer, and for an answer that was not right (a point for trying)
LIMITS = {"correct": (0, 5), "try": (0, 3)}


class Bad(Exception):
    """A request that cannot be answered as it was asked; the sentence is shown to her."""


@bp.app_errorhandler(Bad)
def _bad(exc):
    return jsonify(error=str(exc)), 400


# ---------------------------------------------------------------- reading what was asked
def clean_amount(value):
    """The number of points as an integer (1 to 50, or the same negative to take points off), None for anything else; zero gives nothing."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    try:
        n = int(value)
    except (ValueError, OverflowError):
        return None
    return n if n == value and n != 0 and abs(n) <= MAX_AMOUNT else None


def day_or_none(value):
    """The ISO day if it is a real day she could have given points on (not in the future, not more than a year back), else None."""
    d = parse_day(value)
    today = classroom.today_date()
    return d.isoformat() if d and d <= today and (today - d).days <= MAX_BACK_DAYS else None


def scope(args, need_class=True):
    """The class, the subject and the period a screen asks about: (class row | None, subject row | None, period, first day, last day). 404 for anyone else's class or subject."""
    cid, sid = toint(args.get("class_id")), toint(args.get("subject_id"))
    if need_class and not cid:
        raise Bad("اختاري الفصل")
    cls = class_row(cid) if cid else None
    subject = subject_row(sid) if sid else None
    period = args.get("period") or "term"
    if period not in scoring.PERIODS:
        raise Bad("فترة غير معروفة")
    lo, hi = scoring.bounds(period, classroom.today_date(), terms.current(current_app.db, g.user["id"]))
    return cls, subject, period, lo, hi


def point_settings(db, uid) -> dict:
    """How many points a right answer gives (and an answer that was not right), set by her; the pages that give points read it."""
    cfg = settings(db, uid)
    out = {}
    for k, (lo, hi) in LIMITS.items():
        v = cfg.get("points_" + k)
        out[k] = v if isinstance(v, int) and not isinstance(v, bool) and lo <= v <= hi else DEFAULTS[k]
    return out


# ---------------------------------------------------------------- one point and the log
ENTRY = """SELECT p.*, s.name AS student, c.name AS class_name, sj.name AS subject_name FROM points p
           JOIN students s ON s.id = p.student_id JOIN classes c ON c.id = p.class_id LEFT JOIN subjects sj ON sj.id = p.subject_id"""


def entry(r) -> dict:
    label = GAME_LABELS.get(r["game"], "")
    return {"id": r["id"], "student_id": r["student_id"], "student": r["student"], "class_id": r["class_id"], "class": r["class_name"],
            "subject_id": r["subject_id"], "subject": r["subject_name"] or "", "day": r["day"], "day_text": share.ar_date(r["day"]), "amount": r["amount"],
            "source": r["source"], "game": r["game"], "ref": r["ref"], "note": r["note"], "at": r["created_at"], "edited": bool(r["edited_at"]),
            "label": ("لعبة: " + label if label else "لعبة") if r["source"] == "game" else "يدوي"}


def own(pid):
    row = current_app.db.execute("SELECT * FROM points WHERE id = ? AND user_id = ?", (pid, g.user["id"])).fetchone()
    if not row:
        abort(404)
    return row


def given_today(db, uid, student_id) -> int:
    return db.execute("SELECT COALESCE(SUM(amount), 0) FROM points WHERE user_id = ? AND student_id = ? AND day = ?",
                      (uid, student_id, classroom.today_date().isoformat())).fetchone()[0]


def when_of(d, manual):
    """(the day, the moment) a point was given: now, or the moment the page says it was given when that is recent (it was kept while the connection was down).
    A point written by hand may name its day. None when that day is not allowed."""
    t = now()
    if manual and d.get("day"):
        day = day_or_none(d.get("day"))
        return (day, t) if day else None
    at = d.get("at")
    if isinstance(at, (int, float)) and not isinstance(at, bool) and t - MAX_LATE <= at <= t + 120:
        return datetime.datetime.fromtimestamp(at, classroom.TZ).date().isoformat(), float(at)
    return classroom.today_date().isoformat(), t


@bp.post("/api/points")
@login_required
def award():
    """Give points to a student: {student_id, amount, source: game | manual, game, ref, subject_id, note, key, at, day}. The class is the student's. Sent again with the same key it is
    written once (the answer says duplicate)."""
    d = body()
    db, uid = current_app.db, g.user["id"]
    if not award_limit.allow(uid):
        return jsonify(error="أُعطيت نقاط كثيرة خلال ساعة، جرّبي بعد قليل"), 429
    student = student_row(toint(d.get("student_id")))
    if student["class_id"] is None:
        return jsonify(error="هذا الطالب ليس في فصل"), 400
    amount = clean_amount(d.get("amount"))
    if amount is None:
        return jsonify(error=f"عدد النقاط رقم صحيح من 1 إلى {MAX_AMOUNT} (وبالسالب للإنقاص) ولا يكون صفرًا"), 400
    key = str(d.get("key") or "")
    if key and not KEY.match(key):
        return jsonify(error="معرّف النقطة غير صالح"), 400
    if key:
        old = db.execute("SELECT id, student_id FROM points WHERE user_id = ? AND client_key = ?", (uid, key)).fetchone()
        if old:
            return jsonify(id=old["id"], duplicate=True, today=given_today(db, uid, old["student_id"])), 200
    sid = toint(d.get("subject_id")) or None
    if sid:
        subject_row(sid)
    manual = d.get("source") != "game"
    when = when_of(d, manual)
    if not when:
        return jsonify(error="اختاري يومًا لا يتجاوز اليوم ولا يسبقه بأكثر من سنة"), 400
    game = re.sub(r"[^a-z]", "", str(d.get("game") or "").lower())[:20]
    try:
        cur = db.execute("""INSERT INTO points(user_id, class_id, student_id, subject_id, day, amount, source, game, ref, note, client_key, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                         (uid, student["class_id"], student["id"], sid, when[0], amount, "manual" if manual else "game", game, clean_name(d.get("ref"))[:80], clean_name(d.get("note"))[:80], key, when[1]))
        db.commit()
    except sqlite3.IntegrityError:          # the same key arrived twice at the same moment
        db.rollback()
        old = db.execute("SELECT id, student_id FROM points WHERE user_id = ? AND client_key = ?", (uid, key)).fetchone()
        if not old:
            raise
        return jsonify(id=old["id"], duplicate=True, today=given_today(db, uid, old["student_id"])), 200
    return jsonify(id=cur.lastrowid, duplicate=False, today=given_today(db, uid, student["id"])), 201


@bp.delete("/api/points/<int:pid>")
@login_required
def take_back(pid):
    """Takes a point back: the line leaves the log and the boards."""
    own(pid)
    current_app.db.execute("DELETE FROM points WHERE id = ?", (pid,))
    current_app.db.commit()
    return jsonify(ok=True)


@bp.patch("/api/points/<int:pid>")
@login_required
def edit(pid):
    """Corrects a line of the log: how many, the note, the day, the subject, or the student (another student of the same class)."""
    row = own(pid)
    d = body()
    sets, args = [], []
    if "amount" in d:
        n = clean_amount(d["amount"])
        if n is None:
            return jsonify(error=f"عدد النقاط رقم صحيح من 1 إلى {MAX_AMOUNT} (وبالسالب للإنقاص) ولا يكون صفرًا"), 400
        sets.append("amount = ?")
        args.append(n)
    if "note" in d:
        sets.append("note = ?")
        args.append(clean_name(d["note"])[:80])
    if "day" in d:
        day = day_or_none(d["day"])
        if not day:
            return jsonify(error="اختاري يومًا لا يتجاوز اليوم ولا يسبقه بأكثر من سنة"), 400
        sets.append("day = ?")
        args.append(day)
    if "subject_id" in d:
        sid = toint(d["subject_id"]) or None
        if sid:
            subject_row(sid)
        sets.append("subject_id = ?")
        args.append(sid)
    if "student_id" in d:
        st = student_row(toint(d["student_id"]))
        if st["class_id"] != row["class_id"]:
            return jsonify(error="اختاري طالبًا من الفصل نفسه"), 400
        sets.append("student_id = ?")
        args.append(st["id"])
    if not sets:
        return jsonify(error="لا يوجد ما يتغير"), 400
    db = current_app.db
    db.execute(f"UPDATE points SET {', '.join(sets)}, edited_at = ? WHERE id = ?", (*args, now(), pid))
    db.commit()
    return jsonify(entry=entry(db.execute(ENTRY + " WHERE p.id = ?", (pid,)).fetchone()))


@bp.get("/api/points/log")
@login_required
def log():
    """The log, newest first, for the class, the student, the subject and the days asked for (all optional): {entries, total, sum}."""
    db, uid = current_app.db, g.user["id"]
    a = request.args
    where, args = ["p.user_id = ?"], [uid]
    if toint(a.get("class_id")):
        where.append("p.class_id = ?")
        args.append(class_row(toint(a.get("class_id")))["id"])
    if toint(a.get("student_id")):
        where.append("p.student_id = ?")
        args.append(student_row(toint(a.get("student_id")))["id"])
    if toint(a.get("subject_id")):
        where.append("p.subject_id = ?")
        args.append(subject_row(toint(a.get("subject_id")))["id"])
    for name, op in (("from", ">="), ("to", "<=")):
        if a.get(name):
            day = parse_day(a.get(name))
            if not day:
                raise Bad("يوم غير صحيح")
            where.append(f"p.day {op} ?")
            args.append(day.isoformat())
    if a.get("day"):
        day = parse_day(a.get("day"))
        if not day:
            raise Bad("يوم غير صحيح")
        where.append("p.day = ?")
        args.append(day.isoformat())
    cond = " WHERE " + " AND ".join(where)
    total, points = db.execute(f"SELECT COUNT(*), COALESCE(SUM(p.amount), 0) FROM points p{cond}", args).fetchone()
    limit = min(MAX_PAGE, toint(a.get("limit")) if toint(a.get("limit")) >= 1 else 50)
    offset = max(0, toint(a.get("offset")))
    rows = db.execute(f"{ENTRY}{cond} ORDER BY p.day DESC, p.created_at DESC, p.id DESC LIMIT ? OFFSET ?", [*args, limit, offset]).fetchall()
    return jsonify(entries=[entry(r) for r in rows], total=total, sum=points)


# ---------------------------------------------------------------- the board
def totals_by_student(db, uid, cid, sid, lo, hi) -> list:
    """Every student of the class with the points she has in the period (and in the subject, when one is asked for): a student with none is there with zero."""
    sql = "SELECT s.id, s.name, COALESCE(SUM(p.amount), 0) AS points, COUNT(p.id) AS awards, MAX(p.day) AS last_day FROM students s LEFT JOIN points p ON p.student_id = s.id AND p.user_id = ?"
    args = [uid]
    if lo:
        sql += " AND p.day >= ?"
        args.append(lo)
    if hi:
        sql += " AND p.day <= ?"
        args.append(hi)
    if sid:
        sql += " AND p.subject_id = ?"
        args.append(sid)
    sql += " WHERE s.class_id = ? AND s.user_id = ? GROUP BY s.id"
    return [{"student_id": r["id"], "name": r["name"], "points": r["points"], "awards": r["awards"], "last_day": r["last_day"] or ""} for r in db.execute(sql, [*args, cid, uid])]


@bp.get("/api/points/board")
@login_required
def board():
    """The board of a class: {class, subject, period, rows (every student, in order, each with a place), top (the first three places), more, total, awards}."""
    cls, subject, period, lo, hi = scope(request.args)
    rows = scoring.standings(totals_by_student(current_app.db, g.user["id"], cls["id"], subject["id"] if subject else None, lo, hi))
    top, more = scoring.podium(rows)
    return jsonify(**{"class": {"id": cls["id"], "name": cls["name"]}}, subject={"id": subject["id"], "name": subject["name"]} if subject else None, period=period,
                   period_name=scoring.NAMES[period], first=lo, last=hi, rows=rows, top=top, more=more,
                   total=sum(r["points"] for r in rows), awards=sum(r["awards"] for r in rows))


# ---------------------------------------------------------------- how many points an answer gives
@bp.get("/api/points/settings")
@login_required
def get_settings():
    return jsonify(**point_settings(current_app.db, g.user["id"]), limits={k: list(v) for k, v in LIMITS.items()})


@bp.put("/api/points/settings")
@login_required
def put_point_settings():
    d = body()
    db, uid = current_app.db, g.user["id"]
    patch = {}
    for k, (lo, hi) in LIMITS.items():
        if k in d:
            v = d[k]
            if isinstance(v, bool) or not isinstance(v, int) or not lo <= v <= hi:
                return jsonify(error=f"اختاري رقمًا من {lo} إلى {hi}"), 400
            patch["points_" + k] = v
    put_settings(db, uid, patch)
    db.commit()
    return jsonify(**point_settings(db, uid), limits={k: list(v) for k, v in LIMITS.items()})


@bp.get("/points")
@login_required
def page():
    return render_template("points.html")
