"""How participation points are added up: the days a period covers and who stands where on the board. Pure arithmetic: nothing here reads or writes the database."""
import datetime

PERIODS = ("today", "week", "term", "all")
NAMES = {"today": "اليوم", "week": "هذا الأسبوع", "term": "الفصل الدراسي", "all": "كل الفترات"}


def week_start(today: datetime.date) -> datetime.date:
    """The Sunday that began her week (the school week starts on Sunday)."""
    return today - datetime.timedelta(days=(today.weekday() + 1) % 7)


def bounds(period, today: datetime.date, term=None):
    """(first, last) as ISO days that a period covers; None on a side means no limit there. «الفصل الدراسي» is her current term (no limit when she has none)."""
    if period == "today":
        return today.isoformat(), today.isoformat()
    if period == "week":
        return week_start(today).isoformat(), today.isoformat()
    if period == "term" and term:
        return term["starts"], term["ends"]
    return None, None


def standings(rows) -> list:
    """The rows (each has "name" and "points") sorted by points and then name, every one given its place: 1, 2, 2, 3 ... (students with the same points share a place).
    A student with no points, or fewer than none, stands nowhere (place None)."""
    out, place, last = [], 0, None
    for r in sorted(rows, key=lambda r: (-r["points"], r["name"])):
        if r["points"] > 0 and r["points"] != last:
            place, last = place + 1, r["points"]
        out.append({**r, "rank": place if r["points"] > 0 else None})
    return out


def podium(ranked, places=3, cap=9):
    """(the students on the first places, how many more are on them but do not fit). Everyone who shares a place is on it, so a tie is never settled by the alphabet;
    `cap` only keeps a class where everyone has the same points from filling the screen."""
    on = [r for r in ranked if r["rank"] and r["rank"] <= places]
    return on[:cap], max(0, len(on) - cap)
