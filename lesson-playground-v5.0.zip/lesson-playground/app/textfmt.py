"""Counting in Arabic the way a teacher writes it: سؤال واحد، سؤالان، 3 أسئلة، 11 سؤالًا (the same rule is in app.js for the pages built in the browser)."""
import math


def percent(part, whole):
    """100 × part ÷ whole as a whole number, with the half rounded up (62.5 → 63: the way a teacher rounds, and the way the screens round with Math.round). None when there is no whole."""
    if not whole:
        return None
    if isinstance(part, int) and isinstance(whole, int):
        return (200 * part + whole) // (2 * whole)          # (whole numbers: exact, no float in between)
    return math.floor(100 * part / whole + 0.5)


def count(n, one: str, two: str, few: str, many: str) -> str:
    """one: the noun alone for 1 («سؤال واحد»); two: the dual for 2; few: the plural after 3 to 10 and for 0; many: the singular accusative after 11 and over."""
    try:
        n = int(n)
    except (TypeError, ValueError):
        n = 0
    if n == 1:
        return one
    if n == 2:
        return two
    if 3 <= n <= 10 or n == 0:
        return f"{n} {few}"
    return f"{n} {many}"


def questions(n) -> str:
    return count(n, "سؤال واحد", "سؤالان", "أسئلة", "سؤالًا")


def students(n) -> str:
    return count(n, "طالب واحد", "طالبان", "طلاب", "طالبًا")


def lessons(n) -> str:
    return count(n, "درس واحد", "درسان", "دروس", "درسًا")


def points(n) -> str:
    return count(n, "نقطة واحدة", "نقطتان", "نقاط", "نقطة")


def marks(x) -> str:
    """Marks the way a paper says them: درجة واحدة، درجتان، 3 درجات، 11 درجة، and with half a mark: نصف درجة، درجة ونصف، درجتان ونصف، 3 درجات ونصف."""
    try:
        v = float(x)
    except (TypeError, ValueError):
        v = 0.0
    whole, half = int(v), (v - int(v)) >= 0.5
    if not half:
        return count(whole, "درجة واحدة", "درجتان", "درجات", "درجة")
    if whole == 0:
        return "نصف درجة"
    return count(whole, "درجة", "درجتان", "درجات", "درجة") + " ونصف"



def assignments(n) -> str:
    return count(n, "واجب واحد", "واجبان", "واجبات", "واجبًا")


def day_offset(n) -> str:
    """Where a day is from today, in words: اليوم، غدًا، بعد يومين، بعد 5 أيام، أمس، قبل يومين، قبل 12 يومًا."""
    try:
        n = int(n)
    except (TypeError, ValueError):
        return ""
    if n == 0:
        return "اليوم"
    if n == 1:
        return "غدًا"
    if n == -1:
        return "أمس"
    word = {2: "يومين"}.get(abs(n)) or (f"{abs(n)} أيام" if 3 <= abs(n) <= 10 else f"{abs(n)} يومًا")
    return ("بعد " if n > 0 else "قبل ") + word
