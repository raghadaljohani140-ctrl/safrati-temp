"""The teacher's weekly timetable: for every day and period, the class she teaches and the subject.

She can fill the grid by hand or give the app the timetable she already has (a sheet, a Word table, a PDF, a picture): it is read, shown to her cell by cell with what it
matched and what is new, and saved only when she confirms. The periods a class has in a subject are what the plan (plan.py) lays its lessons over."""
import json
import re

from flask import Blueprint, current_app, g, jsonify, render_template, request

from . import extract, tables, timetable
from .classroom import ensure_subject, subjects_list
from .db import jload, now
from .security import Limiter, login_required
from .students import MAX_CLASSES, body, class_row, clean_name, toint

bp = Blueprint("schedule", __name__)
MAX_IMPORT_MB = 10
DEFAULT_DAYS = [0, 1, 2, 3, 4]
DEFAULT_PERIODS = 7
import_limit = Limiter(30, 3600)
_HHMM = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")


# ---------------------------------------------------------------- her settings (the days of her week, how many periods a day has)
def settings(db, uid) -> dict:
    row = db.execute("SELECT data FROM teacher_settings WHERE user_id = ?", (uid,)).fetchone()
    return jload(row["data"], {}) if row else {}


def put_settings(db, uid, patch: dict):
    data = settings(db, uid)
    data.update(patch)
    db.execute("INSERT INTO teacher_settings(user_id, data) VALUES (?,?) ON CONFLICT(user_id) DO UPDATE SET data = excluded.data", (uid, json.dumps(data, ensure_ascii=False)))


def hhmm(value) -> str:
    m = _HHMM.match(str(value or "").strip())
    return f"{int(m.group(1)):02d}:{m.group(2)}" if m else ""


# ---------------------------------------------------------------- reading
def schedule_data(db, uid) -> dict:
    cfg = settings(db, uid)
    slots = [{"day": r["day"], "period": r["period"], "class_id": r["class_id"], "subject_id": r["subject_id"]}
             for r in db.execute("SELECT day, period, class_id, subject_id FROM schedule_slots WHERE user_id = ? ORDER BY day, period", (uid,))]
    days = sorted({int(d) for d in cfg.get("days", DEFAULT_DAYS) if isinstance(d, int) and 0 <= d <= 6} | {s["day"] for s in slots})
    periods = max([int(cfg.get("periods") or DEFAULT_PERIODS)] + [s["period"] for s in slots])
    times = {str(r["period"]): {"starts": r["starts"], "ends": r["ends"]} for r in db.execute("SELECT period, starts, ends FROM schedule_times WHERE user_id = ? ORDER BY period", (uid,))}
    classes = [{"id": r["id"], "name": r["name"]} for r in db.execute("SELECT id, name FROM classes WHERE user_id = ? ORDER BY id", (uid,))]
    return {"days": days or DEFAULT_DAYS, "periods": min(periods, timetable.MAX_PERIODS), "day_names": timetable.DAY_NAMES, "slots": slots, "times": times,
            "classes": classes, "subjects": [{"id": s["id"], "name": s["name"]} for s in subjects_list()]}


@bp.get("/schedule")
@login_required
def page():
    return render_template("schedule.html")


@bp.get("/api/schedule")
@login_required
def data():
    return jsonify(schedule_data(current_app.db, g.user["id"]))


# ---------------------------------------------------------------- saving (one transaction: all of it or none of it)
def save_all(db, uid, days, periods, slots, times):
    """Replace the whole timetable. slots: [(day, period, class_id, subject_id)] already checked. A class and a subject that meet in the timetable are linked (she teaches it).
    The lessons of her plans keep their place in the row of periods when the periods change (the plans' logs say what moved)."""
    from . import plan
    with plan.realigning(db, uid, "تغيّر جدول الحصص"):
        db.execute("DELETE FROM schedule_slots WHERE user_id = ?", (uid,))
        linked = set()
        for day, period, cid, sid in slots:
            db.execute("INSERT INTO schedule_slots(user_id, day, period, class_id, subject_id) VALUES (?,?,?,?,?)", (uid, day, period, cid, sid))
            if (cid, sid) not in linked:
                linked.add((cid, sid))
                if not db.execute("SELECT 1 FROM class_subjects WHERE class_id = ? AND subject_id = ?", (cid, sid)).fetchone():
                    db.execute("INSERT INTO class_subjects(user_id, class_id, subject_id, created_at) VALUES (?,?,?,?)", (uid, cid, sid, now()))
        db.execute("DELETE FROM schedule_times WHERE user_id = ?", (uid,))
        for period, t in times.items():
            db.execute("INSERT INTO schedule_times(user_id, period, starts, ends) VALUES (?,?,?,?)", (uid, period, t[0], t[1]))
        put_settings(db, uid, {"days": days, "periods": periods})


def clean_times(raw) -> dict:
    out = {}
    if isinstance(raw, dict):
        for k, v in raw.items():
            p = toint(k)
            if 1 <= p <= timetable.MAX_PERIODS and isinstance(v, dict):
                a, b = hhmm(v.get("starts")), hhmm(v.get("ends"))
                if a or b:
                    out[p] = (a, b)
    return out


def clean_days(raw) -> list:
    days = sorted({toint(d) for d in (raw or []) if isinstance(d, int) and 0 <= d <= 6})
    return days or DEFAULT_DAYS


@bp.put("/api/schedule")
@login_required
def save():
    data = body()
    db = current_app.db
    uid = g.user["id"]
    slots_in = data.get("slots")
    if not isinstance(slots_in, list) or len(slots_in) > 7 * timetable.MAX_PERIODS:
        return jsonify(error="بيانات الجدول غير صحيحة"), 400
    mine_classes = {r["id"] for r in db.execute("SELECT id FROM classes WHERE user_id = ?", (uid,))}
    mine_subjects = {r["id"] for r in db.execute("SELECT id FROM subjects WHERE user_id = ?", (uid,))}
    seen, slots = set(), []
    for s in slots_in:
        if not isinstance(s, dict):
            return jsonify(error="بيانات الجدول غير صحيحة"), 400
        day, period, cid, sid = toint(s.get("day")), toint(s.get("period")), toint(s.get("class_id")), toint(s.get("subject_id"))
        if not (0 <= day <= 6 and 1 <= period <= timetable.MAX_PERIODS):
            return jsonify(error="يوم أو حصة غير صحيحة في الجدول"), 400
        if cid not in mine_classes or sid not in mine_subjects:
            return jsonify(error="فصل أو مادة غير موجودة"), 404
        if (day, period) in seen:
            return jsonify(error="في الجدول أكثر من فصل في الحصة نفسها"), 400
        seen.add((day, period))
        slots.append((day, period, cid, sid))
    periods = min(timetable.MAX_PERIODS, max([max(1, toint(data.get("periods")) or DEFAULT_PERIODS)] + [s[1] for s in slots]))
    days = sorted(set(clean_days(data.get("days"))) | {s[0] for s in slots})
    try:
        save_all(db, uid, days, periods, slots, clean_times(data.get("times")))
        db.commit()
    except Exception:
        db.rollback()
        raise
    return jsonify(schedule_data(db, uid))


# ---------------------------------------------------------------- importing a timetable she already has
def _cells_out(parsed):
    return [{"day": c["day"], "period": c["period"], "class_id": c["class_id"], "class_name": c["class"], "subject_id": c["subject_id"], "subject_name": c["subject"], "raw": c["raw"]}
            for c in sorted(parsed["cells"], key=lambda c: (c["day"], c["period"]))]


@bp.post("/api/schedule/import")
@login_required
def import_file():
    """Read a timetable file and show what it holds, matched with her classes and subjects. Nothing is saved."""
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify(error="اختاري ملف الجدول أولًا"), 400
    if not import_limit.allow(g.user["id"]):
        return jsonify(error="قرأتِ ملفات كثيرة خلال ساعة، جرّبي بعد قليل"), 429
    data = f.read()
    if not data:
        return jsonify(error="الملف فارغ"), 400
    if len(data) > MAX_IMPORT_MB * 1024 * 1024:
        return jsonify(error=f"الملف كبير، الحد الأقصى {MAX_IMPORT_MB} ميجابايت"), 413
    try:
        kind = tables.kind_of(f.filename, data[:16])
        if kind in ("pdf", "image"):
            sheets = tables.sheets_from_text(extract.plain(kind, data))
        else:
            sheets = tables.read_sheets(kind, data)
    except (tables.TableError, extract.ExtractError) as exc:
        return jsonify(error=str(exc)), 400
    db = current_app.db
    uid = g.user["id"]
    subjects = [(s["id"], s["name"]) for s in subjects_list()]
    classes = [(r["id"], r["name"]) for r in db.execute("SELECT id, name FROM classes WHERE user_id = ? ORDER BY id", (uid,))]
    parsed = timetable.parse(sheets, [n for _i, n in subjects])
    if not parsed:
        return jsonify(error="لم نجد جدول حصص واضحًا في الملف. تأكدي أن فيه أيام الأسبوع والحصص، أو املئي الجدول بنفسك"), 400
    timetable.resolve(parsed, classes, subjects)
    cells = _cells_out(parsed)
    return jsonify(cells=cells, times={str(p): {"starts": a, "ends": b} for p, (a, b) in parsed["times"].items()}, periods=parsed["periods"],
                   days=sorted({c["day"] for c in cells}), classes=[{"id": i, "name": n} for i, n in classes], subjects=[{"id": i, "name": n} for i, n in subjects])


@bp.post("/api/schedule/import/confirm")
@login_required
def import_confirm():
    """Save the timetable she reviewed: each cell names a class and a subject she has (by id) or a new one (by name, made now). It replaces her timetable."""
    data = body()
    db = current_app.db
    uid = g.user["id"]
    cells = data.get("cells")
    if not isinstance(cells, list) or not cells or len(cells) > 7 * timetable.MAX_PERIODS:
        return jsonify(error="لا توجد حصص لحفظها"), 400
    mine_classes = {r["id"] for r in db.execute("SELECT id FROM classes WHERE user_id = ?", (uid,))}
    mine_subjects = {r["id"] for r in db.execute("SELECT id FROM subjects WHERE user_id = ?", (uid,))}
    made_classes, slots, seen = {}, [], set()
    try:
        for c in cells:
            if not isinstance(c, dict):
                raise ValueError
            day, period = toint(c.get("day")), toint(c.get("period"))
            if not (0 <= day <= 6 and 1 <= period <= timetable.MAX_PERIODS) or (day, period) in seen:
                raise ValueError
            cid = toint(c.get("class_id"))
            if cid:
                if cid not in mine_classes:
                    db.rollback()
                    return jsonify(error="فصل غير موجود"), 404
            else:
                name = clean_name(c.get("class_name"))
                if len(name) < 2:
                    raise ValueError
                if name not in made_classes:
                    row = db.execute("SELECT id FROM classes WHERE user_id = ? AND name = ?", (uid, name)).fetchone()
                    if row:
                        made_classes[name] = row["id"]
                    else:
                        if db.execute("SELECT COUNT(*) FROM classes WHERE user_id = ?", (uid,)).fetchone()[0] >= MAX_CLASSES:
                            db.rollback()
                            return jsonify(error=f"الحد الأقصى {MAX_CLASSES} فصلًا"), 400
                        made_classes[name] = db.execute("INSERT INTO classes(user_id, name, created_at) VALUES (?,?,?)", (uid, name, now())).lastrowid
                cid = made_classes[name]
            sid = toint(c.get("subject_id"))
            if sid:
                if sid not in mine_subjects:
                    db.rollback()
                    return jsonify(error="مادة غير موجودة"), 404
            else:
                sid = ensure_subject(c.get("subject_name"))
                if sid is None:
                    db.rollback()
                    return jsonify(error="اكتبي اسم المادة لكل حصة (أو احذفي الحصة)"), 400
            seen.add((day, period))
            slots.append((day, period, cid, sid))
        periods = min(timetable.MAX_PERIODS, max([toint(data.get("periods")) or DEFAULT_PERIODS] + [s[1] for s in slots]))
        days = sorted(set(clean_days(data.get("days"))) | {s[0] for s in slots})
        save_all(db, uid, days, periods, slots, clean_times(data.get("times")))
        db.commit()
    except ValueError:
        db.rollback()
        return jsonify(error="بيانات الجدول غير صحيحة"), 400
    except Exception:
        db.rollback()
        raise
    return jsonify(schedule_data(db, uid))
