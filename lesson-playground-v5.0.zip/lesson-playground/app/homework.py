"""Activities and homework (the fourth button of the home screen). The teacher gives a class a homework, an activity, a project, a reading or a revision with its instructions, the
day it is due and the students it is for; the app writes the message for the class's WhatsApp group (nothing is sent from here), and she ticks who did it, who did part of it and who did not.

Everything is the teacher's own: an assignment belongs to one of her classes, only students of THAT class can be on it, and a class, a student or an assignment of anyone else is
treated as if it did not exist. The students an assignment is for are fixed when it is made (a student who joins the class later is not owed an old homework) and she can change them."""
import datetime
import logging
import re

from flask import Blueprint, abort, current_app, g, jsonify, render_template, request

from . import classroom, plan, planner, share, terms, textfmt
from .classroom import subject_row
from .db import now
from .security import Limiter, login_required
from .students import body, class_row, toint

log = logging.getLogger(__name__)
bp = Blueprint("homework", __name__)
create_limit = Limiter(60, 3600)
KINDS = {"homework": ("واجب", "📚"), "activity": ("نشاط", "🎯"), "project": ("مشروع", "🧩"), "reading": ("قراءة", "📖"), "review": ("مراجعة", "🔁")}
STATUSES = ("pending", "done", "partial", "missing")
STATUS_NAMES = {"pending": "لم يُراجَع", "done": "أنجز", "partial": "أنجز جزءًا", "missing": "لم ينجز"}
KIND_LIST = [{"key": k, "name": v[0], "icon": v[1]} for k, v in KINDS.items()]
DAY_FORM = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}")
MAX_ASSIGNMENTS = 1500
MAX_INSTRUCTIONS = 1500
MAX_TITLE = 80
MAX_TOPIC = 100
MAX_TARGETS = 300
MAX_DAYS_AHEAD = 400
LIST_LIMIT = 300


# ---------------------------------------------------------------- what is hers
def assignment_row(aid):
    row = current_app.db.execute("SELECT * FROM assignments WHERE id = ? AND user_id = ?", (aid, g.user["id"])).fetchone()
    if not row:
        abort(404)                     # another teacher's assignment looks exactly like one that does not exist
    return row


def class_students(db, uid, cid):
    return db.execute("SELECT id, name FROM students WHERE class_id = ? AND user_id = ? ORDER BY name, id", (cid, uid)).fetchall()


# ---------------------------------------------------------------- cleaning what she typed
def clean_text(value, limit=MAX_INSTRUCTIONS):
    """Lines kept, each one trimmed and its inner spaces collapsed, no more than one blank line in a row. Only text is text: a number or a list is nothing."""
    text = "\n".join(" ".join(line.split()) for line in (value if isinstance(value, str) else "").replace("\r", "").split("\n")).strip()
    while "\n\n\n" in text:
        text = text.replace("\n\n\n", "\n\n")
    return text[:limit].rstrip() if limit else text


def one_line(value, limit):
    return " ".join((value if isinstance(value, str) else "").split())[:limit]


def parse_due(value, since: datetime.date):
    """(day, error): '' for no day, the iso day when it is a real day from `since` to a little over a year later, else an error sentence."""
    v = (value if isinstance(value, str) else "" if value is None or value == "" else "?").strip()
    if not v:
        return "", None
    try:
        d = datetime.date.fromisoformat(v) if DAY_FORM.fullmatch(v) else None          # 2026-09-08 and nothing else: not 20260908, not a week of the year
    except ValueError:
        d = None
    if d is None:
        return None, "موعد التسليم غير صحيح"
    if d < since:
        return None, "موعد التسليم قبل يوم إعطاء الواجب"
    if d > since + datetime.timedelta(days=MAX_DAYS_AHEAD):
        return None, "موعد التسليم بعيد جدًا"
    return d.isoformat(), None


def default_title(kind, subject_name, topic):
    return (KINDS[kind][0] + (f" {subject_name}" if subject_name else "") + (f" — {topic}" if topic else ""))[:MAX_TITLE]


def due_info(due, today: datetime.date):
    """(state, days from today): none, later, tomorrow, today or past."""
    if not due:
        return "none", None
    n = (datetime.date.fromisoformat(due) - today).days
    return ("past" if n < 0 else "today" if n == 0 else "tomorrow" if n == 1 else "later"), n


def next_lesson(db, uid, cid, sid, today: datetime.date):
    """The next day (after today) this class has this subject in her timetable, or None: the usual day a homework is due. It needs the term and the timetable; holidays and the days
    she is absent are skipped, as the plan skips them."""
    if not sid:
        return None
    slots, term = plan.slots_of(db, uid, cid, sid), terms.current(db, uid, today)
    if not slots or not term:
        return None
    a, b = planner.parse_day(term["starts"]), planner.parse_day(term["ends"])
    if not a or not b:
        return None
    occs = planner.occurrences(slots, a, b, terms.holidays_of(db, term["id"]), plan.absent_set(db, uid, term), first=today + datetime.timedelta(days=1))
    return {"date": occs[0].day.isoformat(), "text": share.ar_date(occs[0].day.isoformat())} if occs else None


# ---------------------------------------------------------------- reading an assignment
def counts_of(rows) -> dict:
    c = {s: 0 for s in STATUSES}
    for r in rows:
        c[r["status"]] += 1
    total = sum(c.values())
    return {"total": total, **c, "checked": total - c["pending"], "percent": textfmt.percent(c["done"], total)}


def stats_for(db, ids) -> dict:
    out = {i: counts_of([]) for i in ids}
    if ids:
        marks = ",".join("?" * len(ids))
        grouped = {}
        for r in db.execute(f"SELECT assignment_id, status, COUNT(*) AS n FROM assignment_students WHERE assignment_id IN ({marks}) GROUP BY assignment_id, status", list(ids)):
            grouped.setdefault(r["assignment_id"], []).extend([{"status": r["status"]}] * r["n"])
        for i, rows in grouped.items():
            out[i] = counts_of(rows)
    return out


def assignment_dict(db, row, stats, today) -> dict:
    cls = db.execute("SELECT id, name, whatsapp FROM classes WHERE id = ?", (row["class_id"],)).fetchone()
    subj = db.execute("SELECT id, name FROM subjects WHERE id = ?", (row["subject_id"],)).fetchone() if row["subject_id"] else None
    state, days = due_info(row["due_date"], today)
    kind_name, icon = KINDS[row["kind"]]
    return {"id": row["id"], "kind": row["kind"], "kind_name": kind_name, "icon": icon, "title": row["title"], "topic": row["topic"], "instructions": row["instructions"],
            "given": row["given_date"], "given_text": share.ar_date(row["given_date"]), "due": row["due_date"], "due_text": share.ar_date(row["due_date"]) if row["due_date"] else "",
            "due_state": state, "due_label": textfmt.day_offset(days) if days is not None else "", "closed": bool(row["closed"]),
            "class": {"id": cls["id"], "name": cls["name"], "whatsapp": cls["whatsapp"]} if cls else None, "subject": {"id": subj["id"], "name": subj["name"]} if subj else None,
            "stats": stats, "needs_review": (not row["closed"]) and state in ("today", "past") and stats["pending"] > 0, "created_at": row["created_at"]}


def detail(db, row, today) -> dict:
    """The assignment with the students it is for (name order) and the students of the class who are not on it, for changing the list."""
    rows = db.execute("""SELECT s.id AS student_id, s.name, a.status FROM assignment_students a JOIN students s ON s.id = a.student_id
                         WHERE a.assignment_id = ? AND a.user_id = ? AND s.user_id = ? ORDER BY s.name, s.id""", (row["id"], row["user_id"], row["user_id"])).fetchall()
    out = assignment_dict(db, row, counts_of(rows), today)
    on = {r["student_id"] for r in rows}
    out["students"] = [{"student_id": r["student_id"], "name": r["name"], "status": r["status"]} for r in rows]
    out["others"] = [{"id": s["id"], "name": s["name"]} for s in class_students(db, row["user_id"], row["class_id"]) if s["id"] not in on]
    out["everyone"] = not out["others"]
    out["statuses"] = [{"key": k, "name": STATUS_NAMES[k]} for k in STATUSES]
    out["kinds"] = KIND_LIST
    return out


def attention(db, uid, today_iso) -> int:
    """How many open assignments are due (or past due) and still have students she has not checked: the number on the home screen."""
    return db.execute("""SELECT COUNT(*) FROM assignments a WHERE a.user_id = ? AND a.closed = 0 AND a.due_date != '' AND a.due_date <= ?
                         AND EXISTS (SELECT 1 FROM assignment_students s WHERE s.assignment_id = a.id AND s.status = 'pending')""", (uid, today_iso)).fetchone()[0]


# ---------------------------------------------------------------- the pages
@bp.get("/homework")
@login_required
def page():
    return render_template("homework.html")


@bp.get("/homework/<int:aid>")
@login_required
def one_page(aid):
    assignment_row(aid)
    return render_template("homework_one.html", aid=aid)


# ---------------------------------------------------------------- the list, the lessons of a class, making one
@bp.get("/api/homework")
@login_required
def listing():
    db, uid = current_app.db, g.user["id"]
    cid = toint(request.args.get("class_id"))
    state = request.args.get("state", "all")
    sql, args = "SELECT * FROM assignments WHERE user_id = ?", [uid]
    if cid:
        class_row(cid)
        sql, args = sql + " AND class_id = ?", args + [cid]
    rows = []
    for closed in ((0, 1) if state not in ("open", "closed") else ((0,) if state == "open" else (1,))):          # all the ones she still follows are listed; of the finished ones, the newest
        rows += db.execute(sql + " AND closed = ? ORDER BY id DESC LIMIT ?", args + [closed, LIST_LIMIT if closed else MAX_ASSIGNMENTS]).fetchall()
    today = classroom.today_date()
    stats = stats_for(db, [r["id"] for r in rows])
    items = [assignment_dict(db, r, stats[r["id"]], today) for r in rows]
    items.sort(key=lambda a: (a["closed"], "" if a["closed"] else (a["due"] or "9999-12-31"), -a["id"]))          # open ones first, the nearest day first, the ones with no day last
    return jsonify(assignments=items, attention=attention(db, uid, today.isoformat()), kinds=KIND_LIST, today=today.isoformat(), max_days=MAX_DAYS_AHEAD)


@bp.get("/api/homework/lessons")
@login_required
def lessons():
    """What the form needs to know about a class and a subject: the next day they meet (the usual due day) and the lessons of the book she teaches them, to name the lesson a homework
    is about (optional): in the order of the book, the ones done in the plan marked."""
    db, uid = current_app.db, g.user["id"]
    cid, sid = toint(request.args.get("class_id")), toint(request.args.get("subject_id"))
    class_row(cid)
    if sid:
        subject_row(sid)
    nxt = next_lesson(db, uid, cid, sid, classroom.today_date())
    link = db.execute("SELECT book_id FROM class_subjects WHERE user_id = ? AND class_id = ? AND subject_id = ?", (uid, cid, sid)).fetchone() if sid else None
    book = db.execute("SELECT id, title FROM books WHERE id = ? AND user_id = ?", (link["book_id"], uid)).fetchone() if link and link["book_id"] else None
    if not book:
        return jsonify(book=None, lessons=[], next_lesson=nxt)
    done = {r["book_lesson_id"] for r in db.execute("SELECT book_lesson_id FROM plan_items WHERE user_id = ? AND class_id = ? AND subject_id = ? AND status = 'done'", (uid, cid, sid))}
    units = {r["id"]: r["title"] for r in db.execute("SELECT id, title FROM book_units WHERE book_id = ?", (book["id"],))}
    out = [{"id": r["id"], "title": r["title"], "unit": units.get(r["unit_id"], ""), "done": r["id"] in done} for r in db.execute(
        "SELECT id, unit_id, title FROM book_lessons WHERE book_id = ? AND user_id = ? AND kind != 'exam' ORDER BY position, id", (book["id"], uid))]
    return jsonify(book=dict(book), lessons=out, next_lesson=nxt)


def pick_targets(db, uid, cid, raw):
    """The ids of the students an assignment is for. Nothing or «all» is every student of the class; a list may hold students of THIS class only (anyone else is not found)."""
    mine = {s["id"] for s in class_students(db, uid, cid)}
    if raw is None or raw == "all":
        return sorted(mine), None
    if not isinstance(raw, list) or len(raw) > MAX_TARGETS:
        return None, (jsonify(error="قائمة الطلاب غير صحيحة"), 400)
    ids = [toint(x) for x in raw]
    if not ids:
        return None, (jsonify(error="اختاري طالبًا واحدًا على الأقل، أو اختاري كل الفصل"), 400)
    if any(i not in mine for i in ids):
        abort(404)
    return sorted(set(ids)), None


def add_targets(db, row, ids):
    for sid in ids:
        db.execute("INSERT OR IGNORE INTO assignment_students(assignment_id, user_id, class_id, student_id, status, updated_at) VALUES (?,?,?,?, 'pending', ?)", (row["id"], row["user_id"], row["class_id"], sid, now()))


@bp.post("/api/homework")
@login_required
def create():
    db, uid = current_app.db, g.user["id"]
    d = body()
    cls = class_row(toint(d.get("class_id")))
    sid = toint(d.get("subject_id")) or None
    subject = subject_row(sid) if sid else None
    kind = "homework" if d.get("kind") is None else d["kind"]          # no kind is the usual one; a kind that is not one of the five is refused
    if not isinstance(kind, str) or kind not in KINDS:
        return jsonify(error="نوع غير صحيح"), 400
    instructions = clean_text(d.get("instructions"), 0)
    if len(instructions) < 3:
        return jsonify(error="اكتبي المطلوب من الطلاب"), 400
    if len(instructions) > MAX_INSTRUCTIONS:
        return jsonify(error=f"المطلوب أطول من {MAX_INSTRUCTIONS} حرفًا. اختصريه أو قسّميه إلى واجبين"), 400
    today = classroom.today_date()
    due, err = parse_due(d.get("due"), today)
    if err:
        return jsonify(error=err), 400
    ids, bad = pick_targets(db, uid, cls["id"], d.get("students"))
    if bad:
        return bad
    if db.execute("SELECT COUNT(*) FROM assignments WHERE user_id = ?", (uid,)).fetchone()[0] >= MAX_ASSIGNMENTS:
        return jsonify(error=f"وصلتِ إلى الحد الأقصى ({MAX_ASSIGNMENTS}). احذفي القديم منها أولًا"), 400
    if not create_limit.allow(uid):
        return jsonify(error="أنشأتِ واجبات كثيرة خلال ساعة، جرّبي بعد قليل"), 429
    topic = one_line(d.get("topic"), MAX_TOPIC)
    title = one_line(d.get("title"), MAX_TITLE) or default_title(kind, subject["name"] if subject else "", topic)
    cur = db.execute("INSERT INTO assignments(user_id, class_id, subject_id, kind, title, topic, instructions, given_date, due_date, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                     (uid, cls["id"], sid, kind, title, topic, instructions, today.isoformat(), due, now(), now()))
    row = db.execute("SELECT * FROM assignments WHERE id = ?", (cur.lastrowid,)).fetchone()
    add_targets(db, row, ids)
    db.commit()
    return jsonify(assignment=detail(db, row, today)), 201


@bp.get("/api/homework/<int:aid>")
@login_required
def one(aid):
    return jsonify(assignment=detail(current_app.db, assignment_row(aid), classroom.today_date()))


@bp.patch("/api/homework/<int:aid>")
@login_required
def edit(aid):
    """Anything of it may change at any time: the words, the kind, the day, the subject, the students, and whether she is still following it."""
    db, uid = current_app.db, g.user["id"]
    row = assignment_row(aid)
    d = body()
    patch = {}
    if "kind" in d:
        if not isinstance(d["kind"], str) or d["kind"] not in KINDS:
            return jsonify(error="نوع غير صحيح"), 400
        patch["kind"] = d["kind"]
    if "instructions" in d:
        text = clean_text(d.get("instructions"), 0)
        if len(text) < 3:
            return jsonify(error="اكتبي المطلوب من الطلاب"), 400
        if len(text) > MAX_INSTRUCTIONS:
            return jsonify(error=f"المطلوب أطول من {MAX_INSTRUCTIONS} حرفًا"), 400
        patch["instructions"] = text
    if "topic" in d:
        patch["topic"] = one_line(d.get("topic"), MAX_TOPIC)
    if "title" in d:
        t = one_line(d.get("title"), MAX_TITLE)
        if len(t) < 2:
            return jsonify(error="اكتبي عنوانًا للواجب"), 400
        patch["title"] = t
    if "subject_id" in d:
        sid = toint(d.get("subject_id")) or None
        if sid:
            subject_row(sid)
        patch["subject_id"] = sid
    if "due" in d:
        due, err = parse_due(d.get("due"), datetime.date.fromisoformat(row["given_date"]))
        if err:
            return jsonify(error=err), 400
        patch["due_date"] = due
    if "closed" in d:
        if not isinstance(d["closed"], bool):
            return jsonify(error="قيمة غير صحيحة"), 400
        patch["closed"] = 1 if d["closed"] else 0
    ids = None
    if "students" in d:
        ids, bad = pick_targets(db, uid, row["class_id"], d.get("students"))
        if bad:
            return bad
    if patch or ids is not None:
        patch["updated_at"] = now()
        db.execute(f"UPDATE assignments SET {', '.join(f'{k} = ?' for k in patch)} WHERE id = ?", (*patch.values(), aid))
    if ids is not None:
        keep = ",".join("?" * len(ids))
        db.execute(f"DELETE FROM assignment_students WHERE assignment_id = ? AND student_id NOT IN ({keep})", (aid, *ids))          # a student taken off loses her line; the others keep theirs
        add_targets(db, row, ids)
    db.commit()
    return jsonify(assignment=detail(db, assignment_row(aid), classroom.today_date()))


@bp.delete("/api/homework/<int:aid>")
@login_required
def delete(aid):
    assignment_row(aid)
    current_app.db.execute("DELETE FROM assignments WHERE id = ? AND user_id = ?", (aid, g.user["id"]))          # who did it and who did not goes with it
    current_app.db.commit()
    return jsonify(ok=True)


@bp.post("/api/homework/<int:aid>/copy")
@login_required
def copy(aid):
    """The same homework for another class of hers (or the same one again): for all its students, due on the same day if that day has not passed."""
    db, uid = current_app.db, g.user["id"]
    row = assignment_row(aid)
    cls = class_row(toint(body().get("class_id")))
    if db.execute("SELECT COUNT(*) FROM assignments WHERE user_id = ?", (uid,)).fetchone()[0] >= MAX_ASSIGNMENTS:
        return jsonify(error=f"وصلتِ إلى الحد الأقصى ({MAX_ASSIGNMENTS}). احذفي القديم منها أولًا"), 400
    today = classroom.today_date()
    due = row["due_date"] if row["due_date"] and row["due_date"] >= today.isoformat() else ""
    cur = db.execute("INSERT INTO assignments(user_id, class_id, subject_id, kind, title, topic, instructions, given_date, due_date, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                     (uid, cls["id"], row["subject_id"], row["kind"], row["title"], row["topic"], row["instructions"], today.isoformat(), due, now(), now()))
    new = db.execute("SELECT * FROM assignments WHERE id = ?", (cur.lastrowid,)).fetchone()
    add_targets(db, new, [s["id"] for s in class_students(db, uid, cls["id"])])
    db.commit()
    return jsonify(assignment=detail(db, new, today)), 201


# ---------------------------------------------------------------- who did it
@bp.put("/api/homework/<int:aid>/status")
@login_required
def set_status(aid):
    """The state of some of the students: [{student_id, status}]. Every line is checked first and nothing is saved unless all are right; a student who is not on this assignment is not found."""
    db = current_app.db
    row = assignment_row(aid)
    items = body().get("items")
    if not isinstance(items, list) or not items or len(items) > MAX_TARGETS:
        return jsonify(error="لا شيء لحفظه"), 400
    on = {r["student_id"] for r in db.execute("SELECT student_id FROM assignment_students WHERE assignment_id = ? AND user_id = ?", (aid, row["user_id"]))}
    clean = {}
    for it in items:
        if not isinstance(it, dict):
            return jsonify(error="سطر غير صالح"), 400
        sid, status = toint(it.get("student_id")), it.get("status")
        if status not in STATUSES:
            return jsonify(error="حالة غير صحيحة"), 400
        if sid not in on:
            abort(404)
        clean[sid] = status
    for sid, status in clean.items():
        db.execute("UPDATE assignment_students SET status = ?, updated_at = ? WHERE assignment_id = ? AND student_id = ?", (status, now(), aid, sid))
    db.execute("UPDATE assignments SET updated_at = ? WHERE id = ?", (now(), aid))
    db.commit()
    return jsonify(assignment=detail(db, assignment_row(aid), classroom.today_date()))


@bp.post("/api/homework/<int:aid>/rest")
@login_required
def mark_rest(aid):
    """Everyone she has not checked yet gets one state («the rest did it»): the ones she already marked are left as they are."""
    db = current_app.db
    assignment_row(aid)
    status = body().get("status")
    if status not in ("done", "partial", "missing"):
        return jsonify(error="حالة غير صحيحة"), 400
    db.execute("UPDATE assignment_students SET status = ?, updated_at = ? WHERE assignment_id = ? AND user_id = ? AND status = 'pending'", (status, now(), aid, g.user["id"]))
    db.execute("UPDATE assignments SET updated_at = ? WHERE id = ?", (now(), aid))
    db.commit()
    return jsonify(assignment=detail(db, assignment_row(aid), classroom.today_date()))


# ---------------------------------------------------------------- the messages for WhatsApp
@bp.get("/api/homework/<int:aid>/share")
@login_required
def share_texts(aid):
    db = current_app.db
    row = assignment_row(aid)
    a = assignment_dict(db, row, counts_of([]), classroom.today_date())
    announce, reminder = share.homework_announcement(a), share.homework_reminder(a)
    outside = db.execute("SELECT 1 FROM students s WHERE s.class_id = ? AND s.user_id = ? AND s.id NOT IN (SELECT student_id FROM assignment_students WHERE assignment_id = ?) LIMIT 1",
                         (row["class_id"], row["user_id"], aid)).fetchone()
    return jsonify(announce=announce, announce_wa=share.wa_text_url(announce), announce_too_long=len(announce) > share.MAX_TEXT, reminder=reminder, reminder_wa=share.wa_text_url(reminder),
                   group=a["class"]["whatsapp"] if a["class"] else "", for_some=bool(outside))          # for_some: the students are only some of the class, and the group reads the message too
