"""Making the questions. Two providers behind one door:
 * `offline` (the default, free): reads the file's sentences with plain rules and builds the questions from them. No key, no cost, nothing leaves the server.
 * `claude` (paid, OFF until the owner approves a key): sends the file's text to the Anthropic API with strict instructions to use the file only.
Whatever the provider, every question is checked by `grounding.verify`; an answer that is not in the file is never shown as sure."""
import json
import random
import re
import urllib.request

from . import aimodel, grounding as G, meta as lesson_meta

KINDS = ("qa", "mcq", "tf", "cloze", "short", "review")
KIND_NAMES = {"qa": "سؤال وجواب", "mcq": "اختيار من متعدد", "tf": "صح أو خطأ", "cloze": "أكمل الفراغ", "short": "سؤال قصير", "review": "سؤال مراجعة"}
BLANK = "_____"
WORD = re.compile(r"[ء-يً-ْ٠-٩A-Za-z0-9]+")
STOP = set("""في من على الى إلى عن مع هذا هذه ذلك تلك هو هي هم هن كان كانت يكون تكون التي الذي الذين اللذان ان أن إن إذا اذا ثم او أو لا لم لن قد كل بعض غير بين عند عندما حتى لكن
كما ايضا أيضا هناك بعد قبل خلال منذ حيث اي أي ما ماذا كيف لماذا اين أين متى فقط جدا جدًا وهو وهي وهم يمكن يتم تم ولا وقد وان وإن بها به له لها لهم منها منه فيها فيه عليها عليه
إلا الا بل عنه عنها اذ إذ مثل نحو دون سوى لدى لذلك ولذلك وكان وكانت اما أما انه إنه انها إنها هنا هنالك""".split())
DEF_CUES = r"(?:هو|هي|هم|هما|تعني|يعني|تعرّف بأنها|تعرف بأنها|يعرّف بأنه|يعرف بأنه|تسمى|يسمى|تُسمى|يُسمى|عبارة عن|تُعدّ|تعد|يُعدّ|يعد)"
DEF_RE = re.compile(rf"^(?P<term>[^،,:؛.]{{2,40}}?)\s+{DEF_CUES}\s+(?P<def>.{{12,}})$")
COLON_RE = re.compile(r"^(?P<term>[^:،,.]{2,30}):\s*(?P<def>.{12,})$")
CAUSE_RE = re.compile(r"\s(لأن|لان|بسبب|نتيجة|لكي|حتى|مما يؤدي إلى|ويؤدي إلى|يؤدي إلى|ولذلك|لذلك)\s")


# Lines of a file's cover and footer are not lesson: the ministry, the school, a teacher's name, a web address, a phone, a page number, a date of the year.
# A question built from them would be an odd one («ما اسم المدرسة؟»). The first group is dropped wherever it stands; the second only in a short line,
# because words such as «مدرسة» or «الفصل الدراسي» can be part of a real sentence.
_STRONG_NOISE = re.compile(r"https?://|www\.|[\w.+-]+@[\w-]+\.\w|\b0?5\d{8}\b|\+?966\s?\d{8,9}|وزارة\s+التعليم|المملكة\s+العربية\s+السعودية|الإدارة\s+العامة\s+للتعليم|إدارة\s+(?:ال)?تعليم|مكتب\s+(?:ال)?تعليم|"
                           r"اسم\s+(?:الطالب|الطالبة|المعلم|المعلمة)|إعداد\s+(?:المعلم|المعلمة|الأستاذ)|حقوق\s+(?:الطبع|النشر)|جميع\s+الحقوق|(?:ال)?صفحة\s*:?\s*\d+|رقم\s+(?:الجلوس|الهوية)|"
                           r"\d{4}\s*(?:هـ|ه)\b|\d{1,2}\s*[/\-]\s*\d{1,2}\s*[/\-]\s*\d{2,4}")
_SOFT_NOISE = re.compile(r"(?<![ء-ي])(?:مدرسة|ثانوية\s+\S+|متوسطة\s+\S+|ابتدائية\s+\S+)|العام\s+الدراسي|الفصل\s+الدراسي|(?:^|\s)المعلمة\s*:|(?:^|\s)المعلم\s*:|شكرا\s+لكم|شكراً\s+لكم|هل\s+لديكم\s+أسئلة|نهاية\s+الدرس|انتهى\s+الدرس")


def is_noise(sentence: str) -> bool:
    if _STRONG_NOISE.search(sentence):
        return True
    return len(sentence.split()) <= 14 and bool(_SOFT_NOISE.search(sentence))


def split_sentences(text: str) -> list[str]:
    out = []
    for block in re.split(r"\n+", text):
        block = re.sub(r"^[\s•\-–—*·●▪◦\d\)\.\(]+(?=\S)", "", block).strip() if re.match(r"^\s*[•\-–—*·●▪◦]|\s*\d+[\)\.]\s", block) else block.strip()
        for s in re.split(r"(?<=[.!؟?؛])\s+", block):
            s = s.strip()
            n = len(WORD.findall(s))
            if 5 <= n <= 45 and not is_noise(s):
                out.append(s.rstrip("."))
    seen, uniq = set(), []
    for s in out:
        k = G.norm(s)
        if k not in seen:
            seen.add(k)
            uniq.append(s)
    return uniq


# A sentence taken out of the middle of a text can lean on the one before it: «وتسميته بتوحيد الألوهية…» (and its naming…) has no «it» without that sentence.
# As a question it is not clear to the pupils and not even true or false by itself. Such a sentence is left out of the questions, except when only a «و»
# joins a whole sentence to the one before («والنواة مركز التحكم»): then the «و» is taken off and the rest is used.
_EDGE = " \t «»\"'“”‘’()[]{}<>-–—•*·،,:؛"
_MARKS = re.compile(r"[ً-ٰٟـ]")                         # the vowel signs and the stretching letter
_ROOT_WAW = frozenset("""وظيفة وظائف وحدة وحدات وراثة وراثي وراثية وزن وزارة وقت وسيلة وسائل وسط واجب واجبات وجه وجود وجوب وحي وحدانية وصف وضع وطن وقود ولاية وادي
وجد وصل وقع وعد وضوء وفاة وصية وقف وثيقة وردة ورقة وجبة وزير والد والدة والدان والدين واقع واضح واضحة وارد واحد واحدة وقائع وقاية وسام ولادة وليد وكيل وكالة وصول ورثة
وفد وفرة وعي وهج ورد ولد وصلة وصايا وقائي وجيز وسيط واسع واسعة وافر وافية وفير وحش وحوش وحيد وحيدة وراء وعاء وفق ولي وليمة وقفة وثائق وسائط وظائفها""".split())
_FA_LEAD = frozenset("فهو فهي فهم فهن فإن فان فإذا فاذا فإنه فانه فإنها فانها فقد فلا فلم فلن فما فمن فكل فعند فبعد فقبل فيه فيها فهذا فهذه فذلك فتلك فلذلك فأما فاما فكان فكانت فيكون فتكون".split())
_LEAD_WORDS = frozenset("""ثم لكن لكنه لكنها لكنهم بل أو او أم إذ اذ إذن اذن كما كذلك أيضا أيضًا ايضا لذلك لهذا لذا بذلك بهذا بهذه أما اما إلا الا عندئذ حينئذ عندها حينها بالتالي
هذا هذه هذان هاتان هذين هؤلاء ذلك تلك أولئك اولئك هو هي هم هن هما الذي التي الذين اللذان اللتان اللاتي اللواتي حيث بينما مما ممن منها منه فيه فيها به بها له لها عليه عليها
عنه عنها إليه إليها اليه اليها""".split())


def _first_word(sentence: str) -> str:
    lead = sentence.strip().lstrip(_EDGE)
    return _MARKS.sub("", lead.split()[0]).strip(_EDGE) if lead.split() else ""


def _pronoun_noun(word: str) -> bool:
    """A noun or verb with «ـه / ـها / ـهم» joined to it and no «ال» (تسميته، حكمه، أنواعها، يسميه): it speaks about something said before."""
    if word.startswith("ال") or word.endswith(("الله", "لله")) or re.fullmatch(r"ت.{2,3}يه", word):          # تنبيه، توجيه، تشبيه are plain nouns
        return False
    return any(word.endswith(suf) and len(word) - len(suf) >= 3 for suf in ("هما", "هم", "هن", "ها", "ه"))


def standalone(sentence: str):
    """The sentence as it can be used for a question on its own, or None when it leans on the sentence before it."""
    word = _first_word(sentence)
    if not word:
        return None
    if word in ("و", "ف") or word in _LEAD_WORDS or word in _FA_LEAD or _pronoun_noun(word):
        return None
    if word[0] == "و" and word not in _ROOT_WAW:
        rest = re.sub(r"^\s*[" + re.escape(_EDGE) + r"]*و[ً-ٰٟ]*", "", sentence, count=1).strip()
        # only the «و» is borrowed when the subject is right there: a noun with «ال» («والنواة مركز التحكم»), or a subject followed by «هو / هي» («وتوحيد الربوبية هو الإقرار …»)
        if (word.startswith("وال") and len(word) > 4) or any(t in ("هو", "هي", "هم", "هما") for t in rest.split()[1:4]):
            return rest if standalone(rest) else None
        return None
    return sentence.strip()


def _noun_like(word: str) -> bool:
    n = G.norm(word)
    return n.startswith("ال") and len(n) >= 5 and not n.startswith(("الذي", "التي", "الذين"))


def _same_root(a: str, b: str) -> bool:
    a, b = G.norm(a), G.norm(b)
    a, b = (a[2:] if a.startswith("ال") else a), (b[2:] if b.startswith("ال") else b)
    return a[:3] == b[:3]


def _candidates(sentence: str, freq: dict) -> list[str]:
    cands = []
    for w in WORD.findall(sentence):
        n = G.norm(w)
        if len(n) >= 4 and n not in STOP and not n.isdigit() and w not in cands:
            cands.append(w)
    nums = [w for w in WORD.findall(sentence) if w.isdigit() or all(c in "٠١٢٣٤٥٦٧٨٩" for c in w)]
    cands.sort(key=lambda w: (not _noun_like(w), -freq.get(G.norm(w), 0), -len(w)))
    return nums[:1] + cands


def _blank_out(sentence: str, answer: str) -> str:
    return re.sub(rf"(?<![ء-ي\w]){re.escape(answer)}(?![ء-ي\w])", BLANK, sentence, count=1)


class OfflineProvider:
    name = "offline"

    def generate(self, text: str, total: int = 24, rng=None) -> list[dict]:
        return pick_varied(self.candidates(text, rng), max(2, total // len(KINDS)))

    def candidates(self, text: str, rng=None) -> dict:
        """Every question the file can give, checked against the file and sorted by kind, before any choice is made ({kind: [question, ...]}).
        `generate` picks from this what a lesson needs; an exam (examq.py) picks from the same pool what its sections need and keeps the rest as spares."""
        rng = rng or random.Random(7)
        sents = [st for st in map(standalone, split_sentences(text)) if st]          # a sentence that leans on the one before it is not used (see standalone)
        freq: dict = {}
        for w in G.words(text):
            if w not in STOP:
                freq[w] = freq.get(w, 0) + 1
        pool = [w for w, c in sorted(freq.items(), key=lambda kv: -kv[1]) if _noun_like(w)]
        questions: dict[str, list] = {k: [] for k in KINDS}

        for s in sents:
            m = DEF_RE.match(s) or COLON_RE.match(s)
            if m and len(m["term"].split()) <= 4:
                term, definition = m["term"].strip(), m["def"].strip()
                questions["qa"].append(dict(kind="qa", question=f"ما المقصود بـ «{term}»؟", answer=definition, evidence=s))
                questions["review"].append(dict(kind="review", question=f"اذكري ما تعرفينه عن «{term}»", answer=definition, evidence=s))

        usable = []
        for s in sents:
            cands = _candidates(s, freq)
            if cands:
                usable.append((s, cands[0]))
        for s, ans in usable:
            blanked = _blank_out(s, ans)
            if blanked != s:
                questions["cloze"].append(dict(kind="cloze", question=blanked, answer=ans, evidence=s))
                others = [w for w in pool if w not in G.norm(s).split() and not _same_root(w, ans)]
                same = [w for w in others if abs(len(w) - len(G.norm(ans))) <= 3] or others
                if len(set(same)) >= 3:
                    pick = rng.sample(sorted(set(same)), 3)
                    originals = {G.norm(w): w for w in WORD.findall(text)}
                    opts = [originals.get(p, p) for p in pick] + [ans]
                    rng.shuffle(opts)
                    questions["mcq"].append(dict(kind="mcq", question=blanked, answer=ans, options=opts, evidence=s))
            flip = len(questions["tf"]) % 2 == 1
            if flip:
                others = [w for w in pool if w not in G.norm(s).split() and not _same_root(w, ans)]
                if others and _noun_like(ans):
                    originals = {G.norm(w): w for w in WORD.findall(text)}
                    wrong = originals.get(rng.choice(others[:25]), None)
                    if wrong and wrong != ans:
                        false_s = _blank_out(s, ans).replace(BLANK, wrong)
                        if false_s != s:
                            questions["tf"].append(dict(kind="tf", question=false_s, answer="خطأ", evidence=s))
                            continue
            questions["tf"].append(dict(kind="tf", question=s, answer="صح", evidence=s))
        for s in sents:
            m = CAUSE_RE.search(s)
            if m and len(s[:m.start()].split()) >= 3 and len(s[m.end():].split()) >= 2:
                questions["short"].append(dict(kind="short", question=f"{s[:m.start()].strip()} … ؟ (أكملي الجملة)", answer=(m.group(1) + " " + s[m.end():]).strip(), evidence=s))
        if len(questions["short"]) < 3:
            for s in sents:
                words = s.split()
                if len(words) >= 9:
                    cut = len(words) // 2
                    questions["short"].append(dict(kind="short", question=" ".join(words[:cut]) + " … ؟ (أكملي الجملة)", answer=" ".join(words[cut:]), evidence=s))
                if len(questions["short"]) >= 6:
                    break
        if len(questions["review"]) < 2:
            blocks = [b for b in re.split(r"\n\s*\n", text) if len(b.split()) > 8]
            for b in blocks[:6]:
                head = b.strip().splitlines()[0].strip().rstrip(":")
                body = split_sentences(b)
                if body and 1 <= len(head.split()) <= 8 and G.norm(head) != G.norm(body[0]):
                    questions["review"].append(dict(kind="review", question=f"راجعي: ما أهم ما ورد عن «{head}»؟", answer=body[0], evidence=body[0]))

        text_norm = G.norm(text)
        verified = {}
        for kind in KINDS:
            good = [q for q in questions[kind] if G.verify(q, text_norm)]
            rng.shuffle(good) if kind in ("tf", "cloze", "mcq") else None
            verified[kind] = good
        return verified


def _similar(a: str, b: str) -> bool:
    wa, wb = set(G.words(a)), set(G.words(b))
    if min(len(wa), len(wb)) <= 6:                      # a short template («اذكري ما تعرفينه عن X») differs by its term: alike only when identical
        return wa == wb
    return len(wa & wb) / min(len(wa), len(wb)) >= 0.8


LOOK = ("mcq", "tf", "cloze", "short")          # the kinds that show the sentence itself (whole, with a blank, or its first half)


def pick_varied(by_kind: dict, per: int) -> list[dict]:
    """Choose the questions so that nothing is asked twice. A sentence is shown by ONE of the four kinds that show it (a blank, options, true/false, a half),
    a definition («ما المقصود بـ…») does not use a sentence up, and two questions that read alike are never both kept. A short lesson gives fewer questions
    instead of the same sentence again and again (a teacher can add her own)."""
    chosen: list[dict] = []
    texts: list[str] = []
    counts = {k: 0 for k in KINDS}

    def fresh(q):
        return not any(_similar(q["question"], t) for t in texts)

    def add(q):
        texts.append(q["question"])
        chosen.append(q)
        counts[q["kind"]] += 1

    evidences = {G.norm(q["evidence"]) for k in LOOK for q in by_kind.get(k, [])}
    per_look = max(2, min(per, -(-len(evidences) // len(LOOK))))          # the sentences are shared fairly among the four kinds
    for q in by_kind.get("qa", []):
        if counts["qa"] < per and fresh(q):
            add(q)
    shown = set()
    for k in sorted(LOOK, key=lambda k: len(by_kind.get(k, []))):          # the kind with the fewest candidates picks first
        for q in by_kind.get(k, []):
            ev = G.norm(q["evidence"])
            if counts[k] < per_look and ev not in shown and fresh(q):
                add(q)
                shown.add(ev)
    for q in by_kind.get("review", []):
        if counts["review"] < per and fresh(q):
            add(q)
    order = {k: i for i, k in enumerate(KINDS)}
    return sorted(chosen, key=lambda q: order[q["kind"]])


class ClaudeProvider:
    """The paid provider. Never used unless the owner set AI_PROVIDER=claude AND a key AND the teacher agreed (see lessons.py)."""
    name = "claude"
    URL = "https://api.anthropic.com/v1/messages"
    RULES = ("أنتِ مساعدة تعد أسئلة من ملف درس. استخدمي نص الملف فقط ولا تضيفي أي معلومة من خارجه ولا تخترعي إجابة. "
             "لكل سؤال اكتبي في الحقل evidence اقتباسًا حرفيًا من النص يدعم الإجابة. إن لم تجدي إجابة واضحة في النص فاكتبي answer = \"" + G.UNCLEAR + "\". "
             "أعيدي JSON فقط: قائمة عناصر {kind, question, answer, options, evidence}. kind من: qa, mcq, tf, cloze, short, review. "
             "في tf يكون answer \"صح\" أو \"خطأ\". في mcq ضعي 4 خيارات في options أحدها الإجابة. في cloze ضعي ـــــ مكان الكلمة. "
             "لا تسألي عن بيانات الغلاف أو التذييل مثل اسم المدرسة أو الوزارة أو المعلمة أو التاريخ أو رقم الصفحة، ولا عن اسم المادة أو الصف، ولا تكرري سؤالًا بصياغة أخرى ولا تأخذي سؤالين من الجملة نفسها.")

    def __init__(self, key, model=None, transport=None):
        self.key, self.transport = key, transport or self._post
        self.model = aimodel.MODEL                 # fixed on purpose (aimodel.py): whatever is passed here, the approved model is the one called
        self.last_usage = None

    def _post(self, payload: dict) -> dict:
        req = urllib.request.Request(self.URL, data=json.dumps(payload).encode(), method="POST",
                                     headers={"x-api-key": self.key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
        with urllib.request.urlopen(req, timeout=120) as r:       # noqa: S310 (fixed https address)
            return json.loads(r.read().decode())

    def generate(self, text: str, total: int = 24, rng=None) -> list[dict]:
        # thinking is switched off: its tokens would be billed as output and eat max_tokens. No temperature / top_p / top_k (this model refuses them).
        payload = {"model": self.model, "max_tokens": aimodel.MAX_OUT_TOKENS, "thinking": {"type": "disabled"}, "system": self.RULES,
                   "messages": [{"role": "user", "content": f"أعدي نحو {total} سؤالًا متنوعًا من هذا الدرس:\n\n{text[:aimodel.MAX_TEXT_CHARS]}"}]}
        reply = self.transport(payload)
        u = reply.get("usage") or {}
        self.last_usage = {"input": int(u.get("input_tokens", 0)), "output": int(u.get("output_tokens", 0))}          # counted even if the answer turns out unusable
        raw = "".join(b.get("text", "") for b in reply.get("content", []) if b.get("type", "text") == "text")
        m = re.search(r"\[.*\]", raw, re.S)
        items = json.loads(m.group(0)) if m else []
        return [i for i in items if isinstance(i, dict) and i.get("kind") in KINDS]


def provider_for(config, teacher_agreed: bool):
    """The paid provider only when everything is switched on; otherwise the free offline one."""
    if config.ai_provider == "claude" and config.anthropic_key and teacher_agreed:
        return ClaudeProvider(config.anthropic_key)
    return OfflineProvider()


def clean_items(items, text: str, strict: bool) -> list[dict]:
    """Normalise what a provider returned and mark each question `clear` (backed by the file) or not."""
    text_norm = G.norm(text)
    out, seen_q = [], set()
    for it in items:
        q = {"kind": it["kind"], "question": str(it.get("question", "")).strip()[:600], "answer": str(it.get("answer", "")).strip()[:600],
             "evidence": str(it.get("evidence", "")).strip()[:800],
             "options": [str(o).strip()[:200] for o in (it.get("options") or [])][:6]}
        if lesson_meta.mentions(q["question"]):
            q["question"] = lesson_meta.strip_mentions(q["question"])
        if len(q["question"]) < 6 or lesson_meta.mentions(q["question"]):
            continue
        if any(lesson_meta.mentions(x) for x in [q["answer"], q["evidence"], *q["options"]]):          # the subject or the class must never be an answer or an option
            continue
        if q["kind"] == "mcq" and (len(q["options"]) < 2 or q["answer"] not in q["options"]):
            continue
        if is_noise(q["question"]) or is_noise(q["evidence"]):          # a line of the cover or the footer
            continue
        if q["kind"] in LOOK and standalone(q["question"]) is None:    # a statement that starts with «و…» or a pronoun that has nothing to point to
            continue
        key = (G.norm(q["question"]), G.norm(q["answer"]))
        if key in seen_q:                                               # the same question with the same answer twice
            continue
        seen_q.add(key)
        q["clear"] = int(G.verify(q, text_norm, strict=strict))
        if not q["clear"] and not q["answer"]:
            q["answer"] = G.UNCLEAR
        out.append(q)
    return out


def make_questions(config, text: str, ai_allowed: bool, total: int = 24):
    """(provider name, questions, usage). `usage` is {"model", "input", "output"} when the paid reader was really called (so it can be counted), else None."""
    prov = provider_for(config, ai_allowed)
    usage = None
    try:
        items = prov.generate(text, total)
        strict = prov.name == "offline"
    except Exception:
        used = getattr(prov, "last_usage", None)
        if used:
            usage = {"model": prov.model, **used}
        prov = OfflineProvider()
        return prov.name, clean_items(prov.generate(text, total), text, True), usage
    if prov.name == "claude" and prov.last_usage:
        usage = {"model": prov.model, **prov.last_usage}
    if prov.name == "claude" and not items:                    # the paid reader gave nothing usable: the free one still serves her
        return "offline", clean_items(OfflineProvider().generate(text, total), text, True), usage
    return prov.name, clean_items(items, text, strict), usage
