"""The manager's pages. Only a user with is_admin sees them (anyone else gets «not found»).

 /admin                  overview: the numbers that matter, two charts, the transfers waiting, who is about to end
 /admin/subscriptions    requests and receipts, every subscriber with start and end, search, extend / grant / stop
 /admin/ai               what the paid reader costs: per lesson, per call, the monthly cap and its automatic stop, the allowance of each plan
 /admin/finance          money by month, fixed and variable costs, taxes, the bank account, a printable report
 /admin/platform         the packages (prices, limits, creating and hiding them) and the platform switches
Nothing here pays, subscribes or publishes anything: the manager confirms transfers by hand and the paid reader stays off until the server has a key."""
import csv
import io
import math
import re
import time
from datetime import datetime
from urllib.parse import urlencode

from flask import Blueprint, Response, abort, current_app, redirect, render_template, request, send_file, url_for

from . import billing, charts, db as dbm, identity
from .security import admin_required

bp = Blueprint("admin", __name__, url_prefix="/admin")
IBAN = re.compile(r"^SA[0-9]{2}[0-9A-Z]{20}$")
CODE = re.compile(r"^[a-z][a-z0-9_]{1,19}$")
PER_PAGE = 25
DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩٫،", "0123456789.,")
BASE_PLANS = ("free", "monthly", "yearly")


# ---------------------------------------------------------------- small helpers
@bp.app_template_global("riyals")
def _riyals(h):
    """Riyals for the manager's pages: a loss keeps its minus sign on the left of the number, as in any ledger (inside right-to-left text it would jump to the right)."""
    txt = billing.riyals(int(h or 0))
    return f"{charts.LRI}{txt}{charts.PDI}" if txt.startswith("-") else txt


@bp.app_template_global("sar_exact")
def _sar_exact(row):
    """The cost of one logged call in riyals, with enough digits to see it."""
    nano = row["cost_nano"] or (row["cost"] * 10 ** 9 // billing.USD_SAR_X100)
    return billing.sar_text(nano)


@bp.app_template_filter("day")
def _day(ts):
    return datetime.fromtimestamp(ts, billing.RIYADH).strftime("%Y-%m-%d") if ts else "—"


@bp.app_template_filter("when")
def _when(ts):
    return datetime.fromtimestamp(ts, billing.RIYADH).strftime("%Y-%m-%d %H:%M") if ts else "—"


@bp.app_template_filter("sar4")
def _sar4(nano):
    return billing.sar_text(int(nano or 0))


def _num(form, key, lo, hi):
    raw = form.get(key, "").translate(DIGITS).strip().replace(",", ".")
    v = float(raw)
    if not (lo <= v <= hi) or math.isnan(v):
        raise ValueError(key)
    return v


def _int(form, key, lo, hi):
    return int(_num(form, key, lo, hi))


def _like(q):
    return "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"


def _who_like(q):
    """The SQL that finds a person by e-mail, and by mobile number when the search looks like one (0501234567, +966 50 123 4567 or just 4567), with its arguments."""
    d = identity.search_digits(q)
    if d:
        return "(u.email LIKE ? ESCAPE '\\' OR u.phone LIKE ? ESCAPE '\\')", [_like(q), _like(d)]
    return "u.email LIKE ? ESCAPE '\\'", [_like(q)]


def _go(endpoint, msg="", **kw):
    return redirect(url_for(endpoint, msg=msg, **kw) if msg else url_for(endpoint, **kw))


def _back(default, msg):
    """Back to the page the form was on (only inside /admin)."""
    nxt = request.form.get("next", "")
    if nxt.startswith("/admin") and not nxt.startswith("//"):
        sep = "&" if "?" in nxt else "?"
        return redirect(f"{nxt.split('#')[0]}{sep}{urlencode({'msg': msg})}")
    return _go(default, msg)


def _pager(total, page):
    pages = max(1, math.ceil(total / PER_PAGE))
    page = min(max(1, page), pages)
    return {"page": page, "pages": pages, "total": total, "offset": (page - 1) * PER_PAGE}


def _page_arg():
    try:
        return int(request.args.get("p", 1))
    except ValueError:
        return 1


def _msg():
    return request.args.get("msg", "")[:200]


@bp.context_processor
def _nav():
    return {"pending_n": current_app.db.execute("SELECT COUNT(*) FROM subscription_requests WHERE status = 'pending'").fetchone()[0]}


def _pending(db, q=""):
    sql = """SELECT r.*, u.name AS uname, u.email, u.phone, p.name AS plan_name FROM subscription_requests r JOIN users u ON u.id = r.user_id
             JOIN plans p ON p.code = r.plan_code WHERE r.status = 'pending'"""
    args = []
    if q:
        who, who_args = _who_like(q)
        sql += f" AND (r.ref_code LIKE ? ESCAPE '\\' OR u.name LIKE ? ESCAPE '\\' OR {who} OR r.payer_name LIKE ? ESCAPE '\\')"
        args = [_like(q)] * 2 + who_args + [_like(q)]
    return db.execute(sql + " ORDER BY r.id", args).fetchall()


def _decided(db, q="", limit=20, user_id=None):
    sql = """SELECT r.*, u.name AS uname, u.email, u.phone, p.name AS plan_name FROM subscription_requests r JOIN users u ON u.id = r.user_id
             JOIN plans p ON p.code = r.plan_code WHERE r.status != 'pending'"""
    args = []
    if user_id:
        sql, args = sql + " AND r.user_id = ?", [user_id]
    if q:
        who, who_args = _who_like(q)
        sql += f" AND (r.ref_code LIKE ? ESCAPE '\\' OR u.name LIKE ? ESCAPE '\\' OR {who} OR r.payer_name LIKE ? ESCAPE '\\')"
        args += [_like(q)] * 2 + who_args + [_like(q)]
    return db.execute(sql + " ORDER BY r.decided_at DESC, r.id DESC LIMIT ?", args + [limit]).fetchall()


def _search_term():
    q = request.args.get("q", "").translate(DIGITS).strip()[:60]
    m = re.match(r"(?i)^lp\s*-?\s*(\d+)$", q)          # «lp1001», «LP 1001» and «LP-1001» are the same request number
    return f"LP-{m.group(1)}" if m else q


# ---------------------------------------------------------------- overview
@bp.get("")
@admin_required
def dashboard():
    db, now = current_app.db, time.time()
    fin = billing.finance(db, now)
    counts = billing.subscriber_counts(db, now)
    stats = billing.ai_stats(db, now)
    last = fin["months"][-6:]
    labels = [charts.short_month(m["month"]) for m in last]
    money = charts.figure(
        "الإيرادات والتكاليف — آخر 6 أشهر (ريال)",
        charts.bars(labels, [{"name": "الإيرادات", "cls": "s1", "values": [m["gross"] / 100 for m in last]},
                             {"name": "التكاليف", "cls": "s2", "values": [(m["ai"] + m["fixed"] + m["variable"]) / 100 for m in last]}], name="الإيرادات والتكاليف"),
        [("s1", "الإيرادات (شامل الضريبة)"), ("s2", "التكاليف (ذكاء + ثابتة + متغيرة)")],
        ["الشهر", "الإيرادات", "التكاليف", "صافي الربح"],
        [[m["label"], billing.riyals(m["gross"]), billing.riyals(m["ai"] + m["fixed"] + m["variable"]), billing.riyals(m["net"])] for m in reversed(last)])
    people = charts.figure(
        "حالة المشتركات",
        charts.stacked([{"name": "نشطة", "cls": "s1", "value": counts["active"]}, {"name": "مجانية", "cls": "sg", "value": counts["free"]},
                        {"name": "منتهية", "cls": "s2", "value": counts["expired"]}], name="حالة المشتركات"),
        [("s1", f"نشطة ({counts['active']})"), ("sg", f"مجانية ({counts['free']})"), ("s2", f"منتهية ({counts['expired']})")])
    state, pct = charts.gauge_state(stats["month"]["halalas"], stats["cap"])
    soon = db.execute("SELECT u.id, u.name, u.email, u.phone, u.plan_expires, p.name AS plan_name FROM users u JOIN plans p ON p.code = u.plan_code "
                      "WHERE u.plan_code != 'free' AND u.plan_expires BETWEEN ? AND ? ORDER BY u.plan_expires", (now, now + billing.RENEW_WARN_DAYS * 86400)).fetchall()
    return render_template("admin/overview.html", tab="overview", fin=fin, counts=counts, stats=stats, money=money, people=people, soon=soon,
                           gauge=charts.gauge(stats["month"]["halalas"], stats["cap"], "الإنفاق على الذكاء الاصطناعي هذا الشهر"), gstate=state, gpct=pct,
                           pending=_pending(db), recent=_decided(db, limit=8), ai_on=_ai_on(), ai_switch=billing.ai_switch_on(db), msg=_msg())


def _ai_on():
    cfg = current_app.cfg
    return cfg.ai_provider == "claude" and bool(cfg.anthropic_key)


# ---------------------------------------------------------------- requests (the old addresses keep working)
@bp.post("/requests/<int:rid>/<action>")
@admin_required
def decide(rid, action):
    db = current_app.db
    req = db.execute("SELECT * FROM subscription_requests WHERE id = ?", (rid,)).fetchone()
    if not req or req["status"] != "pending" or action not in ("confirm", "reject"):
        abort(404)
    if action == "confirm":
        billing.confirm_request(db, req)
        msg = f"تم تأكيد الطلب {req['ref_code']} وتفعيل الباقة"
    else:
        db.execute("UPDATE subscription_requests SET status = 'rejected', decided_at = ?, note = ? WHERE id = ?", (time.time(), request.form.get("note", "").strip()[:200], rid))
        db.commit()
        msg = f"تم رفض الطلب {req['ref_code']}"
    return _back("admin.dashboard", msg)


@bp.get("/requests/<int:rid>/receipt")
@admin_required
def receipt(rid):
    req = current_app.db.execute("SELECT receipt FROM subscription_requests WHERE id = ?", (rid,)).fetchone()
    if not req or not req["receipt"]:
        abort(404)
    return send_file(current_app.cfg.upload_dir / req["receipt"], download_name=req["receipt"])


# ---------------------------------------------------------------- subscriptions
@bp.get("/subscriptions")
@admin_required
def subscriptions():
    db, now = current_app.db, time.time()
    q, st = _search_term(), request.args.get("st", "")
    if st not in ("active", "soon", "expired", "free"):
        st = ""
    sql = f"""SELECT u.id, u.name, u.email, u.phone, u.plan_code, u.plan_expires, u.plan_started, u.created_at, p.name AS plan_name, ({billing.PAID_BEFORE}) AS paid,
              (SELECT MAX(r.starts_at) FROM subscription_requests r WHERE r.user_id = u.id AND r.status = 'confirmed') AS last_start
              FROM users u JOIN plans p ON p.code = u.plan_code WHERE u.is_admin = 0"""
    args = []
    if q:
        who, who_args = _who_like(q)
        sql += (f" AND (u.name LIKE ? ESCAPE '\\' OR {who} OR u.id IN (SELECT user_id FROM subscription_requests "
                "WHERE ref_code LIKE ? ESCAPE '\\' OR payer_name LIKE ? ESCAPE '\\'))")
        args = [_like(q)] + who_args + [_like(q)] * 2
    people = []
    for r in db.execute(sql + " ORDER BY u.created_at DESC", args):
        status = billing.status_of(r["plan_code"], r["plan_expires"], r["paid"], now)
        if st and status != st and not (st == "active" and status == "soon"):
            continue
        people.append({**dict(r), "status": status, "started": (r["plan_started"] or r["last_start"] or 0) if status in ("active", "soon") else (r["last_start"] or 0),
                       "left": billing.days_left(r, now) if status in ("active", "soon") else None})
    pg = _pager(len(people), _page_arg())
    return render_template("admin/subscriptions.html", tab="subs", q=q, st=st, people=people[pg["offset"]:pg["offset"] + PER_PAGE], pg=pg, status_ar=billing.STATUS_AR,
                           pending=_pending(db, q), recent=_decided(db, q), counts=billing.subscriber_counts(db, now), msg=_msg())


def _subscriber(uid):
    u = current_app.db.execute("SELECT u.*, p.name AS plan_name FROM users u JOIN plans p ON p.code = u.plan_code WHERE u.id = ? AND u.is_admin = 0", (uid,)).fetchone()
    if not u:
        abort(404)
    return u


@bp.get("/subscriptions/<int:uid>")
@admin_required
def subscriber(uid):
    db, now = current_app.db, time.time()
    u = _subscriber(uid)
    paid = db.execute(f"SELECT ({billing.PAID_BEFORE.replace('u.id', '?')}) ", (uid, uid)).fetchone()[0]
    status = billing.status_of(u["plan_code"], u["plan_expires"], paid, now)
    last_start = db.execute("SELECT MAX(starts_at) FROM subscription_requests WHERE user_id = ? AND status = 'confirmed'", (uid,)).fetchone()[0]
    reqs = db.execute("SELECT r.*, p.name AS plan_name FROM subscription_requests r JOIN plans p ON p.code = r.plan_code WHERE r.user_id = ? ORDER BY r.id DESC", (uid,)).fetchall()
    events = db.execute("SELECT e.*, p.name AS plan_name FROM plan_events e LEFT JOIN plans p ON p.code = e.plan_code WHERE e.user_id = ? ORDER BY e.id DESC", (uid,)).fetchall()
    month = billing.month_start(now)
    use = db.execute("SELECT COUNT(*), COALESCE(SUM(cost_nano), 0), COALESCE(SUM(CASE WHEN cost_nano = 0 THEN cost ELSE 0 END), 0) FROM ai_usage WHERE user_id = ? AND created_at >= ?", (uid, month)).fetchone()
    return render_template("admin/subscriber.html", tab="subs", u=u, status=status, status_ar=billing.STATUS_AR, started=(u["plan_started"] or last_start or 0),
                           left=billing.days_left(u, now), reqs=reqs, events=events, lessons=billing.usage(db, uid)[0], allow=billing.lesson_allowance(db, u, now),
                           ai_calls=use[0], ai_nano=use[1] + use[2] * 10 ** 9 // billing.USD_SAR_X100,
                           plans=db.execute("SELECT * FROM plans WHERE code != 'free' ORDER BY price_month + price_year").fetchall(), kinds={"grant": "منح باقة", "extend": "تمديد", "stop": "إيقاف"},
                           req_status={"pending": "قيد التأكيد", "confirmed": "مفعّل", "rejected": "مرفوض"}, msg=_msg())


@bp.post("/subscriptions/<int:uid>/<action>")
@admin_required
def subscriber_action(uid, action):
    db, f = current_app.db, request.form
    _subscriber(uid)
    note = f.get("note", "").strip()[:200]
    try:
        if action == "extend":
            billing.extend_days(db, uid, _int(f, "days", 1, 3650), note)
            msg = "تم تمديد الاشتراك"
        elif action == "grant":
            billing.grant_plan(db, uid, f.get("plan", ""), _int(f, "days", 1, 3650), note)
            msg = "تم تفعيل الباقة"
        elif action == "stop":
            billing.stop_plan(db, uid, note)
            msg = "أُوقف الاشتراك وعادت إلى الباقة المجانية. دروسها محفوظة"
        else:
            abort(404)
    except ValueError:
        msg = "تعذّر تنفيذ الإجراء: راجعي الأرقام والباقة المختارة"
    return _go("admin.subscriber", msg, uid=uid)


# ---------------------------------------------------------------- the paid reader
def _usage_where(month, q):
    where, args = [], []
    if month != "all":
        where += ["a.created_at >= ?", "a.created_at < ?"]
        args += [billing.mstart(month), billing.mstart(billing.madd(month, 1))]
    if q:
        who, who_args = _who_like(q)
        where.append(f"(u.name LIKE ? ESCAPE '\\' OR {who} OR l.title LIKE ? ESCAPE '\\')")
        args += [_like(q)] + who_args + [_like(q)]
    return (" WHERE " + " AND ".join(where)) if where else "", args


@bp.get("/ai")
@admin_required
def ai():
    db, now = current_app.db, time.time()
    stats = billing.ai_stats(db, now)
    cur = billing.mkey(now)
    month = request.args.get("m", cur)
    if month != "all" and not billing.MONTH_KEY.match(month):
        month = cur
    q = request.args.get("q", "").strip()[:60]
    join = "FROM ai_usage a LEFT JOIN users u ON u.id = a.user_id LEFT JOIN lessons l ON l.id = a.lesson_id"
    where, args = _usage_where(month, q)
    total = db.execute(f"SELECT COUNT(*) {join}{where}", args).fetchone()[0]
    pg = _pager(total, _page_arg())
    log = db.execute(f"SELECT a.*, u.name AS uname, l.title AS ltitle {join}{where} ORDER BY a.id DESC LIMIT ? OFFSET ?", args + [PER_PAGE, pg["offset"]]).fetchall()
    per_lesson = db.execute(f"""SELECT a.lesson_id, MAX(l.title) AS title, MAX(u.name) AS uname, COUNT(*) AS calls, SUM(a.input_tokens) AS tin, SUM(a.output_tokens) AS tout,
                                SUM(a.cost_nano) AS nano, SUM(CASE WHEN a.cost_nano = 0 THEN a.cost ELSE 0 END) AS legacy {join}{where}
                                GROUP BY a.lesson_id ORDER BY nano + legacy * 2666666 DESC LIMIT 15""", args).fetchall()
    start = billing.month_start(now)
    per_teacher = db.execute("""SELECT u.id, u.name, COUNT(*) AS calls, SUM(a.cost_nano) AS nano, SUM(CASE WHEN a.cost_nano = 0 THEN a.cost ELSE 0 END) AS legacy
                                FROM ai_usage a JOIN users u ON u.id = a.user_id WHERE a.created_at >= ? GROUP BY u.id ORDER BY nano + legacy * 2666666 DESC LIMIT 10""", (start,)).fetchall()
    days = {r[0]: r[1] for r in db.execute("SELECT CAST(strftime('%d', a.created_at + 10800, 'unixepoch') AS INTEGER), COUNT(*) FROM ai_usage a WHERE a.created_at >= ? GROUP BY 1", (start,))}
    today = int(datetime.fromtimestamp(now, billing.RIYADH).strftime("%d"))
    daily = charts.figure("الاستدعاءات كل يوم هذا الشهر", charts.bars([str(d) if today <= 12 or d % 5 == 0 or d == 1 else "" for d in range(1, today + 1)],
                                                                   [{"name": "الاستدعاءات", "cls": "s1", "values": [days.get(d, 0) for d in range(1, today + 1)]}], unit="استدعاء", name="الاستدعاءات اليومية", integer=True),
                          headers=["اليوم", "الاستدعاءات"], rows=[[d, days.get(d, 0)] for d in range(today, 0, -1) if days.get(d)])
    state, pct = charts.gauge_state(stats["month"]["halalas"], stats["cap"])
    avail = billing.mrange(billing.first_month(db, now), cur)[-12:]
    return render_template("admin/ai.html", tab="ai", stats=stats, gauge=charts.gauge(stats["month"]["halalas"], stats["cap"], "الإنفاق على الذكاء الاصطناعي هذا الشهر"), gstate=state, gpct=pct,
                           log=log, pg=pg, month=month, q=q, months=[(m, billing.mlabel(m)) for m in reversed(avail)], per_lesson=per_lesson, per_teacher=per_teacher, daily=daily,
                           plans=db.execute("SELECT * FROM plans ORDER BY price_month + price_year, code").fetchall(), cap_sar=f"{stats['cap'] / 100:g}", ai_on=_ai_on(),
                           ai_switch=billing.ai_switch_on(db), model=billing.MODEL, prices=billing.PRICE_USD[billing.MODEL], msg=_msg())


@bp.post("/ai/settings")
@admin_required
def ai_settings():
    db, f = current_app.db, request.form
    try:
        cap = _num(f, "ai_cap_sar", 0, 100000)
        quotas = {p["code"]: _int(f, "quota_" + p["code"], 0, 100000) for p in db.execute("SELECT code FROM plans")}
    except ValueError:
        return _go("admin.ai", "اكتبي أرقامًا صحيحة للسقف وللحصص")
    dbm.put_setting(db, "ai_cap_sar", cap)
    dbm.put_setting(db, "ai_enabled", "1" if f.get("ai_enabled") == "1" else "0")
    for code, quota in quotas.items():
        db.execute("UPDATE plans SET ai_quota = ? WHERE code = ?", (quota, code))
    db.commit()
    return _go("admin.ai", "تم حفظ إعدادات الذكاء الاصطناعي")


# ---------------------------------------------------------------- money
def _finance_context(db, now):
    fin = billing.finance(db, now)
    last = fin["months"][-12:]
    labels = [charts.short_month(m["month"]) for m in last]
    rows = [[m["label"], billing.riyals(m["gross"]), billing.riyals(m["vat"]), billing.riyals(m["ai"]), billing.riyals(m["fixed"]), billing.riyals(m["variable"]), billing.riyals(m["net"])] for m in reversed(last)]
    head = ["الشهر", "الإيرادات", "الضريبة", "الذكاء", "ثابتة", "متغيرة", "الصافي"]
    figs = (charts.figure("الإيرادات والتكاليف (ريال)",
                          charts.bars(labels, [{"name": "الإيرادات", "cls": "s1", "values": [m["gross"] / 100 for m in last]},
                                               {"name": "التكاليف", "cls": "s2", "values": [(m["ai"] + m["fixed"] + m["variable"]) / 100 for m in last]}], name="الإيرادات والتكاليف"),
                          [("s1", "الإيرادات (شامل الضريبة)"), ("s2", "التكاليف (ذكاء + ثابتة + متغيرة)")], head, rows),
            charts.figure("صافي الربح بعد كل المصاريف (ريال)",
                          charts.bars(labels, [{"name": "صافي الربح", "cls": "s3", "values": [m["net"] / 100 for m in last]}], name="صافي الربح"),
                          note="يظهر الشهر الخاسر تحت الخط."))
    return fin, figs


@bp.get("/finance")
@admin_required
def finance():
    db, now = current_app.db, time.time()
    fin, (fig_money, fig_net) = _finance_context(db, now)
    cfg = {"bank_name": dbm.setting(db, "bank_name"), "bank_holder": dbm.setting(db, "bank_holder"), "bank_iban": dbm.setting(db, "bank_iban"),
           "fixed_sar": f"{billing.money(db, 'fixed_sar', billing.DEFAULT_FIXED_SAR) / 100:g}", "vat": fin["vat_on"]}
    cur = billing.mkey(now)
    return render_template("admin/finance.html", tab="money", fin=fin, fig_money=fig_money, fig_net=fig_net, cfg=cfg, expenses=billing.expense_rows(db), cur=cur,
                           months=list(reversed(fin["months"])), vat_pct=int(billing.VAT * 100), msg=_msg())


@bp.get("/finance.csv")
@admin_required
def finance_csv():
    rows = billing.months_table(current_app.db)
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["month", "revenue_incl_vat", "vat", "ai_cost", "fixed_costs", "variable_costs", "net_profit", "paid_requests", "ai_calls"])
    for m in rows:
        w.writerow([m["month"]] + [f"{m[k] / 100:.2f}" for k in ("gross", "vat", "ai", "fixed", "variable", "net")] + [m["paid"], m["calls"]])
    return Response("﻿" + out.getvalue(), mimetype="text/csv; charset=utf-8", headers={"Content-Disposition": "attachment; filename=lessonplay-finance.csv"})


@bp.post("/finance/bank")
@admin_required
def finance_bank():
    db, f = current_app.db, request.form
    iban = re.sub(r"\s+", "", f.get("bank_iban", "")).upper()
    if iban and not IBAN.match(iban):
        return _go("admin.finance", "رقم الآيبان غير صحيح (يبدأ بـ SA ويتكون من 24 خانة)")
    for key, val in (("bank_name", f.get("bank_name", "").strip()[:80]), ("bank_holder", f.get("bank_holder", "").strip()[:80]), ("bank_iban", iban)):
        dbm.put_setting(db, key, val)
    return _go("admin.finance", "تم حفظ بيانات الحساب البنكي")


@bp.post("/finance/general")
@admin_required
def finance_general():
    db, f = current_app.db, request.form
    try:
        fixed = _num(f, "fixed_sar", 0, 100000)
    except ValueError:
        return _go("admin.finance", "اكتبي رقمًا صحيحًا للتكاليف الثابتة")
    dbm.put_setting(db, "fixed_sar", fixed)
    dbm.put_setting(db, "vat_registered", "1" if f.get("vat") == "1" else "0")
    return _go("admin.finance", "تم حفظ الإعدادات المالية")


@bp.post("/finance/expenses")
@admin_required
def expense_add():
    f = request.form
    try:
        billing.add_expense(current_app.db, f.get("kind", ""), f.get("title", ""), round(_num(f, "amount", 0.01, 10 ** 7) * 100), f.get("month", "").strip())
    except ValueError:
        return _go("admin.finance", "تعذّرت الإضافة: اكتبي الوصف والمبلغ والشهر")
    return _go("admin.finance", "تمت إضافة المصروف")


@bp.post("/finance/expenses/<int:eid>/<action>")
@admin_required
def expense_change(eid, action):
    db = current_app.db
    row = db.execute("SELECT * FROM expenses WHERE id = ?", (eid,)).fetchone()
    if not row or action not in ("stop", "delete"):
        abort(404)
    if action == "delete":
        db.execute("DELETE FROM expenses WHERE id = ?", (eid,))
        msg = "حُذف المصروف"
    else:                                                        # a monthly cost that ended: counted up to last month, never again
        db.execute("UPDATE expenses SET ended_month = ? WHERE id = ? AND kind = 'fixed'", (billing.madd(billing.mkey(time.time()), -1), eid))
        msg = "أُوقف المصروف الثابت من هذا الشهر"
    db.commit()
    return _go("admin.finance", msg)


# ---------------------------------------------------------------- the packages and the platform
def _plan_values(f, free=False):
    name = f.get("name", "").strip()[:40]
    if len(name) < 2:
        raise ValueError("name")
    period = "" if free else f.get("period", "")
    if not free and period not in billing.DAYS:
        raise ValueError("period")
    price = 0 if free else round(_num(f, "price", 0, 100000) * 100)
    buy = 0 if free else int(f.get("purchasable") == "1")
    if buy and price <= 0:
        raise ValueError("price")
    return {"name": name, "period": period, "price_month": price if period == "month" else 0, "price_year": price if period == "year" else 0, "purchasable": buy,
            "max_lessons": _int(f, "max_lessons", 1, 100000), "max_decks": _int(f, "max_decks", 1, 100000), "ai_quota": _int(f, "ai_quota", 0, 100000)}


@bp.get("/platform")
@admin_required
def platform():
    db = current_app.db
    plans = db.execute("""SELECT p.*, (SELECT COUNT(*) FROM users u WHERE u.plan_code = p.code AND u.is_admin = 0) AS users,
                          (SELECT COUNT(*) FROM subscription_requests r WHERE r.plan_code = p.code) AS reqs FROM plans p ORDER BY p.price_month + p.price_year, p.code""").fetchall()
    return render_template("admin/platform.html", tab="platform", plans=plans, period_of=billing.period_of, price=billing.plan_price, base=BASE_PLANS,
                           open_reg=dbm.setting(db, "registrations_open", "1") != "0", upload_mb=billing.upload_limit_mb(db, current_app.cfg.max_upload_mb),
                           server_mb=current_app.cfg.max_upload_mb, ai_on=_ai_on(), ai_switch=billing.ai_switch_on(db), msg=_msg())


@bp.post("/platform/plans")
@admin_required
def plan_create():
    db, f = current_app.db, request.form
    code = f.get("code", "").strip().lower()
    if not CODE.match(code) or db.execute("SELECT 1 FROM plans WHERE code = ?", (code,)).fetchone():
        return _go("admin.platform", "رمز الباقة: حروف إنجليزية صغيرة وأرقام و(_) وغير مستخدم من قبل")
    try:
        v = _plan_values(f)
    except ValueError:
        return _go("admin.platform", "راجعي بيانات الباقة (الاسم والمدة والسعر والحدود)")
    db.execute("INSERT INTO plans(code, name, max_lessons, max_decks, price_month, price_year, purchasable, ai_quota, period) VALUES (?,?,?,?,?,?,?,?,?)",
               (code, v["name"], v["max_lessons"], v["max_decks"], v["price_month"], v["price_year"], v["purchasable"], v["ai_quota"], v["period"]))
    db.commit()
    return _go("admin.platform", "تمت إضافة الباقة")


@bp.post("/platform/plans/<code>")
@admin_required
def plan_update(code):
    db, f = current_app.db, request.form
    if not db.execute("SELECT 1 FROM plans WHERE code = ?", (code,)).fetchone():
        abort(404)
    try:
        v = _plan_values(f, free=code == "free")
    except ValueError:
        return _go("admin.platform", "راجعي بيانات الباقة (الاسم والمدة والسعر والحدود)")
    db.execute("UPDATE plans SET name = ?, max_lessons = ?, max_decks = ?, price_month = ?, price_year = ?, purchasable = ?, ai_quota = ?, period = ? WHERE code = ?",
               (v["name"], v["max_lessons"], v["max_decks"], v["price_month"], v["price_year"], v["purchasable"], v["ai_quota"], v["period"], code))
    db.commit()
    return _go("admin.platform", "تم حفظ الباقة. الطلبات القديمة تبقى بسعرها وقت الطلب")


@bp.post("/platform/plans/<code>/delete")
@admin_required
def plan_delete(code):
    db = current_app.db
    row = db.execute("SELECT code FROM plans WHERE code = ?", (code,)).fetchone()
    if not row:
        abort(404)
    used = db.execute("SELECT (SELECT COUNT(*) FROM users WHERE plan_code = ?) + (SELECT COUNT(*) FROM subscription_requests WHERE plan_code = ?)", (code, code)).fetchone()[0]
    if code in BASE_PLANS or used:
        return _go("admin.platform", "لا يمكن حذف هذه الباقة (أساسية أو مرتبطة بمشتركات أو طلبات). أخفيها من الاشتراك بدلًا من ذلك")
    db.execute("DELETE FROM plans WHERE code = ?", (code,))
    db.commit()
    return _go("admin.platform", "حُذفت الباقة")


@bp.post("/platform/settings")
@admin_required
def platform_settings():
    db, f = current_app.db, request.form
    try:
        mb = _int(f, "upload_mb", 1, current_app.cfg.max_upload_mb)
    except ValueError:
        return _go("admin.platform", f"حجم الرفع من 1 إلى {current_app.cfg.max_upload_mb} ميجابايت")
    dbm.put_setting(db, "registrations_open", "1" if f.get("registrations_open") == "1" else "0")
    dbm.put_setting(db, "upload_mb", mb)
    return _go("admin.platform", "تم حفظ إعدادات المنصة")


# ---------------------------------------------------------------- the old combined form (kept so nothing that used it breaks)
@bp.post("/settings")
@admin_required
def settings():
    db, f = current_app.db, request.form
    iban = re.sub(r"\s+", "", f.get("bank_iban", "")).upper()
    if iban and not IBAN.match(iban):
        return _go("admin.dashboard", "رقم الآيبان غير صحيح (يبدأ بـ SA ويتكون من 24 خانة)")
    try:
        cap, fixed = float(f.get("ai_cap_sar", "")), float(f.get("fixed_sar", ""))
        if not (0 <= cap <= 100000 and 0 <= fixed <= 100000):
            raise ValueError
    except ValueError:
        return _go("admin.dashboard", "اكتبي أرقامًا صحيحة للسقف والتكلفة الثابتة")
    for key, val in (("bank_name", f.get("bank_name", "").strip()[:80]), ("bank_holder", f.get("bank_holder", "").strip()[:80]), ("bank_iban", iban),
                     ("ai_cap_sar", cap), ("fixed_sar", fixed), ("vat_registered", "1" if f.get("vat") == "1" else "0")):
        dbm.put_setting(db, key, val)
    return _go("admin.dashboard", "تم حفظ الإعدادات")
