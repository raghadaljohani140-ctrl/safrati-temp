"""The one paid reader the owner approved, its official prices and the limits that keep what a call can cost predictable.

The model is fixed here ON PURPOSE: it is not a setting and not an environment variable, so nothing can swap it silently. Changing it is a code
change that needs the owner's approval. The paid reader is still OFF (see config.py): no key means no call and no cost.

Prices are the official ones for Claude Haiku 5.5 in US dollars per million tokens, from
https://platform.claude.com/docs/en/about-claude/pricing (checked 4 Nov 2026). A prompt of up to 100,000 tokens is billed at the first pair,
a longer prompt at the second pair. Thinking tokens are billed as output, so the request switches thinking off (see aiq.ClaudeProvider)."""

MODEL = "claude-haiku-5-5"

# (input, output) in USD per 1,000,000 tokens
PRICE_USD = {"claude-haiku-5-5": (0.10, 0.50), "claude-sonnet-5-5": (2.0, 10.0), "claude-opus-5-5": (4.0, 20.0)}
LONG_PRICE_USD = {"claude-haiku-5-5": (0.50, 2.50)}      # when the prompt is longer than LONG_PROMPT tokens
LONG_PROMPT = 100_000
UNKNOWN_PRICE = (4.0, 20.0)                               # an unknown model is costed like the dearest one, so a cap never under-counts

# what one call can ever be: the file's text is cut here, the answer is cut there
MAX_TEXT_CHARS = 60_000
MAX_OUT_TOKENS = 8_000
PROMPT_OVERHEAD_TOKENS = 1_500                            # the instructions and the sentence around the text (about 400 in reality; generous on purpose)
BYTE_BOUND = 2                                            # no tokenizer needs more than one token per byte; an Arabic letter is two bytes
