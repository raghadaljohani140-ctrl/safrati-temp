#!/usr/bin/env bash
# Update the live "lessonplay-web" container to the code in this folder.
#
# Nothing is changed until the new image has been built and checked. The new container gets exactly the settings of the running one
# (network, volumes, ports, restart policy, environment); the old container is kept, stopped, so that going back is one command.
# It never touches the data volume, the Caddy settings or any other project.
set -u -o pipefail

NAME=lessonplay-web
REPO=lessonplay
SITE=https://lessonplay.duckdns.org/
BACKUPS=${LP_BACKUPS:-/opt/lessonplay/backups}
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)

say()  { echo "== $*"; }
fail() { echo "!! $*" >&2; exit 1; }

command -v docker  >/dev/null || fail "docker not found (nothing changed)"
command -v python3 >/dev/null || fail "python3 not found (nothing changed)"
docker inspect "$NAME" >/dev/null 2>&1 || fail "container $NAME not found (nothing changed)"
[ -f "$HERE/Dockerfile" ] || fail "Dockerfile not found next to this script (nothing changed)"

umask 077
TMP=$(mktemp -d) || fail "no temporary folder"
trap 'rm -rf "$TMP"' EXIT

# a leftover from the previous update: only if it is stopped
if docker inspect "$NAME-old" >/dev/null 2>&1; then
    [ "$(docker inspect -f '{{.State.Running}}' "$NAME-old")" = "false" ] || fail "$NAME-old is running: stop it first (nothing changed)"
    docker rm "$NAME-old" >/dev/null || fail "could not remove the previous leftover $NAME-old"
fi

# ---------------------------------------------------------------- 1. the settings of the running container
say "1 reading the settings of the running container"
OLD_IMAGE=$(docker inspect -f '{{.Image}}' "$NAME") || fail "cannot read the image of $NAME"
python3 - "$NAME" "$OLD_IMAGE" > "$TMP/args" <<'PY' || fail "the running container has a setting this update does not carry over (nothing changed)"
import json
import subprocess
import sys

name, image = sys.argv[1], sys.argv[2]


def inspect(*a):
    return json.loads(subprocess.check_output(["docker", *a]))[0]


c = inspect("inspect", name)
im = inspect("image", "inspect", image)
cfg, hc, icfg = c["Config"], c["HostConfig"], im["Config"]
odd = []

# things this script does not carry over: stop before touching anything
for k in ("Privileged", "ReadonlyRootfs", "PublishAllPorts"):
    if hc.get(k):
        odd.append(k)
for k in ("CapAdd", "CapDrop", "SecurityOpt", "Devices", "Dns", "DnsSearch", "DnsOptions", "ExtraHosts", "Tmpfs", "Sysctls", "Ulimits",
          "VolumesFrom", "Links", "GroupAdd", "DeviceRequests"):
    if hc.get(k):
        odd.append(k)
for k in ("CpuShares", "CpuQuota", "CpuPeriod", "CpusetCpus", "CpusetMems", "PidsLimit", "MemoryReservation", "BlkioWeight"):
    if hc.get(k) and hc.get(k) not in (0, -1):
        odd.append(k)
if hc.get("MemorySwap") not in (None, 0, -1) and hc.get("MemorySwap") != 2 * (hc.get("Memory") or 0):
    odd.append("MemorySwap")
for k in ("Cmd", "Entrypoint", "WorkingDir", "User"):
    if (cfg.get(k) or None) != (icfg.get(k) or None):
        odd.append("Config." + k)
nets = list((c.get("NetworkSettings") or {}).get("Networks") or {})
mode = hc.get("NetworkMode") or "default"
if len(nets) > 1 or mode == "host" or mode.startswith("container:"):
    odd.append("networks " + ",".join(nets))
for m in c.get("Mounts") or []:
    if m.get("Type") not in ("volume", "bind"):
        odd.append("mount " + str(m.get("Type")))
if odd:
    print("not carried over: " + ", ".join(odd), file=sys.stderr)
    sys.exit(2)

args = ["--name", name]
rp = hc.get("RestartPolicy") or {}
if rp.get("Name"):
    args += ["--restart", rp["Name"] + (":%d" % rp["MaximumRetryCount"] if rp["Name"] == "on-failure" and rp.get("MaximumRetryCount") else "")]
if mode not in ("default", "bridge"):
    args += ["--network", mode]
for m in c.get("Mounts") or []:
    src = m["Name"] if m["Type"] == "volume" else m["Source"]
    args += ["-v", "%s:%s%s" % (src, m["Destination"], "" if m.get("RW", True) else ":ro")]
for port, binds in sorted((hc.get("PortBindings") or {}).items()):
    for b in binds or []:
        ip, hp = b.get("HostIp") or "", b.get("HostPort") or ""
        args += ["-p", (ip + ":" if ip else "") + hp + ":" + port if hp or ip else port]
image_env = set(icfg.get("Env") or [])
env_names = []
for e in cfg.get("Env") or []:
    if e not in image_env:
        args += ["-e", e]
        env_names.append(e.split("=", 1)[0])
if hc.get("Memory"):
    args += ["--memory", str(hc["Memory"])]
if hc.get("NanoCpus"):
    args += ["--cpus", "%g" % (hc["NanoCpus"] / 1e9)]
log = hc.get("LogConfig") or {}
if log.get("Type") and log["Type"] != "json-file":
    args += ["--log-driver", log["Type"]]
for k, v in sorted((log.get("Config") or {}).items()):
    args += ["--log-opt", "%s=%s" % (k, v)]

print("   restart=%s network=%s mounts=%s ports=%s env=%s" % (
    rp.get("Name") or "no", mode, [m["Destination"] for m in c.get("Mounts") or []],
    sorted((hc.get("PortBindings") or {})) or "none (reached through the network)", env_names or "none"), file=sys.stderr)
sys.stdout.write("".join(a + "\0" for a in args))
PY
mapfile -d '' -t RUN_ARGS < "$TMP/args"
[ "${#RUN_ARGS[@]}" -ge 2 ] || fail "could not read the settings (nothing changed)"

# ---------------------------------------------------------------- 2. a copy of the database
say "2 saving a copy of the database"
mkdir -p "$BACKUPS" || fail "cannot create $BACKUPS (nothing changed)"
FREE_KB=$(df -Pk /var/lib/docker 2>/dev/null | awk 'NR==2 {print $4}')
if [ -n "${FREE_KB:-}" ] && [ "$FREE_KB" -lt 1500000 ]; then
    fail "less than 1.5 GB free on the server disk ($(( FREE_KB / 1024 )) MB): free some space first, e.g. docker image prune -f (nothing changed)"
fi
COPY="$BACKUPS/app-before-$(date +%Y%m%d-%H%M%S).db"
docker exec "$NAME" python -c "
import os, sqlite3
src = sqlite3.connect(os.path.join(os.environ.get('INSTANCE_DIR', '/srv/instance'), 'app.db'))
dst = sqlite3.connect('/tmp/before-update.db')
src.backup(dst)
dst.close()
src.close()" || fail "the backup failed (nothing changed)"
docker cp "$NAME:/tmp/before-update.db" "$COPY" || fail "could not copy the backup out (nothing changed)"
docker exec "$NAME" rm -f /tmp/before-update.db
COUNTS='import sqlite3, sys; c = sqlite3.connect(sys.argv[1]); print("users", c.execute("select count(*) from users").fetchone()[0], "| lessons", c.execute("select count(*) from lessons").fetchone()[0], "| students", c.execute("select count(*) from students").fetchone()[0])'
chmod 600 "$COPY"
python3 -c "$COUNTS" "$COPY" || fail "the backup copy cannot be read (nothing changed)"
echo "   saved: $COPY"

# ---------------------------------------------------------------- 3. the new image
say "3 building the new image (a few minutes)"
LAST=$(docker images "$REPO" --format '{{.Tag}}' | grep -E '^[0-9]+$' | sort -n | tail -1)
NEW="$REPO:$(( ${LAST:-0} + 1 ))"
docker build -t "$NEW" "$HERE" || fail "the build failed (nothing changed, the site is still running)"
say "4 checking the new image $NEW"
docker run --rm "$NEW" python -c "import flask, pypdf, pdfminer, pptx, PIL, pytesseract; import app.extract, app.pdfgeo; print('   imports ok, pdfminer', pdfminer.__version__)" \
    || fail "the new image does not start (nothing changed, the site is still running)"

# ---------------------------------------------------------------- 5. swap, with the way back
wait_for_app() {
    local i
    for i in $(seq 1 30); do
        sleep 2
        [ "$(docker inspect -f '{{.State.Running}}' "$NAME" 2>/dev/null)" = "true" ] || return 1
        docker exec "$NAME" python -c "import sys, urllib.request as u; sys.exit(0 if u.urlopen('http://127.0.0.1:8100/', timeout=5).status == 200 else 1)" >/dev/null 2>&1 && return 0
    done
    return 1
}

say "5 replacing the container ($(docker inspect -f '{{.Config.Image}}' "$NAME") -> $NEW)"
docker stop "$NAME" >/dev/null || fail "could not stop the old container (nothing changed)"
if ! docker rename "$NAME" "$NAME-old"; then
    docker start "$NAME" >/dev/null
    fail "could not rename the old container; it was started again (nothing changed)"
fi
if docker run -d "${RUN_ARGS[@]}" "$NEW" >/dev/null && wait_for_app; then
    say "6 the new container answers"
else
    echo "!! the new container did not answer; putting the old one back" >&2
    docker logs --tail 25 "$NAME" >&2 2>&1
    docker rm -f "$NAME" >/dev/null 2>&1
    docker rename "$NAME-old" "$NAME" && docker start "$NAME" >/dev/null && echo "== the old container is running again" >&2
    exit 1
fi

# ---------------------------------------------------------------- 7. look at the result
code=000
for _ in 1 2 3 4 5 6; do
    code=$(curl -s -o /dev/null -w '%{http_code}' "$SITE" || true)
    [ "$code" = "200" ] && break
    sleep 3
done
say "7 public site: HTTP $code"
docker exec "$NAME" python -c "
import os, sqlite3, sys
c = sqlite3.connect(os.path.join(os.environ.get('INSTANCE_DIR', '/srv/instance'), 'app.db'))
print('   data now: users', c.execute('select count(*) from users').fetchone()[0], '| lessons', c.execute('select count(*) from lessons').fetchone()[0], '| students', c.execute('select count(*) from students').fetchone()[0])"
docker ps --filter "name=^$NAME\$" --format '   running: {{.Names}}  {{.Image}}  {{.Status}}'
if [ "$code" != "200" ]; then
    echo "!! the container answers but the public site returned $code; send me this screen" >&2
fi
echo "   to go back to the old version if ever needed:"
echo "   docker stop $NAME && docker rename $NAME $NAME-bad && docker rename $NAME-old $NAME && docker start $NAME"
