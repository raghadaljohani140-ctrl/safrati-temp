"""Two companies on one installation.

The second company has its own signed-in owner (every permission of its own company) and its own employee. They try to read and to change the first
company's data through every page that takes an id, through the lists and the exports, through the employee screens, and through the phone API.
Nothing of the first company may show up, and not one row of it may change."""
from __future__ import annotations

import csv
import hashlib
import io
import json
import re
import sqlite3
import sys
import unittest
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from tests.client import Client  # noqa: E402
from tests.harness import LiveServer  # noqa: E402

PW = "Owner-pass-2026"
A_MARKS = ("شركة-ألف", "مالك-ألف", "سارة-ألف", "عميل-ألف", "سر-ألف", "مدينة-ألف", "جوال-ألف", "owner_alef", "sara_a")
B_MARKS = ("شركة-باء", "مالك-باء", "سارة-باء", "عميل-باء", "سر-باء", "مدينة-باء", "جوال-باء", "owner_baa", "sara_b")
for _m in A_MARKS + B_MARKS:
    assert not re.fullmatch(r"[0-9a-f]+", _m), f"marker {_m!r} could appear by chance inside a hash"
SKIP_TABLES = {"sessions", "notices", "backup_log"}   # written by the clock-driven background loop or by logins, not by anything a test does to a company


def csv_bytes(rows: list[list[str]]) -> bytes:
    buf = io.StringIO()
    csv.writer(buf).writerows(rows)
    return ("﻿" + buf.getvalue()).encode("utf-8")


def temp_password(html: str) -> str:
    m = re.search(r'<span class="code">([^<]+)</span>', html)
    assert m, "no temporary password on the page"
    return m.group(1).strip()


def leaks(text: str, marks: tuple[str, ...]) -> list[str]:
    return [m for m in marks if m in text]


def fingerprint(con: sqlite3.Connection, cid: int) -> dict[str, str]:
    """One hash per table of everything that belongs to company `cid`, so a failure says which table changed."""
    out: dict[str, str] = {}
    for (t,) in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall():
        if t in SKIP_TABLES:
            continue
        cols = [r[1] for r in con.execute(f"PRAGMA table_info({t})")]
        args: tuple = (cid,)
        if "company_id" in cols:
            where = "company_id=?" + (" AND type NOT LIKE 'system.%'" if t == "events" else "")
        elif t == "companies":
            where = "id=?"
        elif t == "breaks":
            where = "shift_id IN (SELECT id FROM shifts WHERE company_id=?)"
        elif t == "import_rows":
            where = "batch_id IN (SELECT id FROM lead_batches WHERE company_id=?)"
        else:
            continue
        h = hashlib.sha256()
        for row in con.execute(f"SELECT * FROM {t} WHERE {where} ORDER BY rowid", args):
            h.update(repr(tuple(row)).encode("utf-8"))
        out[t] = h.hexdigest()
    return out


class Isolation(unittest.TestCase):
    srv: LiveServer
    a_owner: Client
    a_sara: Client
    b_owner: Client
    b_sara: Client
    _open: list[sqlite3.Connection] = []

    # ------------------------------------------------------------------------------------------ the two companies
    @classmethod
    def setUpClass(cls) -> None:
        cls.srv = LiveServer().start()
        try:
            cls.build()
        except BaseException:
            cls.srv.stop()
            raise

    @classmethod
    def tearDownClass(cls) -> None:
        log = cls.srv.log()
        if "Traceback" in log:
            print("\n--- server tracebacks ---\n" + "\n".join(blk[:1800] for blk in log.split("Traceback")[1:6]))
        for con in cls._open:
            con.close()
        cls._open.clear()
        cls.srv.stop()

    @classmethod
    def db(cls) -> sqlite3.Connection:
        c = sqlite3.connect(str(cls.srv.db_path), isolation_level=None)
        c.row_factory = sqlite3.Row
        cls._open.append(c)
        return c

    @classmethod
    def employee(cls, owner: Client, name: str, username: str) -> Client:
        owner.get("/m/employees/new")
        r = owner.post("/m/employees/new", {"name": name, "username": username, "phone": "0555000111"})
        assert r.status == 200, r.text[:300]
        s = Client(port=cls.srv.port)
        assert s.post("/login", {"username": username, "password": temp_password(r.text)}).status == 303
        s.get("/password")
        new = "Staff-new-pass-77"
        assert s.post("/password", {"current": temp_password(r.text), "new": new, "again": new}).status == 303
        s.get("/w")
        return s

    @classmethod
    def import_leads(cls, owner: Client, label: str, city: str, first_digits: str, n: int) -> int:
        rows = [["الاسم", "الجوال", "المدينة"]] + [[f"عميل-{label}-{i}", f"05{first_digits}{i:06d}", city] for i in range(1, n + 1)]
        up = owner.upload("/m/import/upload", f"{label}.csv", csv_bytes(rows))
        assert up.status == 303, up.text[:300]
        bid = int(up.location.rsplit("/", 1)[1])
        assert owner.post(f"/m/import/{bid}/map", {"m_name": "0", "m_phone": "1", "m_city": "2", "has_header": "1"}).status == 303
        assert owner.post(f"/m/import/{bid}/commit").status == 303
        return bid

    @classmethod
    def api(cls, path: str, data: dict | None = None, token: str | None = None) -> tuple[int, dict]:
        req = urllib.request.Request(f"http://127.0.0.1:{cls.srv.port}{path}", data=json.dumps(data).encode() if data is not None else None,
                                     headers={"Content-Type": "application/json", **({"Authorization": f"Bearer {token}"} if token else {})})
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return resp.status, json.loads(resp.read())
        except urllib.error.HTTPError as ex:
            return ex.code, json.loads(ex.read())

    @classmethod
    def enroll_device(cls, owner: Client, user_id: int, label: str) -> str:
        page = owner.post("/m/devices/code", {"user": str(user_id), "note": label})
        m = re.search(r'class="code-big ltr">([a-z0-9]{4}-[a-z0-9]{4})<', page.text)
        assert m, page.text[:300]
        status, res = cls.api("/api/v1/enroll", {"code": m.group(1), "name": label, "model": "Pixel", "app_version": "0.1"})
        assert status == 200, res
        return res["token"]

    @classmethod
    def build(cls) -> None:
        settings = {"_all": "1", "platform_name": "استراحتي", "platform_url": "https://estrahati.example", "daily_new": "3", "shift_hours": "8",
                    "minutes_per_call": "4", "tz": "Asia/Riyadh"}
        # --- company A: owner (also the operator of the installation), an employee with a finished day, a device, a comparison, a backup
        o = cls.a_owner = Client(port=cls.srv.port)
        o.get("/setup")
        assert o.post("/setup", {"code": cls.srv.setup_code, "company": "شركة-ألف", "name": "مالك-ألف", "username": "owner_alef", "password": PW, "again": PW}).status in (200, 303)
        o.get("/m/settings")                                       # a page of the signed-in session carries the token the next request needs
        assert o.post("/m/settings", settings).status == 303
        s = cls.a_sara = cls.employee(o, "سارة-ألف", "sara_a")
        cls.a_batch = cls.import_leads(o, "ألف", "مدينة-ألف", "51", 6)
        con = cls.db()
        cls.a_uid_owner = con.execute("SELECT id FROM users WHERE username='owner_alef'").fetchone()[0]
        cls.a_uid_sara = con.execute("SELECT id FROM users WHERE username='sara_a'").fetchone()[0]
        assert s.post("/w/start").status == 303
        ids = [r["lead_id"] for r in con.execute("SELECT lead_id FROM tasks ORDER BY position")]
        assert len(ids) == 3, ids
        s.post(f"/w/lead/{ids[0]}/call")
        s.post(f"/w/lead/{ids[0]}/outcome", {"outcome": "interested", "note": "سر-ألف: ملاحظة لا يراها غير شركتها"})
        s.post(f"/w/lead/{ids[1]}/outcome", {"outcome": "no_answer"})
        s.post(f"/w/lead/{ids[2]}/call")
        s.post(f"/w/lead/{ids[2]}/outcome", {"outcome": "asked_link"})
        end = s.post("/w/end", {"all_reason": "no_time", "note": ""})
        assert end.status == 303, end.text[:300]
        cls.a_leads = [r["id"] for r in con.execute("SELECT id FROM leads WHERE company_id=1 ORDER BY id")]
        cls.a_phone = con.execute("SELECT phone FROM leads WHERE id=?", (ids[0],)).fetchone()[0]
        cls.a_attempt = con.execute("SELECT id FROM call_attempts WHERE company_id=1 AND status='recorded' ORDER BY id LIMIT 1").fetchone()[0]
        cls.a_day = con.execute("SELECT work_date FROM shifts WHERE company_id=1").fetchone()[0]
        cls.a_token = cls.enroll_device(o, cls.a_uid_sara, "جوال-ألف")
        cls.a_device = con.execute("SELECT id FROM devices WHERE company_id=1").fetchone()[0]
        table = ("الاسم\tالجوال\tالإعلانات\tالموافقات\tالتسجيل\tالحالة\n"
                 f"عميل-ألف-1\t{cls.a_phone.replace('+966', '0')}\t1\t1\t2026-11-03 10:00\tنشط\n"
                 "مالك غريب\t0599999999\t3\t3\t2026-10-01 09:00\tنشط\n")
        assert o.post("/m/compare/paste", {"text": table}).status == 303
        row = con.execute("SELECT id, import_id FROM ext_rows WHERE company_id=1 ORDER BY id LIMIT 1").fetchone()
        cls.a_ext_row, cls.a_import = row["id"], row["import_id"]
        assert "تمت النسخة" in o.follow(o.post("/m/backups/make")).text
        cls.a_backup = con.execute("SELECT id FROM backup_log WHERE ok=1 ORDER BY id DESC LIMIT 1").fetchone()[0]
        # --- company B registers through the public page once the operator opens registration
        assert o.post("/p/registration").status == 303
        b = cls.b_owner = Client(port=cls.srv.port)
        b.get("/register")
        reg = b.post("/register", {"company": "شركة-باء", "name": "مالك-باء", "username": "owner_baa", "password": PW, "again": PW})
        assert reg.status == 303, reg.text[:300]
        b.get("/m/settings")
        assert b.post("/m/settings", settings).status == 303
        cls.b_sara = cls.employee(b, "سارة-باء", "sara_b")
        cls.import_leads(b, "باء", "مدينة-باء", "57", 4)
        cls.b_uid_owner = con.execute("SELECT id FROM users WHERE username='owner_baa'").fetchone()[0]
        cls.b_uid_sara = con.execute("SELECT id FROM users WHERE username='sara_b'").fetchone()[0]
        assert cls.b_sara.post("/w/start").status == 303
        cls.b_leads = [r["id"] for r in con.execute("SELECT id FROM leads WHERE company_id=2 ORDER BY id")]
        cls.b_token = cls.enroll_device(b, cls.b_uid_sara, "جوال-باء")
        cls.b_cid = con.execute("SELECT company_id FROM users WHERE username='owner_baa'").fetchone()[0]

    def snapshot(self, cid: int) -> dict[str, str]:
        return fingerprint(self.db(), cid)

    def assert_unchanged(self, before: dict[str, str], cid: int, what: str) -> None:
        after = self.snapshot(cid)
        changed = sorted(t for t in before if before[t] != after.get(t))
        self.assertEqual(changed, [], f"{what} changed rows of company {cid} in: {changed}")

    # ------------------------------------------------------------------------------------------ the two are really separate
    def test_00_the_setup_made_two_companies(self):
        self.assertEqual(self.b_cid, 2)
        con = self.db()
        self.assertEqual(con.execute("SELECT COUNT(*) FROM leads WHERE company_id=1").fetchone()[0], 6)
        self.assertEqual(con.execute("SELECT COUNT(*) FROM leads WHERE company_id=2").fetchone()[0], 4)
        self.assertEqual(self.api("/api/v1/ping", token=self.a_token)[0], 200)
        self.assertEqual(self.api("/api/v1/ping", token=self.b_token)[0], 200)

    def test_01_each_company_sees_only_its_own_pages_lists_and_exports(self):
        manager_pages = ["/m", "/m/employees", "/m/leads", "/m/leads?q=%D8%B9%D9%85%D9%8A%D9%84", "/m/leads?status=interested", "/m/import", "/m/distribute", "/m/reports",
                         "/m/reports.csv", "/m/compare", "/m/settings", "/m/devices", "/m/log", "/m/export", "/m/export/leads.csv", "/m/export/calls.csv",
                         "/m/export/events.csv", "/m/team", "/m/drill/calls"]
        manager_pages += [f"/m/drill/{m}" for m in ("working", "not_started", "answered", "interested", "links_sent", "links_opened", "reg_reported", "reg_confirmed",
                                                    "tasks_open", "gaps", "overdue", "orphans", "exhausted")]
        for who, client, foreign in (("B", self.b_owner, A_MARKS), ("A", self.a_owner, B_MARKS)):
            for path in manager_pages:
                r = client.get(path)
                self.assertEqual(r.status, 200, f"{who} {path}: {r.status}")
                self.assertEqual(leaks(r.text, foreign), [], f"{who} {path} shows the other company's data")
        for who, client, foreign in (("B", self.b_sara, A_MARKS), ("A", self.a_sara, B_MARKS)):
            for path in ("/w", "/w/tasks", "/w/me", "/w/search?q=%D8%B9%D9%85%D9%8A%D9%84", "/w/search?q=0551", "/w/search?q=0571", f"/w/day/{self.a_day}"):
                r = client.get(path)
                self.assertIn(r.status, (200, 303, 404), f"{who} {path}: {r.status}")
                self.assertEqual(leaks(r.text, foreign), [], f"{who} employee {path} shows the other company's data")
        own = self.b_owner.get("/m/leads").text
        self.assertIn("عميل-باء", own, "the company's own clients are there (the check above is not passing on an empty page)")
        self.assertNotIn("عميل-ألف", own)

    def test_02_cannot_open_the_other_companys_records_by_id(self):
        probes = [f"/m/lead/{self.a_leads[0]}", f"/m/lead/{self.a_leads[-1]}", f"/m/employee/{self.a_uid_sara}", f"/m/team/{self.a_uid_owner}",
                  f"/m/reports/employee/{self.a_uid_sara}", f"/m/report/{self.a_uid_sara}/{self.a_day}", f"/m/import/{self.a_batch}",
                  f"/m/import/{self.a_batch}/rejected.csv", f"/m/compare/import/{self.a_import}"]
        for path in probes:
            r = self.b_owner.get(path)
            self.assertIn(r.status, (403, 404), f"B {path}: {r.status}\n{r.text[:200]}")
            self.assertEqual(leaks(r.text, A_MARKS), [], f"B {path} shows company A's data")
        # the same records do open for their own company (so the 404s above are about the company, not about a wrong address)
        for path in (probes[0], probes[2], probes[4], probes[5], probes[6], probes[8]):
            self.assertEqual(self.a_owner.get(path).status, 200, f"A {path}")

    def test_03_cannot_change_the_other_companys_records_by_id(self):
        before = self.snapshot(1)
        b_sara = str(self.b_uid_sara)
        attacks = [
            (f"/m/lead/{self.a_leads[1]}/assign", {"to": b_sara}),
            (f"/m/lead/{self.a_leads[1]}/assign", {"to": "pool"}),
            (f"/m/lead/{self.a_leads[0]}/reopen", {"why": "محاولة من شركة أخرى"}),
            ("/m/leads/bulk", {"ids": [str(i) for i in self.a_leads], "to": b_sara, "back": "/m/leads"}),
            ("/m/leads/bulk", {"ids": [str(i) for i in self.a_leads], "to": "pool", "back": "/m/leads"}),
            (f"/m/employee/{self.a_uid_sara}", {"name": "اسم مسروق", "phone": "0500000000", "daily_new": "1", "shift_hours": "1"}),
            (f"/m/employee/{self.a_uid_sara}/reset", {}),
            (f"/m/employee/{self.a_uid_sara}/active", {}),
            (f"/m/team/{self.a_uid_owner}", {"name": "اسم مسروق", "phone": "0500000000"}),
            (f"/m/team/{self.a_uid_owner}/reset", {}),
            (f"/m/team/{self.a_uid_owner}/active", {}),
            (f"/m/correct/{self.a_attempt}", {"new": "not_interested", "reason": "تصحيح من شركة أخرى", "back": "/m/reports"}),
            (f"/m/report/{self.a_uid_sara}/{self.a_day}/reopen", {"why": "محاولة من شركة أخرى"}),
            (f"/m/import/{self.a_batch}/map", {"m_name": "0", "m_phone": "1", "m_city": "2", "has_header": "1"}),
            (f"/m/import/{self.a_batch}/commit", {}),
            (f"/m/import/{self.a_batch}/cancel", {}),
            (f"/m/compare/row/{self.a_ext_row}/approve", {}),
            (f"/m/compare/row/{self.a_ext_row}/link", {"q": f"#{self.b_leads[0]}"}),
            (f"/m/devices/{self.a_device}/revoke", {}),
        ]
        for path, data in attacks:
            self.b_owner.get("/m")                                 # a fresh page, so the request carries a valid token of B's own session
            r = self.b_owner.post(path, data)
            landed = self.b_owner.follow(r) if r.status in (301, 302, 303) else r
            self.assertEqual(leaks(landed.text, A_MARKS), [], f"POST {path} answered with company A's data")
            self.assertNotIn("نُقل", landed.text.replace("نُقل 0", ""), f"POST {path} reported a move")
        self.assert_unchanged(before, 1, "company B's requests")
        self.assertEqual(self.api("/api/v1/ping", token=self.a_token)[0], 200, "A's phone is still linked")
        self.assertEqual(self.a_owner.get(f"/m/employee/{self.a_uid_sara}").status, 200, "A's employee is still active and under A's name")
        self.assertIn("سارة-ألف", self.a_owner.get(f"/m/employee/{self.a_uid_sara}").text)

    def test_04_an_employee_of_one_company_cannot_work_on_the_others_clients(self):
        before = self.snapshot(1)
        for lead in self.a_leads:
            self.assertIn(self.b_sara.get(f"/w/lead/{lead}").status, (403, 404, 303), f"/w/lead/{lead}")
            self.assertNotEqual(self.b_sara.post(f"/w/lead/{lead}/call").status, 204, f"call {lead}")
            self.assertNotEqual(self.b_sara.post(f"/w/lead/{lead}/link").status, 204, f"link {lead}")
            r = self.b_sara.post(f"/w/lead/{lead}/outcome", {"outcome": "no_answer"})
            self.assertNotEqual(r.status, 303, f"outcome {lead}")
            self.assertEqual(leaks(r.text, A_MARKS), [], "an error page must not carry the other company's client")
        con = self.db()
        for (task,) in con.execute("SELECT id FROM tasks WHERE company_id=1").fetchall():
            self.b_sara.post(f"/w/skip/{task}")
        self.assert_unchanged(before, 1, "company B's employee")
        # and the other way round
        before_b = self.snapshot(2)
        for lead in self.b_leads:
            self.assertNotEqual(self.a_sara.post(f"/w/lead/{lead}/call").status, 204)
            self.assertNotEqual(self.a_sara.post(f"/w/lead/{lead}/outcome", {"outcome": "no_answer"}).status, 303)
        self.assert_unchanged(before_b, 2, "company A's employee")

    def test_05_operator_pages_and_the_whole_database_backup_are_for_the_operator_only(self):
        before = self.snapshot(1)
        for path in ("/p", "/m/backups", f"/m/backups/{self.a_backup}/download", "/m/backups/1/download"):
            r = self.b_owner.get(path)
            self.assertEqual(r.status, 403, f"B {path}")
            self.assertNotIn(b"SQLite format 3", r.body[:20])
        for path, data in (("/p/registration", {}), ("/p/verify", {}), ("/p/company/1/active", {}), ("/p/company", {"company": "شركة-دخيلة", "name": "x", "username": "intruder",
                                                                                                                       "password": PW, "again": PW}),
                           ("/m/backups/make", {}), ("/m/backups/test", {})):
            self.b_owner.get("/m")
            self.assertEqual(self.b_owner.post(path, data).status, 403, f"B POST {path}")
        for path in ("/p", "/m/backups", f"/m/backups/{self.a_backup}/download"):
            self.assertIn(self.b_sara.get(path).status, (303, 403, 404), f"employee {path}")
            self.assertIn(self.a_sara.get(path).status, (303, 403, 404), f"employee {path}")
        dl = self.a_owner.get(f"/m/backups/{self.a_backup}/download")
        self.assertEqual((dl.status, dl.body[:2]), (200, b"\x1f\x8b"), "the operator can download")
        self.assertEqual(self.db().execute("SELECT COUNT(*) FROM users WHERE username='intruder'").fetchone()[0], 0)
        self.assert_unchanged(before, 1, "operator-only requests from company B")

    def test_06_the_phone_api_only_knows_its_own_companys_clients(self):
        now = datetime.now(timezone.utc).isoformat()
        con = self.db()
        b_phone = con.execute("SELECT phone FROM leads WHERE id=?", (self.b_leads[0],)).fetchone()[0]
        # B's phone says it called A's client. Whatever B's phone does may touch B's rows (its own "last seen"), and must touch none of A's.
        before_a = self.snapshot(1)
        status, res = self.api("/api/v1/calls", {"calls": [{"number": self.a_phone, "started_at": now, "duration_sec": 30, "type": "outgoing"}]}, self.b_token)
        self.assertEqual(status, 200, res)
        self.assertEqual((res["stored"], res["matched"]), (0, 0), "A's client is nobody's client in company B, so the call is dropped")
        b_watch = self.api("/api/v1/watch", token=self.b_token)[1]
        self.assert_unchanged(before_a, 1, "company B's phone")
        # and the other way round
        before_b = self.snapshot(2)
        status, res = self.api("/api/v1/calls", {"calls": [{"number": b_phone, "started_at": now, "duration_sec": 30, "type": "outgoing"}]}, self.a_token)
        self.assertEqual(status, 200, res)
        self.assertEqual((res["stored"], res["matched"]), (0, 0))
        a_watch = self.api("/api/v1/watch", token=self.a_token)[1]
        self.assertEqual(con.execute("SELECT COUNT(*) FROM device_calls").fetchone()[0], 0, "no call to a stranger's client is ever stored")
        self.assertEqual(b_watch["count"], len(self.b_leads), "the list a phone is given holds only its own company's numbers")
        self.assertEqual(a_watch["count"], len(self.a_leads))
        self.assertFalse(set(a_watch["hashes"]) & set(b_watch["hashes"]))
        self.assertEqual(self.api("/api/v1/calls", {"calls": []}, "not-a-token-not-a-token")[0], 401)
        # a pairing code links a phone to the company that issued it
        page = self.a_owner.post("/m/devices/code", {"user": str(self.a_uid_sara), "note": "جوال-ألف-2"})
        code = re.search(r'class="code-big ltr">([a-z0-9]{4}-[a-z0-9]{4})<', page.text).group(1)
        status, _ = self.api("/api/v1/enroll", {"code": code, "name": "x", "model": "x", "app_version": "0"})
        self.assertEqual(status, 200)
        self.assertEqual(con.execute("SELECT company_id FROM devices ORDER BY id DESC LIMIT 1").fetchone()[0], 1)
        self.assert_unchanged(before_b, 2, "company A's phone and its pairing")

    def test_07_no_row_points_across_companies_and_both_event_logs_are_intact(self):
        con = self.db()
        crossings = {
            "events -> leads": "SELECT COUNT(*) FROM events e JOIN leads l ON l.id=e.lead_id WHERE l.company_id<>e.company_id",
            "events -> users (user)": "SELECT COUNT(*) FROM events e JOIN users u ON u.id=e.user_id WHERE u.company_id<>e.company_id",
            "events -> users (actor)": "SELECT COUNT(*) FROM events e JOIN users u ON u.id=e.actor_id WHERE u.company_id<>e.company_id",
            "leads -> owner": "SELECT COUNT(*) FROM leads l JOIN users u ON u.id=l.owner_id WHERE u.company_id<>l.company_id",
            "call_attempts -> leads": "SELECT COUNT(*) FROM call_attempts a JOIN leads l ON l.id=a.lead_id WHERE l.company_id<>a.company_id",
            "call_attempts -> users": "SELECT COUNT(*) FROM call_attempts a JOIN users u ON u.id=a.user_id WHERE u.company_id<>a.company_id",
            "tasks -> leads": "SELECT COUNT(*) FROM tasks t JOIN leads l ON l.id=t.lead_id WHERE l.company_id<>t.company_id",
            "tasks -> users": "SELECT COUNT(*) FROM tasks t JOIN users u ON u.id=t.user_id WHERE u.company_id<>t.company_id",
            "assignments -> leads": "SELECT COUNT(*) FROM assignments a JOIN leads l ON l.id=a.lead_id WHERE l.company_id<>a.company_id",
            "shifts -> users": "SELECT COUNT(*) FROM shifts s JOIN users u ON u.id=s.user_id WHERE u.company_id<>s.company_id",
            "devices -> users": "SELECT COUNT(*) FROM devices d JOIN users u ON u.id=d.user_id WHERE u.company_id<>d.company_id",
            "device_calls -> devices": "SELECT COUNT(*) FROM device_calls c JOIN devices d ON d.id=c.device_id WHERE d.company_id<>c.company_id",
            "ext_rows -> leads": "SELECT COUNT(*) FROM ext_rows r JOIN leads l ON l.id=r.lead_id WHERE l.company_id<>r.company_id",
        }
        for name, sql in crossings.items():
            self.assertEqual(con.execute(sql).fetchone()[0], 0, f"rows that point across companies: {name}")
        for who, client in (("A", self.a_owner), ("B", self.b_owner)):
            client.get("/m/log")
            r = client.follow(client.post("/m/log/verify"))
            self.assertIn("السجل سليم", r.text, f"company {who}'s event log")
        self.assertEqual(self.a_owner.follow(self.a_owner.post("/p/verify")).status, 200)


if __name__ == "__main__":
    unittest.main()
