"""A tiny browser stand-in for the tests: keeps cookies, remembers the CSRF token of the last page, never follows redirects by itself."""
from __future__ import annotations

import http.client
import re
import urllib.parse
from dataclasses import dataclass


@dataclass
class Resp:
    status: int
    headers: dict[str, str]
    body: bytes

    @property
    def text(self) -> str:
        return self.body.decode("utf-8", "replace")

    @property
    def location(self) -> str:
        return self.headers.get("location", "")


class Client:
    def __init__(self, host: str = "127.0.0.1", port: int = 18095) -> None:
        self.host, self.port = host, port
        self.cookies: dict[str, str] = {}
        self.csrf = ""
        self.last: Resp | None = None

    def _send(self, method: str, path: str, body: bytes | None = None, headers: dict | None = None) -> Resp:
        conn = http.client.HTTPConnection(self.host, self.port, timeout=30)
        h = {"Host": f"{self.host}:{self.port}", "Sec-Fetch-Site": "same-origin"}
        if self.cookies:
            h["Cookie"] = "; ".join(f"{k}={urllib.parse.quote(v, safe='')}" for k, v in self.cookies.items())
        h.update(headers or {})
        conn.request(method, path, body=body, headers=h)
        r = conn.getresponse()
        data = r.read()
        hdrs = {k.lower(): v for k, v in r.getheaders()}
        for k, v in r.getheaders():
            if k.lower() == "set-cookie":
                pair = v.split(";", 1)[0]
                name, _, val = pair.partition("=")
                if "Max-Age=0" in v:
                    self.cookies.pop(name, None)
                else:
                    self.cookies[name] = urllib.parse.unquote(val)
        conn.close()
        resp = Resp(r.status, hdrs, data)
        m = re.search(r'name="_csrf" value="([^"]+)"', resp.text) if "text/html" in hdrs.get("content-type", "") else None
        if m:
            self.csrf = m.group(1)
        self.last = resp
        return resp

    def get(self, path: str, headers: dict | None = None) -> Resp:
        return self._send("GET", path, None, headers)

    def post(self, path: str, data: dict | None = None, *, csrf: bool = True, headers: dict | None = None) -> Resp:
        fields = dict(data or {})
        if csrf and self.csrf:
            fields.setdefault("_csrf", self.csrf)
        pairs = []
        for k, v in fields.items():
            for item in (v if isinstance(v, (list, tuple)) else [v]):
                pairs.append((k, str(item)))
        body = urllib.parse.urlencode(pairs).encode()
        h = {"Content-Type": "application/x-www-form-urlencoded"}
        h.update(headers or {})
        return self._send("POST", path, body, h)

    def upload(self, path: str, filename: str, content: bytes, fields: dict | None = None, field_name: str = "file") -> Resp:
        boundary = "----mjtest7d3f"
        parts = []
        allf = dict(fields or {})
        if self.csrf:
            allf.setdefault("_csrf", self.csrf)
        for k, v in allf.items():
            parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode())
        parts.append((f'--{boundary}\r\nContent-Disposition: form-data; name="{field_name}"; filename="{filename}"\r\n'
                      f'Content-Type: application/octet-stream\r\n\r\n').encode() + content + b"\r\n")
        parts.append(f"--{boundary}--\r\n".encode())
        return self._send("POST", path, b"".join(parts), {"Content-Type": f"multipart/form-data; boundary={boundary}"})

    def follow(self, resp: Resp | None = None, limit: int = 5) -> Resp:
        r = resp or self.last
        for _ in range(limit):
            if r.status in (301, 302, 303, 307) and r.location:
                r = self.get(r.location)
            else:
                break
        return r
