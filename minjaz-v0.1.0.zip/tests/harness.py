"""Starts the real server in a scratch folder on a free port, so tests talk to it exactly like a browser does."""
from __future__ import annotations

import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class LiveServer:
    def __init__(self, env: dict[str, str] | None = None) -> None:
        self.env = env or {}
        self.dir = Path(tempfile.mkdtemp(prefix="minjaz-test-"))
        self.port = free_port()
        self.proc: subprocess.Popen | None = None
        self._log_fh = None
        self.log_path = self.dir / "server.log"
        self.setup_code = ""

    def start(self) -> "LiveServer":
        env = dict(os.environ, DATA_DIR=str(self.dir / "data"), PORT=str(self.port), HOST="127.0.0.1", COOKIE_SECURE="0", LOG_LEVEL="INFO", **self.env)
        self._log_fh = open(self.log_path, "wb")
        self.proc = subprocess.Popen([sys.executable, "-m", "minjaz", "run"], cwd=ROOT, env=env, stdout=self._log_fh, stderr=subprocess.STDOUT)
        deadline = time.time() + 20
        while time.time() < deadline:
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{self.port}/healthz", timeout=1) as r:
                    if r.status == 200:
                        break
            except Exception:
                time.sleep(0.2)
        else:
            raise RuntimeError("server did not start:\n" + self.log_path.read_text(errors="replace"))
        m = re.search(r"([a-z0-9]{4}-[a-z0-9]{4}-[a-z0-9]{4})", self.log_path.read_text(errors="replace"))
        self.setup_code = m.group(1) if m else ""
        return self

    def stop(self) -> None:
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(8)
            except subprocess.TimeoutExpired:
                self.proc.kill()
        if self._log_fh:
            self._log_fh.close()
            self._log_fh = None
        shutil.rmtree(self.dir, ignore_errors=True)

    def log(self) -> str:
        return self.log_path.read_text(errors="replace")

    @property
    def db_path(self) -> Path:
        return self.dir / "data" / "minjaz.db"

    def __enter__(self) -> "LiveServer":
        return self.start()

    def __exit__(self, *exc) -> None:
        self.stop()
