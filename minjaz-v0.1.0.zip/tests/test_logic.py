"""The rules, one at a time, against a throw-away database and a clock the test controls: phone numbers, follow-up ladders, plan sizing,
who gets which number, idle gaps, forgotten days, login lockout, session expiry, and tamper detection.
The end-to-end story through the real server lives in test_flow.py."""
from __future__ import annotations

import datetime as dt
import gzip
import io
import json
import sqlite3
import subprocess
import sys
import tempfile
import textwrap
import time
import unittest
import zipfile
from unittest import mock
from pathlib import Path
from xml.sax.saxutils import escape

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from minjaz import backup, compare, config, consts, db, importer, leads as leadlib, phones, plans, reports, security, settings as st, util, work  # noqa: E402

UTC = dt.timezone.utc
# Tuesday 3 November 2026, 12:00 in Riyadh (09:00 UTC): inside the allowed calling hours
NOON = dt.datetime(2026, 11, 3, 9, 0, tzinfo=UTC)


class Base(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "t.db"
        db.init(self.path)
        util.freeze(NOON)
        with db.tx(True, self.path) as c:
            self.cid = db.create_company(c, "شركة الاختبار")

    def tearDown(self) -> None:
        util.freeze(None)
        self.tmp.cleanup()

    # --- small builders -------------------------------------------------------------------------------------------------------------------
    def user(self, c, username: str, role: str = "employee", **kw) -> sqlite3.Row:
        cur = c.execute("INSERT INTO users(company_id,username,name,role,password_hash,created_at,daily_new,shift_hours,active) VALUES(?,?,?,?,?,?,?,?,?)",
                        (self.cid, username, kw.get("name", username), role, security.hash_password("Test-pass-2026"), util.now_iso(),
                         kw.get("daily_new"), kw.get("shift_hours"), kw.get("active", 1)))
        return db.one(c, "SELECT * FROM users WHERE id=?", cur.lastrowid)

    def leads(self, c, n: int, *, start: int = 1, landline: bool = False, owner: int | None = None, status: str = "new", due: str | None = None) -> list[int]:
        ids = []
        for i in range(start, start + n):
            phone = f"+96611{i:07d}" if landline else f"+966555{i:06d}"
            cur = c.execute("INSERT INTO leads(company_id,name,phone,added_at,line_type,owner_id,status,next_follow_up) VALUES(?,?,?,?,?,?,?,?)",
                            (self.cid, f"عميل {i}", phone, util.now_iso(), "landline" if landline else "mobile", owner, status, due))
            ids.append(int(cur.lastrowid))
        return ids

    def settings(self, c, **over) -> dict:
        for k, v in over.items():
            db.set_setting(c, self.cid, k, v)
        return st.load(c, self.cid)

    def at(self, minutes: float) -> None:
        util.freeze(NOON + dt.timedelta(minutes=minutes))


# ================================================================================================ phone numbers
class Phones(unittest.TestCase):
    def test_every_way_of_writing_a_mobile_becomes_one_number(self):
        for raw in ("0555123456", "555123456", "+966555123456", "00966555123456", "966555123456", "+966 55 512 3456", "055-512-3456",
                    "٠٥٥٥١٢٣٤٥٦", 555123456, 555123456.0, "5.55123456E+8", " 0555 123 456 ", "+9660555123456"):
            p = phones.normalize_phone(raw)
            self.assertEqual((p.phone, p.kind), ("+966555123456", "mobile"), raw)

    def test_other_kinds_and_rejects(self):
        self.assertEqual(phones.normalize_phone("0112345678"), phones.Phone("+966112345678", "landline", ""))
        self.assertEqual(phones.normalize_phone("920012345").kind, "unified")
        self.assertEqual(phones.normalize_phone("+971501234567").kind, "foreign")
        for bad in ("", None, "   ", "abc", "05551", "055512345678", "0455123456", "+12", "رقم", "٠٠٠"):
            p = phones.normalize_phone(bad)
            self.assertEqual((p.phone, p.kind), (None, "invalid"), bad)
            self.assertTrue(p.reason, f"an invalid number says why: {bad!r}")

    def test_cells_with_two_numbers_and_display(self):
        self.assertEqual(phones.split_numbers("0555123456 / 0566123456"), ["0555123456", "0566123456"])
        self.assertEqual(phones.split_numbers("0555123456،0566123456؛0577123456"), ["0555123456", "0566123456", "0577123456"])
        self.assertEqual(phones.split_numbers("0555123456"), ["0555123456"])
        self.assertEqual(phones.display("+966555123456"), "0555123456")
        self.assertEqual(phones.display(None), "")
        self.assertEqual(phones.wa_digits("+966555123456"), "966555123456")


# ================================================================================================ follow-up ladders
class Zones(unittest.TestCase):
    """The slim container image may have no time-zone database: Riyadh time must still work, and the settings form must still accept it."""

    def test_names_are_checked_with_a_tz_database(self):
        self.assertTrue(util.tz_known("Asia/Riyadh"))
        self.assertTrue(util.tz_known("Europe/London"))
        self.assertFalse(util.tz_known("Mars/Base"))
        self.assertFalse(util.tz_known("../../etc/passwd"))
        self.assertFalse(util.tz_known(""))

    def test_without_a_tz_database_riyadh_time_still_works(self):
        with mock.patch("zoneinfo.ZoneInfo", side_effect=KeyError("no tzdata")):
            self.assertTrue(util.tz_known("Asia/Riyadh"), "the form must accept the default zone")
            self.assertTrue(util.tz_known("Asia/Dubai"))
            self.assertFalse(util.tz_known("Mars/Base"))
            self.assertEqual(util.local_hm("2026-11-03T21:30:00.000Z", "Asia/Riyadh"), "00:30")
            self.assertEqual(util.local_date("2026-11-03T21:30:00.000Z", "Asia/Riyadh"), "2026-11-04", "the day rolls over at midnight Riyadh time")
            self.assertEqual(util.local_hm("2026-11-03T21:30:00.000Z", "Asia/Dubai"), "01:30")


class Ladders(unittest.TestCase):
    S = {k: v[0] for k, v in st.DEFS.items()}
    TODAY = "2026-11-03"

    def after(self, outcome, prev_status="new", prev_step=0, **over):
        return leadlib.after_outcome({**self.S, **over}, outcome, prev_status, prev_step, self.TODAY)

    def test_no_answer_walks_the_ladder_then_stops(self):
        n = self.after("no_answer")
        self.assertEqual((n.status, n.step, n.date), ("no_answer", 1, "2026-11-04"))
        n = self.after("no_answer", "no_answer", 1)
        self.assertEqual((n.step, n.date), (2, "2026-11-05"))
        n = self.after("no_answer", "no_answer", 2)
        self.assertEqual((n.step, n.date), (3, "2026-11-07"))
        n = self.after("no_answer", "no_answer", 3)
        self.assertEqual((n.status, n.date), ("exhausted", None), "after the last step the lead stops coming back and the manager sees it")

    def test_phone_off_continues_the_same_run_unless_it_has_its_own_ladder(self):
        n = self.after("phone_off", "no_answer", 1)
        self.assertEqual((n.status, n.step, n.date), ("phone_off", 2, "2026-11-05"))
        n = self.after("phone_off", "new", 0, fu_phone_off="3,6")
        self.assertEqual(n.date, "2026-11-06")
        n = self.after("phone_off", "phone_off", 1, fu_phone_off="3,6")
        self.assertEqual(n.date, "2026-11-09")

    def test_interested_repeats_the_last_gap_while_the_plus_is_there(self):
        n = self.after("interested", "no_answer", 2)
        self.assertEqual((n.status, n.step, n.date), ("interested", 1, "2026-11-04"), "a different kind of result starts a new run")
        n = self.after("interested", "interested", 1)
        self.assertEqual((n.step, n.date), (2, "2026-11-05"))
        n = self.after("interested", "interested", 7)
        self.assertEqual((n.step, n.date), (8, "2026-11-05"), "1,2+ keeps asking every 2 days")

    def test_finished_outcomes_and_callbacks(self):
        for outcome, status in (("not_interested", "not_interested"), ("wrong_number", "wrong_number"), ("registered", "registered_reported")):
            n = self.after(outcome, "interested", 2)
            self.assertEqual((n.status, n.date), (status, None), outcome)
        n = leadlib.after_outcome(self.S, "call_later", "no_answer", 2, self.TODAY, "2026-11-10", "16:30")
        self.assertEqual((n.status, n.step, n.date, n.time), ("callback", 0, "2026-11-10", "16:30"))
        for outcome, status in (("asked_link", "link_sent"), ("visited", "visited")):
            n = self.after(outcome)
            self.assertEqual((n.status, n.step, n.date), (status, 1, "2026-11-04"), outcome)

    def test_days_text_is_parsed_strictly(self):
        self.assertEqual(st.parse_days("1,2,4"), ([1, 2, 4], False))
        self.assertEqual(st.parse_days("1,2+"), ([1, 2], True))
        self.assertEqual(st.parse_days(" 3 , x , 0 , 200 , 5 "), ([3, 5], False), "junk, zero and out-of-range values are dropped")
        self.assertEqual(st.parse_days("")[0], [])


# ================================================================================================ plan sizing and ownership
class Plans(Base):
    def test_capacity_follows_hours_and_minutes_per_call(self):
        with db.tx(True, self.path) as c:
            s = self.settings(c)
            a = self.user(c, "a")
            b = self.user(c, "b", shift_hours=4)
            self.assertEqual(plans.capacity(s, a), 120)
            self.assertEqual(plans.capacity(s, b), 60)
            self.assertEqual(plans.capacity({**s, "minutes_per_call": 0}, a), 960, "a zero is treated as half a minute, never a division by zero")
            self.assertEqual(plans.capacity(s, self.user(c, "z", shift_hours=0)), 120, "no personal hours set: the company's hours apply")
            self.assertEqual(plans.capacity({**s, "shift_hours": 0.01}, a), 1, "a plan is never empty because of a tiny shift")

    def test_followups_come_first_in_priority_order_and_new_numbers_fill_the_rest(self):
        with db.tx(True, self.path) as c:
            s = self.settings(c, daily_new=5)
            u = self.user(c, "sara")
            today, yesterday = "2026-11-03", "2026-11-02"
            self.leads(c, 1, start=1, owner=u["id"], status="no_answer", due=today)          # plain follow-up
            self.leads(c, 1, start=2, owner=u["id"], status="interested", due=today)         # interested
            self.leads(c, 1, start=3, owner=u["id"], status="callback", due=today)           # promised callback
            self.leads(c, 1, start=4, owner=u["id"], status="no_answer", due=yesterday)      # overdue
            self.leads(c, 1, start=5, owner=u["id"], status="link_sent", due=today)          # did he register after the link?
            self.leads(c, 1, start=6, owner=u["id"], status="no_answer", due="2026-11-09")   # not yet
            self.leads(c, 8, start=10)                                                       # the pool
            sid = c.execute("INSERT INTO shifts(company_id,user_id,work_date,started_at,planned_end_at,last_seen_at,last_action_at) VALUES(?,?,?,?,?,?,?)",
                            (self.cid, u["id"], today, util.now_iso(), util.now_iso(), util.now_iso(), util.now_iso())).lastrowid
            info = plans.build_plan(c, u, sid, s, today)
            self.assertEqual((info["followups"], info["new"], info["trimmed"], info["short"]), (5, 5, False, 0))
            kinds = [t["kind"] for t in plans.tasks_for(c, info["plan_id"])]
            self.assertEqual(kinds, ["overdue", "callback", "interested", "link_check", "followup", "new", "new", "new", "new", "new"])

    def test_a_full_day_of_followups_trims_the_new_numbers_and_tells_the_manager(self):
        with db.tx(True, self.path) as c:
            s = self.settings(c, shift_hours=1, minutes_per_call=6, daily_new=20)   # room for 10 calls
            u = self.user(c, "sara")
            self.leads(c, 4, owner=u["id"], status="no_answer", due="2026-11-03")
            self.leads(c, 30, start=100)
            sid = c.execute("INSERT INTO shifts(company_id,user_id,work_date,started_at,planned_end_at,last_seen_at,last_action_at) VALUES(?,?,?,?,?,?,?)",
                            (self.cid, u["id"], "2026-11-03", util.now_iso(), util.now_iso(), util.now_iso(), util.now_iso())).lastrowid
            info = plans.build_plan(c, u, sid, s, "2026-11-03")
            self.assertEqual((info["capacity"], info["followups"], info["new"], info["trimmed"]), (10, 4, 6, True))
            self.assertEqual(db.scalar(c, "SELECT COUNT(*) FROM notices WHERE kind='plan_trimmed'"), 1)

    def test_pool_runs_out_and_the_shortage_is_recorded(self):
        with db.tx(True, self.path) as c:
            s = self.settings(c, daily_new=10)
            a, b = self.user(c, "a"), self.user(c, "b")
            self.leads(c, 14)
            ids = []
            for u in (a, b):
                sid = c.execute("INSERT INTO shifts(company_id,user_id,work_date,started_at,planned_end_at,last_seen_at,last_action_at) VALUES(?,?,?,?,?,?,?)",
                                (self.cid, u["id"], "2026-11-03", util.now_iso(), util.now_iso(), util.now_iso(), util.now_iso())).lastrowid
                ids.append(plans.build_plan(c, u, sid, s, "2026-11-03"))
            self.assertEqual([i["new"] for i in ids], [10, 4])
            self.assertEqual([i["short"] for i in ids], [0, 6])
            mine = lambda uid: {r["lead_id"] for r in c.execute("SELECT lead_id FROM tasks WHERE user_id=?", (uid,))}  # noqa: E731
            self.assertFalse(mine(a["id"]) & mine(b["id"]), "no number is ever given to two people")
            self.assertEqual(db.scalar(c, "SELECT COUNT(*) FROM notices WHERE kind='pool_short'"), 1)

    def test_landlines_dnc_and_other_companies_stay_out_of_the_pool(self):
        with db.tx(True, self.path) as c:
            u = self.user(c, "sara")
            self.leads(c, 3)
            self.leads(c, 2, start=50, landline=True)
            dnc = self.leads(c, 1, start=70)[0]
            c.execute("UPDATE leads SET do_not_call=1 WHERE id=?", (dnc,))
            other = db.create_company(c, "شركة أخرى")
            c.execute("INSERT INTO leads(company_id,name,phone,added_at) VALUES(?,?,?,?)", (other, "غريب", "+966555999999", util.now_iso()))
            self.assertEqual(leadlib.pool_count(c, self.cid, allow_landline=False), 3)
            self.assertEqual(leadlib.pool_count(c, self.cid, allow_landline=True), 5)
            got = plans.pull_pool(c, self.cid, u["id"], 99, allow_landline=False)
            self.assertEqual(len(got), 3)
            self.assertEqual(db.scalar(c, "SELECT owner_id FROM leads WHERE company_id=?", other), None, "another company's numbers are never touched")

    def test_two_processes_pulling_at_the_same_moment_never_share_a_number(self):
        with db.tx(True, self.path) as c:
            self.settings(c, daily_new=30)
            for name in ("a", "b", "c"):
                self.user(c, name)
            self.leads(c, 50)
        go_at = time.time() + 2.0
        code = textwrap.dedent(f"""
            import sys, time
            sys.path.insert(0, {str(ROOT)!r})
            from minjaz import db, settings as st, work
            name = sys.argv[1]
            while time.time() < {go_at}: pass
            with db.tx(True, {str(self.path)!r}) as c:
                u = db.one(c, "SELECT * FROM users WHERE username=?", name)
                s = st.load(c, u["company_id"])
                print(work.start_day(c, u, s)[0])
        """)
        procs = [subprocess.Popen([sys.executable, "-c", code, n], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) for n in ("a", "b", "c")]
        outs = [p.communicate(timeout=60) for p in procs]
        for out, err in outs:
            self.assertEqual(out.strip(), "True", err)
        con = sqlite3.connect(str(self.path))
        rows = con.execute("SELECT lead_id, COUNT(*) FROM tasks GROUP BY lead_id HAVING COUNT(*)>1").fetchall()
        self.assertEqual(rows, [], "a number appeared in two plans")
        self.assertEqual(con.execute("SELECT COUNT(*) FROM leads WHERE owner_id IS NOT NULL").fetchone()[0], 50, "all 50 handed out, none twice")
        con.close()


# ================================================================================================ the working day
class Day(Base):
    def start(self, c, **over):
        s = self.settings(c, **over)
        u = self.user(c, "sara", name="سارة")
        self.leads(c, 6)
        ok, msg, shift_id = work.start_day(c, u, s)
        self.assertTrue(ok, msg)
        return s, u, db.one(c, "SELECT * FROM shifts WHERE id=?", shift_id)

    def test_idle_gap_is_asked_once_and_answered(self):
        with db.tx(True, self.path) as c:
            s, u, sh = self.start(c)
        self.at(9)
        with db.tx(True, self.path) as c:
            self.assertIsNone(work.check_gap(c, u, db.one(c, "SELECT * FROM shifts WHERE id=?", sh["id"]), s), "nine quiet minutes are fine")
        self.at(11)
        with db.tx(True, self.path) as c:
            row = db.one(c, "SELECT * FROM shifts WHERE id=?", sh["id"])
            g = work.check_gap(c, u, row, s)
            self.assertIsNotNone(g)
            self.assertEqual(g["kind"], "away", "the page was not even open")
            again = work.check_gap(c, u, row, s)
            self.assertEqual(again["id"], g["id"])
            self.assertEqual(db.scalar(c, "SELECT COUNT(*) FROM events WHERE type='gap.detected'"), 1, "asking twice records one gap")
            self.assertFalse(work.answer_gap(c, u, row, g["id"], "nonsense", "")[0])
            self.assertFalse(work.answer_gap(c, u, row, g["id"], "other", "ab")[0], "'other' needs a few words")
            self.assertTrue(work.answer_gap(c, u, row, g["id"], "tech", "")[0])
            self.assertIsNone(work.pending_gap(c, sh["id"]))
            self.assertIsNone(work.check_gap(c, u, db.one(c, "SELECT * FROM shifts WHERE id=?", sh["id"]), s), "answering restarts the clock")

    def test_open_page_but_no_action_is_inactive_not_away_and_a_break_is_never_a_gap(self):
        with db.tx(True, self.path) as c:
            s, u, sh = self.start(c)
        self.at(8)
        with db.tx(True, self.path) as c:
            work.touch_seen(c, sh["id"])           # the page pinged: still open
        self.at(12)
        with db.tx(True, self.path) as c:
            g = work.check_gap(c, u, db.one(c, "SELECT * FROM shifts WHERE id=?", sh["id"]), s)
            self.assertEqual(g["kind"], "inactive")
            c.execute("UPDATE gaps SET status='explained', reason_code='break' WHERE id=?", (g["id"],))
            work.start_break(c, u, db.one(c, "SELECT * FROM shifts WHERE id=?", sh["id"]))
        self.at(120)
        with db.tx(True, self.path) as c:
            self.assertIsNone(work.check_gap(c, u, db.one(c, "SELECT * FROM shifts WHERE id=?", sh["id"]), s))

    def test_closing_needs_every_task_answered_and_no_pending_gap(self):
        with db.tx(True, self.path) as c:
            s, u, sh = self.start(c)
            ok, msg = work.close_day(c, u, sh, s, {})
            self.assertFalse(ok)
            self.assertIn("سببًا", msg)
            tasks = [t["id"] for t in plans.tasks_for(c, plans.plan_for(c, u["id"], sh["work_date"])["id"])]
            self.assertFalse(work.close_day(c, u, sh, s, {tasks[0]: ("no_time", "")})[0], "one task answered, five left")
            reasons = {t: ("no_time", "") for t in tasks}
            self.assertFalse(work.close_day(c, u, sh, s, {**reasons, tasks[0]: ("other", "x")})[0], "'other' needs an explanation")
            ok, msg = work.close_day(c, u, sh, s, reasons)
            self.assertTrue(ok, msg)
            self.assertEqual(db.scalar(c, "SELECT status FROM shifts WHERE id=?", sh["id"]), "closed")
            sealed = reports.latest_sealed(c, self.cid, u["id"], sh["work_date"])
            self.assertEqual(sealed["version"], 1)
            self.assertTrue(reports.verify_report(c, sealed)["ok"])
            self.assertFalse(work.start_day(c, u, s)[0], "one working day per date")

    def test_a_forgotten_day_is_closed_by_the_clock_and_the_manager_is_told(self):
        with db.tx(True, self.path) as c:
            s, u, sh = self.start(c)   # 8h of work + 60 min of break: planned end 9h later; then 2h of grace
            self.assertEqual(db.scalar(c, "SELECT planned_end_at FROM shifts WHERE id=?", sh["id"]), util.iso(NOON + dt.timedelta(hours=9)))
        self.at(60 * 10 + 59)
        with db.tx(True, self.path) as c:
            self.assertEqual(work.auto_close_due(c), 0, "still inside the grace period")
        self.at(60 * 11)
        with db.tx(True, self.path) as c:
            self.assertEqual(work.auto_close_due(c), 1)
            self.assertEqual(work.auto_close_due(c), 0, "only once")
            row = db.one(c, "SELECT * FROM shifts WHERE id=?", sh["id"])
            self.assertEqual(row["status"], "auto_closed")
            self.assertEqual(db.scalar(c, "SELECT COUNT(*) FROM notices WHERE kind='auto_closed'"), 1)
            self.assertEqual(reports.latest_sealed(c, self.cid, u["id"], sh["work_date"])["reason"], "close")
            self.assertEqual(db.scalar(c, "SELECT COUNT(*) FROM tasks WHERE status='open'"), 6, "open tasks stay open: nobody is blamed for answers never given")

    def test_calling_is_locked_outside_the_allowed_hours(self):
        with db.tx(True, self.path) as c:
            s, u, sh = self.start(c)
            lead = db.scalar(c, "SELECT id FROM leads WHERE owner_id=? LIMIT 1", u["id"])
            self.assertTrue(work.start_call(c, u, s, lead)[0])
        util.freeze(dt.datetime(2026, 11, 3, 6, 30, tzinfo=UTC))   # 09:30 Riyadh: open
        self.assertTrue(work.in_call_hours(s)[0])
        util.freeze(dt.datetime(2026, 11, 3, 5, 59, tzinfo=UTC))   # 08:59: closed
        ok, msg = work.in_call_hours(s)
        self.assertFalse(ok)
        self.assertIn("09:00", msg)
        util.freeze(dt.datetime(2026, 11, 3, 19, 1, tzinfo=UTC))   # 22:01: closed
        self.assertFalse(work.in_call_hours(s)[0])
        self.assertTrue(work.in_call_hours({**s, "lock_call_hours": 0})[0], "the lock can be switched off")
        ramadan = {**s, "ramadan": 1}
        util.freeze(dt.datetime(2026, 11, 3, 21, 30, tzinfo=UTC))  # 00:30 Riyadh: only open in Ramadan mode (12:00 to 01:00)
        self.assertTrue(work.in_call_hours(ramadan)[0])
        self.assertFalse(work.in_call_hours(s)[0])

    def test_lateness_counts_only_after_the_grace_period(self):
        s = {**{k: v[0] for k, v in st.DEFS.items()}, "start_time": "09:00", "start_grace_min": 15}
        self.assertEqual(work.late_minutes(s, dt.datetime(2026, 11, 3, 6, 14, tzinfo=UTC)), 0)    # 09:14
        self.assertEqual(work.late_minutes(s, dt.datetime(2026, 11, 3, 6, 45, tzinfo=UTC)), 30)   # 09:45
        self.assertEqual(work.late_minutes({**s, "start_time": ""}, NOON), 0)


# ================================================================================================ sign-in and sessions
class Auth(Base):
    def test_five_wrong_passwords_lock_the_account_for_ten_minutes(self):
        with db.tx(True, self.path) as c:
            self.user(c, "sara")
        def attempt(password):
            with db.tx(False, self.path) as c:
                u = security.find_user(c, "sara")
            result = security.check_login(u, password)
            with db.tx(True, self.path) as c:
                token = security.record_login(c, security.find_user(c, "sara"), result, "1.2.3.4", "test")
            return result, token
        for i in range(4):
            self.assertEqual(attempt("wrong-password-1")[0], "bad", i)
        self.assertEqual(attempt("wrong-password-1")[0], "bad")            # the fifth failure sets the lock
        result, token = attempt("Test-pass-2026")
        self.assertEqual((result, token), ("locked", None), "even the right password is refused while locked")
        self.at(9)
        self.assertEqual(attempt("Test-pass-2026")[0], "locked")
        self.at(10.5)
        result, token = attempt("Test-pass-2026")
        self.assertEqual(result, "")
        self.assertTrue(token)
        with db.tx(False, self.path) as c:
            self.assertEqual(security.find_user(c, "sara")["failed_logins"], 0, "a good sign-in clears the count")
            self.assertEqual(db.scalar(c, "SELECT COUNT(*) FROM events WHERE type='auth.locked'"), 1)

    def test_unknown_and_stopped_accounts_are_refused_the_same_slow_way(self):
        self.assertEqual(security.check_login(None, "whatever-1234"), "bad")
        with db.tx(True, self.path) as c:
            u = self.user(c, "gone", active=0)
        self.assertEqual(security.check_login(u, "Test-pass-2026"), "inactive")

    def test_session_idle_and_absolute_expiry(self):
        with db.tx(True, self.path) as c:
            u = self.user(c, "sara")
            raw = security.create_session(c, u, "1.2.3.4", "ua")
            self.assertIsNotNone(security.load_ctx(c, raw))
            self.assertIsNone(security.load_ctx(c, raw + "x"))
        self.at(60 * 11)
        with db.tx(True, self.path) as c:
            ctx = security.load_ctx(c, raw)
            self.assertIsNotNone(ctx, "eleven idle hours: still in")
            self.assertTrue(security.session_is_stale(ctx))
            security.touch_session(c, ctx.session["id"])
        self.at(60 * 22)
        with db.tx(True, self.path) as c:
            self.assertIsNotNone(security.load_ctx(c, raw), "the touch moved the idle limit")
        self.at(60 * 22 + 60 * 13)
        with db.tx(True, self.path) as c:
            self.assertIsNone(security.load_ctx(c, raw), "thirteen idle hours: out")
            self.assertEqual(security.purge_sessions(c), 1)
        # absolute limit: someone who opens the page every 8 hours never hits the idle limit, yet is signed out 14 days after signing in
        util.freeze(NOON)
        with db.tx(True, self.path) as c:
            raw = security.create_session(c, self.user(c, "khaled"), "1.2.3.4", "ua")
        for step in range(1, 43):                                        # 42 visits x 8 h = exactly 14 days
            util.freeze(NOON + dt.timedelta(hours=8 * step))
            with db.tx(True, self.path) as c:
                ctx = security.load_ctx(c, raw)
                self.assertIsNotNone(ctx, f"visit {step}: busy, and still inside 14 days")
                security.touch_session(c, ctx.session["id"])
        util.freeze(NOON + dt.timedelta(days=14, hours=8))
        with db.tx(True, self.path) as c:
            self.assertIsNone(security.load_ctx(c, raw), "past 14 days the session ends however recently it was used")

    def test_stopping_an_account_or_company_ends_its_sessions_at_once(self):
        with db.tx(True, self.path) as c:
            u = self.user(c, "sara")
            raw = security.create_session(c, u, "1.2.3.4", "ua")
            c.execute("UPDATE users SET active=0 WHERE id=?", (u["id"],))
            self.assertIsNone(security.load_ctx(c, raw))
            c.execute("UPDATE users SET active=1 WHERE id=?", (u["id"],))
            self.assertIsNotNone(security.load_ctx(c, raw))
            c.execute("UPDATE companies SET active=0 WHERE id=?", (self.cid,))
            self.assertIsNone(security.load_ctx(c, raw))

    def test_throttle_window(self):
        lim = security.Limiter()
        self.assertTrue(all(lim.allow("k", 3, 60) for _ in range(3)))
        self.assertFalse(lim.allow("k", 3, 60))
        self.assertTrue(lim.allow("other", 3, 60))
        self.assertTrue(lim.allow("peek", 1, 60, record=False))
        self.assertTrue(lim.allow("peek", 1, 60, record=False), "peeking does not use up an attempt")

    def test_password_and_username_rules(self):
        for bad in ("short1", "12345678", "aaaaaaaa", "x" * 201, ""):
            self.assertTrue(security.password_problem(bad, "sara"), bad)
        self.assertEqual(security.password_problem("Owner-pass-2026", "sara"), "")
        self.assertTrue(security.password_problem("SaraSara", "sarasara"), "the password may not be the username in other letter case")
        for bad in ("ab", "with space", "عربي", "-start", "x" * 33):
            self.assertTrue(security.username_problem(bad), bad)
        for good in ("sara", "sara.k_2", "A-1"):
            self.assertEqual(security.username_problem(good), "", good)
        self.assertTrue(security.verify_password("Owner-pass-2026", security.hash_password("Owner-pass-2026")))
        self.assertFalse(security.verify_password("Owner-pass-2027", security.hash_password("Owner-pass-2026")))
        self.assertNotEqual(security.hash_password("x" * 12), security.hash_password("x" * 12), "every hash has its own salt")


# ================================================================================================ the record cannot be rewritten quietly
class Tamper(Base):
    def a_day(self, c):
        s = self.settings(c)
        u = self.user(c, "sara")
        ids = self.leads(c, 4)
        ok, msg, shift_id = work.start_day(c, u, s)
        self.assertTrue(ok, msg)
        shift = db.one(c, "SELECT * FROM shifts WHERE id=?", shift_id)
        for lead in ids[:2]:
            self.assertTrue(work.start_call(c, u, s, lead)[0])
            ok, msg, _ = work.record_outcome(c, u, s, lead, "no_answer", "", "", "", False)
            self.assertTrue(ok, msg)
        tasks = [t["id"] for t in plans.tasks_for(c, plans.plan_for(c, u["id"], shift["work_date"])["id"], status="open")]
        ok, msg = work.close_day(c, u, shift, s, {t: ("no_time", "") for t in tasks})
        self.assertTrue(ok, msg)
        return u, shift

    def test_history_refuses_edits_and_deletes(self):
        with db.tx(True, self.path) as c:
            u, shift = self.a_day(c)
        con = sqlite3.connect(str(self.path), isolation_level=None)
        for sql in ("UPDATE events SET data='{}' WHERE seq=1", "DELETE FROM events WHERE seq=1", "UPDATE daily_reports SET data='{}'", "DELETE FROM daily_reports"):
            with self.assertRaises(sqlite3.DatabaseError, msg=sql):
                con.execute(sql)
        con.close()

    def test_someone_with_the_file_who_edits_an_event_is_caught_at_that_event(self):
        with db.tx(True, self.path) as c:
            self.a_day(c)
            self.assertTrue(db.verify_chain(c, self.cid)["ok"])
            total = db.scalar(c, "SELECT COUNT(*) FROM events")
        con = sqlite3.connect(str(self.path), isolation_level=None)
        con.execute("DROP TRIGGER events_no_update")    # what a person with direct access to the file could do
        con.execute("UPDATE events SET data='{\"changed\":1}' WHERE seq=3")
        con.close()
        with db.tx(False, self.path) as c:
            r = db.verify_chain(c, self.cid)
            self.assertFalse(r["ok"])
            self.assertEqual(r.get("bad_seq"), 3)
        self.assertGreater(total, 5)

    def test_a_removed_event_breaks_the_chain(self):
        with db.tx(True, self.path) as c:
            self.a_day(c)
        con = sqlite3.connect(str(self.path), isolation_level=None)
        con.execute("DROP TRIGGER events_no_delete")
        con.execute("DELETE FROM events WHERE seq=4")
        con.close()
        with db.tx(False, self.path) as c:
            self.assertFalse(db.verify_chain(c, self.cid)["ok"])

    def test_a_sealed_report_that_is_rewritten_no_longer_verifies(self):
        with db.tx(True, self.path) as c:
            u, shift = self.a_day(c)
            row = reports.latest_sealed(c, self.cid, u["id"], shift["work_date"])
            self.assertEqual(reports.verify_report(c, row), {"seal_ok": True, "anchored": True, "ok": True})
        con = sqlite3.connect(str(self.path), isolation_level=None)
        con.execute("DROP TRIGGER reports_no_update")
        con.execute("UPDATE daily_reports SET data=data||' '")
        con.close()
        with db.tx(False, self.path) as c:
            row = reports.latest_sealed(c, self.cid, u["id"], shift["work_date"])
            v = reports.verify_report(c, row)
            self.assertFalse(v["seal_ok"])
            self.assertFalse(v["ok"])

    def test_two_companies_have_two_independent_chains(self):
        with db.tx(True, self.path) as c:
            other = db.create_company(c, "شركة ثانية")
            db.emit(c, self.cid, "x.test", data={"n": 1})
            db.emit(c, other, "x.test", data={"n": 1})
            db.emit(c, self.cid, "x.test", data={"n": 2})
            self.assertEqual(db.scalar(c, "SELECT MAX(seq) FROM events WHERE company_id=?", self.cid), 2)
            self.assertEqual(db.scalar(c, "SELECT MAX(seq) FROM events WHERE company_id=?", other), 1)
            self.assertTrue(db.verify_chain(c, self.cid)["ok"] and db.verify_chain(c, other)["ok"])

# ================================================================================================ reading Excel and CSV files
def _col(i: int) -> str:
    out, i = "", i + 1
    while i:
        i, r = divmod(i - 1, 26)
        out = chr(65 + r) + out
    return out


def make_xlsx(rows, *, shared: bool = True, workbook: bool = True, sheet_head: str = "") -> bytes:
    """A small but genuine .xlsx. A cell is text, a number, ('n', 'raw numeric text') or None for an empty one."""
    strings: list[str] = []
    xml_rows = []
    for r_i, row in enumerate(rows, start=1):
        cells = []
        for c_i, v in enumerate(row):
            if v is None:
                continue
            ref = f"{_col(c_i)}{r_i}"
            if isinstance(v, tuple):
                cells.append(f'<c r="{ref}"><v>{v[1]}</v></c>')
            elif isinstance(v, (int, float)):
                cells.append(f'<c r="{ref}"><v>{v}</v></c>')
            elif shared:
                strings.append(v)
                cells.append(f'<c r="{ref}" t="s"><v>{len(strings) - 1}</v></c>')
            else:
                cells.append(f'<c r="{ref}" t="inlineStr"><is><t>{escape(v)}</t></is></c>')
        xml_rows.append(f'<row r="{r_i}">{"".join(cells)}</row>')
    main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"/>')
        if workbook:
            z.writestr("xl/workbook.xml", f'<?xml version="1.0"?><workbook xmlns="{main}" xmlns:r="{rel}"><sheets><sheet name="Data" sheetId="1" r:id="rId9"/></sheets></workbook>')
            z.writestr("xl/_rels/workbook.xml.rels", f'<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                                                      f'<Relationship Id="rId9" Type="{rel}/worksheet" Target="worksheets/sheet1.xml"/></Relationships>')
        z.writestr("xl/worksheets/sheet1.xml", f'<?xml version="1.0"?>{sheet_head}<worksheet xmlns="{main}"><sheetData>{"".join(xml_rows)}</sheetData></worksheet>')
        if strings:
            z.writestr("xl/sharedStrings.xml", f'<?xml version="1.0"?><sst xmlns="{main}">' + "".join(f"<si><t>{escape(t)}</t></si>" for t in strings) + "</sst>")
    return buf.getvalue()


class Files(unittest.TestCase):
    def test_excel_cells_come_out_as_the_text_a_person_would_see(self):
        raw = make_xlsx([["الاسم", "الجوال"],
                         ["أحمد", 555123456],                          # Excel drops the leading zero of a number
                         ["سالم", ("n", "5.66123456E+8")],             # and sometimes writes it in scientific form
                         ["ماجد", "0577123456"],
                         [None, None],                                 # an empty row is skipped
                         [None, "0588123456"]])                        # a number with no name, first column empty
        rows = importer.read_xlsx(raw, 100)
        self.assertEqual([r for _, r in rows], [["الاسم", "الجوال"], ["أحمد", "555123456"], ["سالم", "566123456"], ["ماجد", "0577123456"], ["", "0588123456"]])
        self.assertEqual([n for n, _ in rows], [1, 2, 3, 4, 6], "the row numbers are the ones Excel shows, so the manager can find them")
        self.assertEqual(importer.read_xlsx(make_xlsx([["a", "b"], ["c", "d"]], shared=False), 10)[1][1], ["c", "d"], "inline strings read too")
        self.assertEqual(importer.read_xlsx(make_xlsx([["x", "y"]], workbook=False), 10)[0][1], ["x", "y"], "no workbook part: the first sheet file is used")

    def test_files_that_cannot_be_read_say_so_in_plain_arabic(self):
        for name, raw, part in (("a.xlsx", b"not a zip at all", "Excel"), ("a.xls", b"\xd0\xcf\x11\xe0", "xls"), ("a.pdf", b"%PDF-1.4", "xlsx أو csv"),
                                ("a.csv", b"", "فارغ"), ("a.csv", b" \n\n ,, \n", "فارغ"), ("a.xlsx", make_xlsx([[None]]), "فارغ")):
            with self.assertRaises(importer.ImportProblem, msg=name) as cm:
                importer.read_rows(name, raw)
            self.assertIn(part, str(cm.exception), name)
        bomb = make_xlsx([["a"]], sheet_head='<!DOCTYPE lolz [<!ENTITY a "aaaa">]>')
        with self.assertRaises(importer.ImportProblem):
            importer.read_xlsx(bomb, 10)
        too_many = "\n".join(f"n{i},05551{i:05d}" for i in range(50)).encode()
        with self.assertRaises(importer.ImportProblem) as cm:
            importer.read_csv(too_many, 10)
        self.assertIn("أكبر", str(cm.exception))
        self.assertEqual(len(importer.read_rows("many.csv", too_many, 100)), 50)
        self.assertEqual(importer.read_rows("x", make_xlsx([["a", "b"]]))[0][1], ["a", "b"], "no extension but a zip: read as Excel")

    def test_csv_in_the_ways_arabic_offices_save_it(self):
        want = [["الاسم", "الجوال"], ["أحمد، العتيبي", "0555123456"]]
        text = "الاسم,الجوال\n\"أحمد، العتيبي\",0555123456\n"
        for label, raw in (("utf-8 with BOM", text.encode("utf-8-sig")), ("plain utf-8", text.encode("utf-8")), ("windows-1256", text.encode("cp1256")),
                           ("utf-16", text.encode("utf-16")), ("semicolons", text.replace(",", ";").replace("أحمد؛", "أحمد،").encode("utf-8-sig")),
                           ("tabs", text.replace(",0555", "\t0555").replace("الاسم,", "الاسم\t").replace("\"", "").encode("utf-8-sig"))):
            got = [r for _, r in importer.read_csv(raw, 100)]
            self.assertEqual(got[0], want[0], label)
            self.assertEqual(got[1][1], "0555123456", label)
            self.assertIn("أحمد", got[1][0], label)
        self.assertEqual([r for _, r in importer.read_csv("a,b,,\n,,,\nc,d,e,\n".encode(), 10)], [["a", "b"], ["c", "d", "e"]], "empty trailing cells and rows are dropped")

    def test_columns_are_found_by_their_titles_or_by_what_is_in_them(self):
        arabic = [(1, ["اسم المالك", "رقم الجوال", "رقم جوال ثاني", "المدينة", "رابط الإعلان", "الموظف"]), (2, ["أحمد", "0555123456", "0566123456", "جدة", "https://x.test/1", "sara"])]
        m = importer.guess_mapping(arabic, importer.looks_like_header(arabic[0][1]))
        self.assertEqual(m, {"name": 0, "phone": 1, "phone2": 2, "city": 3, "url": 4, "employee": 5})
        english = [(1, ["Full Name", "Mobile", "Alt Phone", "City"]), (2, ["Ahmed", "0555123456", "", "Jeddah"])]
        self.assertEqual(importer.guess_mapping(english, True), {"name": 0, "phone": 1, "phone2": 2, "city": 3, "url": None, "employee": None})
        shuffled = [(1, ["جوال 2", "الجوال"]), (2, ["0566123456", "0555123456"])]
        m = importer.guess_mapping(shuffled, True)
        self.assertEqual((m["phone"], m["phone2"]), (1, 0), "'second mobile' is never mistaken for the main number")
        bare = [(1, ["أحمد", "0555123456", "جدة"]), (2, ["سالم", "0566123456", "الرياض"]), (3, ["ماجد", "0577123456", "مكة"])]
        self.assertFalse(importer.looks_like_header(bare[0][1]), "a first row holding a phone number is data, not titles")
        m = importer.guess_mapping(bare, False)
        self.assertEqual((m["phone"], m["name"]), (1, 0), "no titles at all: the column full of phone numbers is the phone")
        self.assertIsNone(importer.guess_mapping([(1, ["x", "y"]), (2, ["a", "b"])], True)["phone"], "nothing looks like a phone: the manager picks")


# ================================================================================================ checking rows before saving them
class Importing(Base):
    def prepare(self, c):
        s = self.settings(c)
        self.sara = self.user(c, "sara", name="سارة")
        self.owner = self.user(c, "boss", role="manager")
        now = util.now_iso()
        def put(name, phone, city="", alt=None):
            return c.execute("INSERT INTO leads(company_id,name,phone,phone_alt,city,added_at) VALUES(?,?,?,?,?,?)", (self.cid, name, phone, alt, city or None, now)).lastrowid
        self.l_ahmed = put("أحمد", "+966555000001", "جدة", alt="+966555000002")
        self.l_salem = put("سالم", "+966555000003", "الرياض")
        return s

    def batch(self, c, status="preview"):
        return c.execute("INSERT INTO lead_batches(company_id,filename,sha256,uploaded_by,uploaded_at,status) VALUES(?,?,?,?,?,?)",
                         (self.cid, "owners.csv", "ab" * 32, self.owner["id"], util.now_iso(), status)).lastrowid

    FILE = (
        "الاسم,الجوال,جوال ثاني,المدينة,الموظف\n"
        "فهد,0555000010,,جدة,sara\n"                 # 2  new, goes straight to sara
        "فهد مكرر,555000010,,,\n"                      # 3  the same number twice in the file
        "أحمد,0555000001,,,\n"                         # 4  already a client
        "أحمد ثاني,0555000002,,,\n"                    # 5  already a client: his second number
        "ناصر,0555000011,0555000012,,\n"               # 6  new, with a second number
        "ناصر ب,0555000012,,,\n"                       # 7  the same number twice: as row 6's second number
        "ماجد,0555000020,0555000003,,\n"               # 8  new, but his second number is Salem's
        "سالم,0555000030,,الرياض,\n"                   # 9  new, same name and city as a client: maybe the same place
        ",abc,,,\n"                                    # 10 not a number
        "خالد,0112345678,,,\n"                         # 11 a landline: kept, not planned
        "بدون رقم,,,,\n"                               # 12 no number at all
        "\n"                                           # 13 empty line
        "ريم,0555000040,,,ghost\n"                     # 14 new, but nobody is called ghost
        "ريم ب,0555000041,,,سارة\n"                    # 15 new, employee named by the name shown on screen
    )

    def run_file(self, c, s, text=None):
        rows = importer.read_rows("owners.csv", (text or self.FILE).encode("utf-8-sig"))
        has_header = importer.looks_like_header(rows[0][1])
        mapping = importer.guess_mapping(rows, has_header)
        bid = self.batch(c)
        return bid, importer.analyze(c, self.cid, bid, rows, mapping, has_header, s)

    def test_every_row_gets_one_verdict_and_nothing_is_saved_yet(self):
        with db.tx(True, self.path) as c:
            s = self.prepare(c)
            before = db.scalar(c, "SELECT COUNT(*) FROM leads")
            bid, n = self.run_file(c, s)
            self.assertEqual({k: n[k] for k in ("rows", "new", "dup_db", "dup_file", "invalid", "non_mobile", "maybe_same", "assigned", "unknown_staff")},
                             {"rows": 13, "new": 7, "dup_db": 2, "dup_file": 2, "invalid": 2, "non_mobile": 1, "maybe_same": 2, "assigned": 2, "unknown_staff": 1})
            self.assertEqual(n["unknown_names"], [("ghost", 1)])
            self.assertEqual(db.scalar(c, "SELECT COUNT(*) FROM leads"), before, "a preview saves nothing")
            verdict = {r["row_no"]: (r["state"], r["reason"] or "") for r in c.execute("SELECT * FROM import_rows WHERE batch_id=?", (bid,))}
            self.assertEqual(verdict[2][0], "new")
            self.assertEqual(verdict[3], ("dup_file", "مكرر في الصف 2 من الملف"))
            self.assertEqual(verdict[4][0], "dup_db")
            self.assertEqual(verdict[5][0], "dup_db", "his second number is a number we already have")
            self.assertIn("رقم ثانٍ", verdict[5][1])
            self.assertEqual(verdict[7], ("dup_file", "مكرر في الصف 6 من الملف"), "the same number twice in the file, once as a second number")
            self.assertEqual(verdict[8][0], "new")
            self.assertIn("الرقم الثاني", verdict[8][1])
            self.assertIn("نفس الاسم والمدينة", verdict[9][1])
            self.assertEqual(verdict[10][0], "invalid")
            self.assertTrue(verdict[10][1])
            self.assertIn("أرضي", verdict[11][1])
            self.assertEqual(verdict[12], ("invalid", "الخانة فارغة"))
            self.assertEqual(db.scalar(c, "SELECT maybe_same_id FROM import_rows WHERE batch_id=? AND row_no=8", bid), self.l_salem)
            self.assertEqual(db.scalar(c, "SELECT maybe_same_id FROM import_rows WHERE batch_id=? AND row_no=9", bid), self.l_salem)
            again = importer.analyze(c, self.cid, bid, importer.read_rows("o.csv", self.FILE.encode()), importer.guess_mapping(importer.read_rows("o.csv", self.FILE.encode()), True), True, s)
            self.assertEqual(again["new"], 7, "checking again replaces the old verdicts instead of adding to them")
            self.assertEqual(db.scalar(c, "SELECT COUNT(*) FROM import_rows WHERE batch_id=?", bid), 13)

    def test_saving_adds_only_the_new_rows_hands_numbers_to_named_employees_and_writes_the_record(self):
        with db.tx(True, self.path) as c:
            s = self.prepare(c)
            bid, _ = self.run_file(c, s)
            got = importer.commit(c, self.cid, bid, self.owner["id"], s)
            self.assertEqual(got, {"added": 7, "demoted": 0, "assigned": 2})
            self.assertEqual(db.scalar(c, "SELECT COUNT(*) FROM leads WHERE company_id=?", self.cid), 9)
            mine = {r["phone"] for r in c.execute("SELECT phone FROM leads WHERE owner_id=?", (self.sara["id"],))}
            self.assertEqual(mine, {"+966555000010", "+966555000041"})
            self.assertEqual(db.scalar(c, "SELECT COUNT(*) FROM assignments WHERE reason='import_column' AND user_id=?", self.sara["id"]), 2)
            landline = db.one(c, "SELECT * FROM leads WHERE phone='+966112345678'")
            self.assertEqual(landline["line_type"], "landline")
            self.assertEqual(leadlib.pool_count(c, self.cid, allow_landline=False), 6, "2 clients we had + 7 added, minus the 2 given to sara and the landline")
            self.assertEqual(db.one(c, "SELECT phone_alt FROM leads WHERE phone='+966555000011'")["phone_alt"], "+966555000012")
            ev = db.one(c, "SELECT * FROM events WHERE type='import.committed'")
            self.assertEqual(json.loads(ev["data"])["added"], 7)
            self.assertEqual(json.loads(ev["data"])["sha256"], "ab" * 32)
            self.assertEqual(db.scalar(c, "SELECT status FROM lead_batches WHERE id=?", bid), "committed")
            with self.assertRaises(importer.ImportProblem):
                importer.commit(c, self.cid, bid, self.owner["id"], s)
            self.assertEqual(db.scalar(c, "SELECT COUNT(*) FROM leads WHERE company_id=?", self.cid), 9, "pressing save twice cannot add the clients twice")
            csv_text = importer.rejected_csv(c, bid)
            self.assertTrue(csv_text.startswith("﻿"), "a BOM, so Excel opens the Arabic correctly")
            self.assertEqual(len(csv_text.strip().splitlines()), 1 + 6, "a header and the six rows that were not saved")

    def test_a_number_added_by_someone_else_between_preview_and_save_is_not_added_twice(self):
        with db.tx(True, self.path) as c:
            s = self.prepare(c)
            bid, _ = self.run_file(c, s)
            c.execute("INSERT INTO leads(company_id,name,phone,added_at) VALUES(?,?,?,?)", (self.cid, "سبقك", "+966555000010", util.now_iso()))
            got = importer.commit(c, self.cid, bid, self.owner["id"], s)
            self.assertEqual((got["added"], got["demoted"]), (6, 1))
            self.assertEqual(db.scalar(c, "SELECT state FROM import_rows WHERE batch_id=? AND row_no=2", bid), "dup_db")
            self.assertEqual(db.scalar(c, "SELECT COUNT(*) FROM leads WHERE phone='+966555000010'"), 1)

    def test_another_companys_clients_are_not_duplicates_of_ours(self):
        with db.tx(True, self.path) as c:
            s = self.prepare(c)
            other = db.create_company(c, "شركة أخرى")
            c.execute("INSERT INTO leads(company_id,name,phone,added_at) VALUES(?,?,?,?)", (other, "عند الجار", "+966555000010", util.now_iso()))
            bid, n = self.run_file(c, s)
            self.assertEqual(n["new"], 7, "the same number in another company is not our duplicate")
            importer.commit(c, self.cid, bid, self.owner["id"], s)
            self.assertEqual(db.scalar(c, "SELECT COUNT(*) FROM leads WHERE phone='+966555000010'"), 2)

    def test_landlines_enter_the_plans_when_the_company_allows_them(self):
        with db.tx(True, self.path) as c:
            s = self.prepare(c)
            s = self.settings(c, allow_landline=1)
            bid, n = self.run_file(c, s)
            self.assertEqual(n["non_mobile"], 0)
            importer.commit(c, self.cid, bid, self.owner["id"], s)
            self.assertEqual(leadlib.pool_count(c, self.cid, allow_landline=True), 7, "the landline is in the pool now")


# ================================================================================================ the platform's owners table
class Comparing(Base):
    TABLE = ("الاسم\tالجوال\tالإعلانات\tالموافقات\tالتسجيل\tالحالة\n"
             "أحمد العتيبي\t0555000001\t3\t2\t2026-11-02 14:30\tنشط\n"
             "سالم\t0555000002\t1\t0\t2026-11-01 09:05\tنشط\n")

    def test_dates_and_times_in_every_form_the_platform_or_a_phone_shows_them(self):
        for text, day in (("2026-11-02 14:30", "2026-11-02"), ("2026/11/02", "2026-11-02"), ("02-11-2026", "2026-11-02"), ("٠٢/١١/٢٠٢٦", "2026-11-02"),
                          ("2026-13-45", None), ("", None), ("نشط", None), ("3 إعلانات", None)):
            self.assertEqual(compare.parse_date(text), day, text)
        for text, hm in (("2026-11-02 14:30", "14:30"), ("9:05", "09:05"), ("9:05 PM", "21:05"), ("12:15 AM", "00:15"), ("12:30 pm", "12:30"), ("٠٩:٠٥ م", "21:05"),
                         ("٠٩:٠٥ ص", "09:05"), ("2026-11-02 14:30:59", "14:30"), ("25:00", None), ("10:75", None), ("2026-11-02", None), ("", None), ("نشط", None)):
            self.assertEqual(compare.parse_time(text), hm, text)

    def test_the_table_is_understood_however_it_was_copied(self):
        rows = compare.parse_owners(self.TABLE)
        self.assertEqual([(r["name"], r["phone"], r["ads"], r["approved"], r["reg_date"], r["reg_time"], r["problem"]) for r in rows],
                         [("أحمد العتيبي", "+966555000001", 3, 2, "2026-11-02", "14:30", ""), ("سالم", "+966555000002", 1, 0, "2026-11-01", "09:05", "")])
        arabic = compare.parse_owners("أحمد\t٠٥٥٥٠٠٠٠٠١\t٣\t٢\t٢٠٢٦-١١-٠٢ ١٤:٣٠\tنشط")
        self.assertEqual((arabic[0]["phone"], arabic[0]["ads"], arabic[0]["reg_date"], arabic[0]["reg_time"]), ("+966555000001", 3, "2026-11-02", "14:30"))
        piped = compare.parse_owners("أحمد | 0555000001 | 3 | 2 | 2026-11-02 14:30 | نشط")
        self.assertEqual((piped[0]["phone"], piped[0]["reg_time"]), ("+966555000001", "14:30"))
        spaced = compare.parse_owners("أحمد العتيبي    0555000001    3    2    2026-11-02 14:30    نشط")
        self.assertEqual((spaced[0]["name"], spaced[0]["reg_date"], spaced[0]["reg_time"]), ("أحمد العتيبي", "2026-11-02", "14:30"))
        split_cells = compare.parse_owners("أحمد 0555000001 3 2 2026-11-02 14:30 نشط")
        self.assertEqual((split_cells[0]["name"], split_cells[0]["reg_time"]), ("أحمد", "14:30"), "a time in its own cell is not part of the name")
        one_per_line = compare.parse_owners("الاسم\nالجوال\nالإعلانات\nالموافقات\nالتسجيل\nالحالة\n"
                                            "أحمد\n0555000001\n3\n2\n2026-11-02 14:30\nنشط\n"
                                            "سالم\n0555000002\n1\n0\n2026-11-01 09:05\nنشط\n")
        self.assertEqual([(r["name"], r["phone"], r["reg_time"]) for r in one_per_line], [("أحمد", "+966555000001", "14:30"), ("سالم", "+966555000002", "09:05")],
                         "copied from a small screen: one cell per line")

    def test_bad_rows_are_kept_with_the_reason_and_duplicates_are_dropped(self):
        rows = compare.parse_owners("أحمد\t0555000001\t3\t2\t2026-11-02 14:30\nأحمد مرة ثانية\t0555000001\t3\t2\t2026-11-02 14:30\nبلا تاريخ\t0555000003\t1\t0\tنشط\n"
                                    "رقم قصير\t05550\t1\t0\t2026-11-02")
        self.assertEqual(len(rows), 2, "the same phone twice counts once; a row with no real phone is not a row")
        self.assertEqual(rows[1]["problem"], "لا أجد تاريخ التسجيل في هذا الصف")
        self.assertEqual([r["no"] for r in rows], [1, 3], "the numbering follows the pasted rows, so the manager finds them")
        self.assertEqual(compare.parse_owners(""), [])
        self.assertEqual(compare.parse_owners("لا شيء مفيد هنا\nولا هنا"), [])
        many = "\n".join(f"عميل\t05{i:08d}\t1\t0\t2026-11-02 10:00" for i in range(compare.MAX_ROWS + 50))
        self.assertEqual(len(compare.parse_owners(many)), compare.MAX_ROWS)

    # --- whose registration it is ------------------------------------------------------------------------------------------------------
    TZ = "Asia/Riyadh"

    def at(self, day: str, hm: str, user: int) -> tuple[str, str, int]:
        """A contact made at local time `hm` on `day`, in the shape compare.contacts() returns."""
        ts = util.iso(util.local_to_utc(day, hm, self.TZ))
        return (ts, day, user)

    def test_no_contact_or_registration_before_the_first_contact_counts_for_nobody(self):
        self.assertEqual(compare.judge([], "2026-11-02", 30)[:2], ("before", None))
        found = [self.at("2026-11-03", "14:00", 7)]
        self.assertEqual(compare.judge(found, "2026-11-02", 30)[:2], ("before", None), "registered the day before the first call")
        self.assertEqual(compare.judge(found, "2026-11-03", 30, "09:00", self.TZ)[:2], ("before", None), "registered that morning, called that afternoon")
        self.assertEqual(compare.judge(found, "2026-11-03", 30)[:2], ("ours", 7), "with no time in the table the day decides: benefit of the doubt")

    def test_registration_after_the_contact_counts_for_the_employee_who_made_it(self):
        found = [self.at("2026-11-03", "14:00", 7)]
        self.assertEqual(compare.judge(found, "2026-11-03", 30, "15:00", self.TZ)[:2], ("ours", 7))
        self.assertEqual(compare.judge(found, "2026-11-03", 30, "14:00", self.TZ)[:2], ("ours", 7), "the same minute: the call may have come first")
        self.assertEqual(compare.judge(found, "2026-11-03", 30, "13:59", self.TZ)[:2], ("before", None))
        self.assertEqual(compare.judge(found, "2026-11-20", 30, "08:00", self.TZ)[:2], ("ours", 7))

    def test_the_last_contact_before_the_registration_is_the_one_that_counts(self):
        found = [self.at("2026-11-01", "10:00", 7), self.at("2026-11-03", "18:00", 8)]
        v, user, why = compare.judge(found, "2026-11-03", 30, "09:00", self.TZ)
        self.assertEqual((v, user), ("ours", 7), "registered before the second employee's call: the first employee's work")
        self.assertIn("2 يومًا", why)
        self.assertEqual(compare.judge(found, "2026-11-03", 30, "19:00", self.TZ)[:2], ("ours", 8))
        self.assertEqual(compare.judge(found, "2026-11-03", 30)[:2], ("ours", 8), "no time: the day's last contact")

    def test_the_n_day_limit_is_inclusive_and_a_late_registration_is_held_for_the_manager(self):
        found = [self.at("2026-10-01", "10:00", 7)]
        self.assertEqual(compare.judge(found, "2026-10-31", 30, "12:00", self.TZ)[:2], ("ours", 7), "exactly 30 days later")
        v, user, why = compare.judge(found, "2026-11-01", 30, "12:00", self.TZ)
        self.assertEqual((v, user), ("late", 7))
        self.assertIn("الحد 30", why)
        self.assertEqual(compare.judge(found, "2026-11-01", 31)[:2], ("ours", 7), "the limit is the company's setting")

    def test_a_contact_just_after_midnight_in_riyadh_belongs_to_the_riyadh_day(self):
        ts = util.iso(dt.datetime(2026, 11, 2, 21, 30, tzinfo=UTC))        # 00:30 on 3 November in Riyadh
        found = [(ts, util.local_date(ts, self.TZ), 7)]
        self.assertEqual(found[0][1], "2026-11-03")
        self.assertEqual(compare.judge(found, "2026-11-02", 30, "23:00", self.TZ)[:2], ("before", None))

    # --- the whole paste, end to end ----------------------------------------------------------------------------------------------------
    def test_pasting_the_table_confirms_the_right_registrations_and_leaves_the_rest_for_the_manager(self):
        with db.tx(True, self.path) as c:
            s = self.settings(c)
            sara, khaled, boss = self.user(c, "sara", name="سارة"), self.user(c, "khaled", name="خالد"), self.user(c, "boss", role="manager")
            now = util.now_iso()
            def lead(name, phone, alt=None):
                return c.execute("INSERT INTO leads(company_id,name,phone,phone_alt,added_at) VALUES(?,?,?,?,?)", (self.cid, name, phone, alt, now)).lastrowid
            def sent_link(lead_id, user, day, hm):
                util.freeze(util.local_to_utc(day, hm, self.TZ))
                db.emit(c, self.cid, "link.sent", user=user["id"], lead=lead_id, data={})
            l_ok, l_morning, l_never, l_old, l_done, l_second = (lead("سجل بعد", "+966555000001"), lead("سجل قبل", "+966555000002"), lead("لم نتصل", "+966555000003"),
                                                                 lead("قديم", "+966555000004"), lead("مؤكد", "+966555000005"), lead("رقمان", "+966555000006", alt="+966555000007"))
            sent_link(l_ok, sara, "2026-11-02", "13:00")
            sent_link(l_morning, sara, "2026-11-02", "16:00")
            sent_link(l_old, khaled, "2026-09-20", "11:00")
            sent_link(l_second, khaled, "2026-11-01", "11:00")
            c.execute("UPDATE leads SET confirmed_at=?, status='registered_confirmed', attribution=? WHERE id=?", (now, util.canon({"user": khaled["id"]}), l_done))
            util.freeze(util.local_to_utc("2026-11-04", "12:00", self.TZ))
            text = ("الاسم\tالجوال\tالإعلانات\tالموافقات\tالتسجيل\tالحالة\n"
                    "سجل بعد\t0555000001\t2\t2\t2026-11-02 15:00\tنشط\n"
                    "سجل قبل\t0555000002\t1\t1\t2026-11-02 09:00\tنشط\n"
                    "لم نتصل\t0555000003\t1\t0\t2026-11-03 10:00\tنشط\n"
                    "قديم\t0555000004\t4\t3\t2026-11-03 10:00\tنشط\n"
                    "مؤكد\t0555000005\t1\t1\t2026-11-03 10:00\tنشط\n"
                    "رقمان\t0555000007\t1\t1\t2026-11-03 10:00\tنشط\n"
                    "غريب\t0555000099\t1\t0\t2026-11-03 10:00\tنشط\n")
            imp = compare.import_owners(c, self.cid, boss["id"], text, s)
            verdict = {r["phone"]: (r["verdict"], r["user_id"]) for r in c.execute("SELECT * FROM ext_rows WHERE import_id=?", (imp,))}
            self.assertEqual(verdict["+966555000001"], ("ours", sara["id"]))
            self.assertEqual(verdict["+966555000002"], ("before", None), "she registered at 09:00 and was sent the link at 16:00")
            self.assertEqual(verdict["+966555000003"], ("before", None))
            self.assertEqual(verdict["+966555000004"], ("late", khaled["id"]))
            self.assertEqual(verdict["+966555000005"], ("already", khaled["id"]))
            self.assertEqual(verdict["+966555000007"], ("ours", khaled["id"]), "an owner who registered with the second number we hold is still ours")
            self.assertEqual(verdict["+966555000099"][0], "unmatched")
            self.assertEqual(db.scalar(c, "SELECT status FROM leads WHERE id=?", l_ok), "registered_confirmed")
            self.assertEqual(db.scalar(c, "SELECT status FROM leads WHERE id=?", l_old), "new", "a late one waits for the manager")
            row = db.one(c, "SELECT matched, attributed, rows FROM ext_imports WHERE id=?", imp)
            self.assertEqual((row["rows"], row["matched"], row["attributed"]), (7, 6, 2))
            # the manager approves the late one, and links the stranger by hand to a client of ours
            late_id = db.scalar(c, "SELECT id FROM ext_rows WHERE import_id=? AND verdict='late'", imp)
            self.assertEqual(compare.approve_late(c, self.cid, late_id, boss["id"]), (True, ""))
            self.assertFalse(compare.approve_late(c, self.cid, late_id, boss["id"])[0], "approving twice does nothing")
            self.assertEqual(json.loads(db.scalar(c, "SELECT attribution FROM leads WHERE id=?", l_old))["how"], "late_approved")
            stranger = db.scalar(c, "SELECT id FROM ext_rows WHERE import_id=? AND verdict='unmatched'", imp)
            self.assertFalse(compare.link_row(c, self.cid, stranger, "0555111111", boss["id"], s)[0], "no client has that number")
            self.assertTrue(compare.link_row(c, self.cid, stranger, "0555000003", boss["id"], s)[0])
            self.assertEqual(db.scalar(c, "SELECT verdict FROM ext_rows WHERE id=?", stranger), "before", "linked, but nobody had contacted that client before")
            self.assertEqual(db.scalar(c, "SELECT linked_by FROM ext_rows WHERE id=?", stranger), boss["id"])
            self.assertEqual(db.scalar(c, "SELECT COUNT(*) FROM events WHERE type='compare.linked'"), 1)
            self.assertTrue(db.verify_chain(c, self.cid)["ok"])

# ================================================================================================ backups come back whole or not at all
class Restoring(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.data = Path(self.tmp.name)
        self.patch = mock.patch.object(config, "DATA_DIR", self.data)
        self.patch.start()
        util.freeze(NOON)
        db.init()
        with db.tx(True) as c:
            self.cid = db.create_company(c, "شركة النسخ")
            db.emit(c, self.cid, "x.one", data={"n": 1})
            db.emit(c, self.cid, "x.two", data={"n": 2})

    def tearDown(self) -> None:
        self.patch.stop()
        util.freeze(None)
        self.tmp.cleanup()

    def backup_gz(self) -> bytes:
        info = backup.make_backup("manual")
        self.assertTrue(info["ok"], info)
        return Path(info["path"]).read_bytes()

    def live_state(self) -> tuple[int, int]:
        with db.tx() as c:
            return db.scalar(c, "SELECT COUNT(*) FROM events"), db.scalar(c, "SELECT COUNT(*) FROM leads")

    def add_client_after_backup(self) -> None:
        with db.tx(True) as c:
            db.emit(c, self.cid, "x.three", data={"n": 3})
            c.execute("INSERT INTO leads(company_id,name,phone,added_at) VALUES(?,?,?,?)", (self.cid, "بعد النسخة", "+966555000001", util.now_iso()))

    def test_a_backup_comes_back_and_the_data_it_replaced_is_kept_beside_it(self):
        gz = self.backup_gz()
        events_in_copy, _ = self.live_state()
        self.add_client_after_backup()
        info = backup.restore_from(io.BytesIO(gz))
        self.assertTrue(info["ok"], info)
        with db.tx() as c:
            self.assertEqual(db.scalar(c, "SELECT COUNT(*) FROM leads"), 0, "the client added after the backup is not in the restored data")
            types = [r["type"] for r in c.execute("SELECT type FROM events WHERE company_id=? ORDER BY seq", (self.cid,))]
            self.assertNotIn("x.three", types)
            self.assertEqual(types[-1], "system.restored", "the history records that a restore happened")
            self.assertEqual(len(types), events_in_copy + 1)
            self.assertTrue(db.verify_chain(c, self.cid)["ok"], "the chain carries on unbroken from where the copy stopped")
            self.assertEqual(db.scalar(c, "SELECT kind FROM backup_log ORDER BY id DESC LIMIT 1"), "restore")
        kept = [f for f in self.data.glob("minjaz.db.before-restore-*") if not f.name.endswith(("-wal", "-shm"))]
        self.assertEqual([f.name for f in kept], [info["kept_old_as"]])
        old = sqlite3.connect(f"file:{kept[0]}?mode=ro", uri=True)
        try:
            self.assertEqual(old.execute("SELECT COUNT(*) FROM leads").fetchone()[0], 1, "the data that was replaced is still there, whole")
        finally:
            old.close()
        self.assertEqual(list(self.data.glob(".restore-*")), [], "no scratch folder is left behind")
        # and the restored database is an ordinary live one: the app can write to it and back it up again
        with db.tx(True) as c:
            db.emit(c, self.cid, "x.after", data={})
        self.assertTrue(backup.make_backup("manual")["ok"])

    def test_anything_that_is_not_a_whole_backup_is_refused_and_the_live_data_is_not_touched(self):
        good = self.backup_gz()
        raw = gzip.decompress(good)
        self.add_client_after_backup()
        before = self.live_state()
        other_version = Path(self.tmp.name) / "v99.db"
        other_version.write_bytes(raw)
        con = sqlite3.connect(str(other_version))
        con.execute("PRAGMA journal_mode=DELETE")
        con.execute("PRAGMA user_version=99")
        con.commit()
        con.close()
        cases = {"not gzip at all": b"not a backup at all", "gzip of text": gzip.compress(b"hello, this is not a database. " * 20),
                 "cut short": good[: len(good) // 2], "pages wiped": gzip.compress(raw[:100] + b"\0" * (len(raw) - 100)),
                 "another version": gzip.compress(other_version.read_bytes()), "empty": b""}
        for label, blob in cases.items():
            info = backup.restore_from(io.BytesIO(blob))
            self.assertFalse(info["ok"], label)
            self.assertTrue(info["note"], label)
            self.assertEqual(self.live_state(), before, f"{label}: the live data was touched")
        self.assertEqual(list(self.data.glob("minjaz.db.before-restore-*")), [], "a refused restore never moves the live database")
        self.assertEqual(list(self.data.glob(".restore-*")), [])

    def test_a_copy_whose_history_was_edited_is_refused_unless_it_is_all_you_have(self):
        good = self.backup_gz()
        scratch = Path(self.tmp.name) / "edited.db"
        scratch.write_bytes(gzip.decompress(good))
        con = sqlite3.connect(str(scratch), isolation_level=None)
        con.execute("PRAGMA journal_mode=DELETE")
        con.execute("DROP TRIGGER events_no_update")
        con.execute("UPDATE events SET data='{\"n\":99}' WHERE seq=2")
        con.close()
        edited = gzip.compress(scratch.read_bytes())
        self.add_client_after_backup()
        before = self.live_state()
        info = backup.restore_from(io.BytesIO(edited))
        self.assertFalse(info["ok"])
        self.assertIn("سلسلة السجل", info["note"])
        self.assertEqual(info["bad_chains"][0]["bad_seq"], 2)
        self.assertEqual(self.live_state(), before)
        accepted = backup.restore_from(io.BytesIO(edited), allow_bad_chain=True)
        self.assertTrue(accepted["ok"], accepted)
        with db.tx() as c:
            last = db.one(c, "SELECT type, data FROM events WHERE company_id=? ORDER BY seq DESC LIMIT 1", self.cid)
            self.assertEqual(last["type"], "system.restored")
            self.assertTrue(json.loads(last["data"])["bad_chain_accepted"], "accepting a broken copy is written in the history")

    def test_the_command_needs_force_and_reads_the_backup_from_standard_input(self):
        gz = self.backup_gz()
        self.add_client_after_backup()
        env = {**__import__("os").environ, "DATA_DIR": str(self.data)}
        run = lambda *args, data=b"": subprocess.run([sys.executable, "-m", "minjaz", "restore", *args], input=data, capture_output=True, cwd=ROOT, env=env, timeout=60)  # noqa: E731
        no_force = run(data=gz)
        self.assertEqual(no_force.returncode, 2)
        self.assertEqual(self.live_state()[1], 1, "without --force nothing happens")
        bad = run("--force", data=b"garbage")
        self.assertEqual(bad.returncode, 1)
        self.assertIn("ليس", json.loads(bad.stdout)["note"])
        done = run("--force", data=gz)
        self.assertEqual(done.returncode, 0, done.stderr.decode())
        self.assertTrue(json.loads(done.stdout)["ok"])
        self.assertEqual(self.live_state()[1], 0)
        check = subprocess.run([sys.executable, "-m", "minjaz", "verify"], capture_output=True, cwd=ROOT, env=env, timeout=60)
        self.assertEqual(check.returncode, 0, check.stdout.decode())


if __name__ == "__main__":
    unittest.main()
