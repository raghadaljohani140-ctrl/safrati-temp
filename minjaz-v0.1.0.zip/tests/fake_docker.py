#!/usr/bin/env python3
"""A stand-in for the `docker` command, just big enough for install.sh, web.sh, backup.sh, restore.sh, status.sh and uninstall.sh.

It keeps a small world in a JSON file (FAKE_STATE): containers with their networks, mounts and logs, networks, volumes. It understands only the
exact calls those scripts make and stops with an error on anything else, so a script that starts asking Docker something new is noticed.

Switches for the tests (environment variables):
  FAKE_STATE               path of the JSON file holding the world
  FAKE_FAIL_IF_CONTAINS    `caddy validate` fails when the Caddyfile contains this text
  FAKE_RELOAD_FAIL=1       `caddy reload` fails
  FAKE_RESTORE_FAIL=1      `python -m minjaz restore` fails
  FAKE_BACKUP_GARBAGE=1    `python -m minjaz backup` writes a file that is not a database
"""
from __future__ import annotations

import gzip
import hashlib
import json
import os
import sqlite3
import sys
import tempfile
from pathlib import Path

STATE = Path(os.environ["FAKE_STATE"])
PROJECT_LABEL = "com.docker.compose.project"
SETUP_LINE = "=== رمز الإعداد الأول: abcd-efgh-ijkl === افتح /setup وأدخله لإنشاء حساب المالك (يُستخدم مرة واحدة)"
LISTEN_LINE = "2026-11-03 12:00:00 INFO minjaz.web listening on 0.0.0.0:8095"


def load() -> dict:
    return json.loads(STATE.read_text(encoding="utf-8"))


def save(w: dict) -> None:
    STATE.write_text(json.dumps(w, ensure_ascii=False, indent=1), encoding="utf-8")


def log_call(w: dict, *argv: str) -> None:
    w.setdefault("calls", []).append(" ".join(argv))


def die(msg: str, code: int = 1) -> None:
    print(msg, file=sys.stderr)
    sys.exit(code)


def fingerprint() -> str:
    env = Path.cwd() / ".env"
    return hashlib.sha256(env.read_bytes()).hexdigest() if env.exists() else ""


def compose(w: dict, args: list[str]) -> None:
    if args[:1] == ["version"]:
        print("Docker Compose version v2.fake")
        return
    if args[:2] != ["-p", "minjaz"]:
        die(f"fake docker: unexpected compose call {args}", 2)
    rest = args[2:]
    cmd = rest[0]
    c = w["containers"]
    log_call(w, "compose", *rest)
    if cmd == "up":
        w["networks"].setdefault("minjaz_default", {"labels": {PROJECT_LABEL: "minjaz"}})
        w["volumes"].setdefault("minjaz_minjaz_data", {"labels": {PROJECT_LABEL: "minjaz"}})
        w["volume_files"].setdefault("minjaz_minjaz_data", [])
        fp = fingerprint()
        existing = c.get("minjaz-web")
        if existing is None or existing.get("fingerprint") != fp:
            lines = [LISTEN_LINE] + ([SETUP_LINE] if existing is None else ["لم يُنشأ حساب المالك بعد. لتوليد رمز جديد: docker exec minjaz-web python -m minjaz setup-code"])
            c["minjaz-web"] = {"image": "minjaz-app:local", "running": True, "networks": ["minjaz_default"], "labels": {PROJECT_LABEL: "minjaz"}, "ports": [],
                               "mounts": [], "cmd": ["python", "-m", "minjaz", "run"], "args": [], "logs": lines, "fingerprint": fp, "health": "healthy"}
        else:
            existing["running"] = True
    elif cmd == "stop":
        if "minjaz-web" in c:
            c["minjaz-web"]["running"] = False
    elif cmd == "ps":
        for name, d in c.items():
            if d["labels"].get(PROJECT_LABEL) == "minjaz":
                print(f"{name}   {d['image']}   {'Up' if d['running'] else 'Exited'}")
    elif cmd == "down":
        for name in [n for n, d in c.items() if d["labels"].get(PROJECT_LABEL) == "minjaz"]:
            del c[name]
        w["networks"].pop("minjaz_default", None)
        if "--volumes" in rest:
            w["volumes"].pop("minjaz_minjaz_data", None)
    elif cmd == "run":
        data = sys.stdin.buffer.read()
        w.setdefault("restore_inputs", []).append({"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data), "argv": rest})
        if os.environ.get("FAKE_RESTORE_FAIL") == "1":
            print('{"ok": false, "note": "fake failure"}')
            save(w)
            sys.exit(1)
        print('{"ok": true}')
    else:
        die(f"fake docker: unexpected compose command {rest}", 2)


def inspect_fmt(item: dict, fmt: str, name: str) -> str:
    if fmt == '{{ index .Config.Labels "com.docker.compose.project" }}':
        return item["labels"].get(PROJECT_LABEL, "")
    if fmt == "{{.State.Running}}":
        return "true" if item["running"] else "false"
    if fmt == "{{range $k, $v := .NetworkSettings.Networks}}{{$k}} {{end}}":
        return "".join(f"{n} " for n in item["networks"])
    if fmt == '{{range .Mounts}}{{.Type}}|{{.Source}}|{{.Destination}}{{"\\n"}}{{end}}':
        return "".join(f"{t}|{s}|{d}\n" for t, s, d in item["mounts"])
    if fmt == '{{join .Config.Cmd " "}} {{join .Args " "}}':
        return " ".join(item["cmd"]) + " " + " ".join(item["args"])
    if fmt == "{{.State.Health.Status}}":
        return item.get("health", "healthy")
    die(f"fake docker: unexpected inspect format {fmt!r}", 2)
    return ""


def caddy_host_file(w: dict, d: dict) -> Path:
    for _t, src, dst in d["mounts"]:
        if dst == "/etc/caddy/Caddyfile":
            return Path(src)
    die("fake docker: the Caddy container has no Caddyfile mount", 2)
    raise SystemExit


def main(argv: list[str]) -> None:
    w = load()
    c = w["containers"]
    a = argv
    if not a:
        die("fake docker: no arguments", 2)
    cmd = a[0]
    if cmd == "info":
        print("Server Version: fake")
    elif cmd == "compose":
        compose(w, a[1:])
    elif cmd == "inspect":
        fmt = a[2] if a[1] == "-f" else None
        name = a[3] if fmt else a[1]
        if name not in c:
            sys.exit(1)
        if fmt:
            sys.stdout.write(inspect_fmt(c[name], fmt, name))
    elif cmd in ("volume", "network") and a[1] == "inspect":
        coll = w["volumes"] if cmd == "volume" else w["networks"]
        fmt = a[3] if a[2] == "-f" else None
        name = a[4] if fmt else a[2]
        if name not in coll:
            sys.exit(1)
        if fmt == '{{ index .Labels "com.docker.compose.project" }}':
            print(coll[name].get("labels", {}).get(PROJECT_LABEL, ""))
        elif fmt == "{{range $id, $c := .Containers}}{{$c.Name}} {{end}}":
            print("".join(f"{n} " for n, d in c.items() if name in d["networks"]))
        elif fmt:
            die(f"fake docker: unexpected format {fmt!r}", 2)
    elif cmd == "network" and a[1] == "ls":
        print("\n".join(w["networks"]))
    elif cmd == "network" and a[1] in ("connect", "disconnect"):
        net, name = a[2], a[3]
        if net not in w["networks"] or name not in c:
            die("fake docker: no such network or container", 1)
        log_call(w, *a)
        if a[1] == "connect" and net not in c[name]["networks"]:
            c[name]["networks"].append(net)
        if a[1] == "disconnect" and net in c[name]["networks"]:
            c[name]["networks"].remove(net)
    elif cmd == "ps":
        everything = "-a" in a
        fmt = a[a.index("--format") + 1]
        for name, d in c.items():
            if not (d["running"] or everything):
                continue
            if fmt == "{{.Names}}|{{.Image}}":
                print(f"{name}|{d['image']}")
            elif fmt == "    {{.Names}}  ({{.Status}})":
                print(f"    {name}  ({'Up 3 days' if d['running'] else 'Exited'})")
            else:
                die(f"fake docker: unexpected ps format {fmt!r}", 2)
    elif cmd == "port":
        for line in c[a[1]]["ports"]:
            print(line)
    elif cmd == "logs":
        name = a[-1]
        lines = c[name]["logs"]
        if "--tail" in a:
            lines = lines[-int(a[a.index("--tail") + 1]):]
        print("\n".join(lines))
    elif cmd == "exec":
        rest = [x for x in a[1:] if x not in ("-it", "-i", "-t")]
        name, command = rest[0], rest[1:]
        if name not in c:
            die(f"Error: No such container: {name}", 1)
        log_call(w, "exec", name, *command)
        if command[:1] == ["caddy"]:
            file = caddy_host_file(w, c[name])
            text = file.read_text(encoding="utf-8")
            bad = os.environ.get("FAKE_FAIL_IF_CONTAINS")
            if command[1] == "validate":
                if "INVALID" in text or (bad and bad in text):
                    print("Error: adapting config using caddyfile: unrecognized directive", file=sys.stderr)
                    save(w)
                    sys.exit(1)
            elif command[1] == "reload":
                if os.environ.get("FAKE_RELOAD_FAIL") == "1":
                    print("Error: reload failed", file=sys.stderr)
                    save(w)
                    sys.exit(1)
                (STATE.parent / "loaded.Caddyfile").write_text(text, encoding="utf-8")
            else:
                die(f"fake docker: unexpected caddy command {command}", 2)
        elif command[:3] == ["python", "-m", "minjaz"]:
            if command[3] == "setup-code":
                print("رمز الإعداد الجديد: wxyz-1234-abcd")
            elif command[3] == "backup":
                path = "/data/backups/minjaz-20261103-120000-manual.db.gz"
                with tempfile.TemporaryDirectory() as tmp:
                    db_file = Path(tmp) / "x.db"
                    con = sqlite3.connect(str(db_file))
                    con.execute("CREATE TABLE t(a)")
                    con.execute("INSERT INTO t VALUES(1)")
                    con.commit()
                    con.close()
                    blob = b"not a backup" if os.environ.get("FAKE_BACKUP_GARBAGE") == "1" else gzip.compress(db_file.read_bytes())
                w["volume_files"]["minjaz_minjaz_data"] = [[path, blob.hex()]]
                print(json.dumps({"ok": True, "kind": "manual", "path": path}, indent=2))
            else:
                die(f"fake docker: unexpected minjaz command {command}", 2)
        elif command[:2] == ["sh", "-c"]:
            print("12M\t/data")
        else:
            die(f"fake docker: unexpected exec {command}", 2)
    elif cmd == "cp":
        src, dest = a[1], a[2]
        container, _, inside = src.partition(":")
        files = dict(w["volume_files"].get("minjaz_minjaz_data", []))
        if container not in c or inside not in files:
            die("Error: No such container:path", 1)
        Path(dest).write_bytes(bytes.fromhex(files[inside]))
    elif cmd == "stats":
        print("minjaz-web: memory 61MiB / 256MiB, cpu 0.2%")
    elif cmd == "rmi":
        log_call(w, *a)
    else:
        die(f"fake docker: unexpected command {a}", 2)
    save(w)


if __name__ == "__main__":
    main(sys.argv[1:])
