"""One long story against the real server: owner sets up, adds staff, imports numbers, staff work a day, the manager reads the reports,
fixes a result, compares with the platform, links a phone. Each step builds on the one before, so they run in order."""
from __future__ import annotations

import csv
import io
import json
import re
import sqlite3
import sys
import unittest
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from tests.client import Client  # noqa: E402
from tests.harness import LiveServer  # noqa: E402

PASSWORD = "Owner-pass-2026"


def temp_password(html: str) -> str:
    m = re.search(r'<span class="code">([^<]+)</span>', html)
    assert m, "no temporary password on the page"
    return m.group(1).strip()


def csv_bytes(rows: list[list[str]]) -> bytes:
    buf = io.StringIO()
    csv.writer(buf).writerows(rows)
    return ("﻿" + buf.getvalue()).encode("utf-8")


class Flow(unittest.TestCase):
    srv: LiveServer
    owner: Client
    emp: dict[str, Client] = {}
    pw: dict[str, str] = {}
    _open: list[sqlite3.Connection] = []

    @classmethod
    def setUpClass(cls) -> None:
        cls.srv = LiveServer().start()
        cls.owner = Client(port=cls.srv.port)

    @classmethod
    def tearDownClass(cls) -> None:
        log = cls.srv.log()
        if "Traceback" in log:
            print("\n--- server tracebacks ---\n" + "\n".join(blk[:1800] for blk in log.split("Traceback")[1:6]))
        for con in cls._open:
            con.close()
        cls._open.clear()
        cls.srv.stop()

    def db(self) -> sqlite3.Connection:
        c = sqlite3.connect(str(self.srv.db_path), isolation_level=None)  # autocommit: a test must never hold a lock the server waits for
        c.row_factory = sqlite3.Row
        self._open.append(c)
        return c

    def ok(self, resp, status: int = 200):
        self.assertEqual(resp.status, status, resp.text[:400])
        return resp

    # ------------------------------------------------------------------------------------------ 01 setup
    def test_01_setup_and_login(self):
        o = self.owner
        self.assertTrue(self.srv.setup_code, "the setup code is printed in the log")
        self.assertEqual(o.get("/").location, "/setup")
        r = o.get("/setup")
        self.ok(r)
        bad = o.post("/setup", {"code": "aaaa-bbbb-cccc", "company": "شركة الاختبار", "name": "المالك", "username": "boss", "password": PASSWORD, "again": PASSWORD})
        self.assertIn("رمز الإعداد غير صحيح", bad.text)
        weak = o.post("/setup", {"code": self.srv.setup_code, "company": "شركة الاختبار", "name": "المالك", "username": "boss", "password": "12345678", "again": "12345678"})
        self.assertEqual(weak.status, 400)
        good = o.post("/setup", {"code": self.srv.setup_code, "company": "شركة الاختبار", "name": "المالك", "username": "boss", "password": PASSWORD, "again": PASSWORD})
        self.assertEqual(good.status, 303, good.text[:300])
        dash = self.ok(o.follow(good))
        self.assertIn("لوحة المراقبة", dash.text)
        self.assertEqual(Client(port=self.srv.port).get("/setup").location, "/login", "setup closes after the first account")

    def test_02_settings(self):
        o = self.owner
        page = self.ok(o.get("/m/settings"))
        self.assertIn("platform_url", page.text)
        r = o.post("/m/settings", {"_all": "1", "platform_name": "استراحتي", "platform_url": "https://estrahati.example", "daily_new": "6", "shift_hours": "8",
                                   "minutes_per_call": "4", "tz": "Asia/Riyadh"})  # call-hour lock and the rest of the switches stay off
        self.assertEqual(r.status, 303)
        self.assertIn("حُفظ تغيير", o.follow(r).text)
        bad = o.post("/m/settings", {"_all": "1", "tz": "Mars/Base"})
        self.assertIn("المنطقة الزمنية", o.follow(bad).text)
        bad2 = o.post("/m/settings", {"_all": "1", "w_exec": "0", "w_results": "0", "w_quality": "0", "w_discipline": "0"})
        self.assertIn("مجموع أوزان", o.follow(bad2).text)
        con = self.db()
        self.assertEqual(con.execute("SELECT value FROM settings WHERE key='daily_new'").fetchone()[0], "6")
        ev = con.execute("SELECT COUNT(*) FROM events WHERE type='settings.changed'").fetchone()[0]
        self.assertGreaterEqual(ev, 1)

    # ------------------------------------------------------------------------------------------ 03 staff
    def test_03_create_employees(self):
        o = self.owner
        for name, user in (("سارة العتيبي", "sara"), ("خالد الحربي", "khaled")):
            self.ok(o.get("/m/employees/new"))
            r = o.post("/m/employees/new", {"name": name, "username": user, "phone": "0555000111"})
            self.ok(r)
            self.pw[user] = temp_password(r.text)
            self.assertIn("Cache-Control", {k.title(): v for k, v in r.headers.items()}, "credentials page is never cached")
        dup = o.post("/m/employees/new", {"name": "آخر", "username": "sara"})
        self.assertEqual(dup.status, 400)
        self.assertIn("محجوز", dup.text)
        page = self.ok(o.get("/m/employees"))
        self.assertIn("سارة العتيبي", page.text)
        self.assertIn("خالد الحربي", page.text)

    # ------------------------------------------------------------------------------------------ 04 import
    def test_04_import_numbers(self):
        o = self.owner
        rows = [["الاسم", "الجوال", "المدينة", "رابط الإعلان"]]
        for i in range(1, 15):
            rows.append([f"استراحة {i}", f"05{50 + i:02d}{i:06d}", "جدة" if i % 2 else "الرياض", f"https://example.test/ad/{i}"])
        rows.append(["مكرر داخل الملف", "0551000001", "جدة", ""])          # the same number as row 1
        rows.append(["رقم خطأ", "12345", "جدة", ""])                        # too short
        rows.append(["أرضي", "0112345678", "الرياض", ""])                   # landline
        r = o.upload("/m/import/upload", "numbers.csv", csv_bytes(rows))
        self.assertEqual(r.status, 303, r.text[:300])
        mapping_url = r.location
        m = self.ok(o.get(mapping_url))
        self.assertIn("ربط الأعمدة", m.text)
        bid = int(mapping_url.rsplit("/", 1)[1])
        pre = o.post(f"/m/import/{bid}/map", {"m_name": "0", "m_phone": "1", "m_city": "2", "m_source_url": "3", "has_header": "1"})
        self.assertEqual(pre.status, 303)
        view = self.ok(o.follow(pre))
        self.assertIn("نتيجة الفحص", view.text)
        con = self.db()
        counts = json.loads(con.execute("SELECT counts_json FROM lead_batches WHERE id=?", (bid,)).fetchone()[0])
        self.assertEqual(counts["invalid"], 1)
        self.assertEqual(counts["dup_file"], 1)
        self.assertEqual(counts["new"], 15, counts)  # 14 good + the landline (stored, kept out of plans)
        self.assertEqual(con.execute("SELECT COUNT(*) FROM leads").fetchone()[0], 0, "nothing is saved before approval")
        commit = o.post(f"/m/import/{bid}/commit")
        self.assertEqual(commit.status, 303)
        self.assertIn("أُضيف 15", o.follow(commit).text)
        self.assertEqual(con.execute("SELECT COUNT(*) FROM leads").fetchone()[0], 15)
        self.assertEqual(self.db().execute("SELECT COUNT(*) FROM leads WHERE line_type<>'mobile'").fetchone()[0], 1)
        again = o.post(f"/m/import/{bid}/commit")
        self.assertIn("لا يمكن اعتماده", o.follow(again).text, "a batch is approved once")
        # the same file again: every number is now a duplicate of a saved client
        r2 = o.upload("/m/import/upload", "numbers.csv", csv_bytes(rows))
        bid2 = int(r2.location.rsplit("/", 1)[1])
        o.follow(o.post(f"/m/import/{bid2}/map", {"m_name": "0", "m_phone": "1", "m_city": "2", "has_header": "1"}))
        counts2 = json.loads(self.db().execute("SELECT counts_json FROM lead_batches WHERE id=?", (bid2,)).fetchone()[0])
        self.assertEqual(counts2["new"], 0)
        self.assertEqual(counts2["dup_db"], 16, "every row, including the in-file duplicate, now matches a saved client")
        rej = self.ok(o.get(f"/m/import/{bid2}/rejected.csv"))
        self.assertIn("مكرر", rej.text)
        o.post(f"/m/import/{bid2}/cancel")

    def test_05_leads_list(self):
        o = self.owner
        page = self.ok(o.get("/m/leads"))
        self.assertIn("استراحة 3", page.text)
        self.assertIn("15 عميلًا", page.text)
        self.assertIn("استراحة 4", self.ok(o.get("/m/leads?q=" + urllib.parse.quote("استراحة 4"))).text)
        by_phone = self.ok(o.get("/m/leads?q=0553000003")).text
        self.assertIn("استراحة 3", by_phone)
        self.assertNotIn("استراحة 4<", by_phone)
        self.assertEqual(o.get("/m/export/leads.csv").status, 200)

    # ------------------------------------------------------------------------------------------ 06 employee works
    def test_06_employee_first_login_and_day(self):
        s = Client(port=self.srv.port)
        r = s.post("/login", {"username": "sara", "password": self.pw["sara"]})
        self.assertEqual(r.status, 303)
        self.assertEqual(s.get("/w").location, "/password", "a temporary password must be replaced first")
        s.get("/password")
        bad = s.post("/password", {"current": self.pw["sara"], "new": "short", "again": "short"})
        self.assertEqual(bad.status, 400)
        ok = s.post("/password", {"current": self.pw["sara"], "new": "Sara-new-pass-77", "again": "Sara-new-pass-77"})
        self.assertEqual(ok.status, 303)
        self.pw["sara"] = "Sara-new-pass-77"
        home = self.ok(s.get("/w"))
        self.assertIn("ابدأ", home.text)
        self.assertEqual(s.get("/m").location, "/w", "an employee never sees the manager's pages")
        self.emp["sara"] = s

    def test_07_start_day_and_plan(self):
        s = self.emp["sara"]
        s.get("/w")
        r = s.post("/w/start")
        self.assertEqual(r.status, 303, r.text[:300])
        con = self.db()
        plan = con.execute("SELECT * FROM daily_plans").fetchone()
        self.assertIsNotNone(plan)
        self.assertEqual(plan["new_given"], 6, "the daily quota from settings")
        tasks = con.execute("SELECT * FROM tasks WHERE plan_id=? ORDER BY position", (plan["id"],)).fetchall()
        self.assertEqual(len(tasks), 6)
        self.assertEqual({t["kind"] for t in tasks}, {"new"})
        owned = con.execute("SELECT COUNT(*) FROM leads WHERE owner_id=(SELECT id FROM users WHERE username='sara')").fetchone()[0]
        self.assertEqual(owned, 6)
        landline_taken = con.execute("SELECT COUNT(*) FROM leads WHERE owner_id IS NOT NULL AND line_type<>'mobile'").fetchone()[0]
        self.assertEqual(landline_taken, 0, "landlines never reach a plan while the setting is off")
        # a second start the same day does not make a second plan or take more numbers
        s.post("/w/start")
        self.assertEqual(con.execute("SELECT COUNT(*) FROM daily_plans").fetchone()[0], 1)
        self.assertEqual(self.db().execute("SELECT COUNT(*) FROM leads WHERE owner_id IS NOT NULL").fetchone()[0], 6)

    def test_08_calls_and_results(self):
        s = self.emp["sara"]
        con = self.db()
        ids = [r["lead_id"] for r in con.execute("SELECT lead_id FROM tasks ORDER BY position")]
        page = self.ok(s.get(f"/w/lead/{ids[0]}"))
        self.assertIn("اتصال", page.text)
        # 1: interested (needs a note), pressed "call" first
        self.assertEqual(s.post(f"/w/lead/{ids[0]}/call").status, 204)
        missing = s.post(f"/w/lead/{ids[0]}/outcome", {"outcome": "interested", "note": ""})
        self.assertEqual(missing.status, 400, "a note is required for 'interested'")
        r = s.post(f"/w/lead/{ids[0]}/outcome", {"outcome": "interested", "note": "يريد تفاصيل عن العمولة وسيراجع شريكه"})
        self.assertEqual(r.status, 303)
        # 2: no answer (no call pressed: the lowest evidence)
        s.post(f"/w/lead/{ids[1]}/outcome", {"outcome": "no_answer"})
        # 3: wrong number
        s.post(f"/w/lead/{ids[2]}/call")
        s.post(f"/w/lead/{ids[2]}/outcome", {"outcome": "wrong_number"})
        # 4: call later needs a future date and time
        s.post(f"/w/lead/{ids[3]}/call")
        bad = s.post(f"/w/lead/{ids[3]}/outcome", {"outcome": "call_later"})
        self.assertEqual(bad.status, 400)
        # 5: asked for the link
        s.post(f"/w/lead/{ids[4]}/call")
        s.post(f"/w/lead/{ids[4]}/outcome", {"outcome": "asked_link"})
        # 6: not interested
        s.post(f"/w/lead/{ids[5]}/call")
        s.post(f"/w/lead/{ids[5]}/outcome", {"outcome": "not_interested", "note": "لا يرغب بأي منصات"})
        con = self.db()
        st = {r["id"]: r for r in con.execute("SELECT * FROM leads")}
        self.assertEqual(st[ids[0]]["status"], "interested")
        self.assertIsNotNone(st[ids[0]]["next_follow_up"], "interested clients come back")
        self.assertEqual(st[ids[1]]["status"], "no_answer")
        self.assertEqual(st[ids[2]]["status"], "wrong_number")
        self.assertEqual(st[ids[3]]["status"], "new", "a refused result leaves the client untouched")
        self.assertEqual(st[ids[4]]["status"], "link_sent")
        self.assertEqual(st[ids[5]]["status"], "not_interested")
        ev = {r["lead_id"]: r["evidence"] for r in con.execute("SELECT lead_id, evidence FROM call_attempts WHERE status='recorded'")}
        self.assertEqual(ev[ids[0]], 1)
        self.assertEqual(ev[ids[1]], 0, "a result without pressing call is the lowest evidence")
        done = con.execute("SELECT COUNT(*) FROM tasks WHERE status='done'").fetchone()[0]
        self.assertEqual(done, 5)
        self.__class__.lead_ids = ids

    def test_09_personal_link(self):
        s = self.emp["sara"]
        ids = self.lead_ids
        s.get(f"/w/lead/{ids[4]}")  # opening the card is what makes the personal link
        self.assertEqual(s.post(f"/w/lead/{ids[4]}/link").status, 204)
        con = self.db()
        tok = con.execute("SELECT link_token FROM leads WHERE id=?", (ids[4],)).fetchone()[0]
        self.assertTrue(tok)
        anon = Client(port=self.srv.port)
        r = anon.get(f"/l/{tok}", headers={"User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)"})
        self.assertIn(r.status, (302, 303), r.text[:200])
        self.assertTrue(r.location.startswith("https://estrahati.example"))
        again = anon.get(f"/l/{tok}", headers={"User-Agent": "Mozilla/5.0 (iPhone)"})  # a second open within a minute is the same visit
        opens = self.db().execute("SELECT link_opens FROM leads WHERE id=?", (ids[4],)).fetchone()[0]
        self.assertEqual(opens, 1)
        bot = anon.get(f"/l/{tok}", headers={"User-Agent": "WhatsApp/2.23 A"})
        self.assertEqual(self.db().execute("SELECT link_opens FROM leads WHERE id=?", (ids[4],)).fetchone()[0], 1, "link previews are not visits")
        self.assertEqual(anon.get("/l/doesnotexist").status, 404)

    def test_10_close_day(self):
        s = self.emp["sara"]
        page = self.ok(s.get("/w/end"))
        self.assertIn("إنهاء يوم العمل", page.text)
        r = s.post("/w/end", {"note": ""})
        self.assertEqual(r.status, 303)
        self.assertIn("/w/end", r.location, "open tasks need a reason")
        r = s.post("/w/end", {"all_reason": "no_time", "note": "انتهى الدوام"})
        self.assertEqual(r.status, 303, r.text[:200])
        self.assertIn("/w/day/", r.location)
        con = self.db()
        sh = con.execute("SELECT * FROM shifts").fetchone()
        self.assertEqual(sh["status"], "closed")
        rep = con.execute("SELECT * FROM daily_reports").fetchone()
        self.assertIsNotNone(rep, "the day is sealed when it closes")
        self.assertEqual(rep["version"], 1)
        self.assertEqual(self.ok(s.get(r.location)).status, 200)

    # ------------------------------------------------------------------------------------------ 11 manager reads
    def test_11_manager_views(self):
        o = self.owner
        dash = self.ok(o.get("/m"))
        self.assertIn("سارة العتيبي", dash.text)
        for metric in ("working", "not_started", "calls", "answered", "interested", "links_sent", "links_opened", "reg_reported", "reg_confirmed", "tasks_open", "gaps",
                       "overdue", "orphans", "exhausted"):
            self.ok(o.get(f"/m/drill/{metric}"))
        self.assertEqual(o.get("/m/drill/nonsense").status, 404)
        con = self.db()
        uid = con.execute("SELECT id FROM users WHERE username='sara'").fetchone()[0]
        day = con.execute("SELECT work_date FROM shifts").fetchone()[0]
        rep = self.ok(o.get(f"/m/report/{uid}/{day}"))
        self.assertIn("سارة العتيبي", rep.text)
        self.assertIn("سليم", rep.text, "the seal verifies")
        self.assertIn("تقييم", rep.text)
        self.ok(o.get("/m/reports"))
        self.ok(o.get("/m/reports?kind=day"))
        self.ok(o.get("/m/reports?kind=month"))
        self.ok(o.get(f"/m/reports/employee/{uid}"))
        csvr = self.ok(o.get("/m/reports.csv?kind=week"))
        self.assertIn("سارة العتيبي", csvr.text)
        self.assertEqual(o.get("/m/report/999999/2026-01-01").status, 404)
        self.assertEqual(o.get(f"/m/report/{uid}/not-a-date").status, 404)
        self.__class__.uid_sara, self.__class__.day = uid, day

    def test_12_correct_a_result(self):
        o = self.owner
        con = self.db()
        att = con.execute("SELECT a.* FROM call_attempts a WHERE a.outcome='no_answer'").fetchone()
        back = f"/m/report/{self.uid_sara}/{self.day}"
        no_reason = o.post(f"/m/correct/{att['id']}", {"new": "phone_off", "reason": "x", "back": back})
        self.assertIn("سبب التصحيح", o.follow(no_reason).text)
        r = o.post(f"/m/correct/{att['id']}", {"new": "phone_off", "reason": "سمعتُ الرنين يُغلق فوريًا، الهاتف مغلق", "back": back})
        self.assertEqual(r.status, 303)
        self.assertIn("صُحّحت النتيجة", o.follow(r).text)
        con = self.db()
        self.assertEqual(con.execute("SELECT COUNT(*) FROM corrections").fetchone()[0], 1)
        self.assertEqual(con.execute("SELECT outcome FROM call_attempts WHERE id=?", (att["id"],)).fetchone()[0], "no_answer", "the original is never overwritten")
        self.assertEqual(con.execute("SELECT status FROM leads WHERE id=?", (att["lead_id"],)).fetchone()[0], "phone_off", "the client follows the corrected result")
        reps = con.execute("SELECT version, reason FROM daily_reports ORDER BY version").fetchall()
        self.assertEqual([r["version"] for r in reps], [1, 2])
        self.assertEqual(reps[1]["reason"], "correction")
        page = self.ok(o.get(back))
        self.assertIn("مُصحَّح", page.text)
        same = o.post(f"/m/correct/{att['id']}", {"new": "phone_off", "reason": "نفس النتيجة تمامًا", "back": back})
        self.assertIn("النتيجة الحالية", o.follow(same).text)
        later = o.post(f"/m/correct/{att['id']}", {"new": "call_later", "reason": "يطلب موعدًا لاحقًا", "back": back})
        self.assertIn("موعدًا", o.follow(later).text)
        # the triggers refuse any attempt to rewrite history, even straight in the database
        with self.assertRaises(sqlite3.DatabaseError):
            con.execute("UPDATE corrections SET reason='x'")
        with self.assertRaises(sqlite3.DatabaseError):
            con.execute("DELETE FROM events")
        with self.assertRaises(sqlite3.DatabaseError):
            con.execute("UPDATE daily_reports SET data='{}'")

    def test_13_reopen_day(self):
        o = self.owner
        back = f"/m/report/{self.uid_sara}/{self.day}"
        r = o.post(f"{back}/reopen", {"why": ""})
        self.assertIn("سبب", o.follow(r).text)
        r = o.post(f"{back}/reopen", {"why": "نسيت تسجيل مكالمتين بعد الإغلاق"})
        self.assertIn("أُعيد فتح اليوم", o.follow(r).text)
        self.assertEqual(self.db().execute("SELECT status FROM shifts").fetchone()[0], "open")
        s = self.emp["sara"]
        self.ok(s.get("/w"))
        s.post("/w/end", {"all_reason": "no_time", "note": ""})
        self.assertEqual(self.db().execute("SELECT status FROM shifts").fetchone()[0], "closed")
        self.assertEqual(self.db().execute("SELECT COUNT(*) FROM daily_reports").fetchone()[0], 3, "each close seals a new version; none is replaced")

    # ------------------------------------------------------------------------------------------ 14 comparison with the platform
    def test_14_compare(self):
        o = self.owner
        self.ok(o.get("/m/compare"))
        today = self.day
        r = o.post("/m/compare/daily", {"day": today, "owners": "120", "approved_ads": "200", "views": "5000", "wa_clicks": "300", "note": "من لوحة الإدارة"})
        self.assertIn("حُفظت أرقام استراحتي", o.follow(r).text)
        r = o.post("/m/compare/daily", {"day": today, "owners": "abc", "approved_ads": "1", "views": "1", "wa_clicks": "1"})
        self.assertIn("اكتب رقمًا صحيحًا", o.follow(r).text)
        con = self.db()
        leads = {r["name"]: r for r in con.execute("SELECT * FROM leads")}
        called = [r for r in leads.values() if r["attempts"]]
        self.assertGreaterEqual(len(called), 5)
        interested = next(r for r in leads.values() if r["status"] == "interested")
        untouched = next(r for r in leads.values() if r["attempts"] == 0 and r["line_type"] == "mobile" and r["owner_id"] is None)
        # the platform's times are Riyadh time (UTC+3); the stored ones are UTC. The registration times below are worked out from the real call times,
        # so the story reads the same whatever hour the suite runs at.
        def contacts_of(lead_id: int) -> list[datetime]:
            stamps = [r[0] for r in con.execute("SELECT started_at FROM call_attempts WHERE lead_id=? AND status='recorded'", (lead_id,))]
            stamps += [r[0] for r in con.execute("SELECT ts FROM events WHERE lead_id=? AND type='link.sent'", (lead_id,))]
            return sorted(datetime.strptime(x[:19], "%Y-%m-%dT%H:%M:%S") + timedelta(hours=3) for x in stamps)

        def shown(t: datetime) -> str:
            return t.strftime("%Y-%m-%d %H:%M")
        minute = timedelta(minutes=1)
        reg_after = shown(contacts_of(interested["id"])[-1] + minute)
        earlier = next(r for r in called if r["id"] != interested["id"] and r["status"] != "link_sent" and r["id"] != untouched["id"])
        reg_before = shown(contacts_of(earlier["id"])[0] - minute)
        table = ("الاسم\tالجوال\tالإعلانات\tالموافقات\tالتسجيل\tالحالة\n"
                 f"{interested['name']}\t{interested['phone'].replace('+966', '0')}\t2\t1\t{reg_after}\tنشط\n"          # registered a minute after the last call -> ours
                 f"{earlier['name']}\t{earlier['phone'].replace('+966', '0')}\t1\t1\t{reg_before}\tنشط\n"              # registered a minute before the first call -> nobody's
                 f"{untouched['name']}\t{untouched['phone'].replace('+966', '0')}\t1\t0\t{today} 10:00\tنشط\n"           # nobody called -> registered before contact
                 "مالك غريب\t0599999999\t3\t3\t2026-10-01 09:00\tنشط\n")                                               # not one of ours
        r = o.post("/m/compare/paste", {"text": table})
        self.assertEqual(r.status, 303, r.text[:300])
        page = self.ok(o.follow(r))
        self.assertIn("يُحسب للموظف", page.text)
        self.assertIn("سجّل قبل التواصل", page.text)
        self.assertIn("لم يُطابَق", page.text)
        con = self.db()
        row = con.execute("SELECT verdict, detail, reg_time FROM ext_rows WHERE lead_id=? ORDER BY id DESC LIMIT 1", (earlier["id"],)).fetchone()
        self.assertEqual(row["verdict"], "before", "registered a minute before the first call: nobody's, even on the same day")
        self.assertIn("أول تواصل", row["detail"])
        self.assertEqual(row["reg_time"], reg_before[-5:])
        lead = con.execute("SELECT * FROM leads WHERE id=?", (interested["id"],)).fetchone()
        self.assertEqual(lead["status"], "registered_confirmed")
        self.assertEqual(json.loads(lead["attribution"])["user"], self.uid_sara)
        confirmed = con.execute("SELECT * FROM events WHERE type='lead.confirmed'").fetchall()
        self.assertEqual(len(confirmed), 1)
        self.assertEqual(confirmed[0]["user_id"], self.uid_sara)
        # pasting the same table again changes nothing
        r2 = o.post("/m/compare/paste", {"text": table})
        self.assertIn("مؤكد سابقًا", o.follow(r2).text)
        self.assertEqual(self.db().execute("SELECT COUNT(*) FROM events WHERE type='lead.confirmed'").fetchone()[0], 1)
        # link the unmatched owner by hand to a client Sara called
        rid = con.execute("SELECT id FROM ext_rows WHERE verdict='unmatched' ORDER BY id LIMIT 1").fetchone()[0]
        imp = con.execute("SELECT import_id FROM ext_rows WHERE id=?", (rid,)).fetchone()[0]
        target = next(r for r in leads.values() if r["status"] == "link_sent")
        bad = o.post(f"/m/compare/row/{rid}/link", {"q": "0500000000"})
        self.assertIn("لا أجد عميلًا", o.follow(bad).text)
        good = o.post(f"/m/compare/row/{rid}/link", {"q": f"#{target['id']}"})
        self.assertIn("رُبط الصف", o.follow(good).text)
        row = self.db().execute("SELECT * FROM ext_rows WHERE id=?", (rid,)).fetchone()
        self.assertEqual(row["verdict"], "before", "the owner registered months before any contact, so it is nobody's")
        self.assertEqual(row["linked_by"], 1)
        self.assertEqual(self.db().execute("SELECT COUNT(*) FROM events WHERE type='compare.linked'").fetchone()[0], 1)
        funnel = self.ok(o.get("/m/compare"))
        self.assertIn("قمع الفريق", funnel.text)
        self.ok(o.get(f"/m/compare/import/{imp}"))
        week = self.ok(o.get("/m/reports"))
        self.assertIn("سارة العتيبي", week.text)

    # ------------------------------------------------------------------------------------------ 15 work phones
    def test_15_devices_api(self):
        o = self.owner
        host = f"http://127.0.0.1:{self.srv.port}"

        def api(path, data=None, token=None):
            req = urllib.request.Request(host + path, data=json.dumps(data).encode() if data is not None else None,
                                         headers={"Content-Type": "application/json", **({"Authorization": f"Bearer {token}"} if token else {})})
            try:
                with urllib.request.urlopen(req, timeout=10) as resp:
                    return resp.status, json.loads(resp.read())
            except urllib.error.HTTPError as ex:
                return ex.code, json.loads(ex.read())

        self.ok(o.get("/m/devices"))
        page = self.ok(o.post("/m/devices/code", {"user": str(self.uid_sara), "note": "جوال العمل 1"}))
        m = re.search(r'class="code-big ltr">([a-z0-9]{4}-[a-z0-9]{4})<', page.text)
        self.assertTrue(m, "the one-time code is shown once")
        code = m.group(1)
        self.assertEqual(api("/api/v1/enroll", {"code": "zzzz-zzzz"})[0], 403)
        status, res = api("/api/v1/enroll", {"code": code, "name": "جوال العمل 1", "model": "Pixel 7", "app_version": "0.1"})
        self.assertEqual(status, 200, res)
        token = res["token"]
        self.assertEqual(api("/api/v1/enroll", {"code": code})[0], 403, "a code works once")
        self.assertEqual(api("/api/v1/ping", token="nope-nope-nope-nope-nope")[0], 401)
        self.assertEqual(api("/api/v1/ping", token=token)[0], 200)
        # a fresh attempt by Sara that the phone can confirm (the day is open again after test_13? it is closed: open it)
        con = self.db()
        con.close()
        s = self.emp["sara"]
        o.post(f"/m/report/{self.uid_sara}/{self.day}/reopen", {"why": "اختبار ربط الجهاز"})
        s.get("/w")
        lead = self.db().execute("SELECT id, phone FROM leads WHERE status='new' AND owner_id=? LIMIT 1", (self.uid_sara,)).fetchone()
        self.assertIsNotNone(lead)
        self.assertEqual(s.post(f"/w/lead/{lead['id']}/call").status, 204)
        import datetime as dt
        now = dt.datetime.now(dt.timezone.utc)
        calls = [
            {"number": lead["phone"], "started_at": now.isoformat(), "duration_sec": 42, "type": "outgoing"},
            {"number": "0500000099", "started_at": now.isoformat(), "duration_sec": 5, "type": "outgoing"},  # a personal call: dropped, never stored
            {"number": lead["phone"], "started_at": "not a time", "duration_sec": 5, "type": "outgoing"},
        ]
        status, res = api("/api/v1/calls", {"calls": calls}, token)
        self.assertEqual(status, 200, res)
        self.assertEqual((res["stored"], res["matched"], res["ignored"]), (1, 1, 2), res)
        con = self.db()
        att = con.execute("SELECT * FROM call_attempts WHERE lead_id=? ORDER BY id DESC", (lead["id"],)).fetchone()
        self.assertEqual(att["evidence"], 2)
        self.assertEqual(att["duration_sec"], 42)
        self.assertEqual(con.execute("SELECT COUNT(*) FROM device_calls").fetchone()[0], 1, "only calls to our clients are ever stored")
        self.assertEqual(api("/api/v1/calls", {"calls": calls}, token)[1]["duplicate"], 1, "sending twice stores once")
        status, w = api("/api/v1/watch", token=token)
        self.assertEqual(status, 200)
        self.assertGreater(w["count"], 5)
        self.assertEqual(len(w["hashes"][0]), 12)
        # revoke: the token stops working
        did = con.execute("SELECT id FROM devices").fetchone()[0]
        self.assertIn("أُلغي ربط", o.follow(o.post(f"/m/devices/{did}/revoke")).text)
        self.assertEqual(api("/api/v1/ping", token=token)[0], 401)
        s.post(f"/w/lead/{lead['id']}/outcome", {"outcome": "no_answer"})
        s.post("/w/end", {"all_reason": "no_time", "note": ""})

    # ------------------------------------------------------------------------------------------ 16 log, exports, backups
    def test_16_log_exports_backups(self):
        o = self.owner
        page = self.ok(o.get("/m/log"))
        self.assertIn("سجل العمليات", page.text)
        self.ok(o.get("/m/log?g=call"))
        self.ok(o.get(f"/m/log?u={self.uid_sara}&day={self.day}"))
        v = o.post("/m/log/verify")
        self.assertIn("السجل سليم", o.follow(v).text)
        for f in ("leads", "calls", "events"):
            r = self.ok(o.get(f"/m/export/{f}.csv"))
            self.assertTrue(r.text.startswith("﻿"))
        self.ok(o.get("/m/export"))
        self.ok(o.get("/m/backups"))
        r = o.post("/m/backups/make")
        self.assertIn("تمت النسخة", o.follow(r).text)
        r = o.post("/m/backups/test")
        self.assertIn("الاسترجاع سليم", o.follow(r).text)
        dl = self.ok(o.get("/m/backups"))
        m = re.search(r'/m/backups/(\d+)/download', dl.text)
        self.assertTrue(m)
        self.assertEqual(self.ok(o.get(f"/m/backups/{m.group(1)}/download")).body[:2], b"\x1f\x8b", "a gzip file")

    # ------------------------------------------------------------------------------------------ 17 permissions and safety
    def test_17_permissions(self):
        o = self.owner
        r = o.post("/m/team/new", {"name": "مدير الفريق", "username": "mgr1", "perm_dashboard.view": "1", "perm_leads.view": "1"})
        self.ok(r)
        pw = temp_password(r.text)
        mg = Client(port=self.srv.port)
        mg.post("/login", {"username": "mgr1", "password": pw})
        mg.get("/password")
        mg.post("/password", {"current": pw, "new": "Mgr-pass-2026-x", "again": "Mgr-pass-2026-x"})
        self.ok(mg.get("/m"))
        self.ok(mg.get("/m/leads"))
        for path in ("/m/reports", "/m/settings", "/m/import", "/m/employees", "/m/devices", "/m/log", "/m/compare", "/m/team", "/m/export"):
            self.assertEqual(mg.get(path).status, 403, path)
        self.assertEqual(mg.get("/m/backups").status, 403, "backups belong to the platform operator")
        # an employee can never reach a manager page, nor another employee's data
        s = self.emp["sara"]
        self.assertEqual(s.get("/m/leads").location, "/w")
        other = self.db().execute("SELECT id FROM leads WHERE owner_id IS NULL AND status='new' LIMIT 1").fetchone()[0]
        self.assertNotEqual(s.get(f"/w/lead/{other}").status, 200, "a client that is not in your list is not yours to open")

    def test_18_csrf_and_origin(self):
        o = self.owner
        o.get("/m/employees/new")
        no_token = o.post("/m/employees/new", {"name": "x", "username": "nottoken"}, csrf=False)
        self.assertEqual(no_token.status, 403)
        cross = o.post("/m/employees/new", {"name": "x", "username": "crosssite"}, headers={"Sec-Fetch-Site": "cross-site"})
        self.assertEqual(cross.status, 403)
        self.assertEqual(self.db().execute("SELECT COUNT(*) FROM users WHERE username IN ('nottoken','crosssite')").fetchone()[0], 0)

    LEAK = re.compile(r"&lt;/?(?:span|a|div|input|td|th|tr|b|strong|label|form|small|svg|p|ul|li|button|select|option|br|bdi|details|summary)\b")

    def test_18b_pages_render_cleanly_and_wide_tables_stack(self):
        """Looking at the pages on a phone found markup shown as text and tables cut off at the edge. These checks keep both from coming back."""
        o, con = self.owner, self.db()
        uid = con.execute("SELECT id FROM users WHERE username='sara'").fetchone()[0]
        day = con.execute("SELECT work_date FROM shifts").fetchone()[0]
        manager_pages = ["/m", "/m/employees", f"/m/employee/{uid}", "/m/leads", "/m/leads?status=interested", "/m/import", "/m/distribute",
                         "/m/reports?kind=day", "/m/reports?kind=week", "/m/reports?kind=month", f"/m/reports/employee/{uid}", f"/m/report/{uid}/{day}",
                         "/m/compare", "/m/settings", "/m/devices", "/m/log", "/m/export", "/m/backups", "/m/team", "/p", "/m/drill/calls"]
        for path in manager_pages:
            html = self.ok(o.get(path)).text
            self.assertIsNone(self.LEAK.search(html), f"escaped markup is showing as text on {path}: {self.LEAK.search(html) and html[self.LEAK.search(html).start() - 60:self.LEAK.search(html).end() + 60]}")
            for th in re.findall(r"<th>(.*?)</th>", html):
                self.assertNotIn("<", th, f"a table header carries markup on {path}")
        for user in ("sara",):  # her day is closed, so the task list redirects home; these pages are all reachable
            for path in ("/w", "/w/me", "/w/search?q=%D8%A7", f"/w/day/{day}"):
                r = self.emp[user].get(path)
                self.assertEqual(r.status, 200, f"{user} {path} -> {r.status} {r.location}")
                self.assertIsNone(self.LEAK.search(r.text), f"escaped markup on {path} for {user}")
        # the week report compares with the week before: its arrows are real elements
        week = self.ok(o.get("/m/reports?kind=week")).text
        self.assertIn('class="delta', week)
        # five columns or more: each cell names its column and the table turns into cards on a phone
        for path in ("/m/employees", "/m/leads", "/m/log"):
            html = self.ok(o.get(path)).text
            self.assertIn('<div class="tw cards">', html, path)
            self.assertRegex(html, r'<td data-l="[^"]+"', path)
        # a short table keeps its table layout
        self.assertIn('<div class="tw">', self.ok(o.get(f"/m/report/{uid}/{day}")).text)
        # the select-all box sits above the leads table, not inside a header cell
        leads = self.ok(o.get("/m/leads")).text
        self.assertIn('data-select-all="input[name=ids]"', leads)
        self.assertNotIn("<th><input", leads)

    def test_19_markup_is_escaped_everywhere(self):
        """Names, notes and cities are typed by strangers. Whatever they contain must come out as text on every page."""
        o = self.owner
        evil = '<script>alert(1)</script>"\'><img src=x onerror=alert(2)>'
        rows = [["الاسم", "الجوال", "المدينة"], [evil, "0561234567", evil]]
        r = o.upload("/m/import/upload", "evil.csv", csv_bytes(rows))
        bid = int(r.location.rsplit("/", 1)[1])
        pages = [o.get(r.location).text]
        o.post(f"/m/import/{bid}/map", {"m_name": "0", "m_phone": "1", "m_city": "2", "has_header": "1"})
        pages.append(o.get(f"/m/import/{bid}").text)
        o.post(f"/m/import/{bid}/commit")
        lead_id = self.db().execute("SELECT id FROM leads WHERE phone='+966561234567'").fetchone()[0]
        for path in (f"/m/lead/{lead_id}", "/m/leads", f"/m/leads?q={'x'}", "/m/distribute", "/m", f"/m/import/{bid}", "/m/import"):
            pages.append(self.ok(o.get(path)).text)
        # as an employee note and in the log
        for html in pages:
            self.assertNotIn("<script>alert(1)", html)
            self.assertNotIn("<img src=x", html)
        self.assertIn("&lt;script&gt;", "".join(pages))
        # the query string is escaped too
        for path in ("/m/leads?q=%3Cscript%3Ealert(1)%3C/script%3E", "/m/log?day=%22%3E%3Cscript%3E", "/login?next=%22%3E%3Cscript%3E"):
            html = o.get(path).text
            self.assertNotIn("<script>alert(1)", html)
            self.assertNotIn('"><script>', html)

    def test_20_security_headers_and_static(self):
        anon = Client(port=self.srv.port)
        r = anon.get("/login")
        h = r.headers
        self.assertIn("default-src 'self'", h.get("content-security-policy", ""))
        self.assertEqual(h.get("x-content-type-options"), "nosniff")
        self.assertIn("frame-ancestors 'none'", h.get("content-security-policy", ""))
        self.assertNotIn("<script>", re.sub(r'<script src="[^"]+" defer></script>', "", r.text), "no inline scripts")
        css = anon.get("/static/app.css?v=1")
        self.assertEqual(css.status, 200)
        self.assertEqual(anon.get("/static/../minjaz/db.py").status, 404)
        self.assertEqual(anon.get("/static/%2e%2e/db.py").status, 404)
        self.assertEqual(anon.get("/m").location.split("?")[0], "/login", "pages need a session")
        self.assertEqual(json.loads(anon.get("/healthz").text)["ok"], True)

    def test_20b_distribute_by_hand(self):
        """The manager gives chosen numbers (a city, a file) to chosen employees before anyone pulls them."""
        o, con = self.owner, self.db()
        sara = con.execute("SELECT id FROM users WHERE username='sara'").fetchone()[0]
        khaled = con.execute("SELECT id FROM users WHERE username='khaled'").fetchone()[0]
        boss = con.execute("SELECT id FROM users WHERE username='boss'").fetchone()[0]
        city = "المدينة المنورة"
        rows = [["الاسم", "الجوال", "المدينة"]] + [[f"منوّرة {i}", f"0562000{i:03d}", city] for i in range(1, 10)] + [["أرضي منوّرة", "0148000011", city]]
        r = o.upload("/m/import/upload", "madinah.csv", csv_bytes(rows))
        bid = int(r.location.rsplit("/", 1)[1])
        o.follow(o.post(f"/m/import/{bid}/map", {"m_name": "0", "m_phone": "1", "m_city": "2", "has_header": "1"}))
        self.assertIn("أُضيف 10", o.follow(o.post(f"/m/import/{bid}/commit")).text)
        in_pool = "SELECT COUNT(*) FROM leads WHERE city=? AND owner_id IS NULL AND status='new' AND line_type='mobile'"
        self.assertEqual(con.execute(in_pool, (city,)).fetchone()[0], 9)

        page = self.ok(o.get("/m/distribute")).text
        self.assertIn(f"{city} (9)", page, "the city list counts only numbers an employee could be given")
        self.assertIn("madinah.csv", page)

        # nothing chosen, or nothing asked for: told so, nothing moves
        self.assertIn("اختر موظفًا", o.follow(o.post("/m/distribute", {"total": "5", "city": city})).text)
        self.assertIn("اختر موظفًا", o.follow(o.post("/m/distribute", {"emp": [sara], "total": "0", "city": city})).text)
        self.assertIn("لا توجد أرقام مطابقة", o.follow(o.post("/m/distribute", {"emp": [sara], "total": "5", "city": "مدينة لا عملاء فيها"})).text)
        self.assertIn("لا توجد أرقام مطابقة", o.follow(o.post("/m/distribute", {"emp": [boss, 99999], "total": "5", "city": city})).text,
                      "a manager, or someone who does not exist, cannot be given numbers")
        self.assertEqual(con.execute(in_pool, (city,)).fetchone()[0], 9)

        # five numbers from that city, shared between two employees
        done = o.follow(o.post("/m/distribute", {"emp": [sara, khaled], "total": "5", "city": city})).text
        self.assertIn("وُزّع 5 رقمًا على 2 موظفين", done)
        mine = {u: con.execute("SELECT COUNT(*) FROM leads WHERE city=? AND owner_id=?", (city, u)).fetchone()[0] for u in (sara, khaled)}
        self.assertEqual(sorted(mine.values()), [2, 3], "an odd number is shared as evenly as it can be")
        self.assertEqual(con.execute(in_pool, (city,)).fetchone()[0], 4)
        landline = con.execute("SELECT owner_id FROM leads WHERE phone='+966148000011'").fetchone()
        self.assertIsNone(landline[0], "a landline is not handed out while landlines are switched off")
        self.assertEqual(con.execute("SELECT COUNT(*) FROM assignments WHERE reason='manual' AND by_user_id=? AND ended_at IS NULL", (boss,)).fetchone()[0], 5)
        events = [json.loads(r["data"]) | {"user": r["user_id"]} for r in con.execute("SELECT * FROM events WHERE type='lead.assigned' ORDER BY seq DESC LIMIT 2")]
        self.assertEqual(sorted(e["count"] for e in events), [2, 3])
        self.assertEqual({e["reason"] for e in events}, {"manual"})
        self.assertEqual({e["user"] for e in events}, {sara, khaled})
        one = con.execute("SELECT id FROM leads WHERE city=? AND owner_id=? LIMIT 1", (city, sara)).fetchone()[0]
        self.assertIn("سارة العتيبي", self.ok(o.get(f"/m/lead/{one}")).text)

        # asking for more than is left gives what is left, once; the same numbers cannot be handed out twice
        self.assertIn("وُزّع 4 رقمًا على 1 موظفين", o.follow(o.post("/m/distribute", {"emp": [khaled], "total": "100", "city": city})).text)
        self.assertEqual(con.execute(in_pool, (city,)).fetchone()[0], 0)
        self.assertIn("لا توجد أرقام مطابقة", o.follow(o.post("/m/distribute", {"emp": [sara], "total": "5", "city": city})).text)
        self.assertEqual(con.execute("SELECT COUNT(*) FROM leads WHERE city=? AND owner_id IS NOT NULL", (city,)).fetchone()[0], 9)
        self.assertEqual(con.execute("SELECT COUNT(*) FROM (SELECT lead_id FROM assignments WHERE ended_at IS NULL GROUP BY lead_id HAVING COUNT(*)>1)").fetchone()[0], 0,
                         "no client is open in two people's lists")

        # who may do it: a manager without the permission, and an employee, are turned away; nothing moves
        before = con.execute("SELECT COUNT(*) FROM assignments").fetchone()[0]
        mg = Client(port=self.srv.port)
        mg.post("/login", {"username": "mgr1", "password": "Mgr-pass-2026-x"})
        self.assertEqual(mg.get("/m/distribute").status, 403)
        self.assertEqual(mg.post("/m/distribute", {"emp": [sara], "total": "5"}).status, 403)
        s = self.emp["sara"]
        self.assertEqual(s.get("/m/distribute").location, "/w")
        self.assertNotEqual(s.post("/m/distribute", {"emp": [sara], "total": "5"}).status, 200)
        self.assertEqual(con.execute("SELECT COUNT(*) FROM assignments").fetchone()[0], before)

    def test_21_chain_is_intact_at_the_end(self):
        con = self.db()
        prev = "0" * 64
        n = 0
        import hashlib
        for r in con.execute("SELECT * FROM events WHERE company_id=1 ORDER BY seq"):
            n += 1
            self.assertEqual(r["seq"], n)
            self.assertEqual(r["prev_hash"], prev)
            raw = f"{prev}|{r['company_id']}|{r['seq']}|{r['ts']}|{r['day']}|{r['type']}|{r['actor_id']}|{r['user_id']}|{r['lead_id']}|{r['shift_id']}|{r['ref_id']}|{r['data']}"
            self.assertEqual(r["hash"], hashlib.sha256(raw.encode()).hexdigest())
            prev = r["hash"]
        self.assertGreater(n, 40)
        log = self.srv.log()
        self.assertNotIn("Traceback", log, log[-1500:])


if __name__ == "__main__":
    unittest.main(verbosity=2)
