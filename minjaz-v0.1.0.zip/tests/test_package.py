"""The release zip holds only what is allowed, is the same bytes every time, keeps the scripts runnable, and is not built at all when a file
looks like it holds a secret or does not even parse. (Skipped where the packager is not shipped: it is a tool for whoever builds the release.)"""
from __future__ import annotations

import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PACKAGER = ROOT / "scripts" / "package.py"


def build(packager: Path, out: Path) -> subprocess.CompletedProcess:
    return subprocess.run([sys.executable, str(packager), "--out", str(out)], capture_output=True, text=True, cwd=packager.parent.parent)


@unittest.skipUnless(PACKAGER.exists(), "the packager is not part of the release")
class Package(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = Path(tempfile.mkdtemp(prefix="minjaz-pkg-"))

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp, ignore_errors=True)

    def copy_project(self) -> Path:
        dest = Path(tempfile.mkdtemp(dir=self.tmp)) / "project"
        shutil.copytree(ROOT, dest, ignore=shutil.ignore_patterns(".git", "__pycache__", "*.pyc", "*.zip"))
        return dest

    def test_the_zip_holds_exactly_what_is_allowed_and_is_identical_every_time(self):
        first, second = build(PACKAGER, self.tmp / "a"), build(PACKAGER, self.tmp / "b")
        self.assertEqual((first.returncode, second.returncode), (0, 0), first.stderr + second.stderr)
        path1, sha1, _ = first.stdout.splitlines()
        _, sha2, _ = second.stdout.splitlines()
        self.assertEqual(sha1, sha2, "the same files must give the same archive")
        with zipfile.ZipFile(path1) as z:
            names = z.namelist()
            for must in ("install.sh", "web.sh", "docker-compose.yml", "Dockerfile", ".env.example", "README.md", "minjaz/__init__.py", "minjaz/app.py",
                         "minjaz/static/app.css", "tests/test_logic.py"):
                self.assertIn(must, names)
            bad = [n for n in names if "__pycache__" in n or n.endswith((".pyc", ".db", ".zip", ".gz", ".log")) or n.startswith(("scripts/", "backups/", "data/", ".git/"))
                   or (Path(n).name.startswith(".env") and n != ".env.example") or n in (".state",)]
            self.assertEqual(bad, [], "files that must never be released")
            for n in names:
                mode = (z.getinfo(n).external_attr >> 16) & 0o777
                self.assertEqual(bool(mode & 0o100), n in ("install.sh", "web.sh", "status.sh", "backup.sh", "restore.sh", "uninstall.sh"), f"{n} {oct(mode)}")
            self.assertEqual({z.getinfo(n).date_time for n in names}, {(2026, 11, 3, 0, 0, 0)}, "fixed timestamps")
            self.assertIsNone(z.testzip())
        self.assertIn("minjaz-v0.1.0.zip", path1)

    def refused(self, edit, why: str) -> None:
        project = self.copy_project()
        edit(project)
        out = self.tmp / "out"
        done = build(project / "scripts" / "package.py", out)
        self.assertNotEqual(done.returncode, 0, "the build must stop")
        self.assertIn(why, done.stderr)
        self.assertEqual(list(out.glob("*.zip")) if out.exists() else [], [], "and leave no zip behind")

    def test_a_private_key_in_any_file_stops_the_build(self):
        def edit(p: Path) -> None:
            with (p / "minjaz" / "util.py").open("a", encoding="utf-8") as f:
                f.write("\n# " + "-----BEGIN RSA " + "PRIVATE KEY-----\n")
        self.refused(edit, "private key")

    def test_a_cloud_or_chat_token_in_a_test_file_stops_the_build(self):
        def edit(p: Path) -> None:
            with (p / "tests" / "test_logic.py").open("a", encoding="utf-8") as f:
                f.write("\nTOKEN = '" + "AKIA" + "ABCDEFGHIJKLMNOP" + "'\n")
        self.refused(edit, "AWS access key")

    def test_a_setting_that_holds_a_secret_stops_the_build(self):
        def edit(p: Path) -> None:
            with (p / ".env.example").open("a", encoding="utf-8") as f:
                f.write("\nAPI_TOKEN=abcdefgh12345678\n")
        self.refused(edit, "looks like a secret")

    def test_a_long_secret_literal_in_python_source_stops_the_build(self):
        def edit(p: Path) -> None:
            with (p / "minjaz" / "config.py").open("a", encoding="utf-8") as f:
                f.write("\nAPI_KEY = 'q8Zk3VbN7xLm2Pw9Rt'\n")
        self.refused(edit, "looks like a secret")

    def test_personal_details_stop_the_build(self):
        def edit(p: Path) -> None:
            with (p / "README.md").open("a", encoding="utf-8") as f:
                f.write("\nwrite to someone@" + "gmail.com\n")
        self.refused(edit, "personal details")

    def test_a_key_or_database_file_inside_the_app_folder_stops_the_build(self):
        def edit(p: Path) -> None:
            (p / "minjaz" / "server.key").write_text("x", encoding="utf-8")
        self.refused(edit, "must never be released")

    def test_a_file_that_does_not_parse_stops_the_build(self):
        def edit(p: Path) -> None:
            (p / "minjaz" / "util.py").write_text("def (:\n", encoding="utf-8")
        self.refused(edit, "util.py")

        def edit_sh(p: Path) -> None:
            (p / "install.sh").write_text("if then fi (\n", encoding="utf-8")
        self.refused(edit_sh, "install.sh")


if __name__ == "__main__":
    unittest.main()
