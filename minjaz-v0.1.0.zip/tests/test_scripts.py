"""The install and operation scripts, run for real in bash against a stand-in `docker` (tests/fake_docker.py) and a scratch folder.

The riskiest part is editing the web server's Caddyfile on a shared machine, so most of the tests are about that: the entry is added only after a
copy is saved and the old file is known to be valid, the new file is checked before the reload, and every way it can fail leaves the file exactly as it was."""
from __future__ import annotations

import gzip
import hashlib
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
KIT = ["install.sh", "web.sh", "status.sh", "backup.sh", "restore.sh", "uninstall.sh", ".env.example", "docker-compose.yml"]
DOMAIN = "minjaz.example.org"
MY_IP = "203.0.113.7"
CADDYFILE = """{
\temail admin@example.com
}

site-one.example.com {
\treverse_proxy edge-web-1:8000
}

site-two.example.net {
\treverse_proxy other-web:8090
}
"""


def container(image: str, networks: list[str], project: str, ports: list[str] | None = None, mounts: list | None = None, cmd: list[str] | None = None) -> dict:
    return {"image": image, "running": True, "networks": networks, "labels": {"com.docker.compose.project": project}, "ports": ports or [],
            "mounts": mounts or [], "cmd": cmd or [], "args": [], "logs": [], "health": "healthy"}


class Kit(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = Path(tempfile.mkdtemp(prefix="minjaz-kit-")).resolve()
        self.app, self.bin, self.state = self.tmp / "app", self.tmp / "bin", self.tmp / "state.json"
        self.caddyfile = self.tmp / "Caddyfile"
        self.caddyfile.write_text(CADDYFILE, encoding="utf-8")
        self.app.mkdir()
        self.bin.mkdir()
        for name in KIT:
            text = (ROOT / name).read_text(encoding="utf-8").replace("/opt/minjaz", str(self.app))
            (self.app / name).write_text(text, encoding="utf-8")
        shims = {
            "docker": f'#!/bin/sh\nexec {sys.executable} {ROOT / "tests" / "fake_docker.py"} "$@"\n',
            "sleep": "#!/bin/sh\nexit 0\n",
            "df": "#!/bin/sh\necho 'Filesystem 1M-blocks Used Available Use% Mounted'\necho 'fake 100000 1000 99000 1% /'\n",
            "hostname": f'#!/bin/sh\nif [ "$1" = "-I" ]; then echo "10.0.0.5 {MY_IP} "; else echo fake-host; fi\n',
            "getent": '#!/bin/sh\nfor pair in $(echo "$FAKE_DNS" | tr "," " "); do\n  if [ "${pair%%=*}" = "$2" ]; then echo "${pair#*=} STREAM $2"; exit 0; fi\ndone\nexit 2\n',
            "curl": '#!/bin/sh\nif [ "$FAKE_PUBLIC" = "1" ]; then echo \'{"ok": true, "version": "0.1.0"}\'; exit 0; fi\nexit 22\n',
        }
        for name, body in shims.items():
            (self.bin / name).write_text(body, encoding="utf-8")
            (self.bin / name).chmod(0o755)
        self.write_world()

    def tearDown(self) -> None:
        shutil.rmtree(self.tmp, ignore_errors=True)

    # ------------------------------------------------------------------------------------------ the pretend server
    def write_world(self, caddy_networks: list[str] | None = None, caddy_mounted: bool = True) -> None:
        mounts = [["bind", str(self.caddyfile), "/etc/caddy/Caddyfile"]] if caddy_mounted else []
        caddy_cmd = ["caddy", "run", "--config", "/etc/caddy/Caddyfile", "--adapter", "caddyfile"]
        world = {
            "containers": {
                "edge-caddy-1": container("caddy:2", caddy_networks or ["edge_default"], "edge", ["80/tcp -> 0.0.0.0:80", "443/tcp -> 0.0.0.0:443"], mounts, caddy_cmd),
                "edge-web-1": container("edge-web", ["edge_default"], "edge"),
                "other-web": container("other-site:local", ["other_default", "edge_default"], "other"),
            },
            "networks": {"bridge": {}, "edge_default": {"labels": {"com.docker.compose.project": "edge"}}, "other_default": {"labels": {"com.docker.compose.project": "other"}},
                         "extra_net": {}},
            "volumes": {}, "volume_files": {}, "calls": [],
        }
        self.state.write_text(json.dumps(world, ensure_ascii=False), encoding="utf-8")

    def world(self) -> dict:
        return json.loads(self.state.read_text(encoding="utf-8"))

    def calls(self) -> list[str]:
        return self.world()["calls"]

    def sh(self, script: str, *args: str, input: str = "", env: dict | None = None) -> subprocess.CompletedProcess:
        e = {**os.environ, "PATH": f"{self.bin}:{os.environ['PATH']}", "FAKE_STATE": str(self.state), "FAKE_DNS": f"{DOMAIN}={MY_IP}", **(env or {})}
        return subprocess.run(["bash", str(self.app / script), *args], input=input, capture_output=True, text=True, cwd=self.app, env=e, timeout=120)

    def ok(self, r: subprocess.CompletedProcess) -> subprocess.CompletedProcess:
        self.assertEqual(r.returncode, 0, f"stdout:\n{r.stdout}\nstderr:\n{r.stderr}")
        return r

    def fails(self, r: subprocess.CompletedProcess, why: str = "") -> subprocess.CompletedProcess:
        self.assertNotEqual(r.returncode, 0, f"expected a refusal:\n{r.stdout}")
        if why:
            self.assertIn(why, r.stdout + r.stderr)
        return r

    def installed(self) -> None:
        self.ok(self.sh("install.sh", input="y\n"))

    def proxied(self) -> None:
        self.installed()
        self.ok(self.sh("web.sh", "proxy", DOMAIN, input="n\n"))

    def state_value(self, key: str) -> str:
        path = self.app / ".state"
        if not path.exists():
            return ""
        m = re.search(rf"^{key}=(.*)$", path.read_text(encoding="utf-8"), re.M)
        return m.group(1) if m else ""

    def caddy_text(self) -> str:
        return self.caddyfile.read_text(encoding="utf-8")

    def caddy_calls(self, what: str) -> int:
        return sum(1 for c in self.calls() if c.startswith(f"exec edge-caddy-1 caddy {what}"))


# ================================================================================================ the scripts as text
class Static(Kit):
    def test_every_script_is_valid_bash(self):
        for name in ("install.sh", "web.sh", "status.sh", "backup.sh", "restore.sh", "uninstall.sh"):
            r = subprocess.run(["bash", "-n", str(ROOT / name)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, f"{name}: {r.stderr}")

    def test_the_scripts_never_name_another_project_or_use_blunt_docker_commands(self):
        blunt = re.compile(r"docker\s+(stop|restart|rm|kill|rmi\s+-f|system|container\s+(rm|prune|stop)|volume\s+(rm|prune)|network\s+(rm|prune)|prune|image\s+prune)\b")
        # a container, network, volume or image name written into a script must be MINJAZ's own; the web server's names are found at run time, never typed
        foreign = re.compile(r"(?<![\w./$-])(?!minjaz)[a-z][a-z0-9]*(?:-[a-z0-9]+)*-(?:web|caddy|site|db|app|proxy)(?:-\d+)?(?![\w-])|(?<![\w./$-])(?!minjaz)[a-z][a-z0-9]*_(?:default|data)(?![\w-])")
        for name in ("install.sh", "web.sh", "status.sh", "backup.sh", "restore.sh", "uninstall.sh"):
            text = (ROOT / name).read_text(encoding="utf-8")
            code = "\n".join(line for line in text.splitlines() if not line.lstrip().startswith("#"))
            self.assertEqual(foreign.findall(code), [], f"{name} names something that is not MINJAZ's")
            self.assertIsNone(blunt.search(code), f"{name} uses a command that could affect other containers: {blunt.search(code) and blunt.search(code).group(0)}")
            self.assertNotIn("--privileged", code)
            self.assertNotIn("rm -rf /", code)

    def test_the_guard_against_foreign_names_really_catches_them(self):
        foreign = re.compile(r"(?<![\w./$-])(?!minjaz)[a-z][a-z0-9]*(?:-[a-z0-9]+)*-(?:web|caddy|site|db|app|proxy)(?:-\d+)?(?![\w-])|(?<![\w./$-])(?!minjaz)[a-z][a-z0-9]*_(?:default|data)(?![\w-])")
        for bad in ("docker restart shop-web", "docker network connect shop_default x", "docker exec edge-caddy-1 caddy reload", "docker volume inspect blog_data"):
            self.assertTrue(foreign.search(bad), bad)
        for good in ("docker exec minjaz-web python", "docker network connect minjaz_default x", "docker volume inspect minjaz_minjaz_data", "docker rmi minjaz-app:local",
                     'docker exec "$caddy" caddy reload', "bash web.sh proxy", "the web server", "$APP_DIR/.env"):
            self.assertIsNone(foreign.search(good), good)

    def test_compose_publishes_no_port_and_locks_the_container_down(self):
        text = (ROOT / "docker-compose.yml").read_text(encoding="utf-8")
        for needle in ("read_only: true", "cap_drop:", "no-new-privileges:true", "mem_limit: 256m", "container_name: minjaz-web", "name: minjaz"):
            self.assertIn(needle, text)
        self.assertNotRegex(text, r"(?m)^\s*ports:")
        self.assertNotIn("privileged", text)
        self.assertNotIn("network_mode", text)
        self.assertNotIn("/var/run/docker.sock", text, "the container must never be given control of Docker")

    def test_the_env_template_holds_nothing_secret_and_every_name_is_one_the_app_reads(self):
        text = (ROOT / ".env.example").read_text(encoding="utf-8")
        names = set(re.findall(r"(?m)^([A-Z_]+)=", text))
        config_src = (ROOT / "minjaz" / "config.py").read_text(encoding="utf-8")
        for n in names:
            self.assertIn(f'"{n}"', config_src, f"{n} is in .env.example but the app never reads it")
        self.assertIsNone(re.search(r"(?i)(password|secret|token|key)\s*=\s*\S", text))


# ================================================================================================ install.sh
class Install(Kit):
    def test_first_install_builds_starts_and_shows_the_setup_code(self):
        r = self.ok(self.sh("install.sh", input="y\n"))
        self.assertIn("abcd-efgh-ijkl", r.stdout)
        self.assertIn("web.sh proxy", r.stdout)
        env = self.app / ".env"
        self.assertTrue(env.exists())
        self.assertEqual(env.stat().st_mode & 0o777, 0o600)
        self.assertEqual((self.app / "backups").stat().st_mode & 0o777, 0o700)
        w = self.world()
        self.assertTrue(w["containers"]["minjaz-web"]["running"])
        self.assertIn("compose up -d --build web", w["calls"])
        self.assertEqual([c for c in w["calls"] if c.startswith(("network", "exec edge", "stop"))], [], "nothing outside the project was touched")

    def test_a_second_run_is_an_update_that_keeps_settings(self):
        self.installed()
        before = (self.app / ".env").read_text(encoding="utf-8")
        r = self.ok(self.sh("install.sh"))
        self.assertIn("Keeping your existing settings", r.stdout)
        self.assertIn("Updated", r.stdout)
        self.assertEqual((self.app / ".env").read_text(encoding="utf-8"), before)
        self.assertNotIn("abcd-efgh-ijkl", r.stdout, "the setup code is shown once, on the first install")
        self.assertIn("bash install.sh code", r.stdout, "but an update before the owner account exists says how to get a new one")

    def test_answering_no_cancels_before_anything_happens(self):
        self.fails(self.sh("install.sh", input="n\n"), "cancelled")
        self.assertFalse((self.app / ".env").exists())
        self.assertNotIn("minjaz-web", self.world()["containers"])

    def test_a_name_that_belongs_to_another_project_stops_the_install(self):
        w = self.world()
        w["containers"]["minjaz-web"] = container("something", ["edge_default"], "someone-else")
        self.state.write_text(json.dumps(w), encoding="utf-8")
        self.fails(self.sh("install.sh", input="y\n"), "does not belong to this project")
        self.assertFalse((self.app / ".env").exists())
        self.assertFalse(any("up" in c for c in self.calls()))

    def test_too_little_free_memory_stops_a_first_start(self):
        meminfo = self.tmp / "meminfo"
        meminfo.write_text("MemTotal: 2000000 kB\nMemAvailable:  100000 kB\n", encoding="utf-8")
        self.fails(self.sh("install.sh", input="y\n", env={"MINJAZ_MEMINFO": str(meminfo)}), "memory")
        self.assertNotIn("minjaz-web", self.world()["containers"])

    def test_too_little_disk_stops_the_install(self):
        (self.bin / "df").write_text("#!/bin/sh\necho h\necho 'fake 100 99 500 99% /'\n", encoding="utf-8")
        self.fails(self.sh("install.sh", input="y\n"), "disk")
        self.assertNotIn("minjaz-web", self.world()["containers"])

    def test_a_new_setup_code_can_be_asked_for(self):
        self.fails(self.sh("install.sh", "code"), "not running")
        self.installed()
        self.assertIn("wxyz-1234-abcd", self.ok(self.sh("install.sh", "code")).stdout)
        self.fails(self.sh("install.sh", "nonsense"))

    def test_it_refuses_to_run_from_anywhere_but_its_own_folder(self):
        other = self.tmp / "elsewhere"
        other.mkdir()
        shutil.copy(self.app / "install.sh", other / "install.sh")
        r = subprocess.run(["bash", str(other / "install.sh")], capture_output=True, text=True, input="y\n", env={**os.environ, "PATH": f"{self.bin}:{os.environ['PATH']}", "FAKE_STATE": str(self.state)})
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("must live in", r.stderr)


# ================================================================================================ web.sh proxy / stop / status
class Proxy(Kit):
    def test_it_finds_the_web_servers_network_joins_it_and_leaves_the_caddyfile_alone(self):
        self.installed()
        before = self.caddy_text()
        r = self.ok(self.sh("web.sh", "proxy", DOMAIN, input="n\n"))
        self.assertIn("edge-caddy-1", r.stdout)
        self.assertIn("'edge_default'", r.stdout)
        self.assertIn(f"reverse_proxy minjaz-web:8095", r.stdout)
        env = (self.app / ".env").read_text(encoding="utf-8")
        self.assertIn(f"SITE_URL=https://{DOMAIN}", env)
        self.assertIn("REAL_IP_HEADER=X-Forwarded-For", env)
        self.assertEqual(self.state_value("ACCESS"), "proxy")
        self.assertEqual(self.state_value("PROXY_NETWORK"), "edge_default")
        w = self.world()
        self.assertIn("edge_default", w["containers"]["minjaz-web"]["networks"])
        self.assertEqual(self.caddy_text(), before, "answering no leaves the Caddyfile untouched")
        self.assertEqual(self.caddy_calls("validate") + self.caddy_calls("reload"), 0)
        for name in ("edge-caddy-1", "edge-web-1", "other-web"):
            self.assertTrue(w["containers"][name]["running"], name)
        self.assertEqual(w["containers"]["other-web"]["networks"], ["other_default", "edge_default"])

    def test_if_the_web_server_is_on_several_networks_it_asks_which(self):
        self.write_world(caddy_networks=["edge_default", "extra_net"])
        self.installed()
        r = self.ok(self.sh("web.sh", "proxy", DOMAIN, input="extra_net\nn\n"))
        self.assertIn("several networks", r.stdout)
        self.assertEqual(self.state_value("PROXY_NETWORK"), "extra_net")

    def test_it_stops_when_the_network_or_the_name_is_wrong(self):
        self.installed()
        self.fails(self.sh("web.sh", "proxy", DOMAIN, "no_such_net"), "no Docker network")
        self.fails(self.sh("web.sh", "proxy", DOMAIN, "bridge"), "not a network that can be used")
        self.fails(self.sh("web.sh", "proxy", "bad domain; rm -rf /", "edge_default"), "does not look like a domain")
        self.assertEqual(self.state_value("ACCESS"), "")

    def test_it_needs_minjaz_to_be_installed_and_running_first(self):
        self.fails(self.sh("web.sh", "proxy", DOMAIN), "not installed")

    def test_stop_disconnects_only_minjaz_from_the_network(self):
        self.proxied()
        self.ok(self.sh("web.sh", "stop"))
        w = self.world()
        self.assertNotIn("edge_default", w["containers"]["minjaz-web"]["networks"])
        self.assertEqual(w["containers"]["other-web"]["networks"], ["other_default", "edge_default"])
        self.assertEqual(self.state_value("ACCESS"), "off")

    def test_status_and_link_report_without_changing_anything(self):
        self.proxied()
        calls = len(self.calls())
        r = self.ok(self.sh("web.sh", "status"))
        self.assertIn("Connected to the network 'edge_default'", r.stdout)
        self.assertIn("was NOT added by this script yet", r.stdout)
        self.assertIn(f"https://{DOMAIN}", self.ok(self.sh("web.sh", "link")).stdout)
        s = self.ok(self.sh("status.sh"))
        self.assertIn("memory", s.stdout)
        self.assertEqual([c for c in self.calls()[calls:] if c.startswith(("compose -p minjaz up", "network", "stop"))], [])


# ================================================================================================ web.sh caddy / caddy-undo
class Caddy(Kit):
    def add(self, answers: str = "y\n", **env) -> subprocess.CompletedProcess:
        return self.sh("web.sh", "caddy", input=answers, env={"FAKE_PUBLIC": "1", **env})

    def test_the_entry_is_added_once_at_the_end_after_a_backup_and_the_new_file_is_checked_before_the_reload(self):
        self.proxied()
        original = self.caddy_text()
        r = self.ok(self.add())
        text = self.caddy_text()
        self.assertTrue(text.startswith(original), "everything that was there is untouched, the new block only follows it")
        block = text[len(original):]
        self.assertEqual(block.count("# >>> minjaz"), 1)
        self.assertIn(f"{DOMAIN} {{\n    reverse_proxy minjaz-web:8095\n}}", block)
        self.assertTrue(block.rstrip().endswith("# <<< minjaz <<<"))
        backups = list((self.app / "backups" / "caddy").glob("Caddyfile.*"))
        self.assertEqual(len(backups), 1)
        self.assertEqual(backups[0].read_text(encoding="utf-8"), original, "the saved copy is the file exactly as it was")
        self.assertEqual((self.app / "backups" / "caddy").stat().st_mode & 0o777, 0o700)
        self.assertEqual((self.tmp / "loaded.Caddyfile").read_text(encoding="utf-8"), text, "Caddy loaded the new file")
        order = [c for c in self.calls() if c.startswith("exec edge-caddy-1")]
        self.assertEqual([c.split()[3] for c in order], ["validate", "validate", "reload"], "the old file is checked, then the new one, then the reload")
        self.assertEqual(self.state_value("CADDY_FILE"), str(self.caddyfile))
        self.assertEqual(self.state_value("CADDY_BACKUP"), str(backups[0]))
        self.assertIn("Added, checked and reloaded", r.stdout)
        self.assertIn("/setup", r.stdout)
        self.fails(self.add(), "already added")
        self.assertEqual(self.caddy_text(), text, "a second run changes nothing")

    def test_it_can_be_offered_straight_from_proxy_in_one_go(self):
        self.installed()
        r = self.ok(self.sh("web.sh", "proxy", DOMAIN, input="y\ny\n", env={"FAKE_PUBLIC": "0"}))
        self.assertIn("Added, checked and reloaded", r.stdout)
        self.assertEqual(self.caddy_text().count("# >>> minjaz"), 1)

    def test_a_file_that_does_not_end_with_a_newline_still_gets_a_clean_block(self):
        self.caddyfile.write_text(CADDYFILE.rstrip("\n"), encoding="utf-8")
        self.proxied()
        self.ok(self.add())
        self.assertIn("}\n\n# >>> minjaz", self.caddy_text())

    def test_answering_no_changes_nothing(self):
        self.proxied()
        before = self.caddy_text()
        self.ok(self.add("n\n"))
        self.assertEqual(self.caddy_text(), before)
        self.assertEqual(self.state_value("CADDY_FILE"), "")
        self.assertFalse((self.app / "backups" / "caddy").exists())

    def test_a_domain_that_does_not_point_here_needs_a_second_yes(self):
        self.proxied()
        before = self.caddy_text()
        r = self.ok(self.add("n\n", FAKE_DNS=f"{DOMAIN}=9.9.9.9"))
        self.assertIn("WARNING", r.stdout)
        self.assertIn("Cancelled", r.stdout)
        self.assertEqual(self.caddy_text(), before)
        r = self.ok(self.add("y\ny\n", FAKE_DNS=f"{DOMAIN}=9.9.9.9"))
        self.assertIn("points at another address", r.stdout)
        self.assertIn("# >>> minjaz", self.caddy_text())
        self.ok(self.sh("web.sh", "caddy-undo", input="y\n"))
        self.assertNotIn("minjaz", self.caddy_text())
        r = self.ok(self.add("y\ny\n", FAKE_DNS=""))
        self.assertIn("does not resolve yet", r.stdout, "a name that is not in DNS at all gets its own warning")
        self.assertIn("# >>> minjaz", self.caddy_text())

    def test_if_caddy_rejects_the_new_entry_the_file_is_put_back_exactly(self):
        self.proxied()
        before = self.caddyfile.read_bytes()
        r = self.fails(self.add(FAKE_FAIL_IF_CONTAINS=DOMAIN), "put back exactly")
        self.assertEqual(self.caddyfile.read_bytes(), before)
        self.assertEqual([p.name for p in self.app.glob(".block.*")] + [p.name for p in self.app.glob(".validate.*")], [], "no temporary files are left behind")
        self.assertEqual(self.caddy_calls("reload"), 0, "a config that fails the check is never loaded")
        self.assertEqual(self.state_value("CADDY_FILE"), "")

    def test_if_the_reload_fails_the_file_is_put_back_and_the_old_settings_reloaded(self):
        self.proxied()
        before = self.caddyfile.read_bytes()
        self.fails(self.add(FAKE_RELOAD_FAIL="1"), "put back")
        self.assertEqual(self.caddyfile.read_bytes(), before)
        self.assertEqual(self.caddy_calls("reload"), 2, "the new config failed to load, then the old one was loaded again")
        self.assertEqual(self.state_value("CADDY_FILE"), "")

    def test_a_caddyfile_that_is_already_broken_is_not_touched(self):
        broken = "INVALID\n" + CADDYFILE
        self.caddyfile.write_text(broken, encoding="utf-8")
        self.proxied()
        self.fails(self.add(), "does not pass Caddy's own check")
        self.assertEqual(self.caddy_text(), broken)
        self.assertEqual(self.state_value("CADDY_FILE"), "")

    def test_a_domain_that_is_already_in_the_file_is_refused(self):
        self.caddyfile.write_text(CADDYFILE + f"\n{DOMAIN} {{\n\trespond \"hello\"\n}}\n", encoding="utf-8")
        self.proxied()
        before = self.caddy_text()
        self.fails(self.add(), "already mentions")
        self.assertEqual(self.caddy_text(), before)

    def test_when_the_file_cannot_be_edited_from_here_it_prints_the_entry_to_add_by_hand(self):
        self.write_world(caddy_mounted=False)
        self.proxied()
        r = self.ok(self.add())
        self.assertIn("by hand", r.stdout)
        self.assertIn("reverse_proxy minjaz-web:8095", r.stdout)
        self.assertEqual(self.caddy_calls("reload"), 0)

    def test_when_it_cannot_tell_which_container_is_the_web_server_it_changes_nothing(self):
        w = self.world()
        w["containers"]["other-caddy"] = container("caddy:2", ["edge_default"], "other", ["443/tcp -> 0.0.0.0:443"], [], [])
        self.state.write_text(json.dumps(w), encoding="utf-8")
        self.installed()
        asked = self.ok(self.sh("web.sh", "proxy", DOMAIN, input="edge_default\nn\n"))
        self.assertIn("Docker networks on this server", asked.stdout, "with two web servers it asks instead of guessing the network")
        before = self.caddy_text()
        r = self.ok(self.add())
        self.assertIn("could not tell which container", r.stdout)
        self.assertEqual(self.caddy_text(), before)

    # --- undo ------------------------------------------------------------------------------------------------------------------------
    def test_undo_removes_only_its_own_block_and_keeps_what_was_added_after_it(self):
        self.proxied()
        original = self.caddy_text()
        self.ok(self.add())
        with self.caddyfile.open("a", encoding="utf-8") as f:   # someone adds another site later
            f.write("\nnew-site.example.com {\n\trespond \"hi\"\n}\n")
        self.ok(self.sh("web.sh", "caddy-undo", input="y\n"))
        text = self.caddy_text()
        self.assertNotIn("minjaz", text)
        self.assertTrue(text.startswith(original.rstrip("\n")))
        self.assertIn("new-site.example.com", text, "what was added after our block is kept")
        self.assertEqual((self.tmp / "loaded.Caddyfile").read_text(encoding="utf-8"), text)
        self.assertEqual(self.state_value("CADDY_FILE"), "")
        self.assertEqual(len(list((self.app / "backups" / "caddy").glob("*before-undo"))), 1)

    def test_undo_refuses_a_block_somebody_has_edited(self):
        self.proxied()
        self.ok(self.add())
        text = self.caddy_text()
        self.caddyfile.write_text(text.replace("# <<< minjaz <<<", "# end"), encoding="utf-8")
        before = self.caddy_text()
        self.fails(self.sh("web.sh", "caddy-undo", input="y\n"), "whole MINJAZ block")
        self.assertEqual(self.caddy_text(), before)
        padded = text.replace("}\n# <<< minjaz <<<", "}\n" + "# other\n" * 20 + "# <<< minjaz <<<")
        self.caddyfile.write_text(padded, encoding="utf-8")
        self.fails(self.sh("web.sh", "caddy-undo", input="y\n"), "does not look the way")
        self.assertEqual(self.caddy_text(), padded)

    def test_undo_with_nothing_added_or_a_no_answer_changes_nothing(self):
        self.proxied()
        self.fails(self.sh("web.sh", "caddy-undo", input="y\n"), "nothing to undo")
        self.ok(self.add())
        after_add = self.caddy_text()
        self.ok(self.sh("web.sh", "caddy-undo", input="n\n"))
        self.assertEqual(self.caddy_text(), after_add)

    def test_if_the_file_without_the_block_is_rejected_undo_puts_it_back(self):
        self.proxied()
        self.ok(self.add())
        text = self.caddy_text()
        self.fails(self.sh("web.sh", "caddy-undo", input="y\n", env={"FAKE_FAIL_IF_CONTAINS": "site-one.example.com"}), "put back")
        self.assertEqual(self.caddy_text(), text)

    def test_uninstall_offers_to_take_the_entry_out_first(self):
        self.proxied()
        self.ok(self.add())
        r = self.ok(self.sh("uninstall.sh", input="y\n"))
        self.assertNotIn("minjaz", self.caddy_text())
        self.assertIn("MINJAZ was removed", r.stdout)
        self.assertNotIn("minjaz-web", self.world()["containers"])
        self.assertEqual(self.world()["containers"]["edge-caddy-1"]["running"], True)


# ================================================================================================ backup / restore / uninstall
class Operations(Kit):
    def test_a_backup_is_copied_out_checked_and_old_copies_are_trimmed_to_thirty(self):
        self.installed()
        folder = self.app / "backups"
        for i in range(33):
            (folder / f"minjaz-2025{(i // 28) + 1:02d}{(i % 28) + 1:02d}-000000.db.gz").write_bytes(b"old")
        (folder / "notes.txt").write_text("mine", encoding="utf-8")
        (folder / "minjaz-custom.db.gz").write_bytes(b"mine too")
        r = self.ok(self.sh("backup.sh"))
        self.assertIn("Saved:", r.stdout)
        fresh = [f for f in folder.glob("minjaz-2026*.db.gz")]
        self.assertEqual(len(fresh), 1)
        self.assertEqual(fresh[0].stat().st_mode & 0o777, 0o600)
        self.assertTrue(gzip.decompress(fresh[0].read_bytes()).startswith(b"SQLite format 3\x00"))
        kept = sorted(f.name for f in folder.glob("minjaz-[0-9]*-[0-9]*.db.gz"))
        self.assertEqual(len(kept), 30)
        self.assertEqual(kept[-1], fresh[0].name, "the newest copy is always kept")
        self.assertTrue((folder / "notes.txt").exists() and (folder / "minjaz-custom.db.gz").exists(), "files that are not ours are never removed")
        self.assertEqual(list(folder.glob(".new-*")), [])

    def test_a_copy_that_is_not_a_database_is_thrown_away(self):
        self.installed()
        self.fails(self.sh("backup.sh", env={"FAKE_BACKUP_GARBAGE": "1"}), "not readable")
        self.assertEqual(list((self.app / "backups").glob("*")), [])

    def test_backup_needs_a_running_app(self):
        self.fails(self.sh("backup.sh"), "not running")

    def make_backup_file(self) -> Path:
        path = self.tmp / "minjaz-20261103-101500.db.gz"
        db_file = self.tmp / "x.db"
        con = sqlite3.connect(str(db_file))
        con.execute("CREATE TABLE t(a)")
        con.commit()
        con.close()
        path.write_bytes(gzip.compress(db_file.read_bytes()))
        return path

    def test_restore_refuses_a_file_that_is_not_a_backup_and_asks_before_it_does_anything(self):
        self.installed()
        junk = self.tmp / "junk.db.gz"
        junk.write_bytes(b"hello")
        self.fails(self.sh("restore.sh", str(junk), input="YES\n"), "not a copy made by MINJAZ")
        self.fails(self.sh("restore.sh"), "usage")
        good = self.make_backup_file()
        self.fails(self.sh("restore.sh", str(good), input="no\n"), "cancelled")
        self.assertEqual([c for c in self.calls() if "stop" in c or " run " in c], [], "nothing was stopped or run")

    def test_restore_stops_the_app_restores_from_the_file_and_starts_it_again(self):
        self.installed()
        good = self.make_backup_file()
        seen = len(self.calls())
        r = self.ok(self.sh("restore.sh", str(good), input="YES\n"))
        self.assertIn("running again", r.stdout)
        steps = [c for c in self.calls()[seen:] if c.startswith("compose")]
        self.assertEqual(steps, ["compose stop web", "compose run --rm --no-deps -T web python -m minjaz restore --force", "compose up -d web"])
        sent = self.world()["restore_inputs"][0]
        self.assertEqual(sent["sha256"], hashlib.sha256(good.read_bytes()).hexdigest(), "the app received exactly the file that was named")

    def test_a_failed_restore_starts_the_app_again_with_the_data_it_had(self):
        self.installed()
        good = self.make_backup_file()
        self.fails(self.sh("restore.sh", str(good), input="YES\n", env={"FAKE_RESTORE_FAIL": "1"}), "Nothing was lost")
        self.assertEqual(self.calls()[-1], "compose up -d web")
        self.assertTrue(self.world()["containers"]["minjaz-web"]["running"])

    def test_uninstall_keeps_the_data_unless_told_to_purge_and_purge_asks_first(self):
        self.proxied()
        self.ok(self.sh("uninstall.sh"))
        w = self.world()
        self.assertNotIn("minjaz-web", w["containers"])
        self.assertIn("minjaz_minjaz_data", w["volumes"], "the data survives a plain uninstall")
        self.assertFalse((self.app / ".state").exists())
        self.assertEqual(sorted(w["containers"]), ["edge-caddy-1", "edge-web-1", "other-web"], "the other projects are untouched")
        self.installed()
        self.fails(self.sh("uninstall.sh", "--purge", input="no\n"), "cancelled")
        self.assertIn("minjaz-web", self.world()["containers"])
        self.ok(self.sh("uninstall.sh", "--purge", input="DELETE\n"))
        w = self.world()
        self.assertNotIn("minjaz_minjaz_data", w["volumes"])
        self.assertIn("rmi minjaz-app:local", w["calls"])
        self.fails(self.sh("uninstall.sh", "--nonsense"))


if __name__ == "__main__":
    unittest.main()
