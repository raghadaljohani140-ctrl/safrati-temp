#!/usr/bin/env bash
# Shows only MINJAZ: container state, health, the last log lines, resource use, the data size and the backups.
# Read-only. The log never contains passwords or the text of a query.
set -euo pipefail
[ "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" = "/opt/minjaz" ] || { echo "ERROR: run from /opt/minjaz" >&2; exit 1; }
cd /opt/minjaz
docker compose -p minjaz ps
echo "--- health ---"
docker inspect -f '{{.State.Health.Status}}' minjaz-web 2>/dev/null || echo "not running"
echo "--- memory and cpu ---"
docker stats --no-stream --format '{{.Name}}: memory {{.MemUsage}}, cpu {{.CPUPerc}}' minjaz-web 2>/dev/null || true
echo "--- last log lines ---"
docker logs --tail 15 minjaz-web 2>&1 || true
echo "--- data ---"
docker exec minjaz-web sh -c 'du -sh /data 2>/dev/null' 2>/dev/null || true
echo "--- the app's own backups (inside its data volume) ---"
docker exec minjaz-web sh -c 'ls -1t /data/backups 2>/dev/null | head -5' 2>/dev/null || true
echo "--- copies kept on this server (backups folder) ---"
ls -1t backups 2>/dev/null | grep -v '^caddy$' | head -5 || true
echo "--- address ---"
bash web.sh link || true
