#!/usr/bin/env bash
# MINJAZ: how the public reaches it. MINJAZ itself always runs inside the server and publishes no port; this script only
# connects it to the web server (Caddy) that already runs on the machine.
#
#   bash web.sh proxy [DOMAIN [NETWORK]]   connect MINJAZ to the web server's Docker network, then offer to add the entry to Caddy
#   bash web.sh caddy [DOMAIN]             add the entry to the Caddyfile (backup first, checked before the reload, undone if anything fails)
#   bash web.sh caddy-undo                 take that entry out of the Caddyfile again (and reload)
#   bash web.sh link                       show the address
#   bash web.sh status                     is it running and connected?
#   bash web.sh stop                       disconnect MINJAZ from the web server's network (nobody outside can reach it; it keeps running)
#
# What it may change, and nothing else:
#   - the Docker project "minjaz" (container minjaz-web), and its own files in /opt/minjaz;
#   - the container minjaz-web joins ONE existing Docker network (the one the web server is on), and leaves it again with `stop`;
#   - ONLY when you answer y to the question, and ONLY by appending one block marked "minjaz" at the end of the Caddyfile
#     (after a copy of the whole file is saved in /opt/minjaz/backups/caddy, and the old config is checked first).
#     The block is checked with `caddy validate` before the reload; the reload is Caddy's graceful reload (no downtime).
#     If the check or the reload fails, the file is put back exactly as it was and the other sites keep running.
# It never restarts, stops or recreates the web server or any other project's container.
set -euo pipefail

APP_DIR="/opt/minjaz"
PROJECT="minjaz"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$APP_DIR/.env"
STATE_FILE="$APP_DIR/.state"
BACKUP_DIR="$APP_DIR/backups/caddy"
BLOCK_START="# >>> minjaz (added by /opt/minjaz/web.sh; remove with: bash /opt/minjaz/web.sh caddy-undo) >>>"
BLOCK_END="# <<< minjaz <<<"

die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
say() { printf '%s\n' "$*"; }

[ "$HERE" = "$APP_DIR" ] || die "this script must live in $APP_DIR (it is in $HERE). Nothing was changed."
cd "$APP_DIR"
umask 077

command -v docker >/dev/null 2>&1 || die "docker is not installed on this server."
docker compose version >/dev/null 2>&1 || die "the 'docker compose' plugin is missing."
command -v curl >/dev/null 2>&1 || die "curl is not installed on this server."

# ---------------------------------------------------------------- settings and state files
env_set() { # NAME VALUE (validated before it gets here, so it never holds a newline)
  local tmp
  tmp="$(mktemp "$APP_DIR/.env.XXXXXX")"
  if [ -f "$ENV_FILE" ]; then grep -v "^$1=" "$ENV_FILE" > "$tmp" || true; fi
  printf '%s=%s\n' "$1" "$2" >> "$tmp"
  chmod 600 "$tmp"
  mv "$tmp" "$ENV_FILE"
}

state_get() { if [ -f "$STATE_FILE" ]; then grep -m1 "^$1=" "$STATE_FILE" | cut -d= -f2- || true; fi; }

state_put() { # NAME VALUE: replaces or adds one line, keeps the others
  local tmp
  tmp="$(mktemp "$APP_DIR/.state.XXXXXX")"
  if [ -f "$STATE_FILE" ]; then grep -v "^$1=" "$STATE_FILE" > "$tmp" || true; fi
  printf '%s=%s\n' "$1" "$2" >> "$tmp"
  chmod 600 "$tmp"
  mv "$tmp" "$STATE_FILE"
}

state_del() { # NAME
  local tmp
  [ -f "$STATE_FILE" ] || return 0
  tmp="$(mktemp "$APP_DIR/.state.XXXXXX")"
  grep -v "^$1=" "$STATE_FILE" > "$tmp" || true
  chmod 600 "$tmp"
  mv "$tmp" "$STATE_FILE"
}

need_install() {
  [ -f "$ENV_FILE" ] || die "MINJAZ is not installed yet. Run first:  bash install.sh"
  [ "$(docker inspect -f '{{.State.Running}}' minjaz-web 2>/dev/null || true)" = true ] || die "MINJAZ is not running. Run first:  bash install.sh"
}

# ---------------------------------------------------------------- questions
valid_domain() { [[ "$1" =~ ^([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,24}$ ]] && [ "${#1}" -le 100 ]; }

valid_network() { # has the shape of a Docker network name, and is not one that must never be used
  [[ "$1" =~ ^[A-Za-z0-9][A-Za-z0-9_.-]{0,62}$ ]] || return 1
  case "$1" in bridge|host|none|minjaz_default) return 1 ;; esac
}

clean_domain() { # lower case, no spaces, no scheme, no trailing slash
  local v="${1//[[:space:]]/}"
  v="${v,,}"; v="${v#https://}"; v="${v#http://}"; v="${v%/}"
  printf '%s' "$v"
}

ASKED=""
ask() { # KIND PROMPT -> sets ASKED (KIND: domain | network | name)
  local kind="$1" prompt="$2" value="" attempts=0
  while true; do
    read -r -p "$prompt: " value || die "input was closed."
    if [ "$kind" = domain ]; then value="$(clean_domain "$value")"; else value="${value//[[:space:]]/}"; fi
    case "$kind" in
      domain)  valid_domain "$value" && { ASKED="$value"; return 0; } ;;
      network) valid_network "$value" && { ASKED="$value"; return 0; } ;;
      name)    [[ "$value" =~ ^[A-Za-z0-9][A-Za-z0-9_.-]{0,62}$ ]] && { ASKED="$value"; return 0; } ;;
    esac
    attempts=$((attempts + 1))
    [ "$attempts" -lt 5 ] || die "that did not look right 5 times. Nothing was changed."
    say "  that does not look right (received ${#value} characters). Try again."
  done
}

confirm() { # PROMPT -> exit 0 only when the answer is y / yes
  local reply=""
  read -r -p "$1 [y/N]: " reply || die "input was closed."
  case "$reply" in y|Y|yes|YES|Yes) return 0 ;; *) return 1 ;; esac
}

# ---------------------------------------------------------------- Docker networks (only minjaz-web is ever connected or disconnected)
network_exists() { docker network inspect "$1" >/dev/null 2>&1; }

network_members() {
  docker network inspect -f '{{range $id, $c := .Containers}}{{$c.Name}} {{end}}' "$1" 2>/dev/null || true
}

container_networks() { # CONTAINER -> its networks on one line
  docker inspect -f '{{range $k, $v := .NetworkSettings.Networks}}{{$k}} {{end}}' "$1" 2>/dev/null || true
}

is_connected() { # NETWORK -> exit 0 when minjaz-web is on it
  [ -n "${1:-}" ] || return 1
  [[ " $(container_networks minjaz-web) " == *" $1 "* ]]
}

join_network() { if is_connected "$1"; then return 0; fi; docker network connect "$1" minjaz-web; }

leave_network() { if is_connected "${1:-}"; then docker network disconnect "$1" minjaz-web >/dev/null 2>&1 || true; fi; }

wait_for_app() {
  local i logs
  for i in $(seq 1 30); do
    logs="$(docker logs minjaz-web 2>&1 || true)"
    if [[ "$logs" == *"listening on"* ]]; then return 0; fi
    sleep 2
  done
  say "MINJAZ did not report that it started within 60 seconds. Last log lines:"
  docker logs --tail 20 minjaz-web 2>&1 || true
  return 1
}

public_ok() { # DOMAIN -> exit 0 when MINJAZ answers from the internet
  local out
  out="$(curl -fsS -m 15 "https://$1/healthz" 2>/dev/null || true)"
  [[ "$out" =~ \"ok\":\ *true ]]
}

wait_public() { # DOMAIN -> a new certificate can take a short while
  local i
  for i in $(seq 1 20); do
    if public_ok "$1"; then return 0; fi
    sleep 3
  done
  return 1
}

dns_points_here() { # DOMAIN -> 0: points at one of this server's addresses; 1: points elsewhere; 2: does not resolve
  local ips ip mine
  ips="$(getent ahostsv4 "$1" 2>/dev/null | awk '{print $1}' | sort -u || true)"
  [ -n "$ips" ] || return 2
  mine=" $(hostname -I 2>/dev/null || true) "
  for ip in $ips; do
    if [[ "$mine" == *" $ip "* ]]; then return 0; fi
  done
  return 1
}

# ---------------------------------------------------------------- finding the web server (read-only)
caddy_find() { # prints the container that runs Caddy, or nothing when there is none or when it cannot be told which
  local all pub n count
  all="$(docker ps --format '{{.Names}}|{{.Image}}' 2>/dev/null | awk -F'|' 'tolower($2) ~ /caddy/ {print $1}' || true)"
  count="$(printf '%s\n' "$all" | grep -c . || true)"
  if [ "$count" = 1 ]; then printf '%s\n' "$all"; return 0; fi
  [ "$count" -gt 1 ] || return 0
  pub=""
  for n in $all; do
    if docker port "$n" 2>/dev/null | grep -E '^443/tcp' >/dev/null; then pub="$pub$n"$'\n'; fi
  done
  if [ "$(printf '%s' "$pub" | grep -c . || true)" = 1 ]; then printf '%s' "$pub"; fi
}

caddy_config_path() { # CONTAINER -> where inside the container Caddy reads its Caddyfile
  local cmd path
  cmd="$(docker inspect -f '{{join .Config.Cmd " "}} {{join .Args " "}}' "$1" 2>/dev/null || true)"
  path="$(printf '%s\n' "$cmd" | sed -n 's/.*--config[ =]\([^ ]*\).*/\1/p' | head -n 1)"
  printf '%s' "${path:-/etc/caddy/Caddyfile}"
}

caddy_host_file() { # CONTAINER CONFIG_PATH -> the file on this server that the container reads as CONFIG_PATH ("" when there is none we can edit)
  local mounts type src dst rest
  mounts="$(docker inspect -f '{{range .Mounts}}{{.Type}}|{{.Source}}|{{.Destination}}{{"\n"}}{{end}}' "$1" 2>/dev/null || true)"
  while IFS='|' read -r type src dst; do
    [ "$type" = bind ] || continue
    [ -n "$dst" ] || continue
    if [ "$dst" = "$2" ] && [ -f "$src" ]; then printf '%s' "$src"; return 0; fi
    case "$2" in
      "$dst"/*)
        rest="${2#"$dst"}"
        if [ -f "$src$rest" ]; then printf '%s' "$src$rest"; return 0; fi ;;
    esac
  done <<< "$mounts"
  return 0
}

caddy_validate() { # CONTAINER CONFIG_PATH -> exit 0 when Caddy accepts the config; its complaint goes to $VALIDATE_LOG
  docker exec "$1" caddy validate --config "$2" --adapter caddyfile > "$VALIDATE_LOG" 2>&1
}

caddy_reload() { docker exec "$1" caddy reload --config "$2" --adapter caddyfile; }

put_back() { # BACKUP FILE -> writes the saved copy back INTO the same file (same inode, so the container still sees it)
  cat "$1" > "$2"
}

strip_block() { # FILE -> the file without the MINJAZ block (from its first marker line to its last marker line)
  awk -v e="$BLOCK_END" 'index($0, "# >>> minjaz ") == 1 {skip=1; next} $0 == e {skip=0; next} !skip {print}' "$1"
}

VALIDATE_LOG=""
BLOCK_TMP=""
cleanup_temp() { [ -z "$VALIDATE_LOG" ] || rm -f -- "$VALIDATE_LOG"; [ -z "$BLOCK_TMP" ] || rm -f -- "$BLOCK_TMP"; }

# ---------------------------------------------------------------- commands
cmd_proxy() { # [DOMAIN [NETWORK]]
  need_install
  local domain="${1:-}" net="${2:-}" caddy nets members n count
  if [ -z "$domain" ]; then
    say "The address people will open (a name that already points at this server, for example minjaz.duckdns.org)."
    ask domain "Domain"
    domain="$ASKED"
  else
    domain="$(clean_domain "$domain")"
    valid_domain "$domain" || die "'${1:-}' does not look like a domain name. Nothing was changed."
  fi
  if [ -z "$net" ]; then
    caddy="$(caddy_find)"
    if [ -n "$caddy" ]; then
      nets="$(container_networks "$caddy")"
      count=0
      for n in $nets; do
        case "$n" in bridge|host|none) continue ;; esac
        count=$((count + 1)); net="$n"
      done
      if [ "$count" = 1 ]; then
        say "The web server on this machine is '$caddy', on the network '$net'. MINJAZ will join that network."
      else
        net=""
        say "The web server '$caddy' is on several networks: $nets"
      fi
    fi
    if [ -z "$net" ]; then
      say "Docker networks on this server (names only):"
      docker network ls --format '{{.Name}}' 2>/dev/null | grep -v -x -e bridge -e host -e none -e minjaz_default | sed 's/^/  /' || true
      ask network "The network the web server in front of MINJAZ is on"
      net="$ASKED"
    fi
  else
    valid_network "$net" || die "'$net' is not a network that can be used here. Nothing was changed."
  fi
  network_exists "$net" || die "there is no Docker network called '$net' on this server. Nothing was changed."
  members="$(network_members "$net")"
  say "Network '$net' is used by: ${members:-nobody yet}"
  say "(these containers will be able to reach MINJAZ, and only through the entry shown below)"
  local previous
  previous="$(state_get PROXY_NETWORK)"
  if [ -n "$previous" ] && [ "$previous" != "$net" ]; then leave_network "$previous"; fi
  env_set SITE_URL "https://$domain"
  env_set REAL_IP_HEADER "X-Forwarded-For"
  state_put ACCESS proxy
  state_put PROXY_NETWORK "$net"
  state_put DOMAIN "$domain"
  say "Applying the address to MINJAZ (it is restarted for a few seconds; no other container is touched)..."
  docker compose -p "$PROJECT" up -d web
  wait_for_app || exit 1
  join_network "$net" || die "could not connect MINJAZ to the network '$net'."
  say "MINJAZ is connected to the network '$net' as minjaz-web."
  say ""
  say "Address:  https://$domain"
  say ""
  say "The web server must forward that name to MINJAZ. The entry (Caddy syntax) is:"
  say ""
  say "    $domain {"
  say "        reverse_proxy minjaz-web:8095"
  say "    }"
  say ""
  if public_ok "$domain"; then
    say "It already answers from the internet. Nothing more to do."
    return 0
  fi
  if [ -n "$(state_get CADDY_FILE)" ]; then
    say "The entry is already in the Caddyfile (added by this script). Check it with:  bash web.sh status"
  elif confirm "Add this entry to the Caddyfile now? (a copy of the file is saved first; nothing else in it changes)"; then
    cmd_caddy "$domain"
  else
    say "Not added. When you want it:  bash web.sh caddy"
  fi
}

cmd_caddy() { # [DOMAIN]
  need_install
  local domain="${1:-}" caddy cfg file net stamp backup block rc re
  [ -n "$domain" ] || domain="$(state_get DOMAIN)"
  [ -n "$domain" ] || die "no domain yet. Run first:  bash web.sh proxy"
  domain="$(clean_domain "$domain")"
  valid_domain "$domain" || die "'$domain' does not look like a domain name. Nothing was changed."
  net="$(state_get PROXY_NETWORK)"
  is_connected "$net" || die "MINJAZ is not connected to the web server's network yet. Run first:  bash web.sh proxy"
  if [ -n "$(state_get CADDY_FILE)" ] && [ -n "$(state_get CADDY_BACKUP)" ]; then
    die "the entry was already added (see $(state_get CADDY_FILE)). To remove it:  bash web.sh caddy-undo"
  fi

  caddy="$(caddy_find)"
  if [ -z "$caddy" ]; then
    say "I could not tell which container is the web server (none found, or more than one)."
    say "Add this entry to its Caddyfile by hand and reload it:"
    say ""; say "    $domain {"; say "        reverse_proxy minjaz-web:8095"; say "    }"; say ""
    return 0
  fi
  cfg="$(caddy_config_path "$caddy")"
  file="$(caddy_host_file "$caddy" "$cfg")"
  if [ -z "$file" ]; then
    say "The web server '$caddy' reads $cfg, but that file is not a folder or file shared from this server, so I cannot edit it from here."
    say "Add this entry to it by hand and reload it:"
    say ""; say "    $domain {"; say "        reverse_proxy minjaz-web:8095"; say "    }"; say ""
    return 0
  fi
  [[ " $(container_networks "$caddy") " == *" $net "* ]] || die "the web server '$caddy' is not on the network '$net'. Nothing was changed."
  re="${domain//./\\.}"
  if grep -Ei "(^|[[:space:],/])${re}([[:space:],{:]|$)" "$file" >/dev/null; then
    die "the Caddyfile already mentions $domain. Nothing was changed. Look at it:  $file"
  fi

  rc=0; dns_points_here "$domain" || rc=$?
  case "$rc" in
    0) say "DNS: $domain points at this server." ;;
    1) say "WARNING: $domain points at another address than this server's ($(hostname -I 2>/dev/null | awk '{print $1}')). The web server cannot get a certificate until it points here." ;;
    *) say "WARNING: $domain does not resolve yet. The web server cannot get a certificate until it points at this server." ;;
  esac

  say ""
  say "Web server:   $caddy"
  say "Caddyfile:    $file (read inside the container as $cfg)"
  say "This will:    1) save a copy of the whole file in $BACKUP_DIR"
  say "              2) check that the file is valid on its own right now (if it is not, nothing is changed)"
  say "              3) append this block at the END of the file (nothing existing is edited):"
  say ""
  say "                 $BLOCK_START"
  say "                 $domain {"
  say "                     reverse_proxy minjaz-web:8095"
  say "                 }"
  say "                 $BLOCK_END"
  say ""
  say "              4) check the new file, then reload Caddy gracefully (the other sites keep answering)"
  say "              5) if the check or the reload fails, put the file back exactly as it was"
  say ""
  if [ "$rc" != 0 ]; then
    confirm "The domain does not point here yet. Continue anyway?" || { say "Cancelled. Nothing was changed."; return 0; }
  fi
  confirm "Go ahead?" || { say "Cancelled. Nothing was changed."; return 0; }

  VALIDATE_LOG="$(mktemp "$APP_DIR/.validate.XXXXXX")"
  trap cleanup_temp EXIT
  mkdir -p "$BACKUP_DIR"
  chmod 700 "$BACKUP_DIR"
  stamp="$(date +%Y%m%d-%H%M%S)"
  backup="$BACKUP_DIR/Caddyfile.$stamp"
  cp -p -- "$file" "$backup"
  cmp -s -- "$file" "$backup" || die "the copy of the Caddyfile does not match the original. Nothing was changed."
  say "Saved a copy: $backup"
  caddy_validate "$caddy" "$cfg" || { cat "$VALIDATE_LOG" >&2; die "the Caddyfile as it is now does not pass Caddy's own check, so I did not touch it. Nothing was changed."; }

  block="$(mktemp "$APP_DIR/.block.XXXXXX")"
  BLOCK_TMP="$block"
  {
    printf '%s\n' "$BLOCK_START"
    printf '%s {\n    reverse_proxy minjaz-web:8095\n}\n' "$domain"
    printf '%s\n' "$BLOCK_END"
  } > "$block"
  if [ -s "$file" ] && [ -n "$(tail -c 1 -- "$file")" ]; then printf '\n' >> "$file"; fi   # the file must end with a newline before we add ours
  printf '\n' >> "$file"
  cat -- "$block" >> "$file"
  rm -f -- "$block"

  if ! caddy_validate "$caddy" "$cfg"; then
    put_back "$backup" "$file"
    cat "$VALIDATE_LOG" >&2
    die "Caddy did not accept the new entry. The Caddyfile was put back exactly as it was. Nothing is changed."
  fi
  if ! caddy_reload "$caddy" "$cfg"; then
    put_back "$backup" "$file"
    caddy_reload "$caddy" "$cfg" >/dev/null 2>&1 || true
    die "Caddy could not reload with the new entry. The Caddyfile was put back and the old settings reloaded."
  fi
  state_put CADDY_CONTAINER "$caddy"
  state_put CADDY_CONFIG "$cfg"
  state_put CADDY_FILE "$file"
  state_put CADDY_BACKUP "$backup"
  say "Added, checked and reloaded."
  say ""
  say "Waiting for https://$domain (the first visit makes Caddy request a certificate; this can take up to a minute)..."
  if wait_public "$domain"; then
    say "It answers from the internet:  https://$domain"
    say "Open  https://$domain/setup  and create the owner account with the one-time setup code (if you lost it:  bash install.sh code)."
  else
    say "It does not answer yet. Most often the name does not point at this server yet, or Caddy is still getting its certificate."
    say "Check in a minute with:  bash web.sh status"
  fi
  say ""
  say "To undo only this change:  bash web.sh caddy-undo"
  say "(the copy of the file as it was before: $backup)"
}

cmd_caddy_undo() {
  local caddy file cfg backup stamp tmp domain removed
  file="$(state_get CADDY_FILE)"
  [ -n "$file" ] || die "MINJAZ did not add anything to a Caddyfile (nothing recorded), so there is nothing to undo."
  caddy="$(state_get CADDY_CONTAINER)"
  cfg="$(state_get CADDY_CONFIG)"
  [ -f "$file" ] || die "the Caddyfile $file is not there any more."
  grep -F "# >>> minjaz " "$file" >/dev/null && grep -Fx "$BLOCK_END" "$file" >/dev/null \
    || die "I cannot find the whole MINJAZ block in $file (it may have been changed by hand). Nothing was changed. Remove the lines between '# >>> minjaz' and '$BLOCK_END' by hand."
  say "This removes ONLY the block marked 'minjaz' from $file and reloads the web server gracefully."
  confirm "Go ahead?" || { say "Cancelled. Nothing was changed."; return 0; }
  VALIDATE_LOG="$(mktemp "$APP_DIR/.validate.XXXXXX")"
  trap cleanup_temp EXIT
  mkdir -p "$BACKUP_DIR"
  chmod 700 "$BACKUP_DIR"
  stamp="$(date +%Y%m%d-%H%M%S)"
  backup="$BACKUP_DIR/Caddyfile.$stamp-before-undo"
  cp -p -- "$file" "$backup"
  tmp="$(mktemp "$APP_DIR/.caddy.XXXXXX")"
  BLOCK_TMP="$tmp"
  if ! strip_block "$file" > "$tmp" || [ ! -s "$tmp" ]; then
    rm -f -- "$tmp"
    die "I could not prepare the file without the block. Nothing was changed."
  fi
  removed=$(( $(wc -l < "$file") - $(wc -l < "$tmp") ))   # our block is 5 lines (plus the blank line before it): anything else means someone edited it
  if [ "$removed" -lt 3 ] || [ "$removed" -gt 12 ]; then
    rm -f -- "$tmp"
    die "the MINJAZ block in $file does not look the way it was written ($removed lines would go). Nothing was changed. Remove it by hand."
  fi
  cat -- "$tmp" > "$file"
  rm -f -- "$tmp"
  if ! caddy_validate "$caddy" "$cfg"; then
    put_back "$backup" "$file"
    cat "$VALIDATE_LOG" >&2
    die "Caddy did not accept the file without the block; it was put back as it was. Nothing is changed."
  fi
  if ! caddy_reload "$caddy" "$cfg"; then
    put_back "$backup" "$file"
    caddy_reload "$caddy" "$cfg" >/dev/null 2>&1 || true
    die "Caddy could not reload; the file was put back as it was."
  fi
  state_del CADDY_CONTAINER; state_del CADDY_CONFIG; state_del CADDY_FILE; state_del CADDY_BACKUP
  domain="$(state_get DOMAIN)"
  say "Removed. The web server no longer forwards ${domain:-the domain} to MINJAZ. (A copy of the file before this step: $backup)"
}

cmd_link() {
  if [ "$(state_get ACCESS)" = proxy ]; then say "$(state_get DOMAIN | sed 's#^#https://#')"; else say "The public link is off. Start it with:  bash web.sh proxy"; fi
}

cmd_status() {
  docker compose -p "$PROJECT" ps
  if [ "$(state_get ACCESS)" = proxy ]; then
    local net domain
    net="$(state_get PROXY_NETWORK)"
    domain="$(state_get DOMAIN)"
    if [ -n "$net" ] && is_connected "$net"; then say "Connected to the network '$net'."; else say "NOT connected to the network '${net:-?}'. Fix with:  bash web.sh proxy"; fi
    if [ -n "$(state_get CADDY_FILE)" ]; then say "The Caddy entry was added by this script (undo:  bash web.sh caddy-undo)."; else say "The Caddy entry was NOT added by this script yet:  bash web.sh caddy"; fi
    if [ -n "$domain" ]; then
      if public_ok "$domain"; then say "https://$domain answers from the internet."; else say "https://$domain does not answer from here yet."; fi
    fi
  fi
  say "--- log ---"
  docker logs --tail 8 minjaz-web 2>&1 || true
  say "--- address ---"
  cmd_link
}

cmd_stop() {
  need_install
  local net
  net="$(state_get PROXY_NETWORK)"
  if [ -n "$net" ]; then leave_network "$net"; fi
  state_put ACCESS off
  say "MINJAZ is disconnected from the web server's network: nobody outside can reach it. It keeps running inside the server."
  if [ -n "$(state_get CADDY_FILE)" ]; then say "The entry in the Caddyfile is still there (harmless while MINJAZ is disconnected). Remove it with:  bash web.sh caddy-undo"; fi
}

case "${1:-}" in
  proxy)       cmd_proxy "${2:-}" "${3:-}" ;;
  caddy)       cmd_caddy "${2:-}" ;;
  caddy-undo)  cmd_caddy_undo ;;
  link)        cmd_link ;;
  status)      cmd_status ;;
  stop)        cmd_stop ;;
  *)           die "usage: bash web.sh proxy [DOMAIN [NETWORK]] | caddy [DOMAIN] | caddy-undo | link | status | stop" ;;
esac
