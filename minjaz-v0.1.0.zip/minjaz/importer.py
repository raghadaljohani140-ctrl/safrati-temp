"""Reading Excel (.xlsx) and CSV files of phone numbers, and checking every row before anything is saved."""
from __future__ import annotations

import csv
import io
import re
import sqlite3
import xml.etree.ElementTree as ET
import zipfile
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

from . import config, db, phones, settings as st, util

NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
REL_NS = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
MAX_SHEET_BYTES = 48 * 1024 * 1024
MAX_STRINGS_BYTES = 24 * 1024 * 1024
MAX_COLS = 60

FIELDS = [("name", "الاسم"), ("phone", "رقم الجوال"), ("phone2", "رقم ثانٍ (اختياري)"), ("city", "المدينة (اختياري)"),
          ("url", "رابط الإعلان أو المصدر (اختياري)"), ("employee", "الموظف المسؤول (اختياري)")]

ALIASES = {
    "name": ["الاسم", "اسم", "اسم المالك", "اسم العميل", "المالك", "العميل", "الاسم الكامل", "name", "owner", "customer", "full name", "client"],
    "phone": ["الجوال", "جوال", "رقم الجوال", "رقم جوال", "الهاتف", "رقم الهاتف", "هاتف", "موبايل", "رقم الموبايل", "رقم التواصل", "رقم",
              "واتساب", "mobile", "phone", "tel", "telephone", "whatsapp", "cell", "number", "phone number", "mobile number"],
    "phone2": ["جوال 2", "جوال ثاني", "رقم ثاني", "رقم اخر", "رقم بديل", "الجوال الثاني", "هاتف 2", "phone2", "phone 2", "mobile2", "mobile 2",
               "alt phone", "alternate", "secondary phone"],
    "city": ["المدينة", "مدينة", "المنطقة", "city", "town", "region", "area"],
    "url": ["الرابط", "رابط", "رابط الاعلان", "رابط الإعلان", "المصدر", "url", "link", "source", "ad link", "listing"],
    "employee": ["الموظف", "المسؤول", "المسوق", "موظف", "employee", "assigned", "agent", "assignee"],
}


class ImportProblem(Exception):
    """A problem with the file that the manager can fix. The message is Arabic and shown as is."""


# ------------------------------------------------------------------------------------------------ reading files
def _col_index(ref: str) -> int:
    letters = re.match(r"[A-Z]+", ref or "")
    n = 0
    for ch in (letters.group(0) if letters else "A"):
        n = n * 26 + (ord(ch) - 64)
    return n - 1


def _num_text(text: str) -> str:
    try:
        d = Decimal(text)
    except InvalidOperation:
        return text
    if d == d.to_integral_value():
        return str(int(d))
    return format(d.normalize(), "f")


def _scan_xml_head(zf: zipfile.ZipFile, name: str) -> None:
    with zf.open(name) as fh:
        head = fh.read(4096).lower()
    if b"<!entity" in head or b"<!doctype" in head:
        raise ImportProblem("الملف يحتوي بنية غير مسموحة")


def _read_shared_strings(zf: zipfile.ZipFile) -> list[str]:
    name = "xl/sharedStrings.xml"
    if name not in zf.namelist():
        return []
    if zf.getinfo(name).file_size > MAX_STRINGS_BYTES:
        raise ImportProblem("الملف كبير جدًا")
    _scan_xml_head(zf, name)
    out: list[str] = []
    with zf.open(name) as fh:
        for _, el in ET.iterparse(fh, events=("end",)):
            if el.tag == NS + "si":
                parts = []
                for child in el:
                    if child.tag == NS + "t":
                        parts.append(child.text or "")
                    elif child.tag == NS + "r":
                        for t in child:
                            if t.tag == NS + "t":
                                parts.append(t.text or "")
                out.append("".join(parts))
                el.clear()
    return out


def _first_sheet_path(zf: zipfile.ZipFile) -> str:
    names = set(zf.namelist())
    try:
        _scan_xml_head(zf, "xl/workbook.xml")
        wb = ET.fromstring(zf.read("xl/workbook.xml"))
        sheets = wb.find(NS + "sheets")
        first = next(iter(sheets)) if sheets is not None else None
        rid = first.get(REL_NS + "id") if first is not None else None
        if rid and "xl/_rels/workbook.xml.rels" in names:
            rels = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
            for rel in rels:
                if rel.get("Id") == rid:
                    target = rel.get("Target", "")
                    path = target.lstrip("/") if target.startswith("/") else "xl/" + target
                    if path in names:
                        return path
    except (ET.ParseError, KeyError, StopIteration):
        pass
    if "xl/worksheets/sheet1.xml" in names:
        return "xl/worksheets/sheet1.xml"
    raise ImportProblem("لم أجد ورقة بيانات في ملف Excel")


def read_xlsx(raw: bytes, max_rows: int) -> list[tuple[int, list[str]]]:
    try:
        zf = zipfile.ZipFile(io.BytesIO(raw))
    except zipfile.BadZipFile:
        raise ImportProblem("الملف ليس Excel سليمًا (xlsx). احفظه من Excel بصيغة xlsx أو CSV.")
    with zf:
        sheet = _first_sheet_path(zf)
        if zf.getinfo(sheet).file_size > MAX_SHEET_BYTES:
            raise ImportProblem("الورقة كبيرة جدًا؛ قسّم الملف إلى أجزاء")
        _scan_xml_head(zf, sheet)
        strings = _read_shared_strings(zf)
        rows: list[tuple[int, list[str]]] = []
        cur: dict[int, str] = {}
        row_no = 0
        ctype = ""
        cell_col = 0
        text_v = ""
        inline = ""
        try:
            with zf.open(sheet) as fh:
                for event, el in ET.iterparse(fh, events=("start", "end")):
                    tag = el.tag
                    if event == "start":
                        if tag == NS + "row":
                            row_no = int(el.get("r") or row_no + 1)
                            cur = {}
                        elif tag == NS + "c":
                            ctype = el.get("t", "n")
                            cell_col = _col_index(el.get("r", "")) if el.get("r") else (max(cur) + 1 if cur else 0)
                            text_v = inline = ""
                        continue
                    if tag == NS + "v":
                        text_v = el.text or ""
                    elif tag == NS + "t" and ctype == "inlineStr":
                        inline += el.text or ""
                    elif tag == NS + "c":
                        if cell_col < MAX_COLS:
                            if ctype == "s":
                                val = strings[int(text_v)] if text_v.isdigit() and int(text_v) < len(strings) else ""
                            elif ctype == "inlineStr":
                                val = inline
                            elif ctype == "b":
                                val = "TRUE" if text_v == "1" else "FALSE"
                            elif ctype == "e":
                                val = ""
                            elif ctype in ("n", ""):
                                val = _num_text(text_v) if text_v else ""
                            else:
                                val = text_v
                            if val.strip():
                                cur[cell_col] = val.strip()
                        el.clear()
                    elif tag == NS + "row":
                        if cur:
                            width = max(cur) + 1
                            rows.append((row_no, [cur.get(i, "") for i in range(width)]))
                            if len(rows) > max_rows + 1:
                                raise ImportProblem(f"الملف أكبر من {max_rows:,} صفًا. قسّمه إلى ملفات أصغر.")
                        el.clear()
        except ET.ParseError:
            raise ImportProblem("تعذّرت قراءة الورقة، ربما الملف تالف")
    return rows


def _decode(raw: bytes) -> str:
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        return raw.decode("utf-16")
    for enc in ("utf-8-sig", "cp1256"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1")


def read_csv(raw: bytes, max_rows: int) -> list[tuple[int, list[str]]]:
    text = _decode(raw)
    sample = "\n".join(text.splitlines()[:6])
    counts = {d: sample.count(d) for d in (",", ";", "\t", "|")}
    delim = max(counts, key=lambda d: counts[d]) if any(counts.values()) else ","
    csv.field_size_limit(1_000_000)
    rows: list[tuple[int, list[str]]] = []
    for i, rec in enumerate(csv.reader(io.StringIO(text), delimiter=delim), start=1):
        cells = [x.strip() for x in rec[:MAX_COLS]]
        while cells and not cells[-1]:
            cells.pop()
        if cells:
            rows.append((i, cells))
        if len(rows) > max_rows + 1:
            raise ImportProblem(f"الملف أكبر من {max_rows:,} صفًا. قسّمه إلى ملفات أصغر.")
    return rows


def read_rows(filename: str, raw: bytes, max_rows: int | None = None) -> list[tuple[int, list[str]]]:
    max_rows = max_rows or config.MAX_IMPORT_ROWS
    low = filename.lower()
    if low.endswith(".xlsx") or low.endswith(".xlsm"):
        rows = read_xlsx(raw, max_rows)
    elif low.endswith((".csv", ".txt", ".tsv")):
        rows = read_csv(raw, max_rows)
    elif low.endswith(".xls"):
        raise ImportProblem("صيغة xls القديمة غير مدعومة. افتح الملف في Excel واحفظه بصيغة xlsx أو CSV.")
    else:
        if raw[:2] == b"PK":
            rows = read_xlsx(raw, max_rows)
        else:
            raise ImportProblem("الملف يجب أن يكون xlsx أو csv")
    if not rows:
        raise ImportProblem("الملف فارغ")
    return rows


# ------------------------------------------------------------------------------------------------ guessing the columns
def _key(s: str) -> str:
    return re.sub(r"[\s_\-.:/]+", " ", util.norm_text(s)).strip()


_ALIAS_KEYS = {f: {_key(a) for a in lst} for f, lst in ALIASES.items()}


def looks_like_header(first: list[str]) -> bool:
    if not first:
        return False
    if any(phones.normalize_phone(c).phone for c in first if c):
        return False
    return True


def guess_mapping(rows: list[tuple[int, list[str]]], has_header: bool) -> dict[str, int | None]:
    width = max(len(r[1]) for r in rows[:300])
    mapping: dict[str, int | None] = {f: None for f, _ in FIELDS}
    taken: set[int] = set()
    if has_header:
        headers = [_key(h) for h in rows[0][1]] + [""] * (width - len(rows[0][1]))
        for f in ("phone2", "phone", "name", "city", "url", "employee"):
            for i, h in enumerate(headers):
                if i in taken or not h:
                    continue
                if h in _ALIAS_KEYS[f]:
                    mapping[f] = i
                    taken.add(i)
                    break
        for f in ("phone2", "phone", "name", "city", "url", "employee"):
            if mapping[f] is None:
                for i, h in enumerate(headers):
                    if i not in taken and h and any(a in h for a in _ALIAS_KEYS[f] if len(a) >= 3):
                        if f == "phone" and any(w in h for w in ("2", "ثاني", "اخر", "بديل")):
                            continue
                        mapping[f] = i
                        taken.add(i)
                        break
    body = rows[1:] if has_header else rows
    sample = body[:200]
    if mapping["phone"] is None:
        best, best_share = None, 0.0
        for i in range(width):
            cells = [r[1][i] for r in sample if i < len(r[1]) and r[1][i]]
            if not cells:
                continue
            share = sum(1 for x in cells if any(phones.normalize_phone(p).phone for p in phones.split_numbers(x))) / len(cells)
            if share > best_share and i not in taken:
                best, best_share = i, share
        if best is not None and best_share >= 0.5:
            mapping["phone"] = best
            taken.add(best)
    if mapping["name"] is None:
        best, best_share = None, 0.0
        for i in range(width):
            if i in taken:
                continue
            cells = [r[1][i] for r in sample if i < len(r[1]) and r[1][i]]
            if not cells:
                continue
            share = sum(1 for x in cells if re.search(r"[A-Za-z؀-ۿ]{2}", x) and not phones.normalize_phone(x).phone) / len(cells)
            if share > best_share:
                best, best_share = i, share
        if best is not None and best_share >= 0.6:
            mapping["name"] = best
    return mapping


# ------------------------------------------------------------------------------------------------ checking every row
def _clean(text: str, n: int) -> str:
    return re.sub(r"\s+", " ", text or "").strip()[:n]


def analyze(c: sqlite3.Connection, company_id: int, batch_id: int, rows: list[tuple[int, list[str]]], mapping: dict[str, int | None],
            has_header: bool, s: dict) -> dict[str, Any]:
    """Classifies each row (new, duplicate of a saved client, duplicate inside the file, invalid number) and stores the verdicts."""
    c.execute("DELETE FROM import_rows WHERE batch_id=?", (batch_id,))
    existing = {r["phone"]: r["id"] for r in c.execute("SELECT id, phone FROM leads WHERE company_id=?", (company_id,))}
    existing_alt = {r["phone_alt"]: r["id"] for r in c.execute("SELECT id, phone_alt FROM leads WHERE company_id=? AND phone_alt IS NOT NULL", (company_id,))}
    places = {}
    for r in c.execute("SELECT id, name, city FROM leads WHERE company_id=? AND city IS NOT NULL AND city<>''", (company_id,)):
        places.setdefault(util.norm_text(r["name"]) + "|" + util.norm_text(r["city"]), r["id"])
    staff = {}
    for u in c.execute("SELECT id, username, name FROM users WHERE company_id=? AND role='employee' AND active=1", (company_id,)):
        staff[u["username"].lower()] = u["id"]
        staff[util.norm_text(u["name"])] = u["id"]
    allow = bool(s["allow_landline"])
    seen: dict[str, int] = {}
    out: list[tuple] = []
    counts = {"rows": 0, "new": 0, "dup_db": 0, "dup_file": 0, "invalid": 0, "non_mobile": 0, "maybe_same": 0, "no_name": 0, "assigned": 0,
              "unknown_staff": 0}
    unknown: dict[str, int] = {}
    body = rows[1:] if has_header else rows

    def cell(cells: list[str], f: str) -> str:
        i = mapping.get(f)
        return cells[i] if i is not None and i < len(cells) else ""

    for row_no, cells in body:
        raw_main = cell(cells, "phone")
        raw_alt = cell(cells, "phone2")
        name = _clean(cell(cells, "name"), 120)
        if not raw_main and not raw_alt and not name:
            continue
        counts["rows"] += 1
        city = _clean(cell(cells, "city"), 60)
        url = cell(cells, "url").strip()[:300]
        url = url if url.lower().startswith(("http://", "https://")) else ""
        emp = _clean(cell(cells, "employee"), 60)
        found: list[phones.Phone] = []
        first_error = ""
        for part in phones.split_numbers(raw_main) + phones.split_numbers(raw_alt):
            p = phones.normalize_phone(part)
            if p.phone:
                if all(p.phone != f.phone for f in found):
                    found.append(p)
            elif not first_error:
                first_error = p.reason
        if not name:
            counts["no_name"] += 1
            name = "بدون اسم"
        if not found:
            counts["invalid"] += 1
            out.append((batch_id, row_no, name, raw_main or raw_alt, None, None, city, url, emp, "invalid", first_error or "لا يوجد رقم", None, None, None))
            continue
        main = found[0]
        alt = found[1].phone if len(found) > 1 else None
        state, reason, same = "new", "", None
        if main.phone in seen:  # a number is the same number whether it came as someone's first or second one
            state, reason = "dup_file", f"مكرر في الصف {seen[main.phone]} من الملف"
            counts["dup_file"] += 1
        elif main.phone in existing or main.phone in existing_alt:
            state, reason = "dup_db", "موجود مسبقًا في قائمة العملاء" if main.phone in existing else "موجود مسبقًا كرقم ثانٍ لأحد العملاء"
            counts["dup_db"] += 1
        else:
            seen[main.phone] = row_no
            if alt:
                seen.setdefault(alt, row_no)
            same = places.get(util.norm_text(name) + "|" + util.norm_text(city)) if city and name != "بدون اسم" else None
            if same:
                reason = "نفس الاسم والمدينة مع رقم مختلف: قد يكون نفس المكان"
            elif alt and (existing.get(alt) or existing_alt.get(alt)):
                same = existing.get(alt) or existing_alt.get(alt)
                reason = "الرقم الثاني موجود عند عميل آخر: قد يكون نفس المالك"
            if same:
                counts["maybe_same"] += 1
            if main.kind != "mobile" and not allow:
                counts["non_mobile"] += 1
                reason = (reason + " · " if reason else "") + "رقم أرضي أو دولي: يُحفظ ولا يدخل الخطط"
            counts["new"] += 1
            if emp:
                if staff.get(emp.lower()) or staff.get(util.norm_text(emp)):
                    counts["assigned"] += 1
                else:
                    counts["unknown_staff"] += 1
                    unknown[emp] = unknown.get(emp, 0) + 1
        out.append((batch_id, row_no, name, raw_main or raw_alt, main.phone, alt, city, url, emp, state, reason, None, main.kind, same))
    c.executemany("INSERT INTO import_rows(batch_id,row_no,name,phone_raw,phone,phone_alt,city,source_url,employee,state,reason,lead_id,line_type,maybe_same_id)"
                  " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", out)
    counts["unknown_names"] = sorted(unknown.items(), key=lambda kv: -kv[1])[:8]
    return counts


def commit(c: sqlite3.Connection, company_id: int, batch_id: int, actor: int, s: dict) -> dict[str, int]:
    batch = db.one(c, "SELECT * FROM lead_batches WHERE id=? AND company_id=?", batch_id, company_id)
    if not batch or batch["status"] != "preview":
        raise ImportProblem("هذا الاستيراد لا يمكن اعتماده الآن")
    staff = {}
    for u in c.execute("SELECT id, username, name FROM users WHERE company_id=? AND role='employee' AND active=1", (company_id,)):
        staff[u["username"].lower()] = u["id"]
        staff[util.norm_text(u["name"])] = u["id"]
    now = util.now_iso()
    added = demoted = assigned = 0
    for r in c.execute("SELECT * FROM import_rows WHERE batch_id=? AND state='new' ORDER BY row_no", (batch_id,)).fetchall():
        owner = staff.get((r["employee"] or "").lower()) or staff.get(util.norm_text(r["employee"] or "")) if r["employee"] else None
        cur = c.execute(
            "INSERT OR IGNORE INTO leads(company_id,name,phone,phone_raw,phone_alt,city,source_url,batch_id,added_at,line_type,owner_id,status,status_at,"
            "maybe_same_id,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,'new',?,?,?)",
            (company_id, r["name"], r["phone"], r["phone_raw"], r["phone_alt"], r["city"] or None, r["source_url"] or None, batch_id, now,
             r["line_type"] or "mobile", owner, now, r["maybe_same_id"], actor))
        if cur.rowcount == 0:
            c.execute("UPDATE import_rows SET state='dup_db', reason='أُضيف من استيراد آخر قبل الاعتماد' WHERE batch_id=? AND row_no=?", (batch_id, r["row_no"]))
            demoted += 1
            continue
        added += 1
        c.execute("UPDATE import_rows SET lead_id=? WHERE batch_id=? AND row_no=?", (cur.lastrowid, batch_id, r["row_no"]))
        if owner:
            assigned += 1
            c.execute("INSERT INTO assignments(company_id,lead_id,user_id,assigned_at,reason,by_user_id) VALUES(?,?,?,?,?,?)",
                      (company_id, cur.lastrowid, owner, now, "import_column", actor))
    counts = db.jload(batch["counts_json"], {})
    counts.update({"added": added, "demoted": demoted, "assigned": assigned})
    c.execute("UPDATE lead_batches SET status='committed', committed_at=?, counts_json=? WHERE id=?", (now, util.canon(counts), batch_id))
    db.emit(c, company_id, "import.committed", actor=actor, ref=batch_id,
            data={"file": batch["filename"], "sha256": batch["sha256"], "added": added, "dup_db": counts.get("dup_db", 0), "dup_file": counts.get("dup_file", 0),
                  "invalid": counts.get("invalid", 0), "assigned": assigned})
    return {"added": added, "demoted": demoted, "assigned": assigned}


def rejected_csv(c: sqlite3.Connection, batch_id: int) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["رقم الصف", "الاسم", "الرقم كما ورد", "السبب"])
    labels = {"invalid": "رقم غير صالح", "dup_db": "مكرر (موجود مسبقًا)", "dup_file": "مكرر في الملف"}
    for r in c.execute("SELECT * FROM import_rows WHERE batch_id=? AND state<>'new' ORDER BY row_no", (batch_id,)):
        w.writerow([r["row_no"], r["name"], r["phone_raw"], f"{labels.get(r['state'], r['state'])}: {r['reason'] or ''}".strip(": ")])
    return "﻿" + buf.getvalue()


def save_upload(company_id: int, batch_id: int, filename: str, raw: bytes) -> str:
    ext = Path(filename).suffix.lower()[:6] or ".bin"
    folder = config.uploads_dir() / str(company_id)
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{batch_id}{re.sub(r'[^.a-z0-9]', '', ext)}"
    path.write_bytes(raw)
    return str(path)
