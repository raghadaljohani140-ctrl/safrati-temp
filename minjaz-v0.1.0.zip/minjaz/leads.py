"""Lead rules: which statuses come back into a plan, how follow-ups are spaced, and who owns a lead."""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from typing import Iterable

from . import consts, db, settings as st, util

FOLLOW_STATUSES = ("interested", "no_answer", "phone_off", "callback", "link_sent", "visited")
OPEN_STATUSES = ("new",) + FOLLOW_STATUSES
ASSIGNABLE = OPEN_STATUSES + ("exhausted",)

# which "run" of outcomes a status belongs to: a second "no answer" continues the same ladder, an "interested" starts a new one
CATEGORY = {"interested": "interested", "no_answer": "unreached", "phone_off": "unreached", "link_sent": "link", "visited": "visited",
            "callback": "callback"}
OUTCOME_CATEGORY = {"interested": "interested", "no_answer": "unreached", "phone_off": "unreached", "asked_link": "link", "visited": "visited"}


@dataclass
class Next:
    status: str
    step: int
    date: str | None
    time: str | None = None


def ladder_key(outcome: str, s: dict) -> str:
    if outcome == "interested":
        return "fu_interested"
    if outcome == "asked_link":
        return "fu_link_sent"
    if outcome == "visited":
        return "fu_visited"
    if outcome == "phone_off" and st.parse_days(s.get("fu_phone_off", ""))[0]:
        return "fu_phone_off"
    return "fu_no_answer"


def ladder_days(s: dict, key: str, step: int) -> int | None:
    """Days to wait before the next call, given how many follow-ups already happened. None when the ladder has ended."""
    days, repeat = st.parse_days(s.get(key, ""))
    if not days:
        return None
    if step < len(days):
        return days[step]
    return days[-1] if repeat else None


def after_outcome(s: dict, outcome: str, prev_status: str, prev_step: int, today: str, fu_date: str | None = None,
                  fu_time: str | None = None) -> Next:
    """What happens to a lead after a call result: its new status, ladder position and the day to call again."""
    status = consts.OUTCOME_STATUS[outcome]
    if outcome == "call_later":
        return Next("callback", 0, fu_date, fu_time)
    cat = OUTCOME_CATEGORY.get(outcome)
    if cat is None:  # not interested, wrong number, registered: finished
        return Next(status, 0, None)
    step = prev_step if CATEGORY.get(prev_status) == cat else 0
    days = ladder_days(s, ladder_key(outcome, s), step)
    if days is None:
        return Next("exhausted", step + 1, None)
    return Next(status, step + 1, util.add_days(today, days))


def get(c: sqlite3.Connection, company_id: int, lead_id: int) -> sqlite3.Row | None:
    return db.one(c, "SELECT * FROM leads WHERE id=? AND company_id=?", lead_id, company_id)


def pool_where(allow_landline: bool, alias: str = "") -> str:
    a = alias + "." if alias else ""
    return f"{a}owner_id IS NULL AND {a}status='new' AND {a}do_not_call=0" + ("" if allow_landline else f" AND {a}line_type='mobile'")


def pool_count(c: sqlite3.Connection, company_id: int, allow_landline: bool) -> int:
    return db.scalar(c, f"SELECT COUNT(*) FROM leads WHERE company_id=? AND {pool_where(allow_landline)}", company_id, default=0)


def set_status(c: sqlite3.Connection, lead_id: int, status: str) -> None:
    c.execute("UPDATE leads SET status=?, status_at=? WHERE id=?", (status, util.now_iso(), lead_id))


def chunks(seq: list, n: int) -> Iterable[list]:
    for i in range(0, len(seq), n):
        yield seq[i:i + n]


def assign(c: sqlite3.Connection, company_id: int, lead_ids: list[int], user_id: int | None, actor: int | None,
           reason: str = "manual", emit_event: bool = True) -> int:
    """Gives leads to an employee (or back to the pool with user_id=None). Returns how many actually moved."""
    now = util.now_iso()
    moved: list[int] = []
    marks = ",".join("?" * len(ASSIGNABLE))
    for part in chunks(list(dict.fromkeys(lead_ids)), 400):
        q = ",".join("?" * len(part))
        rows = c.execute(f"SELECT id, owner_id FROM leads WHERE company_id=? AND id IN ({q}) AND status IN ({marks}) AND do_not_call=0",
                         (company_id, *part, *ASSIGNABLE)).fetchall()
        for r in rows:
            if r["owner_id"] == user_id:
                continue
            c.execute("UPDATE assignments SET ended_at=? WHERE lead_id=? AND ended_at IS NULL", (now, r["id"]))
            c.execute("INSERT INTO assignments(company_id,lead_id,user_id,assigned_at,reason,by_user_id) VALUES(?,?,?,?,?,?)",
                      (company_id, r["id"], user_id, now, reason, actor))
            c.execute("UPDATE leads SET owner_id=? WHERE id=?", (user_id, r["id"]))
            moved.append(r["id"])
    if moved and emit_event:
        db.emit(c, company_id, "lead.assigned", actor=actor, user=user_id, data={"count": len(moved), "reason": reason, "ids": moved[:100]})
    return len(moved)


def release_user_leads(c: sqlite3.Connection, company_id: int, user_id: int, actor: int | None) -> dict[str, int]:
    """When an employee leaves: numbers never called go back to the pool; leads mid-follow-up wait for the manager to hand them on."""
    fresh = [r["id"] for r in c.execute("SELECT id FROM leads WHERE company_id=? AND owner_id=? AND status='new'", (company_id, user_id))]
    waiting = [r["id"] for r in c.execute(
        "SELECT id FROM leads WHERE company_id=? AND owner_id=? AND status IN (%s)" % ",".join("?" * len(FOLLOW_STATUSES)),
        (company_id, user_id, *FOLLOW_STATUSES))]
    n_new = assign(c, company_id, fresh, None, actor, "employee_left")
    n_wait = assign(c, company_id, waiting, None, actor, "employee_left")
    return {"returned_new": n_new, "waiting": n_wait}


def make_link_token(c: sqlite3.Connection, lead_id: int) -> str:
    row = db.one(c, "SELECT link_token FROM leads WHERE id=?", lead_id)
    if row and row["link_token"]:
        return row["link_token"]
    for _ in range(5):
        tok = util.token(9)
        try:
            c.execute("UPDATE leads SET link_token=? WHERE id=? AND link_token IS NULL", (tok, lead_id))
            return db.scalar(c, "SELECT link_token FROM leads WHERE id=?", lead_id)
        except sqlite3.IntegrityError:
            continue
    raise RuntimeError("could not create a link token")


def fill_template(text: str, **vals: str) -> str:
    """Only the named placeholders are replaced; nothing else in the text is interpreted."""
    for k, v in vals.items():
        text = text.replace("{" + k + "}", v or "")
    return text
