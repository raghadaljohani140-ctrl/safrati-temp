"""Backups: a consistent copy of the live database, checked after it is made, kept for a while, and test-restored regularly.

A copy is only worth having if it opens. So every backup is verified right away (SQLite's own integrity check and the event chain of every
company), and `restore_test` opens the newest one in a scratch folder the way a real restore would, without touching the live data.
"""
from __future__ import annotations

import datetime as dt
import gzip
import hashlib
import logging
import shutil
import sqlite3
import os
import tempfile
from pathlib import Path
from typing import IO, Any

from . import config, db, util

log = logging.getLogger("minjaz.backup")


def _sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def inspect(path: Path) -> dict[str, Any]:
    """Opens a database file read-only and reports whether it is whole: integrity, schema version, event chains, row counts."""
    out: dict[str, Any] = {"ok": False}
    c = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    c.row_factory = sqlite3.Row
    try:
        out["integrity"] = c.execute("PRAGMA integrity_check").fetchone()[0]
        out["schema"] = c.execute("PRAGMA user_version").fetchone()[0]
        out["companies"] = c.execute("SELECT COUNT(*) FROM companies").fetchone()[0]
        out["users"] = c.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        out["leads"] = c.execute("SELECT COUNT(*) FROM leads").fetchone()[0]
        out["events"] = c.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        bad = []
        for co in c.execute("SELECT id, name FROM companies"):
            r = db.verify_chain(c, co["id"])
            if not r["ok"]:
                bad.append({"company": co["name"], "bad_seq": r.get("bad_seq")})
        out["bad_chains"] = bad
        out["ok"] = out["integrity"] == "ok" and out["schema"] == db.SCHEMA_VERSION and not bad
    finally:
        c.close()
    return out


def make_backup(kind: str = "daily") -> dict[str, Any]:
    """Copies the database with SQLite's online backup (safe while the app is writing), compresses it, verifies it and logs the result."""
    config.backups_dir().mkdir(parents=True, exist_ok=True)
    stamp = util.now().strftime("%Y%m%d-%H%M%S")
    final = config.backups_dir() / f"minjaz-{stamp}-{kind}.db.gz"
    info: dict[str, Any] = {"ok": False, "kind": kind, "path": str(final), "note": ""}
    try:
        with tempfile.TemporaryDirectory(dir=config.backups_dir()) as tmp:
            raw = Path(tmp) / "copy.db"
            src = db.connect()
            try:
                dst = sqlite3.connect(str(raw))
                try:
                    with dst:
                        src.backup(dst)
                finally:
                    dst.close()
            finally:
                src.close()
            check = inspect(raw)
            info["check"] = check
            if not check["ok"]:
                info["note"] = "فشل فحص النسخة: " + (check.get("integrity") if check.get("integrity") != "ok" else "سلسلة السجل غير سليمة")
                return info
            with raw.open("rb") as f_in, gzip.open(final, "wb", compresslevel=6) as f_out:
                shutil.copyfileobj(f_in, f_out)
        info.update(ok=True, size=final.stat().st_size, sha256=_sha(final))
    except Exception as exc:  # a failed backup must be loud in the log but never take the app down
        log.exception("backup failed")
        info["note"] = f"{type(exc).__name__}: {exc}"[:300]
        final.unlink(missing_ok=True)
    finally:
        with db.tx(True) as c:
            c.execute("INSERT INTO backup_log(at,kind,path,size,sha256,ok,note) VALUES(?,?,?,?,?,?,?)",
                      (util.now_iso(), kind, str(final) if info["ok"] else None, info.get("size"), info.get("sha256"), int(info["ok"]), info["note"] or None))
    if info["ok"]:
        info["pruned"] = prune()
    return info


def prune() -> int:
    """Keeps the newest KEEP_DAILY daily copies, KEEP_WEEKLY weekly ones and ten manual ones."""
    limits = {"daily": config.KEEP_DAILY_BACKUPS, "weekly": config.KEEP_WEEKLY_BACKUPS, "manual": 10}
    removed = 0
    with db.tx(True) as c:
        for kind, keep in limits.items():
            rows = c.execute("SELECT id, path FROM backup_log WHERE kind=? AND ok=1 AND path IS NOT NULL ORDER BY id DESC", (kind,)).fetchall()
            for r in rows[keep:]:
                Path(r["path"]).unlink(missing_ok=True)
                c.execute("UPDATE backup_log SET path=NULL, note=COALESCE(note,'')||' (حُذفت لتجاوز مدة الحفظ)' WHERE id=?", (r["id"],))
                removed += 1
    return removed


def latest(kind: str | None = None) -> sqlite3.Row | None:
    with db.tx() as c:
        if kind:
            return db.one(c, "SELECT * FROM backup_log WHERE ok=1 AND path IS NOT NULL AND kind=? ORDER BY id DESC LIMIT 1", kind)
        return db.one(c, "SELECT * FROM backup_log WHERE ok=1 AND path IS NOT NULL AND kind<>'restore-test' ORDER BY id DESC LIMIT 1")


def restore_test() -> dict[str, Any]:
    """Unpacks the newest backup into a scratch folder and checks that it is a whole, readable database. Never touches live data."""
    row = latest()
    info: dict[str, Any] = {"ok": False, "note": ""}
    if not row or not Path(row["path"]).exists():
        info["note"] = "لا توجد نسخة احتياطية لاختبارها"
    else:
        try:
            with tempfile.TemporaryDirectory() as tmp:
                raw = Path(tmp) / "restored.db"
                with gzip.open(row["path"], "rb") as f_in, raw.open("wb") as f_out:
                    shutil.copyfileobj(f_in, f_out)
                info["tested"] = row["path"]
                info["sha_matches"] = _sha(Path(row["path"])) == row["sha256"]
                check = inspect(raw)
                info.update(check)
                info["ok"] = bool(check["ok"] and info["sha_matches"])
                if not info["ok"]:
                    info["note"] = "النسخة لا تُفتح كاملة"
        except Exception as exc:
            log.exception("restore test failed")
            info["note"] = f"{type(exc).__name__}: {exc}"[:300]
    with db.tx(True) as c:
        c.execute("INSERT INTO backup_log(at,kind,path,size,sha256,ok,note) VALUES(?,?,?,?,?,?,?)",
                  (util.now_iso(), "restore-test", None, None, None, int(info["ok"]), info["note"] or (f"اختُبرت {Path(info.get('tested', '')).name}" if info["ok"] else None)))
    return info


def restore_from(stream: IO[bytes], *, allow_bad_chain: bool = False) -> dict[str, Any]:
    """Puts a backup (.db.gz, read from `stream`) in place of the live database. The app must be stopped first (restore.sh does that).

    Nothing is replaced unless the copy is a whole SQLite database of this program's version that passes SQLite's integrity check and whose event
    chains are unbroken (a broken chain can be accepted on purpose, when it is the only copy left). The database that was there is kept beside the
    new one as minjaz.db.before-restore-<time>, with its -wal and -shm files, so a mistaken restore can be undone by renaming it back."""
    info: dict[str, Any] = {"ok": False, "note": ""}
    config.DATA_DIR.mkdir(parents=True, exist_ok=True)
    live = config.db_path()
    with tempfile.TemporaryDirectory(dir=config.DATA_DIR, prefix=".restore-") as tmp:
        raw = Path(tmp) / "incoming.db"
        try:
            with gzip.GzipFile(fileobj=stream) as z_in, raw.open("wb") as f_out:
                shutil.copyfileobj(z_in, f_out, 1 << 20)
        except (OSError, EOFError, gzip.BadGzipFile):
            info["note"] = "الملف ليس نسخة احتياطية مضغوطة سليمة (db.gz)"
            return info
        with raw.open("rb") as f:
            if f.read(16) != b"SQLite format 3\x00":
                info["note"] = "الملف ليس قاعدة بيانات SQLite"
                return info
        try:
            check = inspect(raw)
        except sqlite3.DatabaseError as exc:
            info["note"] = f"تعذّر فتح النسخة: {exc}"[:300]
            return info
        info.update(check)
        if check.get("integrity") != "ok":
            info["note"] = "فشل فحص سلامة النسخة؛ لم يتغيّر شيء"
            return info
        if check.get("schema") != db.SCHEMA_VERSION:
            info["note"] = f"النسخة من إصدار قاعدة بيانات مختلف ({check.get('schema')}) وهذا البرنامج يتوقع {db.SCHEMA_VERSION}؛ لم يتغيّر شيء"
            return info
        if check.get("bad_chains") and not allow_bad_chain:
            info["note"] = "سلسلة السجل في النسخة غير سليمة؛ لم يتغيّر شيء (استعمل --allow-bad-chain إن كانت آخر نسخة لديك)"
            return info
        stamp = util.now().strftime("%Y%m%d-%H%M%S")
        kept = live.with_name(f"{live.name}.before-restore-{stamp}")
        if live.exists():
            os.replace(live, kept)
            for ext in ("-wal", "-shm"):
                side = Path(str(live) + ext)
                if side.exists():
                    os.replace(side, Path(str(kept) + ext))
            info["kept_old_as"] = kept.name
        os.replace(raw, live)
    db.init()
    with db.tx(True) as c:  # the history says that it happened: the chain goes on from where the copy stopped
        for co in db.all_(c, "SELECT id FROM companies ORDER BY id"):
            db.emit(c, co["id"], "system.restored", data={"events_in_copy": check["events"], "kept_old_as": info.get("kept_old_as", ""),
                                                          "bad_chain_accepted": bool(check.get("bad_chains"))})
        c.execute("INSERT INTO backup_log(at,kind,path,size,sha256,ok,note) VALUES(?,?,?,?,?,?,?)",
                  (util.now_iso(), "restore", None, None, None, 1, f"استُعيدت نسخة فيها {check['events']} حدثًا"))
    info["ok"] = True
    return info


def due_today() -> str | None:
    """'weekly' on Sundays, 'daily' otherwise, when it is past the backup hour and none was made today; else None."""
    now = util.now()
    if now.hour < config.BACKUP_HOUR_LOCAL:
        return None
    today = now.strftime("%Y-%m-%d")
    with db.tx() as c:
        made = db.scalar(c, "SELECT COUNT(*) FROM backup_log WHERE ok=1 AND kind IN ('daily','weekly') AND substr(at,1,10)=?", today, default=0)
    if made:
        return None
    return "weekly" if now.weekday() == 6 else "daily"
