"""MINJAZ (مِنجَز): a work diary that follows a remote marketing employee, with evidence for every call.

Standard library only. It has its own database, its own files and its own secrets, and it shares nothing with any other project.
"""

__version__ = "0.1.0"
APP_NAME = "MINJAZ"
