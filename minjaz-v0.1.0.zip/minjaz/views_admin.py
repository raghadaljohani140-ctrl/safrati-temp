"""Company administration: settings, work phones, the activity log, exports, and (for the platform operator) backups."""
from __future__ import annotations

import asyncio
import csv
import datetime as dt
import io
from pathlib import Path

from . import backup, config, consts, db, devices, phones, reports, settings as st, ui, util
from .routes import route
from .ui import badge, button, card, checkbox, e, field, form, notice_box, page, pager, select, table, textarea
from .views_common import EVENT_LABELS, describe_event, outcome_labels, reason_labels
from .views_leads import filters_from
from .web import HttpError, download

GROUPS = [
    ("المنصة والرسائل", "ما يظهر للموظف والعميل", ["platform_name", "platform_url", "link_message", "opening_script"]),
    ("الدوام والخطة اليومية", "كم يعمل الموظف وكم رقمًا يأخذ كل يوم", ["tz", "shift_hours", "planned_break_minutes", "minutes_per_call", "daily_new", "gap_minutes",
                                                                      "auto_close_hours", "start_time", "start_grace_min"]),
    ("ساعات الاتصال", "المكالمات الترويجية لها ساعات مسموحة", ["lock_call_hours", "call_start", "call_end", "ramadan", "ramadan_start", "ramadan_end", "allow_landline"]),
    ("جدول المتابعات", "بعد كم يوم يُتصل بالعميل مرة أخرى", ["fu_interested", "fu_no_answer", "fu_phone_off", "fu_link_sent", "fu_visited"]),
    ("التقييم", "أوزان تقييم اليوم ونقاط النتائج", ["w_exec", "w_results", "w_quality", "w_discipline", "target_points", "pts_registered_confirmed",
                                                   "pts_registered_reported", "pts_link_opened", "pts_link_sent", "pts_interested", "min_note_len"]),
    ("نسب التسجيل للموظف", "تُطبَّق على ما يُلصق بعد التغيير", ["attribution_days"]),
]


def _g(v) -> str:
    return f"{v:g}" if isinstance(v, (int, float)) else str(v)


def setting_field(key: str, value) -> str:
    default, typ, label, hint = st.DEFS[key]
    if typ == "bool":
        return checkbox(label, key, bool(value), hint=hint)
    if typ in ("int", "float"):
        return field(label, key, _g(value), type_="number", min_=0, step="any" if typ == "float" else 1, hint=hint, inputmode="decimal")
    if typ == "time":
        return field(label, key, value, type_="time", hint=hint)
    if typ == "text":
        return textarea(label, key, value, rows=3, hint=hint, maxlength=600)
    return field(label, key, value, hint=hint, ltr=key in ("platform_url", "tz") or typ == "days", maxlength=300)


# ------------------------------------------------------------------------------------------------ settings
@route("GET", "/m/settings", auth="manager", perm="settings.manage")
async def settings_page(req):
    ctx = req.ctx
    covered = {k for _, _, ks in GROUPS for k in ks}
    assert covered == set(st.DEFS), "every setting must be on the page"
    s = ctx.settings

    def go(c):
        return outcome_labels(c, ctx.cid), reason_labels(c, ctx.cid)

    olabels, rlabels = await db.read(go)
    groups = "".join(card("".join(setting_field(k, s[k]) for k in keys), title=title, sub=sub) for title, sub, keys in GROUPS)
    main = form(req, "/m/settings", '<input type="hidden" name="_all" value="1">' + groups + button("حفظ الإعدادات", big=True, icon_name="check"))
    labels = form(req, "/m/settings/labels",
                  '<h3>أزرار نتيجة المكالمة</h3>' + "".join(field(f"«{consts.OUTCOME_LABELS_DEFAULT.get(k, k)}»", f"o_{k}", v, maxlength=60) for k, v in olabels.items())
                  + '<h3>أسباب ترك المهمة</h3>' + "".join(field(consts.REASON_LABELS_DEFAULT.get(k, k), f"r_{k}", v, maxlength=60) for k, v in rlabels.items())
                  + button("حفظ الأسماء", kind="soft"))
    body = (notice_box("تغيير الإعدادات يسري من الآن، ولا يُعاد حساب التقارير المختومة. كل تغيير يُسجَّل باسمك في سجل العمليات.", "info")
            + main + card(labels, title="أسماء الأزرار", sub="تغيّر الاسم الظاهر فقط؛ لا يتغير معنى النتيجة في التقارير"))
    return page(req, "الإعدادات", body, active="settings")


@route("POST", "/m/settings", auth="manager", perm="settings.manage")
async def settings_save(req):
    ctx = req.ctx
    old = ctx.settings
    new: dict[str, str] = {}
    for key, (default, typ, label, hint) in st.DEFS.items():
        if typ == "bool":
            new[key] = "1" if req.f(key) else "0"
        elif key in req.form_keys:
            new[key] = req.f(key)
    errors = []
    for key, raw in new.items():
        ok, why = st.validate(key, raw)
        if not ok:
            errors.append(why)
    if "tz" in new and new["tz"] and not util.tz_known(new["tz"]):
        errors.append("المنطقة الزمنية غير معروفة (مثل Asia/Riyadh)")
    weights = [util.to_float(new.get(k, old[k]), 0) or 0 for k in ("w_exec", "w_results", "w_quality", "w_discipline")]
    if sum(weights) <= 0:
        errors.append("مجموع أوزان التقييم يجب أن يكون أكبر من صفر")
    if "attribution_days" in new and not 1 <= (util.to_int(new["attribution_days"], 0) or 0) <= 365:
        errors.append("مدة نسب التسجيل بين 1 و365 يومًا")
    if errors:
        return ui.flash_redirect("/m/settings", "err", "؛ ".join(dict.fromkeys(errors))[:280])

    def go(c):
        changes = {}
        for key, raw in new.items():
            val = st.convert(key, raw)
            if val != old[key]:
                db.set_setting(c, ctx.cid, key, val if st.DEFS[key][1] not in ("bool",) else int(val))
                changes[key] = [str(old[key])[:80], str(val)[:80]]
        if changes:
            db.emit(c, ctx.cid, "settings.changed", actor=ctx.uid, data={"keys": sorted(changes), "changes": changes})
        return len(changes)

    n = await db.write(go)
    return ui.flash_redirect("/m/settings", "ok", f"حُفظ تغيير {n} إعدادًا" if n else "لا تغييرات للحفظ")


@route("POST", "/m/settings/labels", auth="manager", perm="settings.manage")
async def labels_save(req):
    ctx = req.ctx

    def go(c):
        changed = []
        for table_, prefix in (("outcome_types", "o_"), ("reasons", "r_")):
            for r in c.execute(f"SELECT code, label FROM {table_} WHERE company_id=?", (ctx.cid,)).fetchall():
                v = req.f(prefix + r["code"])[:60]
                if v and v != r["label"]:
                    c.execute(f"UPDATE {table_} SET label=? WHERE company_id=? AND code=?", (v, ctx.cid, r["code"]))
                    changed.append(prefix + r["code"])
        if changed:
            db.emit(c, ctx.cid, "settings.changed", actor=ctx.uid, data={"keys": ["labels"], "changes": {k: ["", ""] for k in changed}})
        return len(changed)

    n = await db.write(go)
    return ui.flash_redirect("/m/settings", "ok", f"حُفظ تغيير {n} اسمًا" if n else "لا تغييرات للحفظ")


# ------------------------------------------------------------------------------------------------ work phones
@route("GET", "/m/devices", auth="manager", perm="devices.manage")
async def devices_page(req):
    ctx = req.ctx
    tz = ctx.tz

    def go(c):
        devs = c.execute("SELECT d.*, u.name AS user_name FROM devices d LEFT JOIN users u ON u.id=d.user_id WHERE d.company_id=? ORDER BY d.revoked_at IS NOT NULL, d.id DESC",
                         (ctx.cid,)).fetchall()
        emps = c.execute("SELECT id, name FROM users WHERE company_id=? AND role='employee' AND active=1 ORDER BY name", (ctx.cid,)).fetchall()
        since = util.iso(util.now() - dt.timedelta(days=7))
        cov = c.execute("SELECT evidence, COUNT(*) n FROM call_attempts WHERE company_id=? AND status='recorded' AND started_at>=? GROUP BY evidence", (ctx.cid, since)).fetchall()
        loose = devices.unrecorded_calls(c, ctx.cid)
        recent = c.execute("SELECT dc.*, l.name AS lead_name FROM device_calls dc JOIN leads l ON l.id=dc.lead_id WHERE dc.company_id=? ORDER BY dc.id DESC LIMIT 30", (ctx.cid,)).fetchall()
        return devs, emps, dict((r["evidence"], r["n"]) for r in cov), loose, recent

    devs, emps, cov, loose, recent = await db.read(go)
    total = sum(cov.values())
    documented = cov.get(2, 0) + cov.get(3, 0)
    cov_txt = (f"{documented} من {total} مكالمة مسجَّلة في آخر 7 أيام موثَّقة بسجل جهاز ({ui.pct(documented, total)})" if total
               else "لا مكالمات مسجَّلة في آخر 7 أيام")
    drows = []
    for d in devs:
        state = badge("أُلغي", "bad") if d["revoked_at"] else (badge("متصل", "ok") if d["last_seen_at"] and util.parse_iso(d["last_seen_at"]) > util.now() - dt.timedelta(hours=1) else badge("خامل", "muted"))
        rev = "" if d["revoked_at"] else form(req, f"/m/devices/{d['id']}/revoke", button("إلغاء الربط", kind="ghost", small=True, confirm="إلغاء ربط هذا الجهاز؟ لن يستطيع إرسال مكالمات بعدها."), cls="inline")
        drows.append([e(d["name"]) + (f'<div class="sub">{e(d["model"])}</div>' if d["model"] else ""), e(d["user_name"] or "مشترك"), e(d["app_version"] or "—"),
                      e(ui.ago(d["last_seen_at"]) if d["last_seen_at"] else "—"), e(ui.ago(d["last_sync_at"]) if d["last_sync_at"] else "—"), state, rev])
    add = form(req, "/m/devices/code", select("لمن هذا الجهاز؟", "user", [("", "جهاز مشترك للفريق")] + [(u["id"], u["name"]) for u in emps])
               + field("اسم الجهاز", "note", "", maxlength=60, placeholder="مثال: جوال العمل 1") + button("إنشاء رمز ربط", icon_name="plus"))
    loose_rows = [[e(ui.fmt_dt(r["started_at"], tz)), f'<a href="/m/lead/{r["lead_id"]}">{e(r["lead_name"])}</a>', e(util.fmt_call_duration(r["duration_sec"])), e(r["device_name"])]
                  for r in loose]
    recent_rows = [[e(ui.fmt_dt(r["started_at"], tz)), f'<a href="/m/lead/{r["lead_id"]}">{e(r["lead_name"])}</a>',
                    {"outgoing": "صادرة", "incoming": "واردة", "missed": "فائتة", "rejected": "مرفوضة"}.get(r["call_type"], r["call_type"]),
                    e(util.fmt_call_duration(r["duration_sec"])), badge("طابقت مكالمة مسجَّلة", "ok") if r["attempt_id"] else badge("بلا تسجيل", "muted")] for r in recent]
    body = (card(f"<p>{e(cov_txt)}</p>"
                 '<p class="sub mt">جهاز العمل يرسل لنا فقط المكالمات الصادرة والواردة لأرقام عملائك: الرقم ووقت البدء والمدة. لا تسجيل صوتي ولا استماع ولا قراءة لجهات الاتصال الشخصية. '
                 'أي رقم ليس من عملائك يُتجاهل ولا يُحفظ. المكالمة الموثَّقة بسجل الجهاز ترفع «الثقة» في نتيجتها؛ لكنها تثبت أن الاتصال تمّ لا ما قيل فيه.</p>',
                 title="توثيق المكالمات بجهاز العمل")
            + card(add, title="ربط جهاز جديد", sub="تطبيق أندرويد المساعد هو المرحلة التالية؛ الواجهة جاهزة له من الآن")
            + card(table(["الجهاز", "الموظف", "الإصدار", "آخر ظهور", "آخر مزامنة", "الحالة", ""], drows, empty_text="لا أجهزة مرتبطة بعد"), title="الأجهزة")
            + card(table(["الوقت", "العميل", "المدة", "الجهاز"], loose_rows, empty_text="كل مكالمات الجهاز مرتبطة بتسجيلات"), title="مكالمات صادرة لم تُسجَّل نتيجتها",
                   sub="آخر 7 أيام: اتصل أحدهم بعميل من الجهاز دون ضغط «اتصال» أو تسجيل نتيجة")
            + card(table(["الوقت", "العميل", "النوع", "المدة", "الربط"], recent_rows, empty_text="لم تصل مكالمات من الأجهزة بعد"), title="آخر ما أرسلته الأجهزة"))
    return page(req, "الأجهزة", body, active="devices", wide=True)


@route("POST", "/m/devices/code", auth="manager", perm="devices.manage")
async def device_code(req):
    ctx = req.ctx
    user_id = util.to_int(req.f("user"))

    def go(c):
        if user_id and not db.one(c, "SELECT 1 FROM users WHERE id=? AND company_id=? AND role='employee'", user_id, ctx.cid):
            return None
        return devices.new_code(c, ctx.cid, ctx.uid, user_id, req.f("note"))

    code = await db.write(go)
    if code is None:
        return ui.flash_redirect("/m/devices", "err", "الموظف غير صالح")
    pretty = code[:4] + "-" + code[4:]
    body = card(notice_box(f"الرمز صالح {devices.CODE_MINUTES} دقيقة ويُستعمل مرة واحدة. لن يظهر مرة أخرى.", "warn")
                + f'<p class="code-big ltr">{e(pretty)}</p>'
                + '<p>في تطبيق MINJAZ على جهاز العمل: اكتب عنوان هذا الموقع ثم الرمز. بعد الربط يرسل الجهاز مكالماته لأرقام عملائك فقط.</p>'
                + button("العودة للأجهزة", href="/m/devices", kind="ghost"), title="رمز الربط")
    resp = page(req, "رمز الربط", body, active="devices")
    resp.header("Cache-Control", "no-store")
    return resp


@route("POST", "/m/devices/<int:did>/revoke", auth="manager", perm="devices.manage")
async def device_revoke(req, did: int):
    ctx = req.ctx
    ok = await db.write(devices.revoke, ctx.cid, did, ctx.uid)
    return ui.flash_redirect("/m/devices", "ok" if ok else "err", "أُلغي ربط الجهاز" if ok else "الجهاز غير موجود")


# ------------------------------------------------------------------------------------------------ the activity log
LOG_GROUPS = {"": "الكل", "call": "المكالمات", "shift": "الدوام", "lead": "العملاء", "import": "الاستيراد", "plan": "الخطط", "user": "المستخدمون",
              "auth": "الدخول", "settings": "الإعدادات", "device": "الأجهزة", "compare": "المقارنة", "report": "التقارير", "export": "التصدير", "link": "الروابط"}


@route("GET", "/m/log", auth="manager", perm="log.view")
async def log_page(req):
    ctx = req.ctx
    grp = req.q("g") if req.q("g") in LOG_GROUPS else ""
    uid = util.to_int(req.q("u"))
    day = req.q("day")
    pg = max(1, util.to_int(req.q("page"), 1) or 1)
    where, args = ["e.company_id=?"], [ctx.cid]
    if grp:
        where.append("e.type LIKE ?")
        args.append(grp + ".%")
    if uid:
        where.append("(e.user_id=? OR e.actor_id=?)")
        args += [uid, uid]
    if day:
        where.append("e.day=?")
        args.append(day)
    w = " AND ".join(where)

    def go(c):
        total = db.scalar(c, f"SELECT COUNT(*) FROM events e WHERE {w}", *args, default=0)
        rows = c.execute(f"SELECT e.*, l.name AS lead_name FROM events e LEFT JOIN leads l ON l.id=e.lead_id WHERE {w} ORDER BY e.seq DESC LIMIT 50 OFFSET ?",
                         (*args, (pg - 1) * 50)).fetchall()
        users = c.execute("SELECT id, name FROM users WHERE company_id=? ORDER BY name", (ctx.cid,)).fetchall()
        return total, rows, users, outcome_labels(c, ctx.cid), reason_labels(c, ctx.cid)

    total, rows, users, ol, rl = await db.read(go)
    names = {u["id"]: u["name"] for u in users}
    flt = form(req, "/m/log", f'<div class="filters">{select("النوع", "g", list(LOG_GROUPS.items()), grp)}{select("الشخص", "u", [("", "الكل")] + [(u["id"], u["name"]) for u in users], uid or "")}'
                              f'{field("اليوم", "day", day, type_="date")}{button("تصفية", small=True, icon_name="search")}</div>', method="get")
    trs = []
    for ev in rows:
        who = names.get(ev["actor_id"] or ev["user_id"], "النظام")
        lead = f' · <a href="/m/lead/{ev["lead_id"]}">{e(ev["lead_name"] or "عميل")}</a>' if ev["lead_id"] else ""
        trs.append([e(ui.fmt_dt(ev["ts"], ctx.tz)), e(who), f'<b>{e(EVENT_LABELS.get(ev["type"], ev["type"]))}</b>{lead}', e(describe_event(ev, ol, rl)),
                    f'<span class="muted num">{ev["seq"]}</span>'])
    pages = max(1, -(-total // 50))
    q = "&".join(f"{k}={v}" for k, v in (("g", grp), ("u", uid or ""), ("day", day)) if v)
    verify = form(req, "/m/log/verify", button("فحص سلامة السجل", kind="soft", small=True, icon_name="shield"), cls="inline")
    body = (card(flt, title="سجل العمليات", sub=f"{total:,} حدثًا · لا يُعدَّل ولا يُحذف", actions=verify)
            + card(table(["الوقت", "الشخص", "الحدث", "التفصيل", "التسلسل"], trs, empty_text="لا أحداث بهذه المواصفات") + pager(pg, pages, "/m/log" + (f"?{q}" if q else "")))
            + '<p class="sub">كل حدث مرتبط بما قبله ببصمة رقمية؛ فأي تعديل أو حذف لاحق يكسر السلسلة ويظهر عند فحص السلامة.</p>')
    return page(req, "سجل العمليات", body, active="log", wide=True)


@route("POST", "/m/log/verify", auth="manager", perm="log.view")
async def log_verify(req):
    ctx = req.ctx
    r = await db.read(db.verify_chain, ctx.cid)
    if r["ok"]:
        return ui.flash_redirect("/m/log", "ok", f"السجل سليم: {r['checked']:,} حدثًا متسلسلًا لم يُعدَّل منها شيء")
    return ui.flash_redirect("/m/log", "err", f"تعارض في السجل عند الحدث رقم {r.get('bad_seq')}: تواصل مع مشغّل المنصة فورًا")


# ------------------------------------------------------------------------------------------------ exports
def _csv(headers: list[str], rows) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(headers)
    for r in rows:
        w.writerow(r)
    return "﻿" + buf.getvalue()


@route("GET", "/m/export", auth="manager", perm="backup.download")
async def export_page(req):
    ctx = req.ctx
    items = [("leads.csv", "العملاء", "كل العملاء بحالتهم وموظفيهم وتواريخ المتابعة", "leads.export"),
             ("calls.csv", "المكالمات", "كل محاولة اتصال بنتيجتها المصحَّحة ودرجة الثقة", "backup.download"),
             ("events.csv", "سجل العمليات", "كل الأحداث المسجَّلة بتسلسلها وبصمتها", "backup.download")]
    cards = "".join(f'<a class="kind" href="/m/export/{f}">{ui.icon("download")}<span>{e(t)}<small>{e(d)}</small></span></a>' for f, t, d, perm in items if ctx.can(perm))
    body = (card(f'<div class="kinds">{cards}</div><p class="sub mt">ملفات CSV تفتح في Excel. كل تصدير يُسجَّل في سجل العمليات باسمك. '
                 'لنسخ قاعدة البيانات كاملة تواصل مع مشغّل المنصة.</p>', title="تصدير بيانات شركتك"))
    return page(req, "تصدير البيانات", body, active="export")


@route("GET", "/m/export/leads.csv", auth="manager", perm="leads.export")
async def export_leads(req):
    ctx = req.ctx
    where, args, _ = filters_from(req)

    def go(c):
        rows = c.execute(f"SELECT l.*, u.name AS owner_name, b.filename FROM leads l LEFT JOIN users u ON u.id=l.owner_id LEFT JOIN lead_batches b ON b.id=l.batch_id"
                         f" WHERE {where} ORDER BY l.id LIMIT 200000", args).fetchall()
        db.emit(c, ctx.cid, "export.data", actor=ctx.uid, data={"what": "العملاء", "rows": len(rows)})
        return rows

    rows = await db.write(go)
    text = _csv(["الرقم المرجعي", "الاسم", "الجوال", "جوال ثانٍ", "المدينة", "الحالة", "الموظف", "المحاولات", "آخر اتصال", "المتابعة القادمة", "أُضيف", "الملف", "الرابط أُرسل", "الرابط فُتح", "سجّل (تأكيد)"],
                [[r["id"], r["name"], phones.display(r["phone"]), phones.display(r["phone_alt"]), r["city"] or "", consts.STATUS_LABELS.get(r["status"], r["status"]),
                  r["owner_name"] or "", r["attempts"], r["last_call_at"] or "", r["next_follow_up"] or "", r["added_at"][:10], r["filename"] or "", r["link_sends"], r["link_opens"],
                  r["confirmed_at"][:10] if r["confirmed_at"] else ""] for r in rows])
    return download(text, f"minjaz-leads-{util.local_date(util.now(), ctx.tz)}.csv", "text/csv; charset=utf-8")


@route("GET", "/m/export/calls.csv", auth="manager", perm="backup.download")
async def export_calls(req):
    ctx = req.ctx

    def go(c):
        rows = c.execute(f"SELECT a.*, {reports.EFFECTIVE} AS eff, l.name AS lead_name, u.name AS user_name FROM call_attempts a JOIN leads l ON l.id=a.lead_id JOIN users u ON u.id=a.user_id"
                         f" WHERE a.company_id=? ORDER BY a.id LIMIT 300000", (ctx.cid,)).fetchall()
        db.emit(c, ctx.cid, "export.data", actor=ctx.uid, data={"what": "المكالمات", "rows": len(rows)})
        return rows, outcome_labels(c, ctx.cid)

    rows, ol = await db.write(go)
    text = _csv(["رقم المحاولة", "اليوم", "بدأت", "الموظف", "العميل", "الجوال", "الحالة", "النتيجة بعد التصحيح", "النتيجة الأصلية", "الثقة", "المدة (ث)", "ملاحظة"],
                [[r["id"], r["day"], r["started_at"], r["user_name"], r["lead_name"], phones.display(r["phone"]), r["status"], ol.get(r["eff"], r["eff"] or ""),
                  ol.get(r["outcome"], r["outcome"] or ""), consts.EVIDENCE[r["evidence"]][0], r["duration_sec"] or "", r["note"] or ""] for r in rows])
    return download(text, f"minjaz-calls-{util.local_date(util.now(), ctx.tz)}.csv", "text/csv; charset=utf-8")


@route("GET", "/m/export/events.csv", auth="manager", perm="backup.download")
async def export_events(req):
    ctx = req.ctx

    def go(c):
        rows = c.execute("SELECT e.*, u.name AS user_name, a.name AS actor_name FROM events e LEFT JOIN users u ON u.id=e.user_id LEFT JOIN users a ON a.id=e.actor_id"
                         " WHERE e.company_id=? ORDER BY e.seq LIMIT 500000", (ctx.cid,)).fetchall()
        db.emit(c, ctx.cid, "export.data", actor=ctx.uid, data={"what": "سجل العمليات", "rows": len(rows)})
        return rows

    rows = await db.write(go)
    text = _csv(["التسلسل", "الوقت (UTC)", "اليوم", "النوع", "الفاعل", "الموظف", "العميل", "تفاصيل", "البصمة"],
                [[r["seq"], r["ts"], r["day"], r["type"], r["actor_name"] or "", r["user_name"] or "", r["lead_id"] or "", r["data"], r["hash"]] for r in rows])
    return download(text, f"minjaz-events-{util.local_date(util.now(), ctx.tz)}.csv", "text/csv; charset=utf-8")


# ------------------------------------------------------------------------------------------------ backups (platform operator only)
def _operator(req) -> None:
    if not req.ctx.user.get("is_platform_admin"):
        raise HttpError(403, "هذه الصفحة لمشغّل المنصة فقط")


@route("GET", "/m/backups", auth="manager")
async def backups_page(req):
    _operator(req)
    ctx = req.ctx

    def go(c):
        return c.execute("SELECT * FROM backup_log ORDER BY id DESC LIMIT 40").fetchall()

    rows = await db.read(go)
    trs = []
    for r in rows:
        kind = {"daily": "يومية", "weekly": "أسبوعية", "manual": "يدوية", "restore-test": "اختبار استرجاع"}.get(r["kind"], r["kind"])
        dl = f'<a href="/m/backups/{r["id"]}/download">تنزيل</a>' if r["path"] and r["ok"] else ""
        trs.append([e(ui.fmt_dt(r["at"], ctx.tz)), e(kind), badge("نجحت", "ok") if r["ok"] else badge("فشلت", "bad"), e(f"{(r['size'] or 0) / 1024:,.0f} ك.ب") if r["size"] else "—",
                    e(r["note"] or ""), dl])
    actions = (form(req, "/m/backups/make", button("نسخة الآن", small=True, icon_name="backup"), cls="inline")
               + form(req, "/m/backups/test", button("اختبار الاسترجاع", small=True, kind="soft"), cls="inline"))
    body = card(table(["الوقت", "النوع", "النتيجة", "الحجم", "ملاحظة", ""], trs, empty_text="لا نسخ بعد")
                + f'<p class="sub mt">تُؤخذ نسخة يومية بعد الساعة {config_hour()} بتوقيت UTC، ونسخة أسبوعية الأحد، وتُختبر النسخة الأسبوعية باسترجاعها في مجلد مؤقت. '
                  f'القاعدة تحوي بيانات كل الشركات؛ لا تُشارك ملفاتها.</p>', title="النسخ الاحتياطية", actions=actions)
    return page(req, "النسخ الاحتياطية", body, active="backups", wide=True)


def config_hour() -> str:
    return f"{config.BACKUP_HOUR_LOCAL:02d}:00"


@route("POST", "/m/backups/make", auth="manager")
async def backups_make(req):
    _operator(req)
    info = await asyncio.to_thread(backup.make_backup, "manual")
    return ui.flash_redirect("/m/backups", "ok" if info["ok"] else "err", "تمت النسخة وفُحصت" if info["ok"] else "فشلت النسخة: " + info["note"])


@route("POST", "/m/backups/test", auth="manager")
async def backups_test(req):
    _operator(req)
    info = await asyncio.to_thread(backup.restore_test)
    msg = (f"الاسترجاع سليم: {info.get('events', 0):,} حدثًا و{info.get('leads', 0):,} عميلًا" if info["ok"] else "فشل الاختبار: " + (info["note"] or "راجع السجل"))
    return ui.flash_redirect("/m/backups", "ok" if info["ok"] else "err", msg)


@route("GET", "/m/backups/<int:bid>/download", auth="manager")
async def backups_download(req, bid: int):
    _operator(req)
    row = await db.read(lambda c: db.one(c, "SELECT * FROM backup_log WHERE id=? AND ok=1 AND path IS NOT NULL", bid))
    if not row or not Path(row["path"]).exists():
        raise HttpError(404, "النسخة غير موجودة")
    return download(Path(row["path"]).read_bytes(), Path(row["path"]).name, "application/gzip")
