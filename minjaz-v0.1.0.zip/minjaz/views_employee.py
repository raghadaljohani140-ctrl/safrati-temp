"""The employee's screens: start the day, work through the list, record results, close the day."""
from __future__ import annotations

import sqlite3
import urllib.parse
from typing import Any

from . import consts, db, leads as leadlib, phones, plans, reports, ui, util, work
from .routes import route
from .ui import badge, button, card, e, field, form, icon, notice_box, page, select, textarea
from .views_common import (evidence_badge, kind_label, outcome_labels, reason_labels, render_day_report, score_badge, site_url)
from .web import Response, json_response, redirect

OC_TONE = {"interested": "pos", "registered": "pos", "asked_link": "pos", "not_interested": "neg", "wrong_number": "neg",
           "no_answer": "unr", "phone_off": "unr"}


# ------------------------------------------------------------------------------------------------ loading the day
def load_day(c: sqlite3.Connection, ctx, gap_check: bool = True) -> dict[str, Any]:
    s = ctx.settings
    user = db.one(c, "SELECT * FROM users WHERE id=?", ctx.uid)
    shift = work.current_shift(c, ctx.uid)
    today = util.local_date(util.now(), s["tz"])
    d: dict[str, Any] = {"user": user, "shift": shift, "plan": None, "prog": None, "brk": None, "gap": None, "today": today, "preview": None}
    if shift:
        d["plan"] = plans.plan_for(c, ctx.uid, shift["work_date"])
        d["prog"] = plans.progress(c, d["plan"]["id"]) if d["plan"] else None
        d["brk"] = work.open_break(c, shift["id"])
        if gap_check:
            d["gap"] = work.check_gap(c, user, shift, s)
        work.touch_seen(c, shift["id"])
    else:
        fu = plans.due_followups(c, ctx.cid, ctx.uid, today)
        cap = plans.capacity(s, user)
        target = plans.daily_new_for(s, user)
        d["preview"] = {"followups": len(fu), "capacity": cap, "target": target, "new": min(target, max(0, cap - len(fu))),
                        "done_today": db.one(c, "SELECT * FROM shifts WHERE user_id=? AND work_date=?", ctx.uid, today),
                        "pool": leadlib.pool_count(c, ctx.cid, bool(s["allow_landline"]))}
    return d


async def day_state(req, gap_check: bool = True) -> dict[str, Any]:
    return await db.write(load_day, req.ctx, gap_check)


def gap_redirect(req) -> Response:
    return redirect("/w/gap?next=" + urllib.parse.quote(req.target if req.method == "GET" else "/w"))


# ------------------------------------------------------------------------------------------------ home
@route("GET", "/w", auth="employee")
async def home(req):
    ctx = req.ctx
    d = await day_state(req)
    if d["gap"]:
        return gap_redirect(req)
    s = ctx.settings
    name = ctx.user["name"].split(" ")[0]
    if not d["shift"]:
        pv = d["preview"]
        if pv["done_today"]:
            body = card(f'<p>أنهيت يوم العمل اليوم. شكرًا لك.</p>{button("تقرير يومي", href=f"/w/day/{d["today"]}", kind="soft")}', title=f"مرحبًا {name}")
            return page(req, "اليوم", body, active="home")
        trim = ""
        if pv["target"] > pv["new"]:
            trim = notice_box(f"لن تسع خطة اليوم كل الأرقام الجديدة: المتابعات {pv['followups']} من سعة {pv['capacity']} مكالمة، فيقل الجديد إلى {pv['new']}.", "warn")
        short = notice_box("لا توجد أرقام جديدة كافية في المخزون الآن. سيُبلَّغ مديرك.", "warn") if pv["pool"] == 0 and pv["new"] > 0 and pv["followups"] == 0 else ""
        stats = ('<div class="grid">' + ui.stat("متابعات مستحقة", pv["followups"], tone="brand" if pv["followups"] else "")
                 + ui.stat("أرقام جديدة", pv["new"]) + ui.stat("سعة اليوم", pv["capacity"], sub="مكالمة") + "</div>")
        start = form(req, "/w/start", button("ابدأ يوم العمل", big=True, icon_name="play"), cls="mt")
        body = card(f'<p class="sub">{e(ui.fmt_day(d["today"]))}</p>{stats}{trim}{short}{start}', title=f"مرحبًا {name}")
        return page(req, "اليوم", body, active="home")
    sh, prog, plan = d["shift"], d["prog"], d["plan"]
    m = await db.read(lambda c: reports.day_metrics(c, ctx.cid, ctx.uid, sh["work_date"], s))
    brk_secs = await db.read(lambda c: work.break_seconds(c, sh["id"], util.now()))
    parts = []
    if d["brk"]:
        parts.append(card(f'<p>أنت في استراحة منذ <b class="num" data-since="{e(d["brk"]["started_at"])}">0:00:00</b></p>'
                          + form(req, "/w/break", f'<input type="hidden" name="do" value="end">{button("العودة للعمل", big=True, icon_name="play")}'),
                          cls="accent", title="استراحة"))
    ring = ui.ring(prog["done"], prog["total"], f"أنجزت {prog['done']} من {prog['total']}")
    mini = (f'<div class="hero-s"><div class="mini"><b>{prog["open"]}</b><span>متبقية</span></div>'
            f'<div class="mini"><b>{m["calls"]["total"]}</b><span>مكالمات مسجَّلة</span></div>'
            f'<div class="mini"><b>{m["interested"]}</b><span>مهتمون</span></div>'
            f'<div class="mini"><b class="num" data-since="{e(sh["started_at"])}" data-break-sec="{brk_secs}"{" data-frozen=1" if d["brk"] else ""}>0:00:00</b><span>وقت العمل</span></div></div>')
    hero = f'<div class="hero">{ring}{mini}</div>'
    nxt = None
    if not d["brk"]:
        nxt = await db.read(lambda c: _next_info(c, plan["id"]))
    if d["brk"]:
        cta = ""
    elif nxt:
        cta = button(f"التالي: {nxt['name']}", href=f"/w/lead/{nxt['lead_id']}", big=True, icon_name="next", cls="mt")
    else:
        more = ""
        room = plan["capacity"] - prog["total"]
        if room > 0:
            more = form(req, "/w/more", button(f"أحتاج أرقامًا إضافية (حتى {min(20, room)})", kind="ghost", big=True), cls="mt")
        if prog["total"]:
            done_note = notice_box("أنجزت كل مهام اليوم. أحسنت!", "ok")
        else:
            done_note = notice_box("لا توجد مهام في خطتك اليوم لأن الأرقام الجديدة انتهت من المخزون. أُبلغ مديرك، ويمكنك طلب أرقام حين تُضاف.", "warn")
        cta = done_note + more
    parts.append(card(hero + cta, title=f"مرحبًا {name}", sub=ui.fmt_day(sh["work_date"])))
    kinds = []
    for k, label in consts.TASK_KINDS:
        info = prog["by_kind"].get(k)
        if info and info["total"]:
            kinds.append(f'<a class="kind" href="/w/tasks?kind={k}">{e(label)}<b>{info["open"]}</b><small>من {info["total"]}</small></a>')
    if kinds:
        parts.append(card('<div class="kinds">' + "".join(kinds) + "</div>", title="قائمة اليوم"))
    parts.append(f'<div class="row">{form(req, "/w/break", f"<input type=hidden name=do value=start>{button("استراحة", kind="ghost", icon_name="coffee")}", cls="inline") if not d["brk"] else ""}'
                 f'{button("إنهاء اليوم", href="/w/end", kind="ghost", icon_name="flag")}</div>')
    parts.append(f'<p class="foot">موعد نهاية الدوام المتوقع {e(ui.fmt_time(sh["planned_end_at"], s["tz"]))}</p>')
    return page(req, "اليوم", "".join(parts), active="home")


def _next_info(c: sqlite3.Connection, plan_id: int) -> dict | None:
    t = plans.next_task(c, plan_id)
    if not t:
        return None
    lead = db.one(c, "SELECT name FROM leads WHERE id=?", t["lead_id"])
    return {"lead_id": t["lead_id"], "name": lead["name"] if lead else ""}


@route("POST", "/w/start", auth="employee")
async def start(req):
    ctx = req.ctx

    def go(c):
        user = db.one(c, "SELECT * FROM users WHERE id=?", ctx.uid)
        return work.start_day(c, user, ctx.settings)

    ok, msg, _ = await db.write(go)
    return ui.flash_redirect("/w", "ok" if ok else "err", "بدأ يوم العمل. بالتوفيق!" if ok else msg)


@route("POST", "/w/break", auth="employee")
async def do_break(req):
    ctx = req.ctx
    action = req.f("do")

    def go(c):
        user = db.one(c, "SELECT * FROM users WHERE id=?", ctx.uid)
        sh = work.current_shift(c, ctx.uid)
        if not sh:
            return False, "لا يوجد يوم مفتوح"
        return work.start_break(c, user, sh) if action == "start" else work.end_break(c, user, sh)

    ok, msg = await db.write(go)
    return ui.flash_redirect("/w", "ok" if ok else "err", ("بدأت الاستراحة" if action == "start" else "عدت للعمل") if ok else msg)


@route("POST", "/w/more", auth="employee")
async def more(req):
    ctx = req.ctx

    def go(c):
        user = db.one(c, "SELECT * FROM users WHERE id=?", ctx.uid)
        sh = work.current_shift(c, ctx.uid)
        plan = plans.plan_for(c, ctx.uid, sh["work_date"]) if sh else None
        return plans.add_more(c, user, plan, ctx.settings) if plan else 0

    n = await db.write(go)
    return ui.flash_redirect("/w", "ok" if n else "warn", f"أُضيف {n} رقمًا جديدًا" if n else "لا توجد أرقام إضافية الآن، أو بلغت سعة اليوم")


@route("POST", "/w/ping", auth="employee")
async def ping(req):
    d = await day_state(req)
    return json_response({"gap": bool(d["gap"])})


# ------------------------------------------------------------------------------------------------ the list
@route("GET", "/w/next", auth="employee")
async def next_(req):
    d = await day_state(req)
    if d["gap"]:
        return gap_redirect(req)
    if not d["plan"] or d["brk"]:
        return redirect("/w")
    nxt = await db.read(lambda c: _next_info(c, d["plan"]["id"]))
    if not nxt:
        return ui.flash_redirect("/w", "ok", "أنجزت كل المهام")
    return redirect(f"/w/lead/{nxt['lead_id']}")


@route("GET", "/w/tasks", auth="employee")
async def tasks(req):
    ctx = req.ctx
    d = await day_state(req)
    if d["gap"]:
        return gap_redirect(req)
    if not d["plan"]:
        return redirect("/w")
    kind = req.q("kind")
    show = "done" if req.q("show") == "done" else "open"
    rows = await db.read(lambda c: plans.tasks_for(c, d["plan"]["id"], kind))
    labels = await db.read(outcome_labels, ctx.cid)
    rl = await db.read(reason_labels, ctx.cid)
    groups: dict[str, list] = {}
    for t in rows:
        if (t["status"] == "open") == (show == "open"):
            groups.setdefault(t["kind"], []).append(t)
    tabs = (f'<div class="row mb">{button("المتبقية", href="/w/tasks" + (f"?kind={kind}" if kind else ""), kind="primary" if show == "open" else "ghost", small=True)}'
            f'{button("المنجزة", href="/w/tasks?show=done" + (f"&kind={kind}" if kind else ""), kind="primary" if show == "done" else "ghost", small=True)}'
            f'{button("كل القوائم", href="/w/tasks", kind="ghost", small=True) if kind else ""}</div>')
    out = [tabs]
    if not groups:
        out.append(card(ui.empty("لا توجد مهام هنا" if show == "open" else "لم تُنجز مهام بعد")))
    for k, label in consts.TASK_KINDS:
        items = groups.get(k)
        if not items:
            continue
        out.append(f'<h3 class="group-h">{e(label)} {badge(str(len(items)))}</h3>')
        for t in items:
            sub = [e(t["city"] or "")]
            if t["kind"] in ("callback", "overdue") and t["next_follow_time"]:
                sub.append(f'موعد {e(t["next_follow_time"])}')
            tag = ""
            if t["status"] == "done":
                tag = badge(labels.get(t["outcome"], "تم"), "ok")
            elif t["status"] == "reason":
                tag = badge(rl.get(t["reason_code"], "سبب"), "muted")
            elif t["lead_status"] != "new":
                tag = ui.status_badge(t["lead_status"])
            cls = "task done" if t["status"] == "done" else "task reason" if t["status"] == "reason" else "task"
            out.append(f'<a class="{cls}" href="/w/lead/{t["lead_id"]}"><div class="t-main"><div class="t-name">{e(t["name"])}</div>'
                       f'<div class="t-sub">{ui.phone(t["phone"])} {" · ".join(x for x in sub if x)}</div></div>{tag}{icon("next", "chev")}</a>')
    return page(req, "المهام", "".join(out), active="tasks")


# ------------------------------------------------------------------------------------------------ the client card
def load_card(c: sqlite3.Connection, ctx, lead_id: int) -> dict[str, Any] | None:
    d = load_day(c, ctx)
    lead = db.one(c, "SELECT * FROM leads WHERE id=? AND company_id=? AND owner_id=?", lead_id, ctx.cid, ctx.uid)
    if not lead:
        return None
    s = ctx.settings
    d["lead"] = lead
    d["labels"] = outcome_labels(c, ctx.cid)
    d["types"] = c.execute("SELECT * FROM outcome_types WHERE company_id=? AND active=1 ORDER BY sort", (ctx.cid,)).fetchall()
    d["open_attempt"] = db.one(c, "SELECT * FROM call_attempts WHERE lead_id=? AND user_id=? AND status='open' ORDER BY id DESC LIMIT 1", lead_id, ctx.uid)
    d["history"] = c.execute(f"SELECT a.*, {reports.EFFECTIVE} AS eff FROM call_attempts a WHERE a.lead_id=? AND a.status='recorded' ORDER BY a.id DESC LIMIT 6", (lead_id,)).fetchall()
    d["task"] = plans.open_task_for_lead(c, d["plan"]["id"], lead_id) if d["plan"] else None
    d["link"] = leadlib.make_link_token(c, lead_id) if s["platform_url"] else None
    return d


def _wa_url(req, lead, token: str | None, s: dict) -> str | None:
    if not token or not s["platform_url"]:
        return None
    link = f"{site_url(req)}/l/{token}"
    msg = leadlib.fill_template(s["link_message"], name=lead["name"], platform=s["platform_name"] or "المنصة", link=link)
    return f"https://wa.me/{phones.wa_digits(lead['phone'])}?text={urllib.parse.quote(msg)}"


def render_card(req, d: dict[str, Any], *, error: str = "", values: dict | None = None, saved: str = "", status: int = 200) -> Response:
    ctx = req.ctx
    s = ctx.settings
    lead = d["lead"]
    v = values or {}
    workable = (lead["status"] in leadlib.OPEN_STATUSES or lead["status"] == "exhausted") and not lead["do_not_call"]
    blockers = []
    if not d["shift"]:
        blockers.append("ابدأ يوم العمل من الصفحة الرئيسية قبل الاتصال.")
    elif d["brk"]:
        blockers.append("أنت في استراحة. أنهِها قبل الاتصال.")
    if lead["do_not_call"]:
        blockers.append("طلب هذا العميل عدم الاتصال به.")
    elif not workable:
        blockers.append("هذا العميل أُغلق ملفه: " + consts.STATUS_LABELS.get(lead["status"], ""))
    ok_hours, hours_msg = work.in_call_hours(s)
    if d["shift"] and not ok_hours:
        blockers.append(hours_msg)
    can_call = not blockers
    tel = f"tel:{lead['phone']}"
    if can_call:
        call_btn = f'<a class="btn call lg" href="{e(tel)}" data-beacon="/w/lead/{lead["id"]}/call">{icon("phone")}<span>اتصال</span></a>'
    else:
        call_btn = f'<span class="btn call off lg">{icon("phone")}<span>اتصال</span></span>'
    wa_url = _wa_url(req, lead, d["link"], s)
    if wa_url and can_call:
        wa_btn = (f'<a class="btn wa lg" href="{e(wa_url)}" target="_blank" rel="noopener" data-beacon="/w/lead/{lead["id"]}/link">'
                  f'{icon("chat")}<span>واتساب</span></a>')
    else:
        wa_btn = f'<span class="btn wa off lg">{icon("chat")}<span>واتساب</span></span>'
    notes = "".join(f'<div class="note warn">{e(b)}</div>' for b in blockers)
    if not s["platform_url"] and can_call:
        notes += '<div class="note info">زر الواتساب يحتاج أن يضبط المدير رابط المنصة في الإعدادات.</div>'
    started = d["open_attempt"]
    started_html = (f'<p id="call-started" class="note info{"" if started else " hidden"}">بدأت المكالمة'
                    f'{" " + e(ui.ago(started["started_at"])) if started else ""}. بعد أن تنتهي سجّل النتيجة بالأسفل.</p>')
    meta = []
    if lead["city"]:
        meta.append(e(lead["city"]))
    if lead["attempts"]:
        meta.append(f'اتصالات سابقة: {lead["attempts"]}')
    if lead["status"] == "callback" and lead["next_follow_up"]:
        meta.append(f'موعد المعاودة {e(lead["next_follow_up"])} {e(lead["next_follow_time"] or "")}')
    elif lead["next_follow_up"] and lead["status"] in leadlib.FOLLOW_STATUSES:
        meta.append(f'المتابعة المقررة {e(lead["next_follow_up"])}')
    src = (f'<a class="sub" href="{e(lead["source_url"])}" target="_blank" rel="noopener noreferrer">رابط الإعلان</a>' if lead["source_url"] else "")
    link_info = ""
    if lead["link_sends"] or lead["link_opens"]:
        link_info = f'<p class="sub">الرابط: أُرسل {lead["link_sends"]} مرة، فُتح {lead["link_opens"]} مرة{" · آخر فتح " + e(ui.ago(lead["link_opened_at"])) if lead["link_opened_at"] else ""}</p>'
    last_note = f'<p class="note">{e(lead["note_last"])}</p>' if lead["note_last"] else ""
    head = card(
        f'<div class="row between">{ui.status_badge(lead["status"])}<span class="sub">{" · ".join(meta)}</span></div>'
        f'<h1>{e(lead["name"])}</h1><span class="big-num">{e(phones.display(lead["phone"]))}</span>'
        f'<div class="call-row">{call_btn}{wa_btn}</div>{started_html}{notes}{src}{link_info}{last_note}', cls="who-card", id_="client")
    saved_html = ""
    if saved:
        extra = ""
        if saved in ("asked_link", "interested") and wa_url:
            extra = f'<a class="btn wa lg mt" href="{e(wa_url)}" target="_blank" rel="noopener" data-beacon="/w/lead/{lead["id"]}/link">{icon("chat")}<span>أرسل الرابط الآن عبر واتساب</span></a>'
        saved_html = card(f'<p>تم حفظ النتيجة: <b>{e(d["labels"].get(saved, ""))}</b></p>{extra}{button("العميل التالي", href="/w/next", big=True, icon_name="next", cls="mt")}',
                          cls="accent")
    script = leadlib.fill_template(s["opening_script"], employee=ctx.user["name"], company=ctx.company["name"], platform=s["platform_name"] or "المنصة",
                                   name=lead["name"])
    script_html = f'<details class="fold" open><summary>{icon("chat")} بطاقة افتتاح المكالمة</summary><div><div class="script"><b>قل:</b>{e(script)}</div></div></details>'
    hist = ""
    if d["history"]:
        items = "".join(f'<li><div class="tl-t">{e(ui.fmt_dt(h["recorded_at"], s["tz"]))} · {evidence_badge(h["evidence"])}</div>'
                        f'<b>{e(d["labels"].get(h["eff"], h["eff"]))}</b>{" — " + e(h["note"]) if h["note"] else ""}</li>' for h in d["history"])
        hist = card(f'<ul class="timeline">{items}</ul>', title="سجل المكالمات")
    panel = ""
    if can_call:
        oc = []
        for t in d["types"]:
            tone = OC_TONE.get(t["code"], "")
            wide = " wide" if t["code"] == "registered" else ""
            chk = " checked" if v.get("outcome") == t["code"] else ""
            oc.append(f'<label class="oc {tone}{wide}"><input type="radio" name="outcome" value="{e(t["code"])}" data-note="{t["needs_note"]}" data-dt="{t["needs_datetime"]}" required{chk}>'
                      f'<span>{e(t["label"])}</span></label>')
        today = d["today"]
        fields = (f'<div class="oc-grid">{"".join(oc)}</div>'
                  f'<div data-dt-box class="hidden"><div class="row"><div style="flex:1">{field("يوم الاتصال", "fu_date", v.get("fu_date", ""), type_="date", min_=today)}</div>'
                  f'<div style="flex:1">{field("الوقت", "fu_time", v.get("fu_time", ""), type_="time")}</div></div></div>'
                  f'<div data-note-box class="hidden"><label class="field"><span class="lbl" data-note-label>ملاحظة</span>'
                  f'<textarea name="note" rows="3" maxlength="500" placeholder="ماذا قال العميل؟">{e(v.get("note", ""))}</textarea></label></div>'
                  f'<label class="check"><input type="checkbox" name="dnc" value="1"{" checked" if v.get("dnc") else ""}><span>طلب العميل ألا نتصل به مرة أخرى<small>يُغلق ملفه فلا يظهر في أي خطة</small></span></label>'
                  f'<button class="btn primary lg" type="submit" data-save disabled>{icon("check")}<span>حفظ النتيجة</span></button>')
        err = notice_box(error, "bad") if error else ""
        panel = card(err + form(req, f"/w/lead/{lead['id']}/outcome", fields, id_="outcome-form"), title="نتيجة المكالمة", id_="outcome-panel")
    skip = ""
    if d["task"] and can_call:
        skip = form(req, f"/w/skip/{d['task']['id']}", button("أجّل هذا العميل لآخر القائمة", kind="ghost", small=True), cls="center")
    return page(req, lead["name"], saved_html + head + script_html + panel + hist + skip, active="tasks", back="/w/tasks", status=status)


async def _card(req, lead_id: int, **kw) -> Response:
    d = await db.write(load_card, req.ctx, lead_id)
    if d is None:
        return ui.error_page(req, 403, "ليس في قائمتك", "هذا العميل غير مسند إليك أو لم يعد موجودًا.")
    if d["gap"]:
        return gap_redirect(req)
    return render_card(req, d, **kw)


@route("GET", "/w/lead/<int:lead_id>", auth="employee")
async def lead_card(req, lead_id: int):
    return await _card(req, lead_id, saved=req.q("saved"))


@route("POST", "/w/lead/<int:lead_id>/call", auth="employee")
async def lead_call(req, lead_id: int):
    ctx = req.ctx

    def go(c):
        user = db.one(c, "SELECT * FROM users WHERE id=?", ctx.uid)
        return work.start_call(c, user, ctx.settings, lead_id)

    ok, msg, _ = await db.write(go)
    return Response(b"", 204 if ok else 409)


@route("POST", "/w/lead/<int:lead_id>/link", auth="employee")
async def lead_link(req, lead_id: int):
    ctx = req.ctx

    def go(c):
        user = db.one(c, "SELECT * FROM users WHERE id=?", ctx.uid)
        return work.record_link_sent(c, user, lead_id)

    ok, _ = await db.write(go)
    return Response(b"", 204 if ok else 409)


@route("POST", "/w/lead/<int:lead_id>/outcome", auth="employee")
async def lead_outcome(req, lead_id: int):
    ctx = req.ctx
    vals = {"outcome": req.f("outcome"), "note": req.f("note"), "fu_date": req.f("fu_date"), "fu_time": req.f("fu_time"), "dnc": req.f("dnc")}

    def go(c):
        user = db.one(c, "SELECT * FROM users WHERE id=?", ctx.uid)
        return work.record_outcome(c, user, ctx.settings, lead_id, vals["outcome"], vals["note"], vals["fu_date"], vals["fu_time"], bool(vals["dnc"]))

    ok, msg, info = await db.write(go)
    if not ok:
        return await _card(req, lead_id, error=msg, values=vals, status=400)
    if vals["outcome"] in ("asked_link", "interested") and not vals["dnc"]:
        return redirect(f"/w/lead/{lead_id}?saved={vals['outcome']}")
    return ui.flash_redirect("/w/next", "ok", "تم حفظ النتيجة")


@route("POST", "/w/skip/<int:task_id>", auth="employee")
async def skip(req, task_id: int):
    ctx = req.ctx

    def go(c):
        user = db.one(c, "SELECT * FROM users WHERE id=?", ctx.uid)
        return work.skip_task(c, user, task_id)

    await db.write(go)
    return redirect("/w/next")


# ------------------------------------------------------------------------------------------------ quiet gaps
@route("GET", "/w/gap", auth="employee")
async def gap_page(req):
    d = await day_state(req)
    if not d["gap"]:
        return redirect(_safe(req.q("next")))
    g = d["gap"]
    mins = max(1, int((util.parse_iso(g["ended_at"]) - util.parse_iso(g["started_at"])).total_seconds() // 60))
    buttons = "".join(f'<button class="btn ghost lg" type="submit" name="reason" value="{k}">{e(v)}</button>' for k, v in consts.GAP_REASONS if k != "other")
    body = (f'<div class="gap-box"><h1>مضت {mins} دقيقة بلا نشاط</h1><p class="sub">ماذا كنت تفعل؟ جوابك يُحفظ في تقرير يومك.</p>'
            + form(req, "/w/gap", f'<input type="hidden" name="gap_id" value="{g["id"]}"><input type="hidden" name="next" value="{e(req.q("next"))}">'
                   f'<div class="reasons">{buttons}</div>'
                   f'<details class="fold mt"><summary>أخرى</summary><div>{textarea("اكتب ما حدث", "text", maxlength=200)}'
                   f'<button class="btn primary lg" type="submit" name="reason" value="other">حفظ</button></div></details>') + "</div>")
    return page(req, "ماذا حدث؟", card(body), hide_nav=True)


def _safe(url: str) -> str:
    from .web import safe_next

    out = safe_next(url or "/w")
    return out if out.startswith("/w") else "/w"


@route("POST", "/w/gap", auth="employee")
async def gap_answer(req):
    ctx = req.ctx
    gap_id = util.to_int(req.f("gap_id"), 0)
    reason, text = req.f("reason"), req.f("text")

    def go(c):
        user = db.one(c, "SELECT * FROM users WHERE id=?", ctx.uid)
        sh = work.current_shift(c, ctx.uid)
        if not sh:
            return True, ""
        return work.answer_gap(c, user, sh, gap_id, reason, text)

    ok, msg = await db.write(go)
    if not ok:
        return ui.flash_redirect("/w/gap?next=" + urllib.parse.quote(req.f("next")), "err", msg)
    return redirect(_safe(req.f("next")))


# ------------------------------------------------------------------------------------------------ closing the day
@route("GET", "/w/end", auth="employee")
async def end_page(req):
    ctx = req.ctx
    d = await day_state(req)
    if d["gap"]:
        return gap_redirect(req)
    if not d["shift"]:
        return redirect("/w")
    s = ctx.settings
    rows = await db.read(lambda c: plans.tasks_for(c, d["plan"]["id"], status="open"))
    m = await db.read(lambda c: reports.day_metrics(c, ctx.cid, ctx.uid, d["shift"]["work_date"], s))
    summary = (f'<div class="grid">{ui.stat("منجزة", f"{m["tasks"]["done"]} / {m["tasks"]["total"]}")}{ui.stat("مكالمات", m["calls"]["total"])}'
               f'{ui.stat("مهتمون", m["interested"])}{ui.stat("روابط", m["links"]["sent"])}</div>')
    reasons = await db.read(lambda c: c.execute("SELECT * FROM reasons WHERE company_id=? AND active=1 ORDER BY sort", (ctx.cid,)).fetchall())
    opts = [("", "— اختر السبب —")] + [(r["code"], r["label"]) for r in reasons]
    fld = ""
    if rows:
        needs = {r["code"]: r["needs_text"] for r in reasons}
        sel_all = (f'<label class="field"><span class="lbl">لماذا بقيت {len(rows)} مهمة بلا نتيجة؟</span>'
                   f'<select name="all_reason" data-other-text="all-text" required>{"".join(f"<option value=\"{e(k)}\" data-needs-text=\"{needs.get(k, 0)}\">{e(t)}</option>" for k, t in opts)}</select></label>'
                   f'<div id="all-text" class="hidden">{field("اكتب السبب", "all_text", maxlength=200)}</div>')
        per = "".join(f'<div class="row between"><span>{e(t["name"])}</span><select class="sel" name="reason_{t["id"]}">'
                      f'{"".join(f"<option value=\"{e(k)}\">{e(tt)}</option>" for k, tt in [("", "نفس السبب أعلاه")] + opts[1:])}</select></div>' for t in rows[:80])
        fld = sel_all + f'<details class="fold"><summary>تفصيل لكل مهمة</summary><div class="stack">{per}</div></details>'
    else:
        fld = notice_box("لا توجد مهام متبقية. يمكنك إنهاء يومك.", "ok")
    body = (card(summary, title="ملخص اليوم") + card(form(req, "/w/end", fld + textarea("ملاحظة ختامية (اختيارية)", "note", maxlength=300)
                                                          + button("إنهاء يوم العمل", big=True, icon_name="flag", confirm="هل تريد إنهاء يوم العمل؟")), title="إنهاء اليوم"))
    return page(req, "إنهاء اليوم", body, active="home", back="/w")


@route("POST", "/w/end", auth="employee")
async def end_post(req):
    ctx = req.ctx
    all_reason, all_text, note = req.f("all_reason"), req.f("all_text"), req.f("note")

    def go(c):
        user = db.one(c, "SELECT * FROM users WHERE id=?", ctx.uid)
        sh = work.current_shift(c, ctx.uid)
        if not sh:
            return False, "لا يوجد يوم مفتوح", None
        plan = plans.plan_for(c, ctx.uid, sh["work_date"])
        reasons: dict[int, tuple[str, str]] = {}
        for t in c.execute("SELECT id FROM tasks WHERE plan_id=? AND status='open'", (plan["id"],)).fetchall():
            own = req.f(f"reason_{t['id']}")
            reasons[t["id"]] = (own, "") if own else (all_reason, all_text)
        ok, msg = work.close_day(c, user, sh, ctx.settings, reasons, note)
        return ok, msg, sh["work_date"]

    ok, msg, day = await db.write(go)
    if not ok:
        return ui.flash_redirect("/w/end", "err", msg)
    return ui.flash_redirect(f"/w/day/{day}", "ok", "أُنهي يوم العمل. شكرًا لك!")


# ------------------------------------------------------------------------------------------------ reports, search, account
def _valid_day(day: str) -> bool:
    try:
        import datetime as dt

        dt.date.fromisoformat(day)
        return True
    except ValueError:
        return False


@route("GET", "/w/day/<day>", auth="employee")
async def my_day(req, day: str):
    ctx = req.ctx
    if not _valid_day(day):
        return ui.error_page(req, 404, "تاريخ غير صالح", "")
    m = await db.read(lambda c: reports.metrics_for(c, ctx.cid, ctx.uid, day, ctx.settings))
    labels = await db.read(outcome_labels, ctx.cid)
    if not m:
        return page(req, "تقرير اليوم", card(ui.empty("لا يوجد يوم عمل في هذا التاريخ")), active="me", back="/w/me")
    return page(req, "تقرير اليوم", render_day_report(m, labels, ctx.tz), active="me", back="/w/me")


@route("GET", "/w/me", auth="employee")
async def me(req):
    ctx = req.ctx
    s = ctx.settings

    def go(c):
        out = []
        for r in c.execute("SELECT work_date, status FROM shifts WHERE user_id=? ORDER BY work_date DESC LIMIT 14", (ctx.uid,)).fetchall():
            m = reports.metrics_for(c, ctx.cid, ctx.uid, r["work_date"], s)
            out.append((r["work_date"], r["status"], m))
        return out

    days = await db.read(go)
    rows = []
    for day, status, m in days:
        if not m:
            continue
        rows.append(f'<a class="task" href="/w/day/{day}"><div class="t-main"><div class="t-name">{e(ui.fmt_day(day, with_year=False))}</div>'
                    f'<div class="t-sub">{m["calls"]["total"]} مكالمة · {m["interested"]} مهتم · {m["tasks"]["done"]}/{m["tasks"]["total"]} مهمة</div></div>'
                    f'{score_badge(m["rating"]["score"] if m["rating"] else None)}{icon("next", "chev")}</a>')
    acct = (f'<dl class="kv"><dt>الاسم</dt><dd>{e(ctx.user["name"])}</dd><dt>اسم المستخدم</dt><dd class="ltr">{e(ctx.user["username"])}</dd>'
            f'<dt>الشركة</dt><dd>{e(ctx.company["name"])}</dd></dl><div class="row mt">{button("كلمة المرور", href="/password", kind="ghost", small=True)}'
            f'{button("الخصوصية وما يُسجَّل", href="/privacy", kind="ghost", small=True)}</div>')
    return page(req, "حسابي", card(acct, title="حسابي") + card("".join(rows) or ui.empty("لا أيام سابقة"), title="آخر أيامي"), active="me")


@route("GET", "/w/search", auth="employee")
async def search(req):
    ctx = req.ctx
    q = req.q("q")
    results = []
    if q:
        digits = "".join(ch for ch in util.ascii_digits(q) if ch.isdigit())

        def go(c):
            if len(digits) >= 4:
                return c.execute("SELECT * FROM leads WHERE company_id=? AND owner_id=? AND phone LIKE ? LIMIT 30", (ctx.cid, ctx.uid, f"%{digits.lstrip('0')}%")).fetchall()
            return c.execute("SELECT * FROM leads WHERE company_id=? AND owner_id=? AND name LIKE ? LIMIT 30", (ctx.cid, ctx.uid, f"%{q}%")).fetchall()

        results = await db.read(go)
    items = "".join(f'<a class="task" href="/w/lead/{r["id"]}"><div class="t-main"><div class="t-name">{e(r["name"])}</div><div class="t-sub">{ui.phone(r["phone"])} {e(r["city"] or "")}</div></div>'
                    f'{ui.status_badge(r["status"])}{icon("next", "chev")}</a>' for r in results)
    body = card(form(req, "/w/search", f'<div class="row"><div style="flex:1">{field("اسم العميل أو رقمه", "q", q, autofocus=not q)}</div></div>{button("بحث", icon_name="search")}', method="get"),
                title="بحث في قائمتي")
    if q:
        body += items or card(ui.empty("لا نتائج"))
    return page(req, "بحث", body, active="search")


# ------------------------------------------------------------------------------------------------ the client's personal link
BOT_WORDS = ("whatsapp", "facebookexternalhit", "telegram", "twitterbot", "slackbot", "bot", "crawler", "spider", "preview", "curl", "wget",
             "python", "headless", "okhttp", "go-http", "linkedin", "discord", "skype")


@route("GET", "/l/<token>", auth="none")
async def personal_link(req, token: str):
    ua = req.headers.get("user-agent", "").lower()
    is_bot = (not ua) or any(w in ua for w in BOT_WORDS) or req.headers.get("sec-purpose", "").startswith("prefetch") or req.headers.get("purpose") == "prefetch"

    def go(c):
        lead = db.one(c, "SELECT id, company_id, owner_id, link_opened_at FROM leads WHERE link_token=?", token)
        if not lead:
            return None
        url = db.scalar(c, "SELECT value FROM settings WHERE company_id=? AND key='platform_url'", lead["company_id"], default="")
        if not is_bot:
            recent = db.one(c, "SELECT ts FROM events WHERE company_id=? AND lead_id=? AND type='link.opened' ORDER BY seq DESC LIMIT 1", lead["company_id"], lead["id"])
            if not recent or (util.now() - util.parse_iso(recent["ts"])).total_seconds() > 60:
                now = util.now_iso()
                c.execute("UPDATE leads SET link_opened_at=?, link_opens=link_opens+1 WHERE id=?", (now, lead["id"]))
                db.emit(c, lead["company_id"], "link.opened", user=lead["owner_id"], lead=lead["id"])
        return url

    url = await db.write(go)
    if url is None:
        return Response("الرابط غير صالح", 404, "text/plain; charset=utf-8")
    if not url:
        return Response("الرابط غير مفعّل بعد", 200, "text/plain; charset=utf-8")
    return Response(b"", 302, "text/plain", [("Location", url), ("Cache-Control", "no-store"), ("Referrer-Policy", "no-referrer")])
