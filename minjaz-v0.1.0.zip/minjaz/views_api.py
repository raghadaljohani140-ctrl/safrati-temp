"""The phone-facing API (`/api/v1`): plain JSON. A work phone links itself once with a short code, then sends its call log with a token.

Only calls to numbers that are this company's clients are kept (see devices.py). The phone app is a later stage; this is its other half.
"""
from __future__ import annotations

from . import db, devices, security, util
from .routes import route
from .web import HttpError, json_response

LIMITER = security.LIMITER


def err(message: str, status: int = 400):
    return json_response({"ok": False, "error": message}, status)


def bearer(req) -> str:
    h = req.headers.get("authorization", "")
    return h[7:].strip() if h.lower().startswith("bearer ") else ""


def body(req) -> dict | None:
    try:
        data = req.json()
    except HttpError:
        return None
    return data if isinstance(data, dict) else None


async def device_for(req):
    """Returns (device, None) or (None, error response). Failed attempts are throttled per address."""
    ip = req.ip
    if not LIMITER.allow(f"api-bad:{ip}", 30, 300, record=False):
        return None, err("محاولات كثيرة، انتظر قليلًا", 429)
    dev = await db.read(devices.authenticate, bearer(req))
    if dev is None:
        LIMITER.allow(f"api-bad:{ip}", 30, 300)
        return None, err("الجهاز غير مرتبط أو أُلغي ربطه", 401)
    if not LIMITER.allow(f"api-dev:{dev['id']}", 120, 60):
        return None, err("طلبات كثيرة", 429)
    return dev, None


@route("POST", "/api/v1/enroll", auth="api")
async def enroll(req):
    if not LIMITER.allow(f"enroll:{req.ip}", 8, 600):
        return err("محاولات كثيرة، انتظر عشر دقائق", 429)
    data = body(req)
    if data is None:
        return err("الطلب ليس JSON صالحًا")
    code = str(data.get("code", ""))

    def go(c):
        return devices.enroll(c, code, str(data.get("name", "")), str(data.get("model", "")), str(data.get("app_version", "")))

    try:
        res = await db.write(go)
    except devices.DeviceProblem as ex:
        return err(str(ex), 403)
    return json_response({"ok": True, **res, "poll_seconds": 300})


@route("GET", "/api/v1/ping", auth="api")
async def ping(req):
    dev, bad = await device_for(req)
    if bad:
        return bad
    await db.write(lambda c: c.execute("UPDATE devices SET last_seen_at=? WHERE id=?", (util.now_iso(), dev["id"])))
    return json_response({"ok": True, "time": util.now_iso(), "device_id": dev["id"], "user_id": dev["user_id"]})


@route("POST", "/api/v1/calls", auth="api")
async def calls(req):
    dev, bad = await device_for(req)
    if bad:
        return bad
    data = body(req)
    items = data.get("calls") if data else None
    if not isinstance(items, list):
        return err('أرسل {"calls": [...]}')

    def go(c):
        return devices.ingest(c, dev, items, db.get_settings(c, dev["company_id"]))

    stats = await db.write(go)
    return json_response({"ok": True, **stats})


@route("GET", "/api/v1/watch", auth="api")
async def watch(req):
    dev, bad = await device_for(req)
    if bad:
        return bad
    return json_response({"ok": True, **await db.read(devices.watch, dev)})
