"""Putting MINJAZ's work next to the platform's numbers, without ever touching the platform.

Two inputs, both typed or pasted by the manager and stored as they came, with who and when:
  * four running totals read off the platform's admin page (owners, approved ads, views, WhatsApp clicks); we work out the daily difference;
  * the owners table copied from that page; we match each owner's phone to a client and decide whether the registration is the employee's.

The rule for "whose registration is it" (the plan's attribution rule):
  registered after the first contact and within N days of the last contact (a call or a link sent)  -> the employee's
  registered before the first contact                                                              -> "registered before contact", nobody's
  registered more than N days after the last contact                                               -> "late", counted only if the manager approves
  a phone that matches no client                                                                    -> "unmatched", the manager may link it by hand
"""
from __future__ import annotations

import datetime as dt
import re
import sqlite3
from typing import Any

from . import db, phones, util

MAX_ROWS = 3000
HEADER_WORDS = {"الاسم", "الجوال", "الاعلانات", "الإعلانات", "الموافقات", "التسجيل", "الحالة", "name", "phone", "mobile", "ads", "status"}
STATUS_WORDS = {"نشط", "موقوف", "فعال", "معلق", "active", "suspended"}
_DATE1 = re.compile(r"(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})")
_DATE2 = re.compile(r"(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})")
_TIME = re.compile(r"(?<![\d:])(\d{1,2}):(\d{2})(?::\d{2})?\s*([AaPp][Mm]|[صم])?(?![\d:])")
_PHONE_CELL = re.compile(r"^[+\d\s\-()]+$")
_INT = re.compile(r"^\d{1,5}$")

VERDICTS = {
    "ours": ("يُحسب للموظف", "ok"),
    "before": ("سجّل قبل التواصل", "muted"),
    "late": ("تسجيل متأخر", "warn"),
    "unmatched": ("لم يُطابَق", "warn"),
    "already": ("مؤكد سابقًا", "info"),
    "bad": ("صف غير مفهوم", "bad"),
}


class CompareProblem(Exception):
    pass


# ------------------------------------------------------------------------------------------------ reading the pasted table
def parse_date(text: str) -> str | None:
    t = util.ascii_digits(text or "")
    m = _DATE1.search(t)
    try:
        if m:
            return dt.date(int(m[1]), int(m[2]), int(m[3])).isoformat()
        m = _DATE2.search(t)
        if m:
            return dt.date(int(m[3]), int(m[2]), int(m[1])).isoformat()
    except ValueError:
        return None
    return None


def parse_time(text: str) -> str | None:
    """'HH:MM' (24-hour) from a cell such as '2026-11-02 14:30', '9:05 PM' or '٠٩:٠٥ م'; None when there is no time in it."""
    m = _TIME.search(util.ascii_digits(text or ""))
    if not m:
        return None
    h, mi, tag = int(m[1]), int(m[2]), (m[3] or "").lower()
    if tag in ("pm", "م") and h < 12:
        h += 12
    elif tag in ("am", "ص") and h == 12:
        h = 0
    return f"{h:02d}:{mi:02d}" if h < 24 and mi < 60 else None


def _is_phone(cell: str) -> bool:
    c = cell.strip()
    if not c or not _PHONE_CELL.match(c) or sum(ch.isdigit() for ch in c) < 9:
        return False
    return phones.normalize_phone(c).phone is not None


def _cells(line: str) -> list[str]:
    if "\t" in line:
        parts = line.split("\t")
    elif "|" in line:
        parts = line.split("|")
    else:
        parts = re.split(r"\s{2,}", line.strip())
    parts = [p.strip() for p in parts if p.strip()]
    if len(parts) == 1:  # everything on one line with single spaces
        parts = line.split()
    return parts


_TIME_CELL = re.compile(r"^\d{1,2}:\d{2}(?::\d{2})?\s*(?:[AaPp][Mm]|[صم])?$")


def _record(cells: list[str]) -> dict[str, Any] | None:
    pi = next((i for i, x in enumerate(cells) if _is_phone(x)), None)
    if pi is None:
        return None
    rest = cells[pi + 1:]

    def plain(x: str) -> bool:
        return not _INT.match(x) and not parse_date(x) and x not in STATUS_WORDS and not _TIME_CELL.match(x)

    name_parts = [x for x in cells[:pi] if plain(x)]
    if not name_parts:  # some tables put the name after the number
        name_parts = [x for x in rest if plain(x)][:1]
    ints = [int(x) for x in rest if _INT.match(x)]
    date = reg_time = None
    for i, x in enumerate(rest):
        date = parse_date(x)
        if date:  # the time sits in the same cell as the date, or in the cell beside it
            reg_time = parse_time(x) or next((parse_time(y) for y in rest[i + 1:i + 3] if _TIME_CELL.match(y)), None)
            break
    status = next((x for x in rest if x in STATUS_WORDS), "")
    raw = cells[pi]
    ph = phones.normalize_phone(raw)
    return {"name": " ".join(name_parts)[:80], "phone_raw": raw[:30], "phone": ph.phone, "ads": ints[0] if ints else None,
            "approved": ints[1] if len(ints) > 1 else None, "reg_date": date, "reg_time": reg_time, "status": status}


def _is_header(cells: list[str]) -> bool:
    return sum(1 for x in cells if x.strip().lower() in HEADER_WORDS) >= 2


def parse_owners(text: str) -> list[dict[str, Any]]:
    text = util.ascii_digits(text or "").replace(" ", " ").replace("‏", "").replace("‎", "")
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    if not lines:
        return []
    with_phone = sum(1 for ln in lines if any(_is_phone(x) for x in _cells(ln)))
    records: list[dict[str, Any]] = []
    if with_phone >= max(1, int(len(lines) * 0.6)):  # one client per line
        for ln in lines:
            cells = _cells(ln)
            if _is_header(cells):
                continue
            rec = _record(cells)
            if rec:
                records.append(rec)
    else:  # a phone's table copied from a small screen often comes one cell per line
        n = 0
        for i, ln in enumerate(lines):
            if ln.strip().lower() in HEADER_WORDS:
                n = 1
                while i + n < len(lines) and lines[i + n].strip().lower() in HEADER_WORDS:
                    n += 1
                start = i + n
                break
        else:
            start = 0
        if n >= 3:
            body = lines[start:]
            chunks = [body[k:k + n] for k in range(0, len(body) - n + 1, n)]
        else:
            pos = [i for i, ln in enumerate(lines) if _is_phone(ln)]
            if not pos:
                return []
            if len(pos) == 1:
                chunks = [lines[max(0, pos[0] - 1):pos[0] + 5]]
            else:
                gaps = sorted(pos[k + 1] - pos[k] for k in range(len(pos) - 1))
                n = gaps[len(gaps) // 2]
                first = max(0, pos[0] - 1)
                chunks = [lines[k:k + n] for k in range(first, len(lines) - n + 1, n)]
        for ch in chunks:
            rec = _record(ch)
            if rec:
                records.append(rec)
    out, seen = [], set()
    for i, r in enumerate(records, 1):
        r["no"] = i
        r["problem"] = ""
        if r["phone"] is None:
            r["problem"] = "رقم غير صالح"
        elif not r["reg_date"]:
            r["problem"] = "لا أجد تاريخ التسجيل في هذا الصف"
        elif r["phone"] in seen:
            continue
        seen.add(r["phone"])
        out.append(r)
    return out[:MAX_ROWS]


# ------------------------------------------------------------------------------------------------ deciding whose registration it is
def contacts(c: sqlite3.Connection, lead_id: int, tz: str) -> list[tuple[str, str, int]]:
    """Every call and every link sent for a client: (timestamp, local date, employee)."""
    out = []
    for r in c.execute("SELECT started_at AS ts, user_id FROM call_attempts WHERE lead_id=? AND status='recorded'", (lead_id,)):
        out.append((r["ts"], util.local_date(r["ts"], tz), r["user_id"]))
    for r in c.execute("SELECT ts, user_id FROM events WHERE lead_id=? AND type='link.sent' AND user_id IS NOT NULL", (lead_id,)):
        out.append((r["ts"], util.local_date(r["ts"], tz), r["user_id"]))
    return sorted(out)


def judge(found: list[tuple[str, str, int]], reg_date: str, days: int, reg_time: str = "", tz: str = "") -> tuple[str, int | None, str]:
    """-> (verdict, the employee it counts for, a sentence saying why).

    With the registration time (read in the company's zone, the same zone the platform shows) "before the first contact" is decided to the minute:
    a client who registered at 09:00 and was called at 14:00 the same day is nobody's. Without a time the day decides, and a same-day
    registration gets the benefit of the doubt."""
    if not found:
        return "before", None, "لم يتصل أحد بهذا العميل ولم يُرسَل له رابط"
    precise = bool(reg_time and tz)

    def at(x: tuple[str, str, int]) -> str:
        return f"{x[1]} {util.local_hm(x[0], tz)}" if precise else x[1]

    reg = f"{reg_date} {reg_time}" if precise else reg_date
    first = at(found[0])
    if reg < first:
        return "before", None, f"أول تواصل {first}، وسجّل {reg}"
    last = [x for x in found if at(x) <= reg][-1]
    gap = util.days_between(last[1], reg_date)
    if gap <= days:
        return "ours", last[2], f"آخر تواصل {last[1]}، وسجّل بعده بـ {gap} يومًا"
    return "late", last[2], f"آخر تواصل {last[1]}، وسجّل بعده بـ {gap} يومًا (الحد {days})"


def confirm_lead(c: sqlite3.Connection, company_id: int, lead: sqlite3.Row, user_id: int, reg_date: str, actor: int, how: str, ads: int | None) -> None:
    ts = util.now_iso()
    c.execute("UPDATE leads SET status='registered_confirmed', status_at=?, confirmed_at=?, attribution=?, next_follow_up=NULL, next_follow_time=NULL,"
              " registered_at=COALESCE(registered_at, ?) WHERE id=?",
              (ts, ts, util.canon({"user": user_id, "reg_date": reg_date, "how": how}), ts, lead["id"]))
    day = min(reg_date, util.local_date(ts, db.get_settings(c, company_id)["tz"]))
    db.emit(c, company_id, "lead.confirmed", actor=actor, user=user_id, lead=lead["id"], day=day,
            data={"verdict": how, "reg_date": reg_date, "ads": ads})


# ------------------------------------------------------------------------------------------------ the pasted table
def import_owners(c: sqlite3.Connection, company_id: int, actor: int, text: str, s: dict) -> int:
    rows = parse_owners(text)
    if not rows:
        raise CompareProblem("لم أجد أرقام جوال في النص. انسخ جدول صفحة «الملاك» كما هو والصقه هنا.")
    days = int(s["attribution_days"])
    tz = s["tz"]
    sha = util.sha256(text.strip())
    cur = c.execute("INSERT INTO ext_imports(company_id,at,by_user,rows,matched,attributed,text_sha) VALUES(?,?,?,?,0,0,?)",
                    (company_id, util.now_iso(), actor, len(rows), sha))
    imp = int(cur.lastrowid)
    all_leads = c.execute("SELECT * FROM leads WHERE company_id=?", (company_id,)).fetchall()
    leads = {r["phone"]: r for r in all_leads}
    for r in all_leads:  # an owner may have registered with the second number we hold for him; a first number always wins
        if r["phone_alt"]:
            leads.setdefault(r["phone_alt"], r)
    tally: dict[str, int] = {}
    matched = attributed = 0
    for r in rows:
        verdict, user, detail, lead = "bad", None, r["problem"], None
        if not r["problem"]:
            lead = leads.get(r["phone"])
            if lead is None:
                verdict, detail = "unmatched", "لا يوجد عميل بهذا الرقم في MINJAZ"
            else:
                matched += 1
                if lead["confirmed_at"]:
                    verdict, detail = "already", "أُكّد تسجيله من قبل"
                    user = json_user(lead["attribution"])
                else:
                    verdict, user, detail = judge(contacts(c, lead["id"], tz), r["reg_date"], days, r["reg_time"] or "", tz)
        c.execute("INSERT INTO ext_rows(import_id,company_id,row_no,phone,name,ads,approved,reg_date,reg_time,lead_id,verdict,user_id,detail) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  (imp, company_id, r["no"], r["phone"], r["name"], r["ads"], r["approved"], r["reg_date"], r["reg_time"], lead["id"] if lead else None, verdict, user, detail))
        if verdict == "ours" and lead is not None and user:
            confirm_lead(c, company_id, lead, user, r["reg_date"], actor, "ours", r["ads"])
            attributed += 1
        tally[verdict] = tally.get(verdict, 0) + 1
    c.execute("UPDATE ext_imports SET matched=?, attributed=? WHERE id=?", (matched, attributed, imp))
    db.emit(c, company_id, "compare.imported", actor=actor, ref=imp, data={"rows": len(rows), "matched": matched, "attributed": attributed, "verdicts": tally, "sha": sha})
    return imp


def json_user(attribution: str | None) -> int | None:
    d = db.jload(attribution, None)
    return d.get("user") if isinstance(d, dict) else None


def approve_late(c: sqlite3.Connection, company_id: int, row_id: int, actor: int) -> tuple[bool, str]:
    r = db.one(c, "SELECT * FROM ext_rows WHERE id=? AND company_id=?", row_id, company_id)
    if not r or r["verdict"] != "late" or not r["lead_id"] or not r["user_id"]:
        return False, "هذا الصف لا يحتاج اعتمادًا"
    lead = db.one(c, "SELECT * FROM leads WHERE id=?", r["lead_id"])
    if lead["confirmed_at"]:
        return False, "أُكّد تسجيل هذا العميل من قبل"
    confirm_lead(c, company_id, lead, r["user_id"], r["reg_date"], actor, "late_approved", r["ads"])
    c.execute("UPDATE ext_rows SET verdict='ours', decided_by=?, detail=detail||' — اعتمده المدير' WHERE id=?", (actor, row_id))
    c.execute("UPDATE ext_imports SET attributed=attributed+1 WHERE id=?", (r["import_id"],))
    return True, ""


def find_lead(c: sqlite3.Connection, company_id: int, query: str) -> sqlite3.Row | None:
    q = util.ascii_digits(query or "").strip()
    if q.startswith("#") and q[1:].isdigit():
        return db.one(c, "SELECT * FROM leads WHERE id=? AND company_id=?", int(q[1:]), company_id)
    p = phones.normalize_phone(q)
    if p.phone:
        return (db.one(c, "SELECT * FROM leads WHERE company_id=? AND phone=?", company_id, p.phone)
                or db.one(c, "SELECT * FROM leads WHERE company_id=? AND phone_alt=? ORDER BY id LIMIT 1", company_id, p.phone))
    return None


def link_row(c: sqlite3.Connection, company_id: int, row_id: int, query: str, actor: int, s: dict) -> tuple[bool, str]:
    r = db.one(c, "SELECT * FROM ext_rows WHERE id=? AND company_id=?", row_id, company_id)
    if not r or r["verdict"] != "unmatched":
        return False, "هذا الصف مطابَق أو غير قابل للربط"
    lead = find_lead(c, company_id, query)
    if not lead:
        return False, "لا أجد عميلًا بهذا الرقم. اكتب جواله أو #رقمه."
    if lead["confirmed_at"]:
        return False, "هذا العميل أُكّد تسجيله من قبل"
    verdict, user, detail = judge(contacts(c, lead["id"], s["tz"]), r["reg_date"], int(s["attribution_days"]), r["reg_time"] or "", s["tz"])
    detail = f"رُبط يدويًا بـ «{lead['name']}»؛ {detail}"
    c.execute("UPDATE ext_rows SET lead_id=?, verdict=?, user_id=?, detail=?, linked_by=? WHERE id=?", (lead["id"], verdict, user, detail, actor, row_id))
    db.emit(c, company_id, "compare.linked", actor=actor, lead=lead["id"], ref=row_id, data={"phone": r["phone"], "verdict": verdict, "reg_date": r["reg_date"]})
    if verdict == "ours" and user:
        confirm_lead(c, company_id, lead, user, r["reg_date"], actor, "linked", r["ads"])
        c.execute("UPDATE ext_imports SET attributed=attributed+1, matched=matched+1 WHERE id=?", (r["import_id"],))
    else:
        c.execute("UPDATE ext_imports SET matched=matched+1 WHERE id=?", (r["import_id"],))
    return True, ""


# ------------------------------------------------------------------------------------------------ the four running totals
FIELDS = [("owners", "أصحاب الاستراحات"), ("approved_ads", "الإعلانات المعتمدة"), ("views", "المشاهدات"), ("wa_clicks", "ضغطات واتساب")]


def save_daily(c: sqlite3.Connection, company_id: int, actor: int, day: str, vals: dict[str, int], note: str) -> dict[str, Any]:
    prev = db.one(c, "SELECT * FROM ext_daily WHERE company_id=? AND day<? ORDER BY day DESC LIMIT 1", company_id, day)
    old = db.one(c, "SELECT * FROM ext_daily WHERE company_id=? AND day=?", company_id, day)
    c.execute("INSERT OR REPLACE INTO ext_daily(company_id,day,owners,approved_ads,views,wa_clicks,note,entered_by,entered_at) VALUES(?,?,?,?,?,?,?,?,?)",
              (company_id, day, vals["owners"], vals["approved_ads"], vals["views"], vals["wa_clicks"], note[:200] or None, actor, util.now_iso()))
    db.emit(c, company_id, "compare.daily", actor=actor, data={"day": day, **vals, "note": note[:200],
                                                                "replaced": {k: old[k] for k, _ in FIELDS} if old else None})
    lower = [lbl for k, lbl in FIELDS if prev and prev[k] is not None and vals[k] < prev[k]]
    return {"lower": lower}


def daily_table(c: sqlite3.Connection, company_id: int, limit: int = 21) -> list[dict[str, Any]]:
    rows = c.execute("SELECT * FROM ext_daily WHERE company_id=? ORDER BY day DESC LIMIT ?", (company_id, limit + 1)).fetchall()
    out = []
    for i, r in enumerate(rows[:limit]):
        before = rows[i + 1] if i + 1 < len(rows) else None
        d = {"row": r, "delta": {}, "since": util.days_between(before["day"], r["day"]) if before else None}
        for k, _ in FIELDS:
            d["delta"][k] = (r[k] - before[k]) if before and r[k] is not None and before[k] is not None else None
        out.append(d)
    return out


def period_deltas(c: sqlite3.Connection, company_id: int, start: str, end: str) -> dict[str, Any]:
    """Change in each running total over [start, end]: last entry in the period minus the last entry before it."""
    last = db.one(c, "SELECT * FROM ext_daily WHERE company_id=? AND day BETWEEN ? AND ? ORDER BY day DESC LIMIT 1", company_id, start, end)
    if not last:
        return {"ok": False, "why": "لا أرقام مُدخلة في هذه الفترة"}
    base = db.one(c, "SELECT * FROM ext_daily WHERE company_id=? AND day<? ORDER BY day DESC LIMIT 1", company_id, start)
    note = ""
    if not base:
        base = db.one(c, "SELECT * FROM ext_daily WHERE company_id=? AND day BETWEEN ? AND ? ORDER BY day LIMIT 1", company_id, start, end)
        if base and base["day"] == last["day"]:
            return {"ok": False, "why": "رقم واحد فقط في الفترة، ولا رقم قبلها للمقارنة"}
        note = f"من أول رقم مُدخل ({base['day']})"
    out = {"ok": True, "note": note, "last": last, "base": base, "delta": {}}
    for k, _ in FIELDS:
        out["delta"][k] = (last[k] - base[k]) if last[k] is not None and base[k] is not None else None
    return out
