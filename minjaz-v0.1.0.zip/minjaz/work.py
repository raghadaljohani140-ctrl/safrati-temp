"""The employee's working day: start, breaks, gaps, calls, results and closing. Every change leaves an event."""
from __future__ import annotations

import datetime as dt
import sqlite3
from typing import Any

from . import consts, db, leads as leadlib, plans, reports, util

Result = tuple[bool, str]


def current_shift(c: sqlite3.Connection, user_id: int) -> sqlite3.Row | None:
    return db.one(c, "SELECT * FROM shifts WHERE user_id=? AND status='open' ORDER BY id DESC LIMIT 1", user_id)


def open_break(c: sqlite3.Connection, shift_id: int) -> sqlite3.Row | None:
    return db.one(c, "SELECT * FROM breaks WHERE shift_id=? AND ended_at IS NULL ORDER BY id DESC LIMIT 1", shift_id)


def break_seconds(c: sqlite3.Connection, shift_id: int, now: dt.datetime) -> int:
    total = 0.0
    for b in c.execute("SELECT started_at, ended_at FROM breaks WHERE shift_id=?", (shift_id,)):
        end = util.parse_iso(b["ended_at"]) if b["ended_at"] else now
        total += max(0.0, (end - util.parse_iso(b["started_at"])).total_seconds())
    return int(total)


def pending_gap(c: sqlite3.Connection, shift_id: int) -> sqlite3.Row | None:
    return db.one(c, "SELECT * FROM gaps WHERE shift_id=? AND status='pending' ORDER BY id LIMIT 1", shift_id)


def in_call_hours(s: dict, now: dt.datetime | None = None) -> Result:
    if not s["lock_call_hours"]:
        return True, ""
    hm = util.local_hm(now or util.now(), s["tz"])
    start, end = (s["ramadan_start"], s["ramadan_end"]) if s["ramadan"] else (s["call_start"], s["call_end"])
    ok = (start <= hm <= end) if start <= end else (hm >= start or hm <= end)
    return ok, "" if ok else f"الاتصال مقفل الآن. الساعات المسموحة من {start} إلى {end}."


def late_minutes(s: dict, now: dt.datetime) -> int:
    if not s["start_time"]:
        return 0
    start = util.local_to_utc(util.local_date(now, s["tz"]), s["start_time"], s["tz"])
    late = (now - start).total_seconds() / 60 - int(s["start_grace_min"])
    return max(0, int(late))


# ------------------------------------------------------------------------------------------------ start, break, gaps
def start_day(c: sqlite3.Connection, user: Any, s: dict) -> tuple[bool, str, int | None]:
    cid, uid = user["company_id"], user["id"]
    now = util.now()
    today = util.local_date(now, s["tz"])
    sh = current_shift(c, uid)
    if sh:
        return True, "", sh["id"]
    if db.one(c, "SELECT 1 FROM shifts WHERE company_id=? AND user_id=? AND work_date=?", cid, uid, today):
        return False, "أنهيت يوم العمل اليوم. إن احتجت فتحه من جديد فاطلب ذلك من مديرك.", None
    hours = float(user["shift_hours"] or s["shift_hours"])
    planned_end = now + dt.timedelta(minutes=hours * 60 + int(s["planned_break_minutes"]))
    ts = util.iso(now)
    cur = c.execute("INSERT INTO shifts(company_id,user_id,work_date,started_at,planned_end_at,last_seen_at,last_action_at) VALUES(?,?,?,?,?,?,?)",
                    (cid, uid, today, ts, util.iso(planned_end), ts, ts))
    shift_id = int(cur.lastrowid)
    late = late_minutes(s, now)
    info = plans.build_plan(c, user, shift_id, s, today)
    db.emit(c, cid, "shift.started", actor=uid, user=uid, shift=shift_id,
            data={"planned_end": util.iso(planned_end), "late_minutes": late, "capacity": info["capacity"]})
    return True, "", shift_id


def touch_seen(c: sqlite3.Connection, shift_id: int) -> None:
    c.execute("UPDATE shifts SET last_seen_at=? WHERE id=?", (util.now_iso(), shift_id))


def touch_action(c: sqlite3.Connection, shift_id: int) -> None:
    ts = util.now_iso()
    c.execute("UPDATE shifts SET last_seen_at=?, last_action_at=? WHERE id=?", (ts, ts, shift_id))


def start_break(c: sqlite3.Connection, user: Any, shift: sqlite3.Row) -> Result:
    if open_break(c, shift["id"]):
        return True, ""
    ts = util.now_iso()
    cur = c.execute("INSERT INTO breaks(shift_id,started_at) VALUES(?,?)", (shift["id"], ts))
    touch_action(c, shift["id"])
    db.emit(c, user["company_id"], "shift.break_started", actor=user["id"], user=user["id"], shift=shift["id"], ref=cur.lastrowid)
    return True, ""


def end_break(c: sqlite3.Connection, user: Any, shift: sqlite3.Row) -> Result:
    b = open_break(c, shift["id"])
    if not b:
        return True, ""
    ts = util.now_iso()
    c.execute("UPDATE breaks SET ended_at=? WHERE id=?", (ts, b["id"]))
    touch_action(c, shift["id"])
    secs = int((util.parse_iso(ts) - util.parse_iso(b["started_at"])).total_seconds())
    db.emit(c, user["company_id"], "shift.break_ended", actor=user["id"], user=user["id"], shift=shift["id"], ref=b["id"], data={"seconds": secs})
    return True, ""


def check_gap(c: sqlite3.Connection, user: Any, shift: sqlite3.Row, s: dict) -> sqlite3.Row | None:
    """If the employee has been idle longer than the allowed minutes, records a gap and returns it so the app asks what happened."""
    pend = pending_gap(c, shift["id"])
    if pend:
        return pend
    if open_break(c, shift["id"]):
        return None
    now = util.now()
    limit = int(s["gap_minutes"]) * 60
    idle = (now - util.parse_iso(shift["last_action_at"])).total_seconds()
    if idle <= limit:
        return None
    away = (now - util.parse_iso(shift["last_seen_at"])).total_seconds() > limit
    kind = "away" if away else "inactive"
    cur = c.execute("INSERT INTO gaps(shift_id,company_id,user_id,started_at,ended_at,kind) VALUES(?,?,?,?,?,?)",
                    (shift["id"], user["company_id"], user["id"], shift["last_action_at"], util.iso(now), kind))
    db.emit(c, user["company_id"], "gap.detected", actor=None, user=user["id"], shift=shift["id"], ref=cur.lastrowid,
            data={"minutes": round(idle / 60, 1), "kind": kind})
    return db.one(c, "SELECT * FROM gaps WHERE id=?", cur.lastrowid)


def answer_gap(c: sqlite3.Connection, user: Any, shift: sqlite3.Row, gap_id: int, code: str, text: str) -> Result:
    gap = db.one(c, "SELECT * FROM gaps WHERE id=? AND shift_id=? AND status='pending'", gap_id, shift["id"])
    if not gap:
        return True, ""
    valid = {k for k, _ in consts.GAP_REASONS}
    if code not in valid:
        return False, "اختر سببًا"
    if code == "other" and len(text.strip()) < 3:
        return False, "اكتب ما حدث باختصار"
    c.execute("UPDATE gaps SET status='explained', reason_code=?, reason_text=?, answered_at=? WHERE id=?", (code, text.strip()[:200] or None, util.now_iso(), gap_id))
    touch_action(c, shift["id"])
    db.emit(c, user["company_id"], "gap.explained", actor=user["id"], user=user["id"], shift=shift["id"], ref=gap_id,
            data={"reason": code, "text": text.strip()[:200]})
    return True, ""


# ------------------------------------------------------------------------------------------------ calls and results
def _owned_lead(c: sqlite3.Connection, user: Any, lead_id: int) -> sqlite3.Row | None:
    return db.one(c, "SELECT * FROM leads WHERE id=? AND company_id=? AND owner_id=?", lead_id, user["company_id"], user["id"])


def start_call(c: sqlite3.Connection, user: Any, s: dict, lead_id: int) -> tuple[bool, str, int | None]:
    lead = _owned_lead(c, user, lead_id)
    if not lead:
        return False, "هذا العميل ليس في قائمتك", None
    if lead["do_not_call"]:
        return False, "طلب هذا العميل عدم الاتصال به", None
    shift = current_shift(c, user["id"])
    if not shift:
        return False, "ابدأ يوم العمل أولًا", None
    if open_break(c, shift["id"]):
        return False, "أنت في استراحة. أنهِها قبل الاتصال.", None
    ok, msg = in_call_hours(s)
    if not ok:
        return False, msg, None
    old = db.one(c, "SELECT * FROM call_attempts WHERE lead_id=? AND user_id=? AND status='open' ORDER BY id DESC LIMIT 1", lead_id, user["id"])
    now = util.now()
    if old:
        if (now - util.parse_iso(old["started_at"])).total_seconds() < 3 * 3600:
            return True, "", old["id"]
        c.execute("UPDATE call_attempts SET status='cancelled', cancel_reason='stale' WHERE id=?", (old["id"],))
    cur = c.execute("INSERT INTO call_attempts(company_id,lead_id,user_id,shift_id,day,started_at,phone,evidence,was_first) VALUES(?,?,?,?,?,?,?,1,?)",
                    (user["company_id"], lead_id, user["id"], shift["id"], shift["work_date"], util.iso(now), lead["phone"], int(lead["attempts"] == 0)))
    touch_action(c, shift["id"])
    db.emit(c, user["company_id"], "call.started", actor=user["id"], user=user["id"], lead=lead_id, shift=shift["id"], ref=cur.lastrowid)
    return True, "", int(cur.lastrowid)


def record_link_sent(c: sqlite3.Connection, user: Any, lead_id: int) -> Result:
    lead = _owned_lead(c, user, lead_id)
    if not lead:
        return False, "هذا العميل ليس في قائمتك"
    shift = current_shift(c, user["id"])
    c.execute("UPDATE leads SET link_sent_at=?, link_sends=link_sends+1 WHERE id=?", (util.now_iso(), lead_id))
    if shift:
        touch_action(c, shift["id"])
    db.emit(c, user["company_id"], "link.sent", actor=user["id"], user=user["id"], lead=lead_id, shift=shift["id"] if shift else None,
            data={"channel": "whatsapp", "n": lead["link_sends"] + 1})
    return True, ""


def _parse_hm(text: str) -> str | None:
    text = util.ascii_digits(text or "").strip()
    if len(text) == 5 and text[2] == ":" and text[:2].isdigit() and text[3:].isdigit() and int(text[:2]) < 24 and int(text[3:]) < 60:
        return text
    return None


def _parse_day(text: str) -> str | None:
    try:
        return dt.date.fromisoformat(util.ascii_digits(text or "").strip()).isoformat()
    except ValueError:
        return None


def record_outcome(c: sqlite3.Connection, user: Any, s: dict, lead_id: int, outcome: str, note: str, fu_date: str, fu_time: str,
                   dnc: bool) -> tuple[bool, str, dict]:
    cid, uid = user["company_id"], user["id"]
    lead = _owned_lead(c, user, lead_id)
    if not lead:
        return False, "هذا العميل ليس في قائمتك", {}
    shift = current_shift(c, uid)
    if not shift:
        return False, "ابدأ يوم العمل أولًا", {}
    if open_break(c, shift["id"]):
        return False, "أنت في استراحة. أنهِها أولًا.", {}
    otype = db.one(c, "SELECT * FROM outcome_types WHERE company_id=? AND code=? AND active=1", cid, outcome)
    if not otype:
        return False, "اختر نتيجة المكالمة", {}
    note = (note or "").strip()[:500]
    if otype["needs_note"] and len(note) < int(s["min_note_len"]):
        return False, f"اكتب ملاحظة لا تقل عن {s['min_note_len']} أحرف", {}
    now = util.now()
    today = util.local_date(now, s["tz"])
    fdate = ftime = None
    if otype["needs_datetime"]:
        fdate, ftime = _parse_day(fu_date), _parse_hm(fu_time)
        if not fdate or not ftime:
            return False, "حدّد يوم الاتصال ووقته", {}
        if fdate < today or util.days_between(today, fdate) > 60:
            return False, "يوم الاتصال يجب أن يكون من اليوم وخلال 60 يومًا", {}
        if fdate == today and ftime <= util.local_hm(now, s["tz"]):
            return False, "وقت الاتصال يجب أن يكون بعد الآن", {}
    attempt = db.one(c, "SELECT * FROM call_attempts WHERE lead_id=? AND user_id=? AND status='open' ORDER BY id DESC LIMIT 1", lead_id, uid)
    ts = util.iso(now)
    if attempt and (now - util.parse_iso(attempt["started_at"])).total_seconds() > 3 * 3600:
        c.execute("UPDATE call_attempts SET status='cancelled', cancel_reason='stale' WHERE id=?", (attempt["id"],))
        attempt = None
    if attempt:
        attempt_id, evidence = attempt["id"], attempt["evidence"]
    else:  # the result was entered without pressing "call" in the app: still recorded, but with the lowest evidence
        cur = c.execute("INSERT INTO call_attempts(company_id,lead_id,user_id,shift_id,day,started_at,phone,evidence,was_first) VALUES(?,?,?,?,?,?,?,0,?)",
                        (cid, lead_id, uid, shift["id"], shift["work_date"], ts, lead["phone"], int(lead["attempts"] == 0)))
        attempt_id, evidence = int(cur.lastrowid), 0
    nxt = leadlib.after_outcome(s, outcome, lead["status"], lead["follow_step"], today, fdate, ftime)
    status = "do_not_call" if dnc else nxt.status
    c.execute("UPDATE call_attempts SET status='recorded', outcome=?, note=?, followup_date=?, followup_time=?, recorded_at=?, dnc=? WHERE id=?",
              (outcome, note or None, fdate, ftime, ts, int(dnc), attempt_id))
    first_call = lead["first_call_at"] or db.scalar(c, "SELECT started_at FROM call_attempts WHERE id=?", attempt_id)
    c.execute("UPDATE leads SET attempts=attempts+1, first_call_at=?, last_call_at=?, status=?, status_at=?, next_follow_up=?, next_follow_time=?,"
              " follow_step=?, note_last=COALESCE(?, note_last), do_not_call=?, registered_at=CASE WHEN ?='registered' THEN ? ELSE registered_at END WHERE id=?",
              (first_call, ts, status, ts, None if dnc else nxt.date, None if dnc else nxt.time, nxt.step, note or None,
               1 if dnc else lead["do_not_call"], outcome, ts, lead_id))
    plan = plans.plan_for(c, uid, shift["work_date"])
    task = plans.open_task_for_lead(c, plan["id"], lead_id) if plan else None
    if task:
        c.execute("UPDATE tasks SET status='done', attempt_id=?, done_at=? WHERE id=?", (attempt_id, ts, task["id"]))
    if plan and nxt.status == "callback" and nxt.date == shift["work_date"] and not dnc:
        plans.add_callback_task(c, plan, user, lead_id, nxt.date)
    touch_action(c, shift["id"])
    db.emit(c, cid, "call.recorded", actor=uid, user=uid, lead=lead_id, shift=shift["id"], ref=attempt_id,
            data={"outcome": outcome, "evidence": evidence, "note": note, "followup_date": fdate, "followup_time": ftime,
                  "status": status, "next": None if dnc else nxt.date, "dnc": bool(dnc), "task": task["id"] if task else None})
    if dnc:
        db.emit(c, cid, "lead.dnc", actor=uid, user=uid, lead=lead_id, shift=shift["id"], ref=attempt_id)
    if status == "exhausted":
        db.emit(c, cid, "lead.exhausted", actor=None, user=uid, lead=lead_id, ref=attempt_id, data={"tries": nxt.step})
    return True, "", {"attempt_id": attempt_id, "status": status, "next": nxt.date, "evidence": evidence, "task_id": task["id"] if task else None}


def skip_task(c: sqlite3.Connection, user: Any, task_id: int) -> Result:
    t = db.one(c, "SELECT * FROM tasks WHERE id=? AND user_id=? AND status='open'", task_id, user["id"])
    if not t:
        return False, "المهمة غير موجودة"
    pos = db.scalar(c, "SELECT MAX(position) FROM tasks WHERE plan_id=?", t["plan_id"], default=0) + 1
    c.execute("UPDATE tasks SET position=? WHERE id=?", (pos, task_id))
    db.emit(c, user["company_id"], "task.skipped", actor=user["id"], user=user["id"], lead=t["lead_id"], ref=task_id)
    return True, ""


# ------------------------------------------------------------------------------------------------ closing the day
def close_day(c: sqlite3.Connection, user: Any, shift: sqlite3.Row, s: dict, reasons: dict[int, tuple[str, str]], note: str = "",
              auto: bool = False) -> Result:
    cid, uid = user["company_id"], user["id"]
    plan = plans.plan_for(c, uid, shift["work_date"])
    open_tasks = c.execute("SELECT * FROM tasks WHERE plan_id=? AND status='open'", (plan["id"],)).fetchall() if plan else []
    valid = {r["code"]: r for r in c.execute("SELECT * FROM reasons WHERE company_id=? AND active=1", (cid,))}
    if not auto:
        if pending_gap(c, shift["id"]):
            return False, "أجب عن سؤال الفترة الصامتة أولًا"
        for t in open_tasks:
            code, text = reasons.get(t["id"], ("", ""))
            r = valid.get(code)
            if not r:
                return False, "حدّد سببًا لكل مهمة لم تُنجز"
            if r["needs_text"] and len(text.strip()) < 3:
                return False, "اكتب توضيحًا للسبب «أخرى»"
    ts = util.now_iso()
    if not auto:
        for t in open_tasks:
            code, text = reasons[t["id"]]
            c.execute("UPDATE tasks SET status='reason', reason_code=?, reason_text=?, done_at=? WHERE id=?", (code, text.strip()[:200] or None, ts, t["id"]))
    cancelled = [r["id"] for r in c.execute("SELECT id FROM call_attempts WHERE shift_id=? AND status='open'", (shift["id"],))]
    c.execute("UPDATE call_attempts SET status='cancelled', cancel_reason='day_closed' WHERE shift_id=? AND status='open'", (shift["id"],))
    if open_break(c, shift["id"]):
        c.execute("UPDATE breaks SET ended_at=? WHERE shift_id=? AND ended_at IS NULL", (ts, shift["id"]))
    status = "auto_closed" if auto else "closed"
    c.execute("UPDATE shifts SET status=?, ended_at=?, close_note=? WHERE id=?", (status, ts, note.strip()[:300] or None, shift["id"]))
    db.emit(c, cid, "shift.closed", actor=None if auto else uid, user=uid, shift=shift["id"],
            data={"auto": auto, "open_tasks": len(open_tasks), "cancelled_calls": cancelled[:50], "note": note.strip()[:300],
                  "reasons": {str(t["id"]): reasons[t["id"]][0] for t in open_tasks} if not auto else {}})
    if auto:
        db.notice(c, cid, "auto_closed", f"أُغلق يوم {user['name']} تلقائيًا بعد انتهاء موعده، وبقيت {len(open_tasks)} مهمة بلا نتيجة", uid, shift["work_date"])
    reports.seal_day(c, cid, uid, shift["work_date"], s, reason="close")
    return True, ""


def auto_close_due(c: sqlite3.Connection) -> int:
    """Called by the scheduler: closes shifts whose planned end passed long ago (the employee forgot)."""
    n = 0
    now = util.now()
    for sh in c.execute("SELECT * FROM shifts WHERE status='open'").fetchall():
        from . import settings as st

        s = st.load(c, sh["company_id"])
        limit = util.parse_iso(sh["planned_end_at"]) + dt.timedelta(hours=float(s["auto_close_hours"]))
        if now >= limit:
            user = db.one(c, "SELECT * FROM users WHERE id=?", sh["user_id"])
            close_day(c, user, sh, s, {}, auto=True)
            n += 1
    return n


def reopen_day(c: sqlite3.Connection, company_id: int, shift_id: int, actor: int, why: str) -> Result:
    sh = db.one(c, "SELECT * FROM shifts WHERE id=? AND company_id=?", shift_id, company_id)
    if not sh or sh["status"] == "open":
        return False, "اليوم غير موجود أو مفتوح"
    if db.one(c, "SELECT 1 FROM shifts WHERE user_id=? AND status='open'", sh["user_id"]):
        return False, "لدى الموظف يوم مفتوح آخر"
    if len(why.strip()) < 3:
        return False, "اكتب سبب إعادة الفتح"
    now = util.now()
    from . import settings as st

    s = st.load(c, company_id)
    hours = float(db.scalar(c, "SELECT COALESCE(shift_hours, ?) FROM users WHERE id=?", s["shift_hours"], sh["user_id"]))
    c.execute("UPDATE shifts SET status='open', ended_at=NULL, planned_end_at=?, last_seen_at=?, last_action_at=? WHERE id=?",
              (util.iso(now + dt.timedelta(minutes=hours * 30)), util.iso(now), util.iso(now), shift_id))
    db.emit(c, company_id, "shift.reopened", actor=actor, user=sh["user_id"], shift=shift_id, data={"why": why.strip()[:200]})
    return True, ""


# ------------------------------------------------------------------------------------------------ corrections by a manager
def correct_outcome(c: sqlite3.Connection, company_id: int, attempt_id: int, new_outcome: str, reason: str, actor: int, s: dict) -> tuple[bool, str, str]:
    """A manager fixes a wrong result. The original stays in the log; reports use the corrected one.

    If it was the client's latest call, the client is put back on the follow-up path the new result implies, starting today.
    Returns (ok, message, effect) where effect is 'rescheduled' or 'report_only'."""
    a = db.one(c, "SELECT * FROM call_attempts WHERE id=? AND company_id=? AND status='recorded'", attempt_id, company_id)
    if not a:
        return False, "المكالمة غير موجودة", ""
    reason = (reason or "").strip()[:300]
    if len(reason) < 5:
        return False, "اكتب سبب التصحيح (5 أحرف على الأقل)", ""
    if new_outcome == "call_later":
        return False, "لا يُصحَّح إلى «اتصل لاحقًا» لأنه يحتاج موعدًا. اطلب من الموظف تسجيل مكالمة جديدة.", ""
    if not db.one(c, "SELECT 1 FROM outcome_types WHERE company_id=? AND code=?", company_id, new_outcome):
        return False, "نتيجة غير معروفة", ""
    old = db.scalar(c, f"SELECT {reports.EFFECTIVE} FROM call_attempts a WHERE a.id=?", attempt_id)
    if old == new_outcome:
        return False, "هذه هي النتيجة الحالية أصلًا", ""
    ts = util.now_iso()
    c.execute("INSERT INTO corrections(company_id,attempt_id,old_outcome,new_outcome,reason,by_user_id,at) VALUES(?,?,?,?,?,?,?)",
              (company_id, attempt_id, old, new_outcome, reason, actor, ts))
    lead = leadlib.get(c, company_id, a["lead_id"])
    latest = db.scalar(c, "SELECT id FROM call_attempts WHERE lead_id=? AND status='recorded' ORDER BY recorded_at DESC, id DESC LIMIT 1", a["lead_id"])
    effect, nxt_date = "report_only", None
    if lead and latest == attempt_id and not lead["do_not_call"] and not lead["confirmed_at"]:
        today = util.local_date(util.now(), s["tz"])
        nxt = leadlib.after_outcome(s, new_outcome, "new", 0, today)
        c.execute("UPDATE leads SET status=?, status_at=?, next_follow_up=?, next_follow_time=NULL, follow_step=?,"
                  " registered_at=CASE WHEN ?='registered' THEN COALESCE(registered_at, ?) WHEN ?='registered' THEN NULL ELSE registered_at END WHERE id=?",
                  (nxt.status, ts, nxt.date, nxt.step, new_outcome, ts, old, a["lead_id"]))
        effect, nxt_date = "rescheduled", nxt.date
    db.emit(c, company_id, "call.corrected", actor=actor, user=a["user_id"], lead=a["lead_id"], shift=a["shift_id"], ref=attempt_id,
            data={"old": old, "new": new_outcome, "reason": reason, "effect": effect, "next": nxt_date})
    if a["shift_id"]:
        sh = db.one(c, "SELECT * FROM shifts WHERE id=?", a["shift_id"])
        if sh and sh["status"] != "open":
            reports.seal_day(c, company_id, a["user_id"], sh["work_date"], s, reason="correction")
    return True, "", effect
