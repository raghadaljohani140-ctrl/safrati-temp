"""Platform administration: the person who runs the installation (not a customer's manager)."""
from __future__ import annotations

import asyncio
import shutil

from . import config, db, security, ui, util
from .routes import route
from .ui import button, card, e, field, form, notice_box, page, table
from .web import HttpError, redirect


def _admin_only(req) -> None:
    if not req.ctx.user.get("is_platform_admin"):
        raise HttpError(403, "هذه الصفحة لمدير المنصة فقط")


def _overview(c):
    rows = db.all_(c, """SELECT co.*, (SELECT COUNT(*) FROM users u WHERE u.company_id=co.id AND u.active=1) AS users,
        (SELECT COUNT(*) FROM leads l WHERE l.company_id=co.id) AS leads,
        (SELECT COUNT(*) FROM events ev WHERE ev.company_id=co.id) AS events,
        (SELECT MAX(ts) FROM events ev WHERE ev.company_id=co.id) AS last_event,
        (SELECT name FROM users u WHERE u.company_id=co.id AND u.role='owner' ORDER BY id LIMIT 1) AS owner_name
        FROM companies co ORDER BY co.id""")
    return rows, db.platform_get(c, "registration_open") == "1"


@route("GET", "/p", auth="user")
async def overview(req):
    _admin_only(req)
    rows, opened = await db.read(_overview)
    tz = req.ctx.tz
    body_rows = []
    for r in rows:
        toggle = form(req, f"/p/company/{r['id']}/active", button("إيقاف" if r["active"] else "تفعيل", kind="ghost", small=True,
                                                                  confirm="تأكيد؟ إيقاف الشركة يمنع دخول موظفيها."), cls="inline")
        body_rows.append([e(r["name"]), e(r["owner_name"] or ""), str(r["users"]), str(r["leads"]), str(r["events"]),
                          ui.fmt_dt(r["last_event"], tz) or "—", ui.badge("نشطة", "ok") if r["active"] else ui.badge("موقوفة", "bad"), toggle])
    disk = shutil.disk_usage(config.DATA_DIR)
    db_size = config.db_path().stat().st_size if config.db_path().exists() else 0
    info = (f'<dl class="kv"><dt>حجم قاعدة البيانات</dt><dd>{db_size / 1048576:.1f} ميغابايت</dd>'
            f'<dt>المساحة الفارغة</dt><dd>{disk.free / 1073741824:.1f} غيغابايت</dd><dt>الإصدار</dt><dd class="ltr">{e(ui.VER)}</dd></dl>')
    reg = form(req, "/p/registration", button("إغلاق تسجيل الشركات" if opened else "فتح تسجيل الشركات",
                                              kind="ghost" if opened else "soft", small=True), cls="inline")
    new = form(req, "/p/company", (field("اسم الشركة", "company", required=True, maxlength=80) + field("اسم المالك", "name", required=True, maxlength=80)
                                   + field("اسم المستخدم", "username", ltr=True, required=True, hint="إنجليزي بلا مسافات")
                                   + button("إنشاء الشركة وكلمة مرور مؤقتة")))
    verify = form(req, "/p/verify", button("فحص سلامة السجلات", kind="ghost", small=True), cls="inline")
    body = (card(table(["الشركة", "المالك", "المستخدمون", "العملاء", "الأحداث", "آخر نشاط", "الحالة", ""], body_rows), title="الشركات",
                 actions=reg + verify) + card(info, title="الخادم") + card(new, title="شركة جديدة", sub="يُنشأ حساب المالك بكلمة مرور مؤقتة تظهر مرة واحدة."))
    return page(req, "إدارة المنصة", body, active="platform", wide=True)


@route("POST", "/p/registration", auth="user")
async def toggle_registration(req):
    _admin_only(req)

    def go(c):
        new = "0" if db.platform_get(c, "registration_open") == "1" else "1"
        db.platform_set(c, "registration_open", new)
        db.emit(c, req.ctx.cid, "admin.registration_toggled", actor=req.ctx.uid, data={"open": new})
        return new

    new = await db.write(go)
    return ui.flash_redirect("/p", "ok", "فُتح التسجيل" if new == "1" else "أُغلق التسجيل")


@route("POST", "/p/company/<int:cid>/active", auth="user")
async def toggle_company(req, cid: int):
    _admin_only(req)
    if cid == req.ctx.cid:
        return ui.flash_redirect("/p", "err", "لا يمكن إيقاف شركتك الحالية")

    def go(c):
        row = db.one(c, "SELECT active FROM companies WHERE id=?", cid)
        if not row:
            return None
        new = 0 if row["active"] else 1
        c.execute("UPDATE companies SET active=? WHERE id=?", (new, cid))
        if not new:
            c.execute("DELETE FROM sessions WHERE company_id=?", (cid,))
        db.emit(c, cid, "admin.company_active", actor=req.ctx.uid, data={"active": new})
        return new

    r = await db.write(go)
    return ui.flash_redirect("/p", "ok" if r is not None else "err", "تم" if r is not None else "الشركة غير موجودة")


@route("POST", "/p/company", auth="user")
async def create_company(req):
    _admin_only(req)
    company, name, username = req.f("company"), req.f("name"), req.f("username")
    problem = (security.username_problem(username) if username else "اكتب اسم المستخدم") or (
        "اكتب اسم الشركة واسم المالك" if len(company) < 2 or len(name) < 2 else "")
    if problem:
        return ui.flash_redirect("/p", "err", problem)
    temp = security.generate_password()
    hashed = await asyncio.to_thread(security.hash_password, temp)

    def go(c):
        if db.one(c, "SELECT 1 FROM users WHERE username=?", username):
            return False
        cid = db.create_company(c, company, username)
        cur = c.execute("INSERT INTO users(company_id,username,name,role,password_hash,must_change_password,created_at,created_by) VALUES(?,?,?,?,?,1,?,?)",
                        (cid, username, name, "owner", hashed, util.now_iso(), req.ctx.uid))
        db.emit(c, cid, "admin.company_created", actor=req.ctx.uid, user=cur.lastrowid, data={"company": company})
        return True

    if not await db.write(go):
        return ui.flash_redirect("/p", "err", "اسم المستخدم محجوز")
    body = card(notice_box("احفظ كلمة المرور الآن؛ لن تظهر مرة أخرى. سيُطلب من المالك تغييرها عند أول دخول.", "warn") +
                f'<dl class="kv"><dt>الشركة</dt><dd>{e(company)}</dd><dt>اسم المستخدم</dt><dd class="ltr">{e(username)}</dd>'
                f'<dt>كلمة المرور المؤقتة</dt><dd><span class="code">{e(temp)}</span> '
                f'<button class="btn ghost sm" type="button" data-copy="{e(temp)}" data-keep>نسخ</button></dd></dl>'
                + button("العودة", href="/p", kind="ghost"), title="تم إنشاء الشركة")
    resp = page(req, "تم إنشاء الشركة", body, active="platform")
    resp.header("Cache-Control", "no-store")
    return resp


@route("POST", "/p/verify", auth="user")
async def verify_all(req):
    _admin_only(req)

    def go(c):
        out = []
        for co in db.all_(c, "SELECT id, name FROM companies ORDER BY id"):
            out.append((co["name"], db.verify_chain(c, co["id"])))
        return out

    results = await db.read(go)
    rows = [[e(n), ui.badge("سليم", "ok") if r["ok"] else ui.badge(f"خلل عند الحدث {r['bad_seq']}", "bad"), str(r["checked"])] for n, r in results]
    body = card(table(["الشركة", "النتيجة", "الأحداث المفحوصة"], rows) + '<p class="sub mt">يُعاد حساب بصمة كل حدث من أول السجل ويُقارن بالمخزّن.</p>'
                + button("رجوع", href="/p", kind="ghost"), title="نتيجة الفحص")
    return page(req, "فحص السجلات", body, active="platform")
