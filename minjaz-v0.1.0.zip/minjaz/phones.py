"""Phone numbers: one international form before any comparison.

Saudi mobile numbers are written many ways (0555123456, 555123456, +966555123456, 00966555123456, Arabic digits, spaces, dashes,
or with the leading zero eaten by Excel). All of them become +966555123456, so a number can never be stored twice.
"""
from __future__ import annotations

import re
from decimal import Decimal, InvalidOperation
from typing import NamedTuple

from .util import ascii_digits

_SCI = re.compile(r"^\d+(\.\d+)?[eE]\+?\d+$")
_LETTERS = re.compile(r"[A-Za-z؀-ۿ]")
_SPLIT = re.compile(r"[,،;؛/\\|\n\r]+")


class Phone(NamedTuple):
    phone: str | None  # +966555123456, or None when invalid
    kind: str  # mobile | landline | unified | foreign | invalid
    reason: str  # Arabic reason when invalid, else ""


def _invalid(reason: str) -> Phone:
    return Phone(None, "invalid", reason)


def normalize_phone(raw: object) -> Phone:
    if raw is None:
        return _invalid("الخانة فارغة")
    if isinstance(raw, float):
        raw = str(int(raw)) if raw == int(raw) else str(raw)
    s = ascii_digits(str(raw)).strip()
    if not s:
        return _invalid("الخانة فارغة")
    compact = s.replace(",", "").replace(" ", "")
    if _SCI.match(compact):  # Excel turned the number into 5.55123456E+8
        try:
            s = str(int(Decimal(compact)))
        except (InvalidOperation, ValueError):
            return _invalid("صيغة الرقم غير مفهومة")
    elif re.fullmatch(r"\d+\.0+", compact):
        s = compact.split(".")[0]
    if _LETTERS.search(s):
        return _invalid("الرقم فيه حروف")
    plus = s.lstrip().startswith("+")
    digits = re.sub(r"\D", "", s)
    if not digits:
        return _invalid("لا يوجد فيه أرقام")
    if digits.startswith("00"):
        digits, plus = digits[2:], True
    if digits.startswith("966") and (plus or len(digits) >= 11):
        national = digits[3:]
        if national.startswith("0"):
            national = national[1:]
    elif plus:
        if 8 <= len(digits) <= 15:
            return Phone("+" + digits, "foreign", "")
        return _invalid("الرقم الدولي طوله غير صحيح")
    elif digits.startswith("0"):
        national = digits[1:]
    else:
        national = digits
    if len(national) < 9:
        return _invalid(f"الرقم ناقص ({len(national)} أرقام بعد الصفر)")
    if len(national) > 9:
        return _invalid(f"الرقم زائد ({len(national)} أرقام)")
    first = national[0]
    if first == "5":
        return Phone("+966" + national, "mobile", "")
    if first == "1":
        return Phone("+966" + national, "landline", "")
    if first == "9":
        return Phone("+966" + national, "unified", "")
    return _invalid("لا يبدأ برقم جوال أو هاتف سعودي")


def split_numbers(raw: object) -> list[str]:
    """A cell can hold several numbers ("055..., 050..."). Returns the pieces that look like numbers."""
    if raw is None:
        return []
    if isinstance(raw, (int, float)):
        return [str(raw)]
    parts = [p.strip() for p in _SPLIT.split(str(raw)) if p.strip()]
    return parts or [str(raw)]


def wa_digits(phone: str) -> str:
    """wa.me wants digits only, with the country code."""
    return re.sub(r"\D", "", phone)


def display(phone: str | None) -> str:
    """+966555123456 -> 0555123456 (how Saudis write it)."""
    if not phone:
        return ""
    if phone.startswith("+966"):
        return "0" + phone[4:]
    return phone


PHONE_IN_TEXT = re.compile(r"(?:\+|00)?[\d٠-٩]{1,3}[\s\-]?[\d٠-٩][\d٠-٩\s\-]{7,14}[\d٠-٩]")
