"""Daily numbers, the rating, review signals, sealed daily reports, and the manager's live picture."""
from __future__ import annotations

import datetime as dt
import sqlite3
from typing import Any

from . import consts, db, plans, util

EFFECTIVE = "COALESCE((SELECT k.new_outcome FROM corrections k WHERE k.attempt_id=a.id ORDER BY k.id DESC LIMIT 1), a.outcome)"
FAST_SECONDS = 8
BUNCH_WINDOW = 60
BUNCH_COUNT = 10
SAME_RUN = 15


def _clamp(x: float) -> float:
    return max(0.0, min(1.0, x))


def day_metrics(c: sqlite3.Connection, company_id: int, user_id: int, day: str, s: dict, with_tasks: bool = False) -> dict[str, Any]:
    now = util.now()
    shift = db.one(c, "SELECT * FROM shifts WHERE company_id=? AND user_id=? AND work_date=?", company_id, user_id, day)
    m: dict[str, Any] = {"day": day, "user_id": user_id, "shift": None}
    brk = 0
    if shift:
        from . import work

        brk = work.break_seconds(c, shift["id"], now)
        end = util.parse_iso(shift["ended_at"]) if shift["ended_at"] else now
        total = max(0, int((end - util.parse_iso(shift["started_at"])).total_seconds()))
        m["shift"] = {"id": shift["id"], "status": shift["status"], "started_at": shift["started_at"], "ended_at": shift["ended_at"],
                      "planned_end_at": shift["planned_end_at"], "work_seconds": max(0, total - brk), "break_seconds": brk,
                      "late_minutes": _late(c, shift, s)}
    plan = plans.plan_for(c, user_id, day)
    m["tasks"] = plans.progress(c, plan["id"]) if plan else {"total": 0, "done": 0, "reason": 0, "open": 0, "by_kind": {}}
    m["plan"] = {"capacity": plan["capacity"], "new_target": plan["new_target"], "new_given": plan["new_given"], "followups": plan["followups"],
                 "trimmed": bool(plan["trimmed"]), "pool_short": plan["pool_short"]} if plan else None
    rows = c.execute(f"SELECT a.id, a.lead_id, a.outcome AS orig, {EFFECTIVE} AS eff, a.evidence, a.was_first, a.started_at, a.recorded_at, a.dnc,"
                     f" (SELECT COUNT(*) FROM corrections k WHERE k.attempt_id=a.id) AS corr FROM call_attempts a"
                     f" WHERE a.company_id=? AND a.user_id=? AND a.day=? AND a.status='recorded' ORDER BY a.recorded_at", (company_id, user_id, day)).fetchall()
    outcomes: dict[str, int] = {}
    evidence = {0: 0, 1: 0, 2: 0, 3: 0}
    fast = corrected = dnc = first = 0
    stamps: list[float] = []
    longest = run = 0
    prev = None
    for r in rows:
        outcomes[r["eff"]] = outcomes.get(r["eff"], 0) + 1
        evidence[r["evidence"]] = evidence.get(r["evidence"], 0) + 1
        first += r["was_first"]
        dnc += r["dnc"]
        corrected += 1 if r["corr"] else 0
        if r["evidence"] >= 1 and (util.parse_iso(r["recorded_at"]) - util.parse_iso(r["started_at"])).total_seconds() < FAST_SECONDS:
            fast += 1
        stamps.append(util.parse_iso(r["recorded_at"]).timestamp())
        run = run + 1 if r["orig"] == prev else 1
        prev = r["orig"]
        longest = max(longest, run)
    bunched = 0
    j = 0
    for i in range(len(stamps)):
        while stamps[i] - stamps[j] > BUNCH_WINDOW:
            j += 1
        bunched = max(bunched, i - j + 1)
    n = len(rows)
    answered = sum(v for k, v in outcomes.items() if k in consts.ANSWERED)
    m["calls"] = {"total": n, "answered": answered, "unreached": sum(v for k, v in outcomes.items() if k in consts.UNREACHED),
                  "outcomes": outcomes, "first": first, "followup": n - first, "evidence": evidence, "fast": fast, "corrected": corrected,
                  "longest_run": longest, "bunched": bunched, "dnc": dnc}
    ev = dict(c.execute("SELECT type, COUNT(*) FROM events WHERE company_id=? AND user_id=? AND day=? AND type IN ('link.sent','link.opened','lead.confirmed','task.skipped') GROUP BY type",
                        (company_id, user_id, day)).fetchall())
    m["links"] = {"sent": ev.get("link.sent", 0), "opened": ev.get("link.opened", 0)}
    m["registered"] = {"reported": outcomes.get("registered", 0), "confirmed": ev.get("lead.confirmed", 0)}
    m["interested"] = outcomes.get("interested", 0)
    m["skips"] = ev.get("task.skipped", 0)
    gaps = c.execute("SELECT g.status, g.started_at, g.ended_at FROM gaps g JOIN shifts sh ON sh.id=g.shift_id WHERE g.company_id=? AND g.user_id=? AND sh.work_date=?",
                     (company_id, user_id, day)).fetchall()
    m["gaps"] = {"count": len(gaps), "explained": sum(1 for g in gaps if g["status"] == "explained"),
                 "pending": sum(1 for g in gaps if g["status"] == "pending"),
                 "seconds": int(sum((util.parse_iso(g["ended_at"]) - util.parse_iso(g["started_at"])).total_seconds() for g in gaps))}
    m["rating"] = rating(m, s)
    m["flags"] = flags(m, s)
    if with_tasks and plan:
        m["task_list"] = [{"lead": t["lead_id"], "kind": t["kind"], "status": t["status"], "reason": t["reason_code"],
                           "outcome": db.scalar(c, f"SELECT {EFFECTIVE} FROM call_attempts a WHERE a.id=?", t["attempt_id"]) if t["attempt_id"] else None}
                          for t in c.execute("SELECT * FROM tasks WHERE plan_id=? ORDER BY position", (plan["id"],))]
    return m


def _late(c: sqlite3.Connection, shift: sqlite3.Row, s: dict) -> int:
    ev = db.one(c, "SELECT data FROM events WHERE shift_id=? AND type='shift.started' ORDER BY seq LIMIT 1", shift["id"])
    if not ev:
        return 0
    return int(db.jload(ev["data"], {}).get("late_minutes", 0))


def points(m: dict, s: dict) -> float:
    return (m["registered"]["confirmed"] * float(s["pts_registered_confirmed"]) + m["registered"]["reported"] * float(s["pts_registered_reported"])
            + m["links"]["opened"] * float(s["pts_link_opened"]) + m["links"]["sent"] * float(s["pts_link_sent"])
            + m["interested"] * float(s["pts_interested"]))


def rating(m: dict, s: dict) -> dict[str, Any] | None:
    sh = m["shift"]
    if not sh:
        return None
    t = m["tasks"]
    calls = m["calls"]
    ex = (t["done"] / t["total"]) if t["total"] else 0.0
    res = _clamp(points(m, s) / max(0.1, float(s["target_points"])))
    n = calls["total"]
    if n:
        quality = _clamp(1.0 - 0.4 * (calls["evidence"].get(0, 0) / n) - 0.4 * (calls["fast"] / n) - 0.2 * min(1.0, calls["corrected"] / n * 3))
    else:
        quality = 0.0
    parts = []
    late = sh["late_minutes"]
    parts.append(1.0 if late == 0 else _clamp(1 - late / 60))
    g = m["gaps"]
    parts.append(1.0 if g["count"] == 0 else g["explained"] / g["count"])
    allowance = int(s["planned_break_minutes"]) * 60 * 1.25
    parts.append(1.0 if sh["break_seconds"] <= allowance else _clamp(1 - (sh["break_seconds"] - allowance) / 1800))
    parts.append(0.0 if sh["status"] == "auto_closed" else 1.0)
    disc = sum(parts) / len(parts)
    w = {"exec": float(s["w_exec"]), "results": float(s["w_results"]), "quality": float(s["w_quality"]), "discipline": float(s["w_discipline"])}
    total_w = sum(w.values()) or 1.0
    vals = {"exec": ex, "results": res, "quality": quality, "discipline": disc}
    score = round(100 * sum(w[k] * vals[k] for k in w) / total_w)
    return {"score": score, "parts": {k: round(v * 100) for k, v in vals.items()}, "weights": {k: int(v) for k, v in w.items()}}


def flags(m: dict, s: dict) -> list[dict[str, str]]:
    """Signals worth a conversation. They describe what the log shows; they do not say why."""
    out: list[dict[str, str]] = []
    calls, sh, g = m["calls"], m["shift"], m["gaps"]
    n = calls["total"]

    def add(code: str, label: str, detail: str, tone: str = "warn") -> None:
        out.append({"code": code, "label": label, "detail": detail, "tone": tone})

    if sh and sh["late_minutes"] > 0:
        add("late", "بدأ متأخرًا", f"{sh['late_minutes']} دقيقة بعد موعد الدوام والسماح", "info")
    if sh and sh["status"] == "auto_closed":
        add("auto_closed", "أُغلق اليوم تلقائيًا", f"بقيت {m['tasks']['open']} مهمة بلا نتيجة ولا سبب")
    if g["pending"]:
        add("gap_pending", "فترات صامتة بلا توضيح", f"{g['pending']} فترة لم يُجب عنها")
    if g["count"] and g["seconds"] >= 3600:
        add("gap_long", "فترات صامتة طويلة", f"المجموع {util.fmt_duration(g['seconds'])}", "info")
    if n >= 8 and calls["fast"] / n >= 0.3:
        add("fast", "نتائج سُجّلت بعد ثوانٍ من بدء الاتصال", f"{calls['fast']} من {n} أقل من {FAST_SECONDS} ثوانٍ")
    if n >= 10 and calls["evidence"].get(0, 0) / n >= 0.4:
        add("no_start", "نتائج بلا ضغط على «اتصال»", f"{calls['evidence'].get(0, 0)} من {n} سُجّلت دون بدء من التطبيق")
    if calls["longest_run"] >= SAME_RUN:
        add("same_run", "نتيجة واحدة متكررة", f"{calls['longest_run']} نتائج متتالية متطابقة")
    if calls["bunched"] >= BUNCH_COUNT:
        add("bunched", "تسجيلات متراكمة في دقيقة", f"{calls['bunched']} نتيجة خلال دقيقة واحدة")
    if n >= 20 and calls["unreached"] / n >= 0.75:
        add("unreached", "نسبة «لم يرد/مغلق» مرتفعة", f"{round(100 * calls['unreached'] / n)}% من المكالمات", "info")
    if m["skips"] >= 8:
        add("skips", "تأجيل مهام كثير", f"{m['skips']} مرة", "info")
    if m["tasks"]["total"] and sh and sh["status"] != "open" and m["tasks"]["reason"] >= max(5, m["tasks"]["total"] // 3):
        add("many_reasons", "مهام كثيرة بلا نتيجة", f"{m['tasks']['reason']} من {m['tasks']['total']} بأسباب معلنة", "info")
    return out


# ------------------------------------------------------------------------------------------------ sealed daily reports
def _canon_data(m: dict) -> dict:
    return {k: v for k, v in m.items()}


def seal_day(c: sqlite3.Connection, company_id: int, user_id: int, day: str, s: dict, reason: str = "close") -> int:
    m = day_metrics(c, company_id, user_id, day, s, with_tasks=True)
    seq, last_hash = db.last_event(c, company_id)
    prev = db.one(c, "SELECT id, version FROM daily_reports WHERE company_id=? AND user_id=? AND work_date=? ORDER BY version DESC LIMIT 1",
                  company_id, user_id, day)
    version = (prev["version"] + 1) if prev else 1
    data = util.canon(_canon_data(m))
    seal = util.sha256(f"{data}|{last_hash}|{version}")
    cur = c.execute("INSERT INTO daily_reports(company_id,user_id,work_date,version,created_at,data,last_event_seq,last_event_hash,seal,supersedes,reason)"
                    " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                    (company_id, user_id, day, version, util.now_iso(), data, seq, last_hash, seal, prev["id"] if prev else None, reason))
    db.emit(c, company_id, "report.sealed", actor=None, user=user_id, ref=cur.lastrowid, data={"day": day, "version": version, "seal": seal, "why": reason})
    return int(cur.lastrowid)


def verify_report(c: sqlite3.Connection, row: sqlite3.Row) -> dict[str, Any]:
    again = util.sha256(f"{row['data']}|{row['last_event_hash']}|{row['version']}")
    ev = db.one(c, "SELECT hash FROM events WHERE company_id=? AND seq=?", row["company_id"], row["last_event_seq"]) if row["last_event_seq"] else None
    anchored = (row["last_event_seq"] == 0) or (ev is not None and ev["hash"] == row["last_event_hash"])
    return {"seal_ok": again == row["seal"], "anchored": anchored, "ok": again == row["seal"] and anchored}


def latest_sealed(c: sqlite3.Connection, company_id: int, user_id: int, day: str) -> sqlite3.Row | None:
    return db.one(c, "SELECT * FROM daily_reports WHERE company_id=? AND user_id=? AND work_date=? ORDER BY version DESC LIMIT 1", company_id, user_id, day)


def unseal(row: sqlite3.Row) -> dict | None:
    """A sealed report is JSON, so its numeric dictionary keys come back as text; put them back."""
    m = db.jload(row["data"], None)
    if m and m.get("calls"):
        m["calls"]["evidence"] = {int(k): v for k, v in m["calls"]["evidence"].items()}
    return m


def metrics_for(c: sqlite3.Connection, company_id: int, user_id: int, day: str, s: dict) -> dict | None:
    """Closed days come from the sealed report (what the manager was shown); an open day is computed live."""
    shift = db.one(c, "SELECT status FROM shifts WHERE company_id=? AND user_id=? AND work_date=?", company_id, user_id, day)
    if not shift:
        return None
    if shift["status"] != "open":
        row = latest_sealed(c, company_id, user_id, day)
        if row:
            return unseal(row)
    return day_metrics(c, company_id, user_id, day, s)


# ------------------------------------------------------------------------------------------------ ranges (week, month, compare)
def days_in(start: str, end: str) -> list[str]:
    n = util.days_between(start, end)
    return [util.add_days(start, i) for i in range(max(0, n) + 1)]


def range_rows(c: sqlite3.Connection, company_id: int, start: str, end: str, s: dict, only_user: int | None = None) -> list[dict]:
    """One row per employee with totals over the days in [start, end]."""
    users = c.execute("SELECT id, name, active FROM users WHERE company_id=? AND role='employee' ORDER BY name", (company_id,)).fetchall()
    shifts = c.execute("SELECT user_id, work_date FROM shifts WHERE company_id=? AND work_date BETWEEN ? AND ?", (company_id, start, end)).fetchall()
    by_user: dict[int, list[str]] = {}
    for r in shifts:
        by_user.setdefault(r["user_id"], []).append(r["work_date"])
    # a registration is confirmed after the day it happened, so a sealed day never has it: count them from the log by their own date
    confirmed = dict(c.execute("SELECT user_id, COUNT(*) FROM events WHERE company_id=? AND type='lead.confirmed' AND day BETWEEN ? AND ? GROUP BY user_id",
                               (company_id, start, end)).fetchall())
    rows = []
    for u in users:
        if only_user and u["id"] != only_user:
            continue
        days = sorted(by_user.get(u["id"], []))
        if not days and not u["active"] and not confirmed.get(u["id"]):
            continue
        agg = {"user_id": u["id"], "name": u["name"], "active": u["active"], "days": len(days), "calls": 0, "answered": 0, "interested": 0,
               "links_sent": 0, "links_opened": 0, "reg_reported": 0, "reg_confirmed": 0, "tasks": 0, "done": 0, "work_seconds": 0,
               "scores": [], "flags": 0, "outcomes": {}}
        for d in days:
            m = metrics_for(c, company_id, u["id"], d, s)
            if not m:
                continue
            agg["calls"] += m["calls"]["total"]
            agg["answered"] += m["calls"]["answered"]
            agg["interested"] += m["interested"]
            agg["links_sent"] += m["links"]["sent"]
            agg["links_opened"] += m["links"]["opened"]
            agg["reg_reported"] += m["registered"]["reported"]
            agg["reg_confirmed"] += m["registered"]["confirmed"]
            agg["tasks"] += m["tasks"]["total"]
            agg["done"] += m["tasks"]["done"]
            agg["work_seconds"] += (m["shift"] or {}).get("work_seconds", 0)
            if m.get("rating"):
                agg["scores"].append(m["rating"]["score"])
            agg["flags"] += len(m.get("flags", []))
            for k, v in m["calls"]["outcomes"].items():
                agg["outcomes"][k] = agg["outcomes"].get(k, 0) + v
        agg["score"] = round(sum(agg["scores"]) / len(agg["scores"])) if agg["scores"] else None
        agg["reg_confirmed"] = confirmed.get(u["id"], 0)
        rows.append(agg)
    return rows


def totals(rows: list[dict]) -> dict[str, Any]:
    keys = ["days", "calls", "answered", "interested", "links_sent", "links_opened", "reg_reported", "reg_confirmed", "tasks", "done", "work_seconds"]
    out = {k: sum(r[k] for r in rows) for k in keys}
    scores = [r["score"] for r in rows if r["score"] is not None]
    out["score"] = round(sum(scores) / len(scores)) if scores else None
    return out


def period(kind: str, ref: str) -> tuple[str, str]:
    """('week'|'month'|'day', any date in it) -> first and last day. Weeks run Sunday to Saturday, as in Saudi Arabia."""
    d = dt.date.fromisoformat(ref)
    if kind == "week":
        start = d - dt.timedelta(days=(d.weekday() + 1) % 7)
        return start.isoformat(), (start + dt.timedelta(days=6)).isoformat()
    if kind == "month":
        start = d.replace(day=1)
        nxt = (start.replace(day=28) + dt.timedelta(days=4)).replace(day=1)
        return start.isoformat(), (nxt - dt.timedelta(days=1)).isoformat()
    return d.isoformat(), d.isoformat()


def previous_period(kind: str, start: str) -> tuple[str, str]:
    d = dt.date.fromisoformat(start)
    if kind == "week":
        return period("week", (d - dt.timedelta(days=7)).isoformat())
    if kind == "month":
        return period("month", (d - dt.timedelta(days=1)).isoformat())
    return period("day", (d - dt.timedelta(days=1)).isoformat())


# ------------------------------------------------------------------------------------------------ the manager's live picture
def team_today(c: sqlite3.Connection, company_id: int, today: str, s: dict) -> dict[str, Any]:
    now = util.now()
    users = c.execute("SELECT * FROM users WHERE company_id=? AND role='employee' AND active=1 ORDER BY name", (company_id,)).fetchall()
    emps = []
    tot = {"working": 0, "break": 0, "not_started": 0, "closed": 0, "calls": 0, "answered": 0, "interested": 0, "links_sent": 0,
           "links_opened": 0, "reg_reported": 0, "reg_confirmed": 0, "tasks_open": 0, "tasks_total": 0, "pending_gaps": 0}
    from . import work

    for u in users:
        sh = db.one(c, "SELECT * FROM shifts WHERE user_id=? AND status='open' ORDER BY id DESC LIMIT 1", u["id"])
        day = sh["work_date"] if sh else today
        m = day_metrics(c, company_id, u["id"], day, s)
        if sh:
            on_break = work.open_break(c, sh["id"]) is not None
            state = "break" if on_break else "working"
        elif m["shift"]:
            state = "closed"
        else:
            state = "not_started"
        tot[{"working": "working", "break": "break", "closed": "closed", "not_started": "not_started"}[state]] += 1
        last = sh["last_seen_at"] if sh else None
        emps.append({"user": u, "state": state, "m": m, "last_seen": last, "shift": sh})
        tot["calls"] += m["calls"]["total"]
        tot["answered"] += m["calls"]["answered"]
        tot["interested"] += m["interested"]
        tot["links_sent"] += m["links"]["sent"]
        tot["links_opened"] += m["links"]["opened"]
        tot["reg_reported"] += m["registered"]["reported"]
        tot["reg_confirmed"] += m["registered"]["confirmed"]
        tot["tasks_open"] += m["tasks"]["open"]
        tot["tasks_total"] += m["tasks"]["total"]
        tot["pending_gaps"] += m["gaps"]["pending"]
    allow = bool(s["allow_landline"])
    marks = ",".join("?" * 6)
    follow = ("interested", "no_answer", "phone_off", "callback", "link_sent", "visited")
    extra = {
        "pool": db.scalar(c, "SELECT COUNT(*) FROM leads WHERE company_id=? AND owner_id IS NULL AND status='new' AND do_not_call=0" + ("" if allow else " AND line_type='mobile'"), company_id, default=0),
        "overdue": db.scalar(c, f"SELECT COUNT(*) FROM leads WHERE company_id=? AND status IN ({marks}) AND next_follow_up<? AND owner_id IS NOT NULL", company_id, *follow, today, default=0),
        "orphans": db.scalar(c, f"SELECT COUNT(*) FROM leads WHERE company_id=? AND status IN ({marks}) AND owner_id IS NULL", company_id, *follow, default=0),
        "exhausted": db.scalar(c, "SELECT COUNT(*) FROM leads WHERE company_id=? AND status='exhausted'", company_id, default=0),
        "leads": db.scalar(c, "SELECT COUNT(*) FROM leads WHERE company_id=?", company_id, default=0),
    }
    notices = c.execute("SELECT * FROM notices WHERE company_id=? AND seen_at IS NULL ORDER BY id DESC LIMIT 12", (company_id,)).fetchall()
    return {"employees": emps, "totals": tot, "extra": extra, "notices": notices}
