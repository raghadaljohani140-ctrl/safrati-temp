"""Command line: run the server, check it, make a setup code, back up, test a restore, restore."""
from __future__ import annotations

import json
import sys
import urllib.request

from . import __version__, config


def _check() -> int:
    """Used by the container health check: ask our own /healthz."""
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{config.PORT}/healthz", timeout=4) as r:  # nosec - fixed local address
            data = json.loads(r.read().decode())
            return 0 if data.get("ok") else 1
    except Exception as exc:
        print(f"unhealthy: {exc}", file=sys.stderr)
        return 1


def main(argv: list[str]) -> int:
    cmd = argv[0] if argv else "run"
    if cmd == "run":
        from . import app

        app.main()
        return 0
    if cmd == "check":
        return _check()
    if cmd == "version":
        print(__version__)
        return 0
    if cmd == "setup-code":
        from . import db, views_auth

        db.init()
        with db.tx(True) as c:
            if not views_auth.setup_needed(c):
                print("تم إنشاء حساب المالك مسبقًا؛ لا حاجة لرمز إعداد.")
                return 1
            print("رمز الإعداد الجديد:", views_auth.new_setup_code(c))
        return 0
    if cmd == "backup":
        from . import backup

        info = backup.make_backup("manual")
        print(json.dumps(info, ensure_ascii=False, indent=2))
        return 0 if info["ok"] else 1
    if cmd == "restore":
        if "--force" not in argv:
            print("restore replaces ALL the data with the backup read from standard input. Stop the app first (bash restore.sh does) and add --force.", file=sys.stderr)
            return 2
        from . import backup

        info = backup.restore_from(sys.stdin.buffer, allow_bad_chain="--allow-bad-chain" in argv)
        print(json.dumps(info, ensure_ascii=False, indent=2))
        return 0 if info["ok"] else 1
    if cmd == "restore-test":
        from . import backup

        info = backup.restore_test()
        print(json.dumps(info, ensure_ascii=False, indent=2))
        return 0 if info["ok"] else 1
    if cmd == "verify":
        from . import db

        db.init()
        bad = 0
        with db.tx() as c:
            for co in db.all_(c, "SELECT id, name FROM companies ORDER BY id"):
                r = db.verify_chain(c, co["id"])
                print(co["name"], "OK" if r["ok"] else f"BAD at {r['bad_seq']}", r["checked"])
                bad += 0 if r["ok"] else 1
        return 1 if bad else 0
    print("usage: python -m minjaz [run|check|version|setup-code|backup|restore-test|restore --force|verify]", file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
