"""Reports: team by day, week or month; one employee's day with its seal; fixing a wrong result; reopening a day."""
from __future__ import annotations

import csv
import datetime as dt
import io
import re
from typing import Any

from . import consts, db, reports, ui, util, work
from .routes import route
from .ui import badge, button, card, e, form, notice_box, page, select, table, textarea
from .views_common import (EVENT_LABELS, describe_event, evidence_badge, kind_label, outcome_labels, reason_labels, render_day_report, score_badge)
from .web import HttpError, download, redirect

PERIODS = {"day": "يوم", "week": "أسبوع", "month": "شهر"}
DAY_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def valid_day(text: str) -> str | None:
    text = util.ascii_digits(text or "").strip()
    if not DAY_RE.match(text):
        return None
    try:
        return dt.date.fromisoformat(text).isoformat()
    except ValueError:
        return None


def trend(cur: float | None, prev: float | None, *, points: bool = False) -> str:
    """How this period compares with the one before it, in a few characters."""
    if cur is None or prev is None:
        return ""
    if points:
        d = round(cur - prev)
        if d == 0:
            return '<span class="delta flat">= كما قبلها</span>'
        return f'<span class="delta {"up" if d > 0 else "down"}">{"▲" if d > 0 else "▼"} {abs(d)} نقطة</span>'
    if prev == 0:
        return '<span class="delta up">▲ جديد</span>' if cur else ""
    pct = round((cur - prev) / prev * 100)
    if pct == 0:
        return '<span class="delta flat">= كما قبلها</span>'
    return f'<span class="delta {"up" if pct > 0 else "down"}">{"▲" if pct > 0 else "▼"} {abs(pct)}%</span>'


def period_nav(base: str, kind: str, start: str, end: str, today: str) -> str:
    tabs = "".join(f'<a class="{"on" if k == kind else ""}" href="{base}?kind={k}&amp;ref={e(today)}">{lbl}</a>' for k, lbl in PERIODS.items())
    prev_s, _ = reports.previous_period(kind, start)
    nxt_link = f'<a class="btn ghost sm" href="{base}?kind={kind}&amp;ref={util.add_days(end, 1)}">التالي</a>' if end < today else "<span></span>"
    if kind == "day":
        label = ui.fmt_day(start)
    else:
        label = f"من {ui.fmt_day(start, weekday=False)} إلى {ui.fmt_day(end, weekday=False)}"
    return (f'<div class="row between"><div class="seg">{tabs}</div></div>'
            f'<div class="row between mt"><a class="btn ghost sm" href="{base}?kind={kind}&amp;ref={prev_s}">السابق</a>'
            f'<strong>{e(label)}</strong>{nxt_link}</div>')


def hours(seconds: int) -> str:
    return util.fmt_duration(seconds) if seconds else "—"


# ------------------------------------------------------------------------------------------------ team report
@route("GET", "/m/reports", auth="manager", perm="reports.view")
async def reports_home(req):
    ctx = req.ctx
    s = ctx.settings
    today = util.local_date(util.now(), ctx.tz)
    kind = req.q("kind") if req.q("kind") in PERIODS else "week"
    ref = valid_day(req.q("ref")) or today
    start, end = reports.period(kind, ref)
    pstart, pend = reports.previous_period(kind, start)

    def go(c):
        return reports.range_rows(c, ctx.cid, start, end, s), reports.range_rows(c, ctx.cid, pstart, pend, s)

    cur, prev = await db.read(go)
    t, p = reports.totals(cur), reports.totals(prev)
    tiles = "".join([
        ui.stat("مكالمات", t["calls"], sub_html=trend(t["calls"], p["calls"])),
        ui.stat("ردّ العميل", t["answered"], sub=(ui.pct(t["answered"], t["calls"]) if t["calls"] else "")),
        ui.stat("مهتمون", t["interested"], tone="ok" if t["interested"] else ""),
        ui.stat("روابط أُرسلت", t["links_sent"]), ui.stat("روابط فُتحت", t["links_opened"]),
        ui.stat("تسجيلات مُبلَّغة", t["reg_reported"]),
        ui.stat("تسجيلات مؤكدة", t["reg_confirmed"], tone="ok" if t["reg_confirmed"] else ""),
        ui.stat("متوسط التقييم", t["score"] if t["score"] is not None else "—", sub_html=trend(t["score"], p["score"], points=True))])
    # a second line of "compared with the period before" for the numbers that matter
    cmp_rows = [["مكالمات", str(t["calls"]), str(p["calls"]), trend(t["calls"], p["calls"])],
                ["مهتمون", str(t["interested"]), str(p["interested"]), trend(t["interested"], p["interested"])],
                ["روابط فُتحت", str(t["links_opened"]), str(p["links_opened"]), trend(t["links_opened"], p["links_opened"])],
                ["تسجيلات مؤكدة", str(t["reg_confirmed"]), str(p["reg_confirmed"]), trend(t["reg_confirmed"], p["reg_confirmed"])],
                ["أيام عمل", str(t["days"]), str(p["days"]), trend(t["days"], p["days"])]]
    rows = []
    for r in sorted(cur, key=lambda x: (-(x["score"] if x["score"] is not None else -1), x["name"])):
        rows.append([f'<a href="/m/reports/employee/{r["user_id"]}?kind={kind}&amp;ref={start}">{e(r["name"])}</a>' + ("" if r["active"] else ' <span class="badge muted">موقوف</span>'),
                     str(r["days"]), f'{r["done"]} / {r["tasks"]}' if r["tasks"] else "—", str(r["calls"]), ui.pct(r["answered"], r["calls"]) if r["calls"] else "—",
                     str(r["interested"]), f'{r["links_sent"]} / {r["links_opened"]}', f'{r["reg_reported"]} / {r["reg_confirmed"]}',
                     e(hours(r["work_seconds"])), score_badge(r["score"]), str(r["flags"]) if r["flags"] else "—"])
    tbl = table(["الموظف", "أيام", "المهام", "مكالمات", "ردّ", "مهتمون", "روابط (أُرسل/فُتح)", "تسجيل (أُبلغ/أُكّد)", "ساعات العمل", "التقييم", "إشارات"], rows,
                empty_text="لا أيام عمل في هذه الفترة")
    nav = period_nav("/m/reports", kind, start, end, today)
    csv_link = button("تنزيل CSV", href=f"/m/reports.csv?kind={kind}&ref={start}", kind="ghost", small=True, icon_name="download")
    body = (card(nav, title="التقارير") + f'<div class="grid">{tiles}</div>'
            + card(tbl + '<p class="sub mt">التقييم يجمع تنفيذ الخطة والنتائج والجودة والانضباط، ولا يعتمد على عدد المكالمات وحده. «إشارات» أمور تستحق حديثًا، وليست اتهامًا.</p>',
                   title="الفريق", actions=csv_link)
            + card(table(["المقياس", "هذه الفترة", "السابقة", "الفرق"], cmp_rows), title="مقارنة بالفترة السابقة",
                   sub=f"السابقة: {ui.fmt_day(pstart, weekday=False)}" + ("" if pstart == pend else f" – {ui.fmt_day(pend, weekday=False)}")))
    return page(req, "التقارير", body, active="reports", wide=True)


@route("GET", "/m/reports.csv", auth="manager", perm="reports.view")
async def reports_csv(req):
    ctx = req.ctx
    today = util.local_date(util.now(), ctx.tz)
    kind = req.q("kind") if req.q("kind") in PERIODS else "week"
    start, end = reports.period(kind, valid_day(req.q("ref")) or today)

    def go(c):
        rows = reports.range_rows(c, ctx.cid, start, end, ctx.settings)
        db.emit(c, ctx.cid, "export.data", actor=ctx.uid, data={"what": f"تقرير {PERIODS[kind]} {start}", "rows": len(rows)})
        return rows

    rows = await db.write(go)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["الموظف", "من", "إلى", "أيام العمل", "المهام", "المنجزة", "المكالمات", "ردّ العميل", "مهتمون", "روابط أُرسلت", "روابط فُتحت", "تسجيلات مُبلَّغة",
                "تسجيلات مؤكدة", "ساعات العمل", "التقييم", "إشارات"])
    for r in rows:
        w.writerow([r["name"], start, end, r["days"], r["tasks"], r["done"], r["calls"], r["answered"], r["interested"], r["links_sent"], r["links_opened"],
                    r["reg_reported"], r["reg_confirmed"], round(r["work_seconds"] / 3600, 2), r["score"] if r["score"] is not None else "", r["flags"]])
    return download("﻿" + buf.getvalue(), f"minjaz-report-{kind}-{start}.csv", "text/csv; charset=utf-8")


# ------------------------------------------------------------------------------------------------ one employee over a period
@route("GET", "/m/reports/employee/<int:uid>", auth="manager", perm="reports.view")
async def employee_period(req, uid: int):
    ctx = req.ctx
    s = ctx.settings
    today = util.local_date(util.now(), ctx.tz)
    kind = req.q("kind") if req.q("kind") in PERIODS else "week"
    start, end = reports.period(kind, valid_day(req.q("ref")) or today)
    pstart, pend = reports.previous_period(kind, start)

    def go(c):
        u = db.one(c, "SELECT id, name, active FROM users WHERE id=? AND company_id=? AND role='employee'", uid, ctx.cid)
        if not u:
            raise HttpError(404, "الموظف غير موجود")
        cur = reports.range_rows(c, ctx.cid, start, end, s, only_user=uid)
        prev = reports.range_rows(c, ctx.cid, pstart, pend, s, only_user=uid)
        days = []
        for d in reports.days_in(start, end):
            m = reports.metrics_for(c, ctx.cid, uid, d, s)
            if m:
                days.append(m)
        return u, cur[0] if cur else None, prev[0] if prev else None, days

    u, cur, prev, days = await db.read(go)
    nav = period_nav(f"/m/reports/employee/{uid}", kind, start, end, today)
    rows = []
    for m in days:
        sh = m["shift"] or {}
        status = {"open": "مفتوح", "closed": "أُنهي", "auto_closed": "أُغلق تلقائيًا"}.get(sh.get("status"), "")
        rows.append([f'<a href="/m/report/{uid}/{m["day"]}">{e(ui.fmt_day(m["day"]))}</a>', e(status), f'{m["tasks"]["done"]} / {m["tasks"]["total"]}',
                     str(m["calls"]["total"]), str(m["interested"]), f'{m["links"]["sent"]} / {m["links"]["opened"]}',
                     f'{m["registered"]["reported"]} / {m["registered"]["confirmed"]}', e(hours(sh.get("work_seconds", 0))),
                     score_badge(m["rating"]["score"] if m.get("rating") else None), str(len(m["flags"])) if m.get("flags") else "—"])
    summary = ""
    if cur:
        summary = ('<div class="grid">' + "".join([
            ui.stat("أيام العمل", cur["days"], sub_html=trend(cur["days"], prev["days"] if prev else None)),
            ui.stat("مكالمات", cur["calls"], sub_html=trend(cur["calls"], prev["calls"] if prev else None)),
            ui.stat("مهتمون", cur["interested"], sub_html=trend(cur["interested"], prev["interested"] if prev else None)),
            ui.stat("روابط فُتحت", cur["links_opened"], sub_html=trend(cur["links_opened"], prev["links_opened"] if prev else None)),
            ui.stat("تسجيلات مؤكدة", cur["reg_confirmed"], tone="ok" if cur["reg_confirmed"] else "", sub_html=trend(cur["reg_confirmed"], prev["reg_confirmed"] if prev else None)),
            ui.stat("متوسط التقييم", cur["score"] if cur["score"] is not None else "—", sub_html=trend(cur["score"], prev["score"] if prev else None, points=True))]) + "</div>")
    body = (card(nav, title=u["name"], sub="تقرير الفترة")
            + summary
            + card(table(["اليوم", "الحالة", "المهام", "مكالمات", "مهتمون", "روابط", "تسجيل", "ساعات", "التقييم", "إشارات"], rows, empty_text="لا أيام عمل في هذه الفترة"), title="الأيام"))
    return page(req, u["name"], body, active="reports", wide=True, back=f"/m/reports?kind={kind}&ref={start}")


# ------------------------------------------------------------------------------------------------ one employee, one day
@route("GET", "/m/report/<int:uid>/<day>", auth="manager", perm="reports.view")
async def day_report(req, uid: int, day: str):
    ctx = req.ctx
    s = ctx.settings
    day = valid_day(day) or ""
    if not day:
        raise HttpError(404, "تاريخ غير صالح")

    def go(c):
        u = db.one(c, "SELECT id, name FROM users WHERE id=? AND company_id=? AND role='employee'", uid, ctx.cid)
        if not u:
            raise HttpError(404, "الموظف غير موجود")
        m = reports.metrics_for(c, ctx.cid, uid, day, s)
        versions = []
        for row in c.execute("SELECT * FROM daily_reports WHERE company_id=? AND user_id=? AND work_date=? ORDER BY version", (ctx.cid, uid, day)):
            versions.append((row, reports.verify_report(c, row)))
        attempts = c.execute(f"SELECT a.*, {reports.EFFECTIVE} AS eff, l.name AS lead_name,"
                             f" (SELECT COUNT(*) FROM corrections k WHERE k.attempt_id=a.id) AS corr FROM call_attempts a JOIN leads l ON l.id=a.lead_id"
                             f" WHERE a.company_id=? AND a.user_id=? AND a.day=? ORDER BY a.started_at", (ctx.cid, uid, day)).fetchall()
        gaps = c.execute("SELECT g.* FROM gaps g JOIN shifts sh ON sh.id=g.shift_id WHERE g.company_id=? AND g.user_id=? AND sh.work_date=? ORDER BY g.started_at",
                         (ctx.cid, uid, day)).fetchall()
        plan = db.one(c, "SELECT id FROM daily_plans WHERE company_id=? AND user_id=? AND plan_date=?", ctx.cid, uid, day)
        tasks = c.execute("SELECT t.*, l.name FROM tasks t JOIN leads l ON l.id=t.lead_id WHERE t.plan_id=? ORDER BY t.position", (plan["id"],)).fetchall() if plan else []
        events = c.execute("SELECT * FROM events WHERE company_id=? AND user_id=? AND day=? ORDER BY seq DESC LIMIT 300", (ctx.cid, uid, day)).fetchall()
        shift = db.one(c, "SELECT * FROM shifts WHERE company_id=? AND user_id=? AND work_date=?", ctx.cid, uid, day)
        corr = {r["attempt_id"]: r for r in c.execute(
            "SELECT k.* FROM corrections k JOIN call_attempts a ON a.id=k.attempt_id WHERE a.company_id=? AND a.user_id=? AND a.day=? ORDER BY k.id", (ctx.cid, uid, day))}
        return u, m, versions, attempts, gaps, tasks, events, shift, corr, outcome_labels(c, ctx.cid), reason_labels(c, ctx.cid), \
            {r["id"]: r["name"] for r in c.execute("SELECT id, name FROM users WHERE company_id=?", (ctx.cid,))}

    u, m, versions, attempts, gaps, tasks, events, shift, corr, olabels, rlabels, names = await db.read(go)
    tz = ctx.tz
    today = util.local_date(util.now(), tz)
    nav = (f'<div class="row between"><a class="btn ghost sm" href="/m/report/{uid}/{util.add_days(day, -1)}">اليوم السابق</a>'
           f'<strong>{e(u["name"])}</strong>'
           + (f'<a class="btn ghost sm" href="/m/report/{uid}/{util.add_days(day, 1)}">اليوم التالي</a>' if day < today else "<span></span>") + "</div>")
    body = card(nav)
    if m is None:
        body += card(ui.empty("لا يوجد يوم عمل لهذا الموظف في هذا التاريخ"), title=ui.fmt_day(day))
    else:
        body += render_day_report(m, olabels, tz, who=u["name"])
        if versions:
            vrows = []
            for row, v in versions:
                state = badge("سليم", "ok") if v["ok"] else badge("لا يطابق", "bad")
                why = {"close": "إغلاق اليوم", "correction": "تصحيح نتيجة", "reopen": "إعادة فتح"}.get(row["reason"], row["reason"] or "")
                vrows.append([f'نسخة {row["version"]}', e(ui.fmt_dt(row["created_at"], tz)), e(why), state, f'<span class="code ltr">{e(row["seal"][:12])}…</span>'])
            body += card(table(["النسخة", "وقت الختم", "السبب", "فحص الختم", "الختم"], vrows)
                         + '<p class="sub mt">الختم بصمة رقمية للأرقام مرتبطة بآخر حدث في السجل وقت الإغلاق. لو تغيّر رقم لاحقًا لاختلفت البصمة. أي تصحيح يُنشئ نسخة جديدة ولا يمحو القديمة.</p>',
                         title="ختم التقرير")
        elif shift and shift["status"] == "open":
            body += card(notice_box("اليوم ما زال مفتوحًا؛ الأرقام حيّة وتُختم عند الإغلاق.", "info"), title="ختم التقرير")
        if attempts:
            can_fix = ctx.can("corrections.make")
            fix_opts = [(k, v) for k, v in olabels.items() if k != "call_later"]
            rows = []
            for a in attempts:
                eff = a["eff"]
                if a["status"] == "cancelled":
                    res = '<span class="muted">أُلغيت ' + e({"day_closed": "عند إغلاق اليوم", "stale": "انتهت مدتها"}.get(a["cancel_reason"], "")) + "</span>"
                elif a["status"] == "open":
                    res = '<span class="muted">مفتوحة بلا نتيجة</span>'
                elif a["corr"]:
                    res = f'<s class="muted">{e(olabels.get(a["outcome"], a["outcome"]))}</s> ← <b>{e(olabels.get(eff, eff))}</b> {badge("مُصحَّح", "warn")}'
                else:
                    res = e(olabels.get(eff, eff or ""))
                fix = ""
                if can_fix and a["status"] == "recorded":
                    opts = [("", "— النتيجة الصحيحة —")] + [(k, v) for k, v in fix_opts if k != eff]
                    fix = (f'<details class="fold"><summary>تصحيح</summary><div>'
                           + form(req, f"/m/correct/{a['id']}", select("النتيجة الصحيحة", "new", opts, required=True)
                                  + textarea("سبب التصحيح", "reason", rows=2, required=True, maxlength=300, hint="يُحفظ باسمك ولا يمحو الأصل")
                                  + f'<input type="hidden" name="back" value="/m/report/{uid}/{day}">' + button("حفظ التصحيح", small=True, confirm="تصحيح هذه النتيجة؟"))
                           + "</div></details>")
                rows.append([e(ui.fmt_time(a["started_at"], tz)), f'<a href="/m/lead/{a["lead_id"]}">{e(a["lead_name"])}</a>', res, evidence_badge(a["evidence"]),
                             e(util.fmt_call_duration(a["duration_sec"]) if a["duration_sec"] else ""), e(a["note"] or "") + fix])
            body += card(table(["الوقت", "العميل", "النتيجة", "الثقة", "المدة", "ملاحظة"], rows, title_col=1), title="المكالمات", sub=f"{len(attempts)} محاولة")
            if corr:
                body += card("".join(f'<p><b>{e(names.get(k["by_user_id"], ""))}</b> · {e(ui.fmt_dt(k["at"], tz))}: {e(olabels.get(k["old_outcome"], k["old_outcome"]))} ← '
                                     f'{e(olabels.get(k["new_outcome"], k["new_outcome"]))} — {e(k["reason"])}</p>' for k in corr.values()), title="تصحيحات اليوم")
        if gaps:
            grows = [[e(ui.fmt_time(g["started_at"], tz)) + " – " + e(ui.fmt_time(g["ended_at"], tz)),
                      e(util.fmt_duration((util.parse_iso(g["ended_at"]) - util.parse_iso(g["started_at"])).total_seconds())),
                      "خارج التطبيق" if g["kind"] == "away" else "داخل التطبيق",
                      (e(dict(consts.GAP_REASONS).get(g["reason_code"], g["reason_code"] or "")) + (f" — {e(g['reason_text'])}" if g["reason_text"] else "")) if g["status"] == "explained"
                      else badge("بلا توضيح", "warn")] for g in gaps]
            body += card(table(["الفترة", "المدة", "النوع", "التوضيح"], grows, cards=True), title="الفترات الصامتة")
        if tasks:
            trows = []
            for t in tasks:
                if t["status"] == "done":
                    st_ = badge("بنتيجة", "ok")
                elif t["status"] == "reason":
                    st_ = badge("بسبب", "warn") + " " + e(rlabels.get(t["reason_code"], t["reason_code"] or "")) + (f" — {e(t['reason_text'])}" if t["reason_text"] else "")
                else:
                    st_ = badge("مفتوحة", "muted")
                trows.append([f'<a href="/m/lead/{t["lead_id"]}">{e(t["name"])}</a>', e(kind_label(t["kind"])), st_])
            body += card(table(["العميل", "نوع المهمة", "الحالة"], trows), title="مهام اليوم")
        if events:
            tl = "".join(f'<li><div class="tl-t">{e(ui.fmt_time(ev["ts"], tz))} · {e(names.get(ev["actor_id"] or ev["user_id"], "النظام"))}</div>'
                         f'<b>{e(EVENT_LABELS.get(ev["type"], ev["type"]))}</b> {e(describe_event(ev, olabels, rlabels))}</li>' for ev in events)
            body += card(f'<details class="fold"><summary>عرض السجل الكامل لليوم ({len(events)})</summary><div><ul class="timeline">{tl}</ul></div></details>', title="سجل الأحداث")
        if shift and shift["status"] != "open" and ctx.can("corrections.make"):
            body += card(form(req, f"/m/report/{uid}/{day}/reopen", textarea("سبب إعادة الفتح", "why", rows=2, required=True, maxlength=200,
                                                                          hint="يعود اليوم مفتوحًا للموظف، ويُختم من جديد عند إغلاقه، وتبقى النسخة القديمة")
                              + button("إعادة فتح اليوم", kind="ghost", small=True, confirm="إعادة فتح هذا اليوم للموظف؟")),
                         title="إعادة فتح اليوم")
    return page(req, f"{u['name']} — {ui.fmt_day(day, weekday=False)}", body, active="reports", wide=True, back=f"/m/reports/employee/{uid}")


@route("POST", "/m/report/<int:uid>/<day>/reopen", auth="manager", perm="corrections.make")
async def reopen(req, uid: int, day: str):
    ctx = req.ctx
    day = valid_day(day) or ""
    back = f"/m/report/{uid}/{day}"

    def go(c):
        sh = db.one(c, "SELECT * FROM shifts WHERE company_id=? AND user_id=? AND work_date=?", ctx.cid, uid, day)
        if not sh:
            return False, "لا يوجد يوم عمل"
        return work.reopen_day(c, ctx.cid, sh["id"], ctx.uid, req.f("why"))

    ok, msg = await db.write(go)
    return ui.flash_redirect(back, "ok" if ok else "err", "أُعيد فتح اليوم للموظف" if ok else msg)


@route("POST", "/m/correct/<int:attempt_id>", auth="manager", perm="corrections.make")
async def correct(req, attempt_id: int):
    ctx = req.ctx
    back = req.f("back") if req.f("back").startswith("/m/") else "/m/reports"

    def go(c):
        return work.correct_outcome(c, ctx.cid, attempt_id, req.f("new"), req.f("reason"), ctx.uid, ctx.settings)

    ok, msg, effect = await db.write(go)
    if not ok:
        return ui.flash_redirect(back, "err", msg)
    extra = " وأُعيدت جدولة العميل حسب النتيجة الجديدة" if effect == "rescheduled" else " (في التقرير فقط، لأن للعميل مكالمة أحدث)"
    return ui.flash_redirect(back, "ok", "صُحّحت النتيجة" + extra)
