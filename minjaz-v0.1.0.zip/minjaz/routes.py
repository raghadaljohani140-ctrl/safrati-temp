"""The one router every view module registers its pages on."""
from .web import Router

ROUTER = Router()
route = ROUTER.route
