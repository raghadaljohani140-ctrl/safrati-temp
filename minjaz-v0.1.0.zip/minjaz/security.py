"""Passwords, sessions, permissions and rate limits."""
from __future__ import annotations

import base64
import datetime as dt
import hashlib
import hmac
import secrets
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from typing import Any

from . import consts, db, settings as st, util

SCRYPT_N, SCRYPT_R, SCRYPT_P = 2**14, 8, 1
IDLE_SECONDS = 12 * 3600
ABSOLUTE_SECONDS = 14 * 86400
TOUCH_EVERY = 300  # refresh the sliding expiry at most every five minutes
MAX_FAILS = 5
LOCK_MINUTES = 10
COOKIE = "mj_s"


def _b64(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    dk = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=SCRYPT_N, r=SCRYPT_R, p=SCRYPT_P, maxmem=64 * 1024 * 1024, dklen=32)
    return f"scrypt${SCRYPT_N}${SCRYPT_R}${SCRYPT_P}${_b64(salt)}${_b64(dk)}"


def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, n, r, p, salt, dk = stored.split("$")
        if scheme != "scrypt":
            return False
        want = base64.b64decode(dk)
        got = hashlib.scrypt(password.encode("utf-8"), salt=base64.b64decode(salt), n=int(n), r=int(r), p=int(p),
                             maxmem=64 * 1024 * 1024, dklen=len(want))
        return hmac.compare_digest(got, want)
    except Exception:
        return False


_dummy_hash: str | None = None


def _dummy() -> str:
    global _dummy_hash
    if _dummy_hash is None:
        _dummy_hash = hash_password(secrets.token_urlsafe(8))
    return _dummy_hash


def password_problem(password: str, username: str = "") -> str:
    """Arabic reason the password is not acceptable, or '' when it is fine."""
    if len(password) < 8:
        return "كلمة المرور أقل من 8 أحرف"
    if len(password) > 200:
        return "كلمة المرور طويلة جدًا"
    if password.isdigit():
        return "كلمة المرور أرقام فقط؛ أضف إليها حروفًا"
    if len(set(password)) < 4:
        return "كلمة المرور سهلة التخمين"
    if username and password.lower() == username.lower():
        return "كلمة المرور مثل اسم المستخدم"
    return ""


def username_problem(username: str) -> str:
    if not (3 <= len(username) <= 32):
        return "اسم المستخدم من 3 إلى 32 حرفًا"
    allowed = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-")
    if any(ch not in allowed for ch in username):
        return "اسم المستخدم حروف إنجليزية وأرقام ونقطة وشرطة فقط"
    if not username[0].isalnum():
        return "اسم المستخدم يبدأ بحرف أو رقم"
    return ""


def generate_password() -> str:
    return util.short_token(10)


# ----------------------------------------------------------------------------------------------- permissions
def perms_of(user: sqlite3.Row | dict) -> set[str]:
    role = user["role"]
    if role == "owner":
        return set(consts.PERMISSIONS)
    if role == "manager":
        raw = user["perms"]
        if raw is None:
            return set(consts.ROLE_PERMS["manager"])
        return {p for p in raw.split(",") if p in consts.PERMISSIONS and p != "managers.manage"}
    return set()


# ----------------------------------------------------------------------------------------------- rate limiting
class Limiter:
    """A sliding window held in memory. Good enough for one process; it forgets on restart, which is fine for throttling."""

    def __init__(self) -> None:
        self._hits: dict[str, list[float]] = {}
        self._lock = threading.Lock()

    def allow(self, key: str, limit: int, window: float, record: bool = True) -> bool:
        now = time.monotonic()
        with self._lock:
            hits = [t for t in self._hits.get(key, []) if now - t < window]
            ok = len(hits) < limit
            if ok and record:
                hits.append(now)
            self._hits[key] = hits
            if len(self._hits) > 5000:
                self._hits = {k: v for k, v in self._hits.items() if v and now - v[-1] < 3600}
            return ok


LIMITER = Limiter()


# ----------------------------------------------------------------------------------------------- the per-request context
@dataclass
class Ctx:
    user: dict
    session: dict
    company: dict
    settings: dict[str, Any]
    perms: set[str] = field(default_factory=set)

    @property
    def uid(self) -> int:
        return self.user["id"]

    @property
    def cid(self) -> int:
        return self.user["company_id"]

    @property
    def role(self) -> str:
        return self.user["role"]

    @property
    def is_manager(self) -> bool:
        return self.user["role"] in ("owner", "manager")

    @property
    def tz(self) -> str:
        return self.settings["tz"]

    @property
    def csrf(self) -> str:
        return self.session["csrf"]

    def can(self, perm: str) -> bool:
        return perm in self.perms


def _token_hash(raw: str) -> str:
    return util.sha256("session:" + raw)


def create_session(c: sqlite3.Connection, user: sqlite3.Row | dict, ip: str, ua: str) -> str:
    raw = secrets.token_urlsafe(32)
    now = util.now()
    c.execute(
        "INSERT INTO sessions(token_hash,user_id,company_id,csrf,created_at,last_seen_at,expires_at,ip,ua) VALUES(?,?,?,?,?,?,?,?,?)",
        (_token_hash(raw), user["id"], user["company_id"], secrets.token_urlsafe(24), util.iso(now), util.iso(now),
         util.iso(now + dt.timedelta(seconds=IDLE_SECONDS)), ip[:64], (ua or "")[:200]))
    return raw


def load_ctx(c: sqlite3.Connection, raw: str) -> Ctx | None:
    row = db.one(
        c, "SELECT s.id AS sid, s.csrf, s.created_at AS s_created, s.last_seen_at, s.expires_at, u.*, co.name AS company_name,"
           " co.active AS company_active, co.plan AS company_plan, co.slug AS company_slug"
           " FROM sessions s JOIN users u ON u.id=s.user_id JOIN companies co ON co.id=u.company_id WHERE s.token_hash=?",
        _token_hash(raw))
    if not row:
        return None
    now = util.now()
    if row["expires_at"] < util.iso(now) or util.parse_iso(row["s_created"]) + dt.timedelta(seconds=ABSOLUTE_SECONDS) < now:
        return None
    if not row["active"] or not row["company_active"]:
        return None
    user = {k: row[k] for k in row.keys() if k not in ("sid", "csrf", "s_created", "last_seen_at", "expires_at", "company_name",
                                                       "company_active", "company_plan", "company_slug")}
    session = {"id": row["sid"], "csrf": row["csrf"], "last_seen_at": row["last_seen_at"], "created_at": row["s_created"]}
    company = {"id": row["company_id"], "name": row["company_name"], "plan": row["company_plan"], "slug": row["company_slug"]}
    return Ctx(user=user, session=session, company=company, settings=st.load(c, row["company_id"]), perms=perms_of(user))


def touch_session(c: sqlite3.Connection, session_id: int) -> None:
    now = util.now()
    c.execute("UPDATE sessions SET last_seen_at=?, expires_at=? WHERE id=?",
              (util.iso(now), util.iso(now + dt.timedelta(seconds=IDLE_SECONDS)), session_id))


def session_is_stale(ctx: Ctx) -> bool:
    return (util.now() - util.parse_iso(ctx.session["last_seen_at"])).total_seconds() > TOUCH_EVERY


def end_session(c: sqlite3.Connection, raw: str) -> None:
    c.execute("DELETE FROM sessions WHERE token_hash=?", (_token_hash(raw),))


def end_user_sessions(c: sqlite3.Connection, user_id: int, keep_session_id: int | None = None) -> None:
    c.execute("DELETE FROM sessions WHERE user_id=? AND id IS NOT ?", (user_id, keep_session_id))


def purge_sessions(c: sqlite3.Connection) -> int:
    cur = c.execute("DELETE FROM sessions WHERE expires_at<?", (util.now_iso(),))
    return cur.rowcount


# ----------------------------------------------------------------------------------------------- login
def find_user(c: sqlite3.Connection, username: str) -> sqlite3.Row | None:
    return db.one(c, "SELECT * FROM users WHERE username=?", username.strip())


def check_login(user: sqlite3.Row | None, password: str) -> str:
    """'' when the password is right; else a code: bad | locked | inactive. Slow by design; call outside any write lock."""
    if user is None:
        verify_password(password, _dummy())
        return "bad"
    if user["locked_until"] and user["locked_until"] > util.now_iso():
        return "locked"
    ok = verify_password(password, user["password_hash"])
    if not user["active"]:
        return "inactive"
    return "" if ok else "bad"


def record_login(c: sqlite3.Connection, user: sqlite3.Row, result: str, ip: str, ua: str) -> str | None:
    """Writes the outcome of a login attempt. Returns a raw session token when it succeeded."""
    if result == "":
        c.execute("UPDATE users SET failed_logins=0, locked_until=NULL, last_login_at=? WHERE id=?", (util.now_iso(), user["id"]))
        token = create_session(c, user, ip, ua)
        db.emit(c, user["company_id"], "auth.login", actor=user["id"], user=user["id"], data={"ip": ip, "ua": (ua or "")[:120]})
        return token
    if result == "bad":
        fails = user["failed_logins"] + 1
        if fails >= MAX_FAILS:
            c.execute("UPDATE users SET failed_logins=0, locked_until=? WHERE id=?",
                      (util.iso(util.now() + dt.timedelta(minutes=LOCK_MINUTES)), user["id"]))
            db.emit(c, user["company_id"], "auth.locked", user=user["id"], data={"ip": ip, "minutes": LOCK_MINUTES})
        else:
            c.execute("UPDATE users SET failed_logins=? WHERE id=?", (fails, user["id"]))
            db.emit(c, user["company_id"], "auth.login_failed", user=user["id"], data={"ip": ip})
    return None
