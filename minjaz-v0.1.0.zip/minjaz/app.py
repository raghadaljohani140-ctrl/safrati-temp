"""Request dispatch and start-up."""
from __future__ import annotations

import asyncio
import hmac
import logging
import urllib.parse
from pathlib import Path

from . import __version__, config, db, security, ui, web
from .routes import ROUTER
from .web import HttpError, Request, Response

log = logging.getLogger("minjaz")
STATIC = web.Static(Path(__file__).parent / "static")
OPEN_PATHS = {"/password", "/logout"}


def body_limit(method: str, path: str) -> int:
    if method == "POST" and path == "/m/import/upload":
        return config.MAX_UPLOAD_MB * 1024 * 1024 + 256 * 1024
    if path.startswith("/api/") or path == "/m/compare/paste":
        return 2 * 1024 * 1024
    return 512 * 1024


def same_origin(req: Request) -> bool:
    """Modern browsers say where a request came from. A form posted from another site is refused."""
    site = req.headers.get("sec-fetch-site")
    if site:
        return site in ("same-origin", "none")
    origin = req.headers.get("origin")
    if origin:
        return origin != "null" and urllib.parse.urlsplit(origin).netloc == req.host
    return True


def home_for(ctx) -> str:
    return "/m" if ctx.is_manager else "/w"


async def dispatch(req: Request) -> Response:
    method = "GET" if req.method == "HEAD" else req.method
    path = req.path
    if path.startswith("/static/") and method == "GET":
        hit = STATIC.get(path[8:], versioned="v" in req.query)
        return hit or ui.error_page(req, 404, "غير موجود", "الملف المطلوب غير موجود")
    if path == "/manifest.webmanifest" and method == "GET":
        hit = STATIC.get("manifest.webmanifest", versioned=False)
        return hit or ui.error_page(req, 404, "غير موجود", "الملف المطلوب غير موجود")
    if path == "/healthz":
        ok = await db.read(lambda c: db.scalar(c, "SELECT 1", default=0))
        return web.json_response({"ok": bool(ok), "version": __version__})
    route, params, exists = ROUTER.match(method, path)
    if route is None:
        if exists:
            return ui.error_page(req, 405, "الطريقة غير مسموحة", "لا يمكن فتح هذه الصفحة بهذه الطريقة")
        token = req.cookies.get(security.COOKIE)
        req.ctx = await db.read(security.load_ctx, token) if token else None
        return ui.error_page(req, 404, "الصفحة غير موجودة", "تحقق من الرابط أو عد إلى الرئيسية")
    opts = route.opts
    auth = opts.get("auth", "user")
    ctx = None
    if auth != "api":
        token = req.cookies.get(security.COOKIE)
        if token:
            ctx = await db.read(security.load_ctx, token)
            if ctx is not None and security.session_is_stale(ctx):
                await db.write(security.touch_session, ctx.session["id"])
    req.ctx = ctx
    req.params = params
    if auth in ("user", "employee", "manager") and ctx is None:
        return web.redirect("/login?next=" + urllib.parse.quote(req.target) if method == "GET" else "/login")
    if ctx is not None and ctx.user["must_change_password"] and path not in OPEN_PATHS and not path.startswith("/static/"):
        return web.redirect("/password")
    if auth == "employee" and ctx.is_manager:
        return web.redirect("/m")
    if auth == "manager":
        if not ctx.is_manager:
            return web.redirect("/w")
        perm = opts.get("perm")
        if perm and not ctx.can(perm):
            return ui.error_page(req, 403, "ليست لديك صلاحية", "هذه الصفحة تحتاج صلاحية لا يملكها حسابك. اطلبها من مالك الحساب.")
    if method == "POST" and auth != "api":
        if not same_origin(req):
            return ui.error_page(req, 403, "طلب مرفوض", "جاء الطلب من موقع آخر")
        if ctx is not None and opts.get("csrf", True) and not hmac.compare_digest(req.f_raw("_csrf"), ctx.csrf):
            return ui.error_page(req, 403, "انتهت صلاحية الصفحة", "أعد فتح الصفحة وحاول مرة أخرى")
    try:
        return await route.handler(req, **params)
    except HttpError as e:
        return ui.error_page(req, e.status, web.REASONS.get(e.status, "خطأ"), e.message or "تعذر تنفيذ الطلب")


def load_views() -> None:
    from . import views_auth, views_platform, views_employee, views_manager, views_leads, views_reports, views_compare, views_admin, views_api  # noqa: F401


def build_server() -> web.Server:
    load_views()
    return web.Server(dispatch, body_limit, real_ip_header=config.REAL_IP_HEADER, hsts=config.COOKIE_SECURE)


async def amain() -> None:
    from . import scheduler, views_auth

    logging.basicConfig(level=getattr(logging, config.LOG_LEVEL, logging.INFO), format="%(asctime)s %(levelname)s %(name)s %(message)s")
    config.DATA_DIR.mkdir(parents=True, exist_ok=True)
    config.backups_dir().mkdir(parents=True, exist_ok=True)
    config.uploads_dir().mkdir(parents=True, exist_ok=True)
    db.init()
    server = build_server()
    code = await db.write(views_auth.ensure_setup_code)
    if code:
        log.warning("=== رمز الإعداد الأول: %s === افتح /setup وأدخله لإنشاء حساب المالك (يُستخدم مرة واحدة)", code)
    elif await db.read(views_auth.setup_needed):
        log.warning("لم يُنشأ حساب المالك بعد. لتوليد رمز جديد: docker exec minjaz-web python -m minjaz setup-code")
    await server.serve(config.HOST, config.PORT, background=[scheduler.run])


def main() -> None:
    asyncio.run(amain())
