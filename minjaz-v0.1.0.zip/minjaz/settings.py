"""Company settings: every rule a company may tune, with its default. Stored as text in the `settings` table."""
from __future__ import annotations

import sqlite3
from typing import Any

# key: (default, type, Arabic label, help text)
DEFS: dict[str, tuple[Any, str, str, str]] = {
    "tz": ("Asia/Riyadh", "str", "المنطقة الزمنية", "تُحسب بها الأيام والتقارير"),
    "shift_hours": (8, "float", "ساعات العمل الصافية في اليوم", "بعد خصم الاستراحات"),
    "planned_break_minutes": (60, "int", "الاستراحة المتوقعة (دقائق)", "تُضاف إلى موعد النهاية المخطط"),
    "minutes_per_call": (4, "float", "الدقائق المقدّرة للمكالمة الواحدة", "تحدد سعة اليوم؛ تُقاس لاحقًا من التجربة"),
    "daily_new": (50, "int", "الأرقام الجديدة في اليوم", "لكل موظف، ويمكن تخصيصها له"),
    "gap_minutes": (10, "int", "مدة الخمول قبل السؤال (دقائق)", "بعدها يسأل التطبيق الموظف ماذا يفعل"),
    "auto_close_hours": (2, "float", "الإغلاق التلقائي بعد موعد النهاية (ساعات)", "إن نسي الموظف إنهاء الدوام"),
    "allow_landline": (0, "bool", "إدخال الأرقام الأرضية والدولية في الخطط", "الجوال السعودي فقط إن أُطفئ"),
    "lock_call_hours": (1, "bool", "قفل زر الاتصال خارج الساعات المسموحة", "للمكالمات الترويجية"),
    "call_start": ("09:00", "time", "بداية الاتصال المسموح", "لائحة الهيئة: لا مكالمات ترويجية قبل 9 صباحًا"),
    "call_end": ("22:00", "time", "نهاية الاتصال المسموح", "لا مكالمات بعد 10 مساءً"),
    "ramadan": (0, "bool", "وضع رمضان", "من 12 ظهرًا إلى 1 فجرًا"),
    "ramadan_start": ("12:00", "time", "بداية الاتصال في رمضان", ""),
    "ramadan_end": ("01:00", "time", "نهاية الاتصال في رمضان", "بعد منتصف الليل"),
    "start_time": ("", "time", "موعد بدء الدوام", "اختياري، يدخل في تقييم الانضباط"),
    "start_grace_min": (15, "int", "السماح بالتأخر (دقائق)", ""),
    "platform_name": ("", "str", "اسم المنصة التي تسوّق لها", "يظهر في رسالة الرابط وبطاقة الافتتاح"),
    "platform_url": ("", "str", "رابط المنصة", "إليه يحوّل الرابط الشخصي للعميل"),
    "link_message": ("السلام عليكم {name}، هذا رابط التسجيل في {platform}: {link}", "text", "رسالة الواتساب", "{name} {platform} {link}"),
    "opening_script": ("السلام عليكم، معك {employee} من {company}. أتصل بخصوص تسجيل استراحتكم في {platform}. "
                       "وإن أحببت إنهاء المكالمة فأخبرني.", "text", "بطاقة افتتاح المكالمة", "تُعرض قبل الاتصال: من المتصل وسببه"),
    "w_exec": (35, "int", "وزن تنفيذ الخطة", "من 100"),
    "w_results": (30, "int", "وزن النتائج", ""),
    "w_quality": (25, "int", "وزن الجودة", ""),
    "w_discipline": (10, "int", "وزن الانضباط", ""),
    "target_points": (10, "float", "نقاط النتائج المستهدفة يوميًا", "نقطة لكل نتيجة بحسب الأوزان أدناه"),
    "pts_registered_confirmed": (10, "float", "نقاط تسجيل مؤكد", ""),
    "pts_registered_reported": (3, "float", "نقاط تسجيل مُبلَّغ به", ""),
    "pts_link_opened": (2, "float", "نقاط رابط فُتح", ""),
    "pts_link_sent": (1, "float", "نقاط رابط أُرسل", ""),
    "pts_interested": (1.5, "float", "نقاط عميل مهتم", ""),
    "attribution_days": (30, "int", "مدة نسب التسجيل للموظف (أيام)", "من آخر تواصل"),
    "min_note_len": (5, "int", "أقل طول لملاحظة إلزامية", "حرفًا"),
    "fu_interested": ("1,2+", "days", "متابعة المهتم (أيام)", "الرقم الأخير يتكرر إن انتهى بعلامة +"),
    "fu_no_answer": ("1,2,4", "days", "متابعة «لم يرد» (أيام)", "ثم يتوقف ويظهر للمدير"),
    "fu_phone_off": ("", "days", "متابعة «الهاتف مغلق»", "فارغ = مثل «لم يرد»"),
    "fu_link_sent": ("1,2+", "days", "التحقق ممن أُرسل لهم الرابط", ""),
    "fu_visited": ("1,2+", "days", "متابعة من دخل ولم يسجّل", ""),
}

BOOL_TRUE = {"1", "true", "yes", "on", "y"}


def parse_days(text: str) -> tuple[list[int], bool]:
    """'1,2,4' -> ([1, 2, 4], False);  '1,2+' -> ([1, 2], True). The last number repeats forever when there is a +."""
    text = (text or "").strip()
    repeat = text.endswith("+")
    nums: list[int] = []
    for part in text.rstrip("+").split(","):
        part = part.strip()
        if part.isdigit() and 0 < int(part) <= 90:
            nums.append(int(part))
    return nums, repeat and bool(nums)


def convert(key: str, raw: Any) -> Any:
    default, typ, *_ = DEFS[key]
    if raw is None:
        return default
    try:
        if typ == "int":
            return int(float(raw))
        if typ == "float":
            return float(raw)
        if typ == "bool":
            return 1 if str(raw).strip().lower() in BOOL_TRUE else 0
        return str(raw)
    except (TypeError, ValueError):
        return default


def validate(key: str, raw: str) -> tuple[bool, str]:
    """Is `raw` an acceptable value for this setting? (returns ok, Arabic reason)"""
    if key not in DEFS:
        return False, "إعداد غير معروف"
    _, typ, label, _ = DEFS[key]
    raw = (raw or "").strip()
    if typ in ("int", "float"):
        try:
            v = float(raw)
        except ValueError:
            return False, f"«{label}» يقبل رقمًا فقط"
        if v < 0 or v > 100000:
            return False, f"«{label}» خارج المدى المقبول"
        if key in ("shift_hours",) and not 1 <= v <= 16:
            return False, "ساعات العمل بين 1 و16"
        if key == "minutes_per_call" and not 0.5 <= v <= 60:
            return False, "دقائق المكالمة بين نصف دقيقة و60"
        if key == "daily_new" and not 0 <= v <= 500:
            return False, "الأرقام الجديدة بين 0 و500"
    elif typ == "time":
        if raw and not (len(raw) == 5 and raw[2] == ":" and raw[:2].isdigit() and raw[3:].isdigit() and int(raw[:2]) < 24 and int(raw[3:]) < 60):
            return False, f"«{label}» بصيغة 09:00"
    elif typ == "days":
        if raw and not parse_days(raw)[0]:
            return False, f"«{label}» أرقام أيام مفصولة بفواصل، مثل 1,2,4"
    elif typ == "str":
        if key == "tz" and not raw:
            return False, "المنطقة الزمنية مطلوبة"
        if key == "platform_url" and raw and not raw.startswith(("https://", "http://")):
            return False, "الرابط يبدأ بـ https://"
        if len(raw) > 300:
            return False, "النص طويل"
    elif typ == "text":
        if len(raw) > 600:
            return False, "النص طويل (600 حرف كحد أقصى)"
    return True, ""


def load(c: sqlite3.Connection, company_id: int) -> dict[str, Any]:
    out = {k: v[0] for k, v in DEFS.items()}
    for row in c.execute("SELECT key, value FROM settings WHERE company_id=?", (company_id,)):
        if row["key"] in DEFS:
            out[row["key"]] = convert(row["key"], row["value"])
    return out
