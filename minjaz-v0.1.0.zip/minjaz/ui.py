"""HTML building blocks.

Convention: parameters called `body`, `html_*` or ending in `_html` are trusted markup that the caller has already escaped.
Every other string a function receives is escaped here. Anything that came from a user goes through `e()` before it joins markup.
"""
from __future__ import annotations

import datetime as dt
import html
import json
import re
from typing import Any, Iterable, Sequence

from . import __version__, consts, util
from .phones import display as phone_display
from .web import Request, Response, html_response, redirect

VER = __version__
BRAND = "مِنجَز"


def e(v: Any) -> str:
    return html.escape("" if v is None else str(v), quote=True)


def attrs(**kw: Any) -> str:
    out = []
    for k, v in kw.items():
        if v is None or v is False:
            continue
        k = k.rstrip("_").replace("_", "-")
        out.append(f" {k}" if v is True else f' {k}="{e(v)}"')
    return "".join(out)


# --------------------------------------------------------------------------------------------- dates and numbers
WEEKDAYS = ["الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد"]
MONTHS = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]


def fmt_day(day: str, with_year: bool = True, weekday: bool = True) -> str:
    try:
        d = dt.date.fromisoformat(day)
    except (TypeError, ValueError):
        return day or ""
    text = f"{d.day} {MONTHS[d.month - 1]}"
    if with_year:
        text += f" {d.year}"
    return f"{WEEKDAYS[d.weekday()]} {text}" if weekday else text


def fmt_time(ts: str | None, tz: str) -> str:
    return util.local_hm(ts, tz) if ts else ""


def fmt_dt(ts: str | None, tz: str) -> str:
    if not ts:
        return ""
    d = util.local_dt(ts, tz)
    return f"{d.day} {MONTHS[d.month - 1]} {d:%H:%M}"


def ago(ts: str | None) -> str:
    if not ts:
        return ""
    secs = (util.now() - util.parse_iso(ts)).total_seconds()
    if secs < 45:
        return "الآن"
    if secs < 3600:
        return f"قبل {int(secs // 60) or 1} دقيقة"
    if secs < 86400:
        return f"قبل {int(secs // 3600)} ساعة"
    return f"قبل {int(secs // 86400)} يوم"


def num(n: Any) -> str:
    if n is None:
        return "—"
    if isinstance(n, float):
        return f"{n:,.1f}".rstrip("0").rstrip(".") if n != int(n) else f"{int(n):,}"
    return f"{n:,}"


def pct(a: float, b: float) -> str:
    return f"{round(100 * a / b)}%" if b else "—"


def phone(p: str | None) -> str:
    return f'<bdi dir="ltr" class="num">{e(phone_display(p))}</bdi>' if p else ""


# --------------------------------------------------------------------------------------------- icons
def icon(name: str, cls: str = "") -> str:
    return f'<svg class="i {e(cls)}" aria-hidden="true"><use href="/static/icons.svg?v={VER}#i-{e(name)}"/></svg>'


# --------------------------------------------------------------------------------------------- small components
TONES = {"ok": "ok", "good": "ok", "warn": "warn", "bad": "bad", "info": "info", "muted": "muted", "brand": "brand", "": ""}

STATUS_TONE = {
    "new": "info", "interested": "ok", "not_interested": "muted", "no_answer": "warn", "phone_off": "warn", "wrong_number": "bad",
    "callback": "brand", "link_sent": "brand", "visited": "brand", "registered_reported": "ok", "registered_confirmed": "ok",
    "exhausted": "muted", "do_not_call": "bad",
}


def badge(text: str, tone: str = "") -> str:
    return f'<span class="badge {TONES.get(tone, "")}">{e(text)}</span>'


def status_badge(status: str) -> str:
    return badge(consts.STATUS_LABELS.get(status, status), STATUS_TONE.get(status, ""))


def card(body: str, *, title: str = "", sub: str = "", cls: str = "", actions: str = "", id_: str = "") -> str:
    head = ""
    if title or actions:
        head = (f'<div class="card-h"><div><h2>{e(title)}</h2>{f"<p class=sub>{e(sub)}</p>" if sub else ""}</div>'
                f'{f"<div class=card-a>{actions}</div>" if actions else ""}</div>')
    return f'<section class="card {e(cls)}"{attrs(id=id_ or None)}>{head}{body}</section>'


def stat(label: str, value: Any, *, href: str = "", tone: str = "", sub: str = "", sub_html: str = "") -> str:
    small = e(sub) if sub else sub_html
    inner = (f'<span class="stat-l">{e(label)}</span><strong class="stat-v">{e(value)}</strong>'
             f'{f"<span class=stat-s>{small}</span>" if small else ""}')
    cls = f"stat {TONES.get(tone, '')}"
    return f'<a class="{cls}" href="{e(href)}">{inner}</a>' if href else f'<div class="{cls}">{inner}</div>'


def empty(text: str, hint: str = "", action_html: str = "") -> str:
    return (f'<div class="empty"><p>{e(text)}</p>{f"<p class=sub>{e(hint)}</p>" if hint else ""}{action_html}</div>')


_TAG = re.compile(r"<[^>]*>")
_LONG_CELL = 26


def table(headers: Sequence[str], rows: Iterable[Sequence[str]], *, cls: str = "", empty_text: str = "لا توجد بيانات",
          cards: bool | None = None, title_col: int = 0) -> str:
    """A data table. Cells are trusted markup (callers escape); headers are plain text and are escaped here.

    On a phone a table with five or more columns (or `cards=True`) turns into one card per row: the `title_col` cell is the card's
    heading, long cells span the card, and every other cell shows its column name above its value. Nothing scrolls sideways.
    """
    rows = list(rows)
    if not rows:
        return empty(empty_text)
    as_cards = len(headers) >= 5 if cards is None else cards
    head = "".join(f"<th>{e(h)}</th>" for h in headers)
    out = []
    for r in rows:
        tds = []
        for i, cell in enumerate(r):
            cell = "" if cell is None else str(cell)
            label = headers[i] if i < len(headers) else ""
            plain = _TAG.sub("", cell).strip()
            flags = []
            if i == title_col:
                flags.append("t")
            if not plain and "<input" not in cell and "<form" not in cell and "<svg" not in cell:
                flags.append("e")
            elif len(plain) > _LONG_CELL or "<form" in cell or "<details" in cell:
                flags.append("w")
            klass = f' class="{" ".join(flags)}"' if flags else ""
            tds.append(f'<td data-l="{e(label)}"{klass}>{cell}</td>')
        out.append("<tr>" + "".join(tds) + "</tr>")
    return (f'<div class="tw{" cards" if as_cards else ""}"><table class="table {e(cls)}"><thead><tr>{head}</tr></thead>'
            f'<tbody>{"".join(out)}</tbody></table></div>')


def ring(done: int, total: int, label: str = "") -> str:
    p = 0 if total <= 0 else min(1.0, done / total)
    c = 2 * 3.14159 * 42
    return (f'<div class="ring" role="img" aria-label="{e(label or f"{done} من {total}")}">'
            f'<svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="42" class="ring-bg"/>'
            f'<circle cx="50" cy="50" r="42" class="ring-fg" stroke-dasharray="{c * p:.1f} {c:.1f}" transform="rotate(-90 50 50)"/></svg>'
            f'<div class="ring-t"><strong>{done}</strong><span>من {total}</span></div></div>')


def bar(value: float, total: float, tone: str = "") -> str:
    p = 0 if total <= 0 else max(0, min(100, round(100 * value / total)))
    return f'<div class="bar {TONES.get(tone, "")}"><i style="width:{p}%"></i></div>'


def pager(page: int, pages: int, base: str) -> str:
    if pages <= 1:
        return ""
    sep = "&" if "?" in base else "?"
    prev = f'<a class="btn ghost sm" href="{e(base)}{sep}page={page - 1}">السابق</a>' if page > 1 else ""
    nxt = f'<a class="btn ghost sm" href="{e(base)}{sep}page={page + 1}">التالي</a>' if page < pages else ""
    return f'<nav class="pager">{nxt}<span>صفحة {page} من {pages}</span>{prev}</nav>'


def button(text: str, *, kind: str = "primary", type_: str = "submit", icon_name: str = "", href: str = "", big: bool = False,
           small: bool = False, name: str = "", value: str = "", confirm: str = "", cls: str = "", **extra: Any) -> str:
    classes = f"btn {kind} {'lg' if big else ''} {'sm' if small else ''} {cls}".strip()
    inner = f"{icon(icon_name) if icon_name else ''}<span>{e(text)}</span>"
    if href:
        return f'<a class="{classes}" href="{e(href)}"{attrs(**extra)}>{inner}</a>'
    return (f'<button class="{classes}" type="{e(type_)}"{attrs(name=name or None, value=value or None, data_confirm=confirm or None)}'
            f'{attrs(**extra)}>{inner}</button>')


def csrf_input(req: Request) -> str:
    ctx = req.ctx
    return f'<input type="hidden" name="_csrf" value="{e(ctx.csrf)}">' if ctx else ""


def form(req: Request, action: str, body: str, *, method: str = "post", cls: str = "", confirm: str = "", multipart: bool = False,
         id_: str = "", **extra: Any) -> str:
    enc = ' enctype="multipart/form-data"' if multipart else ""
    tok = csrf_input(req) if method.lower() == "post" else ""
    return (f'<form method="{e(method)}" action="{e(action)}" class="{e(cls)}"{enc}'
            f'{attrs(data_confirm=confirm or None, id=id_ or None)}{attrs(**extra)}>{tok}{body}</form>')


def field(label: str, name: str, value: Any = "", *, type_: str = "text", required: bool = False, hint: str = "", ltr: bool = False,
          placeholder: str = "", autocomplete: str = "", maxlength: int | None = None, min_: Any = None, max_: Any = None,
          step: Any = None, autofocus: bool = False, inputmode: str = "", pattern: str = "") -> str:
    cls = "ltr" if ltr else ""
    extra = attrs(required=required, placeholder=placeholder or None, autocomplete=autocomplete or None, maxlength=maxlength,
                  min=min_, max=max_, step=step, autofocus=autofocus, inputmode=inputmode or None, pattern=pattern or None)
    inp = f'<input id="f-{e(name)}" class="{cls}" type="{e(type_)}" name="{e(name)}" value="{e(value)}"{extra}>'
    return f'<label class="field" for="f-{e(name)}"><span class="lbl">{e(label)}</span>{inp}{f"<span class=hint>{e(hint)}</span>" if hint else ""}</label>'


def textarea(label: str, name: str, value: str = "", *, rows: int = 3, hint: str = "", maxlength: int = 600, required: bool = False,
             placeholder: str = "") -> str:
    return (f'<label class="field" for="f-{e(name)}"><span class="lbl">{e(label)}</span>'
            f'<textarea id="f-{e(name)}" name="{e(name)}" rows="{rows}" maxlength="{maxlength}"{attrs(required=required, placeholder=placeholder or None)}>'
            f'{e(value)}</textarea>{f"<span class=hint>{e(hint)}</span>" if hint else ""}</label>')


def select(label: str, name: str, options: Iterable[tuple[Any, str]], selected: Any = "", *, hint: str = "", required: bool = False,
           auto_submit: bool = False) -> str:
    opts = "".join(f'<option value="{e(v)}"{" selected" if str(v) == str(selected) else ""}>{e(t)}</option>' for v, t in options)
    return (f'<label class="field" for="f-{e(name)}"><span class="lbl">{e(label)}</span>'
            f'<select id="f-{e(name)}" name="{e(name)}"{attrs(required=required, data_auto_submit=auto_submit or None)}>{opts}</select>'
            f'{f"<span class=hint>{e(hint)}</span>" if hint else ""}</label>')


def checkbox(label: str, name: str, checked: bool = False, *, value: str = "1", hint: str = "") -> str:
    return (f'<label class="check"><input type="checkbox" name="{e(name)}" value="{e(value)}"{" checked" if checked else ""}>'
            f'<span>{e(label)}{f"<small>{e(hint)}</small>" if hint else ""}</span></label>')


def notice_box(text: str, tone: str = "info", title: str = "") -> str:
    t = f"<strong>{e(title)}</strong> " if title else ""
    return f'<div class="note {TONES.get(tone, "info")}" role="status">{t}{e(text)}</div>'


# --------------------------------------------------------------------------------------------- flash messages
def flash_redirect(url: str, kind: str, text: str, status: int = 303) -> Response:
    r = redirect(url, status)
    r.cookie("mj_f", json.dumps({"k": kind, "t": text}, ensure_ascii=False), max_age=60, secure=False)
    return r


def _flash_html(req: Request) -> tuple[str, bool]:
    raw = req.cookies.get("mj_f")
    if not raw:
        return "", False
    try:
        d = json.loads(raw)
        kind = {"ok": "ok", "err": "bad", "warn": "warn"}.get(d.get("k"), "info")
        return f'<div class="flash {kind}" role="status">{e(str(d.get("t", ""))[:300])}</div>', True
    except ValueError:
        return "", True


# --------------------------------------------------------------------------------------------- the page shell
def manager_nav(ctx: Any) -> list[tuple[str, str, str, str]]:
    items = [("dash", "/m", "المراقبة", "chart")]
    if ctx.can("leads.view"):
        items.append(("leads", "/m/leads", "العملاء", "list"))
    if ctx.can("leads.import"):
        items.append(("import", "/m/import", "الاستيراد", "upload"))
    if ctx.can("leads.assign"):
        items.append(("dist", "/m/distribute", "التوزيع", "users"))
    if ctx.can("employees.manage"):
        items.append(("emps", "/m/employees", "الموظفون", "user"))
    if ctx.can("reports.view"):
        items.append(("reports", "/m/reports", "التقارير", "flag"))
    if ctx.can("compare.manage"):
        items.append(("compare", "/m/compare", "المقارنة", "target"))
    if ctx.can("settings.manage"):
        items.append(("settings", "/m/settings", "الإعدادات", "settings"))
    return items


def manager_more(ctx: Any) -> list[tuple[str, str, str]]:
    items = []
    if ctx.can("devices.manage"):
        items.append(("devices", "/m/devices", "الأجهزة"))
    if ctx.can("log.view"):
        items.append(("log", "/m/log", "سجل العمليات"))
    if ctx.can("backup.download"):
        items.append(("export", "/m/export", "تصدير البيانات"))
    if ctx.user.get("is_platform_admin"):
        items.append(("backups", "/m/backups", "النسخ الاحتياطية"))
    if ctx.can("managers.manage"):
        items.append(("team", "/m/team", "المدراء والصلاحيات"))
    if ctx.user.get("is_platform_admin"):
        items.append(("platform", "/p", "إدارة المنصة"))
    items.append(("privacy", "/privacy", "الخصوصية وما يُسجَّل"))
    return items


EMP_NAV = [("home", "/w", "اليوم", "home"), ("tasks", "/w/tasks", "المهام", "list"), ("search", "/w/search", "بحث", "search"),
           ("me", "/w/me", "حسابي", "user")]


def page(req: Request, title: str, body: str, *, active: str = "", wide: bool = False, head: str = "", refresh: int = 0,
         status: int = 200, hide_nav: bool = False, back: str = "") -> Response:
    ctx = req.ctx
    flash, had_flash = _flash_html(req)
    role = ctx.role if ctx else "guest"
    top_right = ""
    nav = ""
    if ctx:
        company = e(ctx.company["name"])
        menu = (f'<form method="post" action="/logout" class="inline">{csrf_input(req)}'
                f'<button class="btn ghost sm" type="submit">{icon("logout")}<span>خروج</span></button></form>')
        top_right = f'<div class="who"><span class="who-n">{e(ctx.user["name"])}</span><span class="who-c">{company}</span></div>{menu}'
        if ctx.is_manager and not hide_nav:
            tabs = "".join(f'<a class="tab{" on" if k == active else ""}" href="{h}">{icon(ic)}<span>{t}</span></a>'
                           for k, h, t, ic in manager_nav(ctx))
            more_items = manager_more(ctx)
            more = "".join(f'<a href="{h}"{" class=on" if k == active else ""}>{t}</a>' for k, h, t in more_items)
            tabs += f'<details class="more"><summary class="tab">{icon("menu")}<span>المزيد</span></summary><div class="more-m">{more}</div></details>'
            nav = f'<nav class="tabs" aria-label="التنقل">{tabs}</nav>'
        elif not ctx.is_manager and not hide_nav:
            tabs = "".join(f'<a class="bt{" on" if k == active else ""}" href="{h}">{icon(ic)}<span>{t}</span></a>' for k, h, t, ic in EMP_NAV)
            nav = f'<nav class="bottom" aria-label="التنقل">{tabs}</nav>'
    backlink = f'<a class="back" href="{e(back)}" aria-label="رجوع">{icon("back")}</a>' if back else ""
    wrap = "wrap wide" if wide else "wrap"
    ping = ' data-ping="/w/ping"' if ctx and not ctx.is_manager else ""
    refresh_attr = f' data-refresh="{refresh}"' if refresh else ""
    doc = (
        '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">'
        '<meta name="theme-color" content="#1c4fd8"><meta name="color-scheme" content="light dark">'
        '<meta name="robots" content="noindex,nofollow"><meta name="format-detection" content="telephone=no">'
        f'<title>{e(title)} — {BRAND}</title><link rel="manifest" href="/manifest.webmanifest">'
        f'<link rel="icon" href="/static/icon.svg?v={VER}" type="image/svg+xml"><link rel="apple-touch-icon" href="/static/icon-192.png?v={VER}">'
        f'<link rel="stylesheet" href="/static/app.css?v={VER}">{head}</head>'
        f'<body class="role-{role}{" has-bottom" if role == "employee" and nav else ""}"{ping}{refresh_attr}>'
        f'<header class="top"><div class="top-in">{backlink}<a class="brand" href="/"><img src="/static/icon.svg?v={VER}" alt="" width="28" height="28">'
        f'<span>{BRAND}</span></a><span class="grow"></span>{top_right}</div></header>{nav if role != "employee" else ""}'
        f'<main class="{wrap}">{flash}{body}</main>{nav if role == "employee" else ""}'
        f'<script src="/static/app.js?v={VER}" defer></script></body></html>')
    resp = html_response(doc, status)
    if had_flash:
        resp.drop_cookie("mj_f", secure=False)
    return resp


def error_page(req: Request, status: int, title: str, text: str) -> Response:
    home = "/" if req.ctx else "/login"
    body = card(f'<div class="empty"><h2>{e(title)}</h2><p>{e(text)}</p>{button("العودة للرئيسية", href=home, kind="primary")}</div>')
    return page(req, title, body, status=status, hide_nav=True)
