"""The daily plan: which clients an employee should reach today, in what order, and how many fit in the day."""
from __future__ import annotations

import sqlite3
from typing import Any

from . import consts, db, leads as leadlib, util

KIND_RANK = {k: i for i, (k, _) in enumerate(consts.TASK_KINDS)}


def capacity(s: dict, user: Any) -> int:
    hours = user["shift_hours"] or s["shift_hours"]
    return max(1, int(float(hours) * 60 // max(0.5, float(s["minutes_per_call"]))))


def daily_new_for(s: dict, user: Any) -> int:
    v = user["daily_new"]
    return int(v) if v is not None else int(s["daily_new"])


def due_followups(c: sqlite3.Connection, company_id: int, user_id: int, today: str) -> list[dict]:
    marks = ",".join("?" * len(leadlib.FOLLOW_STATUSES))
    rows = c.execute(
        f"SELECT id, status, next_follow_up, next_follow_time FROM leads WHERE company_id=? AND owner_id=? AND do_not_call=0 "
        f"AND status IN ({marks}) AND next_follow_up IS NOT NULL AND next_follow_up<=?",
        (company_id, user_id, *leadlib.FOLLOW_STATUSES, today)).fetchall()
    out = []
    for r in rows:
        due = r["next_follow_up"]
        if due < today:
            kind = "overdue"
        elif r["status"] == "callback":
            kind = "callback"
        elif r["status"] == "interested":
            kind = "interested"
        elif r["status"] in ("link_sent", "visited"):
            kind = "link_check"
        else:
            kind = "followup"
        out.append({"id": r["id"], "kind": kind, "due": due, "time": r["next_follow_time"] or "99:99"})
    out.sort(key=lambda d: (KIND_RANK[d["kind"]], d["due"], d["time"], d["id"]))
    return out


def own_new(c: sqlite3.Connection, company_id: int, user_id: int, n: int, allow_landline: bool, exclude: set[int] | None = None) -> list[int]:
    if n <= 0:
        return []
    extra = "" if allow_landline else " AND line_type='mobile'"
    rows = c.execute(f"SELECT id FROM leads WHERE company_id=? AND owner_id=? AND status='new' AND do_not_call=0{extra} ORDER BY id LIMIT ?",
                     (company_id, user_id, n + len(exclude or ()))).fetchall()
    ids = [r["id"] for r in rows if r["id"] not in (exclude or set())]
    return ids[:n]


def pull_pool(c: sqlite3.Connection, company_id: int, user_id: int, n: int, allow_landline: bool) -> list[int]:
    """Takes up to n unassigned numbers for this employee. Runs inside the caller's write transaction, so two employees never get the same one."""
    if n <= 0:
        return []
    rows = c.execute(f"SELECT id FROM leads WHERE company_id=? AND {leadlib.pool_where(allow_landline)} ORDER BY id LIMIT ?",
                     (company_id, n)).fetchall()
    ids = [r["id"] for r in rows]
    if ids:
        leadlib.assign(c, company_id, ids, user_id, None, "daily_pull")
    return ids


def _insert_tasks(c: sqlite3.Connection, plan_id: int, user: Any, plan_date: str, items: list[tuple[int, str, str | None]], start_pos: int) -> int:
    now = util.now_iso()
    pos = start_pos
    for lead_id, kind, due in items:
        pos += 1
        c.execute("INSERT INTO tasks(plan_id,company_id,user_id,lead_id,kind,position,created_at,due_date,plan_date) VALUES(?,?,?,?,?,?,?,?,?)",
                  (plan_id, user["company_id"], user["id"], lead_id, kind, pos, now, due, plan_date))
    return pos


def build_plan(c: sqlite3.Connection, user: Any, shift_id: int, s: dict, today: str) -> dict:
    cid, uid = user["company_id"], user["id"]
    cap = capacity(s, user)
    fu = due_followups(c, cid, uid, today)
    target = daily_new_for(s, user)
    room = max(0, cap - len(fu))
    new_n = min(target, room)
    trimmed = new_n < target
    allow = bool(s["allow_landline"])
    mine = own_new(c, cid, uid, new_n, allow)
    pulled = pull_pool(c, cid, uid, new_n - len(mine), allow)
    short = max(0, new_n - len(mine) - len(pulled))
    cur = c.execute("INSERT INTO daily_plans(company_id,user_id,shift_id,plan_date,created_at,capacity,new_target,new_given,followups,trimmed,pool_short)"
                    " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                    (cid, uid, shift_id, today, util.now_iso(), cap, target, len(mine) + len(pulled), len(fu), int(trimmed), short))
    plan_id = int(cur.lastrowid)
    items = [(d["id"], d["kind"], d["due"]) for d in fu] + [(i, "new", None) for i in mine + pulled]
    _insert_tasks(c, plan_id, user, today, items, 0)
    db.emit(c, cid, "plan.created", actor=uid, user=uid, shift=shift_id, ref=plan_id,
            data={"capacity": cap, "followups": len(fu), "new_target": target, "new_given": len(mine) + len(pulled), "trimmed": trimmed,
                  "pool_short": short})
    if trimmed:
        db.notice(c, cid, "plan_trimmed", f"خطة {user['name']} لا تتسع لكل الأرقام الجديدة: المتابعات {len(fu)} من سعة {cap}", uid, today)
    if short:
        db.notice(c, cid, "pool_short", f"نقص {short} رقمًا جديدًا في خطة {user['name']}: قائمة الأرقام غير الموزعة انتهت. استورد ملفًا جديدًا.", uid, today)
    return {"plan_id": plan_id, "capacity": cap, "followups": len(fu), "new": len(mine) + len(pulled), "trimmed": trimmed, "short": short}


def plan_for(c: sqlite3.Connection, user_id: int, plan_date: str) -> sqlite3.Row | None:
    return db.one(c, "SELECT * FROM daily_plans WHERE user_id=? AND plan_date=?", user_id, plan_date)


def progress(c: sqlite3.Connection, plan_id: int) -> dict:
    rows = c.execute("SELECT kind, status, COUNT(*) n FROM tasks WHERE plan_id=? GROUP BY kind, status", (plan_id,)).fetchall()
    by_kind: dict[str, dict[str, int]] = {}
    total = done = reason = open_ = 0
    for r in rows:
        k = by_kind.setdefault(r["kind"], {"total": 0, "open": 0, "done": 0, "reason": 0})
        k["total"] += r["n"]
        k[r["status"]] += r["n"]
        total += r["n"]
        if r["status"] == "done":
            done += r["n"]
        elif r["status"] == "reason":
            reason += r["n"]
        else:
            open_ += r["n"]
    return {"total": total, "done": done, "reason": reason, "open": open_, "by_kind": by_kind}


def tasks_for(c: sqlite3.Connection, plan_id: int, kind: str = "", status: str = "") -> list[sqlite3.Row]:
    sql = ("SELECT t.*, l.name, l.phone, l.city, l.status AS lead_status, l.next_follow_time, l.attempts, l.note_last, a.outcome AS outcome "
           "FROM tasks t JOIN leads l ON l.id=t.lead_id LEFT JOIN call_attempts a ON a.id=t.attempt_id WHERE t.plan_id=?")
    args: list[Any] = [plan_id]
    if kind:
        sql += " AND t.kind=?"
        args.append(kind)
    if status:
        sql += " AND t.status=?"
        args.append(status)
    sql += " ORDER BY CASE t.status WHEN 'open' THEN 0 ELSE 1 END, t.position"
    return c.execute(sql, args).fetchall()


def next_task(c: sqlite3.Connection, plan_id: int, skip_lead: int | None = None) -> sqlite3.Row | None:
    return db.one(c, "SELECT * FROM tasks WHERE plan_id=? AND status='open' AND lead_id IS NOT ? ORDER BY position LIMIT 1", plan_id, skip_lead)


def open_task_for_lead(c: sqlite3.Connection, plan_id: int, lead_id: int) -> sqlite3.Row | None:
    return db.one(c, "SELECT * FROM tasks WHERE plan_id=? AND lead_id=? AND status='open' ORDER BY id LIMIT 1", plan_id, lead_id)


def add_callback_task(c: sqlite3.Connection, plan: sqlite3.Row, user: Any, lead_id: int, due: str) -> None:
    if open_task_for_lead(c, plan["id"], lead_id):
        return
    pos = db.scalar(c, "SELECT MAX(position) FROM tasks WHERE plan_id=?", plan["id"], default=0)
    _insert_tasks(c, plan["id"], user, plan["plan_date"], [(lead_id, "callback", due)], pos)


def add_more(c: sqlite3.Connection, user: Any, plan: sqlite3.Row, s: dict, chunk: int = 20) -> int:
    """For an employee who finished early: more new numbers, never beyond what the day's minutes can hold."""
    prog = progress(c, plan["id"])
    if prog["open"] > 0:
        return 0
    room = max(0, plan["capacity"] - prog["total"])
    n = min(chunk, room)
    if n <= 0:
        return 0
    allow = bool(s["allow_landline"])
    taken = {r["lead_id"] for r in c.execute("SELECT lead_id FROM tasks WHERE plan_id=?", (plan["id"],))}
    mine = own_new(c, user["company_id"], user["id"], n, allow, exclude=taken)
    pulled = pull_pool(c, user["company_id"], user["id"], n - len(mine), allow)
    ids = mine + pulled
    if not ids:
        return 0
    pos = db.scalar(c, "SELECT MAX(position) FROM tasks WHERE plan_id=?", plan["id"], default=0)
    _insert_tasks(c, plan["id"], user, plan["plan_date"], [(i, "new", None) for i in ids], pos)
    c.execute("UPDATE daily_plans SET new_given=new_given+? WHERE id=?", (len(ids), plan["id"]))
    db.emit(c, user["company_id"], "plan.extended", actor=user["id"], user=user["id"], ref=plan["id"], data={"added": len(ids)})
    return len(ids)
