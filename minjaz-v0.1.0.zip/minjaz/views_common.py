"""Pieces shared by the employee and manager screens."""
from __future__ import annotations

import sqlite3
from typing import Any

from . import config, consts, db, ui, util
from .ui import badge, bar, card, e, num, table
from .web import Request


def site_url(req: Request) -> str:
    if config.SITE_URL:
        return config.SITE_URL
    scheme = "https" if req.is_https or config.COOKIE_SECURE else "http"
    return f"{scheme}://{req.host}"


def outcome_labels(c: sqlite3.Connection, company_id: int) -> dict[str, str]:
    return {r["code"]: r["label"] for r in c.execute("SELECT code, label FROM outcome_types WHERE company_id=? ORDER BY sort", (company_id,))}


def reason_labels(c: sqlite3.Connection, company_id: int) -> dict[str, str]:
    return {r["code"]: r["label"] for r in c.execute("SELECT code, label FROM reasons WHERE company_id=?", (company_id,))}


def score_cls(score: int | None) -> str:
    if score is None:
        return ""
    return "hi" if score >= 75 else "mid" if score >= 50 else "lo"


def score_badge(score: int | None) -> str:
    return f'<span class="score {score_cls(score)}">{score if score is not None else "—"}</span>'


def kind_label(kind: str) -> str:
    return consts.TASK_KIND_LABELS.get(kind, kind)


def evidence_badge(level: int) -> str:
    label = consts.EVIDENCE.get(level, ("", ""))[0]
    return badge(label, {0: "muted", 1: "info", 2: "ok", 3: "ok"}.get(level, ""))


def flag_badges(flags: list[dict]) -> str:
    if not flags:
        return '<span class="muted">لا إشارات</span>'
    return '<div class="flags">' + "".join(
        f'<span class="badge {"warn" if f["tone"] == "warn" else "info"}" title="{e(f["detail"])}">{e(f["label"])}</span>' for f in flags) + "</div>"


def render_day_report(m: dict, labels: dict[str, str], tz: str, *, show_flags: bool = True, who: str = "") -> str:
    sh = m.get("shift")
    if not sh:
        return card(ui.empty("لا يوجد يوم عمل في هذا التاريخ"), title=ui.fmt_day(m["day"]))
    t, calls, g = m["tasks"], m["calls"], m["gaps"]
    r = m.get("rating")
    head = ""
    if r:
        parts = [("تنفيذ الخطة", "exec"), ("النتائج", "results"), ("الجودة", "quality"), ("الانضباط", "discipline")]
        bars = "".join(f'<div class="row between"><span>{lbl} <span class="muted">({r["weights"][k]}%)</span></span><b>{r["parts"][k]}%</b></div>'
                       f'{bar(r["parts"][k], 100, "ok" if r["parts"][k] >= 70 else "warn" if r["parts"][k] >= 40 else "bad")}' for lbl, k in parts)
        label = f"التقييم {r['score']} من 100"
        head = f'<div class="hero">{ui.ring(r["score"], 100, label)}<div style="flex:1">{bars}</div></div>'
    status = {"open": "مفتوح", "closed": "أُنهي", "auto_closed": "أُغلق تلقائيًا"}.get(sh["status"], sh["status"])
    kv = (f'<dl class="kv"><dt>الحالة</dt><dd>{e(status)}</dd><dt>بدأ</dt><dd>{e(ui.fmt_time(sh["started_at"], tz))}</dd>'
          f'<dt>انتهى</dt><dd>{e(ui.fmt_time(sh["ended_at"], tz) or "—")}</dd><dt>مدة العمل</dt><dd>{e(util.fmt_duration(sh["work_seconds"]))}</dd>'
          f'<dt>الاستراحات</dt><dd>{e(util.fmt_duration(sh["break_seconds"]) or "0")}</dd>'
          f'<dt>الفترات الصامتة</dt><dd>{g["count"]} ({g["explained"]} موضَّحة{f"، {g["pending"]} بلا توضيح" if g["pending"] else ""})</dd></dl>')
    plan = m.get("plan")
    plan_txt = ""
    if plan:
        plan_txt = (f'<p class="sub">سعة اليوم {plan["capacity"]} مكالمة · متابعات {plan["followups"]} · أرقام جديدة {plan["new_given"]} من {plan["new_target"]}'
                    f'{" · قُلّصت الأرقام الجديدة لضيق الوقت" if plan["trimmed"] else ""}{f" · نقص {plan["pool_short"]} رقمًا في المخزون" if plan["pool_short"] else ""}</p>')
    stats = '<div class="grid">' + "".join([
        ui.stat("مهام منجزة", f'{t["done"]} / {t["total"]}'),
        ui.stat("مكالمات مسجَّلة", calls["total"]), ui.stat("ردّ العميل", calls["answered"], sub=ui.pct(calls["answered"], calls["total"]) if calls["total"] else ""),
        ui.stat("مهتمون", m["interested"], tone="ok" if m["interested"] else ""),
        ui.stat("روابط أُرسلت", m["links"]["sent"]), ui.stat("روابط فُتحت", m["links"]["opened"]),
        ui.stat("تسجيلات مُبلَّغة", m["registered"]["reported"], tone="ok" if m["registered"]["reported"] else ""),
        ui.stat("تسجيلات مؤكدة", m["registered"]["confirmed"], tone="ok" if m["registered"]["confirmed"] else "")]) + "</div>"
    out_rows = [[e(labels.get(k, k)), str(v), ui.pct(v, calls["total"])] for k, v in sorted(calls["outcomes"].items(), key=lambda kv: -kv[1])]
    out_tbl = table(["النتيجة", "العدد", "النسبة"], out_rows, empty_text="لا مكالمات مسجَّلة")
    ev = calls["evidence"]
    ev_txt = " · ".join(f'{consts.EVIDENCE[k][0]}: {ev.get(k, 0)}' for k in (0, 1, 2, 3) if ev.get(k, 0))
    flags_html = ""
    if show_flags:
        flags_html = card(flag_badges(m.get("flags", [])) + ("".join(f'<p class="sub mt">{e(f["label"])}: {e(f["detail"])}</p>' for f in m.get("flags", []))),
                          title="إشارات للمراجعة", sub="تصف ما في السجل، وليست حكمًا على السبب")
    return (card(head + kv + plan_txt, title=f"{who + ' · ' if who else ''}{ui.fmt_day(m['day'])}") + stats
            + card(out_tbl + (f'<p class="sub mt">درجة الثقة في المكالمات: {e(ev_txt)}</p>' if ev_txt else ""), title="نتائج المكالمات") + flags_html)


# ------------------------------------------------------------------------------------------------ describing events in plain Arabic
EVENT_LABELS = {
    "auth.login": "دخول", "auth.logout": "خروج", "auth.login_failed": "محاولة دخول فاشلة", "auth.locked": "إيقاف الدخول مؤقتًا",
    "auth.password_changed": "تغيير كلمة المرور",
    "shift.started": "بدأ يوم العمل", "shift.closed": "أنهى يوم العمل", "shift.break_started": "بدأ استراحة", "shift.break_ended": "أنهى الاستراحة",
    "shift.reopened": "أُعيد فتح اليوم", "gap.detected": "فترة صامتة", "gap.explained": "توضيح فترة صامتة",
    "plan.created": "أُنشئت خطة اليوم", "plan.extended": "أرقام إضافية للخطة",
    "call.started": "ضغط «اتصال»", "call.recorded": "سجّل نتيجة مكالمة", "call.corrected": "تصحيح نتيجة", "task.skipped": "أجّل عميلًا",
    "link.sent": "أرسل رابط المنصة", "link.opened": "العميل فتح الرابط",
    "lead.assigned": "توزيع عملاء", "lead.dnc": "طلب عدم الاتصال", "lead.exhausted": "توقفت المحاولات", "lead.confirmed": "تسجيل مؤكد",
    "lead.reopened": "إعادة فتح عميل", "lead.added": "إضافة عميل",
    "import.committed": "اعتماد استيراد ملف", "report.sealed": "ختم تقرير يومي", "settings.changed": "تغيير إعدادات",
    "user.created": "إنشاء مستخدم", "user.updated": "تعديل مستخدم", "user.password_reset": "إعادة تعيين كلمة مرور", "user.deactivated": "إيقاف مستخدم",
    "user.activated": "تفعيل مستخدم", "device.enroll_code": "رمز ربط جهاز", "device.enrolled": "ربط جهاز", "device.revoked": "إلغاء جهاز",
    "device.call_matched": "مطابقة مكالمة بسجل الجهاز", "compare.imported": "مطابقة مع المنصة", "compare.daily": "أرقام المنصة اليومية",
    "export.data": "تصدير بيانات", "backup.made": "نسخة احتياطية", "backup.tested": "اختبار استرجاع", "notice.seen": "إخفاء تنبيه",
    "admin.setup": "إعداد الحساب الأول", "admin.company_created": "إنشاء شركة", "admin.company_registered": "تسجيل شركة",
    "admin.registration_toggled": "فتح/غلق التسجيل", "admin.company_active": "تفعيل/إيقاف شركة",
    "compare.linked": "ربط يدوي بعميل",
}


def describe_event(ev: sqlite3.Row, olabels: dict[str, str], rlabels: dict[str, str]) -> str:
    d = db.jload(ev["data"], {}) or {}
    t = ev["type"]
    if t == "call.recorded":
        txt = olabels.get(d.get("outcome"), d.get("outcome", ""))
        if d.get("note"):
            txt += f" — {d['note']}"
        if d.get("followup_date"):
            txt += f" (معاودة {d['followup_date']} {d.get('followup_time') or ''})"
        return txt
    if t == "call.corrected":
        return f"{olabels.get(d.get('old'), d.get('old', ''))} ← {olabels.get(d.get('new'), d.get('new', ''))}: {d.get('reason', '')}"
    if t == "gap.explained":
        return dict(consts.GAP_REASONS).get(d.get("reason"), d.get("reason", "")) + (f" — {d['text']}" if d.get("text") else "")
    if t == "gap.detected":
        return f"{d.get('minutes')} دقيقة ({'خارج التطبيق' if d.get('kind') == 'away' else 'داخل التطبيق'})"
    if t == "shift.closed":
        return ("إغلاق تلقائي، " if d.get("auto") else "") + f"مهام بلا نتيجة: {d.get('open_tasks', 0)}" + (f" — {d['note']}" if d.get("note") else "")
    if t == "shift.started" and d.get("late_minutes"):
        return f"تأخر {d['late_minutes']} دقيقة"
    if t == "plan.created":
        return (f"متابعات {d.get('followups')}، جديد {d.get('new_given')} من {d.get('new_target')}، السعة {d.get('capacity')}"
                + ("، قُلّص الجديد" if d.get("trimmed") else "") + (f"، نقص {d['pool_short']} في المخزون" if d.get("pool_short") else ""))
    if t == "lead.assigned":
        return f"{d.get('count')} عميلًا ({ {'daily_pull': 'سحب يومي', 'manual': 'يدوي', 'employee_left': 'مغادرة موظف', 'import_column': 'من عمود الملف'}.get(d.get('reason'), d.get('reason', '')) })"
    if t == "import.committed":
        return f"{d.get('file', '')}: أُضيف {d.get('added')}، مكرر {d.get('dup_db', 0) + d.get('dup_file', 0)}، غير صالح {d.get('invalid', 0)}"
    if t == "report.sealed":
        return f"{d.get('day')} (نسخة {d.get('version')})"
    if t == "settings.changed":
        return "، ".join(d.get("keys", []))[:200]
    if t in ("link.sent",):
        return "واتساب"
    if t == "lead.confirmed":
        how = {"ours": "يُحسب للموظف", "late_approved": "تسجيل متأخر اعتمده المدير", "linked": "ربطه المدير يدويًا بالعميل"}.get(d.get("verdict"), d.get("verdict", ""))
        return how + (f" — سجّل في استراحتي {d['reg_date']}" if d.get("reg_date") else "")
    if t == "compare.imported":
        return f"{d.get('rows', 0)} صفًا، طابق {d.get('matched', 0)} عميلًا، ونُسب {d.get('attributed', 0)} للفريق"
    if t == "compare.daily":
        return d.get("day", "")
    if t == "compare.linked":
        return d.get("phone", "")
    if t == "device.call_matched":
        return f"مكالمة {util.fmt_call_duration(d.get('seconds'))} على جهاز العمل"
    if t in ("device.enrolled", "device.revoked"):
        return d.get("name", "")
    if t in ("user.created", "user.updated", "user.deactivated", "user.activated", "user.password_reset"):
        return d.get("name", "") or d.get("username", "")
    if t == "export.data":
        return f"{d.get('what', '')} ({d.get('rows', 0)} صف)"
    return ""
