"""Time, text and small helpers. No project-specific rules live here."""
from __future__ import annotations

import datetime as dt
import hashlib
import html
import json
import re
import secrets
from typing import Any

UTC = dt.timezone.utc
_FROZEN: dt.datetime | None = None  # tests set this to control the clock


def freeze(t: dt.datetime | None) -> None:
    global _FROZEN
    _FROZEN = t


def now() -> dt.datetime:
    return _FROZEN if _FROZEN is not None else dt.datetime.now(UTC)


def iso(t: dt.datetime) -> str:
    t = t.astimezone(UTC)
    return t.strftime("%Y-%m-%dT%H:%M:%S.") + f"{t.microsecond // 1000:03d}Z"


def now_iso() -> str:
    return iso(now())


def parse_iso(s: str) -> dt.datetime:
    s = s.strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    t = dt.datetime.fromisoformat(s)
    return t if t.tzinfo else t.replace(tzinfo=UTC)


_FIXED = {"Asia/Riyadh": 180, "Asia/Kuwait": 180, "Asia/Qatar": 180, "Asia/Baghdad": 180, "Asia/Dubai": 240, "Asia/Bahrain": 180,
          "UTC": 0, "Africa/Cairo": 120, "Asia/Amman": 180}


def tzinfo_for(name: str) -> dt.tzinfo:
    """Saudi Arabia has no daylight saving, so a fixed offset is a safe fallback when the system has no tz database."""
    try:
        from zoneinfo import ZoneInfo

        return ZoneInfo(name)
    except Exception:
        return dt.timezone(dt.timedelta(minutes=_FIXED.get(name, 180)), name)


def tz_known(name: str) -> bool:
    """True for a name the system knows, or (when the system has no tz database) for one of the few fixed-offset fallbacks above."""
    try:
        from zoneinfo import ZoneInfo

        ZoneInfo(name)
        return True
    except Exception:
        return name in _FIXED


def local_dt(t: dt.datetime | str, tzname: str) -> dt.datetime:
    if isinstance(t, str):
        t = parse_iso(t)
    return t.astimezone(tzinfo_for(tzname))


def local_date(t: dt.datetime | str, tzname: str) -> str:
    return local_dt(t, tzname).strftime("%Y-%m-%d")


def local_hm(t: dt.datetime | str | None, tzname: str) -> str:
    if not t:
        return ""
    return local_dt(t, tzname).strftime("%H:%M")


def add_days(day: str, n: int) -> str:
    return (dt.date.fromisoformat(day) + dt.timedelta(days=n)).isoformat()


def days_between(a: str, b: str) -> int:
    return (dt.date.fromisoformat(b) - dt.date.fromisoformat(a)).days


def local_to_utc(day: str, hm: str, tzname: str) -> dt.datetime:
    h, m = (int(x) for x in hm.split(":"))
    d = dt.datetime.fromisoformat(day).replace(hour=h, minute=m, tzinfo=tzinfo_for(tzname))
    return d.astimezone(UTC)


_AR_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


def ascii_digits(s: str) -> str:
    return s.translate(_AR_DIGITS)


_DIACRITICS = re.compile("[ً-ٰٟـ]")


def norm_text(s: str) -> str:
    """For comparing names and cities: no diacritics, one kind of alef/ya/ta marbuta, no spacing noise."""
    s = _DIACRITICS.sub("", ascii_digits(s or "")).lower()
    s = s.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا").replace("ى", "ي").replace("ة", "ه")
    return re.sub(r"[\s‎‏\-_.,،:؛]+", " ", s).strip()


def canon(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def sha256(data: str | bytes) -> str:
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def token(n: int = 32) -> str:
    return secrets.token_urlsafe(n)


def esc(v: Any) -> str:
    return html.escape("" if v is None else str(v), quote=True)


def short_token(n: int = 8) -> str:
    alphabet = "abcdefghijkmnpqrstuvwxyz23456789"  # no look-alike letters
    return "".join(secrets.choice(alphabet) for _ in range(n))


def fmt_duration(seconds: float | int | None) -> str:
    if seconds is None:
        return ""
    seconds = int(max(0, seconds))
    h, rem = divmod(seconds, 3600)
    m = rem // 60
    if h:
        return f"{h}:{m:02d} ساعة" if m else f"{h} ساعة"
    if m:
        return f"{m} دقيقة"
    return f"{seconds} ث"


def fmt_call_duration(seconds: int | None) -> str:
    if seconds is None:
        return ""
    m, s = divmod(int(seconds), 60)
    if m:
        return f"{m} د {s} ث" if s else f"{m} د"
    return f"{s} ث"


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def to_int(v: Any, default: int | None = None) -> int | None:
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        return default


def to_float(v: Any, default: float | None = None) -> float | None:
    try:
        return float(ascii_digits(str(v)).strip().replace(",", "."))
    except (TypeError, ValueError):
        return default
