/* مِنجَز — سلوك بسيط فوق صفحات تعمل بدونه. لا مكتبات خارجية. */
(function () {
  'use strict';
  var doc = document;
  var csrf = (doc.querySelector('input[name="_csrf"]') || {}).value || '';

  // 1) زر الاتصال: يفتح المتصل فورًا ويسجّل بدء المكالمة في الخلفية
  doc.addEventListener('click', function (ev) {
    var a = ev.target.closest('[data-beacon]');
    if (!a) return;
    var url = a.getAttribute('data-beacon');
    var fd = new FormData();
    fd.append('_csrf', csrf);
    var sent = false;
    try { sent = navigator.sendBeacon(url, fd); } catch (e) { sent = false; }
    if (!sent) { try { fetch(url, { method: 'POST', body: fd, keepalive: true, credentials: 'same-origin' }); } catch (e) { /* يبقى الرابط يعمل */ } }
    var panel = doc.getElementById('outcome-panel');
    if (panel) { panel.classList.add('called'); setTimeout(function () { panel.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 600); }
    var flag = doc.getElementById('call-started');
    if (flag) flag.classList.remove('hidden');
  });

  // 2) نموذج النتيجة: يُظهر الحقول المطلوبة حسب الخيار ويمنع الإرسال المزدوج
  var oform = doc.getElementById('outcome-form');
  if (oform) {
    var noteBox = oform.querySelector('[data-note-box]');
    var dtBox = oform.querySelector('[data-dt-box]');
    var noteLbl = oform.querySelector('[data-note-label]');
    var save = oform.querySelector('[data-save]');
    var sync = function () {
      var picked = oform.querySelector('input[name="outcome"]:checked');
      if (save) save.disabled = !picked;
      if (!picked) { if (noteBox) noteBox.classList.add('hidden'); if (dtBox) dtBox.classList.add('hidden'); return; }
      var needsNote = picked.getAttribute('data-note') === '1';
      var needsDt = picked.getAttribute('data-dt') === '1';
      if (noteBox) noteBox.classList.remove('hidden');
      if (noteLbl) noteLbl.textContent = needsNote ? 'ملاحظة (مطلوبة)' : 'ملاحظة (اختيارية)';
      var ta = noteBox && noteBox.querySelector('textarea');
      if (ta) ta.required = needsNote;
      if (dtBox) {
        dtBox.classList.toggle('hidden', !needsDt);
        dtBox.querySelectorAll('input').forEach(function (i) { i.required = needsDt; });
      }
    };
    oform.addEventListener('change', sync);
    sync();
    oform.addEventListener('submit', function () { if (save) { save.disabled = true; save.classList.add('off'); } });
  }

  // 3) تأكيد الإجراءات الحساسة
  doc.addEventListener('submit', function (ev) {
    var f = ev.target;
    var msg = f.getAttribute && f.getAttribute('data-confirm');
    if (msg && !window.confirm(msg)) { ev.preventDefault(); return; }
    var btn = ev.submitter;
    if (btn && btn.getAttribute('data-confirm') && !window.confirm(btn.getAttribute('data-confirm'))) { ev.preventDefault(); return; }
    f.querySelectorAll('button[type=submit]:not([data-keep])').forEach(function (b) { setTimeout(function () { b.disabled = true; }, 0); });
  });
  window.addEventListener('pageshow', function (e) { if (e.persisted) doc.querySelectorAll('button[disabled]').forEach(function (b) { b.disabled = false; }); });

  // 4) إرسال نموذج التصفية عند تغيير القائمة
  doc.addEventListener('change', function (ev) {
    var s = ev.target;
    if (s.matches && s.matches('[data-auto-submit]') && s.form) s.form.submit();
    if (s.matches && s.matches('[data-select-all]')) {
      var sel = s.getAttribute('data-select-all');
      doc.querySelectorAll(sel).forEach(function (c) { c.checked = s.checked; });
    }
  });

  // 5) نبض الحضور للموظف: يخبر الخادم أن الصفحة مفتوحة وظاهرة
  if (doc.body.hasAttribute('data-ping')) {
    var pingUrl = doc.body.getAttribute('data-ping');
    var ping = function () {
      if (doc.visibilityState !== 'visible') return;
      var fd = new FormData(); fd.append('_csrf', csrf);
      try { fetch(pingUrl, { method: 'POST', body: fd, credentials: 'same-origin', keepalive: true }).then(function (r) {
        if (r.ok) return r.json(); return null; }).then(function (j) { if (j && j.gap) { location.href = '/w/gap'; } }).catch(function () {}); } catch (e) {}
    };
    setInterval(ping, 60000);
    doc.addEventListener('visibilitychange', function () { if (doc.visibilityState === 'visible') ping(); });
  }

  // 6) تحديث تلقائي للوحة المراقبة
  var r = parseInt(doc.body.getAttribute('data-refresh') || '0', 10);
  if (r > 0) {
    setInterval(function () {
      if (doc.visibilityState !== 'visible') return;
      if (doc.activeElement && /^(INPUT|TEXTAREA|SELECT)$/.test(doc.activeElement.tagName)) return;
      location.reload();
    }, r * 1000);
  }

  // 7) نسخ نص
  doc.addEventListener('click', function (ev) {
    var b = ev.target.closest('[data-copy]');
    if (!b) return;
    var text = b.getAttribute('data-copy');
    var done = function () { var old = b.textContent; b.textContent = 'تم النسخ ✓'; setTimeout(function () { b.textContent = old; }, 1600); };
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, function () {});
    else { var t = doc.createElement('textarea'); t.value = text; doc.body.appendChild(t); t.select(); try { doc.execCommand('copy'); done(); } catch (e) {} t.remove(); }
  });

  // 8) عدّاد وقت العمل
  doc.querySelectorAll('[data-since]').forEach(function (el) {
    var start = Date.parse(el.getAttribute('data-since'));
    var brk = parseInt(el.getAttribute('data-break-sec') || '0', 10) * 1000;
    var frozen = el.getAttribute('data-frozen') === '1';
    var pad = function (n) { return (n < 10 ? '0' : '') + n; };
    var tick = function () {
      var ms = Math.max(0, Date.now() - start - brk), s = Math.floor(ms / 1000);
      el.textContent = Math.floor(s / 3600) + ':' + pad(Math.floor(s % 3600 / 60)) + ':' + pad(s % 60);
    };
    tick();
    if (!frozen) setInterval(tick, 1000);
  });

  // 9) اختيار «أخرى» يطلب نصًا
  doc.querySelectorAll('select[data-other-text]').forEach(function (sel) {
    var box = doc.getElementById(sel.getAttribute('data-other-text'));
    var upd = function () { var need = sel.selectedOptions[0] && sel.selectedOptions[0].getAttribute('data-needs-text') === '1'; if (box) { box.classList.toggle('hidden', !need); box.querySelectorAll('input,textarea').forEach(function (i) { i.required = !!need; }); } };
    sel.addEventListener('change', upd); upd();
  });

  // 10) شريط تبويبات المدير يتمرّر أفقيًا على الجوال: نُظهر التبويب الحالي دائمًا
  var curTab = doc.querySelector('.tabs .tab.on');
  if (curTab && curTab.scrollIntoView) {
    try { curTab.scrollIntoView({ block: 'nearest', inline: 'center' }); } catch (e) { curTab.scrollIntoView(); }
  }
})();
