"""Sign-in, first-run setup, company registration, password change, privacy page."""
from __future__ import annotations

import asyncio
import sqlite3

from . import config, db, security, ui, util
from .routes import route
from .ui import card, e, field, form, page, button, notice_box
from .web import redirect, safe_next

SETUP_ATTEMPTS = (10, 3600)


# ------------------------------------------------------------------------------------------------ first-run setup code
def setup_needed(c: sqlite3.Connection) -> bool:
    return db.one(c, "SELECT 1 FROM users LIMIT 1") is None


def ensure_setup_code(c: sqlite3.Connection) -> str | None:
    """On the very first start, makes a one-time code that is printed in the server log. Only its hash is stored."""
    if not setup_needed(c) or db.platform_get(c, "setup_code_hash"):
        return None
    return new_setup_code(c)


def new_setup_code(c: sqlite3.Connection) -> str:
    raw = "-".join(util.short_token(4) for _ in range(3))
    db.platform_set(c, "setup_code_hash", util.sha256("setup:" + raw))
    return raw


def _check_setup_code(c: sqlite3.Connection, code: str) -> bool:
    want = db.platform_get(c, "setup_code_hash")
    return bool(want) and util.sha256("setup:" + code.strip().lower()) == want


def _auth_page(req, title: str, body: str, status: int = 200):
    shell = (f'<div class="auth"><div class="brand-big"><img src="/static/icon.svg?v={ui.VER}" width="76" height="76" alt="">'
             f'<span>{ui.BRAND}</span></div>{card(body, title=title)}'
             f'<p class="foot"><a href="/privacy">الخصوصية وما يُسجَّل في التطبيق</a></p></div>')
    return page(req, title, shell, status=status, hide_nav=True)


# ------------------------------------------------------------------------------------------------ home
@route("GET", "/", auth="none")
async def home(req):
    if req.ctx:
        return redirect("/m" if req.ctx.is_manager else "/w")
    if await db.read(setup_needed):
        return redirect("/setup")
    return redirect("/login")


# ------------------------------------------------------------------------------------------------ sign in
def _login_form(req, error: str = "", username: str = "", nxt: str = ""):
    reg = ""
    err = notice_box(error, "bad") if error else ""
    body = err + form(req, "/login", (
        field("اسم المستخدم", "username", username, ltr=True, required=True, autocomplete="username", autofocus=True)
        + field("كلمة المرور", "password", "", type_="password", required=True, autocomplete="current-password")
        + f'<input type="hidden" name="next" value="{e(nxt)}">'
        + button("دخول", big=True)))
    return body + reg


@route("GET", "/login", auth="none")
async def login_page(req):
    if req.ctx:
        return redirect("/")
    if await db.read(setup_needed):
        return redirect("/setup")
    body = _login_form(req, nxt=safe_next(req.q("next")))
    opened = await db.read(lambda c: db.platform_get(c, "registration_open") == "1")
    if opened:
        body += f'<p class="center mt sub">شركتك جديدة؟ <a href="/register">سجّل حساب شركة</a></p>'
    return _auth_page(req, "تسجيل الدخول", body)


@route("POST", "/login", auth="none")
async def login_post(req):
    username = req.f("username")
    password = req.f_raw("password")
    nxt = safe_next(req.f("next"))
    if not security.LIMITER.allow(f"login-ip:{req.ip}", 30, 600) or not security.LIMITER.allow(f"login-user:{username.lower()}", 12, 600):
        return _auth_page(req, "تسجيل الدخول", _login_form(req, "محاولات كثيرة. انتظر بضع دقائق ثم حاول من جديد.", username, nxt), 429)
    user = await db.read(security.find_user, username) if username else None
    result = await asyncio.to_thread(security.check_login, user, password)
    token = None
    if user is not None:
        token = await db.write(security.record_login, user, result, req.ip, req.headers.get("user-agent", ""))
    if result == "locked":
        msg = f"أُوقف الدخول مؤقتًا بعد محاولات خاطئة. حاول بعد {security.LOCK_MINUTES} دقائق."
    elif result == "inactive":
        msg = "هذا الحساب موقوف. تواصل مع مدير فريقك."
    elif result:
        msg = "اسم المستخدم أو كلمة المرور غير صحيحة."
    else:
        msg = ""
    if msg or not token:
        return _auth_page(req, "تسجيل الدخول", _login_form(req, msg or "تعذر الدخول", username, nxt), 401)
    resp = redirect(nxt)
    resp.cookie(security.COOKIE, token, max_age=14 * 86400, secure=config.COOKIE_SECURE)
    return resp


@route("POST", "/logout", auth="none")
async def logout(req):
    token = req.cookies.get(security.COOKIE)
    if token:
        ctx = req.ctx
        await db.write(lambda c: (security.end_session(c, token), ctx and db.emit(c, ctx.cid, "auth.logout", actor=ctx.uid, user=ctx.uid)))
    resp = redirect("/login")
    resp.drop_cookie(security.COOKIE, secure=config.COOKIE_SECURE)
    return resp


# ------------------------------------------------------------------------------------------------ change password
@route("GET", "/password", auth="user")
async def password_page(req):
    forced = bool(req.ctx.user["must_change_password"])
    intro = notice_box("هذه كلمة مرور مؤقتة. اختر كلمة مرور خاصة بك قبل المتابعة.", "info") if forced else ""
    body = intro + form(req, "/password", (
        field("كلمة المرور الحالية", "current", "", type_="password", required=True, autocomplete="current-password")
        + field("كلمة المرور الجديدة", "new", "", type_="password", required=True, autocomplete="new-password",
                hint="8 أحرف على الأقل، ولا تكون أرقامًا فقط")
        + field("أعد كتابتها", "again", "", type_="password", required=True, autocomplete="new-password")
        + button("حفظ كلمة المرور", big=True)))
    return page(req, "كلمة المرور", card(body, title="تغيير كلمة المرور"), hide_nav=forced, back="" if forced else "/")


@route("POST", "/password", auth="user")
async def password_post(req):
    ctx = req.ctx
    cur, new, again = req.f_raw("current"), req.f_raw("new"), req.f_raw("again")

    def fail(msg: str):
        body = notice_box(msg, "bad") + form(req, "/password", (
            field("كلمة المرور الحالية", "current", "", type_="password", required=True)
            + field("كلمة المرور الجديدة", "new", "", type_="password", required=True)
            + field("أعد كتابتها", "again", "", type_="password", required=True) + button("حفظ كلمة المرور", big=True)))
        return page(req, "كلمة المرور", card(body, title="تغيير كلمة المرور"), status=400, hide_nav=bool(ctx.user["must_change_password"]))

    if not security.LIMITER.allow(f"pw:{ctx.uid}", 8, 600):
        return fail("محاولات كثيرة. انتظر قليلًا.")
    row = await db.read(lambda c: db.one(c, "SELECT password_hash FROM users WHERE id=?", ctx.uid))
    if not await asyncio.to_thread(security.verify_password, cur, row["password_hash"]):
        return fail("كلمة المرور الحالية غير صحيحة.")
    if new != again:
        return fail("كلمتا المرور الجديدتان غير متطابقتين.")
    problem = security.password_problem(new, ctx.user["username"])
    if problem:
        return fail(problem)
    if new == cur:
        return fail("اختر كلمة مرور مختلفة عن الحالية.")
    hashed = await asyncio.to_thread(security.hash_password, new)

    def save(c):
        c.execute("UPDATE users SET password_hash=?, must_change_password=0, failed_logins=0, locked_until=NULL WHERE id=?", (hashed, ctx.uid))
        security.end_user_sessions(c, ctx.uid, keep_session_id=ctx.session["id"])
        db.emit(c, ctx.cid, "auth.password_changed", actor=ctx.uid, user=ctx.uid)

    await db.write(save)
    return ui.flash_redirect("/", "ok", "تم تغيير كلمة المرور")


# ------------------------------------------------------------------------------------------------ first-run setup
def _setup_form(req, error: str = "", values: dict | None = None):
    v = values or {}
    body = (notice_box(error, "bad") if error else "") + notice_box(
        "عند أول تشغيل يُطبع رمز الإعداد في سجل الخادم. أدخله هنا لإنشاء حساب مالك الحساب.", "info") + form(req, "/setup", (
        field("رمز الإعداد", "code", v.get("code", ""), ltr=True, required=True, placeholder="xxxx-xxxx-xxxx")
        + field("اسم الشركة", "company", v.get("company", ""), required=True, maxlength=80)
        + field("اسمك", "name", v.get("name", ""), required=True, maxlength=80)
        + field("اسم المستخدم للدخول", "username", v.get("username", ""), ltr=True, required=True, hint="إنجليزي بلا مسافات", autocomplete="username")
        + field("كلمة المرور", "password", "", type_="password", required=True, autocomplete="new-password")
        + field("أعد كتابتها", "again", "", type_="password", required=True, autocomplete="new-password")
        + button("إنشاء الحساب", big=True)))
    return _auth_page(req, "إعداد مِنجَز لأول مرة", body, 400 if error else 200)


@route("GET", "/setup", auth="none")
async def setup_page(req):
    if not await db.read(setup_needed):
        return redirect("/login")
    return _setup_form(req)


def _validate_account(username: str, password: str, again: str, name: str, company: str = "x") -> str:
    if not company or len(company) < 2:
        return "اكتب اسم الشركة"
    if not name or len(name) < 2:
        return "اكتب الاسم"
    p = security.username_problem(username)
    if p:
        return p
    if password != again:
        return "كلمتا المرور غير متطابقتين"
    return security.password_problem(password, username)


@route("POST", "/setup", auth="none")
async def setup_post(req):
    vals = {k: req.f(k) for k in ("code", "company", "name", "username")}
    if not security.LIMITER.allow(f"setup:{req.ip}", *SETUP_ATTEMPTS):
        return _setup_form(req, "محاولات كثيرة. حاول بعد ساعة.", vals)
    password, again = req.f_raw("password"), req.f_raw("again")
    err = _validate_account(vals["username"], password, again, vals["name"], vals["company"])
    if err:
        return _setup_form(req, err, vals)
    hashed = await asyncio.to_thread(security.hash_password, password)

    def create(c):
        if not setup_needed(c):
            return "done", None
        if not _check_setup_code(c, vals["code"]):
            return "code", None
        cid = db.create_company(c, vals["company"], vals["username"])
        cur = c.execute("INSERT INTO users(company_id,username,name,role,password_hash,is_platform_admin,created_at) VALUES(?,?,?,?,?,1,?)",
                        (cid, vals["username"], vals["name"], "owner", hashed, util.now_iso()))
        uid = cur.lastrowid
        db.emit(c, cid, "admin.setup", actor=uid, user=uid, data={"company": vals["company"]})
        db.platform_set(c, "setup_done", "1")
        c.execute("DELETE FROM platform WHERE key='setup_code_hash'")
        user = db.one(c, "SELECT * FROM users WHERE id=?", uid)
        return "ok", security.record_login(c, user, "", req.ip, req.headers.get("user-agent", ""))

    state, token = await db.write(create)
    if state == "done":
        return redirect("/login")
    if state == "code":
        return _setup_form(req, "رمز الإعداد غير صحيح.", vals)
    resp = ui.flash_redirect("/m", "ok", "تم إنشاء الحساب. ابدأ بضبط الإعدادات ثم أضف الموظفين.")
    resp.cookie(security.COOKIE, token, max_age=14 * 86400, secure=config.COOKIE_SECURE)
    return resp


# ------------------------------------------------------------------------------------------------ company registration (when the platform owner opens it)
def _register_form(req, error: str = "", values: dict | None = None):
    v = values or {}
    body = (notice_box(error, "bad") if error else "") + form(req, "/register", (
        field("اسم الشركة", "company", v.get("company", ""), required=True, maxlength=80)
        + field("اسمك", "name", v.get("name", ""), required=True, maxlength=80)
        + field("اسم المستخدم للدخول", "username", v.get("username", ""), ltr=True, required=True, hint="إنجليزي بلا مسافات", autocomplete="username")
        + field("كلمة المرور", "password", "", type_="password", required=True, autocomplete="new-password")
        + field("أعد كتابتها", "again", "", type_="password", required=True, autocomplete="new-password")
        + button("تسجيل الشركة", big=True)))
    return _auth_page(req, "تسجيل شركة جديدة", body, 400 if error else 200)


@route("GET", "/register", auth="none")
async def register_page(req):
    if req.ctx:
        return redirect("/")
    if await db.read(setup_needed):
        return redirect("/setup")
    if not await db.read(lambda c: db.platform_get(c, "registration_open") == "1"):
        return _auth_page(req, "التسجيل مغلق", notice_box("تسجيل الشركات الجديدة مغلق حاليًا. تواصل مع إدارة المنصة.", "info") +
                          button("العودة لتسجيل الدخول", href="/login", kind="ghost"), 403)
    return _register_form(req)


@route("POST", "/register", auth="none")
async def register_post(req):
    if not await db.read(lambda c: db.platform_get(c, "registration_open") == "1"):
        return redirect("/register")
    vals = {k: req.f(k) for k in ("company", "name", "username")}
    if not security.LIMITER.allow(f"register:{req.ip}", 5, 3600):
        return _register_form(req, "محاولات كثيرة. حاول لاحقًا.", vals)
    password, again = req.f_raw("password"), req.f_raw("again")
    err = _validate_account(vals["username"], password, again, vals["name"], vals["company"])
    if err:
        return _register_form(req, err, vals)
    hashed = await asyncio.to_thread(security.hash_password, password)

    def create(c):
        if db.one(c, "SELECT 1 FROM users WHERE username=?", vals["username"]):
            return None
        cid = db.create_company(c, vals["company"], vals["username"])
        cur = c.execute("INSERT INTO users(company_id,username,name,role,password_hash,created_at) VALUES(?,?,?,?,?,?)",
                        (cid, vals["username"], vals["name"], "owner", hashed, util.now_iso()))
        uid = cur.lastrowid
        db.emit(c, cid, "admin.company_registered", actor=uid, user=uid, data={"company": vals["company"]})
        return security.record_login(c, db.one(c, "SELECT * FROM users WHERE id=?", uid), "", req.ip, req.headers.get("user-agent", ""))

    token = await db.write(create)
    if not token:
        return _register_form(req, "اسم المستخدم محجوز، اختر غيره.", vals)
    resp = ui.flash_redirect("/m", "ok", "تم تسجيل الشركة")
    resp.cookie(security.COOKIE, token, max_age=14 * 86400, secure=config.COOKIE_SECURE)
    return resp


# ------------------------------------------------------------------------------------------------ privacy
@route("GET", "/privacy", auth="none")
async def privacy(req):
    body = card(
        '<h3>ما الذي يسجله مِنجَز؟</h3><ul class="plain">'
        "<li>وقت دخولك وبدء يوم العمل وإنهائه، وفترات الاستراحة التي تضغطها.</li>"
        "<li>الأرقام التي تضغط «اتصال» عليها ووقت الضغط. هذا يثبت أنك بدأت المكالمة من التطبيق، ولا يثبت أنها تمّت.</li>"
        "<li>النتيجة التي تختارها لكل مكالمة وملاحظتك، ووقت تسجيلها.</li>"
        "<li>فترات الخمول: إن مضت مدة بلا نشاط يسألك التطبيق ماذا كنت تفعل، ويحفظ جوابك.</li>"
        "<li>مرات فتح العميل للرابط الشخصي الذي أرسلته له.</li></ul>"
        '<h3>ما الذي لا يسجله؟</h3><ul class="plain">'
        "<li>لا يسمع المكالمات ولا يسجّلها، ولا يقرأ رسائلك ولا جهات اتصالك الشخصية.</li>"
        "<li>لا يتتبع موقعك.</li><li>لا يطّلع على شيء خارج التطبيق في هاتفك.</li></ul>"
        '<h3>درجات الثقة في السجل</h3><ul class="plain">'
        "<li><b>مُبلَّغة:</b> سجّلت النتيجة دون أثر آخر.</li>"
        "<li><b>بدأت من التطبيق:</b> ضغطت «اتصال» فسُجّل الحدث بوقت الخادم.</li>"
        "<li><b>موثَّقة بسجل الجهاز:</b> عند ربط جهاز عمل بتطبيق مساعد، تُطابَق المكالمة الصادرة (الرقم والوقت والمدة فقط) مع النتيجة. "
        "لا يُرفع إلا ما يخص أرقام قائمة العملاء، ويتم هذا بعلمك على جهاز العمل فقط.</li></ul>"
        '<h3>من يرى بياناتك؟</h3><p>مدراء شركتك فقط. السجل لا يُحذف ولا يُعدَّل؛ وإن صُحّحت نتيجة فتبقى القيمة الأصلية ظاهرة بجانب التصحيح وسببه.</p>'
        '<p class="sub">الإشارات التي تظهر للمدير (مثل مكالمات سريعة جدًا) للمراجعة والحديث معك، وليست اتهامًا.</p>',
        title="الخصوصية وما يُسجَّل")
    return page(req, "الخصوصية", body, back="/" if req.ctx else "/login", hide_nav=not req.ctx)
