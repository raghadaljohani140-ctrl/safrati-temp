"""The manager's screens: live dashboard, drill-downs, employees and permissions, distributing numbers."""
from __future__ import annotations

import asyncio
import sqlite3
from typing import Any

from . import consts, db, leads as leadlib, plans, reports, security, ui, util, work
from .routes import route
from .ui import badge, bar, button, card, checkbox, e, field, form, icon, notice_box, page, select, table
from .views_common import (EVENT_LABELS, describe_event, evidence_badge, flag_badges, kind_label, outcome_labels, score_badge)
from .web import HttpError, Response, redirect

STATE_LABEL = {"working": ("يعمل", "on"), "break": ("في استراحة", "brk"), "closed": ("أنهى يومه", "off"), "not_started": ("لم يبدأ", "off")}


def link(href: str, text: str) -> str:
    return f'<a href="{e(href)}">{e(text)}</a>'


def lead_link(lead_id: int, name: str) -> str:
    return link(f"/m/lead/{lead_id}", name)


# ------------------------------------------------------------------------------------------------ dashboard
@route("GET", "/m", auth="manager")
async def dashboard(req):
    ctx = req.ctx
    s = ctx.settings
    today = util.local_date(util.now(), s["tz"])
    if not ctx.can("dashboard.view"):
        links = "".join(f'<a class="kind" href="{h}">{e(t)}</a>' for k, h, t, ic in ui.manager_nav(ctx) if k != "dash")
        return page(req, "الرئيسية", card(f'<div class="kinds">{links}</div>', title="الأقسام المتاحة لك"), active="dash")

    def go(c):
        data = reports.team_today(c, ctx.cid, today, s)
        data["n_users"] = db.scalar(c, "SELECT COUNT(*) FROM users WHERE company_id=? AND role='employee' AND active=1", ctx.cid, default=0)
        data["n_leads"] = db.scalar(c, "SELECT COUNT(*) FROM leads WHERE company_id=?", ctx.cid, default=0)
        return data

    data = await db.read(go)
    t, x = data["totals"], data["extra"]
    parts: list[str] = []
    if data["n_users"] == 0 or data["n_leads"] == 0 or not s["platform_url"]:
        steps = [("اضبط اسم المنصة ورابطها", bool(s["platform_url"]), "/m/settings", "settings.manage"),
                 ("أضف موظفيك", data["n_users"] > 0, "/m/employees/new", "employees.manage"),
                 ("استورد ملف الأرقام", data["n_leads"] > 0, "/m/import", "leads.import")]
        lis = "".join(f'<a class="kind" href="{h}">{icon("check") if ok else icon("plus")}<span>{e(lbl)}</span><b>{"تم" if ok else ""}</b></a>'
                      for lbl, ok, h, perm in steps if ctx.can(perm))
        parts.append(card(f'<div class="kinds">{lis}</div>', title="ابدأ من هنا", sub="ثلاث خطوات ويعمل فريقك غدًا", cls="accent"))
    for n in data["notices"]:
        parts.append(f'<div class="alert-row">{icon("alert")}<p>{e(n["text"])} <span class="sub">{e(ui.fmt_dt(n["created_at"], s["tz"]))}</span></p>'
                     f'{form(req, f"/m/notice/{n["id"]}/seen", button("تم", kind="ghost", small=True), cls="inline")}</div>')
    working = t["working"] + t["break"]
    tiles = [
        ui.stat("يعملون الآن", working, href="/m/drill/working", tone="ok" if working else "", sub=f"من {data['n_users']} موظفًا"),
        ui.stat("لم يبدؤوا", t["not_started"], href="/m/drill/not_started", tone="warn" if t["not_started"] and working else ""),
        ui.stat("مكالمات اليوم", t["calls"], href="/m/drill/calls"),
        ui.stat("ردّ العميل", t["answered"], href="/m/drill/answered", sub=ui.pct(t["answered"], t["calls"]) if t["calls"] else ""),
        ui.stat("مهتمون", t["interested"], href="/m/drill/interested", tone="ok" if t["interested"] else ""),
        ui.stat("روابط أُرسلت", t["links_sent"], href="/m/drill/links_sent"),
        ui.stat("روابط فُتحت", t["links_opened"], href="/m/drill/links_opened"),
        ui.stat("تسجيلات مُبلَّغة", t["reg_reported"], href="/m/drill/reg_reported", tone="ok" if t["reg_reported"] else ""),
        ui.stat("تسجيلات مؤكدة", t["reg_confirmed"], href="/m/drill/reg_confirmed", tone="ok" if t["reg_confirmed"] else ""),
        ui.stat("مهام متبقية", t["tasks_open"], href="/m/drill/tasks_open", sub=f"من {t['tasks_total']}" if t["tasks_total"] else ""),
        ui.stat("فترات صامتة بلا توضيح", t["pending_gaps"], href="/m/drill/gaps", tone="warn" if t["pending_gaps"] else ""),
        ui.stat("متابعات متأخرة", x["overdue"], href="/m/drill/overdue", tone="warn" if x["overdue"] else ""),
        ui.stat("أرقام جديدة في المخزون", x["pool"], href="/m/leads?status=new&owner=none", tone="bad" if x["pool"] == 0 and data["n_users"] else ""),
    ]
    parts.append(f'<div class="grid">{"".join(tiles)}</div>')
    extra = []
    if x["orphans"]:
        extra.append(f'<a class="kind" href="/m/drill/orphans">{icon("alert")}<span>متابعات بلا موظف (تحتاج توزيعًا)</span><b>{x["orphans"]}</b></a>')
    if x["exhausted"]:
        extra.append(f'<a class="kind" href="/m/drill/exhausted">{icon("clock")}<span>أرقام توقفت محاولاتها</span><b>{x["exhausted"]}</b></a>')
    if extra:
        parts.append(f'<div class="kinds mt">{"".join(extra)}</div>')
    rows = []
    for en in data["employees"]:
        u, m, st_ = en["user"], en["m"], en["state"]
        lbl, dot = STATE_LABEL[st_]
        seen = ""
        if en["last_seen"] and st_ in ("working", "break"):
            seen = f'<div class="sub">آخر ظهور {e(ui.ago(en["last_seen"]))}</div>'
        done = f'{m["tasks"]["done"]} / {m["tasks"]["total"]}' if m["tasks"]["total"] else "—"
        started = ui.fmt_time(m["shift"]["started_at"], s["tz"]) if m["shift"] else "—"
        rating = m["rating"]["score"] if m["rating"] else None
        rows.append([link(f"/m/report/{u['id']}/{m['day']}", u["name"]) + seen, f'<span class="dot {dot}"></span>{lbl}', e(started),
                     e(done) + (bar(m["tasks"]["done"], m["tasks"]["total"]) if m["tasks"]["total"] else ""), str(m["calls"]["total"]),
                     str(m["interested"]), str(m["links"]["sent"]), str(m["registered"]["reported"]), score_badge(rating), str(len(m["flags"])) if m["flags"] else "—"])
    parts.append(card(table(["الموظف", "الحالة", "بدأ", "المهام", "مكالمات", "مهتمون", "روابط", "تسجيلات", "التقييم", "إشارات"], rows,
                            empty_text="لم تضف موظفين بعد"), title="الفريق اليوم", sub=ui.fmt_day(today),
                    actions=button("تقرير الفريق", href="/m/reports", kind="ghost", small=True) if ctx.can("reports.view") else ""))
    return page(req, "لوحة المراقبة", "".join(parts), active="dash", wide=True, refresh=60)


@route("POST", "/m/notice/<int:nid>/seen", auth="manager")
async def notice_seen(req, nid: int):
    ctx = req.ctx
    await db.write(lambda c: c.execute("UPDATE notices SET seen_at=?, seen_by=? WHERE id=? AND company_id=?", (util.now_iso(), ctx.uid, nid, ctx.cid)))
    return redirect("/m")


# ------------------------------------------------------------------------------------------------ drill-downs
DRILL_TITLES = {
    "working": "يعملون الآن", "not_started": "لم يبدؤوا اليوم", "calls": "مكالمات اليوم", "answered": "ردّ فيها العميل", "interested": "العملاء المهتمون",
    "links_sent": "روابط أُرسلت", "links_opened": "روابط فتحها العملاء", "reg_reported": "تسجيلات أبلغ بها الموظفون", "reg_confirmed": "تسجيلات مؤكدة",
    "tasks_open": "مهام متبقية", "gaps": "فترات صامتة بلا توضيح", "overdue": "متابعات متأخرة", "orphans": "متابعات بلا موظف", "exhausted": "أرقام توقفت محاولاتها",
}


def drill_data(c: sqlite3.Connection, ctx, metric: str, day: str) -> tuple[list[str], list[list[str]], str]:
    cid, s = ctx.cid, ctx.settings
    names = {r["id"]: r["name"] for r in c.execute("SELECT id, name FROM users WHERE company_id=?", (cid,))}
    olabels = outcome_labels(c, cid)
    note = ""
    if metric in ("working", "not_started"):
        data = reports.team_today(c, cid, day, s)
        want = ("working", "break") if metric == "working" else ("not_started",)
        rows = [[link(f"/m/report/{en['user']['id']}/{day}", en["user"]["name"]), STATE_LABEL[en["state"]][0],
                 e(ui.fmt_time(en["m"]["shift"]["started_at"], s["tz"]) if en["m"]["shift"] else "—"),
                 f'{en["m"]["tasks"]["done"]} / {en["m"]["tasks"]["total"]}'] for en in data["employees"] if en["state"] in want]
        return ["الموظف", "الحالة", "بدأ", "المهام"], rows, note
    if metric in ("calls", "answered", "interested", "reg_reported"):
        sql = (f"SELECT a.*, {reports.EFFECTIVE} AS eff, l.name FROM call_attempts a JOIN leads l ON l.id=a.lead_id "
               f"WHERE a.company_id=? AND a.day=? AND a.status='recorded' ORDER BY a.recorded_at DESC LIMIT 500")
        out = []
        for r in c.execute(sql, (cid, day)):
            if metric == "answered" and r["eff"] not in consts.ANSWERED:
                continue
            if metric == "interested" and r["eff"] != "interested":
                continue
            if metric == "reg_reported" and r["eff"] != "registered":
                continue
            out.append([e(ui.fmt_time(r["recorded_at"], s["tz"])), e(names.get(r["user_id"], "")), lead_link(r["lead_id"], r["name"]),
                        ui.phone(r["phone"]), e(olabels.get(r["eff"], r["eff"])), evidence_badge(r["evidence"]), e(r["note"] or "")])
        return ["الوقت", "الموظف", "العميل", "الرقم", "النتيجة", "الثقة", "ملاحظة"], out, note
    if metric in ("links_sent", "links_opened", "reg_confirmed"):
        typ = {"links_sent": "link.sent", "links_opened": "link.opened", "reg_confirmed": "lead.confirmed"}[metric]
        out = []
        for r in c.execute("SELECT ev.*, l.name FROM events ev LEFT JOIN leads l ON l.id=ev.lead_id WHERE ev.company_id=? AND ev.day=? AND ev.type=? ORDER BY ev.seq DESC LIMIT 500",
                           (cid, day, typ)):
            out.append([e(ui.fmt_time(r["ts"], s["tz"])), e(names.get(r["user_id"], "—")), lead_link(r["lead_id"], r["name"] or "عميل") if r["lead_id"] else ""])
        return ["الوقت", "الموظف", "العميل"], out, note
    if metric == "tasks_open":
        out = [[e(names.get(r["user_id"], "")), lead_link(r["lead_id"], r["name"]), ui.phone(r["phone"]), e(kind_label(r["kind"]))]
               for r in c.execute("SELECT t.*, l.name, l.phone FROM tasks t JOIN leads l ON l.id=t.lead_id JOIN shifts sh ON sh.user_id=t.user_id AND sh.work_date=t.plan_date "
                                  "WHERE t.company_id=? AND t.status='open' AND sh.status='open' ORDER BY t.user_id, t.position LIMIT 500", (cid,))]
        return ["الموظف", "العميل", "الرقم", "نوع المهمة"], out, note
    if metric == "gaps":
        out = [[e(names.get(r["user_id"], "")), e(ui.fmt_dt(r["started_at"], s["tz"])),
                e(util.fmt_duration((util.parse_iso(r["ended_at"]) - util.parse_iso(r["started_at"])).total_seconds())),
                "خارج التطبيق" if r["kind"] == "away" else "داخل التطبيق"]
               for r in c.execute("SELECT g.* FROM gaps g JOIN shifts sh ON sh.id=g.shift_id WHERE g.company_id=? AND g.status='pending' AND sh.work_date=? ORDER BY g.id DESC",
                                  (cid, day))]
        return ["الموظف", "بدأت", "المدة", "النوع"], out, note
    marks = ",".join("?" * len(leadlib.FOLLOW_STATUSES))
    if metric == "overdue":
        out = [[lead_link(r["id"], r["name"]), ui.phone(r["phone"]), e(names.get(r["owner_id"], "")), ui.status_badge(r["status"]), e(r["next_follow_up"]),
                f'{util.days_between(r["next_follow_up"], day)} يوم']
               for r in c.execute(f"SELECT * FROM leads WHERE company_id=? AND status IN ({marks}) AND next_follow_up<? AND owner_id IS NOT NULL ORDER BY next_follow_up LIMIT 500",
                                  (cid, *leadlib.FOLLOW_STATUSES, day))]
        return ["العميل", "الرقم", "الموظف", "الحالة", "موعدها", "تأخرت"], out, note
    if metric == "orphans":
        out = [[lead_link(r["id"], r["name"]), ui.phone(r["phone"]), ui.status_badge(r["status"]), e(r["next_follow_up"] or "")]
               for r in c.execute(f"SELECT * FROM leads WHERE company_id=? AND status IN ({marks}) AND owner_id IS NULL ORDER BY next_follow_up LIMIT 500", (cid, *leadlib.FOLLOW_STATUSES))]
        return ["العميل", "الرقم", "الحالة", "موعدها"], out, "وزّعهم من صفحة العملاء: اختر الحالة ثم «بلا موظف»."
    if metric == "exhausted":
        out = [[lead_link(r["id"], r["name"]), ui.phone(r["phone"]), e(names.get(r["owner_id"], "—")), str(r["attempts"]), e(ui.ago(r["last_call_at"]))]
               for r in c.execute("SELECT * FROM leads WHERE company_id=? AND status='exhausted' ORDER BY last_call_at DESC LIMIT 500", (cid,))]
        return ["العميل", "الرقم", "الموظف", "المحاولات", "آخر اتصال"], out, ""
    raise HttpError(404, "مقياس غير معروف")


@route("GET", "/m/drill/<metric>", auth="manager", perm="dashboard.view")
async def drill(req, metric: str):
    ctx = req.ctx
    if metric not in DRILL_TITLES:
        raise HttpError(404, "مقياس غير معروف")
    day = req.q("day") or util.local_date(util.now(), ctx.tz)
    headers, rows, note = await db.read(drill_data, ctx, metric, day)
    body = card(table(headers, rows, empty_text="لا شيء هنا الآن") + (f'<p class="sub mt">{e(note)}</p>' if note else "")
                + ('<p class="sub mt">يُعرض أحدث 500 صف.</p>' if len(rows) >= 500 else ""), title=DRILL_TITLES[metric], sub=ui.fmt_day(day))
    return page(req, DRILL_TITLES[metric], body, active="dash", wide=True, back="/m")


# ------------------------------------------------------------------------------------------------ users: employees and managers
def credentials_page(req, title: str, name: str, username: str, temp: str, back: str, back_text: str = "العودة"):
    body = card(notice_box("احفظ كلمة المرور الآن؛ لن تظهر مرة أخرى. سيُطلب منه تغييرها عند أول دخول.", "warn")
                + f'<dl class="kv"><dt>الاسم</dt><dd>{e(name)}</dd><dt>اسم المستخدم</dt><dd class="ltr">{e(username)}</dd>'
                  f'<dt>كلمة المرور المؤقتة</dt><dd><span class="code">{e(temp)}</span> '
                  f'<button class="btn ghost sm" type="button" data-copy="{e(temp)}" data-keep>نسخ</button></dd></dl>'
                + button(back_text, href=back, kind="ghost"), title=title)
    resp = page(req, title, body, active="emps")
    resp.header("Cache-Control", "no-store")
    return resp


def _int_or_none(v: str, lo: float, hi: float) -> tuple[bool, float | None]:
    if v == "":
        return True, None
    n = util.to_float(v)
    if n is None or not lo <= n <= hi:
        return False, None
    return True, n


def user_form(req, role: str, u: dict | None = None, error: str = "") -> str:
    v = u or {}
    ctx = req.ctx
    new = u is None
    fields = [field("الاسم", "name", v.get("name", ""), required=True, maxlength=80)]
    if new:
        fields.append(field("اسم المستخدم للدخول", "username", "", ltr=True, required=True, hint="إنجليزي بلا مسافات", autocomplete="off"))
    fields.append(field("الجوال (اختياري)", "phone", v.get("phone") or "", ltr=True, inputmode="tel"))
    if role == "employee":
        fields.append(f'<div class="row"><div style="flex:1">{field("أرقام جديدة يوميًا", "daily_new", v.get("daily_new") if v.get("daily_new") is not None else "", type_="number", min_=0, max_=500, hint=f"فارغ = الافتراضي ({ctx.settings["daily_new"]})")}</div>'
                      f'<div style="flex:1">{field("ساعات العمل الصافية", "shift_hours", v.get("shift_hours") if v.get("shift_hours") is not None else "", type_="number", min_=1, max_=16, step=0.5, hint=f"فارغ = الافتراضي ({ctx.settings["shift_hours"]})")}</div></div>')
    else:
        current = security.perms_of({"role": "manager", "perms": v.get("perms")}) if not new else set(consts.ROLE_PERMS["manager"])
        boxes = "".join(checkbox(label, f"perm_{k}", k in current) for k, label in consts.PERMISSIONS.items() if k != "managers.manage")
        fields.append(f'<h3>الصلاحيات</h3>{boxes}')
    return (notice_box(error, "bad") if error else "") + "".join(fields)


def _parse_user_form(req, role: str) -> tuple[dict[str, Any], str]:
    out: dict[str, Any] = {"name": req.f("name")[:80], "phone": req.f("phone")[:20] or None, "daily_new": None, "shift_hours": None, "perms": None}
    if len(out["name"]) < 2:
        return out, "اكتب الاسم"
    if role == "employee":
        ok1, dn = _int_or_none(req.f("daily_new"), 0, 500)
        ok2, sh = _int_or_none(req.f("shift_hours"), 1, 16)
        if not ok1 or not ok2:
            return out, "راجع الأرقام: الجديد من 0 إلى 500، والساعات من 1 إلى 16"
        out["daily_new"] = int(dn) if dn is not None else None
        out["shift_hours"] = sh
    else:
        chosen = [k for k in consts.PERMISSIONS if k != "managers.manage" and req.f(f"perm_{k}")]
        out["perms"] = ",".join(chosen)
    return out, ""


async def _create_user(req, role: str, back: str):
    ctx = req.ctx
    data, err = _parse_user_form(req, role)
    username = req.f("username")
    err = err or security.username_problem(username)
    if err:
        return page(req, "إضافة", card(form(req, req.path, user_form(req, role, {**data, "daily_new": req.f("daily_new"), "shift_hours": req.f("shift_hours")}, err)
                                            + button("حفظ", big=True)), title="إضافة"), active="emps", status=400, back=back)
    temp = security.generate_password()
    hashed = await asyncio.to_thread(security.hash_password, temp)

    def go(c):
        if db.one(c, "SELECT 1 FROM users WHERE username=?", username):
            return False
        cur = c.execute("INSERT INTO users(company_id,username,name,role,password_hash,must_change_password,phone,daily_new,shift_hours,perms,created_at,created_by)"
                        " VALUES(?,?,?,?,?,1,?,?,?,?,?,?)",
                        (ctx.cid, username, data["name"], role, hashed, data["phone"], data["daily_new"], data["shift_hours"], data["perms"], util.now_iso(), ctx.uid))
        db.emit(c, ctx.cid, "user.created", actor=ctx.uid, user=cur.lastrowid, data={"name": data["name"], "role": role, "username": username})
        return True

    if not await db.write(go):
        return page(req, "إضافة", card(form(req, req.path, user_form(req, role, {**data}, "اسم المستخدم محجوز، اختر غيره") + button("حفظ", big=True)), title="إضافة"),
                    active="emps", status=400, back=back)
    return credentials_page(req, "تمت الإضافة", data["name"], username, temp, back)


# ---- employees
@route("GET", "/m/employees", auth="manager", perm="employees.manage")
async def employees(req):
    ctx = req.ctx
    today = util.local_date(util.now(), ctx.tz)

    def go(c):
        return c.execute("SELECT u.*, (SELECT COUNT(*) FROM leads l WHERE l.owner_id=u.id AND l.status='new') AS fresh, "
                         "(SELECT COUNT(*) FROM leads l WHERE l.owner_id=u.id AND l.status IN ('interested','no_answer','phone_off','callback','link_sent','visited')) AS follow, "
                         "(SELECT status FROM shifts sh WHERE sh.user_id=u.id AND sh.work_date=?) AS shift_status "
                         "FROM users u WHERE u.company_id=? AND u.role='employee' ORDER BY u.active DESC, u.name", (today, ctx.cid)).fetchall()

    rows = []
    for u in await db.read(go):
        state = {"open": "يعمل", "closed": "أنهى يومه", "auto_closed": "أغلق تلقائيًا", None: "لم يبدأ"}[u["shift_status"]]
        rows.append([link(f"/m/employee/{u['id']}", u["name"]), f'<span class="ltr">{e(u["username"])}</span>', ui.badge("نشط", "ok") if u["active"] else ui.badge("موقوف", "bad"),
                     e(state if u["active"] else "—"), str(u["fresh"]), str(u["follow"]), e(u["daily_new"] if u["daily_new"] is not None else "الافتراضي"),
                     e(ui.ago(u["last_login_at"]) if u["last_login_at"] else "لم يدخل")])
    body = card(table(["الموظف", "الدخول", "الحساب", "اليوم", "أرقام جديدة معه", "متابعات معه", "الجديد يوميًا", "آخر دخول"], rows, empty_text="لم تضف موظفين بعد"),
                title="الموظفون", actions=button("إضافة موظف", href="/m/employees/new", icon_name="plus", small=True))
    return page(req, "الموظفون", body, active="emps", wide=True)


@route("GET", "/m/employees/new", auth="manager", perm="employees.manage")
async def employee_new(req):
    return page(req, "إضافة موظف", card(form(req, "/m/employees/new", user_form(req, "employee") + button("إضافة وتوليد كلمة مرور مؤقتة", big=True)), title="موظف جديد"),
                active="emps", back="/m/employees")


@route("POST", "/m/employees/new", auth="manager", perm="employees.manage")
async def employee_create(req):
    return await _create_user(req, "employee", "/m/employees")


def _user_or_404(c: sqlite3.Connection, ctx, uid: int, role: str) -> sqlite3.Row:
    u = db.one(c, "SELECT * FROM users WHERE id=? AND company_id=? AND role=?", uid, ctx.cid, role)
    if not u:
        raise HttpError(404, "المستخدم غير موجود")
    return u


@route("GET", "/m/employee/<int:uid>", auth="manager", perm="employees.manage")
async def employee_page(req, uid: int):
    ctx = req.ctx
    s = ctx.settings

    def go(c):
        u = _user_or_404(c, ctx, uid, "employee")
        days = []
        for r in c.execute("SELECT work_date FROM shifts WHERE user_id=? ORDER BY work_date DESC LIMIT 30", (uid,)).fetchall():
            days.append((r["work_date"], reports.metrics_for(c, ctx.cid, uid, r["work_date"], s)))
        counts = dict(c.execute("SELECT status, COUNT(*) FROM leads WHERE owner_id=? GROUP BY status", (uid,)).fetchall())
        return u, days, counts

    u, days, counts = await db.read(go)
    rows = [[link(f"/m/report/{uid}/{d}", ui.fmt_day(d, with_year=False)), str(m["calls"]["total"]), str(m["interested"]), str(m["links"]["sent"]),
             f'{m["tasks"]["done"]}/{m["tasks"]["total"]}', score_badge(m["rating"]["score"] if m["rating"] else None), flag_badges(m["flags"])]
            for d, m in days if m]
    cts = "".join(f'<dt>{e(consts.STATUS_LABELS.get(k, k))}</dt><dd>{v}</dd>' for k, v in sorted(counts.items(), key=lambda kv: -kv[1]))
    acts = ""
    if u["active"]:
        acts = (form(req, f"/m/employee/{uid}/reset", button("إعادة تعيين كلمة المرور", kind="ghost", small=True, confirm="سيُنشأ رمز مؤقت جديد ويُنهى دخوله الحالي. متابعة؟"), cls="inline")
                + form(req, f"/m/employee/{uid}/active", button("إيقاف الحساب", kind="danger", small=True,
                                                                  confirm="سيُوقف الحساب ويعود رقمه الجديد للمخزون، وتبقى متابعاته بلا موظف حتى توزعها. متابعة؟"), cls="inline"))
    else:
        acts = form(req, f"/m/employee/{uid}/active", button("تفعيل الحساب", kind="soft", small=True), cls="inline")
    edit = form(req, f"/m/employee/{uid}", user_form(req, "employee", dict(u)) + button("حفظ التعديل", big=True))
    body = (card(edit, title=u["name"], actions=acts) + card(f'<dl class="kv">{cts}</dl>' if cts else ui.empty("لا عملاء مسندون"), title="العملاء المسندون إليه")
            + card(table(["اليوم", "مكالمات", "مهتمون", "روابط", "مهام", "التقييم", "إشارات"], rows, empty_text="لا أيام عمل بعد"), title="آخر 30 يومًا"))
    return page(req, u["name"], body, active="emps", wide=True, back="/m/employees")


@route("POST", "/m/employee/<int:uid>", auth="manager", perm="employees.manage")
async def employee_save(req, uid: int):
    ctx = req.ctx
    data, err = _parse_user_form(req, "employee")
    if err:
        return ui.flash_redirect(f"/m/employee/{uid}", "err", err)

    def go(c):
        _user_or_404(c, ctx, uid, "employee")
        c.execute("UPDATE users SET name=?, phone=?, daily_new=?, shift_hours=? WHERE id=?", (data["name"], data["phone"], data["daily_new"], data["shift_hours"], uid))
        db.emit(c, ctx.cid, "user.updated", actor=ctx.uid, user=uid, data={"name": data["name"], "daily_new": data["daily_new"], "shift_hours": data["shift_hours"]})

    await db.write(go)
    return ui.flash_redirect(f"/m/employee/{uid}", "ok", "تم الحفظ")


async def _reset_password(req, uid: int, role: str, back: str):
    ctx = req.ctx
    temp = security.generate_password()
    hashed = await asyncio.to_thread(security.hash_password, temp)

    def go(c):
        u = _user_or_404(c, ctx, uid, role)
        c.execute("UPDATE users SET password_hash=?, must_change_password=1, failed_logins=0, locked_until=NULL WHERE id=?", (hashed, uid))
        security.end_user_sessions(c, uid)
        db.emit(c, ctx.cid, "user.password_reset", actor=ctx.uid, user=uid, data={"name": u["name"]})
        return u

    u = await db.write(go)
    return credentials_page(req, "كلمة مرور جديدة", u["name"], u["username"], temp, back)


@route("POST", "/m/employee/<int:uid>/reset", auth="manager", perm="employees.manage")
async def employee_reset(req, uid: int):
    return await _reset_password(req, uid, "employee", f"/m/employee/{uid}")


@route("POST", "/m/employee/<int:uid>/active", auth="manager", perm="employees.manage")
async def employee_active(req, uid: int):
    ctx = req.ctx

    def go(c):
        u = _user_or_404(c, ctx, uid, "employee")
        if u["active"]:
            c.execute("UPDATE users SET active=0 WHERE id=?", (uid,))
            security.end_user_sessions(c, uid)
            sh = work.current_shift(c, uid)
            if sh:
                work.close_day(c, u, sh, ctx.settings, {}, auto=True)
            rel = leadlib.release_user_leads(c, ctx.cid, uid, ctx.uid)
            db.emit(c, ctx.cid, "user.deactivated", actor=ctx.uid, user=uid, data={"name": u["name"], **rel})
            return f"أُوقف الحساب. عاد {rel['returned_new']} رقمًا جديدًا للمخزون، و{rel['waiting']} متابعة بلا موظف."
        c.execute("UPDATE users SET active=1 WHERE id=?", (uid,))
        db.emit(c, ctx.cid, "user.activated", actor=ctx.uid, user=uid, data={"name": u["name"]})
        return "فُعّل الحساب"

    msg = await db.write(go)
    return ui.flash_redirect(f"/m/employee/{uid}", "ok", msg)


# ---- managers (owner only)
@route("GET", "/m/team", auth="manager", perm="managers.manage")
async def team(req):
    ctx = req.ctx
    rows = await db.read(lambda c: c.execute("SELECT * FROM users WHERE company_id=? AND role IN ('owner','manager') ORDER BY role DESC, name", (ctx.cid,)).fetchall())
    out = []
    for u in rows:
        out.append([link(f"/m/team/{u['id']}", u["name"]) if u["role"] == "manager" else e(u["name"]), f'<span class="ltr">{e(u["username"])}</span>',
                    e(consts.ROLE_LABELS[u["role"]]), ui.badge("نشط", "ok") if u["active"] else ui.badge("موقوف", "bad"),
                    e(ui.ago(u["last_login_at"]) if u["last_login_at"] else "لم يدخل")])
    note = '<p class="sub mt">المالك يملك كل الصلاحيات دائمًا. المدير يأخذ الصلاحيات التي تحددها له.</p>'
    return page(req, "المدراء", card(table(["الاسم", "الدخول", "الدور", "الحساب", "آخر دخول"], out) + note, title="المدراء والصلاحيات",
                                    actions=button("إضافة مدير", href="/m/team/new", icon_name="plus", small=True)), active="team", wide=True)


@route("GET", "/m/team/new", auth="manager", perm="managers.manage")
async def team_new(req):
    return page(req, "إضافة مدير", card(form(req, "/m/team/new", user_form(req, "manager") + button("إضافة وتوليد كلمة مرور مؤقتة", big=True)), title="مدير جديد"),
                active="team", back="/m/team")


@route("POST", "/m/team/new", auth="manager", perm="managers.manage")
async def team_create(req):
    return await _create_user(req, "manager", "/m/team")


@route("GET", "/m/team/<int:uid>", auth="manager", perm="managers.manage")
async def team_edit(req, uid: int):
    ctx = req.ctx
    u = await db.read(lambda c: _user_or_404(c, ctx, uid, "manager"))
    acts = (form(req, f"/m/team/{uid}/reset", button("إعادة تعيين كلمة المرور", kind="ghost", small=True, confirm="متابعة؟"), cls="inline")
            + form(req, f"/m/team/{uid}/active", button("إيقاف" if u["active"] else "تفعيل", kind="danger" if u["active"] else "soft", small=True), cls="inline"))
    return page(req, u["name"], card(form(req, f"/m/team/{uid}", user_form(req, "manager", dict(u)) + button("حفظ", big=True)), title=u["name"], actions=acts),
                active="team", back="/m/team")


@route("POST", "/m/team/<int:uid>", auth="manager", perm="managers.manage")
async def team_save(req, uid: int):
    ctx = req.ctx
    data, err = _parse_user_form(req, "manager")
    if err:
        return ui.flash_redirect(f"/m/team/{uid}", "err", err)

    def go(c):
        _user_or_404(c, ctx, uid, "manager")
        c.execute("UPDATE users SET name=?, phone=?, perms=? WHERE id=?", (data["name"], data["phone"], data["perms"], uid))
        db.emit(c, ctx.cid, "user.updated", actor=ctx.uid, user=uid, data={"name": data["name"], "perms": data["perms"]})

    await db.write(go)
    return ui.flash_redirect(f"/m/team/{uid}", "ok", "تم الحفظ")


@route("POST", "/m/team/<int:uid>/reset", auth="manager", perm="managers.manage")
async def team_reset(req, uid: int):
    return await _reset_password(req, uid, "manager", f"/m/team/{uid}")


@route("POST", "/m/team/<int:uid>/active", auth="manager", perm="managers.manage")
async def team_active(req, uid: int):
    ctx = req.ctx

    def go(c):
        u = _user_or_404(c, ctx, uid, "manager")
        new = 0 if u["active"] else 1
        c.execute("UPDATE users SET active=? WHERE id=?", (new, uid))
        if not new:
            security.end_user_sessions(c, uid)
        db.emit(c, ctx.cid, "user.deactivated" if not new else "user.activated", actor=ctx.uid, user=uid, data={"name": u["name"]})

    await db.write(go)
    return ui.flash_redirect(f"/m/team/{uid}", "ok", "تم")


# ------------------------------------------------------------------------------------------------ distributing new numbers
@route("GET", "/m/distribute", auth="manager", perm="leads.assign")
async def distribute(req):
    ctx = req.ctx
    s = ctx.settings
    allow = bool(s["allow_landline"])
    where = leadlib.pool_where(allow)

    def go(c):
        pool = leadlib.pool_count(c, ctx.cid, allow)
        emps = c.execute("SELECT u.id, u.name, (SELECT COUNT(*) FROM leads l WHERE l.owner_id=u.id AND l.status='new') AS fresh FROM users u "
                         "WHERE u.company_id=? AND u.role='employee' AND u.active=1 ORDER BY u.name", (ctx.cid,)).fetchall()
        batches = c.execute(f"SELECT b.id, b.filename, (SELECT COUNT(*) FROM leads l WHERE l.batch_id=b.id AND {leadlib.pool_where(allow, 'l')}) AS n "
                            f"FROM lead_batches b WHERE b.company_id=? AND b.status='committed' ORDER BY b.id DESC LIMIT 20", (ctx.cid,)).fetchall()
        cities = c.execute(f"SELECT city, COUNT(*) n FROM leads WHERE company_id=? AND {where} AND city IS NOT NULL AND city<>'' GROUP BY city ORDER BY n DESC LIMIT 25", (ctx.cid,)).fetchall()
        return pool, emps, batches, cities

    pool, emps, batches, cities = await db.read(go)
    if not emps:
        return page(req, "التوزيع", card(ui.empty("أضف موظفين أولًا", action_html=button("إضافة موظف", href="/m/employees/new"))), active="dist")
    boxes = "".join(f'<label class="check"><input type="checkbox" name="emp" value="{u["id"]}"><span>{e(u["name"])}<small>معه {u["fresh"]} رقمًا جديدًا لم يُتصل به</small></span></label>' for u in emps)
    bopts = [("", "كل الملفات")] + [(b["id"], f"{b['filename']} ({b['n']} متبقٍ)") for b in batches]
    copts = [("", "كل المدن")] + [(r["city"], f"{r['city']} ({r['n']})") for r in cities]
    body = (card(f'<p>الأرقام الجديدة غير الموزعة في المخزون: <b>{pool}</b></p><p class="sub">الموظف يسحب أرقامه تلقائيًا كل صباح عند بدء يومه ({s["daily_new"]} افتراضيًا). '
                 f'استخدم هذه الصفحة لتخصيص أرقام لموظف بعينه (مثلًا مدينة أو ملف معيّن) قبل أن يسحبها غيره.</p>', title="التوزيع")
            + card(form(req, "/m/distribute", f'<h3>الموظفون</h3>{boxes}<div class="row"><div style="flex:1">{field("إجمالي الأرقام", "total", min(pool, 50 * len(emps)), type_="number", min_=1, max_=100000, required=True, hint="تُقسم بالتساوي على المحددين")}</div></div>'
                                                      f'<div class="row"><div style="flex:1">{select("من ملف", "batch", bopts)}</div><div style="flex:1">{select("المدينة", "city", copts)}</div></div>'
                                                      + button("وزّع الأرقام", big=True, confirm="تأكيد التوزيع؟")), title="توزيع أرقام جديدة"))
    return page(req, "التوزيع", body, active="dist")


@route("POST", "/m/distribute", auth="manager", perm="leads.assign")
async def distribute_post(req):
    ctx = req.ctx
    s = ctx.settings
    emp_ids = [i for i in (util.to_int(x) for x in req.fl("emp")) if i]
    total = util.to_int(req.f("total"), 0) or 0
    batch, city = util.to_int(req.f("batch")), req.f("city")
    if not emp_ids or total <= 0:
        return ui.flash_redirect("/m/distribute", "err", "اختر موظفًا واحدًا على الأقل وعددًا")

    def go(c):
        valid = [r["id"] for r in c.execute(f"SELECT id FROM users WHERE company_id=? AND role='employee' AND active=1 AND id IN ({','.join('?' * len(emp_ids))}) ORDER BY name",
                                            (ctx.cid, *emp_ids))]
        if not valid:
            return 0, 0
        sql = f"SELECT id FROM leads WHERE company_id=? AND {leadlib.pool_where(bool(s['allow_landline']))}"
        args: list[Any] = [ctx.cid]
        if batch:
            sql += " AND batch_id=?"
            args.append(batch)
        if city:
            sql += " AND city=?"
            args.append(city)
        sql += " ORDER BY id LIMIT ?"
        args.append(total)
        ids = [r["id"] for r in c.execute(sql, args)]
        per, extra = divmod(len(ids), len(valid))
        pos = moved = 0
        for i, uid in enumerate(valid):
            n = per + (1 if i < extra else 0)
            moved += leadlib.assign(c, ctx.cid, ids[pos:pos + n], uid, ctx.uid, "manual")
            pos += n
        return moved, len(valid)

    moved, k = await db.write(go)
    if not moved:
        return ui.flash_redirect("/m/distribute", "warn", "لا توجد أرقام مطابقة في المخزون")
    return ui.flash_redirect("/m/distribute", "ok", f"وُزّع {moved} رقمًا على {k} موظفين")
