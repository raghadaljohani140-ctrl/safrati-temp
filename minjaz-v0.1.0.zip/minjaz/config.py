"""Settings read from the environment. None of them is a secret."""
from __future__ import annotations

import os
from pathlib import Path


def _int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except ValueError:
        return default


DATA_DIR = Path(os.environ.get("DATA_DIR", "./data")).resolve()
PORT = _int("PORT", 8095)
HOST = os.environ.get("HOST", "0.0.0.0")
SITE_URL = os.environ.get("SITE_URL", "").rstrip("/")  # https://minjaz.example.com (used for personal links)
COOKIE_SECURE = os.environ.get("COOKIE_SECURE", "1") == "1"
REAL_IP_HEADER = os.environ.get("REAL_IP_HEADER", "").strip()  # e.g. X-Forwarded-For, only when a trusted proxy sets it
LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO").upper()
MAX_UPLOAD_MB = _int("MAX_UPLOAD_MB", 12)
MAX_IMPORT_ROWS = _int("MAX_IMPORT_ROWS", 100000)
BACKUP_HOUR_LOCAL = _int("BACKUP_HOUR", 0)  # hour (UTC) after which the day's backup is made; 0 = 03:00 in Riyadh
KEEP_DAILY_BACKUPS = _int("KEEP_DAILY_BACKUPS", 14)
KEEP_WEEKLY_BACKUPS = _int("KEEP_WEEKLY_BACKUPS", 8)
DEFAULT_TZ = os.environ.get("TZ", "Asia/Riyadh") or "Asia/Riyadh"


def db_path() -> Path:
    return DATA_DIR / "minjaz.db"


def backups_dir() -> Path:
    return DATA_DIR / "backups"


def uploads_dir() -> Path:
    return DATA_DIR / "uploads"
