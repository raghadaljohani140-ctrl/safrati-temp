"""The background loop: closes forgotten days, tidies old sessions, makes the daily backup and the weekly restore test.

It runs inside the web process (one process, one small container). Every step is guarded, so a failing step is logged and tried again
next time; it can never stop the server.
"""
from __future__ import annotations

import asyncio
import logging

from . import backup, db, security, work

log = logging.getLogger("minjaz.scheduler")
TICK = 60


async def _step(name: str, fn, *args) -> None:
    try:
        await fn(*args)
    except Exception:
        log.exception("scheduled step failed: %s", name)


async def close_forgotten_days() -> None:
    n = await db.write(work.auto_close_due)
    if n:
        log.info("closed %d forgotten day(s)", n)


async def tidy_sessions() -> None:
    await db.write(security.purge_sessions)


async def backups() -> None:
    kind = await asyncio.to_thread(backup.due_today)
    if not kind:
        return
    info = await asyncio.to_thread(backup.make_backup, kind)
    log.info("backup %s: %s", kind, "ok" if info["ok"] else info["note"])
    if info["ok"] and kind == "weekly":
        test = await asyncio.to_thread(backup.restore_test)
        log.info("restore test: %s", "ok" if test["ok"] else test["note"])


async def run() -> None:
    tick = 0
    await asyncio.sleep(5)
    while True:
        await _step("close-days", close_forgotten_days)
        if tick % 30 == 0:
            await _step("sessions", tidy_sessions)
            await _step("backups", backups)
        tick += 1
        await asyncio.sleep(TICK)
