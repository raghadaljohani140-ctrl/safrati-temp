"""The comparison page: the team's funnel next to the platform's own numbers, and where every number came from."""
from __future__ import annotations

from . import compare, db, reports, ui, util
from .routes import route
from .ui import badge, button, card, e, field, form, notice_box, page, table, textarea
from .views_reports import valid_day
from .web import HttpError, redirect

KINDS = {"week": "أسبوع", "month": "شهر"}


def verdict_badge(v: str) -> str:
    label, tone = compare.VERDICTS.get(v, (v, ""))
    return badge(label, tone)


def source_line(text: str) -> str:
    return f'<span class="stat-s">{e(text)}</span>'


# ------------------------------------------------------------------------------------------------ the page
@route("GET", "/m/compare", auth="manager", perm="compare.manage")
async def compare_home(req):
    ctx = req.ctx
    s = ctx.settings
    today = util.local_date(util.now(), ctx.tz)
    kind = req.q("kind") if req.q("kind") in KINDS else "week"
    start, end = reports.period(kind, valid_day(req.q("ref")) or today)

    def go(c):
        rows = reports.range_rows(c, ctx.cid, start, end, s)
        names = {r["id"]: r["name"] for r in c.execute("SELECT id, name FROM users WHERE company_id=?", (ctx.cid,))}
        deltas = compare.period_deltas(c, ctx.cid, start, end)
        daily = compare.daily_table(c, ctx.cid)
        imports = c.execute("SELECT * FROM ext_imports WHERE company_id=? ORDER BY id DESC LIMIT 12", (ctx.cid,)).fetchall()
        in_period = db.scalar(c, "SELECT COUNT(*) FROM ext_imports WHERE company_id=? AND substr(at,1,10) BETWEEN ? AND ?", ctx.cid, start, end, default=0)
        unresolved = db.scalar(c, "SELECT COUNT(*) FROM ext_rows WHERE company_id=? AND verdict IN ('late','unmatched')", ctx.cid, default=0)
        return rows, names, deltas, daily, imports, in_period, unresolved

    rows, names, deltas, daily, imports, in_period, unresolved = await db.read(go)
    tot = reports.totals(rows)

    # 1) the team's funnel
    frows = []
    for r in sorted(rows, key=lambda x: -x["reg_confirmed"]):
        per100 = f'{r["reg_confirmed"] * 100 / r["calls"]:.1f}' if r["calls"] else "—"
        frows.append([e(r["name"]), str(r["calls"]), str(r["answered"]), str(r["interested"]), str(r["links_sent"]), str(r["links_opened"]),
                      str(r["reg_reported"]), f'<b>{r["reg_confirmed"]}</b>', per100])
    frows.append([f'<b>{e("المجموع")}</b>', *[f"<b>{tot[k]}</b>" for k in ("calls", "answered", "interested", "links_sent", "links_opened", "reg_reported", "reg_confirmed")],
                  f'{tot["reg_confirmed"] * 100 / tot["calls"]:.1f}' if tot["calls"] else "—"])
    funnel = table(["الموظف", "مكالمات", "ردّ العميل", "مهتمون", "روابط أُرسلت", "روابط فُتحت", "تسجيل مُبلَّغ", "تسجيل مؤكد", "مؤكد لكل 100 مكالمة"], frows,
                   empty_text="لا أيام عمل في هذه الفترة")
    src = ('<p class="sub mt">من أين جاء كل رقم: المكالمات والنتائج والروابط المُرسلة من سجل MINJAZ؛ الروابط المفتوحة من «الرابط الشخصي» لكل عميل؛ '
           f'«تسجيل مؤكد» من جدول الملاك الذي لصقته ({in_period} مرة في هذه الفترة) بقاعدة الإسناد: بعد أول تواصل وخلال {int(s["attribution_days"])} يومًا من آخره.</p>')

    # 2) what the platform itself shows
    if deltas["ok"]:
        last, base = deltas["last"], deltas["base"]
        tiles = ""
        for k, label in compare.FIELDS:
            d = deltas["delta"][k]
            tiles += ui.stat(label, f"{d:+d}" if d is not None else "—", sub=f'الآن {last[k]:,}' if last[k] is not None else "")
        who = names.get(last["entered_by"], "")
        cap = (f'كتبتَه يدويًا بتاريخ {last["day"]}' if last["entered_by"] == ctx.uid else f'كتبه {who} بتاريخ {last["day"]}') + f"، والفرق عن رقم {base['day']}"
        extra = ""
        if deltas["delta"]["owners"] and deltas["delta"]["owners"] > 0:
            extra = (f'<p class="mt">الفريق نُسب له <b>{tot["reg_confirmed"]}</b> تسجيلًا مؤكدًا من <b>{deltas["delta"]["owners"]}</b> مالكًا جديدًا في استراحتي في الفترة. '
                     f'الباقي جاء من مصادر أخرى أو لم يُلصق جدوله بعد.</p>')
        plat = (f'<div class="grid">{tiles}</div>{extra}<p class="sub mt">{e(cap)}{(" — " + e(deltas["note"])) if deltas["note"] else ""}</p>')
    else:
        plat = notice_box(deltas["why"] + ". اكتب أرقام استراحتي أدناه ليظهر الفرق هنا.", "info")

    seg = "".join(f'<a class="{"on" if k == kind else ""}" href="/m/compare?kind={k}&amp;ref={today}">{lbl}</a>' for k, lbl in KINDS.items())
    prev_s, _ = reports.previous_period(kind, start)
    label = f"من {ui.fmt_day(start, weekday=False)} إلى {ui.fmt_day(end, weekday=False)}"
    head = (f'<div class="seg">{seg}</div><div class="row between mt"><a class="btn ghost sm" href="/m/compare?kind={kind}&amp;ref={prev_s}">السابق</a>'
            f'<strong>{e(label)}</strong>' + (f'<a class="btn ghost sm" href="/m/compare?kind={kind}&amp;ref={util.add_days(end, 1)}">التالي</a>' if end < today else "<span></span>") + "</div>")

    alert = ""
    if unresolved:
        alert = notice_box(f"{unresolved} صفًا في الجداول الملصوقة ينتظر قرارك (متأخر أو غير مطابَق). افتح الجدول المعني من القائمة أدناه.", "warn")

    # 3) typed numbers
    drows = []
    for d in daily:
        r = d["row"]
        cells = []
        for k, _ in compare.FIELDS:
            val = r[k]
            dl = d["delta"][k]
            cells.append(f'{val:,}' + (f' <span class="delta {"up" if dl > 0 else "down" if dl < 0 else "flat"}">{dl:+d}</span>' if dl is not None else "") if val is not None else "—")
        since = f' <span class="sub">(منذ {d["since"]} يومًا)</span>' if d["since"] and d["since"] > 1 else ""
        drows.append([e(ui.fmt_day(r["day"], weekday=False)) + since, *cells, e(names.get(r["entered_by"], "")) + f'<div class="sub">{e(ui.fmt_dt(r["entered_at"], ctx.tz))}</div>',
                      e(r["note"] or "")])
    daily_form = form(req, "/m/compare/daily", (
        f'<div class="grid two">{field("التاريخ", "day", today, type_="date", required=True, max_=today)}</div>'
        + '<div class="grid two">' + "".join(field(label, k, "", type_="number", min_=0, max_=1000000000, inputmode="numeric", required=True) for k, label in compare.FIELDS) + "</div>"
        + field("ملاحظة (اختياري)", "note", "", maxlength=200) + button("حفظ أرقام اليوم", icon_name="check")))
    paste_form = form(req, "/m/compare/paste", (
        textarea("جدول الملاك", "text", "", rows=7, maxlength=300000, required=True,
                 hint="افتح صفحة «الملاك» في لوحة استراحتي، حدّد الجدول وانسخه، ثم الصقه هنا كما هو. لا نقرأ من استراحتي شيئًا بأنفسنا.")
        + button("مطابقة مع العملاء", icon_name="check")))
    irows = [[f'<a href="/m/compare/import/{i["id"]}">{e(ui.fmt_dt(i["at"], ctx.tz))}</a>', e(names.get(i["by_user"], "")), str(i["rows"]), str(i["matched"]), str(i["attributed"])]
             for i in imports]

    body = (card(head + alert, title="المقارنة مع استراحتي", sub="تقرير الفريق بجانب أرقام المنصة")
            + card(funnel + src, title="قمع الفريق في الفترة")
            + card(plat, title="ما حدث في استراحتي في الفترة")
            + card(daily_form + table(["اليوم", "أصحاب الاستراحات", "إعلانات معتمدة", "مشاهدات", "ضغطات واتساب", "كتبه", "ملاحظة"], drows,
                                      empty_text="لم تكتب أرقامًا بعد"),
                   title="أرقام استراحتي اليوم", sub="اقرأها من لوحة الإدارة كما تظهر (تراكمية) واكتبها؛ نحسب الفرق عن آخر رقم")
            + card(paste_form + table(["اللصق", "بواسطة", "صفوف", "طابقت عميلًا", "نُسبت للفريق"], irows, empty_text="لم تلصق جدولًا بعد"), title="جدول الملاك",
                   sub="لمعرفة من سجّل فعلًا ولمن يُنسب التسجيل"))
    return page(req, "المقارنة", body, active="compare", wide=True)


# ------------------------------------------------------------------------------------------------ typed numbers
@route("POST", "/m/compare/daily", auth="manager", perm="compare.manage")
async def save_daily(req):
    ctx = req.ctx
    today = util.local_date(util.now(), ctx.tz)
    day = valid_day(req.f("day"))
    if not day or day > today or util.days_between(day, today) > 90:
        return ui.flash_redirect("/m/compare", "err", "اختر تاريخًا من اليوم إلى 90 يومًا مضت")
    vals: dict[str, int] = {}
    for k, label in compare.FIELDS:
        n = util.to_int(util.ascii_digits(req.f(k)).replace(",", ""))
        if n is None or n < 0 or n > 1_000_000_000:
            return ui.flash_redirect("/m/compare", "err", f"«{label}»: اكتب رقمًا صحيحًا")
        vals[k] = n
    res = await db.write(lambda c: compare.save_daily(c, ctx.cid, ctx.uid, day, vals, req.f("note")))
    msg = "حُفظت أرقام استراحتي"
    if res["lower"]:
        msg += "؛ لاحظ أن «" + "، ".join(res["lower"]) + "» أقل من آخر رقم مُدخل. إن كان خطأ فأعد إدخاله بالتاريخ نفسه."
    return ui.flash_redirect("/m/compare", "warn" if res["lower"] else "ok", msg)


# ------------------------------------------------------------------------------------------------ the pasted owners table
@route("POST", "/m/compare/paste", auth="manager", perm="compare.manage")
async def paste(req):
    ctx = req.ctx
    text = req.f_raw("text")
    if len(text.strip()) < 10:
        return ui.flash_redirect("/m/compare", "err", "الصق جدول الملاك أولًا")

    def go(c):
        return compare.import_owners(c, ctx.cid, ctx.uid, text, ctx.settings)

    try:
        iid = await db.write(go)
    except compare.CompareProblem as ex:
        return ui.flash_redirect("/m/compare", "err", str(ex))
    return redirect(f"/m/compare/import/{iid}")


@route("GET", "/m/compare/import/<int:iid>", auth="manager", perm="compare.manage")
async def import_view(req, iid: int):
    ctx = req.ctx

    def go(c):
        imp = db.one(c, "SELECT * FROM ext_imports WHERE id=? AND company_id=?", iid, ctx.cid)
        if not imp:
            raise HttpError(404, "غير موجود")
        rows = c.execute("SELECT r.*, l.name AS lead_name FROM ext_rows r LEFT JOIN leads l ON l.id=r.lead_id WHERE r.import_id=? ORDER BY r.row_no", (iid,)).fetchall()
        names = {r["id"]: r["name"] for r in c.execute("SELECT id, name FROM users WHERE company_id=?", (ctx.cid,))}
        return imp, rows, names

    imp, rows, names = await db.read(go)
    groups: dict[str, list] = {}
    for r in rows:
        groups.setdefault(r["verdict"], []).append(r)
    tiles = '<div class="grid">' + "".join(
        ui.stat(compare.VERDICTS[v][0], len(groups.get(v, [])), tone={"ours": "ok", "late": "warn", "unmatched": "warn", "bad": "bad"}.get(v, ""))
        for v in ("ours", "before", "late", "unmatched", "already", "bad")) + "</div>"
    blocks = ""
    for v in ("late", "unmatched", "ours", "before", "already", "bad"):
        items = groups.get(v)
        if not items:
            continue
        trs = []
        for r in items:
            who = e(names.get(r["user_id"], "")) if r["user_id"] else "—"
            act = ""
            if v == "late" and r["lead_id"] and r["user_id"]:
                act = form(req, f"/m/compare/row/{r['id']}/approve", button("اعتمد للموظف", small=True, kind="soft", confirm=f"يُحسب هذا التسجيل لـ {names.get(r['user_id'], '')}؟"), cls="inline")
            elif v == "unmatched":
                act = form(req, f"/m/compare/row/{r['id']}/link", f'<div class="row">{field("جوال العميل أو #رقمه", "q", "", ltr=True, required=True)}{button("ربط", small=True, kind="soft")}</div>')
            lead = f'<a href="/m/lead/{r["lead_id"]}">{e(r["lead_name"])}</a>' if r["lead_id"] else "—"
            trs.append([str(r["row_no"]), e(r["name"] or ""), ui.phone(r["phone"]) if r["phone"] else "—", (e(r["reg_date"]) + (f' <span class="muted num">{e(r["reg_time"])}</span>' if r["reg_time"] else "") if r["reg_date"] else "—"), str(r["ads"]) if r["ads"] is not None else "—",
                        lead, who, e(r["detail"] or "") + (f'<div class="sub">رُبط بواسطة {e(names.get(r["linked_by"], ""))}</div>' if r["linked_by"] else "")
                        + (f'<div class="sub">اعتمده {e(names.get(r["decided_by"], ""))}</div>' if r["decided_by"] else ""), act])
        open_attr = " open" if v in ("late", "unmatched") else ""
        blocks += (f'<details class="fold"{open_attr}><summary>{verdict_badge(v)} ({len(items)})</summary><div>'
                   + table(["#", "الاسم", "الجوال", "تاريخ التسجيل", "إعلانات", "العميل", "للموظف", "التفصيل", ""], trs) + "</div></details>")
    legend = (f'<p class="sub mt">القاعدة: التسجيل بعد أول تواصل وخلال {int(ctx.settings["attribution_days"])} يومًا من آخر تواصل (مكالمة أو رابط أُرسل) يُحسب للموظف. '
              f'إن كان في الجدول وقت التسجيل (بتوقيت الشركة) فالمقارنة بالدقيقة: من سجّل صباحًا ثم اتصلنا به ظهرًا لا يُحسب لأحد. '
              f'وإن كان التاريخ بلا ساعة فالتسجيل في يوم أول مكالمة يُحسب للموظف. تغيير المدة يسري على ما يلصق بعده؛ ما نُسب سابقًا لا يُعاد حسابه.</p>')
    body = (card(tiles + legend, title="نتيجة المطابقة", sub=f'{ui.fmt_dt(imp["at"], ctx.tz)} · {names.get(imp["by_user"], "")} · {imp["rows"]} صفًا')
            + card(blocks or ui.empty("لا صفوف"), title="الصفوف")
            + button("رجوع للمقارنة", href="/m/compare", kind="ghost", small=True))
    return page(req, "نتيجة مطابقة الملاك", body, active="compare", wide=True, back="/m/compare")


@route("POST", "/m/compare/row/<int:rid>/approve", auth="manager", perm="compare.manage")
async def row_approve(req, rid: int):
    ctx = req.ctx

    def go(c):
        r = db.one(c, "SELECT import_id FROM ext_rows WHERE id=? AND company_id=?", rid, ctx.cid)
        if not r:
            return None, False, "غير موجود"
        ok, msg = compare.approve_late(c, ctx.cid, rid, ctx.uid)
        return r["import_id"], ok, msg

    iid, ok, msg = await db.write(go)
    if iid is None:
        raise HttpError(404, "غير موجود")
    return ui.flash_redirect(f"/m/compare/import/{iid}", "ok" if ok else "err", "اعتُمد التسجيل للموظف" if ok else msg)


@route("POST", "/m/compare/row/<int:rid>/link", auth="manager", perm="compare.manage")
async def row_link(req, rid: int):
    ctx = req.ctx

    def go(c):
        r = db.one(c, "SELECT import_id FROM ext_rows WHERE id=? AND company_id=?", rid, ctx.cid)
        if not r:
            return None, False, "غير موجود"
        ok, msg = compare.link_row(c, ctx.cid, rid, req.f("q"), ctx.uid, ctx.settings)
        return r["import_id"], ok, msg

    iid, ok, msg = await db.write(go)
    if iid is None:
        raise HttpError(404, "غير موجود")
    return ui.flash_redirect(f"/m/compare/import/{iid}", "ok" if ok else "err", "رُبط الصف بالعميل" if ok else msg)
