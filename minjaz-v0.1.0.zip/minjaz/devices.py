"""Work phones: how a phone is linked to the company, and how its call log confirms the calls employees record.

Two promises the code keeps (not just the policy):
  * the phone may send only calls whose number is one of this company's clients; anything else is dropped on arrival and never stored;
  * nothing here records, listens to, or reads the content of a call: only the number, the start time, the length and the direction.

A phone is linked once with a short code the manager creates; after that it holds a long token that the server keeps only as a hash.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import sqlite3
from typing import Any

from . import db, phones, reports, util

CODE_MINUTES = 15
MAX_CALLS = 500
CALL_TYPES = ("outgoing", "incoming", "missed", "rejected")
MATCH_AFTER = dt.timedelta(minutes=15)   # the phone's call starts up to 15 minutes after "call" was pressed in the app
MATCH_BEFORE = dt.timedelta(minutes=5)   # ... or a few minutes before it, when the phone's clock is off
MAX_AGE = dt.timedelta(days=14)


class DeviceProblem(Exception):
    pass


def norm_code(code: str) -> str:
    return "".join(ch for ch in (code or "").lower() if ch.isalnum())


def new_code(c: sqlite3.Connection, company_id: int, actor: int, user_id: int | None, note: str) -> str:
    code = util.short_token(8)
    c.execute("INSERT INTO device_codes(company_id,user_id,code_hash,note,created_at,expires_at,created_by) VALUES(?,?,?,?,?,?,?)",
              (company_id, user_id, util.sha256(code), note[:80] or None, util.now_iso(), util.iso(util.now() + dt.timedelta(minutes=CODE_MINUTES)), actor))
    db.emit(c, company_id, "device.enroll_code", actor=actor, user=user_id, data={"note": note[:80], "minutes": CODE_MINUTES})
    return code


def enroll(c: sqlite3.Connection, code: str, name: str, model: str, app_version: str) -> dict[str, Any]:
    row = db.one(c, "SELECT * FROM device_codes WHERE code_hash=? AND used_at IS NULL AND expires_at>?", util.sha256(norm_code(code)), util.now_iso())
    if not row:
        raise DeviceProblem("الرمز غير صحيح أو انتهت مدته")
    token = util.token(24)
    name = (name or row["note"] or "جهاز عمل").strip()[:60]
    cur = c.execute("INSERT INTO devices(company_id,user_id,name,model,app_version,token_hash,created_at,created_by,last_seen_at) VALUES(?,?,?,?,?,?,?,?,?)",
                    (row["company_id"], row["user_id"], name, (model or "")[:60] or None, (app_version or "")[:20] or None, util.sha256(token),
                     util.now_iso(), row["created_by"], util.now_iso()))
    c.execute("UPDATE device_codes SET used_at=? WHERE id=?", (util.now_iso(), row["id"]))
    db.emit(c, row["company_id"], "device.enrolled", actor=None, user=row["user_id"], ref=cur.lastrowid, data={"name": name, "model": model[:60]})
    co = db.one(c, "SELECT name FROM companies WHERE id=?", row["company_id"])
    return {"device_id": cur.lastrowid, "token": token, "company": co["name"] if co else "", "user_id": row["user_id"]}


def authenticate(c: sqlite3.Connection, token: str) -> sqlite3.Row | None:
    if not token or len(token) < 20:
        return None
    return db.one(c, "SELECT d.* FROM devices d JOIN companies co ON co.id=d.company_id WHERE d.token_hash=? AND d.revoked_at IS NULL AND co.active=1", util.sha256(token))


def revoke(c: sqlite3.Connection, company_id: int, device_id: int, actor: int) -> bool:
    d = db.one(c, "SELECT * FROM devices WHERE id=? AND company_id=? AND revoked_at IS NULL", device_id, company_id)
    if not d:
        return False
    c.execute("UPDATE devices SET revoked_at=? WHERE id=?", (util.now_iso(), device_id))
    db.emit(c, company_id, "device.revoked", actor=actor, user=d["user_id"], ref=device_id, data={"name": d["name"]})
    return True


def parse_ts(v: Any) -> str | None:
    """Epoch milliseconds, epoch seconds or an ISO time -> our ISO form (UTC)."""
    try:
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            secs = v / 1000 if v > 1e11 else v
            return util.iso(dt.datetime.fromtimestamp(secs, util.UTC))
        if isinstance(v, str) and v.strip():
            t = v.strip()
            if t.lstrip("-").isdigit():
                return parse_ts(int(t))
            return util.iso(util.parse_iso(t))
    except (ValueError, OverflowError, OSError):
        return None
    return None


def watch(c: sqlite3.Connection, device: sqlite3.Row) -> dict[str, Any]:
    """Salted short hashes of the numbers still worth watching, so the phone can pick out the right calls without being sent the client list."""
    salt = util.token(8)
    rows = c.execute("SELECT phone FROM leads WHERE company_id=? AND status NOT IN ('wrong_number','not_interested') AND do_not_call=0 ORDER BY id DESC LIMIT 50000",
                     (device["company_id"],)).fetchall()
    hashes = [hashlib.sha256((salt + r["phone"].lstrip("+")).encode()).hexdigest()[:12] for r in rows]
    return {"salt": salt, "count": len(hashes), "hashes": hashes, "digits": "e164-without-plus", "algo": "sha256(salt+digits)[:12]"}


def ingest(c: sqlite3.Connection, device: sqlite3.Row, items: list[Any], s: dict) -> dict[str, int]:
    """Stores the phone's calls to known clients and ties each outgoing one to the attempt the employee started (evidence level 2)."""
    cid = device["company_id"]
    now = util.now()
    stats = {"received": len(items), "stored": 0, "matched": 0, "ignored": 0, "duplicate": 0}
    parsed: list[tuple[str, str, int, str]] = []
    for it in items[:MAX_CALLS]:
        if not isinstance(it, dict):
            stats["ignored"] += 1
            continue
        ph = phones.normalize_phone(it.get("number"))
        ts = parse_ts(it.get("started_at"))
        dur = util.to_int(it.get("duration_sec"))
        typ = str(it.get("type") or "").lower()
        if not ph.phone or not ts or dur is None or not 0 <= dur <= 6 * 3600 or typ not in CALL_TYPES:
            stats["ignored"] += 1
            continue
        started = util.parse_iso(ts)
        if started < now - MAX_AGE or started > now + dt.timedelta(minutes=10):
            stats["ignored"] += 1
            continue
        parsed.append((ts, ph.phone, dur, typ))
    stats["ignored"] += max(0, len(items) - MAX_CALLS)
    if not parsed:
        return stats
    wanted = sorted({p[1] for p in parsed})
    leads: dict[str, int] = {}
    for i in range(0, len(wanted), 400):
        part = wanted[i:i + 400]
        for r in c.execute(f"SELECT id, phone FROM leads WHERE company_id=? AND phone IN ({','.join('?' * len(part))})", (cid, *part)):
            leads[r["phone"]] = r["id"]
    resealed: set[tuple[int, str]] = set()
    for ts, number, dur, typ in sorted(parsed):
        lead_id = leads.get(number)
        if lead_id is None:  # not one of our clients: never stored
            stats["ignored"] += 1
            continue
        cur = c.execute("INSERT OR IGNORE INTO device_calls(company_id,device_id,number,started_at,duration_sec,call_type,lead_id,received_at) VALUES(?,?,?,?,?,?,?,?)",
                        (cid, device["id"], number, ts, dur, typ, lead_id, util.now_iso()))
        if cur.rowcount == 0:
            stats["duplicate"] += 1
            continue
        stats["stored"] += 1
        call_id = int(cur.lastrowid)
        if typ != "outgoing":
            continue
        started = util.parse_iso(ts)
        lo, hi = util.iso(started - MATCH_AFTER), util.iso(started + MATCH_BEFORE)
        q = ("SELECT id, user_id, shift_id, day, started_at, evidence FROM call_attempts WHERE company_id=? AND lead_id=? AND device_call_id IS NULL"
             " AND status IN ('open','recorded') AND evidence<2 AND started_at BETWEEN ? AND ?")
        args: list[Any] = [cid, lead_id, lo, hi]
        if device["user_id"]:
            q += " AND user_id=?"
            args.append(device["user_id"])
        cands = c.execute(q, args).fetchall()
        if not cands:
            continue
        best = min(cands, key=lambda r: abs((util.parse_iso(r["started_at"]) - started).total_seconds()))
        c.execute("UPDATE call_attempts SET device_call_id=?, duration_sec=?, evidence=2 WHERE id=?", (call_id, dur, best["id"]))
        c.execute("UPDATE device_calls SET attempt_id=? WHERE id=?", (best["id"], call_id))
        db.emit(c, cid, "device.call_matched", actor=None, user=best["user_id"], lead=lead_id, shift=best["shift_id"], ref=best["id"],
                data={"device": device["id"], "seconds": dur, "was": best["evidence"]})
        stats["matched"] += 1
        resealed.add((best["user_id"], best["day"]))
    c.execute("UPDATE devices SET last_seen_at=?, last_sync_at=? WHERE id=?", (util.now_iso(), util.now_iso(), device["id"]))
    for user_id, day in resealed:  # a closed day's report is re-sealed as a new version so it shows the better evidence; the old one stays
        sh = db.one(c, "SELECT status FROM shifts WHERE company_id=? AND user_id=? AND work_date=?", cid, user_id, day)
        if sh and sh["status"] != "open":
            reports.seal_day(c, cid, user_id, day, s, reason="device")
    return stats


def unrecorded_calls(c: sqlite3.Connection, company_id: int, days: int = 7) -> list[sqlite3.Row]:
    """Outgoing calls the phone saw that no employee started or recorded in the app: worth asking about."""
    since = util.iso(util.now() - dt.timedelta(days=days))
    return c.execute("SELECT dc.*, l.name AS lead_name, d.name AS device_name, d.user_id AS device_user FROM device_calls dc JOIN leads l ON l.id=dc.lead_id"
                     " JOIN devices d ON d.id=dc.device_id WHERE dc.company_id=? AND dc.call_type='outgoing' AND dc.attempt_id IS NULL AND dc.duration_sec>0"
                     " AND dc.started_at>=? ORDER BY dc.started_at DESC LIMIT 100", (company_id, since)).fetchall()
