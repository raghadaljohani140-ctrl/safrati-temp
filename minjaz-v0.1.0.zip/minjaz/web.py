"""A small asyncio HTTP/1.1 server and router. Standard library only; no framework."""
from __future__ import annotations

import asyncio
import gzip
import json
import logging
import mimetypes
import re
import signal
import time
import urllib.parse
from pathlib import Path
from typing import Any, Awaitable, Callable

log = logging.getLogger("minjaz.web")

REASONS = {200: "OK", 201: "Created", 204: "No Content", 301: "Moved Permanently", 302: "Found", 303: "See Other",
           304: "Not Modified", 400: "Bad Request", 401: "Unauthorized", 403: "Forbidden", 404: "Not Found",
           405: "Method Not Allowed", 408: "Request Timeout", 411: "Length Required", 413: "Payload Too Large",
           429: "Too Many Requests", 431: "Request Header Fields Too Large", 500: "Internal Server Error",
           501: "Not Implemented", 503: "Service Unavailable"}

HEADER_LIMIT = 32 * 1024
IDLE_TIMEOUT = 75
BODY_TIMEOUT = 60
MAX_CONNECTIONS = 300


class HttpError(Exception):
    def __init__(self, status: int, message: str = "") -> None:
        super().__init__(message or REASONS.get(status, ""))
        self.status = status
        self.message = message


# ------------------------------------------------------------------------------------------------ request
def parse_multipart(body: bytes, boundary: str) -> tuple[dict[str, list[str]], dict[str, tuple[str, bytes]]]:
    fields: dict[str, list[str]] = {}
    files: dict[str, tuple[str, bytes]] = {}
    delim = b"--" + boundary.encode("latin-1")
    for part in body.split(delim)[1:]:
        if part.startswith(b"--"):
            break
        if part.startswith(b"\r\n"):
            part = part[2:]
        head, sep, data = part.partition(b"\r\n\r\n")
        if not sep:
            continue
        if data.endswith(b"\r\n"):
            data = data[:-2]
        disp = ""
        for line in head.decode("utf-8", "replace").split("\r\n"):
            if line.lower().startswith("content-disposition:"):
                disp = line.split(":", 1)[1]
        name = re.search(r'\bname="([^"]*)"', disp)
        if not name:
            continue
        filename = re.search(r'\bfilename="([^"]*)"', disp)
        if filename is not None:
            if filename.group(1):
                files[name.group(1)] = (filename.group(1), data)
        else:
            fields.setdefault(name.group(1), []).append(data.decode("utf-8", "replace"))
    return fields, files


class Request:
    def __init__(self, method: str, target: str, headers: dict[str, str], body: bytes, ip: str) -> None:
        self.method = method.upper()
        self.target = target
        parts = urllib.parse.urlsplit(target)
        self.path = urllib.parse.unquote(parts.path) or "/"
        self.query = urllib.parse.parse_qs(parts.query, keep_blank_values=True)
        self.headers = headers
        self.body = body
        self.ip = ip
        self.cookies: dict[str, str] = {}
        for piece in headers.get("cookie", "").split(";"):
            k, sep, v = piece.strip().partition("=")
            if sep:
                self.cookies[k] = urllib.parse.unquote(v)
        self.ctx: Any = None
        self.params: dict[str, Any] = {}
        self._form: dict[str, list[str]] | None = None
        self._files: dict[str, tuple[str, bytes]] = {}

    # query string
    def q(self, name: str, default: str = "") -> str:
        v = self.query.get(name)
        return v[0].strip() if v else default

    # form body
    def _parse(self) -> None:
        if self._form is not None:
            return
        ctype = self.headers.get("content-type", "")
        self._form = {}
        if not self.body:
            return
        if ctype.startswith("application/x-www-form-urlencoded"):
            self._form = urllib.parse.parse_qs(self.body.decode("utf-8", "replace"), keep_blank_values=True)
        elif ctype.startswith("multipart/form-data"):
            m = re.search(r'boundary="?([^";]+)"?', ctype)
            if not m:
                raise HttpError(400, "طلب غير صالح")
            self._form, self._files = parse_multipart(self.body, m.group(1))

    def f(self, name: str, default: str = "") -> str:
        self._parse()
        v = (self._form or {}).get(name)
        return v[0].strip() if v else default

    def f_raw(self, name: str, default: str = "") -> str:
        self._parse()
        v = (self._form or {}).get(name)
        return v[0] if v else default

    def fl(self, name: str) -> list[str]:
        self._parse()
        return [x.strip() for x in (self._form or {}).get(name, [])]

    @property
    def form_keys(self) -> list[str]:
        self._parse()
        return list(self._form or {})

    def file(self, name: str) -> tuple[str, bytes] | None:
        self._parse()
        return self._files.get(name)

    def json(self) -> Any:
        try:
            return json.loads(self.body.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            raise HttpError(400, "JSON غير صالح")

    @property
    def host(self) -> str:
        return self.headers.get("host", "")

    @property
    def is_https(self) -> bool:
        return self.headers.get("x-forwarded-proto", "").lower() == "https"


# ------------------------------------------------------------------------------------------------ response
class Response:
    def __init__(self, body: bytes | str = b"", status: int = 200, content_type: str = "text/html; charset=utf-8",
                 headers: list[tuple[str, str]] | None = None) -> None:
        self.body = body.encode("utf-8") if isinstance(body, str) else body
        self.status = status
        self.content_type = content_type
        self.headers: list[tuple[str, str]] = list(headers or [])

    def header(self, name: str, value: str) -> "Response":
        self.headers.append((name, value))
        return self

    def cookie(self, name: str, value: str, *, max_age: int | None = None, secure: bool = True, http_only: bool = True,
               same_site: str = "Lax", path: str = "/") -> "Response":
        parts = [f"{name}={urllib.parse.quote(value, safe='')}", f"Path={path}", f"SameSite={same_site}"]
        if max_age is not None:
            parts.append(f"Max-Age={max_age}")
        if secure:
            parts.append("Secure")
        if http_only:
            parts.append("HttpOnly")
        self.headers.append(("Set-Cookie", "; ".join(parts)))
        return self

    def drop_cookie(self, name: str, secure: bool = True) -> "Response":
        return self.cookie(name, "", max_age=0, secure=secure)


def safe_next(url: str) -> str:
    """Only paths on this site are accepted as a place to go after sign-in."""
    if url.startswith("/") and not url.startswith("//") and "\\" not in url and "\n" not in url and "\r" not in url:
        return url
    return "/"


def html_response(body: str, status: int = 200) -> Response:
    return Response(body, status, "text/html; charset=utf-8", [("Cache-Control", "no-store")])


def redirect(url: str, status: int = 303) -> Response:
    return Response(b"", status, "text/plain; charset=utf-8", [("Location", url), ("Cache-Control", "no-store")])


def json_response(obj: Any, status: int = 200) -> Response:
    return Response(json.dumps(obj, ensure_ascii=False), status, "application/json; charset=utf-8", [("Cache-Control", "no-store")])


def text_response(text: str, status: int = 200) -> Response:
    return Response(text, status, "text/plain; charset=utf-8", [("Cache-Control", "no-store")])


def download(data: bytes | str, filename: str, content_type: str = "application/octet-stream") -> Response:
    quoted = urllib.parse.quote(filename)
    return Response(data, 200, content_type, [("Content-Disposition", f"attachment; filename*=UTF-8''{quoted}"),
                                              ("Cache-Control", "no-store")])


# ------------------------------------------------------------------------------------------------ routing
class Route:
    def __init__(self, method: str, pattern: str, handler: Callable[..., Awaitable[Response]], opts: dict[str, Any]) -> None:
        self.method = method
        self.pattern = pattern
        self.handler = handler
        self.opts = opts
        def part(m: re.Match) -> str:
            kind, name = m.group(1), m.group(2)
            return f"(?P<{name}>{ {'int': '[0-9]+', 'path': '.+'}.get(kind or '', '[^/]+') })"

        regex = re.sub(r"<(?:(int|path):)?(\w+)>", part, pattern)
        self.regex = re.compile("^" + regex + "$")
        self.int_params = set(re.findall(r"<int:(\w+)>", pattern))


class Router:
    def __init__(self) -> None:
        self.routes: list[Route] = []
        self._exact: dict[tuple[str, str], Route] = {}

    def add(self, method: str, pattern: str, handler: Callable[..., Awaitable[Response]], **opts: Any) -> None:
        route = Route(method.upper(), pattern, handler, opts)
        self.routes.append(route)
        if "<" not in pattern:
            self._exact[(route.method, pattern)] = route

    def route(self, method: str, pattern: str, **opts: Any):
        def deco(fn: Callable[..., Awaitable[Response]]):
            self.add(method, pattern, fn, **opts)
            return fn
        return deco

    def match(self, method: str, path: str) -> tuple[Route | None, dict[str, Any], bool]:
        """(route, params, path_exists_for_other_method)"""
        hit = self._exact.get((method, path))
        if hit:
            return hit, {}, True
        other = any(p == path for (_, p) in self._exact)
        for r in self.routes:
            m = r.regex.match(path)
            if not m:
                continue
            if r.method != method:
                other = True
                continue
            params = {k: (int(v) if k in r.int_params else v) for k, v in m.groupdict().items()}
            return r, params, True
        return None, {}, other


# ------------------------------------------------------------------------------------------------ static files
class Static:
    """Serves a fixed folder. Files are read once at start, so a request can never reach outside it."""

    ALLOWED = {".css", ".js", ".png", ".svg", ".ico", ".webmanifest", ".woff2", ".txt", ".json"}

    def __init__(self, folder: Path) -> None:
        self.files: dict[str, tuple[bytes, str]] = {}
        if folder.is_dir():
            for p in sorted(folder.iterdir()):
                if p.is_file() and p.suffix in self.ALLOWED:
                    ctype = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
                    if p.suffix == ".webmanifest":
                        ctype = "application/manifest+json"
                    if ctype.startswith("text/") or ctype in ("application/javascript", "application/json", "image/svg+xml"):
                        ctype += "; charset=utf-8" if "charset" not in ctype else ""
                    self.files[p.name] = (p.read_bytes(), ctype)

    def get(self, name: str, versioned: bool) -> Response | None:
        item = self.files.get(name)
        if not item:
            return None
        data, ctype = item
        cache = "public, max-age=31536000, immutable" if versioned else "public, max-age=600"
        return Response(data, 200, ctype, [("Cache-Control", cache)])


# ------------------------------------------------------------------------------------------------ the server
SECURITY_HEADERS = [
    ("X-Content-Type-Options", "nosniff"),
    ("X-Frame-Options", "DENY"),
    ("Referrer-Policy", "same-origin"),
    ("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=(), usb=()"),
    ("Cross-Origin-Opener-Policy", "same-origin"),
    ("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
                                "font-src 'self'; connect-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'; "
                                "object-src 'none'"),
]


class Server:
    def __init__(self, dispatch: Callable[[Request], Awaitable[Response]], body_limit: Callable[[str, str], int],
                 *, real_ip_header: str = "", secure_cookies: bool = True, hsts: bool = False) -> None:
        self.dispatch = dispatch
        self.body_limit = body_limit
        self.real_ip_header = real_ip_header.lower()
        self.hsts = hsts
        self.connections = 0
        self.started = time.time()
        self.requests = 0
        self.errors = 0

    def _client_ip(self, headers: dict[str, str], peer: str) -> str:
        if self.real_ip_header:
            raw = headers.get(self.real_ip_header, "")
            if raw:
                return raw.split(",")[-1].strip()[:64]
        return peer

    async def _read_request(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter, peer: str) -> Request | None:
        try:
            head = await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), timeout=IDLE_TIMEOUT)
        except asyncio.IncompleteReadError as e:
            if not e.partial:
                return None
            raise HttpError(400)
        except asyncio.LimitOverrunError:
            raise HttpError(431)
        except asyncio.TimeoutError:
            return None
        lines = head[:-4].decode("latin-1").split("\r\n")
        bits = lines[0].split(" ")
        if len(bits) != 3 or not bits[2].startswith("HTTP/"):
            raise HttpError(400)
        method, target, _version = bits
        headers: dict[str, str] = {}
        for line in lines[1:]:
            k, sep, v = line.partition(":")
            if not sep:
                raise HttpError(400)
            headers[k.strip().lower()] = v.strip()
        if "transfer-encoding" in headers:
            raise HttpError(501, "الترميز المجزأ غير مدعوم")
        length_raw = headers.get("content-length", "0") or "0"
        if not length_raw.isdigit():
            raise HttpError(400)
        length = int(length_raw)
        limit = self.body_limit(method.upper(), urllib.parse.urlsplit(target).path)
        if length > limit:
            raise HttpError(413, "الملف أكبر من الحد المسموح")
        if headers.get("expect", "").lower() == "100-continue" and length:
            writer.write(b"HTTP/1.1 100 Continue\r\n\r\n")
            await writer.drain()
        body = b""
        if length:
            try:
                body = await asyncio.wait_for(reader.readexactly(length), timeout=BODY_TIMEOUT)
            except (asyncio.IncompleteReadError, asyncio.TimeoutError):
                raise HttpError(408)
        return Request(method, target, headers, body, self._client_ip(headers, peer))

    def _serialize(self, resp: Response, req: Request | None, keep_alive: bool) -> bytes:
        body = resp.body
        head_only = req is not None and req.method == "HEAD"
        headers = list(resp.headers)
        names = {h[0].lower() for h in headers}
        if (req is not None and "gzip" in req.headers.get("accept-encoding", "") and len(body) > 1200 and "content-encoding" not in names
                and (resp.content_type.startswith(("text/", "application/json", "image/svg")))):
            body = gzip.compress(body, 5, mtime=0)
            headers.append(("Content-Encoding", "gzip"))
            headers.append(("Vary", "Accept-Encoding"))
        out = [f"HTTP/1.1 {resp.status} {REASONS.get(resp.status, 'OK')}", f"Content-Type: {resp.content_type}",
               f"Content-Length: {len(body)}", f"Connection: {'keep-alive' if keep_alive else 'close'}"]
        for k, v in SECURITY_HEADERS:
            if k.lower() not in names:
                out.append(f"{k}: {v}")
        if self.hsts:
            out.append("Strict-Transport-Security: max-age=31536000")
        for k, v in headers:
            out.append(f"{k}: {v}")
        data = ("\r\n".join(out) + "\r\n\r\n").encode("latin-1", "replace")
        return data if head_only or resp.status in (204, 304) else data + body

    async def _handle(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        peername = writer.get_extra_info("peername")
        peer = peername[0] if peername else ""
        self.connections += 1
        try:
            if self.connections > MAX_CONNECTIONS:
                writer.write(self._serialize(Response("busy", 503, "text/plain"), None, False))
                await writer.drain()
                return
            while True:
                req: Request | None = None
                try:
                    req = await self._read_request(reader, writer, peer)
                    if req is None:
                        return
                    t0 = time.perf_counter()
                    resp = await self.dispatch(req)
                    self.requests += 1
                    shown = req.path if not req.path.startswith("/l/") else "/l/…"
                    log.info("%s %s %s %.0fms", req.method, shown, resp.status, (time.perf_counter() - t0) * 1000)
                    keep = req.headers.get("connection", "").lower() != "close"
                except HttpError as e:
                    resp = Response(e.message or REASONS.get(e.status, "error"), e.status, "text/plain; charset=utf-8")
                    keep = False
                except (asyncio.CancelledError, ConnectionError):
                    raise
                except Exception:
                    self.errors += 1
                    log.exception("unhandled error")
                    resp = Response("حدث خطأ غير متوقع", 500, "text/plain; charset=utf-8")
                    keep = False
                writer.write(self._serialize(resp, req, keep))
                await writer.drain()
                if not keep:
                    return
        except (ConnectionError, asyncio.CancelledError, asyncio.IncompleteReadError, TimeoutError):
            pass
        finally:
            self.connections -= 1
            try:
                writer.close()
            except Exception:
                pass

    async def serve(self, host: str, port: int, on_ready: Callable[[], Awaitable[None]] | None = None,
                    background: list[Callable[[], Awaitable[None]]] | None = None) -> None:
        server = await asyncio.start_server(self._handle, host, port, limit=HEADER_LIMIT, backlog=128)
        stop = asyncio.Event()
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(sig, stop.set)
            except NotImplementedError:
                pass
        tasks = [asyncio.create_task(fn()) for fn in (background or [])]
        if on_ready:
            await on_ready()
        log.info("listening on %s:%s", host, port)
        await stop.wait()
        log.info("shutting down")
        server.close()
        for t in tasks:
            t.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        try:
            await asyncio.wait_for(server.wait_closed(), timeout=5)
        except asyncio.TimeoutError:
            pass
