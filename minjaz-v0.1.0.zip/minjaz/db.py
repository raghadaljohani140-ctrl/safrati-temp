"""The database: one SQLite file that belongs to MINJAZ alone.

Every table carries `company_id` from day one, so selling it to other companies later is an addition, not a rebuild.
`events` is the source of truth: append-only (the database itself refuses UPDATE and DELETE), and every row carries a SHA-256
fingerprint that includes the fingerprint of the row before it, so any later tampering shows.
"""
from __future__ import annotations

import asyncio
import contextlib
import json
import sqlite3
import threading
from pathlib import Path
from typing import Any, Callable, Iterator

from . import config, consts, settings as st, util

SCHEMA_VERSION = 1

SCHEMA = """
CREATE TABLE companies(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, slug TEXT NOT NULL UNIQUE,
  plan TEXT NOT NULL DEFAULT 'trial', plan_status TEXT NOT NULL DEFAULT 'active', valid_until TEXT,
  active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);

CREATE TABLE users(
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL REFERENCES companies(id),
  username TEXT NOT NULL COLLATE NOCASE UNIQUE, name TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('owner','manager','employee')),
  password_hash TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, is_platform_admin INTEGER NOT NULL DEFAULT 0,
  must_change_password INTEGER NOT NULL DEFAULT 0, daily_new INTEGER, shift_hours REAL, phone TEXT, perms TEXT,
  created_at TEXT NOT NULL, created_by INTEGER, last_login_at TEXT,
  failed_logins INTEGER NOT NULL DEFAULT 0, locked_until TEXT);
CREATE INDEX users_company ON users(company_id, role, active);

CREATE TABLE sessions(
  id INTEGER PRIMARY KEY, token_hash TEXT NOT NULL UNIQUE, user_id INTEGER NOT NULL REFERENCES users(id),
  company_id INTEGER NOT NULL, csrf TEXT NOT NULL, created_at TEXT NOT NULL, last_seen_at TEXT NOT NULL,
  expires_at TEXT NOT NULL, ip TEXT, ua TEXT);

CREATE TABLE settings(
  company_id INTEGER NOT NULL, key TEXT NOT NULL, value TEXT NOT NULL, PRIMARY KEY(company_id, key));

CREATE TABLE outcome_types(
  company_id INTEGER NOT NULL, code TEXT NOT NULL, label TEXT NOT NULL, sort INTEGER NOT NULL,
  needs_note INTEGER NOT NULL DEFAULT 0, needs_datetime INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1,
  PRIMARY KEY(company_id, code));

CREATE TABLE reasons(
  company_id INTEGER NOT NULL, code TEXT NOT NULL, label TEXT NOT NULL, needs_text INTEGER NOT NULL DEFAULT 0,
  sort INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1, PRIMARY KEY(company_id, code));

CREATE TABLE lead_batches(
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL, filename TEXT NOT NULL, sha256 TEXT NOT NULL,
  uploaded_by INTEGER NOT NULL, uploaded_at TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'mapping' CHECK(status IN ('mapping','preview','committed','cancelled')),
  mapping_json TEXT, counts_json TEXT, rows_total INTEGER NOT NULL DEFAULT 0, raw_path TEXT, committed_at TEXT);
CREATE INDEX batches_company ON lead_batches(company_id, status);

CREATE TABLE import_rows(
  batch_id INTEGER NOT NULL, row_no INTEGER NOT NULL, name TEXT, phone_raw TEXT, phone TEXT, phone_alt TEXT, city TEXT,
  source_url TEXT, employee TEXT, state TEXT NOT NULL, reason TEXT, lead_id INTEGER, line_type TEXT, maybe_same_id INTEGER,
  PRIMARY KEY(batch_id, row_no));

CREATE TABLE leads(
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL, name TEXT NOT NULL, phone TEXT NOT NULL, phone_raw TEXT, phone_alt TEXT,
  city TEXT, source_url TEXT, batch_id INTEGER, added_at TEXT NOT NULL, line_type TEXT NOT NULL DEFAULT 'mobile',
  owner_id INTEGER REFERENCES users(id), status TEXT NOT NULL DEFAULT 'new', status_at TEXT,
  attempts INTEGER NOT NULL DEFAULT 0, first_call_at TEXT, last_call_at TEXT, next_follow_up TEXT, next_follow_time TEXT,
  follow_step INTEGER NOT NULL DEFAULT 0, note_last TEXT, do_not_call INTEGER NOT NULL DEFAULT 0,
  maybe_same_id INTEGER, link_token TEXT UNIQUE, link_sent_at TEXT, link_sends INTEGER NOT NULL DEFAULT 0, link_opened_at TEXT,
  link_opens INTEGER NOT NULL DEFAULT 0, registered_at TEXT, confirmed_at TEXT, attribution TEXT, created_by INTEGER,
  UNIQUE(company_id, phone));
CREATE INDEX leads_owner ON leads(company_id, owner_id, status, next_follow_up);
CREATE INDEX leads_pool ON leads(company_id, owner_id, status, id);
CREATE INDEX leads_name ON leads(company_id, name);

CREATE TABLE assignments(
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL, lead_id INTEGER NOT NULL, user_id INTEGER, assigned_at TEXT NOT NULL,
  ended_at TEXT, reason TEXT, by_user_id INTEGER);
CREATE INDEX assignments_lead ON assignments(lead_id);

CREATE TABLE shifts(
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL, user_id INTEGER NOT NULL, work_date TEXT NOT NULL, started_at TEXT NOT NULL,
  ended_at TEXT, planned_end_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','closed','auto_closed')),
  last_seen_at TEXT NOT NULL, last_action_at TEXT NOT NULL, device_id INTEGER, close_note TEXT,
  UNIQUE(company_id, user_id, work_date));
CREATE TABLE breaks(
  id INTEGER PRIMARY KEY, shift_id INTEGER NOT NULL REFERENCES shifts(id), started_at TEXT NOT NULL, ended_at TEXT);
CREATE TABLE gaps(
  id INTEGER PRIMARY KEY, shift_id INTEGER NOT NULL REFERENCES shifts(id), company_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
  started_at TEXT NOT NULL, ended_at TEXT NOT NULL, kind TEXT NOT NULL CHECK(kind IN ('inactive','away')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','explained')), reason_code TEXT, reason_text TEXT, answered_at TEXT);

CREATE TABLE daily_plans(
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL, user_id INTEGER NOT NULL, shift_id INTEGER, plan_date TEXT NOT NULL,
  created_at TEXT NOT NULL, capacity INTEGER NOT NULL, new_target INTEGER NOT NULL, new_given INTEGER NOT NULL,
  followups INTEGER NOT NULL, trimmed INTEGER NOT NULL DEFAULT 0, pool_short INTEGER NOT NULL DEFAULT 0,
  UNIQUE(company_id, user_id, plan_date));
CREATE TABLE tasks(
  id INTEGER PRIMARY KEY, plan_id INTEGER NOT NULL REFERENCES daily_plans(id), company_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
  lead_id INTEGER NOT NULL REFERENCES leads(id), kind TEXT NOT NULL, position INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','done','reason')), attempt_id INTEGER, reason_code TEXT,
  reason_text TEXT, created_at TEXT NOT NULL, done_at TEXT, due_date TEXT, plan_date TEXT NOT NULL);
CREATE INDEX tasks_user ON tasks(company_id, user_id, plan_date, status);
CREATE INDEX tasks_lead ON tasks(lead_id, status);
CREATE INDEX tasks_plan ON tasks(plan_id, status, position);

CREATE TABLE notices(
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL, kind TEXT NOT NULL, user_id INTEGER, day TEXT, text TEXT NOT NULL,
  created_at TEXT NOT NULL, seen_at TEXT, seen_by INTEGER);
CREATE INDEX notices_open ON notices(company_id, seen_at, id);

CREATE TABLE call_attempts(
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL, lead_id INTEGER NOT NULL REFERENCES leads(id), user_id INTEGER NOT NULL,
  shift_id INTEGER, task_id INTEGER, day TEXT NOT NULL, started_at TEXT NOT NULL, phone TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','recorded','cancelled')), outcome TEXT, note TEXT,
  followup_date TEXT, followup_time TEXT, recorded_at TEXT, evidence INTEGER NOT NULL DEFAULT 1, duration_sec INTEGER,
  device_call_id INTEGER, cancel_reason TEXT, dnc INTEGER NOT NULL DEFAULT 0, was_first INTEGER NOT NULL DEFAULT 0);
CREATE INDEX attempts_user_day ON call_attempts(company_id, user_id, day);
CREATE INDEX attempts_lead ON call_attempts(lead_id);

CREATE TABLE corrections(
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL, attempt_id INTEGER NOT NULL REFERENCES call_attempts(id),
  old_outcome TEXT, new_outcome TEXT NOT NULL, reason TEXT NOT NULL, by_user_id INTEGER NOT NULL, at TEXT NOT NULL);

CREATE TABLE devices(
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL, user_id INTEGER, name TEXT NOT NULL, model TEXT, app_version TEXT,
  token_hash TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL, created_by INTEGER, last_seen_at TEXT, last_sync_at TEXT, revoked_at TEXT);
CREATE TABLE device_codes(
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL, user_id INTEGER, code_hash TEXT NOT NULL UNIQUE, note TEXT,
  created_at TEXT NOT NULL, expires_at TEXT NOT NULL, used_at TEXT, created_by INTEGER);
CREATE TABLE device_calls(
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL, device_id INTEGER NOT NULL REFERENCES devices(id), number TEXT NOT NULL,
  started_at TEXT NOT NULL, duration_sec INTEGER NOT NULL, call_type TEXT NOT NULL, attempt_id INTEGER, lead_id INTEGER,
  received_at TEXT NOT NULL, UNIQUE(device_id, started_at, number));
CREATE INDEX device_calls_lookup ON device_calls(company_id, number, started_at);

CREATE TABLE daily_reports(
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL, user_id INTEGER NOT NULL, work_date TEXT NOT NULL, version INTEGER NOT NULL,
  created_at TEXT NOT NULL, data TEXT NOT NULL, last_event_seq INTEGER NOT NULL, last_event_hash TEXT NOT NULL, seal TEXT NOT NULL,
  supersedes INTEGER, reason TEXT, UNIQUE(company_id, user_id, work_date, version));

CREATE TABLE ext_daily(
  company_id INTEGER NOT NULL, day TEXT NOT NULL, owners INTEGER, approved_ads INTEGER, views INTEGER, wa_clicks INTEGER, note TEXT,
  entered_by INTEGER NOT NULL, entered_at TEXT NOT NULL, PRIMARY KEY(company_id, day));
CREATE TABLE ext_imports(
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL, at TEXT NOT NULL, by_user INTEGER NOT NULL, rows INTEGER NOT NULL,
  matched INTEGER NOT NULL, attributed INTEGER NOT NULL, text_sha TEXT NOT NULL);
CREATE TABLE ext_rows(
  id INTEGER PRIMARY KEY, import_id INTEGER NOT NULL, company_id INTEGER NOT NULL, row_no INTEGER NOT NULL, phone TEXT, name TEXT, ads INTEGER,
  approved INTEGER, reg_date TEXT, reg_time TEXT, lead_id INTEGER, verdict TEXT NOT NULL, user_id INTEGER, detail TEXT, linked_by INTEGER, decided_by INTEGER);
CREATE INDEX ext_rows_import ON ext_rows(import_id, verdict);

CREATE TABLE events(
  id INTEGER PRIMARY KEY, company_id INTEGER NOT NULL, seq INTEGER NOT NULL, ts TEXT NOT NULL, day TEXT NOT NULL, type TEXT NOT NULL,
  actor_id INTEGER, user_id INTEGER, lead_id INTEGER, shift_id INTEGER, ref_id INTEGER, data TEXT NOT NULL,
  prev_hash TEXT NOT NULL, hash TEXT NOT NULL, UNIQUE(company_id, seq));
CREATE INDEX events_lead ON events(company_id, lead_id, seq);
CREATE INDEX events_user_day ON events(company_id, user_id, day, type);
CREATE INDEX events_type ON events(company_id, type, seq);
CREATE TRIGGER events_no_update BEFORE UPDATE ON events BEGIN SELECT RAISE(ABORT, 'events are append-only'); END;
CREATE TRIGGER events_no_delete BEFORE DELETE ON events BEGIN SELECT RAISE(ABORT, 'events are append-only'); END;
CREATE TRIGGER reports_no_update BEFORE UPDATE ON daily_reports BEGIN SELECT RAISE(ABORT, 'sealed reports never change'); END;
CREATE TRIGGER reports_no_delete BEFORE DELETE ON daily_reports BEGIN SELECT RAISE(ABORT, 'sealed reports never change'); END;
CREATE TRIGGER corrections_no_update BEFORE UPDATE ON corrections BEGIN SELECT RAISE(ABORT, 'corrections never change'); END;
CREATE TRIGGER corrections_no_delete BEFORE DELETE ON corrections BEGIN SELECT RAISE(ABORT, 'corrections never change'); END;

CREATE TABLE backup_log(
  id INTEGER PRIMARY KEY, at TEXT NOT NULL, kind TEXT NOT NULL, path TEXT, size INTEGER, sha256 TEXT, ok INTEGER NOT NULL, note TEXT);
CREATE TABLE platform(key TEXT PRIMARY KEY, value TEXT NOT NULL);
"""

_write_lock = threading.Lock()  # one writer at a time inside this process; SQLite enforces it across processes


def connect(path: Path | str | None = None) -> sqlite3.Connection:
    p = Path(path) if path else config.db_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(str(p), timeout=15, isolation_level=None)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("PRAGMA busy_timeout=15000")
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA synchronous=NORMAL")
    return c


def init(path: Path | str | None = None) -> None:
    c = connect(path)
    try:
        version = c.execute("PRAGMA user_version").fetchone()[0]
        if version == 0:
            c.executescript("BEGIN;" + SCHEMA + f"PRAGMA user_version={SCHEMA_VERSION}; COMMIT;")
        elif version > SCHEMA_VERSION:
            raise RuntimeError(f"database is newer (v{version}) than this program (v{SCHEMA_VERSION})")
        # later versions: add `if version < 2: ...` blocks here, each in one transaction
    finally:
        c.close()


@contextlib.contextmanager
def tx(write: bool = False, path: Path | str | None = None) -> Iterator[sqlite3.Connection]:
    c = connect(path)
    locked = False
    try:
        if write:
            _write_lock.acquire()
            locked = True
            c.execute("BEGIN IMMEDIATE")
        else:
            c.execute("BEGIN")
        yield c
        c.execute("COMMIT")
    except BaseException:
        with contextlib.suppress(sqlite3.Error):
            c.execute("ROLLBACK")
        raise
    finally:
        c.close()
        if locked:
            _write_lock.release()


def _run(write: bool, fn: Callable[..., Any], args: tuple, kwargs: dict) -> Any:
    with tx(write) as c:
        return fn(c, *args, **kwargs)


async def read(fn: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    return await asyncio.to_thread(_run, False, fn, args, kwargs)


async def write(fn: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    return await asyncio.to_thread(_run, True, fn, args, kwargs)


# ---------------------------------------------------------------- small query helpers
def one(c: sqlite3.Connection, sql: str, *params: Any) -> sqlite3.Row | None:
    return c.execute(sql, params).fetchone()


def all_(c: sqlite3.Connection, sql: str, *params: Any) -> list[sqlite3.Row]:
    return c.execute(sql, params).fetchall()


def scalar(c: sqlite3.Connection, sql: str, *params: Any, default: Any = None) -> Any:
    row = c.execute(sql, params).fetchone()
    return default if row is None or row[0] is None else row[0]


def platform_get(c: sqlite3.Connection, key: str, default: str = "") -> str:
    row = one(c, "SELECT value FROM platform WHERE key=?", key)
    return row["value"] if row else default


def platform_set(c: sqlite3.Connection, key: str, value: str) -> None:
    c.execute("INSERT INTO platform(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))


# ---------------------------------------------------------------- settings
def get_settings(c: sqlite3.Connection, company_id: int) -> dict[str, Any]:
    return st.load(c, company_id)


def set_setting(c: sqlite3.Connection, company_id: int, key: str, value: Any) -> None:
    c.execute("INSERT INTO settings(company_id,key,value) VALUES(?,?,?) ON CONFLICT(company_id,key) DO UPDATE SET value=excluded.value",
              (company_id, key, str(value)))


# ---------------------------------------------------------------- events: the append-only, hash-chained log
GENESIS = "0" * 64


def _tz(c: sqlite3.Connection, company_id: int) -> str:
    row = one(c, "SELECT value FROM settings WHERE company_id=? AND key='tz'", company_id)
    return row["value"] if row else st.DEFS["tz"][0]


def emit(c: sqlite3.Connection, company_id: int, type_: str, *, actor: int | None = None, user: int | None = None,
         lead: int | None = None, shift: int | None = None, ref: int | None = None, data: dict | None = None, day: str | None = None) -> int:
    """Append one event. Must be called inside a write transaction. Returns its sequence number.

    `day` is the working day the event belongs to. It is the day it was written unless the event is about an earlier date
    (a registration confirmed today that happened last Tuesday). The real time is always in `ts`, and both are in the hash."""
    ts = util.now_iso()
    day = day or util.local_date(ts, _tz(c, company_id))
    last = one(c, "SELECT seq, hash FROM events WHERE company_id=? ORDER BY seq DESC LIMIT 1", company_id)
    seq = (last["seq"] if last else 0) + 1
    prev = last["hash"] if last else GENESIS
    payload = util.canon(data or {})
    digest = util.sha256(f"{prev}|{company_id}|{seq}|{ts}|{day}|{type_}|{actor}|{user}|{lead}|{shift}|{ref}|{payload}")
    c.execute(
        "INSERT INTO events(company_id,seq,ts,day,type,actor_id,user_id,lead_id,shift_id,ref_id,data,prev_hash,hash)"
        " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (company_id, seq, ts, day, type_, actor, user, lead, shift, ref, payload, prev, digest))
    return seq


def admin_log(c: sqlite3.Connection, company_id: int, actor: int | None, what: str, **data: Any) -> int:
    return emit(c, company_id, "admin." + what, actor=actor, data=data)


def verify_chain(c: sqlite3.Connection, company_id: int) -> dict[str, Any]:
    prev = GENESIS
    expected = 1
    count = 0
    for r in c.execute("SELECT * FROM events WHERE company_id=? ORDER BY seq", (company_id,)):
        digest = util.sha256(f"{prev}|{r['company_id']}|{r['seq']}|{r['ts']}|{r['day']}|{r['type']}|{r['actor_id']}|{r['user_id']}|"
                             f"{r['lead_id']}|{r['shift_id']}|{r['ref_id']}|{r['data']}")
        if r["seq"] != expected or r["prev_hash"] != prev or r["hash"] != digest:
            return {"ok": False, "checked": count, "bad_seq": r["seq"]}
        prev = r["hash"]
        expected += 1
        count += 1
    return {"ok": True, "checked": count, "bad_seq": None, "last_hash": prev}


def last_event(c: sqlite3.Connection, company_id: int) -> tuple[int, str]:
    row = one(c, "SELECT seq, hash FROM events WHERE company_id=? ORDER BY seq DESC LIMIT 1", company_id)
    return (row["seq"], row["hash"]) if row else (0, GENESIS)


# ---------------------------------------------------------------- creating a company with its defaults
def seed_company(c: sqlite3.Connection, company_id: int) -> None:
    for i, (code, label, needs_note, needs_dt) in enumerate(consts.OUTCOMES):
        c.execute("INSERT OR IGNORE INTO outcome_types(company_id,code,label,sort,needs_note,needs_datetime) VALUES(?,?,?,?,?,?)",
                  (company_id, code, label, i, needs_note, needs_dt))
    for i, (code, label, needs_text) in enumerate(consts.REASONS):
        c.execute("INSERT OR IGNORE INTO reasons(company_id,code,label,needs_text,sort) VALUES(?,?,?,?,?)",
                  (company_id, code, label, needs_text, i))


def create_company(c: sqlite3.Connection, name: str, slug: str | None = None) -> int:
    import re

    base = re.sub(r"[^a-z0-9]+", "-", (slug or "").lower()).strip("-") or "co"
    candidate, n = base, 1
    while one(c, "SELECT 1 FROM companies WHERE slug=?", candidate):
        n += 1
        candidate = f"{base}-{n}"
    cur = c.execute("INSERT INTO companies(name,slug,created_at) VALUES(?,?,?)", (name, candidate, util.now_iso()))
    company_id = int(cur.lastrowid)
    seed_company(c, company_id)
    return company_id


def notice(c: sqlite3.Connection, company_id: int, kind: str, text: str, user_id: int | None = None, day: str | None = None) -> None:
    """A line for the manager's dashboard ("plan trimmed", "day closed automatically"). Not evidence, so it may be dismissed."""
    if day is None:
        day = util.local_date(util.now(), _tz(c, company_id))
    if one(c, "SELECT 1 FROM notices WHERE company_id=? AND kind=? AND IFNULL(user_id,0)=IFNULL(?,0) AND day=? AND seen_at IS NULL",
           company_id, kind, user_id, day):
        return
    c.execute("INSERT INTO notices(company_id,kind,user_id,day,text,created_at) VALUES(?,?,?,?,?,?)",
              (company_id, kind, user_id, day, text, util.now_iso()))


def jload(text: str | None, default: Any = None) -> Any:
    try:
        return json.loads(text) if text else default
    except ValueError:
        return default
