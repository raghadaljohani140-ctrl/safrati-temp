"""Names that the interface and the reports share. Arabic labels are the defaults a company can rename."""
from __future__ import annotations

# The nine results the brief asks for, in the order they appear on the buttons.
OUTCOMES = [
    # code, label, needs_note, needs_datetime
    ("interested", "تم الرد والعميل مهتم", 1, 0),
    ("not_interested", "تم الرد وغير مهتم", 1, 0),
    ("no_answer", "لم يرد", 0, 0),
    ("phone_off", "الهاتف مغلق", 0, 0),
    ("wrong_number", "الرقم غير صحيح", 0, 0),
    ("call_later", "طلب الاتصال لاحقًا", 0, 1),
    ("asked_link", "طلب إرسال رابط المنصة", 0, 0),
    ("visited", "دخل إلى المنصة ولم يسجل", 1, 0),
    ("registered", "سجل في منصة استراحتي", 0, 0),
]
OUTCOME_CODES = [o[0] for o in OUTCOMES]
OUTCOME_LABELS_DEFAULT = {o[0]: o[1] for o in OUTCOMES}
ANSWERED = {"interested", "not_interested", "call_later", "asked_link", "visited", "registered"}
UNREACHED = {"no_answer", "phone_off"}

# outcome -> status of the client
OUTCOME_STATUS = {
    "interested": "interested",
    "not_interested": "not_interested",
    "no_answer": "no_answer",
    "phone_off": "phone_off",
    "wrong_number": "wrong_number",
    "call_later": "callback",
    "asked_link": "link_sent",
    "visited": "visited",
    "registered": "registered_reported",
}

STATUS_LABELS = {
    "new": "جديد",
    "interested": "مهتم",
    "not_interested": "غير مهتم",
    "no_answer": "لم يرد",
    "phone_off": "هاتف مغلق",
    "wrong_number": "رقم غير صحيح",
    "callback": "معاودة اتصال",
    "link_sent": "أُرسل الرابط",
    "visited": "دخل ولم يسجّل",
    "registered_reported": "سجّل (بإبلاغ الموظف)",
    "registered_confirmed": "سجّل مؤكد",
    "exhausted": "توقفت المحاولات",
    "do_not_call": "لا تتصل به",
}
# statuses that never come back into a plan
CLOSED_STATUSES = {"not_interested", "wrong_number", "registered_reported", "registered_confirmed", "exhausted"}

TASK_KINDS = [
    ("overdue", "متأخرة من الأيام السابقة"),
    ("callback", "معاودة اتصال اليوم"),
    ("interested", "مهتمون لم يسجّلوا"),
    ("link_check", "التحقق ممن أُرسل لهم الرابط"),
    ("followup", "لم يردّوا أو الهاتف مغلق"),
    ("new", "أرقام جديدة"),
]
TASK_KIND_LABELS = dict(TASK_KINDS)

EVIDENCE = {
    0: ("مُبلَّغة", "سجّل الموظف النتيجة بلا أي أثر آخر"),
    1: ("بدأت من التطبيق", "ضغط «اتصال» فسُجِّل الحدث بوقت الخادم، ولا يثبت أن المكالمة تمّت"),
    2: ("موثَّقة بسجل الجهاز", "وجد التطبيق المساعد مكالمة صادرة لنفس الرقم"),
    3: ("موثَّقة بكشف المشغّل", "ظهرت المكالمة في كشف الخط لدى المشغّل"),
}

# reasons a task may stay without a result
REASONS = [
    ("internet", "انقطاع الإنترنت", 0),
    ("device", "عطل الجهاز", 0),
    ("no_time", "لم يتسع الوقت", 0),
    ("manager", "تعليمات من المدير", 0),
    ("admin", "مهمة إدارية", 0),
    ("other", "أخرى", 1),
]

REASON_LABELS_DEFAULT = {r[0]: r[1] for r in REASONS}

GAP_REASONS = [
    ("break", "استراحة"),
    ("call", "مكالمة"),
    ("recording", "تسجيل نتيجة"),
    ("tech", "مشكلة تقنية"),
    ("other", "أخرى"),
]

ROLE_LABELS = {"owner": "مالك الحساب", "manager": "مدير", "employee": "موظف"}

PERMISSIONS = {
    "dashboard.view": "لوحة المراقبة",
    "leads.view": "قوائم العملاء",
    "leads.import": "استيراد الملفات",
    "leads.assign": "توزيع العملاء ونقلهم",
    "leads.export": "تصدير العملاء",
    "reports.view": "التقارير",
    "corrections.make": "تصحيح النتائج",
    "employees.manage": "إدارة الموظفين",
    "settings.manage": "الإعدادات",
    "devices.manage": "الأجهزة",
    "compare.manage": "المقارنة مع المنصة",
    "log.view": "سجل العمليات",
    "backup.download": "تصدير بيانات الشركة",
    "managers.manage": "إدارة المدراء",
}
ROLE_PERMS = {
    "owner": set(PERMISSIONS),
    "manager": set(PERMISSIONS) - {"managers.manage"},
    "employee": set(),
}

LEAD_PAGE = 50
