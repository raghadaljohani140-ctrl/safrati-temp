"""Clients list and detail, bulk moves, and the import flow (upload, map columns, preview, approve)."""
from __future__ import annotations

import asyncio
import sqlite3
import urllib.parse
from pathlib import Path
from typing import Any

from . import config, consts, db, importer, leads as leadlib, phones, reports, ui, util
from .routes import route
from .ui import badge, button, card, checkbox, e, field, form, icon, notice_box, page, pager, select, table, textarea
from .views_common import EVENT_LABELS, describe_event, evidence_badge, outcome_labels, reason_labels
from .web import HttpError, Response, download, redirect

PAGE_SIZE = consts.LEAD_PAGE
FOLLOW_GROUP = "follow"
LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"


def col_name(i: int) -> str:
    return LETTERS[i] if i < 26 else LETTERS[i // 26 - 1] + LETTERS[i % 26]


# ------------------------------------------------------------------------------------------------ list
def filters_from(req) -> tuple[str, list[Any], dict[str, str]]:
    where, args, qs = ["l.company_id=?"], [req.ctx.cid], {}
    status = req.q("status")
    if status == FOLLOW_GROUP:
        where.append(f"l.status IN ({','.join('?' * len(leadlib.FOLLOW_STATUSES))})")
        args += list(leadlib.FOLLOW_STATUSES)
        qs["status"] = status
    elif status in consts.STATUS_LABELS:
        where.append("l.status=?")
        args.append(status)
        qs["status"] = status
    owner = req.q("owner")
    if owner == "none":
        where.append("l.owner_id IS NULL")
        qs["owner"] = owner
    elif owner.isdigit():
        where.append("l.owner_id=?")
        args.append(int(owner))
        qs["owner"] = owner
    batch = req.q("batch")
    if batch.isdigit():
        where.append("l.batch_id=?")
        args.append(int(batch))
        qs["batch"] = batch
    city = req.q("city")
    if city:
        where.append("l.city=?")
        args.append(city)
        qs["city"] = city
    q = req.q("q")
    if q:
        digits = "".join(ch for ch in util.ascii_digits(q) if ch.isdigit())
        if len(digits) >= 4:
            where.append("l.phone LIKE ?")
            args.append(f"%{digits.lstrip('0')}%")
        else:
            where.append("l.name LIKE ?")
            args.append(f"%{q}%")
        qs["q"] = q
    if req.q("sort") == "due":
        qs["sort"] = "due"
    return " AND ".join(where), args, qs


@route("GET", "/m/leads", auth="manager", perm="leads.view")
async def leads_list(req):
    ctx = req.ctx
    tz = ctx.tz
    where, args, qs = filters_from(req)
    pg = max(1, util.to_int(req.q("page"), 1) or 1)
    order = "CASE WHEN l.next_follow_up IS NULL THEN 1 ELSE 0 END, l.next_follow_up, l.id DESC" if qs.get("sort") == "due" else "l.id DESC"

    def go(c):
        total = db.scalar(c, f"SELECT COUNT(*) FROM leads l WHERE {where}", *args, default=0)
        rows = c.execute(f"SELECT l.*, u.name AS owner_name FROM leads l LEFT JOIN users u ON u.id=l.owner_id WHERE {where} ORDER BY {order} LIMIT ? OFFSET ?",
                         (*args, PAGE_SIZE, (pg - 1) * PAGE_SIZE)).fetchall()
        emps = c.execute("SELECT id, name FROM users WHERE company_id=? AND role='employee' AND active=1 ORDER BY name", (ctx.cid,)).fetchall()
        batches = c.execute("SELECT id, filename FROM lead_batches WHERE company_id=? AND status='committed' ORDER BY id DESC LIMIT 30", (ctx.cid,)).fetchall()
        cities = [r["city"] for r in c.execute("SELECT city, COUNT(*) n FROM leads WHERE company_id=? AND city IS NOT NULL AND city<>'' GROUP BY city ORDER BY n DESC LIMIT 40", (ctx.cid,))]
        counts = dict(c.execute("SELECT status, COUNT(*) FROM leads WHERE company_id=? GROUP BY status", (ctx.cid,)).fetchall())
        return total, rows, emps, batches, cities, counts

    total, rows, emps, batches, cities, counts = await db.read(go)
    pages = max(1, -(-total // PAGE_SIZE))
    st_opts = [("", f"كل الحالات ({sum(counts.values())})"), (FOLLOW_GROUP, "قيد المتابعة")] + [(k, f"{v} ({counts.get(k, 0)})") for k, v in consts.STATUS_LABELS.items()]
    flt = form(req, "/m/leads", (
        f'<div class="filters">{select("الحالة", "status", st_opts, req.q("status"))}'
        f'{select("الموظف", "owner", [("", "الكل"), ("none", "بلا موظف")] + [(u["id"], u["name"]) for u in emps], req.q("owner"))}'
        f'{select("الملف", "batch", [("", "الكل")] + [(b["id"], b["filename"]) for b in batches], req.q("batch"))}'
        f'{select("المدينة", "city", [("", "الكل")] + [(x, x) for x in cities], req.q("city"))}'
        f'{field("بحث بالاسم أو الرقم", "q", req.q("q"))}{button("تصفية", icon_name="search", small=True)}</div>'), method="get")
    qstr = urllib.parse.urlencode({k: v for k, v in qs.items()})
    base = "/m/leads" + (f"?{qstr}" if qstr else "")
    can_assign = ctx.can("leads.assign")
    body_rows = []
    for r in rows:
        who = link_lead(r)
        if can_assign:
            who = f'<label class="rowchk"><input type="checkbox" name="ids" value="{r["id"]}" aria-label="تحديد">{who}</label>'
        due = e(r["next_follow_up"] or "")
        body_rows.append([who, ui.phone(r["phone"]), e(r["city"] or ""), ui.status_badge(r["status"]),
                          e(r["owner_name"] or "—"), str(r["attempts"]), e(ui.ago(r["last_call_at"]) if r["last_call_at"] else "—"), due])
    tbl = table(["الاسم", "الرقم", "المدينة", "الحالة", "الموظف", "اتصالات", "آخر اتصال", "المتابعة"], body_rows, empty_text="لا عملاء بهذه المواصفات")
    if can_assign and rows:
        select_all = '<label class="check all"><input type="checkbox" data-select-all="input[name=ids]"><span>تحديد كل عملاء هذه الصفحة</span></label>'
        emp_opts = [("pool", "← إرجاع للمخزون (بلا موظف)")] + [(u["id"], f"← {u['name']}") for u in emps]
        bulk = (f'<div class="row mt"><div style="flex:1">{select("نقل المحدد إلى", "to", emp_opts)}</div>'
                f'<input type="hidden" name="back" value="{e(base)}">{button("نقل", kind="soft", confirm="نقل العملاء المحددين؟")}</div>')
        tbl = form(req, "/m/leads/bulk", select_all + tbl + bulk)
    head = card(flt, title="العملاء", sub=f"{total:,} عميلًا", actions=((button("استيراد ملف", href="/m/import", icon_name="upload", small=True) if ctx.can("leads.import") else "")
                                                                          + (button("تصدير CSV", href="/m/export/leads.csv" + (f"?{qstr}" if qstr else ""), kind="ghost", icon_name="download", small=True)
                                                                             if ctx.can("leads.export") else "")))
    return page(req, "العملاء", head + card(tbl + pager(pg, pages, base)), active="leads", wide=True)


def link_lead(r) -> str:
    return f'<a href="/m/lead/{r["id"]}">{e(r["name"])}</a>'


@route("POST", "/m/leads/bulk", auth="manager", perm="leads.assign")
async def leads_bulk(req):
    ctx = req.ctx
    ids = [i for i in (util.to_int(x) for x in req.fl("ids")) if i]
    to = req.f("to")
    back = req.f("back") if req.f("back").startswith("/m/") else "/m/leads"
    if not ids:
        return ui.flash_redirect(back, "err", "حدّد عملاء أولًا")
    target = None if to == "pool" else util.to_int(to)

    def go(c):
        if target is not None and not db.one(c, "SELECT 1 FROM users WHERE id=? AND company_id=? AND role='employee' AND active=1", target, ctx.cid):
            return -1
        return leadlib.assign(c, ctx.cid, ids, target, ctx.uid, "manual")

    n = await db.write(go)
    if n < 0:
        return ui.flash_redirect(back, "err", "الموظف غير صالح")
    return ui.flash_redirect(back, "ok", f"نُقل {n} عميلًا" + (" (المغلقة ملفاتهم لا تُنقل)" if n < len(ids) else ""))


# ------------------------------------------------------------------------------------------------ one client
@route("GET", "/m/lead/<int:lead_id>", auth="manager", perm="leads.view")
async def lead_detail(req, lead_id: int):
    ctx = req.ctx
    tz = ctx.tz

    def go(c):
        lead = leadlib.get(c, ctx.cid, lead_id)
        if not lead:
            raise HttpError(404, "العميل غير موجود")
        names = {r["id"]: r["name"] for r in c.execute("SELECT id, name FROM users WHERE company_id=?", (ctx.cid,))}
        events = c.execute("SELECT * FROM events WHERE company_id=? AND lead_id=? ORDER BY seq DESC LIMIT 200", (ctx.cid, lead_id)).fetchall()
        attempts = c.execute(f"SELECT a.*, {reports.EFFECTIVE} AS eff FROM call_attempts a WHERE a.lead_id=? ORDER BY a.id DESC LIMIT 50", (lead_id,)).fetchall()
        emps = c.execute("SELECT id, name FROM users WHERE company_id=? AND role='employee' AND active=1 ORDER BY name", (ctx.cid,)).fetchall()
        batch = db.one(c, "SELECT filename FROM lead_batches WHERE id=?", lead["batch_id"]) if lead["batch_id"] else None
        same = db.one(c, "SELECT id, name FROM leads WHERE id=?", lead["maybe_same_id"]) if lead["maybe_same_id"] else None
        return lead, names, events, attempts, emps, batch, same, outcome_labels(c, ctx.cid), reason_labels(c, ctx.cid)

    lead, names, events, attempts, emps, batch, same, olabels, rlabels = await db.read(go)
    kv = (f'<dl class="kv"><dt>الرقم</dt><dd>{ui.phone(lead["phone"])}</dd>'
          + (f'<dt>رقم ثانٍ</dt><dd>{ui.phone(lead["phone_alt"])}</dd>' if lead["phone_alt"] else "")
          + f'<dt>المدينة</dt><dd>{e(lead["city"] or "—")}</dd><dt>الحالة</dt><dd>{ui.status_badge(lead["status"])}</dd>'
          f'<dt>الموظف</dt><dd>{e(names.get(lead["owner_id"], "بلا موظف"))}</dd><dt>الاتصالات</dt><dd>{lead["attempts"]}</dd>'
          f'<dt>المتابعة القادمة</dt><dd>{e(lead["next_follow_up"] or "—")} {e(lead["next_follow_time"] or "")}</dd>'
          f'<dt>الرابط الشخصي</dt><dd>أُرسل {lead["link_sends"]} · فُتح {lead["link_opens"]}</dd>'
          f'<dt>أُضيف</dt><dd>{e(ui.fmt_dt(lead["added_at"], tz))}{" من الملف " + e(batch["filename"]) if batch else ""}</dd></dl>')
    if lead["source_url"]:
        kv += f'<p><a href="{e(lead["source_url"])}" target="_blank" rel="noopener noreferrer">رابط الإعلان</a></p>'
    if same:
        kv += notice_box(f"قد يكون هذا نفس مكان العميل «{same['name']}» برقم مختلف.", "warn")
    if lead["do_not_call"]:
        kv += notice_box("طلب هذا العميل عدم الاتصال به.", "bad")
    actions = ""
    if ctx.can("leads.assign"):
        opts = [("", "— اختر —"), ("pool", "إرجاع للمخزون")] + [(u["id"], u["name"]) for u in emps]
        actions += form(req, f"/m/lead/{lead_id}/assign", f'<div class="row"><div style="flex:1">{select("نقل إلى", "to", opts, required=True)}</div>{button("نقل", small=True)}</div>')
        if lead["status"] in ("exhausted", "not_interested", "wrong_number") and not lead["do_not_call"]:
            actions += form(req, f"/m/lead/{lead_id}/reopen", textarea("سبب إعادة الفتح", "why", rows=2, required=True) + button("إعادة فتح الملف", kind="ghost", small=True))
    att = [[e(ui.fmt_dt(a["started_at"], tz)), e(names.get(a["user_id"], "")), e(olabels.get(a["eff"], "لم تُسجَّل") if a["eff"] else ("ملغاة" if a["status"] == "cancelled" else "مفتوحة")),
            evidence_badge(a["evidence"]), e(a["note"] or ""), e(util.fmt_call_duration(a["duration_sec"]) if a["duration_sec"] else "")] for a in attempts]
    tl = "".join(f'<li><div class="tl-t">{e(ui.fmt_dt(ev["ts"], tz))} · {e(names.get(ev["actor_id"] or ev["user_id"], "النظام"))}</div>'
                 f'<b>{e(EVENT_LABELS.get(ev["type"], ev["type"]))}</b> {e(describe_event(ev, olabels, rlabels))}</li>' for ev in events)
    body = (card(kv, title=lead["name"]) + (card(actions, title="إجراءات") if actions else "")
            + card(table(["الوقت", "الموظف", "النتيجة", "الثقة", "ملاحظة", "المدة"], att, empty_text="لا مكالمات بعد"), title="المكالمات")
            + card(f'<ul class="timeline">{tl}</ul>' if tl else ui.empty("لا أحداث"), title="سجل العميل الكامل", sub="من سجل الأحداث المحفوظ"))
    return page(req, lead["name"], body, active="leads", wide=True, back="/m/leads")


@route("POST", "/m/lead/<int:lead_id>/assign", auth="manager", perm="leads.assign")
async def lead_assign(req, lead_id: int):
    ctx = req.ctx
    to = req.f("to")
    target = None if to == "pool" else util.to_int(to)

    def go(c):
        if not leadlib.get(c, ctx.cid, lead_id):
            return -1
        if target is not None and not db.one(c, "SELECT 1 FROM users WHERE id=? AND company_id=? AND role='employee' AND active=1", target, ctx.cid):
            return -1
        return leadlib.assign(c, ctx.cid, [lead_id], target, ctx.uid, "manual")

    n = await db.write(go)
    return ui.flash_redirect(f"/m/lead/{lead_id}", "ok" if n > 0 else "warn", "نُقل العميل" if n > 0 else "لم يتغير شيء")


@route("POST", "/m/lead/<int:lead_id>/reopen", auth="manager", perm="leads.assign")
async def lead_reopen(req, lead_id: int):
    ctx = req.ctx
    why = req.f("why")
    if len(why) < 3:
        return ui.flash_redirect(f"/m/lead/{lead_id}", "err", "اكتب سبب إعادة الفتح")

    def go(c):
        lead = leadlib.get(c, ctx.cid, lead_id)
        if not lead or lead["status"] not in ("exhausted", "not_interested", "wrong_number") or lead["do_not_call"]:
            return False
        c.execute("UPDATE leads SET status='new', status_at=?, follow_step=0, next_follow_up=NULL, next_follow_time=NULL WHERE id=?", (util.now_iso(), lead_id))
        db.emit(c, ctx.cid, "lead.reopened", actor=ctx.uid, user=lead["owner_id"], lead=lead_id, data={"from": lead["status"], "why": why[:200]})
        return True

    ok = await db.write(go)
    return ui.flash_redirect(f"/m/lead/{lead_id}", "ok" if ok else "err", "أُعيد فتح الملف" if ok else "لا يمكن إعادة فتحه")


# ------------------------------------------------------------------------------------------------ import
BATCH_STATUS = {"mapping": ("اختيار الأعمدة", "warn"), "preview": ("بانتظار الاعتماد", "warn"), "committed": ("معتمد", "ok"), "cancelled": ("أُلغي", "muted")}


@route("GET", "/m/import", auth="manager", perm="leads.import")
async def import_home(req):
    ctx = req.ctx

    def go(c):
        return c.execute("SELECT b.*, u.name AS by_name FROM lead_batches b LEFT JOIN users u ON u.id=b.uploaded_by WHERE b.company_id=? ORDER BY b.id DESC LIMIT 30", (ctx.cid,)).fetchall()

    rows = []
    for b in await db.read(go):
        cn = db.jload(b["counts_json"], {}) or {}
        lbl, tone = BATCH_STATUS.get(b["status"], (b["status"], ""))
        rows.append([f'<a href="/m/import/{b["id"]}">{e(b["filename"])}</a>', badge(lbl, tone), e(ui.fmt_dt(b["uploaded_at"], ctx.tz)), str(cn.get("rows", b["rows_total"])),
                     str(cn.get("added", cn.get("new", "—"))), str(cn.get("dup_db", 0) + cn.get("dup_file", 0)), str(cn.get("invalid", 0)), e(b["by_name"] or "")])
    up = form(req, "/m/import/upload", f'<label class="field"><span class="lbl">ملف الأرقام (xlsx أو csv)</span><input type="file" name="file" accept=".xlsx,.xlsm,.csv,.txt,.tsv" required></label>'
                                       f'<p class="sub">أقصى حجم {config.MAX_UPLOAD_MB} ميغابايت و{config.MAX_IMPORT_ROWS:,} صف. لن يُحفظ شيء قبل أن تراجع النتيجة وتعتمدها.</p>'
              + button("رفع وفحص الملف", icon_name="upload"), multipart=True)
    body = (card(up, title="استيراد ملف جديد", sub="الأعمدة المطلوبة: الجوال. والباقي اختياري: الاسم، المدينة، رابط الإعلان، الموظف")
            + card(table(["الملف", "الحالة", "رُفع", "الصفوف", "أُضيف", "مكرر", "غير صالح", "بواسطة"], rows, empty_text="لم تستورد ملفات بعد"), title="الاستيرادات السابقة"))
    return page(req, "الاستيراد", body, active="import", wide=True)


@route("POST", "/m/import/upload", auth="manager", perm="leads.import")
async def import_upload(req):
    ctx = req.ctx
    f = req.file("file")
    if not f:
        return ui.flash_redirect("/m/import", "err", "اختر ملفًا أولًا")
    filename, raw = f
    filename = Path(filename).name[:120]
    if not raw:
        return ui.flash_redirect("/m/import", "err", "الملف فارغ")
    try:
        rows = await asyncio.to_thread(importer.read_rows, filename, raw)
    except importer.ImportProblem as ex:
        return ui.flash_redirect("/m/import", "err", str(ex))
    except Exception:
        return ui.flash_redirect("/m/import", "err", "تعذّرت قراءة الملف. تأكد أنه xlsx أو csv سليم.")
    has_header = importer.looks_like_header(rows[0][1])
    mapping = importer.guess_mapping(rows, has_header)
    width = max(len(r[1]) for r in rows[:300])
    sample = [r[1][:importer.MAX_COLS] for r in rows[:8]]
    digest = util.sha256(raw)

    def go(c):
        again = db.one(c, "SELECT id FROM lead_batches WHERE company_id=? AND sha256=? AND status='committed' ORDER BY id DESC LIMIT 1", ctx.cid, digest)
        cur = c.execute("INSERT INTO lead_batches(company_id,filename,sha256,uploaded_by,uploaded_at,status,mapping_json,rows_total) VALUES(?,?,?,?,?,'mapping',?,?)",
                        (ctx.cid, filename, digest, ctx.uid, util.now_iso(), util.canon({"has_header": has_header, "mapping": mapping, "sample": sample, "width": width, "dup_file": again["id"] if again else None}),
                         len(rows) - (1 if has_header else 0)))
        bid = int(cur.lastrowid)
        path = importer.save_upload(ctx.cid, bid, filename, raw)
        c.execute("UPDATE lead_batches SET raw_path=? WHERE id=?", (path, bid))
        return bid

    bid = await db.write(go)
    return redirect(f"/m/import/{bid}")


def _batch(c: sqlite3.Connection, ctx, bid: int) -> sqlite3.Row:
    b = db.one(c, "SELECT * FROM lead_batches WHERE id=? AND company_id=?", bid, ctx.cid)
    if not b:
        raise HttpError(404, "الاستيراد غير موجود")
    return b


@route("GET", "/m/import/<int:bid>", auth="manager", perm="leads.import")
async def import_view(req, bid: int):
    ctx = req.ctx
    b = await db.read(_batch, ctx, bid)
    info = db.jload(b["mapping_json"], {}) or {}
    if b["status"] == "mapping":
        sample, width, has_header = info.get("sample", []), info.get("width", 0), info.get("has_header", True)
        mapping = info.get("mapping", {})
        head = sample[0] if sample else []
        opts_base = [("", "— لا شيء —")]
        selects = ""
        for key, label in importer.FIELDS:
            opts = opts_base + [(i, f"{col_name(i)}: {(head[i] if has_header and i < len(head) else (sample[0][i] if sample and i < len(sample[0]) else ''))[:28]}") for i in range(width)]
            cur = mapping.get(key)
            selects += select(label, f"m_{key}", opts, "" if cur is None else cur)
        prev = table([col_name(i) for i in range(width)], [[e(x) for x in (r + [""] * (width - len(r)))] for r in sample[:6]])
        warn = ""
        if info.get("dup_file"):
            warn = notice_box("هذا الملف نفسه استُورد من قبل. سيُكتشف تكراره صفًا صفًا في الخطوة التالية.", "warn")
        body = (card(warn + f'<p>{e(b["filename"])} — {b["rows_total"]:,} صفًا</p>{prev}', title="الخطوة 1: ما الذي في كل عمود؟")
                + card(form(req, f"/m/import/{bid}/map", selects + checkbox("الصف الأول عناوين أعمدة", "has_header", has_header) + button("افحص الصفوف", big=True)), title="ربط الأعمدة")
                + form(req, f"/m/import/{bid}/cancel", button("إلغاء الاستيراد", kind="ghost", small=True), cls="center"))
        return page(req, "ربط الأعمدة", body, active="import", wide=True, back="/m/import")
    cn = db.jload(b["counts_json"], {}) or {}
    if b["status"] in ("preview", "committed"):
        def go(c):
            out = {}
            for state in ("new", "dup_db", "dup_file", "invalid"):
                out[state] = c.execute("SELECT * FROM import_rows WHERE batch_id=? AND state=? ORDER BY row_no LIMIT 8", (bid, state)).fetchall()
            return out

        samples = await db.read(go)
        committed = b["status"] == "committed"
        tiles = ('<div class="grid">' + ui.stat("صفوف الملف", cn.get("rows", 0)) + ui.stat("أُضيف" if committed else "جديد سيُضاف", cn.get("added", cn.get("new", 0)), tone="ok")
                 + ui.stat("مكرر مع عملاء محفوظين", cn.get("dup_db", 0), tone="warn" if cn.get("dup_db") else "")
                 + ui.stat("مكرر داخل الملف", cn.get("dup_file", 0), tone="warn" if cn.get("dup_file") else "")
                 + ui.stat("رقم غير صالح", cn.get("invalid", 0), tone="bad" if cn.get("invalid") else "") + "</div>")
        notes = ""
        if cn.get("maybe_same"):
            notes += notice_box(f"{cn['maybe_same']} صفًا بنفس اسم ومدينة عميل محفوظ لكن برقم مختلف؛ سيُضافون مع تنبيه «قد يكون نفس المكان».", "info")
        if cn.get("non_mobile"):
            notes += notice_box(f"{cn['non_mobile']} رقمًا أرضيًا أو دوليًا: يُحفظون ولا يدخلون الخطط ما دام إعداد «الأرقام الأرضية» مطفأً.", "info")
        if cn.get("unknown_staff"):
            names = "، ".join(f"{n} ({k})" for n, k in cn.get("unknown_names", []))
            notes += notice_box(f"{cn['unknown_staff']} صفًا باسم موظف غير موجود ({names}). سيذهبون للمخزون العام.", "warn")
        if cn.get("assigned"):
            notes += notice_box(f"{cn['assigned']} صفًا سيُسند مباشرة للموظف المذكور في الملف.", "info")
        if cn.get("no_name"):
            notes += notice_box(f"{cn['no_name']} صفًا بلا اسم؛ سُمّيت «بدون اسم».", "info")
        labels = {"new": "جديد", "dup_db": "مكرر مع محفوظ", "dup_file": "مكرر في الملف", "invalid": "غير صالح"}
        blocks = ""
        for state, rows in samples.items():
            if rows:
                blocks += f'<details class="fold"><summary>{e(labels[state])} — أمثلة</summary><div>' + table(
                    ["الصف", "الاسم", "الرقم كما ورد", "ملاحظة"], [[str(r["row_no"]), e(r["name"]), e(r["phone_raw"] or ""), e(r["reason"] or "")] for r in rows]) + "</div></details>"
        actions = ""
        if b["status"] == "preview":
            if cn.get("new", 0):
                commit = form(req, f"/m/import/{bid}/commit", button(f"اعتماد وإضافة {cn.get('new', 0):,} عميلًا", big=True, icon_name="check", confirm="سيُضاف الجدد إلى قائمة العملاء. متابعة؟"), cls="mt")
            else:
                commit = f'<div class="mt">{notice_box("لا يوجد في هذا الملف عميل جديد: كل أرقامه مكررة أو غير صالحة، فلا شيء يُضاف.", "warn")}</div>'
            actions = commit + form(req, f"/m/import/{bid}/cancel", button("إلغاء الاستيراد", kind="ghost", small=True), cls="center mt")
        elif committed:
            actions = f'<div class="row mt">{button("عرض العملاء", href=f"/m/leads?batch={bid}", kind="soft")}{button("توزيع الأرقام", href="/m/distribute", kind="ghost")}</div>'
        rej = button("تنزيل المرفوضات (CSV)", href=f"/m/import/{bid}/rejected.csv", kind="ghost", small=True) if (cn.get("dup_db") or cn.get("dup_file") or cn.get("invalid")) else ""
        body = card(f'<p>{e(b["filename"])}</p>{tiles}{notes}{blocks}{rej}{actions}', title="الخطوة 2: نتيجة الفحص" if not committed else "تم الاستيراد",
                    sub="لم يُحفظ أي عميل بعد" if not committed else ui.fmt_dt(b["committed_at"], ctx.tz))
        return page(req, "نتيجة الفحص", body, active="import", wide=True, back="/m/import")
    return page(req, "استيراد", card(ui.empty("أُلغي هذا الاستيراد", action_html=button("استيراد جديد", href="/m/import"))), active="import", back="/m/import")


@route("POST", "/m/import/<int:bid>/map", auth="manager", perm="leads.import")
async def import_map(req, bid: int):
    ctx = req.ctx
    b = await db.read(_batch, ctx, bid)
    if b["status"] not in ("mapping", "preview"):
        return redirect(f"/m/import/{bid}")
    mapping: dict[str, int | None] = {}
    for key, _ in importer.FIELDS:
        v = req.f(f"m_{key}")
        mapping[key] = int(v) if v.isdigit() else None
    if mapping["phone"] is None:
        return ui.flash_redirect(f"/m/import/{bid}", "err", "اختر العمود الذي فيه رقم الجوال")
    chosen = [v for v in mapping.values() if v is not None]
    if len(chosen) != len(set(chosen)):
        return ui.flash_redirect(f"/m/import/{bid}", "err", "لا يمكن استخدام العمود نفسه لحقلين")
    has_header = bool(req.f("has_header"))
    try:
        raw = Path(b["raw_path"]).read_bytes()
        rows = await asyncio.to_thread(importer.read_rows, b["filename"], raw)
    except (importer.ImportProblem, OSError) as ex:
        return ui.flash_redirect(f"/m/import/{bid}", "err", str(ex) if isinstance(ex, importer.ImportProblem) else "الملف المرفوع لم يعد موجودًا")

    def go(c):
        counts = importer.analyze(c, ctx.cid, bid, rows, mapping, has_header, ctx.settings)
        info = db.jload(b["mapping_json"], {}) or {}
        info.update({"has_header": has_header, "mapping": mapping})
        c.execute("UPDATE lead_batches SET status='preview', counts_json=?, mapping_json=?, rows_total=? WHERE id=?", (util.canon(counts), util.canon(info), counts["rows"], bid))

    await db.write(go)
    return redirect(f"/m/import/{bid}")


@route("POST", "/m/import/<int:bid>/commit", auth="manager", perm="leads.import")
async def import_commit(req, bid: int):
    ctx = req.ctx

    def go(c):
        _batch(c, ctx, bid)
        return importer.commit(c, ctx.cid, bid, ctx.uid, ctx.settings)

    try:
        res = await db.write(go)
    except importer.ImportProblem as ex:
        return ui.flash_redirect(f"/m/import/{bid}", "err", str(ex))
    return ui.flash_redirect(f"/m/import/{bid}", "ok", f"أُضيف {res['added']:,} عميلًا" + (f" ({res['demoted']} كانوا مضافين قبل لحظات)" if res["demoted"] else ""))


@route("POST", "/m/import/<int:bid>/cancel", auth="manager", perm="leads.import")
async def import_cancel(req, bid: int):
    ctx = req.ctx

    def go(c):
        b = _batch(c, ctx, bid)
        if b["status"] in ("mapping", "preview"):
            c.execute("UPDATE lead_batches SET status='cancelled' WHERE id=?", (bid,))
            c.execute("DELETE FROM import_rows WHERE batch_id=?", (bid,))

    await db.write(go)
    return ui.flash_redirect("/m/import", "ok", "أُلغي الاستيراد")


@route("GET", "/m/import/<int:bid>/rejected.csv", auth="manager", perm="leads.import")
async def import_rejected(req, bid: int):
    ctx = req.ctx

    def go(c):
        b = _batch(c, ctx, bid)
        return importer.rejected_csv(c, bid), b["filename"]

    text, fname = await db.read(go)
    return download(text, f"rejected-{Path(fname).stem}.csv", "text/csv; charset=utf-8")
