#!/usr/bin/env bash
# Puts a copy made by backup.sh (or one of MINJAZ's own copies) back. It REPLACES all of MINJAZ's data with the copy; the
# data that was there is not deleted: it stays in the same data volume next to the new data, in files ending in
# .before-restore-<time>. The copy is refused, and nothing changes, unless it is a whole database of this version.
#
#   bash restore.sh backups/minjaz-20261103-101500.db.gz
set -euo pipefail
[ "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" = "/opt/minjaz" ] || { echo "ERROR: run from /opt/minjaz" >&2; exit 1; }
cd /opt/minjaz
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
file="${1:-}"
[ -n "$file" ] && [ -f "$file" ] || die "usage: bash restore.sh backups/minjaz-YYYYMMDD-HHMMSS.db.gz"
magic="$(gzip -dc "$file" 2>/dev/null | head -c 15 || true)"
if ! gzip -t "$file" 2>/dev/null || [ "$magic" != "SQLite format 3" ]; then
  die "this file is not a copy made by MINJAZ (a .db.gz of its database). Nothing was changed."
fi
echo "This replaces ALL of MINJAZ's data (companies, staff, clients, calls, reports, the log) with: $file"
echo "Everything entered after that copy was made will be gone from the live data (it is kept aside, not deleted)."
read -r -p "Type YES to continue: " answer || exit 1
[ "$answer" = "YES" ] || die "cancelled. Nothing was changed."
docker compose -p minjaz stop web
if docker compose -p minjaz run --rm --no-deps -T web python -m minjaz restore --force < "$file"; then
  docker compose -p minjaz up -d web
  echo "Done. MINJAZ is running again with the copy. Check the event log:  docker exec minjaz-web python -m minjaz verify"
else
  docker compose -p minjaz up -d web
  die "the copy could not be restored; MINJAZ was started again with the data it had. Nothing was lost."
fi
