#!/usr/bin/env bash
# Stops and removes ONLY the MINJAZ container and the project's own network.
#   bash uninstall.sh            keep the data (companies, staff, clients, reports, the log)
#   bash uninstall.sh --purge    ALSO delete the data volume and the image. This erases everything MINJAZ holds.
#                                It asks you to type the word DELETE first. Make a backup and download it before.
# If this folder's web.sh added an entry to the Caddyfile, you are asked whether to take that entry out first.
# The folder /opt/minjaz, its .env and its backups stay; delete the folder yourself if you want it gone.
set -euo pipefail
[ "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" = "/opt/minjaz" ] || { echo "ERROR: run from /opt/minjaz" >&2; exit 1; }
cd /opt/minjaz
mode="${1:-}"
case "$mode" in ""|--purge) ;; *) echo "usage: bash uninstall.sh [--purge]" >&2; exit 1 ;; esac
if [ "$mode" = "--purge" ]; then
  echo "This will ERASE all MINJAZ data (companies, staff, clients, calls, reports, the log)."
  read -r -p "Type DELETE to continue: " answer || exit 1
  [ "$answer" = "DELETE" ] || { echo "cancelled. Nothing was deleted."; exit 1; }
fi
if [ -f .state ] && grep -E '^CADDY_FILE=.' .state >/dev/null; then
  echo "A Caddy entry for MINJAZ was added to the web server's file. Taking it out first:"
  bash web.sh caddy-undo || echo "The entry was not removed; remove it later with:  bash web.sh caddy-undo"
fi
if [ -f .state ]; then
  net="$(grep -m1 '^PROXY_NETWORK=' .state | cut -d= -f2- || true)"
  if [ -n "$net" ] && docker network inspect "$net" >/dev/null 2>&1; then docker network disconnect "$net" minjaz-web >/dev/null 2>&1 || true; fi
fi
if [ "$mode" = "--purge" ]; then
  docker compose -p minjaz down --volumes
  docker rmi minjaz-app:local >/dev/null 2>&1 || true
else
  docker compose -p minjaz down
fi
rm -f .state
echo "MINJAZ was removed. Other projects were not touched."
