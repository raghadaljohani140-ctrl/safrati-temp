#!/usr/bin/env bash
# MINJAZ: installer / updater.
#
#   bash install.sh          first install, or update to the files in this folder (keeps .env, the data and the backups)
#   bash install.sh code     print a new one-time setup code (only works until the owner account exists)
#
# Safety: runs only inside /opt/minjaz and only touches the Docker project "minjaz"
# (container minjaz-web, network minjaz_default, volume minjaz_minjaz_data, image minjaz-app:local).
# It never stops, restarts, rebuilds, removes or edits anything that belongs to another project, and it stops
# before doing anything if one of these names is already used by something that is not this project.
# It does not touch the web server in front (Caddy): that is a separate step, `bash web.sh proxy`, which asks first.
# MINJAZ has no secret to type here: its settings (.env) hold no key and no password.
set -euo pipefail

APP_DIR="/opt/minjaz"
PROJECT="minjaz"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$APP_DIR/.env"

die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
say() { printf '%s\n' "$*"; }

[ "$HERE" = "$APP_DIR" ] || die "this script must live in $APP_DIR (it is in $HERE). Nothing was changed."
cd "$APP_DIR"
umask 077

command -v docker >/dev/null 2>&1 || die "docker is not installed on this server."
docker compose version >/dev/null 2>&1 || die "the 'docker compose' plugin is missing."
docker info >/dev/null 2>&1 || die "docker is not running, or this user may not use it."

# ---------------------------------------------------------------- helpers
state_get() { if [ -f "$APP_DIR/.state" ]; then grep -m1 "^$1=" "$APP_DIR/.state" | cut -d= -f2- || true; fi; }

owner_of() { # KIND NAME -> the compose project that created it ("" when it does not exist or has no label)
  case "$1" in
    container) docker inspect -f '{{ index .Config.Labels "com.docker.compose.project" }}' "$2" 2>/dev/null || true ;;
    volume)    docker volume inspect -f '{{ index .Labels "com.docker.compose.project" }}' "$2" 2>/dev/null || true ;;
    network)   docker network inspect -f '{{ index .Labels "com.docker.compose.project" }}' "$2" 2>/dev/null || true ;;
  esac
}

exists() { # KIND NAME
  case "$1" in
    container) docker inspect "$2" >/dev/null 2>&1 ;;
    volume)    docker volume inspect "$2" >/dev/null 2>&1 ;;
    network)   docker network inspect "$2" >/dev/null 2>&1 ;;
  esac
}

preflight() { # read-only: look at the server, and stop if any name we need belongs to someone else
  local kind name owner item
  say "Checking this server (nothing is changed yet)..."
  for item in container:minjaz-web volume:minjaz_minjaz_data network:minjaz_default; do
    kind="${item%%:*}"; name="${item#*:}"
    if exists "$kind" "$name"; then
      owner="$(owner_of "$kind" "$name")"
      [ "$owner" = "$PROJECT" ] || die "the $kind '$name' already exists and does not belong to this project (it belongs to '${owner:-no project}'). Nothing was changed."
    fi
  done
  local free_mb kb mem_mb="?"
  free_mb="$(df -Pm "$APP_DIR" 2>/dev/null | awk 'NR==2 {print $4}')"
  if [[ "$free_mb" =~ ^[0-9]+$ ]] && [ "$free_mb" -lt 1024 ]; then
    die "only $free_mb MB of disk is free here; the build needs about 1 GB. Nothing was changed."
  fi
  kb="$(awk '/^MemAvailable:/ {print $2}' "${MINJAZ_MEMINFO:-/proc/meminfo}" 2>/dev/null || true)"
  if [[ "$kb" =~ ^[0-9]+$ ]]; then
    mem_mb=$((kb / 1024))
    # an app that is already running counts in the server's memory, so only a first start is held back
    if ! exists container minjaz-web && [ "$mem_mb" -lt 350 ]; then
      die "only $mem_mb MB of memory is free on this server. MINJAZ needs about 100 MB (it is capped at 256 MB) and starting it could slow down the other projects here. Nothing was changed."
    fi
  fi
  say "  disk free: ${free_mb:-?} MB, memory free: $mem_mb MB"
  say "  other containers on this server (they will not be touched):"
  docker ps -a --format '    {{.Names}}  ({{.Status}})' | grep -v '^    minjaz-' || say "    none"
}

rejoin_proxy() { # a rebuilt app is a new container, so it is put back on the network of the web server in front
  local net names
  [ "$(state_get ACCESS)" = proxy ] || return 0
  net="$(state_get PROXY_NETWORK)"
  [ -n "$net" ] || return 0
  if ! docker network inspect "$net" >/dev/null 2>&1; then
    say "WARNING: the network '$net' does not exist any more, so the web server in front cannot reach MINJAZ. Run:  bash web.sh proxy"
    return 0
  fi
  names="$(docker inspect -f '{{range $k, $v := .NetworkSettings.Networks}}{{$k}} {{end}}' minjaz-web 2>/dev/null || true)"
  if [[ " $names " != *" $net "* ]]; then
    docker network connect "$net" minjaz-web || say "WARNING: could not connect MINJAZ to the network '$net'. Run:  bash web.sh proxy"
  fi
  say "MINJAZ is connected to the network '$net'."
}

start_app() {
  say "Building and starting MINJAZ (the first build takes 1 to 3 minutes)..."
  docker compose -p "$PROJECT" up -d --build web
  local i logs
  for i in $(seq 1 30); do
    logs="$(docker logs minjaz-web 2>&1 || true)"
    if [[ "$logs" == *"listening on"* ]]; then
      say "MINJAZ is running:"
      printf '%s\n' "$logs" | grep -F "listening on" | tail -n 1 || true
      rejoin_proxy
      return 0
    fi
    sleep 2
  done
  say "MINJAZ did not report that it started within 60 seconds. Last log lines:"
  docker logs --tail 20 minjaz-web 2>&1 || true
  return 1
}

# ---------------------------------------------------------------- a new setup code
if [ "${1:-}" = "code" ]; then
  [ "$(docker inspect -f '{{.State.Running}}' minjaz-web 2>/dev/null || true)" = true ] || die "MINJAZ is not running. Run first:  bash install.sh"
  exec docker exec minjaz-web python -m minjaz setup-code
fi

[ -z "${1:-}" ] || die "unknown option. Use: bash install.sh   or   bash install.sh code"

# ---------------------------------------------------------------- install or update
FIRST=0
if [ -f "$ENV_FILE" ]; then
  say "Keeping your existing settings in .env."
else
  FIRST=1
  say "This server is: $(hostname 2>/dev/null || echo unknown)"
  say "MINJAZ will be installed here, in $APP_DIR, on its own and separate from every other project."
  read -r -p "Is this the right server? Type y then Enter to continue (anything else cancels): " reply || die "input was closed."
  case "$reply" in
    y|Y|yes|YES|Yes) ;;
    *) die "cancelled. No container was started and no setting was saved." ;;
  esac
fi

preflight

if [ "$FIRST" = 1 ]; then
  [ -f "$APP_DIR/.env.example" ] || die ".env.example is missing from this folder."
  cp "$APP_DIR/.env.example" "$ENV_FILE"
  say ""
  say "Settings saved in $ENV_FILE (readable by root only)."
fi
chmod 600 "$ENV_FILE"
mkdir -p "$APP_DIR/backups"
chmod 700 "$APP_DIR/backups"

say ""
start_app || exit 1
say ""
say "Containers of this project:"
docker compose -p "$PROJECT" ps
say ""
if [ "$FIRST" = 1 ]; then
  code="$(docker logs minjaz-web 2>&1 | grep -F 'رمز الإعداد الأول' | tail -n 1 || true)"
  say "The one-time setup code (you type it on the /setup page to create the owner account):"
  say "  ${code:-not shown yet; run:  bash install.sh code}"
  say ""
  say "Next step:  bash web.sh proxy      (connects MINJAZ to the web server already on this machine, and asks before it changes anything)"
else
  say "Updated. Your data, settings and backups were kept."
  say "If the owner account has not been created yet, a setup code comes from:  bash install.sh code   (it says so if the account already exists)"
fi
say "Done."
