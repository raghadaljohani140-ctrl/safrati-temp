#!/usr/bin/env bash
# Makes a copy of everything MINJAZ keeps (companies, staff, clients, calls, reports, the event log) as ONE file in
# /opt/minjaz/backups. It is safe to run while MINJAZ is running: the copy is made with SQLite's online backup, then
# checked (integrity, version, the event chain of every company) before it is accepted.
#
#   bash backup.sh      make a copy now (the newest 30 copies are kept; only files that follow our own naming are ever removed)
#
# MINJAZ also makes its own daily copy at 03:00 Riyadh time inside its data volume. A copy that stays on the same
# server does not protect you if the server is lost: from time to time download the newest file from the backups
# folder to your own computer.
set -euo pipefail
[ "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" = "/opt/minjaz" ] || { echo "ERROR: run from /opt/minjaz" >&2; exit 1; }
cd /opt/minjaz
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
umask 077
[ "$(docker inspect -f '{{.State.Running}}' minjaz-web 2>/dev/null || true)" = true ] || die "MINJAZ is not running."
mkdir -p backups
chmod 700 backups
out="$(docker exec minjaz-web python -m minjaz backup 2>&1)" || { printf '%s\n' "$out" >&2; die "the copy failed. Nothing was saved."; }
inside="$(printf '%s\n' "$out" | sed -n 's/.*"path": "\([^"]*\)".*/\1/p' | head -n 1)"
case "$inside" in /data/backups/minjaz-*.db.gz) ;; *) printf '%s\n' "$out" >&2; die "could not tell where the copy was written. Nothing was saved." ;; esac
stamp="$(date +%Y%m%d-%H%M%S)"
part="backups/.new-$stamp.part"
final="backups/minjaz-$stamp.db.gz"
if ! docker cp "minjaz-web:$inside" "$part" >/dev/null; then
  rm -f -- "$part"
  die "could not copy the file out of MINJAZ. Nothing was saved."
fi
# The file must be a whole gzip of a SQLite database.
magic="$(gzip -dc "$part" 2>/dev/null | head -c 15 || true)"
if ! gzip -t "$part" 2>/dev/null || [ "$magic" != "SQLite format 3" ]; then
  rm -f -- "$part"
  die "the copy is not readable. Nothing was saved."
fi
mv -- "$part" "$final"
chmod 600 "$final"
echo "Saved: /opt/minjaz/$final ($(du -h "$final" | cut -f1))"
# keep the newest 30; only files of this folder that follow our own naming are ever removed
find backups -maxdepth 1 -type f -name 'minjaz-[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]-[0-9][0-9][0-9][0-9][0-9][0-9].db.gz' | sort | head -n -30 | while read -r old; do
  rm -f -- "$old"
  echo "Removed an old copy: $old"
done
