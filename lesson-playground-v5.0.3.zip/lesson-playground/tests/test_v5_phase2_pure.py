"""Version 5, phase 2 (the parts that need no server): reading the shape of a book, laying lessons over periods, reading a timetable."""
import datetime
import unittest

from app import bookread, extract, planner, tables, timetable
from tests import files5 as X

D = datetime.date


# ---------------------------------------------------------------- the shape of a book
def flat(units):
    return [(u["title"], [l["title"] for l in u["lessons"]]) for u in units]


def body(title, n=5):
    return [title] + [f"جملة شرح رقم {i} عن {title} تحتوي على معلومات مفيدة للطالبات في هذا الدرس المهم." for i in range(n)]


class BookShape(unittest.TestCase):
    TOC = ["فهرس المحتويات",
           "الوحدة الأولى: الأعداد الصحيحة ........ 5", "الدرس الأول: مقارنة الأعداد ........ 6", "الدرس الثاني: جمع الأعداد ........ 12", "مراجعة الوحدة الأولى ........ 18",
           "الوحدة الثانية: الكسور ........ 20", "الدرس الأول: الكسور العادية ........ 21", "اختبار الفصل ........ 30", "المراجع ........ 32"]

    def book(self, toc=None):
        lines = ["الرياضيات", "الصف الأول المتوسط"] + (toc or self.TOC)
        lines += body("الوحدة الأولى: الأعداد الصحيحة", 1) + body("الدرس الأول: مقارنة الأعداد") + body("الدرس الثاني: جمع الأعداد") + body("مراجعة الوحدة الأولى", 2)
        lines += body("الوحدة الثانية: الكسور", 1) + body("الدرس الأول: الكسور العادية") + body("اختبار الفصل", 2) + ["المراجع", "كتاب الرياضيات"]
        return lines

    def test_the_contents_page_gives_the_units_and_the_lessons(self):
        r = bookread.analyze(self.book())
        self.assertTrue(r["toc"])
        self.assertEqual(flat(r["units"]), [
            ("الوحدة الأولى: الأعداد الصحيحة", ["الدرس الأول: مقارنة الأعداد", "الدرس الثاني: جمع الأعداد", "مراجعة الوحدة الأولى"]),
            ("الوحدة الثانية: الكسور", ["الدرس الأول: الكسور العادية", "اختبار الفصل"])])

    def test_the_references_are_not_a_lesson_and_reviews_and_tests_are_marked(self):
        lessons = [l for u in bookread.analyze(self.book())["units"] for l in u["lessons"]]
        self.assertEqual([l["kind"] for l in lessons], ["lesson", "lesson", "review", "lesson", "exam"])
        self.assertFalse(any("المراجع" == l["title"] for l in lessons))

    def test_the_pages_come_from_the_contents_page(self):
        les = bookread.analyze(self.book())["units"][0]["lessons"]
        self.assertEqual((les[0]["first_page"], les[0]["last_page"]), (6, 11))
        self.assertEqual((les[1]["first_page"], les[1]["last_page"]), (12, 17))

    def test_the_text_of_a_lesson_is_the_text_between_its_heading_and_the_next(self):
        les = bookread.analyze(self.book())["units"][0]["lessons"]
        self.assertEqual(les[0]["text"].count("جملة شرح"), 5)
        self.assertIn("مقارنة الأعداد", les[0]["text"])
        self.assertNotIn("جمع الأعداد", les[0]["text"])          # the next lesson's lines are not in it
        self.assertEqual(les[1]["text"].count("جملة شرح"), 5)
        self.assertNotIn("مقارنة الأعداد", les[1]["text"])
        self.assertFalse(les[0]["text"].startswith("الدرس الأول: مقارنة الأعداد\n"))          # the heading itself is the title, not the text

    def test_a_book_with_no_contents_page_is_read_from_its_headings(self):
        lines = body("الوحدة الأولى: المادة", 1) + body("الدرس الأول: خصائص المادة") + body("الدرس الثاني: حالات المادة") + body("الوحدة الثانية: الطاقة", 1) + body("الدرس الأول: أشكال الطاقة")
        r = bookread.analyze(lines)
        self.assertFalse(r["toc"])
        self.assertEqual(flat(r["units"]), [("الوحدة الأولى: المادة", ["الدرس الأول: خصائص المادة", "الدرس الثاني: حالات المادة"]), ("الوحدة الثانية: الطاقة", ["الدرس الأول: أشكال الطاقة"])])

    def test_a_sentence_that_begins_with_the_word_lesson_is_not_a_heading(self):
        lines = ["الدرس الذي سبق كان مفيدا للجميع وفيه فوائد كثيرة جدا.", "درس اليوم يتحدث عن النباتات وأجزائها", "جملة عادية"] + body("الدرس الأول: النبات") + body("الدرس الثاني: الحيوان")
        titles = [l["title"] for u in bookread.analyze(lines)["units"] for l in u["lessons"]]
        self.assertEqual(titles, ["الدرس الأول: النبات", "الدرس الثاني: الحيوان"])

    def test_a_contents_page_without_the_words_unit_and_lesson(self):
        toc = ["المحتويات", "الجمع والطرح ........ 3", "الضرب ........ 9", "القسمة ........ 15", "الكسور ........ 21", "النسبة والتناسب ........ 27"]
        lines = ["الرياضيات"] + toc + sum((body(t) for t in ("الجمع والطرح", "الضرب", "القسمة", "الكسور", "النسبة والتناسب")), [])
        r = bookread.analyze(lines)
        self.assertTrue(r["toc"])
        self.assertEqual(flat(r["units"])[0][1], ["الجمع والطرح", "الضرب", "القسمة", "الكسور", "النسبة والتناسب"])
        self.assertTrue(all(l["text"] for l in r["units"][0]["lessons"]))

    def test_numbered_lessons_give_their_units(self):
        toc = ["المحتويات", "1-1 الأعداد الصحيحة ..... 4", "1-2 جمع الأعداد ..... 10", "2-1 المعادلات ..... 16", "2-2 حل المعادلات ..... 22", "3-1 الهندسة ..... 30"]
        lines = toc + sum((body(t) for t in ("1-1 الأعداد الصحيحة", "1-2 جمع الأعداد", "2-1 المعادلات", "2-2 حل المعادلات", "3-1 الهندسة")), [])
        r = bookread.analyze(lines)
        self.assertEqual([(u["title"], len(u["lessons"])) for u in r["units"]], [("الوحدة 1", 2), ("الوحدة 2", 2), ("الوحدة 3", 1)])

    def test_an_english_book(self):
        toc = ["Contents", "Unit 1: Forces ..... 5", "Lesson 1: Gravity ..... 6", "Lesson 2: Friction ..... 12", "Unit 2: Energy ..... 18", "Lesson 1: Heat ..... 19"]
        lines = toc + body("Unit 1: Forces") + body("Lesson 1: Gravity") + body("Lesson 2: Friction") + body("Unit 2: Energy") + body("Lesson 1: Heat")
        self.assertEqual(flat(bookread.analyze(lines)["units"]), [("Unit 1: Forces", ["Lesson 1: Gravity", "Lesson 2: Friction"]), ("Unit 2: Energy", ["Lesson 1: Heat"])])

    def test_page_numbers_that_do_not_rise_are_not_a_contents_page(self):
        junk = ["مقدمة", "عدد الطلاب 25", "عدد المعلمين 9", "عدد الفصول 4", "عدد الصفوف 3", "عدد القاعات 2", "نص عادي"]
        self.assertIsNone(bookread.find_toc(junk))

    def test_a_running_header_on_every_page_is_not_content_and_not_a_heading(self):
        lines, pages = [], []
        for p in range(1, 13):
            lines.append("الوحدة الأولى: المادة"); pages.append(p)          # printed on every page
            if p == 2:
                chunk = body("الدرس الأول: خصائص المادة")
            elif p == 6:
                chunk = body("الدرس الثاني: حالات المادة")
            else:
                chunk = body(f"فقرة {p}", 2)
            lines += chunk; pages += [p] * len(chunk)
        r = bookread.analyze(lines, pages)
        # the unit named at the top of every page is one unit (once), and the line is not repeated inside the lessons
        self.assertEqual(flat(r["units"]), [("الوحدة الأولى: المادة", ["الدرس الأول: خصائص المادة", "الدرس الثاني: حالات المادة"])])
        for les in r["units"][0]["lessons"]:
            self.assertNotIn("الوحدة الأولى", les["text"])
            self.assertGreater(les["text"].count("جملة"), 3)

    def test_nothing_to_go_on_is_an_empty_answer_with_a_sentence(self):
        r = bookread.analyze(["جملة عادية تتحدث عن موضوع ما", "وجملة أخرى", "وثالثة"])
        self.assertEqual(r["units"], [])
        self.assertIn("الصقي الفهرس", r["warn"])

    def test_the_contents_pasted_by_the_teacher(self):
        units = bookread.parse_outline("الوحدة الأولى: الأعداد\nالدرس الأول: الجمع\nالدرس الثاني: الطرح\nالوحدة الثانية\nالكسور 12\nالمقارنة")
        self.assertEqual(flat(units), [("الوحدة الأولى: الأعداد", ["الدرس الأول: الجمع", "الدرس الثاني: الطرح"]), ("الوحدة الثانية", ["الكسور", "المقارنة"])])
        self.assertEqual(units[1]["lessons"][0]["first_page"], 12)
        indented = bookread.parse_outline("الأعداد\n   الجمع\n   الطرح\nالكسور\n   العادية\n   العشرية")
        self.assertEqual(flat(indented), [("الأعداد", ["الجمع", "الطرح"]), ("الكسور", ["العادية", "العشرية"])])
        self.assertEqual(flat(bookread.parse_outline("الجمع\nالطرح\nالضرب")), [("", ["الجمع", "الطرح", "الضرب"])])
        self.assertEqual(bookread.parse_outline("   \n\n"), [])

    def test_the_subject_and_the_class_named_by_the_book(self):
        self.assertEqual(bookread.detect_meta("المادة: الرياضيات\nالصف: الأول المتوسط", "x.pdf"), ("الرياضيات", "الأول المتوسط"))
        self.assertEqual(bookread.detect_meta("كتاب الطالب\nالعلوم للصف الثالث الابتدائي", "book.pdf", ["حاسب"]), ("العلوم", "الثالث الابتدائي"))
        self.assertEqual(bookread.detect_meta("نص بلا اسم", "لغتي الخالدة.pdf")[0], "لغتي الخالدة")
        self.assertEqual(bookread.detect_meta("نص بلا اسم", "x.pdf"), ("", ""))

    def test_a_real_pdf_book(self):
        info = extract.book_lines("pdf", X.book_pdf())
        self.assertEqual(info["page_count"], 12)
        r = bookread.analyze(info["lines"], info["pages"], info["hints"])
        self.assertTrue(r["toc"])
        self.assertEqual([len(u["lessons"]) for u in r["units"]], [3, 3])
        lessons = [l for u in r["units"] for l in u["lessons"]]
        self.assertEqual([l["kind"] for l in lessons], ["lesson", "lesson", "review", "lesson", "lesson", "exam"])
        self.assertTrue(all(len(l["text"]) > 300 for l in lessons))
        self.assertNotIn("الرياضيات - الصف الأول المتوسط", lessons[0]["text"])          # the running header of every page is gone
        subject, grade = bookread.detect_meta(info["first_text"], "book.pdf")
        self.assertEqual((subject, grade), ("الرياضيات", "الأول المتوسط"))

    def test_a_word_book_with_and_without_heading_styles(self):
        for headings in (True, False):
            info = extract.book_lines("docx", X.book_docx(headings))
            r = bookread.analyze(info["lines"], info["pages"], info["hints"])
            self.assertEqual([u["title"] for u in r["units"]], ["الوحدة الأولى: الأعداد الصحيحة", "الوحدة الثانية: الكسور"], headings)
            self.assertEqual([len(u["lessons"]) for u in r["units"]][0] >= 2, True)
        # a Word book that names no unit or lesson: its Heading 1 are the lessons
        from tests.files5 import _p, docx_bytes
        body_xml = "".join(_p(t, "Heading1") + "".join(_p(f"جملة شرح {i} عن {t} فيها معلومة مفيدة للطالبات.") for i in range(4)) for t in ("الجمع", "الطرح", "الضرب"))
        info = extract.book_lines("docx", docx_bytes(body_xml))
        self.assertEqual(flat(bookread.analyze(info["lines"], None, info["hints"])["units"]), [("", ["الجمع", "الطرح", "الضرب"])])

    def test_a_file_that_is_not_a_book_is_a_sentence(self):
        with self.assertRaises(extract.ExtractError):
            extract.detect_book("a.exe", b"MZ\x90")
        with self.assertRaises(extract.ExtractError) as e:
            extract.detect_book("old.doc", b"\xd0\xcf\x11\xe0")
        self.assertIn("docx", str(e.exception))
        self.assertEqual(extract.detect_book("a.docx", b"PK\x03\x04"), "docx")
        self.assertEqual(extract.detect_book("a.pdf", b"%PDF-1.7"), "pdf")


# ---------------------------------------------------------------- lessons over periods
class ContentsTable(unittest.TestCase):
    """A contents page that is a table: the title is in one cell and the page number in another, and the reader gives each cell its own line."""
    HEAD = ["المحتويات", "الموضوع", "الصفحة"]
    ROWS = [("المقدمة", 6), ("أولًا: السنة النبوية", 8), ("تعريف السنة النبوية", 9), ("حفظ السنة النبوية", 12), ("ثانيًا: الأحاديث", 21),
            ("الحديث الأول: «مثل ما بعثني الله به»", 22), ("الحديث الثاني: «من سن في الإسلام سنة حسنة»", 26), ("الحديث الثالث: «إن الحلال بين»", 30),
            ("الحديث الرابع: «سبعة يظلهم الله في ظله»", 33)]

    def cells(self, rows):
        return [x for title, page in rows for x in (title, str(page))]

    def book(self, toc, pages=4):
        lines = ["كتاب الحديث", "الصف الثاني الثانوي"] + toc
        for title, _ in self.ROWS:
            lines += body(title.split(":")[0] if title.startswith("الحديث") else title, pages)          # a page for every entry, headed by its label
        return lines

    def lessons(self, r):
        return [(u["title"], [l["title"] for l in u["lessons"]]) for u in r["units"]]

    def test_title_and_page_number_on_two_lines_are_one_entry(self):
        r = bookread.analyze(self.book(self.HEAD + self.cells(self.ROWS)))
        self.assertTrue(r["toc"])
        self.assertEqual([(t, len(ls)) for t, ls in self.lessons(r)], [("أولًا: السنة النبوية", 2), ("ثانيًا: الأحاديث", 4)])
        first = r["units"][1]["lessons"][0]
        self.assertEqual(first["title"], "الحديث الأول: «مثل ما بعثني الله به»")
        self.assertEqual((first["first_page"], first["last_page"]), (22, 25))
        self.assertEqual(r["units"][0]["lessons"][0]["first_page"], 9)

    def test_the_page_after_the_label_is_found_in_the_book_and_its_text_is_kept(self):
        r = bookread.analyze(self.book(self.HEAD + self.cells(self.ROWS)))
        self.assertEqual(r["matched"], len(self.ROWS))
        self.assertEqual(r["warn"], "")
        les = r["units"][1]["lessons"]
        self.assertEqual(les[0]["text"].count("جملة شرح"), 4)
        self.assertIn("الحديث الأول", les[0]["text"])
        self.assertNotIn("الحديث الثاني", les[0]["text"])
        self.assertEqual(les[1]["text"].count("جملة شرح"), 4)

    def test_a_table_that_goes_on_over_the_next_page_is_one_contents(self):
        foot = ["وزارة التعليم", "Ministry of Education", "2025 - 1447"]
        r = bookread.analyze(self.book(self.HEAD + self.cells(self.ROWS[:6]) + foot + self.HEAD[1:] + self.cells(self.ROWS[6:])))
        self.assertEqual([(t, len(ls)) for t, ls in self.lessons(r)], [("أولًا: السنة النبوية", 2), ("ثانيًا: الأحاديث", 4)])

    def test_a_title_wrapped_over_two_lines_with_its_number_between_them(self):
        rows = self.cells(self.ROWS[:7]) + ["الحديث الثالث: أن رجلًا قدم من جيشان فسأل النبي عن شراب يشربونه بأرضهم من الذرة", "30", "يقال له المزر فقال أو مسكر هو"] + self.cells(self.ROWS[8:])
        r = bookread.analyze(self.book(self.HEAD + rows))
        lessons = r["units"][1]["lessons"]
        self.assertEqual(len(lessons), 4)
        self.assertTrue(lessons[2]["title"].startswith("الحديث الثالث: أن رجلًا قدم من جيشان"))
        self.assertEqual(lessons[2]["first_page"], 30)

    def test_a_piece_of_the_title_that_lands_between_the_first_piece_and_the_number_is_part_of_the_title(self):
        stray = ["الحديث الثالث: أن رجلًا قدم من جيشان فسأل النبي", "صلى الله عليه وسلم", "30", "عن شراب يشربونه بأرضهم"]
        r = bookread.analyze(self.book(self.HEAD + self.cells(self.ROWS[:7]) + stray + self.cells(self.ROWS[8:])))
        lessons = r["units"][1]["lessons"]
        self.assertEqual(len(lessons), 4)
        self.assertEqual(lessons[2]["title"], "الحديث الثالث: أن رجلًا قدم من جيشان فسأل النبي صلى الله عليه وسلم")
        self.assertEqual(lessons[2]["first_page"], 30)

    def test_a_second_table_that_starts_again_from_low_numbers_is_not_part_of_the_contents(self):
        more = ["جدول الأشكال", "الشكل الأول", "3", "الشكل الثاني", "4", "الشكل الثالث", "5", "الشكل الرابع", "6"]
        r = bookread.analyze(self.book(self.HEAD + self.cells(self.ROWS) + ["ملاحظة", "نهاية الفهرس"] + more))
        self.assertEqual([len(u["lessons"]) for u in r["units"]], [2, 4])

    def test_a_number_alone_under_a_line_of_a_page_is_not_a_contents_table(self):
        lines = []
        for n in range(1, 9):
            lines += [f"جملة من الصفحة {n} تشرح موضوعًا في الكتاب بكلمات كثيرة ليست عنوانًا", "هذا سطر آخر من الصفحة نفسها فيه شرح", str(n)]
        r = bookread.analyze(lines)
        self.assertFalse(r["toc"])
        self.assertEqual(r["units"], [])

    def test_a_row_is_not_made_of_two_numbers_or_of_a_title_that_is_long_text(self):
        rows, first, last = bookread._rows(["12", "13", "نص " * 60, "14", "وحدة 1", "5"], 6)
        self.assertEqual(rows[:2], ["12", "13"])
        self.assertEqual(rows[2], "نص " * 60)            # long text followed by a number is not a row: (the number would be a page's foot)
        self.assertEqual((rows[3], rows[4]), ("14", "وحدة 1  5"))
        self.assertEqual((first[4], last[4]), (4, 5))

    def test_the_groups_of_a_table_open_with_first_second_and_third(self):
        for word in ("أولًا", "ثانيًا", "ثالثًا", "رابعًا"):
            self.assertEqual(bookread.classify(f"{word}: القسم", strict=False)[0], "unit")
            self.assertIsNone(bookread.classify(f"{word}: القسم", strict=True)[0])          # in the pages themselves it is only a numbered point

    def test_the_dots_that_trail_off_a_saying_do_not_leave_a_gap_before_its_quote(self):
        self.assertEqual(bookread.clean_title("الحديث الأول: «مثل ما بعثني الله به...»"), "الحديث الأول: «مثل ما بعثني الله به»")
        self.assertEqual(bookread.clean_title("الدرس الأول ......... 5"), "الدرس الأول 5")

    def test_the_contents_pasted_from_a_table_has_the_numbers_on_their_own_lines(self):
        pasted = "\n".join(self.HEAD + self.cells(self.ROWS))
        units = bookread.parse_outline(pasted)
        self.assertEqual([(u["title"], len(u["lessons"])) for u in units], [("أولًا: السنة النبوية", 2), ("ثانيًا: الأحاديث", 4)])
        self.assertEqual(units[1]["lessons"][0]["first_page"], 22)
        self.assertFalse(any(l["title"].isdigit() for u in units for l in u["lessons"]))
        self.assertEqual(bookread.parse_outline("الدرس الأول\n5\n٦\nالدرس الثاني\n١٢")[0]["lessons"][1]["first_page"], 12)          # a number alone is never a lesson

    def test_a_real_pdf_with_a_contents_table(self):
        info = extract.book_lines("pdf", X.table_book_pdf())
        r = bookread.analyze(info["lines"], info["pages"], info["hints"])
        self.assertTrue(r["toc"])
        self.assertEqual([len(u["lessons"]) for u in r["units"]], [2, 8])
        hadith = r["units"][1]["lessons"]
        self.assertEqual([l["first_page"] for l in hadith], [22, 26, 30, 33, 38, 41, 45, 48])
        self.assertTrue(hadith[6]["title"].startswith("الحديث السابع: أن رجل"))          # the one that wraps over two lines of its cell
        self.assertTrue(all(len(l["text"]) > 300 for l in hadith))
        self.assertEqual(r["warn"], "")

    def test_the_same_pdf_without_the_foot_of_the_page(self):
        info = extract.book_lines("pdf", X.table_book_pdf(foot=False))
        r = bookread.analyze(info["lines"], info["pages"], info["hints"])
        self.assertEqual([len(u["lessons"]) for u in r["units"]], [2, 8])


class Planner(unittest.TestCase):
    START = D(2026, 9, 6)          # a Sunday

    def test_the_weekdays_are_counted_the_way_a_saudi_timetable_does(self):
        self.assertEqual([planner.sun0(self.START + datetime.timedelta(days=i)) for i in range(7)], [0, 1, 2, 3, 4, 5, 6])

    def test_the_periods_of_a_class_are_the_cells_of_its_timetable_over_the_term(self):
        occ = planner.occurrences([(0, 1), (2, 2)], self.START, self.START + datetime.timedelta(days=13))
        self.assertEqual([(o.day.isoformat(), o.period) for o in occ], [("2026-09-06", 1), ("2026-09-08", 2), ("2026-09-13", 1), ("2026-09-15", 2)])

    def test_holidays_and_her_absences_take_periods_away(self):
        end = self.START + datetime.timedelta(days=13)
        occ = planner.occurrences([(0, 1), (2, 2)], self.START, end, holidays={D(2026, 9, 8)}, absent={(D(2026, 9, 13), None)})
        self.assertEqual([(o.day.isoformat(), o.period) for o in occ], [("2026-09-06", 1), ("2026-09-15", 2)])
        occ = planner.occurrences([(0, 1), (0, 2)], self.START, end, absent={(D(2026, 9, 6), 2)})          # one period of a day only
        self.assertEqual([(o.day.isoformat(), o.period) for o in occ], [("2026-09-06", 1), ("2026-09-13", 1), ("2026-09-13", 2)])

    def test_counting_starts_from_a_day(self):
        occ = planner.occurrences([(0, 1)], self.START, self.START + datetime.timedelta(days=20), first=D(2026, 9, 7))
        self.assertEqual([o.day.isoformat() for o in occ], ["2026-09-13", "2026-09-20"])
        self.assertEqual(planner.occurrences([(0, 1)], self.START, self.START, first=D(2026, 9, 7)), [])

    def items(self, *periods, statuses=None):
        statuses = statuses or ["pending"] * len(periods)
        return [{"id": i + 1, "periods": p, "status": s} for i, (p, s) in enumerate(zip(periods, statuses))]

    def occs(self, n):
        return planner.occurrences([(0, 1)], self.START, self.START + datetime.timedelta(days=7 * n), first=None)[:n]

    def test_lessons_take_the_periods_in_order_and_a_long_lesson_takes_several(self):
        plan, unplaced = planner.assign(self.items(1, 2, 1), self.occs(5))
        self.assertEqual(unplaced, 0)
        self.assertEqual(plan[1][0], plan[1][1])
        self.assertEqual((plan[2][0].day.isoformat(), plan[2][1].day.isoformat()), ("2026-09-13", "2026-09-20"))
        self.assertEqual(plan[3][0].day.isoformat(), "2026-09-27")

    def test_a_lesson_done_or_skipped_takes_no_period(self):
        plan, _ = planner.assign(self.items(1, 1, 1, statuses=["done", "skipped", "pending"]), self.occs(3))
        self.assertEqual(list(plan), [3])
        self.assertEqual(plan[3][0].day.isoformat(), "2026-09-06")

    def test_lessons_that_do_not_fit_are_counted_and_never_dropped(self):
        plan, unplaced = planner.assign(self.items(1, 2, 1, 1), self.occs(3))
        self.assertEqual(set(plan), {1, 2})
        self.assertEqual(unplaced, 2)          # the third and the fourth have no period left; they are still in the list

    def test_the_day_each_lesson_is_due_when_the_plan_is_made(self):
        due = planner.baseline(self.items(1, 2, 1, statuses=["pending", "pending", "skipped"]), self.occs(4))
        self.assertEqual({k: v.day.isoformat() for k, v in due.items()}, {1: "2026-09-06", 2: "2026-09-20"})

    def test_where_the_plan_stands(self):
        items = self.items(1, 1, 2, 1, statuses=["done", "done", "pending", "pending"])
        for it, d in zip(items, (D(2026, 9, 6), D(2026, 9, 13), D(2026, 9, 20), D(2026, 9, 27))):
            it["due"] = d
        s = planner.summary(items, self.occs(3), D(2026, 9, 25), D(2026, 12, 17))
        self.assertEqual((s["done"], s["pending"], s["periods_total"], s["periods_done"], s["percent"]), (2, 2, 5, 2, 40))
        self.assertEqual(s["late"], [3])          # due on 20 September, not done on the 25th
        self.assertEqual((s["periods_left"], s["periods_needed"], s["spare"]), (3, 3, 0))
        self.assertEqual(s["current"], 3)
        self.assertGreater(s["weeks_left"], 10)
        short = planner.summary(items, self.occs(2), D(2026, 9, 25))
        self.assertEqual(short["spare"], -1)

    def test_periods_are_shared_out_by_the_size_of_each_lesson(self):
        self.assertEqual(planner.suggest_periods([1, 1, 2], 8), [2, 2, 4])
        self.assertEqual(sum(planner.suggest_periods([3, 5, 2, 9, 1], 23)), 23)
        self.assertTrue(all(p >= 1 for p in planner.suggest_periods([0, 0, 10], 5)))
        self.assertEqual(planner.suggest_periods([5, 5, 5], 3), [1, 1, 1])
        self.assertEqual(planner.suggest_periods([5, 5, 5], 2), [1, 1, 1])
        self.assertEqual(planner.suggest_periods([], 5), [])
        self.assertEqual(planner.suggest_periods([0, 0], 6), [3, 3])

    def test_plenty_of_periods_are_not_poured_into_a_few_lessons(self):
        self.assertEqual(planner.suggest_periods([1, 1, 1], 42, cap=4), [4, 4, 4])          # the rest stays free for revision and exams
        self.assertEqual(planner.suggest_periods([1, 1, 2], 8, cap=3), [3, 2, 3])          # a capped lesson hands its extra period to the next one
        self.assertEqual(sum(planner.suggest_periods([3, 5, 2, 9, 1], 23, cap=4)), 20)
        self.assertEqual(planner.suggest_periods([1, 1, 2], 8, cap=None), [2, 2, 4])          # no cap, no change
        self.assertTrue(all(1 <= p <= planner.MAX_SHARED_PERIODS for p in planner.suggest_periods([1, 2, 3, 4, 5, 6], 60, cap=planner.MAX_SHARED_PERIODS)))
        self.assertEqual(planner.suggest_periods([4, 4], 2, cap=4), [1, 1])

    def test_lessons_that_could_be_taught_together_are_the_shortest_neighbours(self):
        items = [{"id": i, "periods": 1, "status": "pending", "kind": "lesson"} for i in range(1, 6)]
        ideas = planner.merge_ideas(items, 2, {1: 8, 2: 1, 3: 1, 4: 9, 5: 7})
        self.assertEqual(ideas, [(2, 3), (4, 5)])
        self.assertEqual(planner.merge_ideas(items, 0), [])
        self.assertEqual(planner.merge_ideas(items[:1], 3), [])


# ---------------------------------------------------------------- the timetable
SUBJ = ["الرياضيات", "العلوم"]


class Timetable(unittest.TestCase):
    ACROSS = [["الحصة", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس"],
              ["الأولى 7:00-7:45", "أول/أ رياضيات", "", "ثاني/ب علوم", "", "أول/أ رياضيات"],
              ["الثانية 7:45-8:30", "", "أول/ب رياضيات", "", "أول/أ علوم", ""],
              ["الثالثة 8:30-9:15", "فراغ", "-", "أول/أ رياضيات", "أول/ب رياضيات", "ثاني/ب علوم"],
              ["الرابعة", "ثاني/ب علوم", "", "", "", ""]]
    DOWN = [["اليوم", "1", "2", "3", "4", "5", "6", "7"],
            ["الأحد", "الصف الأول أ - الرياضيات", "", "الصف الثاني ب - العلوم", "", "", "", ""],
            ["الاثنين", "", "الصف الأول ب - الرياضيات", "", "", "", "", ""],
            ["الثلاثاء", "", "", "", "الصف الأول أ - العلوم", "", "", ""],
            ["الأربعاء", "الصف الأول أ - الرياضيات", "", "", "", "", "", ""],
            ["الخميس", "", "", "الصف الثاني ب - العلوم", "", "", "", ""]]

    def cells(self, parsed):
        return sorted((c["day"], c["period"], c["class"], c["subject"]) for c in parsed["cells"])

    def test_days_across_the_top_and_periods_down_the_side(self):
        parsed = timetable.parse(tables.read_xlsx(X.xlsx_bytes({"جدول": self.ACROSS})), SUBJ)
        self.assertEqual(len(parsed["cells"]), 9)          # the empty cells, the dash and «فراغ» are not lessons
        self.assertEqual(parsed["periods"], 4)
        self.assertEqual(parsed["times"], {1: ("07:00", "07:45"), 2: ("07:45", "08:30"), 3: ("08:30", "09:15")})
        self.assertIn((0, 1, "أول/أ", "الرياضيات"), self.cells(parsed))
        self.assertIn((4, 3, "ثاني/ب", "العلوم"), self.cells(parsed))
        self.assertNotIn((0, 3), [(c[0], c[1]) for c in self.cells(parsed)])

    def test_days_down_the_side_and_periods_across_the_top(self):
        parsed = timetable.parse(tables.read_xlsx(X.xlsx_bytes({"Sheet1": self.DOWN})), [])
        self.assertEqual(self.cells(parsed)[0], (0, 1, "الصف الأول أ", "الرياضيات"))
        self.assertEqual(len(parsed["cells"]), 6)
        self.assertEqual(parsed["periods"], 7)

    def test_the_same_table_in_a_word_file(self):
        d = X.docx_bytes(X._p("جدول المعلمة") + X._tbl(self.ACROSS))
        parsed = timetable.parse(tables.docx_sheets(tables.read_docx(d)), SUBJ)
        self.assertEqual(len(parsed["cells"]), 9)

    def test_a_timetable_given_as_lines_of_text(self):
        text = "جدول الحصص\nالأحد   أول/أ رياضيات   ثاني/ب علوم\nالاثنين   أول/ب رياضيات\nالثلاثاء   أول/أ رياضيات"
        parsed = timetable.parse(tables.sheets_from_text(text), SUBJ)
        self.assertEqual(self.cells(parsed), [(0, 1, "أول/أ", "الرياضيات"), (0, 2, "ثاني/ب", "العلوم"), (1, 1, "أول/ب", "الرياضيات"), (2, 1, "أول/أ", "الرياضيات")])

    LIST = [["اليوم", "رقم الحصة", "الفصل", "المادة", "المقرر", "ملاحظة"],
            ["الأحد", 2, "1/1", "الدراسات الإسلامية", "القرآن الكريم وتفسيره", "الدرس 1 ثم متابعة التسلسل الأسبوعي"],
            ["الأحد", 3, "1/2", "الدراسات الإسلامية", "القرآن الكريم وتفسيره", "الدرس 1"],
            ["الأربعاء", 4, "1/1", "الدراسات الإسلامية", "الحديث 1", "الدرس 2"],
            ["الخميس", 2, "1/2", "الدراسات الإسلامية", "الحديث 1", ""]]

    def test_a_timetable_written_as_a_list_one_row_for_every_period(self):
        r = timetable.parse(tables.read_sheets("xlsx", X.xlsx_bytes({"جدول المعلم": self.LIST})))
        got = [(c["day"], c["period"], c["class"], c["subject"]) for c in r["cells"]]
        self.assertEqual(got, [(0, 2, "1/1", "الدراسات الإسلامية"), (0, 3, "1/2", "الدراسات الإسلامية"), (3, 4, "1/1", "الدراسات الإسلامية"), (4, 2, "1/2", "الدراسات الإسلامية")])
        self.assertEqual(r["periods"], 4)

    def test_a_list_with_only_the_class_or_with_the_period_in_words_and_a_blank_row(self):
        rows = [["اليوم", "الحصة", "الصف"], ["الأحد", "الأولى", "أول ثانوي أ"], ["", "", ""], ["الاثنين", "الثالثة", "أول ثانوي ب"], ["الاثنين", "الرابعة", "فراغ"]]
        r = timetable.parse(tables.read_sheets("xlsx", X.xlsx_bytes({"ورقة": rows})))
        self.assertEqual([(c["day"], c["period"], c["class"], c["subject"]) for c in r["cells"]], [(0, 1, "أول ثانوي أ", ""), (1, 3, "أول ثانوي ب", "")])

    def test_a_list_gives_her_classes_and_subjects_when_she_has_them(self):
        r = timetable.parse(tables.read_sheets("xlsx", X.xlsx_bytes({"جدول المعلم": self.LIST})))
        out = timetable.resolve(r, [(7, "الصف الأول 1"), (8, "الصف الأول 2")], [(3, "الدراسات الإسلامية")])
        self.assertEqual([(c["class_id"], c["subject_id"]) for c in out["cells"]], [(7, 3), (8, 3), (7, 3), (8, 3)])

    def test_a_text_that_is_not_a_timetable_gives_nothing(self):
        self.assertIsNone(timetable.parse(tables.sheets_from_text("مرحبا\nهذا نص عادي"), []))
        self.assertIsNone(timetable.parse([{"name": "", "rows": [["a", "b"], ["c", "d"]]}], []))

    def test_the_class_and_the_subject_in_a_cell(self):
        cases = {"1/3 رياضيات": ("1/3", "الرياضيات"), "أول/أ - الفقه": ("أول/أ", "الفقه"), "رياضيات (أول أ)": ("أول أ", "الرياضيات"),
                 "الصف الثاني (ب) - لغتي الخالدة": ("الصف الثاني (ب)", "لغتي الخالدة"), "علوم": ("", "العلوم"), "الصف الأول أ": ("الصف الأول أ", ""),
                 "ثالث/ج إنجليزي": ("ثالث/ج", "اللغة الإنجليزية")}
        for raw, want in cases.items():
            self.assertEqual(timetable.split_cell(raw, ["العلوم"]), want, raw)

    def test_periods_days_and_times_are_read_in_the_ways_they_are_written(self):
        self.assertEqual([timetable.period_of(x) for x in ["الأولى", "الحصة 3", "3", "الثانية عشرة", "السابعة 11:00-11:45", "الحادية عشرة", "الأحد"]], [1, 3, 3, 12, 7, 11, None])
        self.assertEqual([timetable.day_of(x) for x in ["الأحد", "يوم الاثنين", "الأربعاء", "الخميس 12/11", "السبت", "رياضيات"]], [0, 1, 3, 4, 6, None])
        self.assertEqual(timetable.time_of("الأولى 7:00 - 7:45"), ("07:00", "07:45"))
        self.assertIsNone(timetable.time_of("25:00-26:00"))

    def test_her_classes_are_matched_by_grade_and_section_and_never_guessed_between_two(self):
        classes = [(1, "الصف الأول أ"), (2, "الصف الأول ب"), (3, "الصف الثاني أ")]
        self.assertEqual([timetable.match_class(x, classes) for x in ("أول/أ", "الأول ب", "1 أ", "ثاني أ", "الصف الأول أ")], [1, 2, 1, 3, 1])
        self.assertIsNone(timetable.match_class("الصف الأول", classes))          # two sections: which one?
        self.assertIsNone(timetable.match_class("خامس ج", classes))
        self.assertIsNone(timetable.match_class("", classes))
        self.assertEqual(timetable.match_subject("رياضيات", [(1, "الرياضيات"), (2, "العلوم")]), 1)
        self.assertIsNone(timetable.match_subject("فقه", [(1, "الرياضيات")]))


if __name__ == "__main__":
    unittest.main()
