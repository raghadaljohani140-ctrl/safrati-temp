// مراجعة الكتاب: the units and lessons the reader found, as a list she can fix (names, periods, order, adding, removing) and then confirm.
(function () {
  const id = Number(document.getElementById('book-app').dataset.id);
  const $ = x => document.getElementById(x);
  const say = (x, text) => { const n = $(x); n.textContent = text || ''; n.hidden = !text; };
  const KINDS = [['lesson', 'درس'], ['review', 'مراجعة'], ['exam', 'اختبار']];
  const COMMON = ['القرآن الكريم', 'التوحيد', 'الفقه', 'الحديث', 'اللغة العربية', 'لغتي', 'الرياضيات', 'العلوم', 'اللغة الإنجليزية', 'الاجتماعيات', 'الحاسب وتقنية المعلومات', 'التربية الفنية', 'التربية البدنية'];
  const lessonsWord = n => arCount(n, ['درس واحد', 'درسان', 'دروس', 'درسًا']);
  let B = null, S = null, dirty = false, timer = null, focusKey = null;

  const touch = () => { dirty = true; $('bk-saved').textContent = ''; };
  window.addEventListener('beforeunload', e => { if (dirty) { e.preventDefault(); e.returnValue = ''; } });

  function fromServer(b, keep) {
    return {
      title: (keep && keep.title) || b.title, subject: (keep && keep.subject) || b.subject, grade: (keep && keep.grade) || b.grade,
      units: b.units.map(u => ({id: u.id, title: u.title, lessons: u.lessons.map(l => ({id: l.id, title: l.title, periods: l.periods, kind: l.kind, first: l.first_page, last: l.last_page, hasText: l.has_text, done: l.done}))})),
      classIds: keep ? keep.classIds : new Set(b.classes.filter(c => c.linked).map(c => c.id)),
    };
  }
  const blank = () => ({id: null, title: '', periods: 1, kind: 'lesson', first: 0, last: 0, hasText: false, done: 0});

  // ---------------------------------------------------------------- the tree
  function ib(text, label, fn, extra) {
    const b = el('button', Object.assign({type: 'button', class: 'ib', text, 'aria-label': label}, extra || {})); b.addEventListener('click', fn); return b;
  }
  function moveUnit(ui, dir) {
    const j = ui + dir; if (j < 0 || j >= S.units.length) return;
    [S.units[ui], S.units[j]] = [S.units[j], S.units[ui]]; touch(); focusKey = 'u' + j + (dir < 0 ? '-up' : '-dn'); drawTree();
  }
  function moveLesson(ui, li, dir) {
    const u = S.units[ui], l = u.lessons[li];
    if (dir < 0) {
      if (li > 0) { [u.lessons[li - 1], u.lessons[li]] = [l, u.lessons[li - 1]]; focusKey = 'u' + ui + 'l' + (li - 1) + '-up'; }
      else if (ui > 0) { u.lessons.splice(li, 1); const p = S.units[ui - 1]; p.lessons.push(l); focusKey = 'u' + (ui - 1) + 'l' + (p.lessons.length - 1) + '-up'; }
      else return;
    } else {
      if (li < u.lessons.length - 1) { [u.lessons[li + 1], u.lessons[li]] = [l, u.lessons[li + 1]]; focusKey = 'u' + ui + 'l' + (li + 1) + '-dn'; }
      else if (ui < S.units.length - 1) { u.lessons.splice(li, 1); S.units[ui + 1].lessons.unshift(l); focusKey = 'u' + (ui + 1) + 'l0-dn'; }
      else return;
    }
    touch(); drawTree();
  }
  function lessonRow(u, l, ui, li) {
    const base = 'u' + ui + 'l' + li;
    const title = el('input', {class: 'les-title', value: l.title, maxlength: 140, placeholder: 'عنوان الدرس', 'aria-label': 'عنوان الدرس', 'data-fk': base + '-t'});
    title.addEventListener('input', () => { l.title = title.value; touch(); summary(); });
    const kind = el('select', {class: 'kind', 'aria-label': 'نوع الدرس'}, ...KINDS.map(([v, t]) => el('option', Object.assign({value: v, text: t}, l.kind === v ? {selected: true} : {}))));
    kind.addEventListener('change', () => { l.kind = kind.value; touch(); });
    const periods = stepper(l.periods, 1, 6, v => { l.periods = v; touch(); summary(); }, 'عدد حصص الدرس');
    const info = [l.first ? 'ص ' + l.first + (l.last > l.first ? '–' + l.last : '') : '', l.hasText ? 'نصه موجود ✓' : 'بلا نص'].filter(Boolean).join(' · ');
    const last = ui === S.units.length - 1 && li === u.lessons.length - 1;
    const first = ui === 0 && li === 0;
    const up = ib('▲', 'تحريك الدرس لأعلى', () => moveLesson(ui, li, -1), {'data-fk': base + '-up', disabled: first});
    const dn = ib('▼', 'تحريك الدرس لأسفل', () => moveLesson(ui, li, 1), {'data-fk': base + '-dn', disabled: last});
    const del = ib('✕', 'حذف الدرس', () => {
      if (l.done && !confirm('هذا الدرس مسجّل منجزًا في خطة فصل. حذفه من الكتاب يحذفه من الخطة أيضًا. حذفه؟')) return;
      u.lessons.splice(li, 1); touch(); drawTree();
    }, {class: 'ib bad'});
    return el('li', {class: 'les'}, el('div', {class: 'les-top'}, title),
      el('div', {class: 'les-bot'}, el('span', {class: 'les-per'}, periods, el('small', {text: 'حصص'})), kind, el('small', {class: 'les-info muted', text: info}), el('span', {class: 'les-btns'}, up, dn, del)));
  }
  function unitCard(u, ui) {
    const title = el('input', {class: 'unit-title', value: u.title, maxlength: 140, placeholder: 'اسم الوحدة (اتركيه فارغًا لدروس بلا وحدة)', 'aria-label': 'اسم الوحدة', 'data-fk': 'u' + ui + '-t'});
    title.addEventListener('input', () => { u.title = title.value; touch(); summary(); });
    const del = ib('✕', 'حذف الوحدة', () => {
      if (u.lessons.length && !confirm('حذف هذه الوحدة وكل دروسها (' + lessonsWord(u.lessons.length) + ') من الكتاب؟')) return;
      S.units.splice(ui, 1); touch(); drawTree();
    }, {class: 'ib bad'});
    const head = el('div', {class: 'unit-head'}, el('span', {class: 'unit-ico', 'aria-hidden': 'true', text: '📚'}), title,
      ib('▲', 'تحريك الوحدة لأعلى', () => moveUnit(ui, -1), {'data-fk': 'u' + ui + '-up', disabled: ui === 0}),
      ib('▼', 'تحريك الوحدة لأسفل', () => moveUnit(ui, 1), {'data-fk': 'u' + ui + '-dn', disabled: ui === S.units.length - 1}), del);
    const list = el('ol', {class: 'les-list'}, ...u.lessons.map((l, li) => lessonRow(u, l, ui, li)));
    const add = el('button', {class: 'btn ghost small', type: 'button', text: '+ إضافة درس'});
    add.addEventListener('click', () => { u.lessons.push(blank()); touch(); focusKey = 'u' + ui + 'l' + (u.lessons.length - 1) + '-t'; drawTree(); });
    return el('section', {class: 'card unit'}, head, list, el('div', {class: 'btn-row'}, add));
  }
  function drawTree() {
    const box = $('bk-tree'); box.replaceChildren(...S.units.map(unitCard));
    if (focusKey) {
      let t = box.querySelector('[data-fk="' + focusKey + '"]');
      if (t && t.disabled) t = box.querySelector('[data-fk="' + focusKey.replace(/-(up|dn)$/, m => m === '-up' ? '-dn' : '-up') + '"]');
      if (t && !t.disabled) t.focus();
      focusKey = null;
    }
    summary();
  }
  function summary() {
    const les = S.units.reduce((a, u) => a + u.lessons.filter(l => l.title.trim()).length, 0), per = S.units.reduce((a, u) => a + u.lessons.filter(l => l.title.trim()).reduce((x, l) => x + l.periods, 0), 0);
    const units = S.units.filter(u => u.title.trim() && u.lessons.length).length;
    $('bk-sum').textContent = (units ? arCount(units, ['وحدة واحدة', 'وحدتان', 'وحدات', 'وحدة']) + ' · ' : '') + lessonsWord(les) + ' · تحتاج ' + arCount(per, ['حصة واحدة', 'حصتين', 'حصص', 'حصة']) + ' بحسب ما ضبطتِ';
  }

  // ---------------------------------------------------------------- the rest of the page
  function drawClasses() {
    const box = $('bk-classes'); box.replaceChildren();
    $('bk-noclass').hidden = !!B.classes.length;
    B.classes.forEach(c => {
      const on = S.classIds.has(c.id);
      const b = el('button', {type: 'button', class: 'chip-btn' + (on ? ' on' : ''), 'aria-pressed': on ? 'true' : 'false'}, c.name, c.other ? el('small', {text: on ? 'سيحل محل «' + c.other + '»' : 'يستخدم «' + c.other + '»'}) : null);
      b.addEventListener('click', () => { if (on) S.classIds.delete(c.id); else S.classIds.add(c.id); touch(); drawClasses(); });
      box.append(b);
    });
  }
  function drawHead() {
    $('bk-title').value = S.title; $('bk-subject').value = S.subject; $('bk-grade').value = S.grade;
    const names = [...new Set([...(B.subjects || []), ...COMMON])];
    $('bk-subjects').replaceChildren(...names.map(n => el('option', {value: n})));
    $('bk-unconfirmed').hidden = B.confirmed;
    say('bk-warn', B.warn); say('bk-error', B.status === 'failed' ? B.error : '');
    $('bk-paste').hidden = B.confirmed;
    $('bk-reread-row').hidden = B.confirmed || B.kind === 'manual' || !(B.warn || !B.lessons);          // only when the reading was not good and there is a file to read again
    if (!B.confirmed && !B.lessons) $('bk-paste').open = true;
    $('bk-classes-card').hidden = false;
  }
  function drawAll() { drawHead(); drawClasses(); drawTree(); }
  [['bk-title', 'title'], ['bk-subject', 'subject'], ['bk-grade', 'grade']].forEach(([x, k]) => $(x).addEventListener('input', () => { S[k] = $(x).value; touch(); }));

  async function load() {
    clearTimeout(timer);
    let d;
    try { d = await api('GET', '/api/books/' + id); } catch (e) { $('bk-wait').hidden = false; $('bk-wait').querySelector('h2').textContent = e.message; return; }
    B = d;
    if (d.status === 'processing') {
      $('bk-wait').hidden = false; $('bk-main').hidden = true;
      const p = $('bk-prog');
      if (d.pages) { p.max = d.pages; p.value = d.progress; $('bk-prog-text').textContent = 'قرأنا ' + d.progress + ' من ' + d.pages + ' صفحة'; }
      else { p.removeAttribute('value'); $('bk-prog-text').textContent = 'جارٍ القراءة…'; }
      timer = setTimeout(load, 1500); return;
    }
    $('bk-wait').hidden = true; $('bk-main').hidden = false;
    S = fromServer(d); dirty = false; drawAll();
    if (d.confirmed) { const first = [...S.classIds][0]; if (first) { $('bk-plan').href = '/plan?class=' + first; $('bk-plan').hidden = false; } }
  }

  // ---------------------------------------------------------------- saving
  $('bk-add-unit').addEventListener('click', () => { S.units.push({id: null, title: '', lessons: [blank()]}); touch(); focusKey = 'u' + (S.units.length - 1) + '-t'; drawTree(); });
  $('bk-save').addEventListener('click', async () => {
    say('bk-save-err', '');
    const units = S.units.map(u => ({id: u.id, title: u.title.trim(), lessons: u.lessons.filter(l => l.title.trim()).map(l => ({id: l.id, title: l.title.trim(), periods: l.periods, kind: l.kind}))})).filter(u => u.lessons.length);
    if (S.title.trim().length < 2) { say('bk-save-err', 'اكتبي اسم الكتاب'); $('bk-title').focus(); return; }
    if (S.subject.trim().length < 2) { say('bk-save-err', 'اكتبي اسم المادة'); $('bk-subject').focus(); return; }
    if (!units.length) { say('bk-save-err', 'أضيفي درسًا واحدًا على الأقل'); return; }
    const before = new Set(B.units.flatMap(u => u.lessons.map(l => l.id))), kept = new Set(units.flatMap(u => u.lessons.map(l => l.id)));
    const gone = [...before].filter(x => !kept.has(x)).length;
    if (gone && !confirm('حذفتِ ' + lessonsWord(gone) + ' من الكتاب، وسيُزال أيضًا من خطط الفصول. متابعة؟')) return;
    const btn = $('bk-save'); btn.disabled = true;
    try {
      const d = await api('PUT', '/api/books/' + id, {title: S.title, subject: S.subject, grade: S.grade, units, class_ids: [...S.classIds]});
      B = d; S = fromServer(d, {title: d.title, subject: d.subject, grade: d.grade, classIds: new Set(d.classes.filter(c => c.linked).map(c => c.id))});
      dirty = false; drawAll();
      $('bk-saved').textContent = 'تم اعتماد الكتاب ✓';
      const first = [...S.classIds][0]; $('bk-plan').href = '/plan' + (first ? '?class=' + first : ''); $('bk-plan').hidden = false;
    } catch (x) { say('bk-save-err', x.message); }
    finally { btn.disabled = false; }
  });
  $('bk-paste-go').addEventListener('click', async () => {
    say('bk-paste-err', '');
    if (S.units.some(u => u.lessons.length) && !confirm('سيحل هذا الفهرس محل وحدات الكتاب ودروسه الحالية. متابعة؟')) return;
    try {
      const d = await api('POST', '/api/books/' + id + '/outline', {text: $('bk-paste-text').value});
      const keep = {title: S.title, subject: S.subject, grade: S.grade, classIds: S.classIds};
      B = d; S = fromServer(d, keep); drawAll(); touch(); $('bk-paste').open = false;
    } catch (x) { say('bk-paste-err', x.message); }
  });
  $('bk-reread').addEventListener('click', async () => {
    say('bk-error', '');
    if (S.units.some(u => u.lessons.length) && !confirm('سيُستبدل ما في الشاشة بما تقرؤه الصفحة من ملف الكتاب هذه المرة. متابعة؟')) return;
    try { await api('POST', '/api/books/' + id + '/reread'); dirty = false; load(); } catch (x) { say('bk-error', x.message); }
  });
  $('bk-del').addEventListener('click', async () => {
    if (!confirm('حذف هذا الكتاب وخطط الفصول المبنية عليه؟ الدروس التفاعلية التي أنشأتِها منه تبقى.')) return;
    try { await api('DELETE', '/api/books/' + id); dirty = false; location.href = '/curriculum'; } catch (e) { alert(e.message); }
  });
  load();
})();
