"""The teacher's weekly timetable out of a file she already has: an Excel sheet or Word table of days and periods, a CSV, a PDF or a picture of the printed table.

Timetables are drawn two ways, days down the side and periods across the top or the other way round, and a cell says «الأول أ رياضيات», «1/3 علوم», «الصف الثاني
(ب) - الفقه» or nothing. The reader finds the days and the periods wherever they are written, takes the class and the subject out of every cell, and matches them
with the classes and the subjects the teacher already has; what it cannot match is offered as new, never dropped. The result is a PROPOSAL: she sees the grid,
changes any cell and confirms (schedule.py).
"""
import re

from .bookread import SUBJECTS, ck, digits
from .roster import key

DAYS = {"الاحد": 0, "احد": 0, "الاثنين": 1, "الاتنين": 1, "اثنين": 1, "الثلاثاء": 2, "ثلاثاء": 2, "الثلاثا": 2, "الاربعاء": 3, "اربعاء": 3, "الاربعا": 3,
        "الخميس": 4, "خميس": 4, "الجمعه": 5, "جمعه": 5, "السبت": 6, "سبت": 6,
        "sunday": 0, "sun": 0, "monday": 1, "mon": 1, "tuesday": 2, "tue": 2, "wednesday": 3, "wed": 3, "thursday": 4, "thu": 4, "friday": 5, "fri": 5, "saturday": 6, "sat": 6}
DAY_NAMES = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"]
_ORD = {"اول": 1, "اولي": 1, "ثاني": 2, "ثانيه": 2, "ثالث": 3, "ثالثه": 3, "رابع": 4, "رابعه": 4, "خامس": 5, "خامسه": 5, "سادس": 6, "سادسه": 6, "سابع": 7, "سابعه": 7,
        "ثامن": 8, "ثامنه": 8, "تاسع": 9, "تاسعه": 9, "عاشر": 10, "عاشره": 10, "حادي": 11, "حاديه": 11}
_FREE_WORDS = frozenset(ck(w) for w in ["فراغ", "فارغ", "انتظار", "استراحة", "فسحة", "صلاة", "طابور", "لا يوجد", "إشراف", "اشراف"])
_STOP_CLASS = frozenset(key(w) for w in "الصف صف فصل الفصل شعبه الشعبه شعبة متوسط المتوسط ثانوي الثانوي ابتدائي الابتدائي المرحله مرحله".split())
_TIME = re.compile(r"(\d{1,2})\s*[:.]\s*(\d{2})\s*(?:-|–|—|الي|الى|to)\s*(\d{1,2})\s*[:.]\s*(\d{2})")
MAX_PERIODS = 12


def day_of(cell) -> int | None:
    k = ck(re.sub(r"^\s*يوم\s+", "", str(cell or "")))
    words = k.split()
    if not words:
        return None
    if k in DAYS:
        return DAYS[k]
    if words[0] in DAYS and len(words) <= 4 and all(w.isdigit() for w in words[1:]):          # «الأحد 8/11»
        return DAYS[words[0]]
    return None


def period_of(cell) -> int | None:
    """The period number a header cell stands for: «الأولى», «الحصة 3», «3», «الثانية عشرة», «السابعة 11:00-11:45»."""
    k = ck(_TIME.sub(" ", digits(str(cell or ""))))
    k = re.sub(r"(?:^|\s)(?:ال)?(?:حصه|فتره|دوره)(?=\s|$)", " ", k).strip()
    words = k.split()
    for i, tok in enumerate(words):
        base = tok[2:] if tok.startswith("ال") and tok[2:] in _ORD else tok
        if base in _ORD:
            if i + 1 < len(words) and words[i + 1] in ("عشر", "عشره"):
                return 11 if base.startswith("حادي") else (10 + _ORD[base] if _ORD[base] <= 2 else None)
            return _ORD[base] if _ORD[base] <= 10 else None
        if tok.isdigit() and 1 <= int(tok) <= MAX_PERIODS:
            return int(tok)
    return None


def time_of(cell):
    m = _TIME.search(digits(str(cell or "")))
    if not m:
        return None
    a, b, c, d = (int(x) for x in m.groups())
    if a > 23 or c > 23 or b > 59 or d > 59:
        return None
    return f"{a:02d}:{b:02d}", f"{c:02d}:{d:02d}"


def is_free(cell) -> bool:
    """A cell that holds no lesson: empty, a dash, «فراغ», «انتظار»..."""
    k = ck(cell)
    return not k or k in _FREE_WORDS


# ---------------------------------------------------------------- the class and the subject written in a cell
def class_sig(text):
    """(grade number, section) of a class name or of what a cell says about it: «الصف الأول أ» -> (1, 'ا'), «1/3» -> (1, '3'), «أول متوسط ب» -> (1, 'ب'). (0, '') when there is none."""
    k = ck(text)
    words = [w for w in k.split() if w not in _STOP_CLASS]
    grade, rest = 0, []
    for w in words:
        base = w[2:] if w.startswith("ال") and w[2:] in _ORD else w
        if not grade and base in _ORD:
            grade = _ORD[base]
        elif not grade and w.isdigit() and 1 <= int(w) <= 12 and len(words) >= 2:
            grade = int(w)
        else:
            rest.append(w)
    section = ""
    for w in rest:
        if len(w) == 1 or w.isdigit():
            section = w
            break
    return grade, section


ALIASES = {"انجليزي": "اللغة الإنجليزية", "انجليزيه": "اللغة الإنجليزية", "عربي": "اللغة العربية", "قران": "القرآن الكريم", "قرآن": "القرآن الكريم", "اجتماعيات": "الدراسات الاجتماعية",
           "اجتماعي": "الدراسات الاجتماعية", "حاسب": "الحاسب وتقنية المعلومات", "حاسوب": "الحاسب وتقنية المعلومات", "رقميه": "المهارات الرقمية", "فنيه": "التربية الفنية",
           "بدنيه": "التربية البدنية", "اسلاميه": "الدراسات الإسلامية", "تفكير": "التفكير الناقد", "حياتيه": "المهارات الحياتية والأسرية", "اسريه": "التربية الأسرية"}


def _na(word: str) -> str:
    """A word without its «ال» (so «الرياضيات» and «رياضيات» are one word)."""
    return word[2:] if word.startswith("ال") and len(word) > 4 else word


def split_cell(raw: str, subjects=()):
    """(class text, subject text) of a cell. The subject is the longest known subject name written in it (the teacher's own subjects first, then the usual ones and the
    short names teachers write); what is left of the cell is the class, with its own separators kept («1/3», «الثاني (ب)»)."""
    text = re.sub(r"\s+", " ", digits(str(raw or ""))).strip()
    toks = [(m.start(), m.end(), _na(ck(m.group(0)))) for m in re.finditer(r"[^\s/()\-–—،|]+", text)]
    options = [(name, name) for name in set(list(subjects) + list(SUBJECTS))] + [(alias, full) for alias, full in ALIASES.items()]
    for written, name in sorted(options, key=lambda o: (-len(ck(o[0]).split()), -len(ck(o[0])))):
        words = [_na(w) for w in ck(written).split()]
        n = len(words)
        if not n or (n == 1 and len(words[0]) < 3):
            continue
        for i in range(len(toks) - n + 1):
            if [t[2] for t in toks[i:i + n]] == words:
                rest = text[:toks[i][0]] + " " + text[toks[i + n - 1][1]:]
                rest = re.sub(r"\(\s*\)", " ", rest)
                rest = re.sub(r"\s+", " ", rest).strip(" -–—/،|")
                return re.sub(r"^\((.*)\)$", r"\1", rest).strip(), name
    return text, ""


# ---------------------------------------------------------------- finding the days and the periods
def _grid(rows):
    """The cells of one sheet as {(row, col): text} and its size."""
    cells = {}
    width = 0
    for r, row in enumerate(rows):
        for c, v in enumerate(row):
            if str(v or "").strip():
                cells[(r, c)] = str(v).strip()
                width = max(width, c + 1)
    return cells, len(rows), width


def _layout(cells, height, width):
    """("across", header row, {col: day}) when the days are the columns, ("down", day column, {row: day}) when the days are the rows, else None."""
    best = None
    for r in range(height):
        hit = {c: day_of(cells[(r, c)]) for c in range(width) if (r, c) in cells and day_of(cells[(r, c)]) is not None}
        if len(hit) >= 3 and (best is None or len(hit) > best[0]):
            best = (len(hit), "across", r, hit)
    for c in range(width):
        hit = {r: day_of(cells[(r, c)]) for r in range(height) if (r, c) in cells and day_of(cells[(r, c)]) is not None}
        if len(hit) >= 3 and (best is None or len(hit) > best[0]):
            best = (len(hit), "down", c, hit)
    return best[1:] if best else None


_LIST_ROLES = {"day": {"اليوم", "اليوم الدراسي", "يوم", "day"}, "period": {"الحصه", "رقم الحصه", "الحصه رقم", "حصه", "رقم الحصص", "period", "lesson"},
               "class": {"الفصل", "الصف", "فصل", "صف", "الشعبه", "الفصل الدراسي", "class"}, "subject": {"الماده", "ماده", "الماده الدراسيه", "subject"}}


def _list_layout(cells, height, width):
    """(header row, {role: column}) for a timetable written as a LIST: one row for every period, with a column for the day, the period, the class and the subject."""
    for r in range(min(height, 6)):
        cols = {}
        for c in range(width):
            k = ck((cells.get((r, c)) or ""))
            for role, names in _LIST_ROLES.items():
                if k in names and role not in cols:
                    cols[role] = c
        if "day" in cols and "period" in cols and ("class" in cols or "subject" in cols):
            return r, cols
    return None


def _parse_list(cells, height, lay):
    head, cols = lay
    out, seen = [], 0
    for r in range(head + 1, height):
        day, period = day_of(cells.get((r, cols["day"]), "")), period_of(cells.get((r, cols["period"]), ""))
        cls = re.sub(r"\s+", " ", digits(cells.get((r, cols["class"]), "") if "class" in cols else "")).strip()
        sub = re.sub(r"\s+", " ", cells.get((r, cols["subject"]), "") if "subject" in cols else "").strip()
        if day is None or not period or is_free(cls or sub) or not (cls or sub):
            continue
        out.append({"day": day, "period": period, "class": cls, "subject": sub, "raw": (cls + " " + sub).strip()})
        seen = max(seen, period)
    return out, seen


def parse_sheet(rows, subjects=()):
    """The cells of a timetable in one sheet: {"cells": [{day, period, class, subject, raw}], "times": {period: (start, end)}, "periods": int} or None."""
    cells, height, width = _grid(rows)
    listed = _list_layout(cells, height, width)
    if listed:
        out, seen = _parse_list(cells, height, listed)
        if not out:
            return None
        return {"cells": [x for x in out if 1 <= x["period"] <= MAX_PERIODS], "times": {}, "periods": min(MAX_PERIODS, seen)}
    lay = _layout(cells, height, width)
    if not lay:
        return None
    mode, line, days = lay
    out, times, seen = [], {}, 0
    if mode == "across":
        day_cols = set(days)
        seq = 0
        for r in range(line + 1, height):
            labels = [cells[(r, c)] for c in range(width) if c not in day_cols and (r, c) in cells]
            period = next((p for p in (period_of(x) for x in labels) if p), None)
            if period is None:
                period = seq + 1 if any((r, c) in cells for c in day_cols) else None
            if period is None:
                continue
            seq = period
            t = next((x for x in (time_of(x) for x in labels) if x), None)
            if t:
                times[period] = t
            for c, d in days.items():
                raw = cells.get((r, c), "")
                if raw and not is_free(raw):
                    cls, sub = split_cell(raw, subjects)
                    out.append({"day": d, "period": period, "class": cls, "subject": sub, "raw": raw})
            seen = max(seen, period)
    else:
        day_rows = set(days)
        header = None
        for r in range(0, height):
            if r in day_rows:
                break
            hit = {c: period_of(cells[(r, c)]) for c in range(width) if c != line and (r, c) in cells and period_of(cells[(r, c)])}
            if len(hit) >= 2:
                header = hit
        for r, d in days.items():
            if header is None:
                cols = [c for c in range(width) if c != line]
                mapping = {c: i + 1 for i, c in enumerate(sorted(cols))}
            else:
                mapping = header
            for c, period in mapping.items():
                raw = cells.get((r, c), "")
                if raw and not is_free(raw):
                    cls, sub = split_cell(raw, subjects)
                    out.append({"day": d, "period": period, "class": cls, "subject": sub, "raw": raw})
                seen = max(seen, period)
        if header:
            for r in range(0, min(day_rows)):
                for c, period in header.items():
                    t = time_of(cells.get((r, c), ""))
                    if t:
                        times[period] = t
    if not out:
        return None
    return {"cells": [x for x in out if 1 <= x["period"] <= MAX_PERIODS], "times": times, "periods": min(MAX_PERIODS, max(seen, max(x["period"] for x in out)))}


def parse_lines(lines, subjects=()):
    """A timetable given as plain lines (a PDF or a picture): every line that starts with a day lists that day's periods in order, the cells apart by two spaces, a tab,
    a bar or a comma. The periods' own numbers are not read from the text, so the result is as sure as the order of the cells."""
    rows = []
    for line in lines:
        line = str(line).strip()
        if not line:
            continue
        parts = [p.strip() for p in re.split(r"\t|\s{2,}|\||،|;", line) if p.strip()]
        if len(parts) == 1:
            m = re.match(r"^(\S+)\s+(.+)$", line)
            if m and day_of(m.group(1)) is not None:
                parts = [m.group(1), m.group(2)]
        rows.append(parts)
    return parse_sheet(rows, subjects)


def parse(sheets, subjects=()):
    """The best timetable among the sheets of a file (the one with the most cells), or None."""
    best = None
    for sh in sheets:
        res = parse_sheet(sh["rows"], subjects)
        if not res and all(len(r) <= 1 for r in sh["rows"]):
            res = parse_lines([r[0] if r else "" for r in sh["rows"]], subjects)
        if res and (best is None or len(res["cells"]) > len(best["cells"])):
            best = res
    return best


# ---------------------------------------------------------------- matching the cells with what the teacher already has
def match_class(text, classes):
    """The id of her class that this text names, or None. classes: [(id, name)]. A class matches by the same name once spelled alike, else by the same grade and
    section («أول/أ» is «الصف الأول أ»), else by containing the other's name; a text that fits two classes (a grade without its section) matches none."""
    if not text:
        return None
    k = ck(text)
    for cid, name in classes:
        if ck(name) == k:
            return cid
    g, s = class_sig(text)
    if g and s:
        hits = [cid for cid, name in classes if class_sig(name) == (g, s)]
        if len(hits) == 1:
            return hits[0]
    hits = []
    for cid, name in classes:
        kn = ck(name)
        if kn and len(k) >= 3 and (k in kn or kn in k):
            hits.append(cid)
    return hits[0] if len(hits) == 1 else None


def match_subject(text, subjects):
    """The id of her subject with this name, or None. subjects: [(id, name)]."""
    k = ck(text)
    if not k:
        return None
    for sid, name in subjects:
        if ck(name) == k:
            return sid
    for sid, name in subjects:
        kn = ck(name)
        if kn and (kn in k or k in kn):
            return sid
    return None


def resolve(parsed, classes, subjects):
    """The parsed timetable with every cell matched: class_id / subject_id when she already has it (else None, and the text stays as the name to create)."""
    cl = list(classes)
    sb = list(subjects)
    for c in parsed["cells"]:
        c["class_id"] = match_class(c["class"], cl)
        c["subject_id"] = match_subject(c["subject"], sb)
    return parsed
