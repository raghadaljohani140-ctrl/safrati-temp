"""Reads a timetable that is only a picture (the ministry's aSc page: days down the right-hand side, periods across the top, a subject and a class in each box).
The ruled lines are found first, then every box is read on its own, which works where reading the whole page does not. Nothing is saved: the result goes to the same preview screen as any timetable file."""
import re

DAYS = ("الاحد", "الاثنين", "الثلاثاء", "الاربعاء", "الخميس", "الجمعة", "السبت")
_NORM = str.maketrans({"أ": "ا", "إ": "ا", "آ": "ا", "ى": "ي", "ة": "ه", "ئ": "ي", "ؤ": "و"})
_DAY_KEYS = {"احد": 0, "الاحد": 0, "اثنين": 1, "الاثنين": 1, "اثنين": 1, "ثلاثاء": 2, "الثلاثاء": 2, "اربعاء": 3, "الاربعاء": 3, "خميس": 4, "الخميس": 4, "جمعه": 5, "الجمعه": 5, "سبت": 6, "السبت": 6}
MAX_CELLS = 120


def _lines(flags, min_gap: int):
    """The centres of runs of True, runs closer than min_gap merged."""
    out, start = [], None
    for i, f in enumerate(list(flags) + [False]):
        if f and start is None:
            start = i
        elif not f and start is not None:
            c = (start + i - 1) // 2
            if out and c - out[-1] < min_gap:
                pass
            else:
                out.append(c)
            start = None
    return out


def grid_lines(img):
    """(horizontal line ys, vertical line xs) of the table's ruling, or ([], [])."""
    from PIL import Image
    g = img.convert("L").point(lambda v: 255 if v < 190 else 0)
    w, h = g.size
    rows = [v > 0.6 * 255 for v in g.resize((1, h), Image.BOX).tobytes()]
    cols = [v > 0.5 * 255 for v in g.resize((w, 1), Image.BOX).tobytes()]
    ys = _lines(rows, max(4, h // 60))
    xs = _lines(cols, max(4, w // 60))
    return ys, xs


def _ink(cell):
    """The cell as black text on white: coloured corner flags (the aSc marks) and the grid are not text."""
    from PIL import ImageChops
    r, g, b = cell.convert("RGB").split()
    spread = ImageChops.subtract(ImageChops.lighter(ImageChops.lighter(r, g), b), ImageChops.darker(ImageChops.darker(r, g), b))
    dark = cell.convert("L").point(lambda v: 255 if v < 130 else 0)
    plain = spread.point(lambda v: 255 if v < 60 else 0)
    return ImageChops.invert(ImageChops.darker(dark, plain))          # black where there is dark, uncoloured ink


def _ocr(img, psm: int, langs: str, scale: int = 3) -> str:
    import pytesseract
    from PIL import Image
    big = img.resize((img.width * scale, img.height * scale), Image.LANCZOS)
    return pytesseract.image_to_string(big, lang=langs, config=f"--psm {psm}").strip()


def _lang() -> str:
    import pytesseract
    return "ara" if "ara" in pytesseract.get_languages() else ""       # Arabic only: with English added the small Arabic words come out as Latin letters


def _norm(t: str) -> str:
    t = re.sub(r"[ً-ٰٟـ‎‏]", "", t).translate(_NORM)
    return re.sub(r"[^ء-ي ]", "", t).strip()


def _day_of(text: str):
    for w in _norm(text).split():
        if w in _DAY_KEYS:
            return _DAY_KEYS[w]
    return None


_GRADES = {"اولي": "اولى", "اول": "اول", "ثاني": "ثانية", "ثانيه": "ثانية", "ثالث": "ثالث", "ثالثه": "ثالثة", "رابع": "رابع", "خامس": "خامس", "سادس": "سادس", "عام": "عام", "ثانوي": "ثانوي"}
_SECTION = {"T": "3", "t": "3", "٣": "3", "3": "3", "٢": "2", "2": "2", "٤": "4", "4": "4", "٥": "5", "5": "5"}


def _vocab(extra=()):
    from . import timetable
    names = list(dict.fromkeys(list(extra) + list(timetable.SUBJECTS) + list(timetable.ALIASES.values())))
    return [(_norm(n), n) for n in names if _norm(n)]


def _best_subject(text: str, vocab, mine=(), floor: float = 0.62):
    import difflib
    k = _norm(text)
    if len(k) < 4:
        return ""
    best, score = "", 0.0
    for nk, name in vocab:
        r = difflib.SequenceMatcher(None, k, nk).ratio()
        if r > score:
            best, score = name, r
    if score >= floor:
        return best
    own, score = "", 0.0
    for name in mine:                                       # her own few subjects: a rougher reading is enough
        r = difflib.SequenceMatcher(None, k, _norm(name)).ratio()
        if r > score:
            own, score = name, r
    return own if score >= 0.42 else ""


_GRADE_WORDS = ("اولى", "ثانية", "ثالث", "رابع", "خامس", "سادس")


def _grade_of(line: str) -> str:
    """«ثالث عام» / «اولى» from a badly read class line: «يالك عام» is «ثالث عام»."""
    import difflib
    words = _norm(line).split()
    out = []
    for w in words:
        if w in _GRADES:
            out.append(_GRADES[w])
            continue
        if len(w) >= 3:
            r, g = max((difflib.SequenceMatcher(None, w, x).ratio(), x) for x in _GRADE_WORDS)
            if r >= 0.5:
                out.append(g)
    if "عام" in words:                                      # «عام» is the third year of the secondary school
        out = ["ثالث", "عام"]
    seen = []
    for w in out:
        if w not in seen:
            seen.append(w)
    return " ".join(seen[:2])


def _section_of(line: str) -> str:
    for ch in reversed(line):
        if ch in _SECTION:
            return _SECTION[ch]
    return ""


def clean_lines(lines, vocab, mine=()) -> str:
    """The lines of one box (top to bottom) as «subject class»: the last line is the class, the lines above it are the subject."""
    lines = [ln for ln in lines if ln.strip()]
    if not lines:
        return ""
    klass = ""
    if lines:
        grade = _grade_of(lines[-1])
        if grade:
            sect = _section_of(lines[-1])
            klass = (grade + (" " + sect if sect else "")).strip()
            lines = lines[:-1]
    subject = _best_subject(" ".join(lines), vocab, mine) if lines else ""
    return " ".join(x for x in (subject, klass) if x)


def _cell_lines(cell, langs: str):
    """The text lines of one box, each read on its own."""
    from PIL import Image, ImageFilter
    h = cell.height
    rows = [v < 255 for v in cell.point(lambda v: 255 if v >= 128 else 0).resize((1, h), Image.BOX).tobytes()]
    runs, st = [], None
    for i, f in enumerate(list(rows) + [False]):
        if f and st is None:
            st = i
        elif not f and st is not None:
            runs.append([st, i])
            st = None
    merged = []
    for r in runs:
        if merged and r[0] - merged[-1][1] < 3:
            merged[-1][1] = r[1]
        else:
            merged.append(r)
    out = []
    for a, b in merged:
        if b - a < 5:
            continue
        line = cell.crop((0, max(0, a - 3), cell.width, min(cell.height, b + 3)))
        import pytesseract
        text = ""
        for scale, blur, psm in ((5, 1, 7), (3, 0, 7), (4, 0, 6), (2, 0, 7)):
            big = line.resize((line.width * scale, line.height * scale), Image.LANCZOS)
            if blur:
                big = big.filter(ImageFilter.GaussianBlur(blur))
            text = pytesseract.image_to_string(big, lang=langs, config=f"--psm {psm}").strip()
            if len(re.findall(r"[\u0621-\u064a]", text)) >= 2:
                break
        out.append(text)
    return out


def _box_text(cell, langs, vocab, mine):
    if not cell:
        return ""
    return clean_lines(_cell_lines(cell, langs), vocab, mine) or "؟"


def read_grid(img, subjects=()):
    """A sheet {"rows": [...]} like a spreadsheet one: a header row of period numbers and a row per day («الأحد», cell, cell…), or None when the picture is not such a table."""
    langs = _lang()
    if not langs:
        return None
    ys, xs = grid_lines(img)
    if len(ys) < 4 or len(xs) < 4 or (len(ys) - 1) * (len(xs) - 1) > MAX_CELLS:
        return None
    img = img.convert("RGB")
    ncols = len(xs) - 1
    table, days_found = [], 0
    for r in range(len(ys) - 1):
        row = []
        for c in range(ncols):
            box = (xs[c] + 4, ys[r] + 4, xs[c + 1] - 3, ys[r + 1] - 3)
            if box[2] - box[0] < 8 or box[3] - box[1] < 8:
                row.append("")
                continue
            cell = _ink(img.crop(box))
            from PIL import ImageStat
            if 1 - ImageStat.Stat(cell.point(lambda v: 255 if v >= 128 else 0)).mean[0] / 255 < 0.004:
                row.append("")
                continue
            row.append(cell)
        table.append(row)
    # the page is right to left: the day names sit in the right-hand column and period 1 is the first box from the right
    def name(c):
        return _day_of(" ".join(_cell_lines(c, langs))) if c != "" else None
    body_rows = table[1:]                                    # the first row holds the period numbers
    if not 2 <= len(body_rows) <= 7:
        return None
    right = [name(row[-1]) for row in body_rows]
    left = [name(row[0]) for row in body_rows]
    rtl = sum(d is not None for d in right) >= sum(d is not None for d in left)
    named = right if rtl else left
    if sum(d is not None for d in named) >= 3:
        days = named
    else:                                                    # the big day names are often read badly: the rows are then the days in order
        days = list(range(len(body_rows)))
    vocab = _vocab(subjects)
    rows = [["اليوم"] + [f"الحصة {p}" for p in range(1, ncols)]]
    for d, row in zip(days, body_rows):
        if d is None:
            continue
        cells = list(reversed(row[:-1])) if rtl else row[1:]  # period 1, 2, 3…
        rows.append([DAYS[d]] + [_box_text(c, langs, vocab, subjects) for c in cells])
    return {"name": "", "rows": rows} if len(rows) > 2 else None
