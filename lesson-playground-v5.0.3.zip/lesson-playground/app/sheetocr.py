"""Reads the ministry's student register (كشف متابعة الطالبات اليومي) when it is a scanned page: the names sit in the right-hand column, one name inside each rounded box.
Reading the whole page at once fails (the checkbox grid drowns the text), so the names column is cut into its boxes and every box is read on its own.
Nothing here saves anything: the lines go to the same preview screen as any other list."""
import io
import re

MAX_ROWS = 80


def _tess(img, psm: int, lang: str) -> str:
    import pytesseract
    return pytesseract.image_to_string(img, lang=lang, config=f"--psm {psm}").strip()


def _langs() -> str:
    import pytesseract
    have = pytesseract.get_languages()
    return "+".join(x for x in ("ara", "eng") if x in have) if "ara" in have else ""


def _runs(flags, min_len: int):
    out, start = [], None
    for i, f in enumerate(list(flags) + [False]):
        if f and start is None:
            start = i
        elif not f and start is not None:
            if i - start >= min_len:
                out.append((start, i))
            start = None
    return out


def _clean(text: str) -> str:
    text = re.sub(r"[\u200e\u200f\u202a-\u202e]", "", text)
    words = []
    for w in text.split():
        w = re.sub(r"[\d\u0660-\u0669.|:\-_\u2018\u2019'\"()\[\]]", "", w)
        if len(re.findall(r"[\u0621-\u064a]", w)) >= 2 and not re.search(r"[A-Za-z]", w):
            words.append(w)
    return " ".join(words)


def _read_box(cell, langs: str) -> str:
    """One name: tries a few sizes and line modes and keeps the first reading with real letters in it."""
    from PIL import Image, ImageOps
    best = ""
    for scale, psm in ((2, 7), (3, 7), (2, 13), (3, 6)):
        big = cell.resize((cell.width * scale, cell.height * scale), Image.LANCZOS)
        for im in (big, ImageOps.autocontrast(big, cutoff=2)):
            text = _clean(_tess(im, psm, langs))
            if len(re.findall(r"[\u0621-\u064a]", text)) >= 5:
                return text
            if len(text) > len(best):
                best = text
    return best if len(re.findall(r"[\u0621-\u064a]", best)) >= 3 else ""


def _header_lines(text: str):
    """Only the class and the subject from the page's heading (the rest of it is the ministry's title and logo, read as noise)."""
    flat = re.sub(r"[\u200e\u200f\u202a-\u202e|]", " ", text).replace("\n", " ")
    out = []
    m = re.search(r"المادة\s*[:：]\s*(.+?)(?=\s+(?:العام|الفصل|الصف)\b|$)", flat)
    if m:
        sub = " ".join(w for w in m.group(1).split() if re.search(r"[\u0621-\u064a]", w))
        if sub:
            out.append(f"المادة : {sub}")
    m = re.search(r"الصف\s*[:：]\s*(.+?)(?=\s+(?:الفصل|المادة|العام)\b|$)", flat)
    if m:
        cls = re.sub(r"[^\w\u0621-\u064a/ ]", " ", m.group(1)).strip()
        if cls:
            out.append(f"الصف : {cls}")
    return out


def looks_like_register(img) -> bool:
    """A page that is mostly a grid of small boxes (the register) rather than a photo of text: many short rounded boxes down the right-hand column."""
    try:
        return len(_boxes(img)) >= 5
    except Exception:
        return False


def _boxes(img):
    """The vertical spans (top, bottom) of the boxes in the right-hand column and the column's x range."""
    g = img.convert("L")
    w, h = g.size
    x0, x1 = int(w * 0.715), int(w * 0.99)
    band = g.crop((x0, 0, x1, h)).point(lambda v: 1 if v < 140 else 0).tobytes()
    bw = x1 - x0
    longest = [0] * h
    for y in range(h):                          # the top and bottom edge of a box is one long unbroken dark line (text is broken into letters)
        row = band[y * bw:(y + 1) * bw]
        if 1 in row:
            longest[y] = max(map(len, row.split(b"\x00")))
    border = [v > 0.5 * bw for v in longest]
    lines = [(a + b) // 2 for a, b in _runs(border, 1)]
    # merge edges that belong to the same line (thick scans)
    merged = []
    for y in lines:
        if merged and y - merged[-1] < h * 0.006:
            continue
        merged.append(y)
    gaps = sorted(b - a for a, b in zip(merged, merged[1:]) if h * 0.012 < b - a < h * 0.05)
    if len(gaps) < 5:
        return [], (x0, x1)
    pitch = gaps[len(gaps) // 2]
    edges = []
    for e in merged:
        if edges and e - edges[-1] < pitch * 0.75:
            continue                                      # a stray line inside a box (a long name touching the edge)
        while edges and e - edges[-1] > pitch * 1.6:      # an edge the scan lost: put it back
            edges.append(edges[-1] + pitch)
        edges.append(e)
    boxes = []
    for a, b in zip(edges, edges[1:]):
        if b - a <= pitch * 1.25:        # the title and the column heading are taller or higher than a name box
            boxes.append((int(a), int(b)))
    boxes = boxes[:MAX_ROWS]
    return boxes, (x0, x1)


def register_lines(img) -> str:
    """The text of the register as lines: the header lines and then '1. name' for every filled box. '' when the page is not such a register."""
    from PIL import Image, ImageStat
    langs = _langs()
    if not langs:
        return ""
    found = _boxes(img)
    boxes, (x0, x1) = found if isinstance(found, tuple) else (found, (0, 0))
    if len(boxes) < 5:
        return ""
    g = img.convert("L")
    w, h = g.size
    out = []
    head = g.crop((0, 0, w, int(h * 0.12)))
    head_text = _tess(head, 6, langs)
    out.extend(_header_lines(head_text))
    n = 0
    for a, b in boxes[:MAX_ROWS]:
        pad = max(4, int((b - a) * 0.12))
        cell = g.crop((x0 + int((x1 - x0) * 0.04), a + pad, x1 - int((x1 - x0) * 0.04), b - pad))
        if 1 - ImageStat.Stat(cell.point(lambda v: 255 if v >= 140 else 0)).mean[0] / 255 < 0.012:          # an empty box
            continue
        text = _read_box(cell, langs)
        if not text:
            continue
        n += 1
        out.append(f"{n}. {text}")
    return "\n".join(out)
