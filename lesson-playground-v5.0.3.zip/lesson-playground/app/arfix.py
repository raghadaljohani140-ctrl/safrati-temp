"""Repairs the text of ministry PDFs whose font maps its glyphs wrongly: a replacement mark (U+FFFD) in front of a letter, an alef written twice («الإأول» for «الأول»),
shadow text where every letter is doubled. The right letter is chosen from the words the same book spells cleanly elsewhere."""
import itertools
import re
from collections import Counter

F = "�"
_MARKS = re.compile("[ً-ْٰـ]")
_TRIM = "‎‏.:،؛؟?()[]«»\"'-–—•*"
_SWAPS = (("ص", "س"), ("ض", "س"), ("ص", "ض"), ("ض", "ص"), ("ش", "س"))
MIN_SHARE = 0.002           # the share of marks among the Arabic letters that says the font is broken


def broken(lines) -> bool:
    arabic = sum(1 for ln in lines for ch in ln if "ء" <= ch <= "ي")
    marks = sum(ln.count(F) for ln in lines)
    return bool(arabic) and marks / arabic >= MIN_SHARE


def _unshadow(word: str) -> str:
    """«��سسووررةة» -> «�سورة»: every letter (or two-letter join) written twice."""
    if len(word) < 6:
        return word
    out, i = [], 0
    while i < len(word):
        if i + 1 < len(word) and word[i] == word[i + 1]:
            out.append(word[i])
            i += 2
        elif i + 3 < len(word) and word[i:i + 2] == word[i + 2:i + 4]:
            out.append(word[i:i + 2])
            i += 4
        else:
            return word
    return "".join(out)


def _alefs(word: str) -> str:
    word = re.sub("ل[أإ]آ", "لآ", word)
    word = re.sub("ل[آأإ]([أإ])", "ل\\1", word)
    word = word.replace("وؤ", "ؤ")
    word = re.sub("ا(?=[أإآ])", "", word)           # «اأ» «اإ» «اآ»
    word = re.sub("(?<=ل)إ(?=[أإآ])", "", word)      # «الإأول»
    word = re.sub("(?<=ل)([أإ])\\1", "\\1", word)
    word = re.sub("إأ", "أ", word)
    word = re.sub("إإ", "إ", word)
    word = re.sub("(?<!ا)لإ(?=[أ-إ])", "ل", word)
    return word


_SCHOOL = ("الإسراء الأولى الثانية الثالثة الرابعة الخامسة السادسة السابعة الثامنة التاسعة العاشرة الحادية الثانية عشر الحادي السادس السادسة السابع السابعة الثامن التاسع العاشر الخامس الرابع الثالث الثاني الأول نشأته نشاط أنشطة ضوابط ضوابطه الضوابط اضبط الصف الصفحة تفسير التفسير يتضمن "
           "مصطلحات الدرس الوحدة الفصل المقرر سورة السورة الآية الآيات استراتيجية استراتيجيات إستراتيجية إستراتيجيات أهداف تقويم الطالب الطالبة الطلاب المعلم المعلمة الأهداف مشروع "
           "المشروع نواتج التعلم الإسراء الأسئلة السؤال اشرح استنبط استخلص ناقش لخص أستنبط أستخلص أستثمر أستدعي أستهل أناقش ألخص أرسم ارسم ضع صنف").split()


def _seen(word: str, vocab) -> int:
    k = _key(word)
    return max(vocab.get(k, 0), vocab.get(k[1:], 0) if len(k) > 4 and k[0] in "وبلكف" else 0)


def _key(word: str) -> str:
    return _MARKS.sub("", word).strip(_TRIM)


_TEETH = "سصضش"


def _cands(word: str):
    """The readings of a word with marks in it: a mark before one of «س ص ض ش» stands for any of the four, otherwise for nothing or for an alef."""
    options, i = [], 0
    while i < len(word):
        ch = word[i]
        if ch != F:
            options.append([ch])
            i += 1
        elif i + 1 < len(word) and word[i + 1] in _TEETH:
            options.append(list(_TEETH))
            i += 2
        else:
            options.append(["", "ا"])
            i += 1
    if len([o for o in options if len(o) > 1]) > 4:
        return []
    return ["".join(c) for c in itertools.product(*options)]


def _model(vocab):
    """Letter trigrams of the words the book spells cleanly: how likely a spelling is."""
    tri = Counter()
    for w, n in vocab.items():
        t = "^^" + w + "$"
        for i in range(len(t) - 2):
            tri[t[i:i + 3]] += min(n, 5)
    return tri


def _score(word: str, tri) -> float:
    import math
    t = "^^" + word + "$"
    return sum(math.log((tri.get(t[i:i + 3], 0) + 0.1)) for i in range(len(t) - 2)) / max(1, len(word))


def repair(lines):
    """The same lines with the damaged words repaired (a copy)."""
    tokens = [[_alefs(_unshadow(w)) for w in ln.split()] for ln in lines]
    vocab = Counter(_key(w) for row in tokens for w in row if F not in w)
    for w in _SCHOOL:
        vocab[w] += 12
    cache = {}
    tri = _model(vocab)
    out = []
    for ln, row in zip(lines, tokens):
        if F not in ln and all(a == b for a, b in zip(ln.split(), row)):
            out.append(ln)
            continue
        fixed = []
        for w in row:
            if F in w:
                if w not in cache:
                    cands = _cands(w)
                    known = max(((_seen(c, vocab), c) for c in cands), default=(0, ""))
                    if known[0] >= 2:
                        cache[w] = known[1]
                    elif cands:
                        cache[w] = max(cands, key=lambda c: _score(_key(c), tri))
                    else:
                        cache[w] = _fallback(w)
                w = cache[w]
            fixed.append(w)
        out.append(" ".join(fixed))
    return out
