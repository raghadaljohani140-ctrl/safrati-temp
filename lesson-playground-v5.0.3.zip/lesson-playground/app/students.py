"""The teacher's own list of students (names she types herself) and how each one did in the questions she asked them. No student accounts: this is her notebook."""
from flask import Blueprint, abort, current_app, g, jsonify, render_template, request

from . import extract, roster, share, tables, textfmt
from .db import jload, now
from .lessons import mine
from .security import Limiter, login_required

from .timetable import class_sig

bp = Blueprint("students", __name__)
MAX_STUDENTS = 600
MAX_CLASSES = 30
MAX_IMPORT_MB = 10
import_limit = Limiter(30, 3600)
LEVELS = ((85, "ممتاز"), (65, "جيد"), (0, "يحتاج إلى دعم"))


def body() -> dict:
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}


def toint(v) -> int:
    try:
        return int(v)
    except (TypeError, ValueError):
        return 0


def level(pct):
    return None if pct is None else next(name for floor, name in LEVELS if pct >= floor)


def student_row(sid):
    row = current_app.db.execute("SELECT * FROM students WHERE id = ? AND user_id = ?", (sid, g.user["id"])).fetchone()
    if not row:
        abort(404)                      # another teacher's student looks exactly like one that does not exist
    return row


def class_row(cid):
    row = current_app.db.execute("SELECT * FROM classes WHERE id = ? AND user_id = ?", (cid, g.user["id"])).fetchone()
    if not row:
        abort(404)
    return row


def default_class():
    """A teacher who never made a class (an older page, or the first name she types) gets «الفصل الأول»."""
    db = current_app.db
    row = db.execute("SELECT id FROM classes WHERE user_id = ? ORDER BY id LIMIT 1", (g.user["id"],)).fetchone()
    if row:
        return row["id"]
    cur = db.execute("INSERT INTO classes(user_id, name, created_at) VALUES (?,?,?)", (g.user["id"], "الفصل الأول", now()))
    db.commit()
    return cur.lastrowid


def clean_name(value) -> str:
    return " ".join(str(value or "").split())[:60]


def listing(class_id=None):
    sql = """SELECT s.id, s.name, s.class_id, COUNT(r.id) AS answered, COALESCE(SUM(r.correct), 0) AS correct,
                    (SELECT COALESCE(SUM(p.amount), 0) FROM points p WHERE p.student_id = s.id) AS points
             FROM students s LEFT JOIN results r ON r.student_id = s.id WHERE s.user_id = ?"""
    args = [g.user["id"]]
    if class_id:
        sql += " AND s.class_id = ?"
        args.append(class_id)
    out = []
    for r in current_app.db.execute(sql + " GROUP BY s.id ORDER BY s.name", args).fetchall():
        pct = textfmt.percent(r["correct"], r["answered"])
        out.append({"id": r["id"], "name": r["name"], "class_id": r["class_id"], "answered": r["answered"], "correct": r["correct"], "percent": pct, "level": level(pct), "points": r["points"]})
    return out


def classes_list():
    db = current_app.db
    rows = db.execute("""SELECT c.id, c.name, c.whatsapp, COUNT(s.id) AS n FROM classes c LEFT JOIN students s ON s.class_id = c.id
                         WHERE c.user_id = ? GROUP BY c.id ORDER BY c.id""", (g.user["id"],)).fetchall()
    subjects = {}
    for r in db.execute("SELECT cs.class_id, s.id, s.name FROM class_subjects cs JOIN subjects s ON s.id = cs.subject_id WHERE cs.user_id = ? ORDER BY s.name", (g.user["id"],)):
        subjects.setdefault(r["class_id"], []).append({"id": r["id"], "name": r["name"]})
    return [{"id": r["id"], "name": r["name"], "count": r["n"], "whatsapp": r["whatsapp"], "subjects": subjects.get(r["id"], [])} for r in rows]


@bp.get("/students")
@login_required
def page():
    return render_template("students.html")


@bp.get("/api/students")
@login_required
def students():
    return jsonify(students=listing(toint(request.args.get("class_id")) or None), classes=classes_list())


@bp.get("/api/classes")
@login_required
def classes():
    return jsonify(classes=classes_list())


@bp.post("/api/classes")
@login_required
def add_class():
    name = clean_name(body().get("name"))
    if len(name) < 2:
        return jsonify(error="اكتبي اسم الفصل (حرفان على الأقل)"), 400
    if current_app.db.execute("SELECT COUNT(*) FROM classes WHERE user_id = ?", (g.user["id"],)).fetchone()[0] >= MAX_CLASSES:
        return jsonify(error=f"الحد الأقصى {MAX_CLASSES} فصلًا"), 400
    try:
        cur = current_app.db.execute("INSERT INTO classes(user_id, name, created_at) VALUES (?,?,?)", (g.user["id"], name, now()))
        current_app.db.commit()
    except Exception:
        return jsonify(error="يوجد فصل بهذا الاسم"), 409
    return jsonify(id=cur.lastrowid, classes=classes_list()), 201


@bp.patch("/api/classes/<int:cid>")
@login_required
def edit_class(cid):
    """Her class's name and the link of its WhatsApp group (optional: a class without a group simply leaves it empty)."""
    class_row(cid)
    d = body()
    sets, args = [], []
    if "name" in d or "whatsapp" not in d:
        name = clean_name(d.get("name"))
        if len(name) < 2:
            return jsonify(error="اكتبي اسم الفصل"), 400
        sets.append("name = ?")
        args.append(name)
    link = None
    if "whatsapp" in d:
        link = share.clean_group_link(d.get("whatsapp"))
        if link is None:
            return jsonify(error=share.BAD_LINK), 400
        sets.append("whatsapp = ?")
        args.append(link)
    try:
        current_app.db.execute(f"UPDATE classes SET {', '.join(sets)} WHERE id = ?", (*args, cid))
        current_app.db.commit()
    except Exception:
        return jsonify(error="يوجد فصل بهذا الاسم"), 409
    return jsonify(saved=True, whatsapp=link if link is not None else class_row(cid)["whatsapp"])


@bp.delete("/api/classes/<int:cid>")
@login_required
def delete_class(cid):
    class_row(cid)
    current_app.db.execute("DELETE FROM classes WHERE id = ?", (cid,))          # its students and their results go with it
    current_app.db.commit()
    return jsonify(ok=True)


@bp.post("/api/students")
@login_required
def add():
    d = body()
    names = d.get("names") if isinstance(d.get("names"), list) else [d.get("name")]
    db = current_app.db
    cid = class_row(toint(d.get("class_id")))["id"] if d.get("class_id") else default_class()
    have = db.execute("SELECT COUNT(*) FROM students WHERE user_id = ?", (g.user["id"],)).fetchone()[0]
    added = skipped = 0
    for raw in names:
        name = clean_name(raw)
        if len(name) < 2:
            skipped += 1
            continue
        if have + added >= MAX_STUDENTS:
            return jsonify(error=f"الحد الأقصى {MAX_STUDENTS} طالبًا"), 400
        try:
            db.execute("INSERT INTO students(user_id, class_id, name, created_at) VALUES (?,?,?,?)", (g.user["id"], cid, name, now()))
            added += 1
        except Exception:
            skipped += 1                # the same name twice
    db.commit()
    if not added:
        return jsonify(error="اكتبي اسمًا جديدًا (حرفان على الأقل ولا يتكرر)"), 400
    return jsonify(added=added, skipped=skipped, students=listing(), classes=classes_list()), 201


# ---------------------------------------------------------------- a list she already has (Excel, Word, CSV, PDF, a photo)
def _names_in_class(cid):
    return {roster.key(r["name"]) for r in current_app.db.execute("SELECT name FROM students WHERE class_id = ?", (cid,))}


@bp.post("/api/students/import")
@login_required
def import_preview():
    """Reads the file and PROPOSES the classes and names in it. Nothing is saved here: she sees the proposal, fixes it and confirms it (import_confirm).
    The file itself is not kept, and the names never leave the server (the picture reader is the local Tesseract)."""
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify(error="اختاري ملف القائمة أولًا"), 400
    if not import_limit.allow(g.user["id"]):
        return jsonify(error="رفعتِ ملفات كثيرة خلال ساعة، جرّبي بعد قليل"), 429
    data = f.read(MAX_IMPORT_MB * 1024 * 1024 + 1)
    if len(data) > MAX_IMPORT_MB * 1024 * 1024:
        return jsonify(error=f"الملف كبير، الحد الأقصى {MAX_IMPORT_MB} ميجابايت"), 400
    if not data:
        return jsonify(error="الملف فارغ"), 400
    try:
        kind = tables.kind_of(f.filename, data[:16])
        sheets = tables.sheets_from_text(extract.plain(kind, data)) if kind in ("pdf", "image") else tables.read_sheets(kind, data)
    except (tables.TableError, extract.ExtractError) as exc:
        return jsonify(error=str(exc)), 400
    groups = roster.from_sheets(sheets)
    if not groups:
        return jsonify(error="لم نجد أسماء طلاب في هذا الملف. اجعلي الأسماء في عمود واحد أو سطرًا لكل اسم، أو اكتبيها هنا بنفسك"), 400
    classes = classes_list()
    by_key = {roster.key(c["name"]): c for c in classes}
    out = []
    for gr in groups:
        match = by_key.get(roster.key(gr["class"])) if gr["class"] else None
        if gr["class"] and not match:                                  # «اولى /3» is her class «الأول 3»: the same grade and section
            sig = class_sig(gr["class"])
            same = [c for c in classes if sig[0] and class_sig(c["name"]) == sig]
            match = same[0] if len(same) == 1 else None
        have = _names_in_class(match["id"]) if match else set()
        out.append({"label": gr["class"], "names": gr["names"], "class_id": match["id"] if match else None, "already": [n for n in gr["names"] if roster.key(n) in have]})
    return jsonify(kind=kind, groups=out, classes=classes)


@bp.post("/api/students/import/confirm")
@login_required
def import_confirm():
    """Saves what she confirmed: [{class_id | class_name, names}]. A new class is made when only a name is given. All of it or none of it."""
    d = body()
    groups = d.get("groups")
    if not isinstance(groups, list) or not groups or len(groups) > 60:
        return jsonify(error="لا توجد أسماء لحفظها"), 400
    db = current_app.db
    uid = g.user["id"]
    have = db.execute("SELECT COUNT(*) FROM students WHERE user_id = ?", (uid,)).fetchone()[0]
    classes_made = added = skipped = 0
    default_id = default_class() if any(isinstance(x, dict) and not x.get("class_id") and not clean_name(x.get("class_name")) for x in groups) else None          # it commits by itself: before anything else is written
    try:
        for gr in groups:
            if not isinstance(gr, dict) or not isinstance(gr.get("names"), list):
                raise ValueError("بيانات غير صحيحة")
            if gr.get("class_id"):
                cid = class_row(toint(gr["class_id"]))["id"]
            else:
                name = clean_name(gr.get("class_name"))
                if not name:
                    cid = default_id
                else:
                    row = db.execute("SELECT id FROM classes WHERE user_id = ? AND name = ?", (uid, name)).fetchone()
                    if row:
                        cid = row["id"]
                    else:
                        if db.execute("SELECT COUNT(*) FROM classes WHERE user_id = ?", (uid,)).fetchone()[0] >= MAX_CLASSES:
                            raise ValueError(f"الحد الأقصى {MAX_CLASSES} فصلًا")
                        cid = db.execute("INSERT INTO classes(user_id, name, created_at) VALUES (?,?,?)", (uid, name, now())).lastrowid
                        classes_made += 1
            for raw in gr["names"]:
                nm = clean_name(raw)
                if len(nm) < 2:
                    skipped += 1
                    continue
                if have + added >= MAX_STUDENTS:
                    raise ValueError(f"الحد الأقصى {MAX_STUDENTS} طالبًا")
                try:
                    db.execute("INSERT INTO students(user_id, class_id, name, created_at) VALUES (?,?,?,?)", (uid, cid, nm, now()))
                    added += 1
                except Exception:
                    skipped += 1          # the same name is already in that class
        db.commit()
    except ValueError as exc:
        db.rollback()
        return jsonify(error=str(exc)), 400
    except Exception:
        db.rollback()
        raise
    return jsonify(added=added, skipped=skipped, classes_made=classes_made, students=listing(), classes=classes_list()), 201


@bp.patch("/api/students/<int:sid>")
@login_required
def rename(sid):
    student_row(sid)
    name = clean_name(body().get("name"))
    if len(name) < 2:
        return jsonify(error="اكتبي اسمًا صحيحًا"), 400
    try:
        current_app.db.execute("UPDATE students SET name = ? WHERE id = ?", (name, sid))
        current_app.db.commit()
    except Exception:
        return jsonify(error="يوجد طالب بهذا الاسم في الفصل"), 409
    return jsonify(saved=True)


@bp.delete("/api/students/<int:sid>")
@login_required
def remove(sid):
    student_row(sid)
    current_app.db.execute("DELETE FROM students WHERE id = ?", (sid,))          # his results go with him
    current_app.db.commit()
    return jsonify(ok=True)


@bp.post("/api/results")
@login_required
def record():
    d = body()
    db = current_app.db
    student = student_row(toint(d.get("student_id")))
    deck = mine("decks", toint(d.get("deck_id")))
    qid = toint(d.get("question_id"))
    if qid not in jload(deck["question_ids"], []):
        return jsonify(error="السؤال ليس من هذا العرض"), 400
    q = db.execute("SELECT kind, question FROM questions WHERE id = ? AND user_id = ?", (qid, g.user["id"])).fetchone()
    if not q:
        return jsonify(error="السؤال غير موجود"), 404
    run = str(d.get("run", ""))[:40]
    correct = 1 if d.get("correct") in (True, 1, "1") else 0
    db.execute("""INSERT INTO results(user_id, student_id, deck_id, deck_title, question_id, question, game, kind, correct, run, created_at)
                  VALUES (?,?,?,?,?,?,?,?,?,?,?)
                  ON CONFLICT(student_id, deck_id, question_id, run) DO UPDATE SET correct = excluded.correct, game = excluded.game, created_at = excluded.created_at""",
               (g.user["id"], student["id"], deck["id"], deck["title"], qid, q["question"][:200], str(d.get("game", ""))[:20], q["kind"], correct, run, now()))
    db.commit()
    return jsonify(ok=True)


@bp.get("/api/students/<int:sid>/results")
@login_required
def results(sid):
    s = student_row(sid)
    db = current_app.db
    decks = db.execute("""SELECT deck_title, COUNT(*) AS answered, SUM(correct) AS correct, MAX(created_at) AS last FROM results WHERE student_id = ?
                          GROUP BY COALESCE(deck_id, deck_title) ORDER BY last DESC""", (sid,)).fetchall()
    recent = db.execute("SELECT deck_title, question, correct, created_at FROM results WHERE student_id = ? ORDER BY created_at DESC, id DESC LIMIT 40", (sid,)).fetchall()
    return jsonify(name=s["name"], decks=[{"title": r["deck_title"], "answered": r["answered"], "correct": r["correct"], "percent": textfmt.percent(r["correct"], r["answered"]), "last": r["last"]} for r in decks],
                   recent=[{"deck": r["deck_title"], "question": r["question"], "correct": bool(r["correct"]), "at": r["created_at"]} for r in recent])


@bp.delete("/api/students/<int:sid>/results")
@login_required
def clear_results(sid):
    student_row(sid)
    current_app.db.execute("DELETE FROM results WHERE student_id = ?", (sid,))
    current_app.db.commit()
    return jsonify(ok=True)
