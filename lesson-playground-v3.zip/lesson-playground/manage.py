"""Small admin commands:  python manage.py set-plan teacher@example.com monthly\n                  python manage.py make-admin you@example.com"""
import sys

from app import create_app


def main():
    app = create_app()
    if len(sys.argv) == 4 and sys.argv[1] == "set-plan":
        email, plan = sys.argv[2].lower(), sys.argv[3]
        if not app.db.execute("SELECT 1 FROM plans WHERE code = ?", (plan,)).fetchone():
            sys.exit("unknown plan (free, monthly, yearly)")
        n = app.db.execute("UPDATE users SET plan_code = ? WHERE email = ?", (plan, email)).rowcount
        app.db.commit()
        print("done" if n else "no such user")
    elif len(sys.argv) == 3 and sys.argv[1] == "make-admin":
        n = app.db.execute("UPDATE users SET is_admin = 1 WHERE email = ?", (sys.argv[2].lower(),)).rowcount
        app.db.commit()
        print("done" if n else "no such user")
    else:
        print(__doc__)


main()
