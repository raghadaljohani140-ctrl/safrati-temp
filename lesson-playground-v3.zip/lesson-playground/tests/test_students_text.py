import io
import json
import re
import unittest

from app import aiq, extract, meta
from tests import fixtures as F
from tests.test_app import Base

HEADER = "المادة: العلوم العامة الصف: الأول الثانوي المرحلة: الثانوية"


def damaged_pdf(lines):
    """A PDF like the teacher's: every word its own text object, placed left-to-right (so the words of a line come out reversed), with ى / ھ in the middle of words."""
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.pdfgen import canvas
    try:
        pdfmetrics.getFont("DJ")
    except KeyError:
        pdfmetrics.registerFont(TTFont("DJ", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"))
    buf = io.BytesIO()
    cv = canvas.Canvas(buf, pagesize=(595, 842))
    y = 780
    for ln in lines:
        x = 40
        for w in reversed(ln.split()):
            w = "".join("ى" if c == "ي" and i + 1 < len(w) else "ھ" if c == "ه" and i + 1 < len(w) else c for i, c in enumerate(w))
            cv.setFont("DJ", 14)
            cv.drawString(x, y, w[::-1])
            x += pdfmetrics.stringWidth(w, "DJ", 14) + 8
        y -= 30
    cv.save()
    return buf.getvalue()


BODY = ["مقدمة في مفهوم الطاقة والتحول العالمي والمصادر المتجددة.",
        "الطاقة المتجددة هي الطاقة التي تأتي من مصادر طبيعية لا تنفد مثل الشمس والرياح."]


class TextTests(unittest.TestCase):
    def test_letters_that_do_not_join_become_normal_letters(self):
        broken = "أساسىات المفھوم والأكادىمىة کیف على إلى مستشفى"
        fixed = extract.arabic_letters(broken)
        self.assertEqual(fixed, "أساسيات المفهوم والأكاديمية كيف على إلى مستشفى")      # a final ى stays
        self.assertEqual(extract.arabic_letters("ﻣﻔﻬﻮم ﺍﻟﻄﺎﻗﺔ"), "مفهوم الطاقة")             # presentation forms

    def test_words_of_a_left_to_right_pdf_are_put_back_in_order_and_header_is_removed(self):
        text, details = extract.read("pdf", damaged_pdf([HEADER, "الوحدة الثالثة: الطاقة المتجددة", *BODY]))
        self.assertIn("الطاقة المتجددة هي الطاقة التي تأتي من مصادر طبيعية لا تنفد مثل الشمس والرياح.", text)
        self.assertIn("مقدمة في مفهوم الطاقة والتحول العالمي والمصادر المتجددة.", text)
        for bad in ("ى", "ھ", "المادة", "الصف:", "المرحلة"):
            self.assertNotIn(bad if bad != "ى" else "ىا", text)
        self.assertEqual(details, {"subject": "العلوم العامة", "grade": "الأول الثانوي"})
        self.assertNotIn("الأول الثانوي", text)

    def test_a_normal_chromium_pdf_still_reads_the_same(self):
        text = extract.extract("pdf", F.pdf_bytes())
        self.assertIn("النواة هي مركز التحكم في الخلية", text)

    def test_subject_and_class_never_reach_a_question(self):
        text, _ = meta.split_header(HEADER + "\n" + "\n".join(BODY))
        items = [
            {"kind": "qa", "question": "في مادة العلوم للصف الأول الثانوي، ما الطاقة المتجددة؟", "answer": "الطاقة التي تأتي من مصادر طبيعية", "evidence": "الطاقة المتجددة هي الطاقة التي تأتي من مصادر طبيعية لا تنفد مثل الشمس والرياح"},
            {"kind": "mcq", "question": "ما المقصود بالطاقة المتجددة؟", "answer": "الطاقة التي تأتي من مصادر طبيعية", "options": ["الطاقة التي تأتي من مصادر طبيعية", "الصف الأول الثانوي"], "evidence": "الطاقة المتجددة هي الطاقة التي تأتي من مصادر طبيعية لا تنفد مثل الشمس والرياح"},
            {"kind": "qa", "question": "ما المادة؟", "answer": "المادة: العلوم", "evidence": "الطاقة المتجددة هي الطاقة التي تأتي من مصادر طبيعية لا تنفد"},
            {"kind": "qa", "question": "ما مصدر الطاقة المتجددة للصف الثالث الثانوي؟", "answer": "الشمس", "evidence": "مثل الشمس والرياح"},
        ]
        out = aiq.clean_items(items, text, strict=False)
        blob = json.dumps(out, ensure_ascii=False)
        for word in ("مادة", "للصف", "الصف", "الثانوي"):
            self.assertNotIn(word, blob)
        self.assertEqual(out[0]["question"], "ما الطاقة المتجددة؟")
        self.assertEqual(len(out), 2)                                     # the one with the class as an option, and the one asking for the subject, are dropped

    def test_the_offline_generator_makes_clean_questions_from_a_damaged_pdf(self):
        class C:
            ai_provider, anthropic_key, anthropic_model = "offline", "", "m"
        text, _ = extract.read("pdf", damaged_pdf([HEADER, *BODY]))
        _, items, _ = aiq.make_questions(C, text, False)
        self.assertTrue(items)
        blob = json.dumps(items, ensure_ascii=False)
        for word in ("المادة", "الصف", "العلوم العامة", "الأول الثانوي"):
            self.assertNotIn(word, blob)


class UploadTests(Base):
    def test_the_lesson_keeps_subject_and_class_as_its_own_details_only(self):
        c = self.client()
        self.register(c)
        r = self.upload(c, "energy.pdf", damaged_pdf([HEADER, "الوحدة الثالثة: الطاقة المتجددة", *BODY]))
        lid = int(re.search(r"/lessons/(\d+)", r.headers["Location"]).group(1))
        row = self.app.db.execute("SELECT * FROM lessons WHERE id = ?", (lid,)).fetchone()
        self.assertEqual((row["status"], row["subject"], row["grade"]), ("ready", "العلوم العامة", "الأول الثانوي"))
        st = c.get(f"/api/lessons/{lid}").get_json()
        self.assertEqual((st["subject"], st["grade"]), ("العلوم العامة", "الأول الثانوي"))
        self.assertIn('id="lesson-info"', c.get(f"/lessons/{lid}").get_data(as_text=True))
        qs = c.get(f"/api/lessons/{lid}/questions").get_json()["questions"]
        self.assertTrue(qs)
        blob = json.dumps(qs, ensure_ascii=False)
        for word in ("العلوم العامة", "الأول الثانوي", "المادة", "الصف"):
            self.assertNotIn(word, blob)
        self.assertNotIn("العلوم العامة", row["text"])


class StudentTests(Base):
    def setUp(self):
        super().setUp()
        self.c, self.lid = self.teacher_with_lesson()

    def students(self, c=None):
        return (c or self.c).get("/api/students").get_json()["students"]

    def deck(self, games=("pick", "qa")):
        qs = self.c.get(f"/api/lessons/{self.lid}/questions").get_json()["questions"]
        r = self.j(self.c, "post", f"/api/lessons/{self.lid}/decks", {"games": list(games), "question_ids": [q["id"] for q in qs]})
        self.assertEqual(r.status_code, 201)
        return r.get_json()["id"], qs

    def test_add_edit_delete_and_save_the_list(self):
        r = self.j(self.c, "post", "/api/students", {"names": ["سارة أحمد", "  نورة   علي ", "سارة أحمد", "x"]})
        self.assertEqual((r.status_code, r.get_json()["added"], r.get_json()["skipped"]), (201, 2, 2))
        self.assertEqual([s["name"] for s in self.students()], ["سارة أحمد", "نورة علي"])
        sid = self.students()[0]["id"]
        self.assertEqual(self.j(self.c, "patch", f"/api/students/{sid}", {"name": "سارة محمد"}).status_code, 200)
        self.assertEqual(self.j(self.c, "patch", f"/api/students/{sid}", {"name": "نورة علي"}).status_code, 409)
        self.assertEqual(self.j(self.c, "post", "/api/students", {"name": "ريم"}).status_code, 201)
        self.assertEqual(len(self.students()), 3)
        self.assertEqual(self.j(self.c, "delete", f"/api/students/{sid}").status_code, 200)
        self.assertEqual(sorted(s["name"] for s in self.students()), ["ريم", "نورة علي"])
        self.assertEqual(self.c.get("/students").status_code, 200)

    def test_results_are_linked_to_the_student_and_summed(self):
        self.j(self.c, "post", "/api/students", {"names": ["سارة", "نورة"]})
        a, b = self.students()
        deck, qs = self.deck()
        def rec(s, q, ok, run="r1", game="pick"):
            return self.j(self.c, "post", "/api/results", {"student_id": s["id"], "deck_id": deck, "question_id": q["id"], "game": game, "correct": ok, "run": run})
        self.assertEqual(rec(a, qs[0], True).status_code, 200)
        self.assertEqual(rec(a, qs[1], False).status_code, 200)
        self.assertEqual(rec(a, qs[1], True).status_code, 200)                 # marking the same question again corrects it, never doubles it
        self.assertEqual(rec(b, qs[0], False).status_code, 200)
        by = {s["name"]: s for s in self.students()}
        self.assertEqual((by["سارة"]["answered"], by["سارة"]["correct"], by["سارة"]["percent"], by["سارة"]["level"]), (2, 2, 100, "ممتاز"))
        self.assertEqual((by["نورة"]["answered"], by["نورة"]["percent"], by["نورة"]["level"]), (1, 0, "يحتاج إلى دعم"))
        detail = self.c.get(f"/api/students/{a['id']}/results").get_json()
        self.assertEqual((detail["decks"][0]["answered"], detail["decks"][0]["correct"], len(detail["recent"])), (2, 2, 2))
        self.assertEqual(self.j(self.c, "post", "/api/results", {"student_id": a["id"], "deck_id": deck, "question_id": 99999, "correct": 1}).status_code, 400)
        self.assertEqual(self.j(self.c, "post", "/api/results", {"student_id": "x", "deck_id": deck, "question_id": qs[0]["id"]}).status_code, 404)
        self.j(self.c, "delete", f"/api/students/{a['id']}/results")
        self.assertEqual({s["name"]: s["answered"] for s in self.students()}["سارة"], 0)
        # deleting the student takes her results with her; the deck keeps working
        self.j(self.c, "delete", f"/api/students/{b['id']}")
        self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM results").fetchone()[0], 0)

    def test_a_teacher_never_sees_or_touches_another_teachers_students(self):
        self.j(self.c, "post", "/api/students", {"name": "سارة"})
        sid = self.students()[0]["id"]
        deck, qs = self.deck()
        other = self.client()
        self.register(other, "b@example.com")
        self.assertEqual(self.students(other), [])
        for method, url, data in (("patch", f"/api/students/{sid}", {"name": "x1"}), ("delete", f"/api/students/{sid}", None)):
            self.assertEqual(self.j(other, method, url, data).status_code, 404)
        self.assertEqual(other.get(f"/api/students/{sid}/results").status_code, 404)
        self.assertEqual(self.j(other, "post", "/api/results", {"student_id": sid, "deck_id": deck, "question_id": qs[0]["id"], "correct": 1}).status_code, 404)
        self.assertEqual(self.j(other, "post", "/api/students", {"name": "سارة"}).status_code, 201)        # the same name is fine for her
        self.assertEqual(len(self.students()), 1)

    def test_results_need_login_and_the_page_is_private(self):
        anon = self.client()
        self.assertEqual(anon.get("/students").status_code, 302)
        self.assertEqual(anon.get("/api/students").status_code, 401)
        self.assertEqual(anon.post("/api/results", json={}).status_code in (401, 403), True)

    def test_account_deletion_removes_students_and_results(self):
        self.j(self.c, "post", "/api/students", {"name": "سارة"})
        deck, qs = self.deck()
        s = self.students()[0]
        self.j(self.c, "post", "/api/results", {"student_id": s["id"], "deck_id": deck, "question_id": qs[0]["id"], "correct": 1, "run": "a"})
        self.assertEqual(self.j(self.c, "post", "/api/me/delete", {"password": "Teacher-pass-1"}).status_code, 200)
        db = self.app.db
        self.assertEqual((db.execute("SELECT COUNT(*) FROM students").fetchone()[0], db.execute("SELECT COUNT(*) FROM results").fetchone()[0]), (0, 0))

    def test_the_students_wheel_is_a_game_and_old_decks_get_it_too(self):
        deck, qs = self.deck(("qa",))
        data = self.c.get(f"/api/decks/{deck}/data").get_json()
        self.assertIn("pick", data["game_info"])
        self.assertEqual(sorted(data["game_info"]["pick"]["kinds"]), sorted(aiq.KINDS))
        page = self.c.get(f"/lessons/{self.lid}").get_data(as_text=True)
        self.assertIn('value="pick"', page)

    def test_old_database_gets_the_new_tables_and_columns(self):
        import sqlite3, tempfile
        from app import db as dbm
        with tempfile.TemporaryDirectory() as d:
            conn = sqlite3.connect(d + "/old.db")
            conn.executescript("CREATE TABLE users(id INTEGER PRIMARY KEY, email TEXT, name TEXT, pass_hash TEXT, plan_code TEXT DEFAULT 'free', ai_consent INTEGER DEFAULT 0, created_at REAL);"
                               "CREATE TABLE lessons(id INTEGER PRIMARY KEY, user_id INTEGER, title TEXT, original_name TEXT, stored_name TEXT, kind TEXT, text TEXT DEFAULT '', status TEXT DEFAULT 'ready', error TEXT DEFAULT '', engine TEXT DEFAULT '', created_at REAL, updated_at REAL);"
                               "CREATE TABLE plans(code TEXT PRIMARY KEY, name TEXT, max_lessons INTEGER, max_decks INTEGER, price_month INTEGER DEFAULT 0, price_year INTEGER DEFAULT 0, purchasable INTEGER DEFAULT 0);"
                               "INSERT INTO users(email, name, pass_hash, created_at) VALUES ('o@x.com','o','h',1); INSERT INTO lessons(user_id,title,original_name,stored_name,kind,created_at,updated_at) VALUES (1,'t','a','b','pdf',1,1);")
            conn.row_factory = sqlite3.Row
            dbm.init(conn)
            cols = [r[1] for r in conn.execute("PRAGMA table_info(lessons)")]
            self.assertIn("subject", cols)
            self.assertIn("grade", cols)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM lessons").fetchone()[0], 1)           # nothing was lost
            conn.execute("INSERT INTO students(user_id, name, created_at) VALUES (1, 'x', 1)")


if __name__ == "__main__":
    unittest.main()
