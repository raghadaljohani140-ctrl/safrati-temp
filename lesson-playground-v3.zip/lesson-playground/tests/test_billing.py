import io
import json
import re
import time
import unittest

from app import aiq, billing
from tests import fixtures as F
from tests.test_app import Base

IBAN = "SA0380000000608010167519"
DAY = 86400


class Money(Base):
    def post(self, c, url, **data):
        return c.post(url, data={"_csrf": self.token(c), **data})

    def setup_bank(self):
        for k, v in (("bank_name", "بنك تجريبي"), ("bank_holder", "صاحب الحساب"), ("bank_iban", IBAN)):
            self.app.db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES (?, ?)", (k, v))
        self.app.db.commit()

    def admin(self):
        c = self.client()
        self.register(c, "boss@example.com", "المديرة")
        self.app.db.execute("UPDATE users SET is_admin = 1 WHERE email = 'boss@example.com'")
        self.app.db.commit()
        return c

    def uid(self, email):
        return self.app.db.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone()[0]

    def ask(self, c, plan="monthly"):
        self.post(c, "/subscribe/request", plan=plan)
        return self.app.db.execute("SELECT * FROM subscription_requests ORDER BY id DESC").fetchone()


class FlowTests(Money):
    def test_request_needs_bank_details_and_makes_a_code(self):
        c = self.client()
        self.register(c)
        self.assertIn("بيانات الحساب", c.get("/subscribe").get_data(as_text=True))
        self.post(c, "/subscribe/request", plan="monthly")
        self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM subscription_requests").fetchone()[0], 0)
        self.setup_bank()
        req = self.ask(c)
        self.assertEqual((req["ref_code"], req["amount"], req["status"]), (f"LP-{1000 + req['id']}", 2900, "pending"))
        page = c.get("/subscribe").get_data(as_text=True)
        self.assertIn(req["ref_code"], page)
        self.assertIn(IBAN, page)
        self.post(c, "/subscribe/request", plan="yearly")                       # one open request at a time
        self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM subscription_requests").fetchone()[0], 1)
        self.post(c, "/subscribe/request", plan="free")
        self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM subscription_requests").fetchone()[0], 1)

    def test_confirm_activates_and_lifts_limits_then_expiry_returns_to_free(self):
        self.setup_bank()
        t = self.client()
        self.register(t)
        req = self.ask(t)
        self.post(t, f"/subscribe/{req['id']}/paid", payer_name="أم أحمد", transfer_date="2026-11-01")
        adm = self.admin()
        self.assertIn("أم أحمد", adm.get("/admin").get_data(as_text=True))
        self.assertEqual(self.post(adm, f"/admin/requests/{req['id']}/confirm").status_code, 302)
        u = self.app.db.execute("SELECT * FROM users WHERE email = 'a@example.com'").fetchone()
        self.assertEqual(u["plan_code"], "monthly")
        self.assertAlmostEqual(u["plan_expires"] - time.time(), 30 * DAY, delta=60)
        self.assertEqual(billing.plan_of(self.app.db, u)["max_lessons"], 30)
        self.assertEqual(self.app.db.execute("SELECT status FROM subscription_requests").fetchone()[0], "confirmed")
        self.assertEqual(self.post(adm, f"/admin/requests/{req['id']}/confirm").status_code, 404)      # not twice
        # renewal while active extends from the end date
        req2 = self.ask(t)
        self.post(adm, f"/admin/requests/{req2['id']}/confirm")
        u2 = self.app.db.execute("SELECT plan_expires FROM users WHERE email = 'a@example.com'").fetchone()[0]
        self.assertAlmostEqual(u2 - u["plan_expires"], 30 * DAY, delta=60)
        # a lapsed subscription is free again, with the lessons untouched
        self.upload(t, "cell.pptx", F.pptx_bytes())
        self.app.db.execute("UPDATE users SET plan_expires = ?", (time.time() - 5,))
        self.app.db.commit()
        u3 = self.app.db.execute("SELECT * FROM users WHERE email = 'a@example.com'").fetchone()
        self.assertEqual(billing.plan_of(self.app.db, u3)["code"], "free")
        self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM lessons").fetchone()[0], 1)
        self.assertIn("عدتِ إلى الباقة المجانية", t.get("/dashboard").get_data(as_text=True))

    def test_reject_and_cancel(self):
        self.setup_bank()
        t = self.client()
        self.register(t)
        req = self.ask(t)
        adm = self.admin()
        self.post(adm, f"/admin/requests/{req['id']}/reject", note="لم يصل التحويل")
        row = self.app.db.execute("SELECT status, note FROM subscription_requests").fetchone()
        self.assertEqual((row[0], row[1]), ("rejected", "لم يصل التحويل"))
        self.assertEqual(self.app.db.execute("SELECT plan_code FROM users WHERE email = 'a@example.com'").fetchone()[0], "free")
        req2 = self.ask(t)
        self.post(t, f"/subscribe/{req2['id']}/cancel")
        self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM subscription_requests WHERE id = ?", (req2["id"],)).fetchone()[0], 0)

    def test_renewal_warning_seven_days_before(self):
        t = self.client()
        self.register(t)
        self.app.db.execute("UPDATE users SET plan_code = 'monthly', plan_expires = ?", (time.time() + 3 * DAY,))
        self.app.db.commit()
        self.assertIn("ينتهي اشتراكك بعد 3", t.get("/dashboard").get_data(as_text=True))
        self.app.db.execute("UPDATE users SET plan_expires = ?", (time.time() + 20 * DAY,))
        self.app.db.commit()
        self.assertNotIn("ينتهي اشتراكك", t.get("/dashboard").get_data(as_text=True))


class AccessTests(Money):
    def test_admin_pages_do_not_exist_for_teachers_or_visitors(self):
        self.setup_bank()
        t = self.client()
        self.register(t)
        req = self.ask(t)
        self.assertEqual(t.get("/admin").status_code, 404)
        self.assertEqual(self.post(t, f"/admin/requests/{req['id']}/confirm").status_code, 404)
        self.assertEqual(self.post(t, "/admin/settings", bank_iban=IBAN, ai_cap_sar="1", fixed_sar="1").status_code, 404)
        self.assertEqual(self.client().get("/admin").status_code, 302)
        self.assertEqual(self.app.db.execute("SELECT status FROM subscription_requests").fetchone()[0], "pending")

    def test_receipts_are_private_and_validated(self):
        self.setup_bank()
        a, b = self.client(), self.client()
        self.register(a)
        self.register(b, "b@example.com")
        req = self.ask(a)
        bad = self.post(a, f"/subscribe/{req['id']}/paid", payer_name="س ص", receipt=(io.BytesIO(b"MZ not an image"), "x.png"))
        self.assertEqual(bad.status_code, 302)
        self.assertEqual(self.app.db.execute("SELECT receipt FROM subscription_requests").fetchone()[0], "")
        t = self.token(a)
        a.post(f"/subscribe/{req['id']}/paid", data={"_csrf": t, "payer_name": "س ص", "receipt": (io.BytesIO(b"%PDF-1.4 receipt"), "r.pdf")}, content_type="multipart/form-data")
        name = self.app.db.execute("SELECT receipt FROM subscription_requests").fetchone()[0]
        self.assertTrue(name.startswith("rcpt-") and name.endswith(".pdf"))
        self.assertEqual(a.get(f"/subscribe/{req['id']}/receipt").status_code, 200)
        self.assertEqual(b.get(f"/subscribe/{req['id']}/receipt").status_code, 404)
        self.assertEqual(b.get(f"/admin/requests/{req['id']}/receipt").status_code, 404)
        self.assertEqual(self.admin().get(f"/admin/requests/{req['id']}/receipt").status_code, 200)
        self.assertEqual(self.post(b, f"/subscribe/{req['id']}/paid", payer_name="لص").status_code, 404)
        # deleting the account removes the receipt file too
        t = self.token(a)
        self.assertEqual(a.post("/api/me/delete", json={"password": "Teacher-pass-1"}, headers={"X-CSRF": t}).status_code, 200)
        self.assertFalse((self.app.cfg.upload_dir / name).exists())

    def test_settings_validate_the_iban(self):
        adm = self.admin()
        self.post(adm, "/admin/settings", bank_iban="12345", ai_cap_sar="10", fixed_sar="5")
        self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM settings WHERE key = 'bank_iban'").fetchone()[0], 0)
        self.post(adm, "/admin/settings", bank_name="ب", bank_holder="ح", bank_iban="sa03 8000 0000 6080 1016 7519", ai_cap_sar="10", fixed_sar="5", vat="1")
        self.assertEqual(self.app.db.execute("SELECT value FROM settings WHERE key = 'bank_iban'").fetchone()[0], IBAN)


class AiMoneyTests(Money):
    def paid_teacher(self, plan="monthly"):
        t = self.client()
        self.register(t)
        self.app.db.execute("UPDATE users SET plan_code = ?, plan_expires = ?, ai_consent = 1 WHERE email = 'a@example.com'", (plan, time.time() + 10 * DAY))
        self.app.db.commit()
        self.app.cfg.ai_provider, self.app.cfg.anthropic_key = "claude", "TEST-KEY"
        return t

    def stub(self, calls):
        def post(inner, payload):
            calls.append(payload["model"])
            return {"content": [{"text": "[]"}], "usage": {"input_tokens": 3000, "output_tokens": 1500}}
        return post

    def test_paid_reader_runs_only_when_allowed_and_every_call_is_logged(self):
        calls = []
        orig = aiq.ClaudeProvider._post
        aiq.ClaudeProvider._post = self.stub(calls)
        try:
            free = self.client()
            self.register(free, "free@example.com")
            self.app.db.execute("UPDATE users SET ai_consent = 1 WHERE email = 'free@example.com'")
            self.app.db.commit()
            self.upload(free, "cell.pptx", F.pptx_bytes())
            self.assertEqual(calls, [])                                         # free plan: zero AI cost
            t = self.paid_teacher()
            self.upload(t, "cell.pptx", F.pptx_bytes())
            self.assertEqual(calls, ["claude-haiku-5-5"])
            row = self.app.db.execute("SELECT * FROM ai_usage").fetchone()
            self.assertEqual((row["input_tokens"], row["output_tokens"], row["cost"]), (3000, 1500, billing.cost_halalas("claude-haiku-5-5", 3000, 1500)))
            self.assertGreater(row["cost"], 0)
        finally:
            aiq.ClaudeProvider._post = orig

    def test_quota_and_monthly_cap_stop_the_paid_reader(self):
        calls = []
        orig = aiq.ClaudeProvider._post
        aiq.ClaudeProvider._post = self.stub(calls)
        try:
            t = self.paid_teacher()
            uid = self.uid("a@example.com")
            self.app.db.execute("UPDATE plans SET ai_quota = 2 WHERE code = 'monthly'")
            self.app.db.commit()
            for _ in range(3):
                self.upload(t, "cell.pptx", F.pptx_bytes())
            self.assertEqual(len(calls), 2)                                      # the third lesson used the free generator
            self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM lessons").fetchone()[0], 3)
            self.assertEqual(billing.ai_used(self.app.db, uid), 2)
            # the cap: pretend the month's bill is already at the limit
            self.app.db.execute("UPDATE plans SET ai_quota = 100 WHERE code = 'monthly'")
            self.app.db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES ('ai_cap_sar', '0.01')")
            self.app.db.commit()
            self.upload(t, "cell.pptx", F.pptx_bytes())
            self.assertEqual(len(calls), 2)
        finally:
            aiq.ClaudeProvider._post = orig

    def test_a_failed_paid_call_still_falls_back_and_counts_what_was_charged(self):
        orig = aiq.ClaudeProvider._post
        aiq.ClaudeProvider._post = lambda inner, payload: {"content": [{"text": "not json at all ["}], "usage": {"input_tokens": 10, "output_tokens": 5}}
        try:
            t = self.paid_teacher()
            r = self.upload(t, "cell.pptx", F.pptx_bytes())
            self.assertEqual(r.status_code, 302)
            self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM questions").fetchone()[0] > 0, True)
            self.assertEqual(self.app.db.execute("SELECT COUNT(*) FROM ai_usage").fetchone()[0], 1)
        finally:
            aiq.ClaudeProvider._post = orig

    def test_finance_numbers(self):
        db = self.app.db
        self.admin()
        t = self.client()
        self.register(t)
        uid = self.uid("a@example.com")
        db.execute("INSERT INTO subscription_requests(user_id, plan_code, period, amount, status, created_at, decided_at, ref_code) VALUES (?, 'monthly', 'month', 2900, 'confirmed', ?, ?, 'LP-1')", (uid, time.time(), time.time()))
        db.execute("INSERT INTO subscription_requests(user_id, plan_code, period, amount, status, created_at, decided_at, ref_code) VALUES (?, 'yearly', 'year', 24900, 'rejected', ?, ?, 'LP-2')", (uid, time.time(), time.time()))
        billing.log_ai(db, uid, None, "claude-haiku-5-5", 1_000_000, 0)            # $0.10 = 0.375 SAR → 38 halalas
        db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES ('fixed_sar', '10')")
        db.commit()
        f = billing.finance(db)
        self.assertEqual((f["gross"], f["vat"], f["fixed"]), (2900, 0, 1000))
        self.assertEqual(f["ai"], billing.cost_halalas("claude-haiku-5-5", 1_000_000, 0))
        self.assertEqual(f["net"], 2900 - f["ai"] - 1000)
        db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES ('vat_registered', '1')")
        db.commit()
        f = billing.finance(db)
        self.assertEqual(f["vat"], round(2900 - 2900 / 1.15))
        self.assertEqual(f["net"], 2900 - f["vat"] - f["ai"] - 1000)


class AbuseTests(Money):
    def test_registration_and_upload_are_rate_limited(self):
        c = self.client()
        codes = [self.register(c, f"u{i}@example.com").status_code for i in range(7)]
        self.assertEqual(codes[:5], [302] * 5)
        self.assertEqual(codes[5], 400)
        t = self.client()
        from app import auth
        auth.register_limit.hits.clear()
        self.register(t, "x@example.com")
        from app import lessons
        for _ in range(20):
            lessons.upload_limit.allow(self.uid("x@example.com"))
        r = self.upload(t, "cell.pptx", F.pptx_bytes())
        self.assertIn("ملفات كثيرة", __import__("urllib.parse").parse.unquote_plus(r.headers["Location"]))


if __name__ == "__main__":
    unittest.main()
