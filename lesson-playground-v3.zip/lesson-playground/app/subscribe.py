"""The teacher's side of a subscription by bank transfer: ask, see the account and her own code, say she paid, wait for the manager."""
import secrets
import time

from flask import Blueprint, abort, current_app, g, redirect, render_template, request, send_file, url_for

from . import billing, db as dbm
from .security import login_required

bp = Blueprint("subscribe", __name__)
RECEIPT_TYPES = {b"%PDF-": "pdf", b"\xff\xd8\xff": "jpg", b"\x89PNG\r": "png"}
MAX_RECEIPT = 5 * 1024 * 1024


def bank(conn) -> dict:
    return {k: dbm.setting(conn, "bank_" + k) for k in ("name", "holder", "iban")}


def mine_request(rid):
    row = current_app.db.execute("SELECT * FROM subscription_requests WHERE id = ? AND user_id = ?", (rid, g.user["id"])).fetchone()
    if not row:
        abort(404)
    return row


@bp.get("/subscribe")
@login_required
def page():
    db = current_app.db
    plans = {r["code"]: r for r in db.execute("SELECT * FROM plans WHERE purchasable = 1")}
    reqs = db.execute("SELECT r.*, p.name AS plan_name FROM subscription_requests r JOIN plans p ON p.code = r.plan_code WHERE r.user_id = ? ORDER BY r.id DESC LIMIT 10", (g.user["id"],)).fetchall()
    pending = next((r for r in reqs if r["status"] == "pending"), None)
    cur = billing.plan_of(db, g.user)
    return render_template("subscribe.html", plans=plans, reqs=reqs, pending=pending, bank=bank(db), cur=cur, left=billing.days_left(g.user), riyals=billing.riyals,
                           ai_used=billing.ai_used(db, g.user["id"]), msg=request.args.get("msg", ""))


@bp.post("/subscribe/request")
@login_required
def ask():
    db = current_app.db
    code = request.form.get("plan", "")
    plan = db.execute("SELECT * FROM plans WHERE code = ? AND purchasable = 1", (code,)).fetchone()
    if not plan:
        return redirect(url_for("subscribe.page", msg="اختاري باقة صحيحة"))
    if not bank(db)["iban"]:
        return redirect(url_for("subscribe.page", msg="بيانات الحساب البنكي لم تُضَف بعد، جرّبي لاحقًا"))
    if db.execute("SELECT 1 FROM subscription_requests WHERE user_id = ? AND status = 'pending'", (g.user["id"],)).fetchone():
        return redirect(url_for("subscribe.page", msg="لديك طلب قائم بانتظار التأكيد"))
    period = billing.period_of(code)
    cur = db.execute("INSERT INTO subscription_requests(user_id, plan_code, period, amount, created_at) VALUES (?,?,?,?,?)",
                     (g.user["id"], code, period, billing.price_of(plan, period), time.time()))
    db.execute("UPDATE subscription_requests SET ref_code = ? WHERE id = ?", (f"LP-{1000 + cur.lastrowid}", cur.lastrowid))
    db.commit()
    return redirect(url_for("subscribe.page", msg="تم إنشاء طلبك. حوّلي المبلغ واكتبي رمز الطلب في ملاحظات التحويل"))


@bp.post("/subscribe/<int:rid>/paid")
@login_required
def paid(rid):
    req = mine_request(rid)
    if req["status"] != "pending":
        abort(404)
    payer = request.form.get("payer_name", "").strip()[:80]
    date = request.form.get("transfer_date", "").strip()[:10]
    if len(payer) < 2:
        return redirect(url_for("subscribe.page", msg="اكتبي اسم صاحب الحساب المحوِّل"))
    receipt = req["receipt"]
    f = request.files.get("receipt")
    if f and f.filename:
        data = f.read(MAX_RECEIPT + 1)
        ext = next((e for magic, e in RECEIPT_TYPES.items() if data.startswith(magic)), None)
        if not ext or len(data) > MAX_RECEIPT:
            return redirect(url_for("subscribe.page", msg="الإيصال يجب أن يكون PDF أو صورة JPG/PNG حتى 5 ميجابايت"))
        name = "rcpt-" + secrets.token_hex(12) + "." + ext
        (current_app.cfg.upload_dir / name).write_bytes(data)
        if receipt:
            try:
                (current_app.cfg.upload_dir / receipt).unlink()
            except OSError:
                pass
        receipt = name
    current_app.db.execute("UPDATE subscription_requests SET payer_name = ?, transfer_date = ?, receipt = ? WHERE id = ?", (payer, date, receipt, rid))
    current_app.db.commit()
    return redirect(url_for("subscribe.page", msg="وصلنا إشعارك، سنؤكد التحويل ونفعّل باقتك قريبًا"))


@bp.post("/subscribe/<int:rid>/cancel")
@login_required
def cancel(rid):
    req = mine_request(rid)
    if req["status"] == "pending":
        current_app.db.execute("DELETE FROM subscription_requests WHERE id = ?", (rid,))
        current_app.db.commit()
        if req["receipt"]:
            try:
                (current_app.cfg.upload_dir / req["receipt"]).unlink()
            except OSError:
                pass
    return redirect(url_for("subscribe.page", msg="أُلغي الطلب"))


@bp.get("/subscribe/<int:rid>/receipt")
@login_required
def receipt(rid):
    req = mine_request(rid)
    if not req["receipt"]:
        abort(404)
    return send_file(current_app.cfg.upload_dir / req["receipt"], download_name=req["receipt"])
