"""The manager's pages: the money, the transfers waiting to be confirmed, and the settings (bank account, caps). Only a user with is_admin sees them."""
import re
import time

from flask import Blueprint, abort, current_app, g, redirect, render_template, request, send_file, url_for

from . import billing, db as dbm
from .security import admin_required

bp = Blueprint("admin", __name__, url_prefix="/admin")
IBAN = re.compile(r"^SA[0-9]{2}[0-9A-Z]{20}$")


@bp.get("")
@admin_required
def dashboard():
    db = current_app.db
    fin = billing.finance(db)
    pending = db.execute("""SELECT r.*, u.name AS uname, u.email, p.name AS plan_name FROM subscription_requests r JOIN users u ON u.id = r.user_id
                            JOIN plans p ON p.code = r.plan_code WHERE r.status = 'pending' ORDER BY r.id""").fetchall()
    recent = db.execute("""SELECT r.*, u.name AS uname, p.name AS plan_name FROM subscription_requests r JOIN users u ON u.id = r.user_id
                           JOIN plans p ON p.code = r.plan_code WHERE r.status != 'pending' ORDER BY r.decided_at DESC LIMIT 15""").fetchall()
    soon = db.execute("SELECT name, email, plan_code, plan_expires FROM users WHERE plan_code != 'free' AND plan_expires BETWEEN ? AND ? ORDER BY plan_expires",
                      (time.time(), time.time() + billing.RENEW_WARN_DAYS * 86400)).fetchall()
    cfg = {"bank_name": dbm.setting(db, "bank_name"), "bank_holder": dbm.setting(db, "bank_holder"), "bank_iban": dbm.setting(db, "bank_iban"),
           "ai_cap_sar": f'{float(dbm.setting(db, "ai_cap_sar", billing.DEFAULT_AI_CAP_SAR)):g}', "fixed_sar": f'{float(dbm.setting(db, "fixed_sar", billing.DEFAULT_FIXED_SAR)):g}',
           "vat": dbm.setting(db, "vat_registered", "0") == "1"}
    return render_template("admin.html", fin=fin, pending=pending, recent=recent, soon=soon, cfg=cfg, riyals=billing.riyals, ai_on=current_app.cfg.ai_provider == "claude" and bool(current_app.cfg.anthropic_key),
                           msg=request.args.get("msg", ""))


@bp.post("/settings")
@admin_required
def settings():
    db, f = current_app.db, request.form
    iban = re.sub(r"\s+", "", f.get("bank_iban", "")).upper()
    if iban and not IBAN.match(iban):
        return redirect(url_for("admin.dashboard", msg="رقم الآيبان غير صحيح (يبدأ بـ SA ويتكون من 24 خانة)"))
    try:
        cap, fixed = float(f.get("ai_cap_sar", "")), float(f.get("fixed_sar", ""))
        if not (0 <= cap <= 100000 and 0 <= fixed <= 100000):
            raise ValueError
    except ValueError:
        return redirect(url_for("admin.dashboard", msg="اكتبي أرقامًا صحيحة للسقف والتكلفة الثابتة"))
    for key, val in (("bank_name", f.get("bank_name", "").strip()[:80]), ("bank_holder", f.get("bank_holder", "").strip()[:80]), ("bank_iban", iban),
                     ("ai_cap_sar", cap), ("fixed_sar", fixed), ("vat_registered", "1" if f.get("vat") == "1" else "0")):
        dbm.put_setting(db, key, val)
    return redirect(url_for("admin.dashboard", msg="تم حفظ الإعدادات"))


@bp.post("/requests/<int:rid>/<action>")
@admin_required
def decide(rid, action):
    db = current_app.db
    req = db.execute("SELECT * FROM subscription_requests WHERE id = ?", (rid,)).fetchone()
    if not req or req["status"] != "pending" or action not in ("confirm", "reject"):
        abort(404)
    if action == "confirm":
        billing.confirm_request(db, req)
        msg = f"تم تأكيد الطلب {req['ref_code']} وتفعيل الباقة"
    else:
        db.execute("UPDATE subscription_requests SET status = 'rejected', decided_at = ?, note = ? WHERE id = ?", (time.time(), request.form.get("note", "").strip()[:200], rid))
        db.commit()
        msg = f"تم رفض الطلب {req['ref_code']}"
    return redirect(url_for("admin.dashboard", msg=msg))


@bp.get("/requests/<int:rid>/receipt")
@admin_required
def receipt(rid):
    req = current_app.db.execute("SELECT receipt FROM subscription_requests WHERE id = ?", (rid,)).fetchone()
    if not req or not req["receipt"]:
        abort(404)
    return send_file(current_app.cfg.upload_dir / req["receipt"], download_name=req["receipt"])
