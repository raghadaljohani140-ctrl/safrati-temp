(function () {
  const file = document.getElementById('lesson-file');
  const form = document.querySelector('.upload-form');
  if (file) {
    file.addEventListener('change', () => {
      const f = file.files[0];
      if (!f) return;
      const max = Number(form.dataset.maxMb) * 1024 * 1024;
      document.getElementById('drop-name').textContent = f.name;
      if (f.size > max) { alert('الملف كبير، الحد الأقصى ' + form.dataset.maxMb + ' ميجابايت'); file.value = ''; document.getElementById('drop-name').textContent = 'اختاري ملف الدرس من جهازك'; }
    });
    form.addEventListener('submit', () => { const b = document.getElementById('upload-btn'); b.disabled = true; b.textContent = 'جارٍ الرفع…'; });
  }
  document.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', async () => {
    if (!confirm(b.dataset.ask)) return;
    try { await api('DELETE', b.dataset.del); location.reload(); } catch (e) { alert(e.message); }
  }));
  const consent = document.getElementById('ai-consent');
  if (consent) consent.addEventListener('change', async () => { try { await api('POST', '/api/me/consent', {ai_consent: consent.checked}); } catch (e) { alert(e.message); } });
  const del = document.getElementById('del-account');
  if (del) del.addEventListener('submit', async ev => {
    ev.preventDefault();
    if (!confirm('سيُحذف حسابك وكل ما فيه نهائيًا. متأكدة؟')) return;
    try { await api('POST', '/api/me/delete', {password: del.password.value}); location.href = '/'; }
    catch (e) { const n = document.getElementById('del-err'); n.textContent = e.message; n.hidden = false; }
  });
})();
