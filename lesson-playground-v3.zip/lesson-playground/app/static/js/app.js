// shared helpers: fetch with the form-check token
window.api = async function (method, url, data) {
  const token = document.querySelector('meta[name=csrf]').content;
  const res = await fetch(url, {method, headers: {'Content-Type': 'application/json', 'X-CSRF': token}, body: data === undefined ? undefined : JSON.stringify(data), credentials: 'same-origin'});
  let json = {};
  try { json = await res.json(); } catch (e) {}
  if (!res.ok) { const err = new Error(json.error || 'حدث خطأ، حاولي مرة أخرى'); err.status = res.status; throw err; }
  return json;
};
window.el = function (tag, attrs, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === 'class') n.className = v; else if (k === 'text') n.textContent = v; else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
    else if (v === true) n.setAttribute(k, ''); else if (v !== false && v != null) n.setAttribute(k, v);
  }
  for (const kid of kids.flat()) if (kid != null) n.append(kid.nodeType ? kid : document.createTextNode(kid));
  return n;
};
