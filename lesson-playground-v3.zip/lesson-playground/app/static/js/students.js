(function () {
  const rows = document.getElementById('rows'), tbl = document.getElementById('tbl'), empty = document.getElementById('empty'), count = document.getElementById('count');
  const detail = document.getElementById('detail'); let openId = null;
  const fmt = t => new Date(t * 1000).toLocaleDateString('ar-SA', {day: 'numeric', month: 'short'});

  async function load() {
    const {students} = await api('GET', '/api/students');
    rows.replaceChildren(); tbl.hidden = !students.length; empty.hidden = !!students.length; count.textContent = students.length ? '(' + students.length + ')' : '';
    students.forEach(s => rows.append(row(s)));
    if (openId && !students.some(s => s.id === openId)) { openId = null; detail.hidden = true; }
  }
  function row(s) {
    const tr = el('tr'); const name = el('input', {value: s.name, maxlength: 60, 'aria-label': 'اسم الطالب', class: 'cell-in'});
    const saved = el('span', {class: 'saved'});
    name.addEventListener('change', async () => {
      try { await api('PATCH', '/api/students/' + s.id, {name: name.value}); saved.textContent = 'تم الحفظ ✓'; setTimeout(() => load(), 600); }
      catch (e) { saved.textContent = e.message; name.value = s.name; }
    });
    const show = el('button', {class: 'btn ghost small', type: 'button', text: 'النتائج'}); show.addEventListener('click', () => openDetail(s.id));
    const del = el('button', {class: 'btn ghost small danger', type: 'button', text: 'حذف'});
    del.addEventListener('click', async () => { if (!confirm('حذف ' + s.name + ' ونتائجه؟')) return; await api('DELETE', '/api/students/' + s.id); load(); });
    tr.append(el('td', {}, name, saved), el('td', {text: s.answered}), el('td', {text: s.correct}), el('td', {text: s.percent == null ? '—' : s.percent + '%'}),
      el('td', {}, s.level ? el('span', {class: 'lvl l' + (s.percent >= 85 ? 'a' : s.percent >= 65 ? 'b' : 'c'), text: s.level}) : '—'), el('td', {class: 'acts'}, show, del));
    return tr;
  }
  async function openDetail(id) {
    openId = id; const d = await api('GET', '/api/students/' + id + '/results');
    document.getElementById('d-name').textContent = 'نتائج ' + d.name;
    const decks = document.getElementById('d-decks'); decks.replaceChildren();
    if (!d.decks.length) decks.append(el('tr', {}, el('td', {colspan: 4, class: 'muted', text: 'لا توجد نتائج بعد. اختاري هذا الطالب أثناء العرض.'})));
    d.decks.forEach(x => decks.append(el('tr', {}, el('td', {text: x.title}), el('td', {text: x.answered}), el('td', {text: x.correct}), el('td', {text: x.percent + '%'}))));
    const list = document.getElementById('d-recent'); list.replaceChildren();
    d.recent.forEach(x => list.append(el('li', {}, el('b', {text: x.correct ? '✔ ' : '✘ '}), x.question, el('small', {class: 'muted', text: ' · ' + x.deck + ' · ' + fmt(x.at)}))));
    detail.hidden = false; detail.scrollIntoView({behavior: 'smooth', block: 'nearest'});
  }
  document.getElementById('d-clear').addEventListener('click', async () => {
    if (!openId || !confirm('مسح كل نتائج هذا الطالب؟ لا يمكن التراجع.')) return;
    await api('DELETE', '/api/students/' + openId + '/results'); await load(); openDetail(openId);
  });
  document.getElementById('add-students').addEventListener('submit', async e => {
    e.preventDefault(); const err = document.getElementById('add-err'); err.hidden = true;
    const names = document.getElementById('names').value.split('\n').map(x => x.trim()).filter(Boolean);
    try { await api('POST', '/api/students', {names}); document.getElementById('names').value = ''; load(); }
    catch (x) { err.textContent = x.message; err.hidden = false; }
  });
  load().catch(e => { empty.hidden = false; empty.textContent = e.message; });
})();
