(function () {
  const stage = document.getElementById('stage');
  const deckId = stage.dataset.deck;
  const view = document.getElementById('view');
  const board = document.getElementById('scoreboard');
  const KEY = 'lp-deck-' + deckId;
  const KIND = {qa: 'سؤال وجواب', mcq: 'اختاري الإجابة الصحيحة', tf: 'صح أم خطأ؟', cloze: 'أكملي الفراغ', short: 'سؤال قصير', review: 'سؤال مراجعة'};
  const COLORS = ['#ffb400', '#ff5d6c', '#7a6cf0', '#2f8cff', '#2fb36b', '#ff7ab8', '#0e7c86', '#f26b21'];
  let deck, S, students = [];

  function fresh() { return {teams: [{name: 'الفريق الأول', pts: 0}, {name: 'الفريق الثاني', pts: 0}], turn: 0, used: {}, screen: null, board: false, student: null, marks: {}, run: Math.random().toString(36).slice(2, 12), round: {n: 1, done: [], absent: [], current: null}}; }
  function load() { try { return Object.assign(fresh(), JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (e) { return fresh(); } }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }
  const byId = id => deck.questions.find(q => q.id === id);
  const poolOf = game => deck.questions.filter(q => deck.game_info[game].kinds.includes(q.kind));
  const rnd = n => Math.floor(Math.random() * n);
  const fair = n => { try { const a = new Uint32Array(1); crypto.getRandomValues(a); return a[0] % n; } catch (e) { return rnd(n); } };
  const usedOf = game => (S.used[game] = S.used[game] || []);
  const unused = game => poolOf(game).filter(q => !usedOf(game).includes(q.id));

  // ----- a question card with its own reveal behaviour -----
  function questionCard(q, game, onRevealed) {
    const card = el('div', {class: 'qcard'});
    const out = el('div'); const ctrl = el('div', {class: 'ctrl'});
    let revealed = false, picked = null;
    const text = el('p', {class: 'qtext'});
    const blank = () => el('span', {class: 'blank' + (revealed ? ' filled' : ''), text: revealed ? q.answer : '      '});
    function paint() {
      text.replaceChildren();
      if (q.kind === 'cloze') { const parts = q.question.split('_____'); parts.forEach((p, i) => { text.append(p); if (i < parts.length - 1) text.append(blank()); }); }
      else text.textContent = q.question;
    }
    paint();
    card.append(el('span', {class: 'kindtag', text: KIND[q.kind]}), text);
    const optBtns = [];
    if (q.kind === 'mcq') {
      const box = el('div', {class: 'opts'});
      q.options.forEach(o => { const b = el('button', {class: 'opt', type: 'button', text: o}); b.addEventListener('click', () => { if (!revealed) { picked = o === q.answer; b.classList.add(o === q.answer ? 'right' : 'wrong'); reveal(); } }); optBtns.push(b); box.append(b); });
      card.append(box);
    }
    if (q.kind === 'tf') {
      const box = el('div', {class: 'tfbtns'});
      ['صح', 'خطأ'].forEach(o => { const b = el('button', {class: 'opt', type: 'button', text: o === 'صح' ? '✔ صح' : '✘ خطأ'}); b.dataset.v = o; b.addEventListener('click', () => { if (!revealed) { picked = o === q.answer; b.classList.add(o === q.answer ? 'right' : 'wrong'); reveal(); } }); optBtns.push(b); box.append(b); });
      card.append(box);
    }
    card.append(out, ctrl);
    const revealBtn = el('button', {class: 'btn big sun', type: 'button', text: 'اكشفي الإجابة'});
    function reveal() {
      if (revealed) return; revealed = true; S.screen && (S.screen.revealed = true); save();
      optBtns.forEach(b => { if ((q.kind === 'mcq' && b.textContent === q.answer) || (q.kind === 'tf' && b.dataset.v === q.answer)) b.classList.add('right'); b.disabled = true; });
      paint(); revealBtn.hidden = true;
      if (q.kind !== 'tf' && q.kind !== 'mcq') {
        const a = el('div', {class: 'answer' + (q.clear ? '' : ' no-clear')}, q.answer);
        out.append(a);
        if (!q.clear) a.append(el('small', {text: '⚠️ لا توجد إجابة واضحة في الملف — راجعيها'}));
      } else if (!q.clear) out.append(el('div', {class: 'answer no-clear'}, '⚠️ لا توجد إجابة واضحة في الملف — راجعيها'));
      if (q.evidence && q.kind === 'tf' && q.answer === 'خطأ') out.append(el('div', {class: 'answer'}, 'الجملة الصحيحة: ' + q.evidence));
      markRow(q, game, out, picked);
      if (onRevealed) onRevealed(ctrl);
    }
    revealBtn.addEventListener('click', reveal);
    ctrl.append(revealBtn);
    if (S.screen && S.screen.revealed) reveal();
    return card;
  }


  // ----- the student who answers, and what she scored -----
  const studentOf = game => { const id = game === 'pick' ? S.round.current : S.student; return students.find(x => x.id === id) || null; };
  async function saveResult(q, game, st, correct) {
    await api('POST', '/api/results', {student_id: st.id, deck_id: Number(deckId), question_id: q.id, game, correct, run: S.run});
    S.marks[game + ':' + q.id] = {sid: st.id, correct}; save();
  }
  function markRow(q, game, out, picked) {
    const st = studentOf(game); if (!st) return;
    const box = el('div', {class: 'marks'}); out.append(box);
    const key = game + ':' + q.id;
    const done = m => box.replaceChildren(el('p', {class: 'marked', text: (m.correct ? '✔ ' : '✘ ') + 'سُجّلت نتيجة ' + st.name + ': ' + (m.correct ? 'إجابة صحيحة' : 'إجابة غير صحيحة')}));
    if (S.marks[key] && S.marks[key].sid === st.id) return done(S.marks[key]);
    const submit = async c => { try { await saveResult(q, game, st, c); done({correct: c}); } catch (e) { box.prepend(el('p', {class: 'marked', text: 'تعذر حفظ النتيجة: ' + e.message})); } };
    if (picked !== null && (q.kind === 'mcq' || q.kind === 'tf')) return submit(picked);          // she tapped an answer: the app already knows
    const ok = el('button', {class: 'btn ok', type: 'button', text: '✔ أجاب ' + st.name + ' بشكل صحيح'}), no = el('button', {class: 'btn no', type: 'button', text: '✘ لم يُجب بشكل صحيح'});
    ok.addEventListener('click', () => submit(true)); no.addEventListener('click', () => submit(false));
    box.append(el('div', {class: 'mark'}, ok, no));
  }
  function fillPicker() {
    const sel = document.getElementById('b-student'); sel.replaceChildren(el('option', {value: '', text: 'الطالب: بدون'}));
    students.forEach(x => sel.append(el('option', {value: x.id, text: x.name})));
    sel.value = S.student && students.some(x => x.id === S.student) ? S.student : '';
    sel.addEventListener('change', () => { S.student = sel.value ? Number(sel.value) : null; save(); });
  }

  // ----- sound (off until the teacher turns it on) -----
  let ac = null;
  const soundOn = () => { try { return localStorage.getItem('lp-sound') === '1'; } catch (e) { return false; } };
  function beep(freq, dur, vol, type) {
    if (!soundOn()) return;
    try {
      ac = ac || new (window.AudioContext || window.webkitAudioContext)(); if (ac.state === 'suspended') ac.resume();
      const o = ac.createOscillator(), g = ac.createGain(), t = ac.currentTime;
      o.type = type || 'triangle'; o.frequency.value = freq; g.gain.setValueAtTime(vol || .06, t); g.gain.exponentialRampToValueAtTime(.0001, t + dur);
      o.connect(g); g.connect(ac.destination); o.start(t); o.stop(t + dur);
    } catch (e) {}
  }
  const fanfare = () => [523, 659, 784, 1047].forEach((f, i) => setTimeout(() => beep(f, .35, .09, 'sine'), i * 140));

  // ----- the students' wheel: everyone gets a turn before anyone gets a second one -----
  const present = () => students.filter(x => !S.round.absent.includes(x.id));
  const remaining = () => present().filter(x => !S.round.done.includes(x.id));
  function rosterPanel(redraw) {
    const box = el('details', {class: 'roster'}); box.open = true;
    const here = present(), done = here.filter(x => S.round.done.includes(x.id)), left = remaining(), gone = students.filter(x => S.round.absent.includes(x.id));
    box.append(el('summary', {text: 'شارك ' + done.length + ' من ' + here.length + ' · الجولة ' + S.round.n}));
    const chips = (list, cls, tip, fn) => el('div', {class: 'chips'}, list.map(x => { const c = el('button', {class: 'chip ' + cls, type: 'button', title: tip, text: (cls === 'done' ? '✓ ' : '') + x.name}); if (fn) c.addEventListener('click', () => fn(x)); return c; }));
    const toggle = x => { const a = S.round.absent; const i = a.indexOf(x.id); if (i < 0) a.push(x.id); else a.splice(i, 1); save(); redraw(); };
    box.append(el('b', {text: 'لم يشاركوا (' + left.length + ') — اضغطي على اسم لاستبعاده كغائب'}), chips(left, '', 'استبعاد كغائب', toggle));
    box.append(el('b', {text: 'شاركوا (' + done.length + ')'}), chips(done, 'done', 'شارك في هذه الجولة'));
    if (gone.length) box.append(el('b', {text: 'مستبعدون (' + gone.length + ') — اضغطي لإعادتهم'}), chips(gone, 'gone', 'إعادته للعجلة', toggle));
    const again = el('button', {class: 'btn ghost small', type: 'button', text: '↻ إعادة الجولة'}), zero = el('button', {class: 'btn ghost small', type: 'button', text: '⟲ تصفير المشاركات'});
    again.addEventListener('click', () => { S.round.done = []; S.round.current = null; S.screen && (S.screen.qid = null); save(); pickFlow(false); });
    zero.addEventListener('click', () => { if (!confirm('تصفير المشاركات والغياب والبدء من الجولة الأولى؟ نتائج الطلاب المسجلة لا تُمسح.')) return; S.round = {n: 1, done: [], absent: [], current: null}; S.screen && (S.screen.qid = null); save(); pickFlow(false); });
    box.append(el('div', {class: 'row'}, again, zero));
    return box;
  }
  function soundBtn() {
    const b = el('button', {class: 'btn ghost small snd', type: 'button'}); const paint = () => { b.textContent = soundOn() ? '🔊 الصوت مفتوح' : '🔇 الصوت مغلق'; };
    b.addEventListener('click', () => { try { localStorage.setItem('lp-sound', soundOn() ? '0' : '1'); } catch (e) {} paint(); beep(660, .15, .08); }); paint(); return b;
  }
  function pickFlow(first) {
    if (first && S.round.current && S.screen.qid && byId(S.screen.qid) && students.some(x => x.id === S.round.current)) return pickShow(byId(S.screen.qid));
    S.round.current = null; S.screen = {game: 'pick', qid: null, revealed: false}; save(); pickWheel();
  }
  function pickWheel() {
    drawBoard();
    if (!students.length) {
      return view.replaceChildren(el('div', {class: 'qcard center'}, el('h2', {text: 'لا توجد أسماء طلاب بعد 👥'}), el('p', {class: 'qtext', text: 'أضيفي أسماء طلابك أولًا ثم عودي لعجلة الطلاب.'}),
        el('div', {class: 'ctrl'}, el('a', {class: 'btn big sun', href: '/students', target: '_blank', rel: 'noopener', text: 'إدارة الطلاب'}), el('button', {class: 'btn big ghost', type: 'button', text: 'الألعاب', onclick: menu}))));
    }
    let note = '';
    if (!present().length) {
      return view.replaceChildren(el('div', {class: 'qcard center'}, el('h2', {text: 'كل الطلاب مستبعدون'}), rosterPanel(pickWheel)));
    }
    if (!remaining().length) { S.round.n++; S.round.done = []; save(); note = 'شارك جميع الطلاب 🎉 بدأت الجولة ' + S.round.n + ' بترتيب جديد'; }
    const pool = remaining().slice();
    for (let i = pool.length - 1; i > 0; i--) { const j = fair(i + 1); [pool[i], pool[j]] = [pool[j], pool[i]]; }          // a new random order every time
    const n = pool.length, arc = 2 * Math.PI / n, size = 760, R = size / 2;
    const c = el('canvas', {width: size, height: size, 'aria-label': 'عجلة الطلاب'}); const g = c.getContext('2d');
    const fontPx = Math.max(10, Math.min(40, (2 * Math.PI * R * .6 / n) * .7));
    pool.forEach((st, i) => {
      g.beginPath(); g.moveTo(R, R); g.arc(R, R, R - 6, -Math.PI / 2 + i * arc, -Math.PI / 2 + (i + 1) * arc); g.closePath();
      g.fillStyle = COLORS[i % COLORS.length]; g.fill(); if (n < 90) { g.lineWidth = 3; g.strokeStyle = '#fff'; g.stroke(); }
      g.save(); g.translate(R, R); g.rotate(-Math.PI / 2 + (i + .5) * arc); g.textAlign = 'right'; g.textBaseline = 'middle'; g.direction = 'rtl'; g.fillStyle = '#fff';
      g.font = '800 ' + fontPx + 'px Tajawal, Tahoma, sans-serif'; let name = st.name; const maxW = R - 90;
      while (g.measureText(name).width > maxW && name.length > 3) name = name.slice(0, -2);
      g.fillText(name === st.name ? name : name + '…', R - 40, 0); g.restore();
    });
    g.beginPath(); g.arc(R, R, 46, 0, 2 * Math.PI); g.fillStyle = '#fff'; g.fill();
    const box = el('div', {class: 'wheel-wrap'}); const w = el('div', {class: 'wheel'}, c, el('span', {class: 'pointer', text: '▼'}));
    const spin = el('button', {class: 'btn big sun', type: 'button', text: 'تدوير العجلة 🎡'});
    if (note) box.append(el('p', {class: 'picked', text: note}));
    box.append(el('p', {class: 'progress', text: 'على العجلة ' + n + ' طالبًا لم يشاركوا بعد'}), w, el('div', {class: 'ctrl'}, spin, soundBtn()));
    view.replaceChildren(box, rosterPanel(pickWheel));
    c.style.transform = 'rotate(' + rot + 'deg)';
    spin.addEventListener('click', () => {
      spin.disabled = true; const k = fair(n); const offset = (Math.random() * .7 - .35) * (360 / n); const seg = 360 / n;
      rot += 360 * 6 + ((-(k + .5) * seg + offset) % 360 + 360) % 360 - (rot % 360);
      c.style.transform = 'rotate(' + rot + 'deg)';
      let last = -1, raf; const watch = () => {
        const m = getComputedStyle(c).transform; if (m && m !== 'none') { const v = m.match(/matrix\(([^)]+)\)/); if (v) { const [a, b] = v[1].split(',').map(Number); const ang = (Math.atan2(b, a) * 180 / Math.PI + 360) % 360; const idx = Math.floor((((360 - ang) % 360)) / seg); if (idx !== last) { if (last !== -1) beep(880, .04, .05, 'square'); last = idx; } } }
        raf = requestAnimationFrame(watch);
      };
      if (soundOn()) watch();
      let done = false; const fin = () => { if (done) return; done = true; cancelAnimationFrame(raf); pickLand(pool[k]); };
      c.addEventListener('transitionend', fin, {once: true}); setTimeout(fin, 4800);
    });
  }
  function pickLand(st) {
    if (!S.round.done.includes(st.id)) S.round.done.push(st.id);
    S.round.current = st.id;
    let left = unused('pick'); if (!left.length) { S.used.pick = []; left = unused('pick'); }
    const q = left[fair(left.length)]; if (!q) return finished('pick');
    usedOf('pick').push(q.id); S.screen = {game: 'pick', qid: q.id, revealed: false}; save(); fanfare(); pickShow(q);
  }
  function pickShow(q) {
    const st = studentOf('pick'); const here = present();
    const next = el('button', {class: 'btn big', type: 'button', text: 'الطالب التالي 🎡'}); next.addEventListener('click', () => pickFlow(false));
    const card = questionCard(q, 'pick', ctrl => ctrl.append(next));
    view.replaceChildren(el('p', {class: 'picked'}, el('small', {text: 'دور الطالب'}), st ? st.name : ''), el('p', {class: 'progress', text: 'شارك ' + S.round.done.filter(id => here.some(x => x.id === id)).length + ' من ' + here.length + ' · الجولة ' + S.round.n}), card, rosterPanel(() => pickShow(q)));
    drawBoard();
  }

  // ----- scoreboard (two teams) -----
  function drawBoard() {
    board.hidden = !S.board; board.replaceChildren();
    S.teams.forEach((t, i) => {
      const name = el('input', {class: 'tname', value: t.name, 'aria-label': 'اسم الفريق'});
      name.addEventListener('input', () => { t.name = name.value; save(); });
      const plus = el('button', {type: 'button', text: '+', 'aria-label': 'زيادة نقطة'}); const minus = el('button', {type: 'button', text: '−', 'aria-label': 'إنقاص نقطة'});
      const pts = el('span', {class: 'pts', text: t.pts});
      plus.addEventListener('click', () => { t.pts++; pts.textContent = t.pts; save(); });
      minus.addEventListener('click', () => { t.pts = Math.max(0, t.pts - 1); pts.textContent = t.pts; save(); });
      board.append(el('div', {class: 'team ' + (i ? 'b' : 'a') + (S.screen && S.screen.game === 'teams' && S.turn === i ? ' turn' : '')}, name, minus, pts, plus));
    });
  }
  function awardRow(next) {
    const row = el('div', {class: 'award'});
    S.teams.forEach((t, i) => { const b = el('button', {class: 'btn' + (i ? ' b' : ''), type: 'button', text: '+1 ' + t.name}); b.addEventListener('click', () => { t.pts++; row.querySelectorAll('button').forEach(x => x.disabled = true); drawBoard(); save(); }); row.append(b); });
    return row;
  }

  // ----- screens -----
  function menu() {
    S.screen = null; save(); drawBoard();
    const m = el('div', {class: 'menu'});
    deck.games.forEach(g => {
      const info = deck.game_info[g]; const n = poolOf(g).length;
      const b = el('button', {class: 'tile-btn g-' + g, type: 'button'}, el('span', {class: 'ico', text: info.icon}), info.name, el('small', {text: n + ' سؤالًا · ' + info.hint}));
      b.addEventListener('click', () => start(g)); m.append(b);
    });
    view.replaceChildren(el('h2', {text: 'اختاري لعبة'}), m);
  }
  function start(game) { S.screen = {game, qid: null, revealed: false}; if (game === 'teams' && !S.board) S.board = true; save(); drawBoard(); next(true); }

  function finished(game) {
    const box = el('div', {class: 'qcard center'}, el('h2', {text: 'انتهت أسئلة هذه اللعبة 🎉'}));
    if (game === 'teams') {
      const [a, b] = S.teams; box.append(el('p', {class: 'qtext', text: a.pts === b.pts ? 'تعادل! ' + a.pts + ' لكل فريق' : (a.pts > b.pts ? a : b).name + ' يفوز! 🏆'}));
    }
    const again = el('button', {class: 'btn big sun', type: 'button', text: 'إعادة الأسئلة'});
    again.addEventListener('click', () => { S.used[game] = []; save(); next(true); });
    const home = el('button', {class: 'btn big ghost', type: 'button', text: 'الألعاب'}); home.addEventListener('click', menu);
    box.append(el('div', {class: 'ctrl'}, again, home)); view.replaceChildren(box);
  }

  function showQ(game, q, extra) {
    S.screen = {game, qid: q.id, revealed: S.screen && S.screen.qid === q.id ? S.screen.revealed : false}; save();
    const parts = [];
    const total = poolOf(game).length;
    parts.push(el('p', {class: 'progress', text: (game === 'teams' ? 'دور ' + S.teams[S.turn].name + ' · ' : '') + 'السؤال ' + Math.min(usedOf(game).length, total) + ' من ' + total}));
    parts.push(questionCard(q, game, ctrl => {
      if (S.board) ctrl.before(awardRow());
      ctrl.append(nextBtn(game));
    }));
    if (extra) parts.push(extra);
    view.replaceChildren(...parts); drawBoard();
  }
  function nextBtn(game) {
    const label = game === 'wheel' ? 'ادوري العجلة 🎡' : game === 'random' ? 'سؤال عشوائي آخر 🎲' : 'السؤال التالي ➜';
    const b = el('button', {class: 'btn big', type: 'button', text: label}); b.addEventListener('click', () => { if (game === 'teams') S.turn = 1 - S.turn; next(false); }); return b;
  }

  function next(first) {
    const game = S.screen && S.screen.game; if (!game) return menu();
    if (!first || !S.screen.qid) S.screen.revealed = false;
    if (game === 'pick') return pickFlow(first);
    if (first && S.screen.qid && byId(S.screen.qid)) { const q = byId(S.screen.qid); return game === 'wheel' ? wheel(game, q) : showQ(game, q); }
    const left = unused(game); if (!left.length) return finished(game);
    if (game === 'wheel') return wheel(game, null);
    let q;
    if (game === 'random' || game === 'teams') q = left[rnd(left.length)]; else q = left[0];
    usedOf(game).push(q.id); S.screen.qid = q.id; save(); showQ(game, q);
  }

  // ----- the wheel -----
  let rot = 0;
  function wheel(game, shown) {
    const left = unused(game); const pickable = shown ? left.concat([shown]) : left;
    if (!pickable.length) return finished(game);
    const segs = pickable.slice().sort(() => Math.random() - .5).slice(0, 12);
    if (shown && !segs.includes(shown)) segs[0] = shown;
    const size = 560, c = el('canvas', {width: size, height: size, 'aria-label': 'عجلة الحظ'}); const g = c.getContext('2d'); const n = segs.length, arc = 2 * Math.PI / n;
    segs.forEach((q, i) => {
      g.beginPath(); g.moveTo(size / 2, size / 2); g.arc(size / 2, size / 2, size / 2 - 6, -Math.PI / 2 + i * arc, -Math.PI / 2 + (i + 1) * arc); g.closePath();
      g.fillStyle = COLORS[i % COLORS.length]; g.fill(); g.lineWidth = 4; g.strokeStyle = '#fff'; g.stroke();
      g.save(); g.translate(size / 2, size / 2); g.rotate(-Math.PI / 2 + (i + .5) * arc); g.textAlign = 'right'; g.fillStyle = '#fff'; g.font = '800 44px Tajawal, Tahoma, sans-serif'; g.fillText(String(i + 1), size / 2 - 40, 15); g.restore();
    });
    g.beginPath(); g.arc(size / 2, size / 2, 44, 0, 2 * Math.PI); g.fillStyle = '#fff'; g.fill();
    const box = el('div', {class: 'wheel-wrap'}); const w = el('div', {class: 'wheel'}, c, el('span', {class: 'pointer', text: '▼'}));
    const spin = el('button', {class: 'btn big sun', type: 'button', text: 'ادوري العجلة 🎡'});
    box.append(el('p', {class: 'progress', text: 'المتبقي ' + left.length + ' سؤالًا'}), w, spin);
    const result = el('div'); box.append(result); view.replaceChildren(box);
    c.style.transform = 'rotate(' + rot + 'deg)';
    function land(k) {
      const q = segs[k]; if (!usedOf(game).includes(q.id)) usedOf(game).push(q.id); S.screen = {game, qid: q.id, revealed: false}; save();
      result.replaceChildren(el('p', {class: 'progress', text: 'استقرت العجلة على السؤال رقم ' + (k + 1)}), questionCard(q, game, ctl => { if (S.board) ctl.before(awardRow()); const again = el('button', {class: 'btn big', type: 'button', text: 'ادوري مرة أخرى 🎡'}); again.addEventListener('click', () => { S.screen.qid = null; next(false); }); ctl.append(again); }));
      spin.hidden = true; w.hidden = true; box.firstChild.hidden = true;
    }
    if (shown) { land(segs.indexOf(shown)); return; }
    spin.addEventListener('click', () => {
      spin.disabled = true; const k = rnd(n); const offset = (Math.random() * .7 - .35) * (360 / n);
      rot += 360 * 5 + ((-(k + .5) * (360 / n) + offset) % 360 + 360) % 360 - (rot % 360);
      c.style.transform = 'rotate(' + rot + 'deg)';
      let done = false; const fin = () => { if (!done) { done = true; land(k); } };
      c.addEventListener('transitionend', fin, {once: true}); setTimeout(fin, 4600);
    });
  }

  // ----- bar buttons -----
  document.getElementById('b-menu').addEventListener('click', menu);
  document.getElementById('b-exit').addEventListener('click', () => { if (document.fullscreenElement) document.exitFullscreen(); location.href = '/dashboard'; });
  document.getElementById('b-score').addEventListener('click', () => { S.board = !S.board; save(); drawBoard(); });
  const pause = document.getElementById('pause');
  document.getElementById('b-pause').addEventListener('click', () => { pause.hidden = false; document.getElementById('b-resume').focus(); });
  document.getElementById('b-resume').addEventListener('click', () => { pause.hidden = true; });
  const fsBtn = document.getElementById('b-full');
  const root = document.documentElement;
  if (!(root.requestFullscreen || root.webkitRequestFullscreen)) fsBtn.hidden = true;
  fsBtn.addEventListener('click', () => {
    if (document.fullscreenElement || document.webkitFullscreenElement) (document.exitFullscreen || document.webkitExitFullscreen).call(document);
    else (root.requestFullscreen || root.webkitRequestFullscreen).call(root);
  });
  document.addEventListener('fullscreenchange', () => { fsBtn.textContent = document.fullscreenElement ? '⛶ خروج من ملء الشاشة' : '⛶ ملء الشاشة'; });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && !pause.hidden) pause.hidden = true; });

  Promise.all([api('GET', '/api/decks/' + deckId + '/data'), api('GET', '/api/students').catch(() => ({students: []}))]).then(([d, st]) => {
    deck = d; S = load(); students = st.students || [];
    S.used = S.used || {}; if (!deck.games.includes('pick') && deck.game_info.pick) deck.games.push('pick');
    fillPicker();
    if (S.screen && S.screen.game && deck.games.includes(S.screen.game)) next(true); else menu();
    drawBoard();
  }).catch(e => { view.textContent = e.message; });
})();
