(function () {
  const root = document.getElementById('lesson-app');
  const lid = root.dataset.id;
  const $ = id => document.getElementById(id);
  const KIND = {qa: 'سؤال وجواب', mcq: 'اختيار من متعدد', tf: 'صح أو خطأ', cloze: 'أكمل الفراغ', short: 'سؤال قصير', review: 'سؤال مراجعة'};
  let questions = [];
  const selected = new Set();
  const timers = {};

  function flashSaved(text) { const s = $('saved'); s.textContent = text; clearTimeout(flashSaved.t); flashSaved.t = setTimeout(() => s.textContent = '', 2500); }

  async function poll() {
    try {
      const st = await api('GET', '/api/lessons/' + lid);
      if (st.status === 'processing') { show('processing'); setTimeout(poll, 1200); return; }
      if (st.status === 'failed') { $('failed-msg').textContent = st.error; show('failed'); return; }
      await load(st);
    } catch (e) { setTimeout(poll, 3000); }
  }
  function show(which) { for (const id of ['processing', 'failed', 'ready']) $(id).hidden = id !== which; }

  async function load(st) {
    questions = (await api('GET', '/api/lessons/' + lid + '/questions')).questions;
    selected.clear();
    questions.forEach(q => { if (q.clear) selected.add(q.id); });
    { const bits = []; if (st.subject) bits.push('المادة ' + st.subject); if (st.grade) bits.push('الصف ' + st.grade); const info = $('lesson-info'); info.hidden = !bits.length; if (bits.length) info.textContent = 'بيانات الدرس (لا تظهر في الأسئلة): ' + bits.join(' · '); }
    $('engine-note').textContent = st.engine === 'offline'
      ? 'تم إعداد الأسئلة داخل الموقع (مجانًا) من جمل ملفكِ مباشرة. راجعيها وعدّلي ما يلزم.'
      : 'تم إعداد الأسئلة بقارئ ذكي. راجعيها وعدّلي ما يلزم.';
    const en = $('empty-note'); en.hidden = !st.error; en.textContent = st.error;
    show('ready'); render();
  }

  function render() {
    const list = $('qlist'); list.replaceChildren();
    questions.forEach((q, i) => list.append(card(q, i)));
    $('qcount').textContent = '(' + questions.length + ' سؤالًا، المحدد ' + selected.size + ')';
    refreshGames();
  }

  function save(q, patch, card) {
    Object.assign(q, patch);
    clearTimeout(timers[q.id]);
    flashSaved('جارٍ الحفظ…');
    timers[q.id] = setTimeout(async () => {
      try {
        const r = await api('PATCH', '/api/questions/' + q.id, {kind: q.kind, question: q.question, answer: q.answer, options: q.options, evidence: q.evidence});
        q.clear = r.question.clear;
        card.classList.toggle('unclear', !q.clear);
        card.querySelector('.warn').hidden = q.clear;
        flashSaved('تم الحفظ تلقائيًا ✓');
        card.querySelector('.err').hidden = true;
      } catch (e) { const er = card.querySelector('.err'); er.textContent = e.message; er.hidden = false; flashSaved(''); }
    }, 700);
  }

  function card(q, idx) {
    const c = el('div', {class: 'q k-' + q.kind + (q.clear ? '' : ' unclear')});
    const use = el('input', {type: 'checkbox', 'aria-label': 'استخدام هذا السؤال', checked: selected.has(q.id)});
    use.addEventListener('change', () => { use.checked ? selected.add(q.id) : selected.delete(q.id); $('qcount').textContent = '(' + questions.length + ' سؤالًا، المحدد ' + selected.size + ')'; refreshGames(); });
    const del = el('button', {class: 'btn ghost small', type: 'button', text: 'حذف'});
    del.addEventListener('click', async () => {
      if (!confirm('حذف هذا السؤال؟')) return;
      await api('DELETE', '/api/questions/' + q.id); questions = questions.filter(x => x.id !== q.id); selected.delete(q.id); render();
    });
    c.append(el('div', {class: 'q-head'}, use, el('span', {class: 'q-kind', text: KIND[q.kind]}), el('span', {class: 'spacer'}), del));
    const qt = el('textarea', {rows: 2, 'aria-label': 'السؤال'}); qt.value = q.question;
    qt.addEventListener('input', () => save(q, {question: qt.value}, c));
    c.append(qt);
    if (q.kind === 'mcq') {
      const box = el('div');
      const draw = () => {
        box.replaceChildren();
        q.options.forEach((o, i) => {
          const r = el('input', {type: 'radio', name: 'right' + q.id, 'aria-label': 'الإجابة الصحيحة', checked: o === q.answer});
          const t = el('input', {value: o, 'aria-label': 'خيار'});
          r.addEventListener('change', () => save(q, {answer: q.options[i]}, c));
          t.addEventListener('input', () => { const wasRight = q.options[i] === q.answer; q.options[i] = t.value; save(q, wasRight ? {answer: t.value, options: q.options} : {options: q.options}, c); });
          box.append(el('div', {class: 'opt-row'}, r, t));
        });
      };
      draw(); c.append(box);
    } else if (q.kind === 'tf') {
      const sel = el('select', {'aria-label': 'الإجابة'}, el('option', {value: 'صح', text: 'الإجابة: صح'}), el('option', {value: 'خطأ', text: 'الإجابة: خطأ'}));
      sel.value = q.answer; sel.addEventListener('change', () => save(q, {answer: sel.value}, c)); c.append(sel);
    } else {
      const at = el('textarea', {rows: 2, 'aria-label': 'الإجابة'}); at.value = q.answer;
      at.addEventListener('input', () => save(q, {answer: at.value}, c)); c.append(at);
    }
    c.append(el('p', {class: 'warn', text: '⚠️ ' + root.dataset.unclear + ' — راجعي الإجابة قبل استخدامها', hidden: q.clear}));
    c.append(el('p', {class: 'err note bad', hidden: true}));
    if (q.evidence) c.append(el('div', {class: 'ev', text: 'من ملفكِ: «' + q.evidence + '»'}));
    return c;
  }

  function refreshGames() {
    document.querySelectorAll('#games .game').forEach(g => {
      const cb = g.querySelector('input'); const kinds = cb.dataset.kinds.split(',');
      const n = questions.filter(q => selected.has(q.id) && kinds.includes(q.kind)).length;
      g.querySelector('.g-n').textContent = n ? n + ' سؤالًا مناسبًا' : 'لا أسئلة مناسبة';
      g.classList.toggle('off', !n); if (!n) cb.checked = false; cb.disabled = !n;
    });
  }

  $('all-on').addEventListener('click', () => { questions.forEach(q => selected.add(q.id)); render(); });
  $('all-off').addEventListener('click', () => { selected.clear(); render(); });
  $('regen').addEventListener('click', async () => {
    if (!confirm('سنعيد توليد الأسئلة التلقائية (أسئلتك التي عدّلتِها أو أضفتِها تبقى). متابعة؟')) return;
    await api('POST', '/api/lessons/' + lid + '/regenerate'); show('processing'); poll();
  });
  const title = $('lesson-title'); let tt;
  title.addEventListener('input', () => { clearTimeout(tt); tt = setTimeout(async () => { try { await api('PATCH', '/api/lessons/' + lid, {title: title.value}); flashSaved('تم الحفظ تلقائيًا ✓'); } catch (e) { flashSaved(e.message); } }, 700); });

  const addForm = $('add-form');
  addForm.kind.addEventListener('change', () => { addForm.querySelector('.opts-in').hidden = addForm.kind.value !== 'mcq'; });
  addForm.addEventListener('submit', async ev => {
    ev.preventDefault(); const err = $('add-err'); err.hidden = true;
    const f = addForm; const data = {kind: f.kind.value, question: f.question.value, answer: f.answer.value, evidence: f.evidence.value};
    if (f.kind.value === 'mcq') data.options = f.options.value.split('\n');
    try { const r = await api('POST', '/api/lessons/' + lid + '/questions', data); questions.push(r.question); selected.add(r.question.id); f.reset(); f.querySelector('.opts-in').hidden = true; render(); }
    catch (e) { err.textContent = e.message; err.hidden = false; }
  });

  $('make-deck').addEventListener('click', async () => {
    const err = $('make-err'); err.hidden = true;
    const games = [...document.querySelectorAll('#games input:checked')].map(i => i.value);
    try { const r = await api('POST', '/api/lessons/' + lid + '/decks', {title: $('deck-title').value, games, question_ids: [...selected]}); location.href = r.url; }
    catch (e) { err.textContent = e.message; err.hidden = false; }
  });

  poll();
})();
