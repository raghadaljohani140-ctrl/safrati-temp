from flask import Flask, g, render_template, request, session

from . import db as dbm
from .config import Config
from .security import csrf_token


def create_app(**over):
    cfg = Config(**over)
    app = Flask(__name__)
    app.config.update(SECRET_KEY=cfg.secret, MAX_CONTENT_LENGTH=(cfg.max_upload_mb + 1) * 1024 * 1024, SESSION_COOKIE_HTTPONLY=True,
                      SESSION_COOKIE_SAMESITE="Lax", SESSION_COOKIE_SECURE=cfg.cookie_secure, JSON_AS_ASCII=False, TEMPLATES_AUTO_RELOAD=False)
    app.cfg = cfg
    app.db = dbm.connect(cfg.db_path)
    dbm.init(app.db)

    from .auth import bp as auth_bp
    from .lessons import bp as lessons_bp
    from .api import bp as api_bp
    app.register_blueprint(auth_bp)
    app.register_blueprint(lessons_bp)
    app.register_blueprint(api_bp)
    from .subscribe import bp as subscribe_bp
    from .admin import bp as admin_bp
    from .students import bp as students_bp
    app.register_blueprint(students_bp)
    app.register_blueprint(subscribe_bp)
    app.register_blueprint(admin_bp)

    @app.before_request
    def load_user():
        uid = session.get("uid")
        g.user = app.db.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone() if uid else None
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            from .security import check_csrf
            check_csrf()

    @app.after_request
    def headers(resp):
        resp.headers["Content-Security-Policy"] = ("default-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; "
                                                    "img-src 'self' data:; script-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Referrer-Policy"] = "same-origin"
        if request.path.startswith(("/api/", "/lessons", "/dashboard", "/present", "/subscribe", "/admin", "/students")):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.context_processor
    def inject():
        return {"csrf": csrf_token(), "user": g.get("user")}

    @app.errorhandler(403)
    def e403(e):
        return render_template("error.html", code=403, msg="انتهت صلاحية الصفحة، حدّثي الصفحة وأعيدي المحاولة"), 403

    @app.errorhandler(404)
    def e404(e):
        return render_template("error.html", code=404, msg="الصفحة غير موجودة"), 404

    @app.errorhandler(413)
    def e413(e):
        return render_template("error.html", code=413, msg=f"الملف كبير، الحد الأقصى {cfg.max_upload_mb} ميجابايت"), 413

    return app
