"""Making the questions. Two providers behind one door:
 * `offline` (the default, free): reads the file's sentences with plain rules and builds the questions from them. No key, no cost, nothing leaves the server.
 * `claude` (paid, OFF until the owner approves a key): sends the file's text to the Anthropic API with strict instructions to use the file only.
Whatever the provider, every question is checked by `grounding.verify`; an answer that is not in the file is never shown as sure."""
import json
import random
import re
import urllib.request

from . import grounding as G, meta as lesson_meta

KINDS = ("qa", "mcq", "tf", "cloze", "short", "review")
KIND_NAMES = {"qa": "سؤال وجواب", "mcq": "اختيار من متعدد", "tf": "صح أو خطأ", "cloze": "أكمل الفراغ", "short": "سؤال قصير", "review": "سؤال مراجعة"}
BLANK = "_____"
WORD = re.compile(r"[ء-يً-ْ٠-٩A-Za-z0-9]+")
STOP = set("""في من على الى إلى عن مع هذا هذه ذلك تلك هو هي هم هن كان كانت يكون تكون التي الذي الذين اللذان ان أن إن إذا اذا ثم او أو لا لم لن قد كل بعض غير بين عند عندما حتى لكن
كما ايضا أيضا هناك بعد قبل خلال منذ حيث اي أي ما ماذا كيف لماذا اين أين متى فقط جدا جدًا وهو وهي وهم يمكن يتم تم ولا وقد وان وإن بها به له لها لهم منها منه فيها فيه عليها عليه
إلا الا بل عنه عنها اذ إذ مثل نحو دون سوى لدى لذلك ولذلك وكان وكانت اما أما انه إنه انها إنها هنا هنالك""".split())
DEF_CUES = r"(?:هو|هي|هم|هما|تعني|يعني|تعرّف بأنها|تعرف بأنها|يعرّف بأنه|يعرف بأنه|تسمى|يسمى|تُسمى|يُسمى|عبارة عن|تُعدّ|تعد|يُعدّ|يعد)"
DEF_RE = re.compile(rf"^(?P<term>[^،,:؛.]{{2,40}}?)\s+{DEF_CUES}\s+(?P<def>.{{12,}})$")
COLON_RE = re.compile(r"^(?P<term>[^:،,.]{2,30}):\s*(?P<def>.{12,})$")
CAUSE_RE = re.compile(r"\s(لأن|لان|بسبب|نتيجة|لكي|حتى|مما يؤدي إلى|ويؤدي إلى|يؤدي إلى|ولذلك|لذلك)\s")


def split_sentences(text: str) -> list[str]:
    out = []
    for block in re.split(r"\n+", text):
        block = re.sub(r"^[\s•\-–—*·●▪◦\d\)\.\(]+(?=\S)", "", block).strip() if re.match(r"^\s*[•\-–—*·●▪◦]|\s*\d+[\)\.]\s", block) else block.strip()
        for s in re.split(r"(?<=[.!؟?؛])\s+", block):
            s = s.strip()
            n = len(WORD.findall(s))
            if 5 <= n <= 45:
                out.append(s.rstrip("."))
    seen, uniq = set(), []
    for s in out:
        k = G.norm(s)
        if k not in seen:
            seen.add(k)
            uniq.append(s)
    return uniq


def _noun_like(word: str) -> bool:
    n = G.norm(word)
    return n.startswith("ال") and len(n) >= 5 and not n.startswith(("الذي", "التي", "الذين"))


def _same_root(a: str, b: str) -> bool:
    a, b = G.norm(a), G.norm(b)
    a, b = (a[2:] if a.startswith("ال") else a), (b[2:] if b.startswith("ال") else b)
    return a[:3] == b[:3]


def _candidates(sentence: str, freq: dict) -> list[str]:
    cands = []
    for w in WORD.findall(sentence):
        n = G.norm(w)
        if len(n) >= 4 and n not in STOP and not n.isdigit() and w not in cands:
            cands.append(w)
    nums = [w for w in WORD.findall(sentence) if w.isdigit() or all(c in "٠١٢٣٤٥٦٧٨٩" for c in w)]
    cands.sort(key=lambda w: (not _noun_like(w), -freq.get(G.norm(w), 0), -len(w)))
    return nums[:1] + cands


def _blank_out(sentence: str, answer: str) -> str:
    return re.sub(rf"(?<![ء-ي\w]){re.escape(answer)}(?![ء-ي\w])", BLANK, sentence, count=1)


class OfflineProvider:
    name = "offline"

    def generate(self, text: str, total: int = 24, rng=None) -> list[dict]:
        rng = rng or random.Random(7)
        sents = split_sentences(text)
        freq: dict = {}
        for w in G.words(text):
            if w not in STOP:
                freq[w] = freq.get(w, 0) + 1
        pool = [w for w, c in sorted(freq.items(), key=lambda kv: -kv[1]) if _noun_like(w)]
        questions: dict[str, list] = {k: [] for k in KINDS}

        for s in sents:
            m = DEF_RE.match(s) or COLON_RE.match(s)
            if m and len(m["term"].split()) <= 4:
                term, definition = m["term"].strip(), m["def"].strip()
                questions["qa"].append(dict(kind="qa", question=f"ما المقصود بـ «{term}»؟", answer=definition, evidence=s))
                questions["review"].append(dict(kind="review", question=f"اذكري ما تعرفينه عن «{term}»", answer=definition, evidence=s))

        usable = []
        for s in sents:
            cands = _candidates(s, freq)
            if cands:
                usable.append((s, cands[0]))
        for s, ans in usable:
            blanked = _blank_out(s, ans)
            if blanked != s:
                questions["cloze"].append(dict(kind="cloze", question=blanked, answer=ans, evidence=s))
                others = [w for w in pool if w not in G.norm(s).split() and not _same_root(w, ans)]
                same = [w for w in others if abs(len(w) - len(G.norm(ans))) <= 3] or others
                if len(set(same)) >= 3:
                    pick = rng.sample(sorted(set(same)), 3)
                    originals = {G.norm(w): w for w in WORD.findall(text)}
                    opts = [originals.get(p, p) for p in pick] + [ans]
                    rng.shuffle(opts)
                    questions["mcq"].append(dict(kind="mcq", question=blanked, answer=ans, options=opts, evidence=s))
            flip = len(questions["tf"]) % 2 == 1
            if flip:
                others = [w for w in pool if w not in G.norm(s).split() and not _same_root(w, ans)]
                if others and _noun_like(ans):
                    originals = {G.norm(w): w for w in WORD.findall(text)}
                    wrong = originals.get(rng.choice(others[:25]), None)
                    if wrong and wrong != ans:
                        false_s = _blank_out(s, ans).replace(BLANK, wrong)
                        if false_s != s:
                            questions["tf"].append(dict(kind="tf", question=false_s, answer="خطأ", evidence=s))
                            continue
            questions["tf"].append(dict(kind="tf", question=s, answer="صح", evidence=s))
        for s in sents:
            m = CAUSE_RE.search(s)
            if m and len(s[:m.start()].split()) >= 3 and len(s[m.end():].split()) >= 2:
                questions["short"].append(dict(kind="short", question=f"{s[:m.start()].strip()} … ؟ (أكملي الجملة)", answer=(m.group(1) + " " + s[m.end():]).strip(), evidence=s))
        if len(questions["short"]) < 3:
            for s in sents:
                words = s.split()
                if len(words) >= 9:
                    cut = len(words) // 2
                    questions["short"].append(dict(kind="short", question=" ".join(words[:cut]) + " … ؟ (أكملي الجملة)", answer=" ".join(words[cut:]), evidence=s))
                if len(questions["short"]) >= 6:
                    break
        if len(questions["review"]) < 2:
            blocks = [b for b in re.split(r"\n\s*\n", text) if len(b.split()) > 8]
            for b in blocks[:6]:
                head = b.strip().splitlines()[0].strip().rstrip(":")
                body = split_sentences(b)
                if body and 1 <= len(head.split()) <= 8 and G.norm(head) != G.norm(body[0]):
                    questions["review"].append(dict(kind="review", question=f"راجعي: ما أهم ما ورد عن «{head}»؟", answer=body[0], evidence=body[0]))

        text_norm = G.norm(text)
        per = max(2, total // len(KINDS))
        out = []
        for kind in KINDS:
            good, seen = [], set()
            for q in questions[kind]:
                key = (G.norm(q["evidence"]), q["kind"])
                if key not in seen and G.verify(q, text_norm):
                    seen.add(key)
                    good.append(q)
            rng.shuffle(good) if kind in ("tf", "cloze", "mcq") else None
            out.extend(good[:per])
        return out


class ClaudeProvider:
    """The paid provider. Never used unless the owner set AI_PROVIDER=claude AND a key AND the teacher agreed (see lessons.py)."""
    name = "claude"
    URL = "https://api.anthropic.com/v1/messages"
    RULES = ("أنتِ مساعدة تعد أسئلة من ملف درس. استخدمي نص الملف فقط ولا تضيفي أي معلومة من خارجه ولا تخترعي إجابة. "
             "لكل سؤال اكتبي في الحقل evidence اقتباسًا حرفيًا من النص يدعم الإجابة. إن لم تجدي إجابة واضحة في النص فاكتبي answer = \"" + G.UNCLEAR + "\". "
             "أعيدي JSON فقط: قائمة عناصر {kind, question, answer, options, evidence}. kind من: qa, mcq, tf, cloze, short, review. "
             "في tf يكون answer \"صح\" أو \"خطأ\". في mcq ضعي 4 خيارات في options أحدها الإجابة. في cloze ضعي ـــــ مكان الكلمة.")

    def __init__(self, key, model, transport=None):
        self.key, self.model, self.transport = key, model, transport or self._post
        self.last_usage = None

    def _post(self, payload: dict) -> dict:
        req = urllib.request.Request(self.URL, data=json.dumps(payload).encode(), method="POST",
                                     headers={"x-api-key": self.key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
        with urllib.request.urlopen(req, timeout=120) as r:       # noqa: S310 (fixed https address)
            return json.loads(r.read().decode())

    def generate(self, text: str, total: int = 24, rng=None) -> list[dict]:
        payload = {"model": self.model, "max_tokens": 6000, "system": self.RULES,
                   "messages": [{"role": "user", "content": f"أعدي نحو {total} سؤالًا متنوعًا من هذا الدرس:\n\n{text[:60000]}"}]}
        reply = self.transport(payload)
        u = reply.get("usage") or {}
        self.last_usage = {"input": int(u.get("input_tokens", 0)), "output": int(u.get("output_tokens", 0))}          # counted even if the answer turns out unusable
        raw = "".join(b.get("text", "") for b in reply.get("content", []))
        m = re.search(r"\[.*\]", raw, re.S)
        items = json.loads(m.group(0)) if m else []
        return [i for i in items if isinstance(i, dict) and i.get("kind") in KINDS]


def provider_for(config, teacher_agreed: bool):
    """The paid provider only when everything is switched on; otherwise the free offline one."""
    if config.ai_provider == "claude" and config.anthropic_key and teacher_agreed:
        return ClaudeProvider(config.anthropic_key, config.anthropic_model)
    return OfflineProvider()


def clean_items(items, text: str, strict: bool) -> list[dict]:
    """Normalise what a provider returned and mark each question `clear` (backed by the file) or not."""
    text_norm = G.norm(text)
    out = []
    for it in items:
        q = {"kind": it["kind"], "question": str(it.get("question", "")).strip()[:600], "answer": str(it.get("answer", "")).strip()[:600],
             "evidence": str(it.get("evidence", "")).strip()[:800],
             "options": [str(o).strip()[:200] for o in (it.get("options") or [])][:6]}
        if lesson_meta.mentions(q["question"]):
            q["question"] = lesson_meta.strip_mentions(q["question"])
        if len(q["question"]) < 6 or lesson_meta.mentions(q["question"]):
            continue
        if any(lesson_meta.mentions(x) for x in [q["answer"], q["evidence"], *q["options"]]):          # the subject or the class must never be an answer or an option
            continue
        if q["kind"] == "mcq" and (len(q["options"]) < 2 or q["answer"] not in q["options"]):
            continue
        q["clear"] = int(G.verify(q, text_norm, strict=strict))
        if not q["clear"] and not q["answer"]:
            q["answer"] = G.UNCLEAR
        out.append(q)
    return out


def make_questions(config, text: str, ai_allowed: bool, total: int = 24):
    """(provider name, questions, usage). `usage` is {"model", "input", "output"} when the paid reader was really called (so it can be counted), else None."""
    prov = provider_for(config, ai_allowed)
    usage = None
    try:
        items = prov.generate(text, total)
        strict = prov.name == "offline"
    except Exception:
        used = getattr(prov, "last_usage", None)
        if used:
            usage = {"model": prov.model, **used}
        prov = OfflineProvider()
        return prov.name, clean_items(prov.generate(text, total), text, True), usage
    if prov.name == "claude" and prov.last_usage:
        usage = {"model": prov.model, **prov.last_usage}
    if prov.name == "claude" and not items:                    # the paid reader gave nothing usable: the free one still serves her
        return "offline", clean_items(OfflineProvider().generate(text, total), text, True), usage
    return prov.name, clean_items(items, text, strict), usage
