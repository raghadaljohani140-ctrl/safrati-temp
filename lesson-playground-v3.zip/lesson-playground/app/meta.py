"""The subject and the class are facts about the lesson, not part of it. They are read from the file's header and kept as lesson details; they never go into a question, an option or an answer."""
import re

_NUM = r"(?:الأول|الاول|الثاني|الثالث|الرابع|الخامس|السادس|السابع|الثامن|التاسع|العاشر|الحادي عشر|الثاني عشر|الأولى|الثانية|الثالثة|الرابعة|الخامسة|السادسة)"
_STAGE = r"(?:الابتدائي|الابتدائية|المتوسط|المتوسطة|الثانوي|الثانوية|الإعدادي|الاعدادي|الإعدادية)"
GRADE = re.compile(rf"(?:(?:ل?ل?صف|صف)\s+{_NUM}(?:\s+{_STAGE})?|{_NUM}\s+{_STAGE}|المرحلة\s+{_STAGE})")
_LABEL = r"(?:المادة|الصف|المرحلة|الفصل الدراسي|العام الدراسي|المسار)"
_STOP = rf"(?:{_LABEL}|(?:الوحدة|الدرس|الموضوع|الفصل|المعلمة|المعلم|المدرسة|التاريخ|الحصة|اسم المعلمة|اسم المعلم)(?:\s+\S+){{0,2}})"
FIELD = re.compile(rf"(?P<label>{_LABEL})\s*[:：]\s*(?P<val>[^\n:：]{{1,60}}?)(?=\s+{_STOP}\s*[:：]|\s*\n|\s*$)")
# "في مادة العلوم للصف الثالث الثانوي،" at the start of a sentence, and the same inside one
_CLASS = rf"ل?ل?صف\s+{_NUM}(?:\s+{_STAGE})?"
_LEAD = re.compile(rf"^\s*(?:في|ضمن|من)?\s*(?:مادة|منهج|مقرر)\s+(?:\S+(?:\s+\S+)?\s+{_CLASS}|\S+\s+{_CLASS}|\S+)\s*[،,:\-–—]*\s*")
_INLINE = re.compile(rf"\s*(?:(?:في|ضمن|من|ل|لدى|لطلاب|لطالبات|لطلبة)\s*)?{_CLASS}|\s*(?:في|ضمن)\s+مادة\s+\S+")


def split_header(text: str):
    """(text without the subject / class lines, {"subject", "grade"})."""
    found = {}
    for m in FIELD.finditer(text):
        label, val = m.group("label"), m.group("val").strip(" .،-–—")
        key = "subject" if label == "المادة" else "grade" if label in ("الصف", "المرحلة") else None
        if key and val and not (key in found and label == "المرحلة"):
            found.setdefault(key, val)
    text = FIELD.sub(" ", text)
    kept = []
    for line in text.split("\n"):
        stripped = GRADE.sub("", line).strip(" :،.-–—()")
        if line.strip() and len(line) <= 70 and not stripped and GRADE.search(line):       # a line that is only a class name
            found.setdefault("grade", line.strip())
            continue
        kept.append(re.sub(r"[ \t]{2,}", " ", line).strip())
    return re.sub(r"\n{3,}", "\n\n", "\n".join(kept)).strip(), found


def mentions(s: str) -> bool:
    """True when a piece of a question still names the subject or the class."""
    return bool(GRADE.search(s) or FIELD.search(s + "\n") or re.search(r"(?:^|\s)(?:في|ضمن)?\s*مادة\s+\S+", s) or re.search(rf"(?:^|\s)(?:المادة|الصف)\s*[:：]", s))


def strip_mentions(s: str) -> str:
    """The sentence without a lead-in such as «في مادة العلوم للصف الثالث الثانوي،»."""
    s = _LEAD.sub("", s)
    s = _INLINE.sub("", s)
    return re.sub(r"\s{2,}", " ", s).strip(" ،,:-–—")
