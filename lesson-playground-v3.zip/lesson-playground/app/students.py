"""The teacher's own list of students (names she types herself) and how each one did in the questions she asked them. No student accounts: this is her notebook."""
from flask import Blueprint, abort, current_app, g, jsonify, render_template, request

from .db import jload, now
from .lessons import mine
from .security import login_required

bp = Blueprint("students", __name__)
MAX_STUDENTS = 300
LEVELS = ((85, "ممتاز"), (65, "جيد"), (0, "يحتاج إلى دعم"))


def body() -> dict:
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}


def toint(v) -> int:
    try:
        return int(v)
    except (TypeError, ValueError):
        return 0


def level(pct):
    return None if pct is None else next(name for floor, name in LEVELS if pct >= floor)


def student_row(sid):
    row = current_app.db.execute("SELECT * FROM students WHERE id = ? AND user_id = ?", (sid, g.user["id"])).fetchone()
    if not row:
        abort(404)                      # another teacher's student looks exactly like one that does not exist
    return row


def clean_name(value) -> str:
    return " ".join(str(value or "").split())[:60]


def listing():
    rows = current_app.db.execute("""SELECT s.id, s.name, COUNT(r.id) AS answered, COALESCE(SUM(r.correct), 0) AS correct
                                     FROM students s LEFT JOIN results r ON r.student_id = s.id WHERE s.user_id = ? GROUP BY s.id ORDER BY s.name""", (g.user["id"],)).fetchall()
    out = []
    for r in rows:
        pct = round(100 * r["correct"] / r["answered"]) if r["answered"] else None
        out.append({"id": r["id"], "name": r["name"], "answered": r["answered"], "correct": r["correct"], "percent": pct, "level": level(pct)})
    return out


@bp.get("/students")
@login_required
def page():
    return render_template("students.html")


@bp.get("/api/students")
@login_required
def students():
    return jsonify(students=listing())


@bp.post("/api/students")
@login_required
def add():
    d = body()
    names = d.get("names") if isinstance(d.get("names"), list) else [d.get("name")]
    db = current_app.db
    have = db.execute("SELECT COUNT(*) FROM students WHERE user_id = ?", (g.user["id"],)).fetchone()[0]
    added = skipped = 0
    for raw in names:
        name = clean_name(raw)
        if len(name) < 2:
            skipped += 1
            continue
        if have + added >= MAX_STUDENTS:
            return jsonify(error=f"الحد الأقصى {MAX_STUDENTS} طالبًا"), 400
        try:
            db.execute("INSERT INTO students(user_id, name, created_at) VALUES (?,?,?)", (g.user["id"], name, now()))
            added += 1
        except Exception:
            skipped += 1                # the same name twice
    db.commit()
    if not added:
        return jsonify(error="اكتبي اسمًا جديدًا (حرفان على الأقل ولا يتكرر)"), 400
    return jsonify(added=added, skipped=skipped, students=listing()), 201


@bp.patch("/api/students/<int:sid>")
@login_required
def rename(sid):
    student_row(sid)
    name = clean_name(body().get("name"))
    if len(name) < 2:
        return jsonify(error="اكتبي اسمًا صحيحًا"), 400
    try:
        current_app.db.execute("UPDATE students SET name = ? WHERE id = ?", (name, sid))
        current_app.db.commit()
    except Exception:
        return jsonify(error="يوجد طالب بهذا الاسم"), 409
    return jsonify(saved=True)


@bp.delete("/api/students/<int:sid>")
@login_required
def remove(sid):
    student_row(sid)
    current_app.db.execute("DELETE FROM students WHERE id = ?", (sid,))          # his results go with him
    current_app.db.commit()
    return jsonify(ok=True)


@bp.post("/api/results")
@login_required
def record():
    d = body()
    db = current_app.db
    student = student_row(toint(d.get("student_id")))
    deck = mine("decks", toint(d.get("deck_id")))
    qid = toint(d.get("question_id"))
    if qid not in jload(deck["question_ids"], []):
        return jsonify(error="السؤال ليس من هذا العرض"), 400
    q = db.execute("SELECT kind, question FROM questions WHERE id = ? AND user_id = ?", (qid, g.user["id"])).fetchone()
    if not q:
        return jsonify(error="السؤال غير موجود"), 404
    run = str(d.get("run", ""))[:40]
    correct = 1 if d.get("correct") in (True, 1, "1") else 0
    db.execute("""INSERT INTO results(user_id, student_id, deck_id, deck_title, question_id, question, game, kind, correct, run, created_at)
                  VALUES (?,?,?,?,?,?,?,?,?,?,?)
                  ON CONFLICT(student_id, deck_id, question_id, run) DO UPDATE SET correct = excluded.correct, game = excluded.game, created_at = excluded.created_at""",
               (g.user["id"], student["id"], deck["id"], deck["title"], qid, q["question"][:200], str(d.get("game", ""))[:20], q["kind"], correct, run, now()))
    db.commit()
    return jsonify(ok=True)


@bp.get("/api/students/<int:sid>/results")
@login_required
def results(sid):
    s = student_row(sid)
    db = current_app.db
    decks = db.execute("""SELECT deck_title, COUNT(*) AS answered, SUM(correct) AS correct, MAX(created_at) AS last FROM results WHERE student_id = ?
                          GROUP BY COALESCE(deck_id, deck_title) ORDER BY last DESC""", (sid,)).fetchall()
    recent = db.execute("SELECT deck_title, question, correct, created_at FROM results WHERE student_id = ? ORDER BY created_at DESC, id DESC LIMIT 40", (sid,)).fetchall()
    return jsonify(name=s["name"], decks=[{"title": r["deck_title"], "answered": r["answered"], "correct": r["correct"], "percent": round(100 * r["correct"] / r["answered"]), "last": r["last"]} for r in decks],
                   recent=[{"deck": r["deck_title"], "question": r["question"], "correct": bool(r["correct"]), "at": r["created_at"]} for r in recent])


@bp.delete("/api/students/<int:sid>/results")
@login_required
def clear_results(sid):
    student_row(sid)
    current_app.db.execute("DELETE FROM results WHERE student_id = ?", (sid,))
    current_app.db.commit()
    return jsonify(ok=True)
