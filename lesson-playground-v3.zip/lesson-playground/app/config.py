"""Settings of the app. Everything comes from the environment; nothing is shared with any other project."""
import os
import secrets
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent


class Config:
    def __init__(self, **over):
        self.instance = Path(over.get("INSTANCE") or os.environ.get("INSTANCE_DIR") or BASE / "instance")
        self.instance.mkdir(parents=True, exist_ok=True)
        self.db_path = self.instance / "app.db"
        self.upload_dir = self.instance / "uploads"
        self.upload_dir.mkdir(exist_ok=True)
        self.max_upload_mb = int(over.get("MAX_UPLOAD_MB") or os.environ.get("MAX_UPLOAD_MB") or 15)
        self.cookie_secure = str(over.get("COOKIE_SECURE", os.environ.get("COOKIE_SECURE", "0"))) == "1"
        self.ai_provider = over.get("AI_PROVIDER") or os.environ.get("AI_PROVIDER") or "offline"
        self.anthropic_key = over.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_API_KEY") or ""
        self.anthropic_model = over.get("ANTHROPIC_MODEL") or os.environ.get("ANTHROPIC_MODEL") or "claude-haiku-5-5"
        self.background = over.get("BACKGROUND", True)          # tests turn the worker thread off
        self.secret = over.get("SECRET_KEY") or os.environ.get("SECRET_KEY") or self._secret()

    def _secret(self) -> str:
        path = self.instance / "secret.key"
        if not path.exists():
            path.write_text(secrets.token_hex(32))
            path.chmod(0o600)
        return path.read_text().strip()
