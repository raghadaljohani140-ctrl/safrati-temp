"""Plans, limits, the subscription by bank transfer, the monthly AI allowance and the money the manager watches.
Money is in halalas (100 = 1 riyal). Prices include VAT. Nothing is charged by the app: the teacher pays by bank transfer and the manager confirms."""
import math
import time
from datetime import datetime, timedelta, timezone

from . import db as dbm

RIYADH = timezone(timedelta(hours=3))
USD_SAR = 3.75
VAT = 0.15
PRICE_USD = {"claude-haiku-5-5": (0.10, 0.50), "claude-sonnet-5-5": (2.0, 10.0), "claude-opus-5-5": (4.0, 20.0)}
UNKNOWN_PRICE = (4.0, 20.0)          # an unknown model is costed like the dearest one, so a cap never under-counts
DAYS = {"month": 30, "year": 365}
RENEW_WARN_DAYS = 7
DEFAULT_AI_CAP_SAR = 50
DEFAULT_FIXED_SAR = 40


def cost_halalas(model: str, input_tokens: int, output_tokens: int) -> int:
    pin, pout = PRICE_USD.get(model, UNKNOWN_PRICE)
    return math.ceil((input_tokens * pin + output_tokens * pout) / 1_000_000 * USD_SAR * 100)


def month_start(ts: float) -> float:
    d = datetime.fromtimestamp(ts, RIYADH)
    return d.replace(day=1, hour=0, minute=0, second=0, microsecond=0).timestamp()


def effective_code(user, now=None) -> str:
    """The plan the teacher really has today: a paid plan whose time is over is the free plan again (her lessons stay)."""
    now = now or time.time()
    if user["plan_code"] != "free" and user["plan_expires"] and user["plan_expires"] < now:
        return "free"
    return user["plan_code"]


def plan_of(conn, user, now=None):
    return conn.execute("SELECT * FROM plans WHERE code = ?", (effective_code(user, now),)).fetchone()


def usage(conn, user_id):
    lessons = conn.execute("SELECT COUNT(*) FROM lessons WHERE user_id = ?", (user_id,)).fetchone()[0]
    decks = conn.execute("SELECT COUNT(*) FROM decks WHERE user_id = ?", (user_id,)).fetchone()[0]
    return lessons, decks


def can_add_lesson(conn, user) -> bool:
    return usage(conn, user["id"])[0] < plan_of(conn, user)["max_lessons"]


def can_add_deck(conn, user) -> bool:
    return usage(conn, user["id"])[1] < plan_of(conn, user)["max_decks"]


# ---- the AI allowance ----
def ai_used(conn, user_id, now=None) -> int:
    start = month_start(now or time.time())
    return conn.execute("SELECT COUNT(*) FROM ai_usage WHERE user_id = ? AND created_at >= ?", (user_id, start)).fetchone()[0]


def ai_cost_month(conn, now=None) -> int:
    start = month_start(now or time.time())
    return conn.execute("SELECT COALESCE(SUM(cost), 0) FROM ai_usage WHERE created_at >= ?", (start,)).fetchone()[0]


def ai_cap_halalas(conn) -> int:
    try:
        return int(float(dbm.setting(conn, "ai_cap_sar", DEFAULT_AI_CAP_SAR)) * 100)
    except ValueError:
        return DEFAULT_AI_CAP_SAR * 100


def ai_allowed(conn, user, now=None) -> bool:
    """The paid reader may be used for this teacher now: her plan has an allowance left this month AND the whole site is under the monthly cost cap."""
    now = now or time.time()
    quota = plan_of(conn, user, now)["ai_quota"]
    return quota > 0 and ai_used(conn, user["id"], now) < quota and ai_cost_month(conn, now) < ai_cap_halalas(conn)


def log_ai(conn, user_id, lesson_id, model, tokens_in, tokens_out, now=None):
    conn.execute("INSERT INTO ai_usage(user_id, lesson_id, model, input_tokens, output_tokens, cost, created_at) VALUES (?,?,?,?,?,?,?)",
                 (user_id, lesson_id, model, tokens_in, tokens_out, cost_halalas(model, tokens_in, tokens_out), now or time.time()))
    conn.commit()


# ---- subscriptions ----
def price_of(plan, period) -> int:
    return plan["price_month"] if period == "month" else plan["price_year"]


def period_of(plan_code) -> str:
    return "year" if plan_code == "yearly" else "month"


def confirm_request(conn, req, now=None):
    """The manager saw the transfer: the plan starts today (or after the days she still has of the same plan, so renewing early loses nothing)."""
    now = now or time.time()
    user = conn.execute("SELECT * FROM users WHERE id = ?", (req["user_id"],)).fetchone()
    base = max(now, user["plan_expires"]) if user["plan_code"] == req["plan_code"] and user["plan_expires"] > now else now
    ends = base + DAYS[req["period"]] * 86400
    conn.execute("UPDATE users SET plan_code = ?, plan_expires = ? WHERE id = ?", (req["plan_code"], ends, user["id"]))
    conn.execute("UPDATE subscription_requests SET status = 'confirmed', decided_at = ?, starts_at = ?, ends_at = ? WHERE id = ?", (now, base, ends, req["id"]))
    conn.commit()
    return ends


def days_left(user, now=None):
    now = now or time.time()
    if user["plan_code"] == "free" or not user["plan_expires"]:
        return None
    return math.ceil((user["plan_expires"] - now) / 86400)


# ---- what the manager sees ----
def finance(conn, now=None) -> dict:
    now = now or time.time()
    start = month_start(now)
    gross = conn.execute("SELECT COALESCE(SUM(amount), 0) FROM subscription_requests WHERE status = 'confirmed' AND decided_at >= ?", (start,)).fetchone()[0]
    vat_on = dbm.setting(conn, "vat_registered", "0") == "1"
    vat = round(gross - gross / (1 + VAT)) if vat_on else 0
    ai = ai_cost_month(conn, now)
    try:
        fixed = int(float(dbm.setting(conn, "fixed_sar", DEFAULT_FIXED_SAR)) * 100)
    except ValueError:
        fixed = DEFAULT_FIXED_SAR * 100
    subs = conn.execute("SELECT COUNT(*) FROM users WHERE plan_code != 'free' AND plan_expires >= ?", (now,)).fetchone()[0]
    soon = conn.execute("SELECT COUNT(*) FROM users WHERE plan_code != 'free' AND plan_expires BETWEEN ? AND ?", (now, now + RENEW_WARN_DAYS * 86400)).fetchone()[0]
    return {"gross": gross, "vat": vat, "ai": ai, "fixed": fixed, "net": gross - vat - ai - fixed, "subs": subs, "soon": soon,
            "teachers": conn.execute("SELECT COUNT(*) FROM users WHERE is_admin = 0").fetchone()[0], "vat_on": vat_on,
            "pending": conn.execute("SELECT COUNT(*) FROM subscription_requests WHERE status = 'pending'").fetchone()[0],
            "cap": ai_cap_halalas(conn), "ai_calls": conn.execute("SELECT COUNT(*) FROM ai_usage WHERE created_at >= ?", (start,)).fetchone()[0]}


def riyals(halalas: int) -> str:
    v = halalas / 100
    return f"{v:,.2f}".rstrip("0").rstrip(".") if v != int(v) else f"{int(v):,}"
