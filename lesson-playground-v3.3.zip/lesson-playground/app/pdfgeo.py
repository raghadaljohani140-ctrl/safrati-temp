"""Reads the text of a PDF from WHERE each letter sits on the page, not from the order the file happens to write it.

PDF programs write Arabic in very different ways: letters in reading order, letters in screen order, a whole line at once, one word at a time, marks (fatha,
damma, shadda...) before or after their letter. A reader that trusts the writing order gets backwards words or scattered marks from some of them. The page
itself never lies: what a reader sees is the letters at their positions, so we sort the letters by position and then work out the reading order the way the
Unicode bidirectional rules would have laid them out (run backwards).

Needs pdfminer.six; without it `pages()` returns None and the caller uses its older reader.
"""
import io
import logging
import re
import time
import unicodedata

_MARK = re.compile("^[ً-ٰٟۖ-ۜ۟-۪ۤۧۨ-ۭ̀-ͯ]+$")
_HIDDEN = dict.fromkeys(map(ord, "​‌‍‎‏‪‫‬‭‮⁦⁧⁨⁩﻿­"))
_OPEN, _CLOSE = "([{«", ")]}»"
_END_PUNCT = ".,;:!?،؛؟"
MAX_SECONDS = 60            # a PDF that needs longer than this is read by the older, faster reader instead
SPACE_GAP = 0.15            # a gap wider than this (in letter heights) between two letters is a space
BREAK_GAP = 2.5             # ... and wider than this is a new column / table cell


class Unit:
    """One letter (with its marks) on the page."""
    __slots__ = ("t", "x0", "x1", "y", "size", "i", "mark")

    def __init__(self, t, x0, x1, y, size, i):
        self.t, self.x0, self.x1, self.y, self.size, self.i = t, x0, x1, y, size, i
        self.mark = bool(_MARK.match(t))

    @property
    def cx(self):
        return (self.x0 + self.x1) / 2


def _chars(obj, LTChar, LTContainer):
    if isinstance(obj, LTChar):
        yield obj
    elif isinstance(obj, LTContainer):
        for o in obj:
            yield from _chars(o, LTChar, LTContainer)


def _units(page, LTChar, LTContainer):
    out = []
    for c in _chars(page, LTChar, LTContainer):
        if not c.upright:
            continue                                   # sideways text is not part of a line of reading
        t = c.get_text()
        if not t or t == "\x00" or t.startswith("(cid:"):
            continue                                   # a glyph the file gives no letter for
        t = t.translate(_HIDDEN)
        if t:
            out.append(Unit(t, min(c.x0, c.x1), max(c.x0, c.x1), c.y0, c.size or c.height or 10, len(out)))
    return out


def _near(a, b):
    return abs(a.y - b.y) <= 0.8 * max(a.size, b.size) and (max(a.x0, b.x0) - min(a.x1, b.x1)) <= 0.3 * max(a.size, b.size)


def _marks_follow(units):
    """Does a letter's mark come right AFTER it in the file (True) or right BEFORE it (False)? A word never starts with a mark where marks follow
    their letter, and never ends with one where they come first, so count which of the two happens."""
    starts = ends = 0
    for k, u in enumerate(units):
        if not u.mark:
            continue
        prev = units[k - 1] if k else None
        nxt = units[k + 1] if k + 1 < len(units) else None
        if prev is None or prev.t.isspace() or not _near(prev, u):
            starts += 1
        if nxt is None or nxt.t.isspace() or not _near(u, nxt):
            ends += 1
    return ends >= starts


def _attach_marks(units):
    follow = _marks_follow(units)
    step = 1 if follow else -1
    out, n = [], len(units)
    for k, u in enumerate(units):
        if u.mark:
            continue
        marks, j = [], k + step
        while 0 <= j < n and units[j].mark:
            if abs(units[j].x0 - u.x0) <= 1.5 * u.size:
                marks.append(units[j].t)
            j += step
        c = Unit(u.t + "".join(marks), u.x0, u.x1, u.y, u.size, u.i)
        c.mark = False
        out.append(c)
    return out


def _cls(t):
    """R Arabic/Hebrew letter, L other letter, D digit, CS , . : /  ET % $  ES + -   WS space, O any other neutral."""
    for ch in t:
        if _MARK.match(ch):
            continue
        if ch.isspace():
            return "WS"
        if "0" <= ch <= "9" or "٠" <= ch <= "٩" or "۰" <= ch <= "۹":
            return "D"
        bd = unicodedata.bidirectional(ch)
        if bd in ("R", "AL"):
            return "R"
        if bd == "L":
            return "L"
        if bd in ("EN", "AN"):
            return "D"
        if bd in ("CS", "ET", "ES"):
            return bd
        return "O"
    return "O"


def logical(items, rtl):
    """items = [(class, text)] left to right as the page shows them; returns the texts in reading order."""
    n = len(items)
    cls = [c for c, _ in items]
    base = "R" if rtl else "L"
    runs, i = [], 0
    while i < n:                                       # digit runs: digits with one , . : / between two of them
        if cls[i] == "D":
            j = i
            while True:
                if j + 1 < n and cls[j + 1] == "D":
                    j += 1
                elif j + 2 < n and cls[j + 1] == "CS" and cls[j + 2] == "D":
                    j += 2
                else:
                    break
            runs.append((i, j))
            i = j + 1
        else:
            i += 1
    kind = list(cls)
    for a, b in runs:
        left = next((cls[k] for k in range(a - 1, -1, -1) if cls[k] in ("R", "L")), None)
        ascii_digits = all("0" <= items[k][1][0] <= "9" for k in range(a, b + 1) if cls[k] == "D")
        after_arabic = any(c == "R" for c in cls[b + 1:]) if rtl else left == "R"
        typ = "L" if ascii_digits and (left == "L" or (not rtl and left is None)) else "N"      # a number after Latin text belongs to it
        for k in range(a, b + 1):
            kind[k] = typ
        if typ == "L" or not after_arabic:             # % $ + - touching a number join it, unless Arabic letters came first
            for k in (a - 1, b + 1):
                if 0 <= k < n and cls[k] in ("ET", "ES") and kind[k] == cls[k]:
                    kind[k] = typ
    stack = []
    for i, (_, t) in enumerate(items):                 # a (...) holding Latin text only, after Latin text, belongs to that text
        if len(t) == 1 and t in _OPEN:
            stack.append(i)
        elif len(t) == 1 and t in _CLOSE:
            k = _CLOSE.index(t)
            for s in range(len(stack) - 1, -1, -1):
                if _OPEN.index(items[stack[s]][1]) == k:
                    o = stack[s]
                    del stack[s:]
                    inside = kind[o + 1:i]
                    left = next((kind[m] for m in range(o - 1, -1, -1) if kind[m] in ("R", "L")), base)
                    if "R" not in inside and "N" not in inside and "L" in inside and left == "L":
                        kind[o] = kind[i] = "L"
                    break
    d_of = lambda c: "R" if c in ("R", "N") else "L"

    def side(i, step):
        j = i + step
        while 0 <= j < n:
            if kind[j] in ("R", "L", "N"):
                return d_of(kind[j])
            j += step
        return base

    low = 2 if rtl else 0
    lv = []
    for i, c in enumerate(kind):
        if c == "R":
            lv.append(1)
        elif c == "L":
            lv.append(low)
        elif c == "N":
            lv.append(2)
        else:
            a, b = side(i, -1), side(i, 1)
            d = a if a == b else base
            lv.append(1 if d == "R" else low)
    idx = list(range(n))
    for k in range(1, (max(lv) if lv else 0) + 1):     # undo the reordering: reverse every run at each level, lowest odd level first
        i = 0
        while i < n:
            if lv[idx[i]] >= k:
                j = i
                while j < n and lv[idx[j]] >= k:
                    j += 1
                idx[i:j] = idx[i:j][::-1]
                i = j
            else:
                i += 1
    return [items[i][1] for i in idx]


def _unmatched(ch, o, c):
    depth = bad = 0
    for x in ch:
        if x == o:
            depth += 1
        elif x == c:
            if depth:
                depth -= 1
            else:
                bad += 1
    return bad + depth


def fix_brackets(s):
    """The page stores the bracket a reader SEES, and in right-to-left text that is the mirror of the one the author typed (some programs store the typed
    one). A kind that is unbalanced as read but balanced when swapped was stored mirrored; a lone bracket (a list marker «1)») is judged from where it
    stands: an opener has space or nothing before it and a word after it."""
    ch = list(s)
    n = len(ch)
    for o, c in zip(_OPEN, _CLOSE):
        if o in ch or c in ch:
            sw = [c if x == o else o if x == c else x for x in ch]
            if _unmatched(sw, o, c) < _unmatched(ch, o, c):
                ch = sw
    for i, c in enumerate(ch):
        if c not in _OPEN and c not in _CLOSE:
            continue
        prev = ch[i - 1] if i else " "
        nxt = ch[i + 1] if i + 1 < n else " "
        opens = (prev.isspace() or prev in _OPEN or prev == "\"") and not nxt.isspace() and nxt not in _CLOSE
        closes = not prev.isspace() and prev not in _OPEN and (nxt.isspace() or nxt in _CLOSE or nxt in _END_PUNCT)
        if opens and not closes and c in _CLOSE:
            ch[i] = _OPEN[_CLOSE.index(c)]
        elif closes and not opens and c in _OPEN:
            ch[i] = _CLOSE[_OPEN.index(c)]
    return "".join(ch)


def _tidy(s):
    s = fix_brackets(s)
    if not any("֐" <= c <= "ࣿ" for c in s):          # an English line in a right-to-left paragraph: its closing full stop sits at the far left
        m = re.match(r"^([.!?;:,]+)(.*[^\s.!?;:,])$", s)
        if m:
            s = m.group(2) + m.group(1)
    return s


def _is_arabic(ch):
    return "֐" <= ch <= "ࣿ" or "יִ" <= ch <= "﻿"


def page_text(page, LTChar, LTContainer):
    units = _attach_marks(_units(page, LTChar, LTContainer))
    if not units:
        return ""
    lines = []
    for u in sorted(units, key=lambda u: -u.y):
        for ln in lines:
            if abs(ln["y"] - u.y) <= 0.5 * min(ln["size"], u.size):
                ln["u"].append(u)
                break
        else:
            lines.append({"y": u.y, "size": u.size, "u": [u]})
    out = []
    for ln in sorted(lines, key=lambda l: -l["y"]):
        segs, cur, prev = [], [], None
        for u in sorted(ln["u"], key=lambda u: (u.cx, u.i)):
            if u.t.isspace():
                if cur and cur[-1][0] != "WS":
                    cur.append(("WS", " "))
                prev = prev or u
                continue
            if prev is not None and not prev.t.isspace():
                gap, sz = u.x0 - prev.x1, max(u.size, prev.size)
                if gap > BREAK_GAP * sz:
                    segs.append(cur)
                    cur = []
                elif gap > SPACE_GAP * sz and cur and cur[-1][0] != "WS":
                    cur.append(("WS", " "))
            cur.append((_cls(u.t), u.t))
            prev = u
        if cur:
            segs.append(cur)
        parts = []
        for seg in segs:
            txt = "".join(t for _, t in seg)
            ar = sum(1 for ch in txt if _is_arabic(ch))
            la = sum(1 for ch in txt if ch.isascii() and ch.isalpha())
            parts.append(_tidy("".join(logical(seg, ar >= la and ar > 0)).strip()))
        if len(parts) > 1 and any(_is_arabic(ch) for p in parts for ch in p):
            parts = parts[::-1]                          # the box on the right is read first
        out.extend(p for p in parts if p)
    return "\n".join(out)


def pages(data, max_pages=200):
    """The text of every page (a list of strings), or None when this reader can not be used (pdfminer missing, a damaged file, too slow)."""
    try:
        from pdfminer.converter import PDFPageAggregator
        from pdfminer.layout import LTChar, LTContainer
        from pdfminer.pdfinterp import PDFPageInterpreter, PDFResourceManager
        from pdfminer.pdfpage import PDFPage
    except ImportError:
        return None
    logging.getLogger("pdfminer").setLevel(logging.ERROR)
    started, out = time.monotonic(), []
    try:
        manager = PDFResourceManager()
        device = PDFPageAggregator(manager, laparams=None)          # no layout guessing: the letters as the file draws them, in the file's order
        interpreter = PDFPageInterpreter(manager, device)
        for page in PDFPage.get_pages(io.BytesIO(data), maxpages=max_pages, check_extractable=False):
            interpreter.process_page(page)
            out.append(unicodedata.normalize("NFKC", page_text(device.get_result(), LTChar, LTContainer)))
            if time.monotonic() - started > MAX_SECONDS:
                return None
    except Exception:
        return None
    return out
