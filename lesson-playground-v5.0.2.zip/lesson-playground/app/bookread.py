"""The shape of a school book: its units and its lessons.

The teacher gives the app a textbook (a PDF, a Word file, a PowerPoint or a picture of the contents page) and the app proposes the units and the lessons the
way a person would find them: from the table of contents when the book has one (a title, dots, a page number), else from the headings in the pages
(«الوحدة الأولى», «الدرس الثاني», «1-2 الجمع»). The text of every lesson is cut out of the pages that follow its heading, so a lesson can be made from the book
later without reading the book again.

Nothing here is final. What comes out is a proposal that the teacher sees, edits and confirms (curriculum.py); when the book gives nothing to go on, the
answer is an empty list and a sentence, never a guess dressed up as a result. No library is needed: the book arrives as lines of text.
"""
import re

from .roster import key

MAX_UNITS = 60
MAX_LESSONS = 500
MAX_TEXT = 60000            # the most text kept for one lesson
MAX_TITLE = 140

_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


def digits(s) -> str:
    return str(s).translate(_DIGITS)


# ---------------------------------------------------------------- words that mark a heading (written the way key() spells them)
_ORD_WORDS = sorted("اول اولي ثاني ثانيه ثالث ثالثه رابع رابعه خامس خامسه سادس سادسه سابع سابعه ثامن ثامنه تاسع تاسعه عاشر عاشره".split(), key=len, reverse=True)
_ORD = (r"(?:(?:ال)?(?:حادي|ثاني|ثالث|رابع|خامس|سادس|سابع|ثامن|تاسع)ه?\s+عشره?"
        r"|(?:ال)?(?:" + "|".join(_ORD_WORDS) + r")|\d{1,3})(?=\W|$)")
_UNIT_WORDS = r"(?:وحده|باب|محور|فصل(?!\s+الدراسي)|مجال|unit|chapter|module)"
_LESSON_WORDS = r"(?:درس|موضوع|lesson|topic)"
_HEAD = r"^(?P<m>(?:ال)?{words})(?![^\W\d_])\s*[\(\[]?\s*(?P<n>{ord})?\s*[\)\]]?\s*(?P<sep>[:：\-–—.،])?"
_UNIT_RE = re.compile(_HEAD.format(words=_UNIT_WORDS, ord=_ORD))
_LESSON_RE = re.compile(_HEAD.format(words=_LESSON_WORDS, ord=_ORD))
_NUMBERED = re.compile(r"^(?P<a>\d{1,2})\s*[\-–—./]\s*(?P<b>\d{1,2})(?:\s*[:：\-–—.])?\s+(?P<t>\S.*)$")
_LEADERS = "[.·…•‧∙_․‧⋯]"
_NOT_LESSONS = frozenset(key(w) for line in """مقدمه|المقدمه|مقدمه الكتاب|تقديم|كلمه وزير التعليم|كلمه الوزير|شكر وتقدير|الاهداء|اهداء|فهرس|الفهرس|المحتويات|المحتوي|محتويات الكتاب|قائمه المحتويات|جدول المحتويات|المراجع|قائمه المراجع|المصادر|الملاحق|ملحق|مسرد المصطلحات|المصطلحات|الموضوع|الموضوعات|الصفحه|رقم الصفحه|contents|index|references|preface|page|topic""".split("\n") for w in line.split("|"))
_TOC_TITLES = frozenset(key(w) for w in "فهرس|الفهرس|المحتويات|المحتوي|محتويات الكتاب|فهرس المحتويات|قائمه المحتويات|جدول المحتويات|contents|table of contents".split("|"))
_REVIEW = ("مراجعه", "تمارين عامه", "تقويم", "تقييم", "تدريبات عامه")
_EXAM = ("اختبار",)


def ck(s) -> str:
    """A spelling for comparing two headings: letters and digits only, one alef / yeh / heh, single spaces (dots, colons and page numbers' leaders vanish)."""
    return " ".join(re.findall(r"[^\W_]+", key(digits(s))))


def clean_title(s) -> str:
    s = digits(re.sub(r"\s+", " ", str(s or "").replace("‏", "").replace("‎", "")).strip())
    s = re.sub(rf"\s*{_LEADERS}{{2,}}(?=\s*[»)\]”])\s*", "", s)          # the dots that trail off a quoted saying: «…العلم...» keeps no gap before the quote
    s = re.sub(rf"\s*{_LEADERS}{{2,}}\s*", " ", s)
    return s.strip(" .:-–—·•*،")[:MAX_TITLE].strip()


def lesson_kind(title: str) -> str:
    k = ck(title)
    if k.startswith(_EXAM):
        return "exam"
    return "review" if k.startswith(_REVIEW) else "lesson"


_ADVERB = re.compile(r"^(?:اولا|ثانيا|ثالثا|رابعا|خامسا|سادسا|سابعا|ثامنا|تاسعا|عاشرا)\s*[:：\-–—]\s*\S")


def classify(line: str, strict: bool = True):
    """What a line is, as a heading: ("unit"|"lesson"|None, the unit number when the line is numbered like 2-3). In strict mode a marker word needs its number or a
    colon (a sentence that merely begins with «درس» is not a heading); loose mode is for the lines of a table of contents, which carry a page number."""
    k = key(digits(line)).strip(" -–—·•*#>\t")
    if not k or len(k) > 160:
        return None, 0
    m = _UNIT_RE.match(k)
    if m and (m.group("n") or m.group("sep") or not strict):
        return "unit", 0
    m = _LESSON_RE.match(k)
    if m and (m.group("n") or m.group("sep") or not strict):
        return "lesson", 0
    if not strict and _ADVERB.match(k):
        return "unit", 0                 # «أولًا: السنة النبوية» in a contents table opens a group, the way a unit does
    m = _NUMBERED.match(k)
    if m and re.search(r"[^\W\d_]", m.group("t")) and int(m.group("a")) <= 30 and int(m.group("b")) <= 30 and len(m.group("t").split()) <= 12:
        return "lesson", int(m.group("a"))
    return None, 0


def heading_like(line: str) -> bool:
    """A heading is a short line that does not end like a sentence."""
    s = line.strip()
    return 2 <= len(s) <= 120 and len(s.split()) <= 14 and not re.search(r"[.؟?!؛]\s*$", s) or bool(re.search(rf"{_LEADERS}{{2,}}", s))


# ---------------------------------------------------------------- the table of contents
_PAGE_END = re.compile(rf"^(?P<t>.*?\S)(?P<lead>[\s.·…•‧∙_․‧⋯\-–—|]*)(?P<n>\d{{1,4}})\s*$")
_PAGE_START = re.compile(rf"^(?P<n>\d{{1,4}})\s*{_LEADERS}{{2,}}\s*(?P<t>\S.*)$")


def split_page(line: str):
    """(title, page, sure) when the line ends (or, after dots, begins) with a page number; (None, 0, False) otherwise. «sure» is true when dots or a wide gap show it
    is a page number and not a digit that belongs to the title («الوحدة 1»)."""
    s = digits(line.strip())
    m = _PAGE_START.match(s)
    if m:
        return clean_title(m.group("t")), int(m.group("n")), True
    m = _PAGE_END.match(s)
    if not m:
        return None, 0, False
    title, lead, page = clean_title(m.group("t")), m.group("lead"), int(m.group("n"))
    if len(title) < 2 or page == 0 or not re.search(r"[^\W\d_]", title):
        return None, 0, False
    sure = bool(re.search(rf"{_LEADERS}{{2,}}|\s{{2,}}|\t|\|", lead)) or bool(re.search(rf"{_LEADERS}", lead))
    if not sure:
        k = ck(title)
        if re.search(r"(?:^|\s)(?:وحده|درس|باب|محور|فصل|موضوع|unit|lesson|chapter|topic)$", k):
            return None, 0, False          # «الوحدة 1»: the number is the unit's own
    return title, page, sure


def _dotted(line: str) -> bool:
    return bool(re.search(rf"{_LEADERS}{{3,}}|(?:\s\.){{3,}}", line))


def _toc_line(line: str):
    """(title, page) for a line of a table of contents, else None."""
    title, page, sure = split_page(line)
    if title is None:
        return None
    level, _ = classify(title, strict=False)
    if sure or level or len(title.split()) >= 2:
        return title, page
    return None


_BARE_PAGE = re.compile(r"^\d{1,4}$")


def _rows(lines, limit):
    """A contents TABLE is read cell by cell: the title on one line and, on the next, the page number that stands in the other column. Here each such pair is
    joined again, with a wide gap (the sign that the number is a page number). Returns (rows, first, last): the lines, and for each one the first and the last
    of the original lines it is made of."""
    rows, first, last, i = [], [], [], 0
    while i < limit:
        line = lines[i]
        nxt = digits(lines[i + 1].strip()) if i + 1 < len(lines) else ""
        if (_BARE_PAGE.match(nxt) and 2 <= len(line.strip()) <= 140 and not _BARE_PAGE.match(digits(line.strip())) and re.search(r"[^\W\d_]", line)
                and _toc_line(line) is None):          # a line that already ends with its page number (dots, a wide gap) is not given the number of the foot of the page
            rows.append(line.strip() + "  " + nxt)
            first.append(i)
            last.append(i + 1)
            i += 2
        else:
            rows.append(line)
            first.append(i)
            last.append(i)
            i += 1
    return rows, first, last


def _weak(title: str) -> bool:
    """A title that can not be the whole of an entry: a few words with no marker of a heading (the last piece of a title that wrapped over two lines)."""
    return len(title.split()) <= 4 and ":" not in title and not classify(title, strict=False)[0]


def _entries(rows, flags, lo, hi):
    """[(title, page)] of the flagged rows lo..hi. A table cell that wraps puts the page number (centred in its cell) after the first piece of the title: when the
    title that came with a number is only a few words and the line before it is text, that line is the beginning of the title."""
    out = []
    for x in range(lo, hi + 1):
        if not flags[x]:
            continue
        title, page = flags[x]
        before = rows[x - 1].strip() if x > lo else ""
        if before and not flags[x - 1] and len(before) >= 20 and _weak(title):
            title = clean_title(before + " " + title)
        out.append((title, page))
    return out


def find_toc(lines):
    """The lines that form the table of contents: (first, last, [(title, page)]) or None. It is the longest run of lines ending in a page number near the start of the
    book (one or two other lines in between are allowed: a wrapped title, a running header; a table that goes on over the next printed page is one run, the foot of
    the page and the head of the table between the two being a few short lines)."""
    window = min(len(lines), max(400, int(len(lines) * 0.4)))
    rows, first_of, last_of = _rows(lines, window)
    n = len(rows)
    flags = [_toc_line(r) for r in rows]
    best = None
    i = 0
    while i < n:
        if not flags[i]:
            i += 1
            continue
        j, last, gap = i, i, 0
        while j < n:
            if flags[j]:
                last, gap = j, 0
            else:
                gap += 1
                if len(rows[j]) > 90 or gap > 2:
                    ahead = next((x for x in range(j, min(j + 5, n)) if flags[x]), None)          # a long piece of a wrapped title, or the foot of a page and the head of the next
                    if ahead is None or flags[ahead][1] < flags[last][1]:
                        break
            j += 1
        entries = _entries(rows, flags, i, last)
        headings = sum(1 for t, _ in entries if classify(t, strict=False)[0])
        dotted = sum(1 for x in range(i, last + 1) if flags[x] and _dotted(rows[x]))
        pages = [pg for _, pg in entries]
        rising = sum(1 for a, b in zip(pages, pages[1:]) if b >= a) / max(1, len(pages) - 1)          # the page numbers of a contents page only go up
        joined = any(first_of[x] != last_of[x] for x in range(i, last + 1))
        dense = not joined or len(entries) >= 0.6 * (last - i + 1)          # a table gives a flagged line for nearly every line; the numbers at the foot of body pages do not
        if len(entries) >= 4 and rising >= 0.75 and dense and (headings >= 2 or dotted >= 4 or len(entries) >= 8):
            score = len(entries) + headings + dotted
            if best is None or score > best[0]:
                best = (score, first_of[i], last_of[last], entries)
        i = last + 1
    return best[1:] if best else None


# ---------------------------------------------------------------- building the structure
def _skip(title: str) -> bool:
    """The parts of a book that are not lessons (the preface, the references)."""
    return ck(title) in _NOT_LESSONS


def _flat(entries):
    """[(level, title, page, unit_no)] from [(title, page)]: a numbered scheme (1-1, 1-2, 2-1) gives the units when the book names none."""
    out = []
    for title, page in entries:
        level, no = classify(title, strict=False)
        out.append((level or "lesson", title, page, no))
    return out


def _assemble(items):
    """units = [{"title", "lessons": [...]}] from [(level, title, page, unit_no, text)]; lessons met before any unit sit in a unit without a title."""
    units, cur, numbered = [], None, {}
    named = any(level == "unit" for level, *_ in items)
    for level, title, page, no, text in items:
        if level == "unit":
            cur = {"title": title, "lessons": [], "page": page}
            units.append(cur)
            continue
        if _skip(title):
            continue
        if not named and no:
            if no not in numbered:
                numbered[no] = {"title": f"الوحدة {no}", "lessons": [], "page": page}
                units.append(numbered[no])
            cur = numbered[no]
        if cur is None:
            cur = {"title": "", "lessons": [], "page": 0}
            units.append(cur)
        cur["lessons"].append({"title": title, "kind": lesson_kind(title), "first_page": page, "last_page": 0, "text": (text or "")[:MAX_TEXT]})
    units = [u for u in units if u["lessons"] or u["title"]]
    if sum(1 for u in units if u["lessons"] and _UNIT_RE.match(key(digits(u["title"])))) >= 2:
        units = [u for u in units if u["lessons"] or not _ADVERB.match(key(u["title"]))]      # «أولًا: أهداف الدليل» in the front matter beside the real «الوحدة…» units
    _page_ranges(units)
    return units


def _page_ranges(units):
    """The last page of each lesson is the page before the next heading starts (known only when the contents page gave page numbers)."""
    marks = []
    for u in units:
        marks.append(u["page"] or 0)
        marks.extend(l["first_page"] or 0 for l in u["lessons"])
    seq = [p for p in marks if p]
    for u in units:
        for i, l in enumerate(u["lessons"]):
            if not l["first_page"]:
                continue
            later = [p for p in seq if p > l["first_page"]]
            l["last_page"] = (min(later) - 1) if later else 0
            if l["last_page"] < l["first_page"]:
                l["last_page"] = l["first_page"]


def _count(units):
    return sum(len(u["lessons"]) for u in units)


def _body_text(lines, start, stop, skip=()):
    """The lines between two headings, without bare page numbers and without the headings that print again and again at the top of every page."""
    out = [l for l in lines[start:stop] if l.strip() and not re.fullmatch(r"[\s\-–—·.]*\d{1,4}[\s\-–—·.]*", l) and ck(l) not in skip]
    return "\n".join(out).strip()


def _drop_running(lines, pages):
    """Lines that print on every page (the book's name at the top, «الفصل الدراسي الأول» at the bottom) are not content: they are taken out so they neither become
    headings nor end up inside a lesson. Only done when the page of every line is known."""
    if not pages or len(set(pages)) < 6:
        return lines, pages
    seen = {}
    for text, p in zip(lines, pages):
        k = ck(text)
        if k and len(text) <= 90:
            seen.setdefault(k, set()).add(p)
    limit = max(4, int(len(set(pages)) * 0.25))
    common = {k for k, ps in seen.items() if len(ps) >= limit}
    keep = [(t, p) for t, p in zip(lines, pages) if ck(t) not in common or classify(t)[0]]
    return [t for t, _ in keep], [p for _, p in keep]


def page_offset(lines, pages):
    """How many pages the printed numbers lag behind the file's pages (the cover and the front matter): the commonest difference between a page's own bare number and its place in the file. None when the pages print no numbers."""
    if not pages:
        return None
    votes, per = {}, {}
    for text, p in zip(lines, pages):
        per.setdefault(p, []).append(text)
    for p, ls in per.items():
        for text in ls[:3] + ls[-3:]:
            m = re.fullmatch(r"\s*(\d{1,3})\s*", digits(text))
            if m and int(m.group(1)) <= p:
                votes[p - int(m.group(1))] = votes.get(p - int(m.group(1)), 0) + 1
    if not votes:
        return None
    off, n = max(votes.items(), key=lambda kv: kv[1])
    return off if n >= 5 and n >= 0.3 * sum(votes.values()) else None


def _fill_from_pages(units, lines, pages, off):
    """A lesson whose heading the body does not print (the page shows it as a picture) takes the text of its pages, as the contents page numbers them."""
    for u in units:
        for l in u["lessons"]:
            if not l["first_page"] or not l["last_page"]:
                continue
            lo, hi = l["first_page"] + off, l["last_page"] + off
            ranged = _body_text([t for t, p in zip(lines, pages) if lo <= p <= hi], 0, 10 ** 9)[:MAX_TEXT]
            if not l["text"] or len(l["text"]) > 2.5 * max(len(ranged), 1):      # no heading found, or one found so far from its place that the text runs over the next lessons
                l["text"] = ranged


def analyze(lines, pages=None, hints=None):
    """The units and lessons of a book from its lines. `pages` gives the page of every line (to drop running headers), `hints` gives the heading level a Word file
    declares for a line (1 unit, 2 lesson). Returns {"units": [...], "toc": bool, "matched": int, "warn": str}."""
    lines = [re.sub(r"\s+", " ", str(l)).strip() for l in lines]
    if hints is None:
        lines, pages = _drop_running(lines, pages)
    toc = find_toc(lines)
    if toc:
        first, last, entries = toc
        off = page_offset(lines, pages) if hints is None else None
        items, found = _from_contents(lines, last + 1, _flat(entries), pages if hints is None else None, off)
        units = _assemble(items)
        if off is not None and pages:
            _fill_from_pages(units, lines, pages, off)
            found = max(found, sum(1 for u in units for l in u["lessons"] if l["text"]))
        n = _count(units)
        if n >= 2:
            warn = "" if found >= 0.7 * len(items) else "لم نجد في صفحات الكتاب نص بعض الدروس، وستبقى بلا نص حتى تضيفيه أو ترفعي ملف الدرس"
            return {"units": units, "toc": True, "matched": found, "warn": warn}
    units = _from_headings(lines, hints)
    if _count(units) >= 2:
        return {"units": units, "toc": False, "matched": _count(units), "warn": ""}
    return {"units": [], "toc": False, "matched": 0,
            "warn": "لم نجد في الكتاب فهرسًا أو عناوين وحدات ودروس واضحة. أضيفيها بنفسك، أو الصقي الفهرس في الخانة المخصصة وسنرتبه لك"}


def _from_contents(lines, start, entries, pages=None, off=None):
    """Walk through the body after the contents page and find each entry's heading in order; the text between two headings belongs to the first one."""
    keys = [ck(l) for l in lines]
    pos, cursor, found = [], start, 0
    for level, title, page, no in entries:
        full = ck(title).split()
        head = " ".join(full[:4])
        mk = ""
        m = (_UNIT_RE if level == "unit" else _LESSON_RE).match(key(digits(title)))
        if m and m.group("n"):
            mk = ck(m.group("m") + " " + m.group("n"))
        lab, rest = "", []
        parts = re.split(r"\s*[:：]\s*", title, maxsplit=1)
        if len(parts) == 2 and 2 <= len(ck(parts[0]).split()) <= 5:
            lab = ck(parts[0])
            rest = ck(parts[1]).split()                  # «الدرس الأول: التعريف بعلم التفسير»: the page often prints the label apart and only the title as the heading                  # «الحديث الأول: «مثل ما بعثني…»»: the page itself prints the label as the heading and the saying below it
        at = None
        for i in range(cursor, len(lines)):
            k = keys[i]
            if not k or len(lines[i]) > 140:
                continue
            if pages and off is not None and page and abs(pages[i] - (page + off)) > 3:
                continue                                  # the contents page says where the lesson starts: a heading far from there is another thing (a sentence quoting it)
            words = len(k.split())
            if lab and (k == lab or (k.startswith(lab + " ") and words <= len(lab.split()) + 8)) and heading_like(lines[i]):
                at = i
                break
            if len(rest) >= 3 and level != "unit" and k.startswith(" ".join(rest[:4])) and words <= len(rest) + 2 and heading_like(lines[i]):
                at = i
                break
            if head and k.startswith(head) and words <= len(full) + (6 if len(full) >= 3 else 2) and heading_like(lines[i]):
                at = i
                break
            if mk and (k == mk or (k.startswith(mk + " ") and words <= 10)) and heading_like(lines[i]):
                at = i
                break
        pos.append(at)
        if at is not None:
            cursor = at + 1
            found += 1
    items = []
    marks = [p for p in pos if p is not None]
    for n, (level, title, page, no) in enumerate(entries):
        text = ""
        if pos[n] is not None and level != "unit":
            nxt = next((p for p in marks if p > pos[n]), len(lines))
            text = _body_text(lines, pos[n] + 1, nxt if nxt != len(lines) else min(len(lines), pos[n] + 400))
        items.append((level, title, page, no, text))
    return items, found


def _from_headings(lines, hints=None):
    """No contents page: the headings of the pages themselves. A heading that repeats the one before it (a running header) is ignored."""
    marks = []                        # (line index, level, title, unit_no)
    last_key, again = {}, set()       # again: headings printed a second time right after themselves (the unit's name at the top of each page): not part of any lesson
    for i, line in enumerate(lines):
        if not line or not heading_like(line):
            continue
        level, no = classify(line, strict=True)
        if level is None and hints and hints[i]:
            level = "unit" if hints[i] == 1 else "lesson" if hints[i] == 2 else None
        if level is None:
            continue
        k = ck(line)
        if last_key.get(level) == k:
            again.add(k)
            continue
        last_key[level] = k
        marks.append((i, level, clean_title(line), no))
    if hints and sum(1 for m in marks if m[1] == "lesson") < 2:
        marks = []                    # a Word file whose headings carry the structure: 1 = unit, 2 = lesson (3 or more is the content)
        for i, line in enumerate(lines):
            h = hints[i] if hints[i] else 0
            if 1 <= h <= 2 and line:
                marks.append((i, "unit" if h == 1 else "lesson", clean_title(line), 0))
        if sum(1 for m in marks if m[1] == "lesson") < 2 and sum(1 for m in marks if m[1] == "unit") >= 2:
            marks = [(i, "lesson", t, n) for i, _l, t, n in marks]          # only first-level headings: they are the lessons
    items = []
    for n, (i, level, title, no) in enumerate(marks):
        stop = marks[n + 1][0] if n + 1 < len(marks) else len(lines)
        text = "" if level == "unit" else _body_text(lines, i + 1, stop, again)
        items.append((level, title, 0, no, text))
    return _assemble(items)


# ---------------------------------------------------------------- an outline the teacher types or pastes
def parse_outline(text: str):
    """Units and lessons from a list: «الوحدة الأولى: …» lines start a unit, any other line is a lesson (a trailing page number is read as the page). A list without
    unit lines can show its units by indenting the lessons under them."""
    rows = []
    lines = [raw for raw in str(text or "").replace("\t", "    ").splitlines() if raw.strip()]
    joined, i = [], 0
    while i < len(lines):                          # a table copied from a PDF gives the title on one line and its page number on the next
        bare = lines[i + 1].strip() if i + 1 < len(lines) else ""
        head = re.sub(r"^[\s\-–—•·*●▪◦]+", "", lines[i].strip())
        if _BARE_PAGE.match(digits(bare)) and not _BARE_PAGE.match(digits(head)) and re.search(r"[^\W\d_]", head) and _toc_line(head) is None:
            joined.append(lines[i].rstrip() + "  " + digits(bare))
            i += 2
        else:
            joined.append(lines[i])
            i += 1
    for raw in joined:
        indent = len(raw) - len(raw.lstrip(" "))
        s = re.sub(r"^[\s\-–—•·*●▪◦]+", "", raw.strip())
        bullet = bool(re.match(r"^\s*[\-–—•·*●▪◦]", raw))
        title, page, _sure = split_page(s)
        if title is None:
            title, page = clean_title(s), 0
        if len(title) >= 2 and re.search(r"[^\W\d_]", title):
            rows.append((indent + (2 if bullet else 0), title, page))
    if not rows:
        return []
    levels = [classify(t, strict=False)[0] for _, t, _p in rows]
    if "unit" not in levels and len({r[0] for r in rows}) > 1:
        base = min(r[0] for r in rows)
        for n, (ind, _t, _p) in enumerate(rows):
            nxt = rows[n + 1][0] if n + 1 < len(rows) else base
            levels[n] = "unit" if ind == base and nxt > ind else "lesson"
    items = [(lvl or "lesson", t, p, 0, "") for lvl, (_i, t, p) in zip(levels, rows)]
    return _assemble(items)[:MAX_UNITS]


# ---------------------------------------------------------------- the subject and the class named by the book
SUBJECTS = ("القرآن الكريم", "التوحيد", "الفقه", "الحديث", "الدراسات الإسلامية", "اللغة العربية", "لغتي الخالدة", "لغتي", "الرياضيات", "العلوم", "الأحياء", "الكيمياء", "الفيزياء",
            "اللغة الإنجليزية", "الدراسات الاجتماعية", "التاريخ", "الجغرافيا", "المهارات الرقمية", "الحاسب وتقنية المعلومات", "التربية الفنية", "التربية البدنية", "التفكير الناقد",
            "المهارات الحياتية والأسرية", "الأحياء والبيئة", "علم الأرض", "الهندسة", "الجبر", "النحو", "البلاغة", "الأدب", "الإملاء", "التربية الوطنية")


def detect_meta(first_text: str, filename: str = "", known=()):
    """(subject, grade) the book names on its first pages or in its file name; empty when it names none."""
    from . import meta
    text = str(first_text or "")[:6000]
    _body, found = meta.split_header(text)
    subject, grade = found.get("subject", ""), found.get("grade", "")
    if not grade:
        g = meta.GRADE.search(text) or meta.GRADE.search(filename.replace("_", " ").replace("-", " "))
        grade = g.group(0).strip() if g else ""
    if not subject:
        hay = ck(text[:3000])
        name_hay = ck(filename.replace("_", " ").replace("-", " ").rsplit(".", 1)[0])
        best = (0, 0, "")
        for name in set(list(known) + list(SUBJECTS)):
            kname = ck(name)
            if len(kname) < 4:
                continue
            pat = rf"(?:^|\s){re.escape(kname)}(?=\s|$)"
            score = len(re.findall(pat, hay)) + 5 * len(re.findall(pat, name_hay))
            if score and (score, len(kname)) > best[:2]:
                best = (score, len(kname), name)
        subject = best[2]
    grade = re.sub(r"^(?:بال|لل|ال|ل|ب)?صف\s+", "", grade.strip())
    return subject[:60], grade[:60]
