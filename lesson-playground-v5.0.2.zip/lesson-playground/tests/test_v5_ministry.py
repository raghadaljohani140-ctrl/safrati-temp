"""The ministry's own papers: a PDF whose font marks letters with a replacement sign, the student register and the weekly timetable as pictures."""
import io
import unittest

from app import arfix, bookread, extract, gridocr, roster, sheetocr, timetable
from tests import files5 as X
from tests.test_app import Base


def have_arabic_ocr():
    try:
        import pytesseract
        return "ara" in pytesseract.get_languages()
    except Exception:
        return False


F = "�"


class DamagedText(unittest.TestCase):
    def test_marks_before_the_teeth_letters_are_chosen_by_the_words_the_book_spells_cleanly(self):
        lines = ["الدرس الأول", "تفسير سورة الفاتحة", "تفسير سورة يونس", f"تف{F}سير {F}سورة", f"الدر{F}س الثاني", f"و{F}صف المقرر"] * 3 + ["وصف المقرر", "وصف النشاط"]
        out = arfix.repair(lines)
        self.assertIn("تفسير سورة", out[3])
        self.assertIn("الدرس الثاني", out[4])
        self.assertTrue(all(F not in l for l in out))

    def test_a_mark_at_the_end_or_before_other_letters_is_an_alef_or_nothing(self):
        out = arfix.repair(["هذا الكتاب", "هذا الدرس", f"هذ{F} الكتاب", f"{F}لله الرحمن", "الله الرحمن", "الله أكبر"])
        self.assertEqual(out[2], "هذا الكتاب")
        self.assertEqual(out[3], "الله الرحمن")

    def test_a_word_printed_twice_over_is_read_once_and_a_doubled_alef_is_one(self):
        self.assertEqual(arfix._unshadow("ووححددةة"), "وحدة")
        self.assertEqual(arfix._alefs("الإأولى"), "الأولى")
        self.assertEqual(arfix._alefs("الأآية"), "الآية")
        self.assertEqual(arfix._alefs("اأستنبط"), "أستنبط")

    def test_a_clean_book_is_left_alone(self):
        lines = ["الدرس الأول", "نص عادي"] * 50
        self.assertFalse(arfix.broken(lines))
        self.assertTrue(arfix.broken(lines + [F] * 200))


class LessonsByPage(unittest.TestCase):
    def book(self):
        lines, pages = [], []

        def add(page, *ls):
            for l in ls:
                lines.append(l)
                pages.append(page)
        add(1, "كتاب الرياضيات")
        add(2, "الموضوع", "الصفحة", "الوحدة الأولى: الأعداد", "5", "الدرس الأول: جمع الأعداد", "6", "الدرس الثاني: طرح الأعداد", "9", "الوحدة الثانية: الأشكال", "12", "الدرس الثالث: المثلث", "13", "الدرس الرابع: المربع", "16")
        for p in range(3, 20):
            add(p, *[f"هذا سطر رقم {i} في الصفحة رقم {p} من الكتاب وفيه كلمات كثيرة تشرح الفكرة" for i in range(6)], str(p))
        return lines, pages

    def test_the_offset_between_the_printed_page_and_the_file_page_is_found(self):
        lines, pages = self.book()
        self.assertEqual(bookread.page_offset(lines, pages), 0)
        shifted = [p + 3 for p in pages]
        self.assertEqual(bookread.page_offset(lines, shifted), 3)

    def test_a_lesson_whose_heading_is_not_in_the_text_gets_the_text_of_its_pages(self):
        lines, pages = self.book()
        r = bookread.analyze(lines, pages, None)
        lessons = [l for u in r["units"] for l in u["lessons"]]
        self.assertEqual([l["first_page"] for l in lessons], [6, 9, 13, 16])
        self.assertIn("الصفحة رقم 7 ", lessons[0]["text"])
        self.assertNotIn("الصفحة رقم 9 ", lessons[0]["text"])
        self.assertIn("الصفحة رقم 10 ", lessons[1]["text"])


class MinistryRoster(unittest.TestCase):
    def test_a_class_heading_with_its_label_gives_the_class_alone(self):
        self.assertEqual(roster._is_class_label("الصف : اولى /3"), "اولى /3")

    def test_the_class_the_ministry_writes_is_the_class_she_has(self):
        for written in ("اولى /3", "اولى ٣", "الأول 3", "1/3", "الصف الأول 3"):
            self.assertEqual(timetable.class_sig(written), (1, "3"), written)
        self.assertEqual(timetable.class_sig("ثالث عام ٣"), (3, "3"))


class Pictures(unittest.TestCase):
    def test_a_page_with_no_boxes_is_not_a_register(self):
        from PIL import Image
        self.assertEqual(sheetocr.register_lines(Image.new("RGB", (800, 1100), "white")), "")

    def test_the_heading_gives_only_the_class_and_the_subject(self):
        out = sheetocr._header_lines("كشيف ياك | لبات | ليومي الصف : اولى /3 الفصل الدراسي : الأول\nالمادة : القران الكريم والتفسير العام الدراسي : 1448")
        self.assertEqual(out, ["المادة : القران الكريم والتفسير", "الصف : اولى /3"])

    def test_a_badly_read_class_line_is_still_a_grade(self):
        self.assertEqual(gridocr._grade_of("يالك عام"), "ثالث عام")
        self.assertEqual(gridocr._grade_of("اولى"), "اولى")
        self.assertEqual(gridocr._grade_of("القرآن الكريم"), "")

    def test_the_subject_is_the_nearest_known_one_the_class_is_the_last_line(self):
        vocab = gridocr._vocab(["القرآن الكريم"])
        self.assertEqual(gridocr.clean_lines(["اعراب لكريم", "ونمععمزة", "اولى ٣"], vocab, ["القرآن الكريم"]), "القرآن الكريم اولى 3")
        self.assertEqual(gridocr.clean_lines(["اتنسداط"], vocab, ["النشاط"]), "النشاط")

    @unittest.skipUnless(have_arabic_ocr(), "needs Tesseract with Arabic")
    def test_the_names_of_a_scanned_register_are_read_box_by_box(self):
        text = extract.plain("image", X.register_png())
        lines = text.splitlines()
        self.assertEqual(lines[:2], ["المادة : القران الكريم والتفسير", "الصف : اولى /3"])
        names = [l.split(". ", 1)[1] for l in lines[2:]]
        self.assertGreaterEqual(len(names), 6)
        got = sum(1 for n in X.REGISTER_NAMES if n in names)
        self.assertGreaterEqual(got, 5, names)

    @unittest.skipUnless(have_arabic_ocr(), "needs Tesseract with Arabic")
    def test_a_timetable_picture_gives_every_used_box_in_its_day_and_period(self):
        data, use = X.timetable_png()
        sheets = extract.grid_sheets("image", data, ["القرآن الكريم", "النشاط"])
        self.assertTrue(sheets)
        parsed = timetable.parse(sheets, ["القرآن الكريم", "النشاط"])
        got = {(c["day"], c["period"]) for c in parsed["cells"]}
        self.assertEqual(got, set(use))
        quran = [c for c in parsed["cells"] if c["subject"] == "القرآن الكريم"]
        self.assertEqual(len(quran), 3)
        self.assertTrue(all("اولى" in c["class"] for c in quran))


class ImportedFromThePicture(Base):
    def setUp(self):
        super().setUp()
        from app import students
        students.import_limit.hits.clear()
        self.c = self.client()
        self.register(self.c)

    @unittest.skipUnless(have_arabic_ocr(), "needs Tesseract with Arabic")
    def test_the_register_picture_goes_to_the_preview_and_finds_her_class(self):
        r = self.j(self.c, "post", "/api/classes", {"name": "الأول 3"})
        cid = r.get_json()["id"]
        resp = self.c.post("/api/students/import", data={"file": (io.BytesIO(X.register_png()), "كشف.png")}, headers={"X-CSRF": self.token(self.c)}, content_type="multipart/form-data")
        self.assertEqual(resp.status_code, 200, resp.get_data(as_text=True))
        g = resp.get_json()["groups"][0]
        self.assertEqual(g["class_id"], cid)
        self.assertGreaterEqual(len(g["names"]), 6)
        self.assertEqual(self.c.get("/api/students").get_json()["students"], [])          # nothing saved before she confirms


if __name__ == "__main__":
    unittest.main()
