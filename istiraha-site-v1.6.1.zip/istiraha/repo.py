"""Reading and writing the adverts: search, offers, discounts, validation of what an owner types."""
from __future__ import annotations

import re
from datetime import date, timedelta
from urllib.parse import urlsplit

from . import founders, util
from .db import Database

UNITS = {"night": "الليلة", "day": "اليوم (نهاري)", "period": "الفترة (صباحية أو مسائية)", "week": "الأسبوع"}
UNIT_SHORT = {"night": "ليلة", "day": "يوم", "period": "فترة", "week": "أسبوع"}
SORTS = {"new": "الأحدث", "cheap": "الأرخص", "dear": "الأغلى", "deal": "أعلى خصم"}
SORT_NEAR = ("near", "الأقرب إليك")               # offered (and chosen first) only while the visitor has given his place
RADII = (5, 10, 25, 50)                           # the distances a visitor can choose, in km
DEFAULT_RADIUS = 25
PAGE_SIZE = 12
REVIEW_LABELS = {"pending": "بانتظار المراجعة", "approved": "معتمد", "rejected": "مرفوض", "stopped": "موقوف من الإدارة"}
RENTAL_STATUS = {"pending": "قيد التأكيد", "confirmed": "مؤكد", "completed": "تم", "cancelled": "ملغي"}
PAY_STATUS = {"due": "مستحقة", "paid": "مدفوعة", "disputed": "متنازع عليها", "waived": "معفاة"}
# what the admin sees in "latest operations" (the stored keys stay English and stable; an unknown key is shown as it is)
AUDIT_LABELS = {
    "admin_login": "دخول المدير", "admin_password": "تغيير كلمة مرور الإدارة", "owner_password": "تغيير كلمة مرور مالك",
    "lockout": "قفل حساب مؤقتًا", "commission": "تغيير نسبة العمولة", "pledge": "نسخة جديدة من التعهد",
    "block_owner": "إيقاف حساب مالك", "unblock_owner": "إعادة تفعيل مالك", "reset_password": "كلمة مرور مؤقتة لمالك",
    "listing_approve": "اعتماد إعلان", "listing_reject": "رفض إعلان", "listing_stop": "إيقاف إعلان", "listing_feature": "تمييز إعلان",
    "auto_approve": "نشر تلقائي لإعلان", "publish_auto": "تفعيل النشر التلقائي", "publish_manual": "إيقاف النشر التلقائي",
    "rental_new": "تسجيل عملية تأجير", "owner_rental_new": "تسجيل عملية من مالك", "rental_update": "تعديل عملية تأجير", "offer_new": "عرض جديد",
    "owner_offer_new": "عرض جديد من مالك", "offer_stop": "إيقاف عرض مالك", "offer_lift": "رفع إيقاف عرض", "offer_delete": "حذف عرض",
    "add_cities": "إضافة مدينة", "add_categories": "إضافة نوع", "add_amenities": "إضافة مرفق",
    "pay_details": "تغيير بيانات استلام العمولة", "payment_report": "بلاغ سداد من مالك", "payment_withdraw": "إلغاء بلاغ سداد",
    "payment_confirm": "تأكيد استلام عمولة", "payment_reject": "رفض بلاغ سداد",
    "founders_on": "تفعيل عرض المؤسسين", "founders_off": "إيقاف عرض المؤسسين", "founders_grant": "منح إعفاء المؤسسين",
    "listing_location": "تحديد موقع إعلان على الخريطة",
}
MAX_BLOCKS = 60


def publish_if_ready(db: Database, listing_id: int, now: float) -> bool:
    """Automatic publishing. A waiting advert nobody objected to goes live as soon as it has a picture. An advert the manager rejected
    or stopped keeps its reason and waits for the manager, so this never overrides a decision of his. True when it went live."""
    if not db.auto_publish():
        return False
    ready = db.one("""SELECT 1 FROM listings l WHERE l.id = ? AND l.review = 'pending' AND l.review_note = ''
                      AND EXISTS (SELECT 1 FROM photos p WHERE p.listing_id = l.id)""", (listing_id,))
    if not ready:
        return False
    db.run("UPDATE listings SET review = 'approved', approved_at = ?, updated_at = ? WHERE id = ?", (now, now, listing_id))
    db.audit(None, "auto_approve", str(listing_id))
    founders.grant_if_open(db, listing_id, util.today(lambda: now), now)          # the founders' offer, only while the manager has it switched on
    return True


def publish_waiting(db: Database, now: float) -> tuple[int, int]:
    """When the manager switches automatic publishing on: (adverts published now, adverts still waiting for their first picture)."""
    waiting = [r["id"] for r in db.all("SELECT id FROM listings WHERE review = 'pending' AND review_note = ''")]
    published = sum(publish_if_ready(db, lid, now) for lid in waiting)
    return published, len(waiting) - published


def active_offers(db: Database, today: date) -> list:
    return db.all("SELECT * FROM offers WHERE active = 1 AND starts_on <= ? AND ends_on >= ?", (today.isoformat(), today.isoformat()))


def discount_for(listing, offers) -> tuple[int, str]:
    """The biggest discount that applies to this advert, and the offer's title. An offer an owner made applies to his adverts only,
    whatever else it says; one the manager made has no owner and follows its city, type or advert."""
    best, title = 0, ""
    for o in offers:
        if o["owner_id"] and o["owner_id"] != listing["owner_id"]:
            continue
        if o["listing_id"] and o["listing_id"] != listing["id"]:
            continue
        if not o["listing_id"]:
            if o["city_id"] and o["city_id"] != listing["city_id"]:
                continue
            if o["category_id"] and o["category_id"] != listing["category_id"]:
                continue
        if o["percent"] > best:
            best, title = o["percent"], o["title"]
    return best, title


def price_after(price: int, percent: int) -> int:
    return round(price * (100 - percent) / 100) if percent else price


def _decorate(db: Database, rows, offers) -> list[dict]:
    items = []
    for r in rows:
        item = dict(r)
        pct, offer_title = discount_for(r, offers)
        item.update(discount=pct, offer_title=offer_title, final_price=price_after(r["price"], pct))
        items.append(item)
    return items


_BASE = """
SELECT l.*, c.name AS city_name, g.name AS category_name,
  (SELECT filename FROM photos p WHERE p.listing_id = l.id ORDER BY p.position, p.id LIMIT 1) AS cover
FROM listings l JOIN cities c ON c.id = l.city_id JOIN categories g ON g.id = l.category_id
"""
_PUBLIC = ("l.review = 'approved' AND l.owner_active = 1 AND c.active = 1 AND g.active = 1 "
           "AND l.owner_id IN (SELECT id FROM users WHERE status = 'active')")


def matching(db: Database, today: date, *, city: int | None = None, category: int | None = None, district: str = "",
             price_min: int | None = None, price_max: int | None = None, on: date | None = None, amenities: list[int] | None = None,
             offers_only: bool = False, sort: str = "new", query: str = "", featured_only: bool = False,
             near: tuple[float, float] | None = None, km: float | None = None, located_only: bool = False) -> list[dict]:
    """Every published advert that fits, not cut into pages (the map shows them all at once). With `located_only` only the adverts that
    have a place stay. With `near` (the visitor's place) the same, and each advert gets `km`, its distance in km; with `km` too, only the
    adverts within that distance stay. An advert without a place never breaks this: it is simply not on the map and not "near" anyone."""
    where, args = [_PUBLIC], []
    if city:
        where.append("l.city_id = ?")
        args.append(city)
    if category:
        where.append("l.category_id = ?")
        args.append(category)
    if district:
        where.append("l.district LIKE ? ESCAPE '\\'")
        args.append("%" + district.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%")
    if query:
        where.append("(l.title LIKE ? ESCAPE '\\' OR l.description LIKE ? ESCAPE '\\')")
        like = "%" + query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        args += [like, like]
    if featured_only:
        where.append("l.featured = 1")
    if on:
        where.append("NOT EXISTS (SELECT 1 FROM blocked_dates b WHERE b.listing_id = l.id AND ? BETWEEN b.start_date AND b.end_date)")
        args.append(on.isoformat())
    for a in (amenities or [])[:12]:
        where.append("EXISTS (SELECT 1 FROM listing_amenities la WHERE la.listing_id = l.id AND la.amenity_id = ?)")
        args.append(a)
    if located_only or near is not None:
        where.append("l.lat IS NOT NULL AND l.lng IS NOT NULL")          # both are written together; this keeps a half-written pair out
    rows = db.all(f"{_BASE} WHERE {' AND '.join(where)} ORDER BY l.id DESC", tuple(args))
    items = _decorate(db, rows, active_offers(db, today))
    if offers_only:
        items = [i for i in items if i["discount"]]
    if price_min is not None:
        items = [i for i in items if i["final_price"] >= price_min]
    if price_max is not None:
        items = [i for i in items if i["final_price"] <= price_max]
    if near is not None:
        for i in items:
            i["km"] = util.distance_km(near[0], near[1], i["lat"], i["lng"])
        if km:
            items = [i for i in items if i["km"] <= km]
    if sort == "near" and near is not None:
        items.sort(key=lambda i: (i["km"], -i["id"]))
    elif sort == "cheap":
        items.sort(key=lambda i: (i["final_price"], -i["id"]))
    elif sort == "dear":
        items.sort(key=lambda i: (-i["final_price"], -i["id"]))
    elif sort == "deal":
        items.sort(key=lambda i: (-i["discount"], -i["id"]))
    return items


def search(db: Database, today: date, *, page: int = 1, **fit) -> tuple[list[dict], int]:
    """(one page of the adverts that fit, how many fit in all). `fit` is what `matching` takes."""
    items = matching(db, today, **fit)
    start = (max(1, page) - 1) * PAGE_SIZE
    return items[start:start + PAGE_SIZE], len(items)


def nearest_km(db: Database, today: date, near: tuple[float, float], **fit) -> float | None:
    """How far the nearest advert that fits is, whatever the chosen distance: said to a visitor who has none within it."""
    fit.pop("km", None)
    items = matching(db, today, near=near, **fit)
    return min((i["km"] for i in items), default=None)


def public_listing(db: Database, listing_id: int, today: date) -> dict | None:
    row = db.one(f"{_BASE} WHERE l.id = ? AND {_PUBLIC}", (listing_id,))
    return _decorate(db, [row], active_offers(db, today))[0] if row else None


def any_listing(db: Database, listing_id: int) -> dict | None:
    row = db.one(f"{_BASE} WHERE l.id = ?", (listing_id,))
    return dict(row) if row else None


def amenities_of(db: Database, listing_id: int) -> list[str]:
    return [r["name"] for r in db.all(
        "SELECT a.name FROM listing_amenities la JOIN amenities a ON a.id = la.amenity_id WHERE la.listing_id = ? ORDER BY a.sort, a.id", (listing_id,))]


def amenity_ids_of(db: Database, listing_id: int) -> set[int]:
    return {r["amenity_id"] for r in db.all("SELECT amenity_id FROM listing_amenities WHERE listing_id = ?", (listing_id,))}


def photos_of(db: Database, listing_id: int) -> list:
    return db.all("SELECT * FROM photos WHERE listing_id = ? ORDER BY position, id", (listing_id,))


def blocks_of(db: Database, listing_id: int) -> list:
    return db.all("SELECT * FROM blocked_dates WHERE listing_id = ? ORDER BY start_date", (listing_id,))


def homepage(db: Database, today: date) -> dict:
    """Three shelves for the front page. An advert sits on the first shelf it qualifies for, so a young site with
    only a few adverts does not show the same card three times."""
    shelves = (("featured", search(db, today, featured_only=True)[0]),
               ("deals", search(db, today, offers_only=True, sort="deal")[0]),
               ("latest", search(db, today)[0]))
    seen: set[int] = set()
    out: dict[str, list[dict]] = {}
    for key, rows in shelves:
        picked = [r for r in rows if r["id"] not in seen][:6]
        seen.update(r["id"] for r in picked)
        out[key] = picked
    return out


# ---- what an owner types ------------------------------------------------------------------------------------
_MAP_HOSTS = ("maps.app.goo.gl", "goo.gl", "www.google.com", "google.com", "maps.google.com", "www.google.com.sa", "maps.apple.com")


def clean_map_url(text: str) -> str | None:
    text = util.clean_text(text)
    if not text:
        return ""
    found = re.search(r"https?://\S+", text)                  # a pasted share text (a place name followed by its link) keeps only the link
    if found:
        text = found.group(0)
    try:
        parts = urlsplit(text)
    except ValueError:
        return None
    if parts.scheme != "https" or (parts.hostname or "") not in _MAP_HOSTS or len(text) > 400:
        return None
    return text


def _text(form, name: str, low: int, high: int, label: str, errors: dict, required: bool = True) -> str:
    value = re.sub(r"[ \t]+", " ", (form.get(name) or "").replace("\r\n", "\n")).strip()
    value = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", value)
    if required and len(value) < low:
        errors[name] = f"{label}: اكتب {low} أحرف على الأقل" if low > 1 else f"اكتب {label}"
    elif len(value) > high:
        errors[name] = f"{label} طويل (الحد {high} حرفًا)"
    return value


def validate_listing(db: Database, form: dict, *, whatsapp_default: str = "") -> tuple[dict, dict]:
    """(values, errors). `form` maps names to a single string, except "amenities" which is a list."""
    errors: dict[str, str] = {}
    v: dict = {}
    v["title"] = _text(form, "title", 4, 80, "اسم الاستراحة", errors)
    v["district"] = _text(form, "district", 0, 60, "الحي", errors, required=False)
    v["description"] = _text(form, "description", 0, 2000, "الوصف", errors, required=False)
    v["availability_note"] = _text(form, "availability_note", 0, 300, "ملاحظة الأوقات", errors, required=False)
    city = util.parse_int(form.get("city") or "", 1, 10**6)
    if not city or not db.one("SELECT 1 FROM cities WHERE id = ? AND active = 1", (city,)):
        errors["city"] = "اختر المدينة"
    v["city_id"] = city
    cat = util.parse_int(form.get("category") or "", 1, 10**6)
    if not cat or not db.one("SELECT 1 FROM categories WHERE id = ? AND active = 1", (cat,)):
        errors["category"] = "اختر نوع الاستراحة"
    v["category_id"] = cat
    raw_price = form.get("price") or ""
    price = util.parse_int(raw_price, 1, 1_000_000, util.PRICE_WORDS)
    if not price:
        errors["price"] = "اكتب سعر الإيجار بالأرقام فقط، مثل 800"
    v["price"] = price or raw_price.strip()                  # when it is refused the page shows what was typed, not an empty box
    unit = form.get("unit") or ""
    if unit not in UNITS:
        errors["unit"] = "اختر مدة الإيجار"
    v["unit"] = unit
    cap = (form.get("capacity") or "").strip()
    v["capacity"] = util.parse_int(cap, 1, 5000, util.PEOPLE_WORDS) if cap else None
    if cap and v["capacity"] is None:
        errors["capacity"] = "اكتب عدد الأشخاص بالأرقام فقط، مثل 20"
        v["capacity"] = cap
    raw_phone = (form.get("whatsapp") or "").strip()
    phone = util.normalize_phone(raw_phone) or ""
    if not phone:
        errors["whatsapp"] = "اكتب رقم جوال سعودي صحيح، مثل 0551234567"
    v["whatsapp"] = phone or raw_phone
    raw_url = (form.get("map_url") or "").strip()
    url = clean_map_url(raw_url)
    if url is None:
        errors["map_url"] = "رابط الموقع يجب أن يكون رابط خرائط قوقل (يبدأ بـ https)"
    v["map_url"] = url if url is not None else raw_url
    v["place_given"] = "lat" in form or "lng" in form               # a page from before the maps existed sends neither: then the place is left as it is
    v["lat"] = v["lng"] = None
    lat_text, lng_text = (form.get("lat") or "").strip(), (form.get("lng") or "").strip()
    if lat_text and not lng_text:
        pair = util.split_pair(lat_text)                           # "24.7136, 46.6753" pasted as the map apps copy it
        if pair:
            lat_text, lng_text = pair
    if lat_text or lng_text:
        lat, lng = util.parse_coord(lat_text, -90, 90), util.parse_coord(lng_text, -180, 180)
        if lat is None or lng is None:
            errors["lat"] = "اكتب خط العرض وخط الطول بالأرقام، مثل 24.7136 و 46.6753"
        elif not util.in_kingdom(lat, lng):
            errors["lat"] = "هذا الموقع خارج المملكة، تأكد من الرقمين (خط العرض أولًا ثم خط الطول)"
        else:
            v["lat"], v["lng"] = lat, lng
        if "lat" in errors:
            v["lat"], v["lng"] = lat_text, lng_text                # the page shows what was typed
    ids = set()
    for raw in form.get("amenities") or []:
        n = util.parse_int(str(raw), 1, 10**6)
        if n:
            ids.add(n)
    valid = {r["id"] for r in db.all("SELECT id FROM amenities WHERE active = 1")}
    v["amenities"] = sorted(ids & valid)
    return v, errors


# fields that make the advert go back to review when they change (the price and the dates do not)
REVIEWED_FIELDS = ("title", "district", "description", "map_url", "city_id", "category_id", "whatsapp", "capacity", "availability_note")
