"""The page shell and the small pieces every page is made of. Everything a visitor typed goes through e()."""
from __future__ import annotations

import html
from datetime import datetime

from . import __version__, founders, repo, util


def e(value) -> str:
    return html.escape(str(value if value is not None else ""), quote=True)


def num(n: int) -> str:
    return f"{int(n):,}"


def stamp(ts: float | None) -> str:
    if not ts:
        return "—"
    return datetime.fromtimestamp(ts, util.SAUDI_TZ).strftime("%Y-%m-%d %H:%M")


MONTHS = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]


def day_text(iso: str) -> str:
    d = util.parse_date(iso)
    return f"{d.day} {MONTHS[d.month - 1]} {d.year}" if d else iso


BRAND_NAME = "استراحتي"        # the name the logo's lettering spells; under any other SITE_NAME the header writes the name as text instead


def brand_html(site_name: str, admin: bool) -> str:
    """The logo in the header: the emblem, then the lettering (a picture) or, for the manager's pages and a renamed site, the name as text."""
    v = f"?v={__version__}"
    mark = f'<img class="mark" src="/static/logo-mark.webp{v}" width="50" height="44" alt="">'
    if admin or site_name != BRAND_NAME:
        return f'{mark}<span>{e(site_name)}</span>'
    return f'{mark}<img class="word" src="/static/logo-word.webp{v}" width="105" height="30" alt="{e(site_name)}">'


class Page:
    """What the shell needs to know about this visit."""

    def __init__(self, site_name: str, site_url: str, user=None, csrf: str = "", admin_user=None, waiting: int = 0):
        self.site_name, self.site_url, self.user, self.csrf, self.admin_user = site_name, site_url, user, csrf, admin_user
        self.waiting = waiting                      # payment reports the manager has not decided yet (a number beside «الأرباح»)


def layout(page: Page, title: str, body: str, *, description: str = "", noindex: bool = False, canonical: str = "",
           image: str = "", extra_class: str = "", admin: bool = False, head: str = "", scripts: str = "") -> str:
    full = f"{title} | {page.site_name}" if title else page.site_name
    desc = description or f"{page.site_name}: منصة سعودية لإيجار الاستراحات. ابحث بالمدينة والسعر والتاريخ وتواصل مع صاحب الاستراحة مباشرة عبر واتساب."
    robots = '<meta name="robots" content="noindex, nofollow">' if noindex else ""
    canon = f'<link rel="canonical" href="{e(page.site_url + canonical)}">' if page.site_url and canonical else ""
    if not image and page.site_url:             # a page with no picture of its own is shared with the logo (the link preview needs a full address)
        image = f"{page.site_url}/static/share.jpg?v={__version__}"
    og_img = f'<meta property="og:image" content="{e(image)}">' if image else ""
    if admin:
        earn = (f'<a href="/admin/earnings" aria-label="الأرباح، {page.waiting} بلاغ سداد بانتظار التأكيد">الأرباح<span class="nbadge">{page.waiting}</span></a>'
                if page.waiting else '<a href="/admin/earnings">الأرباح</a>')
        nav = ('<a href="/admin">اللوحة</a><a href="/admin/listings">الإعلانات</a><a href="/admin/rentals">التأجير</a>'
               f'{earn}'
               '<a href="/admin/commission">العمولة</a><a href="/admin/owners">الملاك</a><a href="/admin/offers">العروض</a><a href="/admin/settings">الإعدادات</a>')
        account = (f'<form method="post" action="/admin/logout" class="inline"><input type="hidden" name="_csrf" value="{e(page.csrf)}">'
                   '<button class="link" type="submit">خروج</button></form>') if page.admin_user else ""
    else:
        nav = '<a href="/search">الاستراحات</a><a href="/offers">العروض</a>'
        if page.user:
            account = ('<a href="/owner">إعلاناتي</a><a href="/owner/offers">عروضي</a><a href="/owner/commissions">عمولاتي</a>'
                       f'<form method="post" action="/owner/logout" class="inline"><input type="hidden" name="_csrf" value="{e(page.csrf)}">'
                       '<button class="link" type="submit">خروج</button></form>')
        else:
            account = '<a href="/owner/login">دخول الملاك</a>'
    cta = "" if admin else '<a class="btn sun small add" href="/owner/new">أضف استراحتك</a>'
    # a signed-in owner's menu has six entries: the stylesheet lays it out as a grid under the name on a phone (as the manager's)
    body_class = " ".join(x for x in (extra_class, "owner-in" if page.user and not admin else "") if x)
    return f"""<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{e(full)}</title>
<meta name="description" content="{e(desc)}">
<meta name="theme-color" content="#2457C5">
<meta property="og:title" content="{e(full)}"><meta property="og:description" content="{e(desc)}"><meta property="og:locale" content="ar_SA">
{og_img}{robots}{canon}
<link rel="icon" href="/static/favicon-32.png?v={__version__}" type="image/png" sizes="32x32">
<link rel="icon" href="/static/favicon-48.png?v={__version__}" type="image/png" sizes="48x48">
<link rel="apple-touch-icon" href="/static/apple-touch-icon.png?v={__version__}">
<link rel="stylesheet" href="/static/app.css?v={__version__}">
{head}</head>
<body class="{e(body_class)}">
<a class="skip" href="#main">تخطي إلى المحتوى</a>
<header class="top"><div class="wrap bar">
<a class="brand" href="{'/admin' if admin else '/'}">{brand_html(page.site_name, admin)}</a>
{cta}<nav class="nav" aria-label="القائمة">{nav}{account}</nav>
</div></header>
<main id="main" class="wrap main">{body}</main>
<footer class="foot"><div class="wrap"><p>{e(page.site_name)}: منصة للتعريف بالاستراحات. الحجز والدفع يتمان مباشرة بين العميل وصاحب الاستراحة عبر واتساب.</p>
<p><a href="/terms">الشروط والأحكام</a> · <a href="/privacy">الخصوصية</a> · <a href="/owner/new">أضف استراحتك</a></p></div></footer>
{scripts}<script src="/static/app.js?v={__version__}" defer></script>
</body></html>"""


LEAFLET_VERSION = "1.9.4"


def map_assets() -> tuple[str, str]:
    """(for the head, for the end of the body): the map library and the site's own map script. Only the pages that show a map ask for them."""
    head = f'<link rel="stylesheet" href="/static/vendor/leaflet/leaflet.css?v={LEAFLET_VERSION}">\n'
    scripts = (f'<script src="/static/vendor/leaflet/leaflet.js?v={LEAFLET_VERSION}" defer></script>\n'
               f'<script src="/static/map.js?v={__version__}" defer></script>\n')
    return head, scripts


def field(label: str, name: str, value="", *, type: str = "text", error: str = "", hint: str = "", required: bool = False,
          attrs: str = "", autocomplete: str = "") -> str:
    err = f'<p class="err" id="e-{e(name)}">{e(error)}</p>' if error else ""
    hint_html = f'<p class="hint">{e(hint)}</p>' if hint else ""
    ac = f' autocomplete="{e(autocomplete)}"' if autocomplete else ""
    req = " required" if required else ""
    return (f'<div class="f{" bad" if error else ""}"><label for="f-{e(name)}">{e(label)}</label>'
            f'<input id="f-{e(name)}" name="{e(name)}" type="{e(type)}" value="{e(value)}"{req}{ac} {attrs}>{hint_html}{err}</div>')


def textarea(label: str, name: str, value="", *, error: str = "", hint: str = "", rows: int = 5) -> str:
    err = f'<p class="err">{e(error)}</p>' if error else ""
    hint_html = f'<p class="hint">{e(hint)}</p>' if hint else ""
    return (f'<div class="f{" bad" if error else ""}"><label for="f-{e(name)}">{e(label)}</label>'
            f'<textarea id="f-{e(name)}" name="{e(name)}" rows="{rows}">{e(value)}</textarea>{hint_html}{err}</div>')


def select(label: str, name: str, options: list[tuple], selected="", *, error: str = "", blank: str = "", hint: str = "") -> str:
    opts = f'<option value="">{e(blank)}</option>' if blank else ""
    for value, text in options:
        opts += f'<option value="{e(value)}"{" selected" if str(value) == str(selected) else ""}>{e(text)}</option>'
    err = f'<p class="err">{e(error)}</p>' if error else ""
    hint_html = f'<p class="hint">{e(hint)}</p>' if hint else ""
    return (f'<div class="f{" bad" if error else ""}"><label for="f-{e(name)}">{e(label)}</label>'
            f'<select id="f-{e(name)}" name="{e(name)}">{opts}</select>{hint_html}{err}</div>')


def checks(name: str, options: list[tuple], selected: set) -> str:
    out = ""
    for value, text in options:
        out += (f'<label class="chk"><input type="checkbox" name="{e(name)}" value="{e(value)}"'
                f'{" checked" if value in selected else ""}><span>{e(text)}</span></label>')
    return f'<div class="chks">{out}</div>'


def csrf_input(token: str) -> str:
    return f'<input type="hidden" name="_csrf" value="{e(token)}">'


def notice(kind: str, text: str) -> str:
    return f'<p class="note {e(kind)}" role="status">{e(text)}</p>' if text else ""


def price_html(item: dict) -> str:
    unit = repo.UNIT_SHORT.get(item["unit"], "")
    if item.get("discount"):
        return (f'<span class="price"><b>{num(item["final_price"])}</b> ر.س <small>/ {e(unit)}</small></span>'
                f'<s class="was">{num(item["price"])}</s>')
    return f'<span class="price"><b>{num(item["price"])}</b> ر.س <small>/ {e(unit)}</small></span>'


def card(item: dict, amenity_names: list[str] | None = None) -> str:
    cover = (f'<img src="/media/{e(item["cover"])}" alt="{e(item["title"])}" loading="lazy" width="640" height="480">'
             if item.get("cover") else '<div class="noimg" aria-hidden="true"></div>')
    badge = f'<span class="badge">خصم {item["discount"]}%</span>' if item.get("discount") else ""
    if item.get("featured"):
        badge += '<span class="badge star">مميزة</span>'
    place = item["city_name"] + (f" · {item['district']}" if item.get("district") else "")
    chips = "".join(f"<li>{e(a)}</li>" for a in (amenity_names or [])[:3])
    away = f'<p class="away">📍 تبعد {e(util.distance_text(item["km"]))} عن موقعك</p>' if item.get("km") is not None else ""      # only while the visitor has given his place
    return (f'<a class="card" href="/r/{item["id"]}"><div class="shot">{cover}{badge}</div>'
            f'<div class="info"><h3>{e(item["title"])}</h3><p class="where">{e(place)} · {e(item["category_name"])}</p>{away}'
            f'{"<ul class=chips>" + chips + "</ul>" if chips else ""}<p class="priceline">{price_html(item)}</p></div></a>')


# ---- the founders' offer (the logic is in founders.py; these are only its pieces of page) -------------------------------------
def founders_meter(left: int) -> str:
    """One thin bar that drains as the seats go: full while all hundred are free, empty at the last one. It is drawn by the browser from two
    numbers (no squares, no inline style) and read aloud as words."""
    cap = founders.CAP
    left = max(0, min(int(left), cap))
    return f'<progress class="meter" max="{cap}" value="{left}" aria-label="المقاعد المتبقية {left} من {cap}">{left} من {cap}</progress>'


def founders_countdown(left: int) -> str:
    """The manager's big number: the seats left, one fewer with every advert that takes a seat, over the bar. The same tile as his other big figures."""
    return (f'<div class="stat big countdown"><b>{num(left)}</b><span>المقاعد المتبقية من {founders.CAP}</span>'
            f'{founders_meter(left)}</div>')


def founders_banner(taken: int, left: int) -> str:
    """The advert of the offer: the sentence, the button, the real number of seats left and the terms. Both numbers come from the database."""
    terms = "".join(f"<li>{e(t)}</li>" for t in founders.TERMS_PUBLIC)
    note = f"استفادت {num(taken)} استراحة حتى الآن" if taken else "كن أول من ينال هذا العرض"
    return (f'<section class="founders" aria-label="{e(founders.NAME)}"><div class="fd-copy"><p class="fd-chip">🏆 {e(founders.NAME)}</p>'
            f'<h2>{e(founders.HEADLINE)}</h2><a class="btn sun big" href="/owner/new">أضف استراحتك</a>'
            f'<details class="fd-terms"><summary>شروط العرض</summary><ul>{terms}</ul></details></div>'
            f'<div class="fd-count"><p class="fd-left"><b>{num(left)}</b><span>المقاعد المتبقية من {founders.CAP}</span></p>'
            f'{founders_meter(left)}<p class="fd-note">{e(note)}</p></div></section>')


def founders_owner_card(rows: list, today_iso: str) -> str:
    """What an owner is told about his free years: one line per advert, with the day it ends (or ended). Empty when he has none."""
    if not rows:
        return ""
    lines, live = "", False
    for r in rows:
        if founders.state_of(r, today_iso) == "active":
            live = True
            lines += f'<small>{e(r["title"])}: من {e(day_text(r["starts_on"]))} حتى {e(day_text(r["ends_on"]))}</small>'
        else:
            lines += f'<small>{e(r["title"])}: انتهى إعفاؤها في {e(day_text(r["ends_on"]))}، وتُحسب العمولة المتفق عليها</small>'
    head = "معفاة من العمولة سنة كاملة" if live else "انتهت سنة الإعفاء"
    return f'<section class="com-card{" ok" if live else ""}"><p>🎁 {e(founders.NAME)}: {head}{lines}</p></section>'


def pager(page: int, total: int, base: str) -> str:
    pages = max(1, -(-total // repo.PAGE_SIZE))
    if pages <= 1:
        return ""
    sep = "&" if "?" in base else "?"
    prev = f'<a class="btn ghost small" href="{e(base)}{sep}page={page - 1}">السابق</a>' if page > 1 else ""
    nxt = f'<a class="btn ghost small" href="{e(base)}{sep}page={page + 1}">التالي</a>' if page < pages else ""
    return f'<nav class="pager" aria-label="الصفحات">{prev}<span>صفحة {page} من {pages}</span>{nxt}</nav>'
