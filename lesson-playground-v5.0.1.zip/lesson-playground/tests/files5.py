"""Builds real Excel / Word / CSV files for the v5 tests. Excel files come from XlsxWriter (it ships with python-pptx), Word files are written by hand
(a .docx is a zip of XML) and, when LibreOffice is installed, also by LibreOffice itself so the readers meet files written by a real program."""
import io
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path

NAMES = ["أحمد محمد العتيبي", "سارة خالد الغامدي", "نورة عبدالله القحطاني", "ريم سعد الدوسري", "منى فهد الشمري"]
NAMES2 = ["خالد عمر الحربي", "ليان ناصر العنزي", "يوسف علي المطيري"]


def xlsx_bytes(sheets):
    """sheets: {"sheet name": [[cell, ...], ...]} -> bytes. A cell that is an int stays a number in the file."""
    import xlsxwriter
    buf = io.BytesIO()
    wb = xlsxwriter.Workbook(buf, {"in_memory": True})
    for name, rows in sheets.items():
        ws = wb.add_worksheet(name)
        for r, row in enumerate(rows):
            for c, v in enumerate(row):
                if v not in ("", None):
                    ws.write(r, c, v)
    wb.close()
    return buf.getvalue()


def roster_xlsx(with_header=True):
    rows = [["م", "الاسم", "رقم الهوية", "ملاحظات"]] if with_header else []
    rows += [[i + 1, n, 1090000000 + i, ""] for i, n in enumerate(NAMES)]
    rows.append(["", "المجموع", len(NAMES), ""])
    return xlsx_bytes({"الصف الأول أ": rows})


W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"


def _p(text, style=None, bold=False):
    ppr = f'<w:pPr><w:pStyle w:val="{style}"/></w:pPr>' if style else ""
    rpr = "<w:rPr><w:b/></w:rPr>" if bold else ""
    return f'<w:p>{ppr}<w:r>{rpr}<w:t xml:space="preserve">{text}</w:t></w:r></w:p>'


def _tbl(rows):
    out = "<w:tbl>"
    for row in rows:
        out += "<w:tr>" + "".join(f"<w:tc>{_p(c)}</w:tc>" for c in row) + "</w:tr>"
    return out + "</w:tbl>"


def docx_bytes(body_xml, with_styles=True):
    doc = f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="{W}"><w:body>{body_xml}</w:body></w:document>'
    styles = (f'<?xml version="1.0" encoding="UTF-8"?><w:styles xmlns:w="{W}">'
              '<w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/></w:style>'
              '<w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/></w:style>'
              '<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/></w:style></w:styles>')
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/>'
                   '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>')
        z.writestr("_rels/.rels", '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>')
        z.writestr("word/document.xml", doc)
        if with_styles:
            z.writestr("word/styles.xml", styles)
    return buf.getvalue()


def roster_docx():
    """Two classes, each a heading line above a table of numbers and names."""
    body = (_p("كشف أسماء الطلاب", "Title") + _p("الصف الأول أ", "Heading1") + _tbl([["م", "الاسم"]] + [[str(i + 1), n] for i, n in enumerate(NAMES)])
            + _p("الصف الأول ب", "Heading1") + _tbl([["م", "الاسم"]] + [[str(i + 1), n] for i, n in enumerate(NAMES2)]))
    return docx_bytes(body)


def roster_docx_lines():
    """No table: a numbered line for each name, with a class heading line before each block."""
    lines = ["الصف الثاني / ب"] + [f"{i + 1}- {n}" for i, n in enumerate(NAMES)] + ["الصف الثالث / ج"] + [f"{i + 1}) {n}" for i, n in enumerate(NAMES2)]
    return docx_bytes("".join(_p(x) for x in lines))


def csv_bytes(encoding="utf-8-sig", delimiter=","):
    rows = [["الاسم", "الفصل"]] + [[n, "الأول أ"] for n in NAMES[:3]] + [[n, "الأول ب"] for n in NAMES2[:2]]
    text = "\n".join(delimiter.join(r) for r in rows)
    return text.encode(encoding)


def soffice_convert(html: str, out_ext: str):
    """A real file written by LibreOffice from an HTML page (None when LibreOffice is not installed)."""
    exe = shutil.which("soffice") or shutil.which("libreoffice")
    if not exe:
        return None
    with tempfile.TemporaryDirectory() as d:
        src = Path(d) / "in.html"
        src.write_text(html, encoding="utf-8")
        flt = {"docx": "docx:MS Word 2007 XML", "xlsx": "xlsx:Calc MS Excel 2007 XML"}[out_ext]
        cmd = [exe, "--headless", "-env:UserInstallation=file://" + d + "/profile", "--convert-to", flt, "--outdir", d, str(src)]
        if out_ext == "xlsx":
            cmd[cmd.index("--convert-to")] = "--infilter=HTML (StarCalc)"
            cmd += ["--convert-to", flt]
        try:
            subprocess.run(cmd, capture_output=True, timeout=120, check=True)
        except (subprocess.SubprocessError, OSError):
            return None
        out = Path(d) / f"in.{out_ext}"
        return out.read_bytes() if out.exists() else None


# ---------------------------------------------------------------- books (phase 2)
BOOK_UNITS = [
    ("الوحدة الأولى: الأعداد الصحيحة", [("الدرس الأول: مقارنة الأعداد الصحيحة", 2), ("الدرس الثاني: جمع الأعداد الصحيحة", 2), ("مراجعة الوحدة الأولى", 1)]),
    ("الوحدة الثانية: الكسور", [("الدرس الأول: الكسور العادية", 2), ("الدرس الثاني: الكسور العشرية", 1), ("اختبار الفصل", 1)]),
]
SENT = "هذه جملة شرح عن {t} تحتوي على معلومة مفيدة للطالبات في هذا الدرس رقم {i}."
DEFN = "{t} هو موضوع أساسي في الرياضيات تتعلمه الطالبات لحل مسائل كثيرة في حياتهن اليومية."          # a sentence the question maker can turn into a question


def book_pages(running=True):
    """The book as a list of pages, each a list of lines: a cover, a contents page (title, dots, page number) and one or two pages for every lesson."""
    pages = [["الرياضيات", "الصف الأول المتوسط", "الفصل الدراسي الأول"]]
    toc, number = ["فهرس المحتويات"], 3
    for unit, lessons in BOOK_UNITS:
        toc.append(f"{unit} ........ {number}")
        for title, n in lessons:
            toc.append(f"{title} ........ {number}")
            number += n
    toc.append(f"المراجع ........ {number}")
    pages.append(toc)
    for unit, lessons in BOOK_UNITS:
        first = True
        for title, n in lessons:
            for k in range(n):
                page = []
                if first:
                    page += [unit, "مقدمة الوحدة: في هذه الوحدة ستتعلمين موضوعات جديدة ومفيدة."]
                    first = False
                if k == 0:
                    page.append(title)
                page += [SENT.format(t=title.split(":")[-1].strip(), i=i + 1) for i in range(6)]
                if k == 0:
                    page.append(DEFN.format(t=title.split(":")[-1].strip()))
                pages.append(page)
    pages.append(["المراجع", "كتاب الرياضيات للصف الأول المتوسط، وزارة التعليم"])
    if running:
        for n, p in enumerate(pages[1:], start=1):
            p.insert(0, "الرياضيات - الصف الأول المتوسط")
            p.append(str(n + 1))
    return pages


def book_pdf(pages=None):
    """A real Arabic PDF printed by Chromium, one page of the book on each printed page."""
    from playwright.sync_api import sync_playwright
    pages = pages or book_pages()
    html = "<html dir=rtl lang=ar><body style='font-family:DejaVu Sans;font-size:16px'>" + "".join(
        "<div style='page-break-after:always'>%s</div>" % "".join("<p>%s</p>" % line for line in page) for page in pages) + "</body></html>"
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page()
        pg.set_content(html)
        data = pg.pdf()
        b.close()
    return data


def book_docx(headings=True):
    """The same book as a Word file; with headings=True the units are Heading 1 and the lessons Heading 2 (the way a book written in Word is built)."""
    body = ""
    for unit, lessons in BOOK_UNITS:
        body += _p(unit, "Heading1" if headings else None)
        for title, n in lessons:
            body += _p(title, "Heading2" if headings else None)
            body += "".join(_p(SENT.format(t=title.split(":")[-1].strip(), i=i + 1)) for i in range(4 * n))
    return docx_bytes(body)


# a book whose contents is a TABLE (topic | page) that runs over two printed pages, like a ministry book: the cells of a row are read one by one
TABLE_ROWS = [("المقدمة", 6), ("أولًا: السنة النبوية", 8), ("تعريف السنة النبوية ومنزلتها", 9), ("حفظ الله تعالى للسنة النبوية", 12),
              ("ثانيًا: الأحاديث", 21),
              ("الحديث الأول: «مثل ما بعثني الله به من الهدى والعلم…»", 22), ("الحديث الثاني: «من سن في الإسلام سنة حسنة…»", 26),
              ("الحديث الثالث: «إن الحلال بيّن وإن الحرام بيّن…»", 30), ("الحديث الرابع: «سبعة يظلهم الله في ظله…»", 33),
              None,
              ("الحديث الخامس: «من عادى لي وليًّا…»", 38), ("الحديث السادس: «لن يُنجّي أحدًا منكم عمله…»", 41),
              ("الحديث السابع: أن رجلًا قدم من جيشان، فسأل النبي عن شراب يشربونه بأرضهم من الذرة، يُقال له: المِزْر، فقال: «أو مسكر هو؟»…", 45),
              ("الحديث الثامن: «بينما رجل يمشي بطريق، وجد غصن شوك…»", 48)]


def table_book_pdf(foot=True):
    """The book of TABLE_ROWS printed by Chromium: the contents table (None is where the printed page ends), then a page for the introduction and one for each hadith."""
    from playwright.sync_api import sync_playwright

    def table(rows):
        return "<table><tr><th>الموضوع</th><th class=n>الصفحة</th></tr>" + "".join("<tr><td>%s</td><td class=n>%d</td></tr>" % r for r in rows) + "</table>"
    cut = TABLE_ROWS.index(None)
    first, second = TABLE_ROWS[:cut], TABLE_ROWS[cut + 1:]
    foot_html = "<p style='margin-top:30px'>وزارة التعليم<br>Ministry of Education<br>2025 - 1447</p>" if foot else ""
    pages = ["<h2>كتاب الحديث للمرحلة الثانوية</h2><p>وزارة التعليم</p>", "<p>تقديم قصير للكتاب.</p>", "<p>شكر وتقدير.</p>",
             "<h3>المحتويات</h3>" + table(first) + foot_html, table(second),
             "<h2>المقدمة</h2><p>" + "نص المقدمة الذي يشرح هدف الكتاب ومنهجه. " * 10 + "</p>"]
    for row in TABLE_ROWS:
        if row and row[0] != "المقدمة":
            label = row[0].split(":")[0] if row[0].startswith("الحديث") else row[0]
            pages.append("<h2>%s</h2><p>%s</p>" % (label, ("نص شرح %s وبيان معانيه وما يستفاد منه في السلوك. " % label) * 12))
    html = ("<html dir=rtl lang=ar><style>body{font-family:'DejaVu Sans';font-size:15px} table{width:100%%;border-collapse:collapse} td,th{border:1px solid #888;padding:5px}"
            " td.n,th.n{width:60px;text-align:center} .pg{page-break-after:always}</style><body>" + "".join("<div class=pg>%s</div>" % p for p in pages) + "</body></html>")
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page()
        pg.set_content(html)
        data = pg.pdf(format="A4")
        b.close()
    return data
