"""Version 5, phase 2 through the server: the books a teacher teaches from, her timetable, her term and holidays, and the plan of every class."""
import datetime
import functools
import io
import re
import unittest
from unittest import mock

from tests import files5 as X
from tests.test_app import Base

D = datetime.date

OUTLINE = """الوحدة الأولى: الأعداد
الدرس الأول: المقارنة
الدرس الثاني: الجمع
الدرس الثالث: الطرح
الوحدة الثانية: الكسور
الدرس الأول: العادية
الدرس الثاني: العشرية
مراجعة الوحدة الثانية"""

TERM = ("2026-09-06", "2026-12-17")          # the first day is a Sunday


@functools.lru_cache(maxsize=1)
def pdf_book():
    try:
        return X.book_pdf()
    except Exception as exc:          # no Chromium here
        raise unittest.SkipTest(f"no PDF printer: {exc}")


def titles(units):
    return [[l["title"] for l in u["lessons"]] for u in units]


class Phase2(Base):
    def setUp(self):
        super().setUp()
        from app import curriculum, schedule, students
        for lim in (curriculum.book_limit, curriculum.outline_limit, curriculum.reread_limit, schedule.import_limit, students.import_limit):
            lim.hits.clear()
        self.today = D(2026, 9, 6)          # a Sunday
        self.clock = datetime.time(6, 0)
        for target, fake in (("app.classroom.today_date", lambda: self.today),
                             ("app.classroom.now_local", lambda: datetime.datetime.combine(self.today, self.clock, tzinfo=datetime.timezone(datetime.timedelta(hours=3))))):
            p = mock.patch(target, side_effect=fake)
            p.start()
            self.addCleanup(p.stop)
        self.c = self.client()
        self.register(self.c)

    # ---------------------------------------------------------------- small helpers
    def api(self, method, url, data=None, c=None):
        return self.j(c or self.c, method, url, data)

    def post_book(self, name, data, c=None, title=None):
        c = c or self.c
        form = {"file": (io.BytesIO(data), name)}
        if title:
            form["title"] = title
        return c.post("/api/books", data=form, headers={"X-CSRF": self.token(c)}, content_type="multipart/form-data")

    def book(self, bid, c=None):
        return (c or self.c).get(f"/api/books/{bid}").get_json()

    def outline_book(self, title="كتاب الرياضيات", text=OUTLINE, c=None):
        r = self.api("post", "/api/books/outline", {"title": title, "text": text}, c)
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        return r.get_json()["id"]

    def make_class(self, name="الصف الأول أ", c=None):
        r = self.api("post", "/api/classes", {"name": name}, c)
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        return r.get_json()["id"]

    def make_subject(self, name="الرياضيات", c=None):
        r = self.api("post", "/api/subjects", {"name": name}, c)
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        return r.get_json()["id"]

    def confirm(self, bid, class_ids=(), subject="الرياضيات", edit=None, c=None):
        """Confirm a book as it was read (optionally changed by edit(units)), linked to the given classes."""
        d = self.book(bid, c)
        units = [{"id": u["id"], "title": u["title"], "lessons": [{"id": l["id"], "title": l["title"], "periods": l["periods"], "kind": l["kind"]} for l in u["lessons"]]} for u in d["units"]]
        if edit:
            edit(units)
        r = self.api("put", f"/api/books/{bid}", {"title": d["title"], "subject": subject, "grade": d["grade"], "units": units, "class_ids": list(class_ids)}, c)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def set_term(self, starts=TERM[0], ends=TERM[1], c=None):
        r = self.api("put", "/api/calendar/term", {"starts": starts, "ends": ends}, c)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def set_slots(self, slots, c=None, **extra):
        r = self.api("put", "/api/schedule", {"slots": [{"day": d, "period": p, "class_id": ci, "subject_id": si} for d, p, ci, si in slots], **extra}, c)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def scenario(self, text=OUTLINE, slots=((0, 1), (2, 2)), term=True):
        """A class, the subject, a timetable with two periods a week, the term, and a confirmed book linked to the class."""
        cid, sid = self.make_class(), self.make_subject()
        self.set_slots([(d, p, cid, sid) for d, p in slots])
        if term:
            self.set_term()
        bid = self.outline_book(text=text)
        self.confirm(bid, [cid])
        return cid, sid, bid

    def plan(self, cid, sid, c=None):
        r = (c or self.c).get(f"/api/plan?class_id={cid}&subject_id={sid}")
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def build(self, cid, sid, c=None):
        r = self.api("post", "/api/plan/build", {"class_id": cid, "subject_id": sid}, c)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    def act(self, item, what, data=None, method="post", c=None):
        r = self.api(method, f"/api/plan/{item}" + (f"/{what}" if what else ""), data or {}, c)
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        return r.get_json()

    @staticmethod
    def where(item):
        pl = item["planned"]
        return (pl["first"]["date"], pl["first"]["period"], pl["last"]["date"], pl["last"]["period"]) if pl else None

    def count(self, sql, *args):
        return self.app.db.execute(sql, args).fetchone()[0]


# ================================================================ the books
class Books(Phase2):
    def test_a_pdf_book_is_read_and_proposed_but_not_yet_confirmed(self):
        r = self.post_book("math.pdf", pdf_book())
        self.assertEqual(r.status_code, 201)
        d = self.book(r.get_json()["id"])
        self.assertEqual((d["status"], d["subject"], d["grade"], d["pages"], d["confirmed"], d["kind"]), ("ready", "الرياضيات", "الأول المتوسط", 12, False, "pdf"))
        self.assertEqual(d["title"], "math")
        self.assertEqual([len(u["lessons"]) for u in d["units"]], [3, 3])
        self.assertEqual([l["kind"] for u in d["units"] for l in u["lessons"]], ["lesson", "lesson", "review", "lesson", "lesson", "exam"])
        self.assertTrue(all(l["has_text"] for u in d["units"] for l in u["lessons"]))
        self.assertEqual(d["units"][0]["lessons"][0]["first_page"], 3)

    def test_the_book_can_be_named_when_it_is_uploaded(self):
        bid = self.post_book("x.pdf", pdf_book(), title="  كتاب   الرياضيات  ").get_json()["id"]
        self.assertEqual(self.book(bid)["title"], "كتاب الرياضيات")

    def test_a_word_book_with_its_heading_styles(self):
        bid = self.post_book("math.docx", X.book_docx(True)).get_json()["id"]
        d = self.book(bid)
        self.assertEqual(d["status"], "ready")
        self.assertEqual([u["title"] for u in d["units"]], ["الوحدة الأولى: الأعداد الصحيحة", "الوحدة الثانية: الكسور"])
        self.assertEqual([len(u["lessons"]) for u in d["units"]], [3, 3])

    def test_reading_a_book_costs_her_nothing(self):
        self.post_book("math.docx", X.book_docx(True))
        self.assertEqual(self.count("SELECT COUNT(*) FROM lessons"), 0)
        self.assertEqual(self.count("SELECT COUNT(*) FROM lesson_usage"), 0)
        from app import billing
        user = self.app.db.execute("SELECT * FROM users").fetchone()
        self.assertEqual(billing.lesson_allowance(self.app.db, user)["used"], 0)

    def test_the_contents_typed_by_hand_make_a_book_with_no_file(self):
        bid = self.outline_book()
        d = self.book(bid)
        self.assertEqual((d["kind"], d["status"], d["pages"]), ("manual", "ready", 0))
        self.assertEqual(titles(d["units"]), [["الدرس الأول: المقارنة", "الدرس الثاني: الجمع", "الدرس الثالث: الطرح"], ["الدرس الأول: العادية", "الدرس الثاني: العشرية", "مراجعة الوحدة الثانية"]])
        self.assertEqual([l["kind"] for u in d["units"] for l in u["lessons"]][-1], "review")
        self.assertFalse(any(l["has_text"] for u in d["units"] for l in u["lessons"]))

    def test_a_typed_contents_needs_a_name_and_lessons(self):
        self.assertEqual(self.api("post", "/api/books/outline", {"title": "x", "text": OUTLINE}).status_code, 400)
        r = self.api("post", "/api/books/outline", {"title": "كتاب", "text": "   \n  "})
        self.assertEqual(r.status_code, 400)
        self.assertIn("دروسًا", r.get_json()["error"])
        self.assertEqual(self.api("post", "/api/books/outline", {"title": "كتاب"}).status_code, 400)

    def test_a_book_that_cannot_be_read_says_why(self):
        bid = self.post_book("bad.docx", b"PK\x03\x04 not really a word file").get_json()["id"]
        d = self.book(bid)
        self.assertEqual(d["status"], "failed")
        self.assertTrue(d["error"])
        self.assertEqual(self.c.get("/api/books").get_json()["books"][0]["status"], "failed")

    def test_a_book_with_no_contents_is_kept_empty_with_a_hint(self):
        flat = X.docx_bytes("".join(X._p(f"جملة عادية رقم {i} تتحدث عن موضوع ما دون عناوين ولا فهرس في هذا الملف.") for i in range(10)))
        bid = self.post_book("plain.docx", flat).get_json()["id"]
        d = self.book(bid)
        self.assertEqual((d["status"], d["lessons"]), ("ready", 0))
        self.assertIn("الصقي الفهرس", d["warn"])
        # pasting the contents fills it
        r = self.api("post", f"/api/books/{bid}/outline", {"text": OUTLINE})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["lessons"], 6)
        self.assertEqual(r.get_json()["warn"], "")

    def test_a_book_is_read_again_from_its_file(self):
        flat = X.docx_bytes("".join(X._p(f"جملة عادية رقم {i} تتحدث عن موضوع ما دون عناوين ولا فهرس في هذا الملف.") for i in range(10)))
        bid = self.post_book("plain.docx", flat).get_json()["id"]
        self.assertEqual(self.book(bid)["lessons"], 0)
        self.api("post", f"/api/books/{bid}/outline", {"text": OUTLINE})                      # she pasted a contents over it
        self.assertEqual(self.book(bid)["lessons"], 6)
        r = self.api("post", f"/api/books/{bid}/reread")
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        d = self.book(bid)
        self.assertEqual((d["status"], d["lessons"]), ("ready", 0))                           # what the file gives now (nothing) replaces what the screen had
        self.assertIn("الصقي الفهرس", d["warn"])

    def test_a_book_read_again_gets_what_the_reader_finds_in_the_file(self):
        bid = self.post_book("math.docx", X.book_docx(True)).get_json()["id"]
        self.api("post", f"/api/books/{bid}/outline", {"text": "درس وحيد\nدرس آخر"})
        self.assertEqual(self.book(bid)["lessons"], 2)
        self.assertEqual(self.api("post", f"/api/books/{bid}/reread").status_code, 200)
        d = self.book(bid)
        self.assertEqual([len(u["lessons"]) for u in d["units"]], [3, 3])
        self.assertEqual((d["status"], d["error"]), ("ready", ""))

    def test_a_book_cannot_be_read_again_when_that_would_replace_what_she_approved_or_there_is_nothing_to_read(self):
        bid = self.post_book("math.docx", X.book_docx(True)).get_json()["id"]
        d = self.book(bid)
        body = {"title": d["title"], "subject": "الرياضيات", "grade": "", "units": [{"id": u["id"], "title": u["title"], "lessons": [{"id": l["id"], "title": l["title"], "periods": 1, "kind": l["kind"]} for l in u["lessons"]]} for u in d["units"]], "class_ids": []}
        self.assertEqual(self.api("put", f"/api/books/{bid}", body).status_code, 200)
        r = self.api("post", f"/api/books/{bid}/reread")
        self.assertEqual(r.status_code, 409)
        self.assertIn("مؤكَّد", r.get_json()["error"])
        self.assertEqual(self.book(bid)["lessons"], 6)
        typed = self.outline_book()
        r = self.api("post", f"/api/books/{typed}/reread")
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.book(typed)["lessons"], 6)

    def test_a_book_whose_file_is_gone_says_so_and_keeps_its_lessons(self):
        bid = self.post_book("math.docx", X.book_docx(True)).get_json()["id"]
        stored = self.app.db.execute("SELECT stored_name FROM books WHERE id = ?", (bid,)).fetchone()[0]
        (self.app.cfg.upload_dir / stored).unlink()
        r = self.api("post", f"/api/books/{bid}/reread")
        self.assertEqual(r.status_code, 410)
        self.assertEqual((self.book(bid)["status"], self.book(bid)["lessons"]), ("ready", 6))

    def test_a_book_being_read_is_not_started_twice_and_reading_again_is_limited(self):
        bid = self.post_book("math.docx", X.book_docx(True)).get_json()["id"]
        self.app.db.execute("UPDATE books SET status = 'processing' WHERE id = ?", (bid,))
        self.app.db.commit()
        self.assertEqual(self.api("post", f"/api/books/{bid}/reread").status_code, 409)
        self.app.db.execute("UPDATE books SET status = 'ready' WHERE id = ?", (bid,))
        self.app.db.commit()
        codes = [self.api("post", f"/api/books/{bid}/reread").status_code for _ in range(22)]
        self.assertEqual(codes[:20], [200] * 20)
        self.assertEqual(codes[20:], [429, 429])

    def test_refusals_come_as_sentences(self):
        self.assertEqual(self.c.post("/api/books", data={}, headers={"X-CSRF": self.token(self.c)}, content_type="multipart/form-data").status_code, 400)
        self.assertEqual(self.post_book("a.docx", b"").status_code, 400)
        self.assertEqual(self.post_book("a.exe", b"MZ\x90 ....").status_code, 400)
        r = self.post_book("old.doc", b"\xd0\xcf\x11\xe0 old word")
        self.assertEqual(r.status_code, 400)
        self.assertIn("docx", r.get_json()["error"])
        self.assertEqual(self.count("SELECT COUNT(*) FROM books"), 0)

    def test_the_size_limit_of_a_book_is_its_own(self):
        self.app.cfg.max_book_mb = 1
        r = self.post_book("big.docx", b"PK\x03\x04" + b"a" * (1024 * 1024 + 10))
        self.assertEqual(r.status_code, 413)
        self.assertIn("1 ميجابايت", r.get_json()["error"])
        self.assertEqual(self.count("SELECT COUNT(*) FROM books"), 0)
        self.assertEqual(self.app.cfg.max_upload_mb, 15)          # a lesson file keeps its own limit
        # a book above the limit the whole request may hold is refused by the server itself, still with a sentence the screen can show
        r = self.post_book("huge.docx", b"PK\x03\x04" + b"a" * (3 * 1024 * 1024))
        self.assertEqual(r.status_code, 413)
        self.assertTrue(r.is_json)
        self.assertIn("1 ميجابايت", r.get_json()["error"])

    def test_a_book_may_be_bigger_than_a_lesson_file(self):
        self.app.cfg.max_book_mb = 20
        data = X.book_docx(True) + b"\x00" * (17 * 1024 * 1024)          # zip tolerates trailing bytes; bigger than the 15 MB of a lesson
        r = self.post_book("big.docx", data)
        self.assertEqual(r.status_code, 201)

    def test_how_many_books_and_how_often(self):
        from app import curriculum
        for i in range(curriculum.MAX_BOOKS):
            self.outline_book(f"كتاب {i}")
        r = self.api("post", "/api/books/outline", {"title": "واحد زيادة", "text": OUTLINE})
        self.assertEqual(r.status_code, 400)
        self.assertIn(str(curriculum.MAX_BOOKS), r.get_json()["error"])
        self.assertEqual(self.post_book("a.docx", X.book_docx()).status_code, 400)
        curriculum.book_limit.hits.clear()
        d = self.client()
        self.register(d, "other@example.com")
        codes = [self.post_book("a.exe", b"MZ", c=d).status_code for _ in range(11)]
        self.assertEqual(codes[:10], [400] * 10)
        self.assertEqual(codes[10], 429)

    def test_a_book_is_hers_alone(self):
        bid = self.outline_book()
        other = self.client()
        self.register(other, "other@example.com")
        self.assertEqual(other.get("/api/books").get_json()["books"], [])
        for method, url, data in (("get", f"/api/books/{bid}", None), ("put", f"/api/books/{bid}", {"title": "x", "subject": "y", "units": []}),
                                  ("delete", f"/api/books/{bid}", None), ("post", f"/api/books/{bid}/outline", {"text": OUTLINE}),
                                  ("post", f"/api/books/{bid}/reread", None)):
            self.assertEqual(self.api(method, url, data, other).status_code, 404, (method, url))
        self.assertEqual(other.get(f"/curriculum/{bid}").status_code, 404)
        self.assertEqual(self.book(bid)["lessons"], 6)

    def test_every_book_call_needs_a_signed_in_teacher_and_the_form_token(self):
        bid = self.outline_book()
        anon = self.client()
        self.assertEqual(anon.get("/api/books").status_code, 401)
        self.assertEqual(self.api("get", f"/api/books/{bid}", None, anon).status_code, 401)
        self.assertEqual(self.c.post("/api/books/outline", json={"title": "كتاب", "text": OUTLINE}).status_code, 403)
        self.assertEqual(self.c.delete(f"/api/books/{bid}").status_code, 403)
        self.assertEqual(self.c.post(f"/api/books/{bid}/reread").status_code, 403)
        self.assertEqual(self.api("post", f"/api/books/{bid}/reread", None, anon).status_code, 401)

    # ---------------------------------------------------------------- confirming and editing
    def test_confirming_keeps_what_she_left_and_changes_what_she_changed(self):
        bid = self.post_book("math.docx", X.book_docx(True)).get_json()["id"]
        before = self.book(bid)
        keep = before["units"][0]["lessons"][1]
        gone = before["units"][0]["lessons"][0]
        text_before = self.app.db.execute("SELECT text FROM book_lessons WHERE id = ?", (keep["id"],)).fetchone()[0]
        self.assertTrue(text_before)

        def edit(units):
            units[0]["lessons"].pop(0)                                                    # leave one lesson out
            units[0]["lessons"][0]["title"] = "  جمع   الأعداد  "                              # rename
            units[0]["lessons"][0]["periods"] = 3
            units[0]["lessons"][1].update(periods=99, kind="review")                        # clamped to the most a lesson may take
            units[1]["lessons"][0]["periods"] = 0                                          # at least one
            units[1]["lessons"].append({"title": "درس جديد", "periods": 2})                # a new lesson has no id
            units.append({"title": "الوحدة الثالثة", "lessons": [{"title": "الهندسة"}]})   # a new unit
            units[0]["lessons"], units[1]["lessons"] = units[0]["lessons"], units[1]["lessons"][::-1]          # and the second unit's lessons turn around

        d = self.confirm(bid, edit=edit)
        self.assertTrue(d["confirmed"])
        self.assertEqual(d["units"][0]["lessons"][0]["title"], "جمع الأعداد")
        self.assertEqual([l["periods"] for l in d["units"][0]["lessons"]], [3, 6])
        self.assertEqual(d["units"][0]["lessons"][1]["kind"], "review")
        self.assertEqual(d["units"][1]["lessons"][-1]["periods"], 1)          # the lesson set to 0 is 1 (it moved to the end when the lessons turned around)
        self.assertEqual([l["title"] for l in d["units"][1]["lessons"]][0], "درس جديد")
        self.assertEqual([u["title"] for u in d["units"]][-1], "الوحدة الثالثة")
        self.assertEqual(d["lessons"], 6 - 1 + 1 + 1)
        ids = {l["id"] for u in d["units"] for l in u["lessons"]}
        self.assertIn(keep["id"], ids)
        self.assertNotIn(gone["id"], ids)
        # a lesson that stays keeps its text and its id
        self.assertEqual(self.app.db.execute("SELECT text FROM book_lessons WHERE id = ?", (keep["id"],)).fetchone()[0], text_before)
        self.assertEqual(self.count("SELECT COUNT(*) FROM book_lessons WHERE id = ?", gone["id"]), 0)
        # the order she gave is the order in the book
        pos = [r[0] for r in self.app.db.execute("SELECT position FROM book_lessons WHERE book_id = ? ORDER BY position", (bid,))]
        self.assertEqual(pos, list(range(len(pos))))

    def test_what_a_book_needs_to_be_confirmed(self):
        bid = self.outline_book()
        d = self.book(bid)
        units = [{"id": u["id"], "title": u["title"], "lessons": [{"id": l["id"], "title": l["title"]} for l in u["lessons"]]} for u in d["units"]]
        ok = {"title": "كتاب", "subject": "الرياضيات", "units": units}
        for change, why in (({"title": "x"}, "name"), ({"subject": ""}, "subject"), ({"units": []}, "no lessons"), ({"units": [{"title": "u", "lessons": []}]}, "no lesson"),
                            ({"units": "nope"}, "not a list"), ({"units": [5]}, "bad unit"), ({"units": [{"title": "u", "lessons": [7]}]}, "bad lesson"),
                            ({"units": [{"title": "u", "lessons": [{"title": ""}]}]}, "only empty titles")):
            r = self.api("put", f"/api/books/{bid}", {**ok, **change})
            self.assertEqual(r.status_code, 400, why)
            self.assertTrue(r.get_json()["error"], why)
        self.assertFalse(self.book(bid)["confirmed"])          # nothing was saved by the refusals
        self.assertEqual(self.book(bid)["lessons"], 6)

    def test_too_many_lessons_are_refused(self):
        from app import bookread
        bid = self.outline_book()
        many = [{"title": "u", "lessons": [{"title": f"درس {i}"} for i in range(bookread.MAX_LESSONS + 1)]}]
        r = self.api("put", f"/api/books/{bid}", {"title": "كتاب", "subject": "الرياضيات", "units": many})
        self.assertEqual(r.status_code, 400)
        self.assertIn(str(bookread.MAX_LESSONS), r.get_json()["error"])
        self.assertEqual(self.book(bid)["lessons"], 6)

    def test_the_book_is_linked_to_her_classes_only(self):
        a, b = self.make_class("الصف الأول أ"), self.make_class("الصف الأول ب")
        bid = self.outline_book()
        d = self.confirm(bid, [a])
        self.assertEqual([(c["name"], c["linked"]) for c in d["classes"]], [("الصف الأول أ", True), ("الصف الأول ب", False)])
        self.assertEqual(self.count("SELECT COUNT(*) FROM class_subjects WHERE book_id = ?", bid), 1)
        d = self.confirm(bid, [a, b])
        self.assertTrue(all(c["linked"] for c in d["classes"]))
        d = self.confirm(bid, [b])
        self.assertEqual([c["linked"] for c in d["classes"]], [False, True])
        other = self.client()
        self.register(other, "other@example.com")
        foreign = self.make_class("فصل معلمة أخرى", other)
        r = self.api("put", f"/api/books/{bid}", {"title": "كتاب", "subject": "الرياضيات", "units": [{"title": "", "lessons": [{"title": "درس"}]}], "class_ids": [foreign]})
        self.assertEqual(r.status_code, 404)
        self.assertEqual(self.book(bid)["lessons"], 6)          # the refused request changed nothing

    def test_a_class_has_one_book_for_a_subject(self):
        a = self.make_class()
        first, second = self.outline_book("الكتاب الأول"), self.outline_book("الكتاب الثاني")
        self.confirm(first, [a])
        d = self.confirm(second, [a])
        self.assertEqual(self.count("SELECT COUNT(*) FROM class_subjects WHERE class_id = ? AND book_id = ?", a, second), 1)
        self.assertEqual(self.count("SELECT COUNT(*) FROM class_subjects WHERE class_id = ? AND book_id = ?", a, first), 0)
        self.assertEqual(self.count("SELECT COUNT(*) FROM class_subjects WHERE class_id = ?", a), 1)
        self.assertEqual(self.book(first)["classes"][0]["other"], "الكتاب الثاني")          # the screen can say «يستخدم كتابًا آخر»
        self.assertTrue(d["classes"][0]["linked"])
        listed = {b["title"]: b["classes"] for b in self.c.get("/api/books").get_json()["books"]}
        self.assertEqual(listed, {"الكتاب الأول": [], "الكتاب الثاني": ["الصف الأول أ"]})

    def test_the_pasted_contents_replace_only_an_unconfirmed_book(self):
        bid = self.outline_book()
        self.assertEqual(self.api("post", f"/api/books/{bid}/outline", {"text": "الجمع\nالطرح"}).get_json()["lessons"], 2)
        self.confirm(bid)
        r = self.api("post", f"/api/books/{bid}/outline", {"text": OUTLINE})
        self.assertEqual(r.status_code, 409)
        self.assertEqual(self.book(bid)["lessons"], 2)
        fresh = self.outline_book("ثانٍ")
        self.assertEqual(self.api("post", f"/api/books/{fresh}/outline", {"text": " "}).status_code, 400)
        self.app.db.execute("UPDATE books SET status = 'processing' WHERE id = ?", (fresh,))
        self.app.db.commit()
        self.assertEqual(self.api("post", f"/api/books/{fresh}/outline", {"text": OUTLINE}).status_code, 409)
        self.assertEqual(self.api("put", f"/api/books/{fresh}", {"title": "كتاب", "subject": "الرياضيات", "units": [{"lessons": [{"title": "د"}]}]}).status_code, 409)

    def test_deleting_a_book_removes_its_file_and_keeps_her_classes_and_lessons(self):
        cid, sid, bid = self.scenario()
        self.build(cid, sid)
        self.assertEqual(self.count("SELECT COUNT(*) FROM plan_items"), 6)
        bid2 = self.post_book("math.docx", X.book_docx(True)).get_json()["id"]
        stored = self.app.db.execute("SELECT stored_name FROM books WHERE id = ?", (bid2,)).fetchone()[0]
        path = self.app.cfg.upload_dir / stored
        self.assertTrue(path.exists())
        self.assertEqual(self.api("delete", f"/api/books/{bid2}").status_code, 200)
        self.assertFalse(path.exists())
        self.assertEqual(self.count("SELECT COUNT(*) FROM book_lessons WHERE book_id = ?", bid2), 0)
        self.assertEqual(self.api("delete", f"/api/books/{bid}").status_code, 200)
        self.assertEqual(self.count("SELECT COUNT(*) FROM plan_items"), 0)                       # the plan was made from the book
        self.assertEqual(self.count("SELECT COUNT(*) FROM class_subjects WHERE class_id = ? AND subject_id = ?", cid, sid), 1)          # she still teaches the class
        self.assertIsNone(self.app.db.execute("SELECT book_id FROM class_subjects WHERE class_id = ?", (cid,)).fetchone()[0])
        self.assertEqual(self.count("SELECT COUNT(*) FROM schedule_slots"), 2)
        self.assertEqual(self.api("get", f"/api/books/{bid}").status_code, 404)

    def test_deleting_the_account_removes_the_book_files(self):
        bid = self.post_book("math.docx", X.book_docx(True)).get_json()["id"]
        stored = self.app.db.execute("SELECT stored_name FROM books WHERE id = ?", (bid,)).fetchone()[0]
        self.assertTrue((self.app.cfg.upload_dir / stored).exists())
        self.assertEqual(self.api("post", "/api/me/delete", {"password": "Teacher-pass-1"}).status_code, 200)
        self.assertFalse((self.app.cfg.upload_dir / stored).exists())
        for table in ("books", "book_units", "book_lessons", "terms", "plan_items", "schedule_slots"):
            self.assertEqual(self.count(f"SELECT COUNT(*) FROM {table}"), 0, table)


# ================================================================ the timetable
class Schedule(Phase2):
    ACROSS = [["الحصة", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس"],
              ["الأولى 7:00-7:45", "أول/أ رياضيات", "", "ثاني/ب علوم", "", "أول/أ رياضيات"],
              ["الثانية 7:45-8:30", "", "أول/ب رياضيات", "", "أول/أ علوم", ""],
              ["الثالثة 8:30-9:15", "فراغ", "-", "أول/أ رياضيات", "أول/ب رياضيات", "ثاني/ب علوم"]]

    def imp(self, name, data, c=None):
        c = c or self.c
        return c.post("/api/schedule/import", data={"file": (io.BytesIO(data), name)}, headers={"X-CSRF": self.token(c)}, content_type="multipart/form-data")

    def test_an_empty_timetable_has_a_normal_week(self):
        d = self.c.get("/api/schedule").get_json()
        self.assertEqual((d["days"], d["periods"], d["slots"], d["times"]), ([0, 1, 2, 3, 4], 7, [], {}))
        self.assertEqual(d["day_names"][0], "الأحد")

    def test_filling_the_grid_by_hand(self):
        a, b = self.make_class("الصف الأول أ"), self.make_class("الصف الأول ب")
        m, s = self.make_subject("الرياضيات"), self.make_subject("العلوم")
        d = self.set_slots([(0, 1, a, m), (0, 2, b, m), (2, 3, a, s), (6, 4, b, s)], periods=8, times={"1": {"starts": "7:00", "ends": "07:45"}, "2": {"starts": "25:00", "ends": "x"}})
        self.assertEqual([(x["day"], x["period"], x["class_id"], x["subject_id"]) for x in d["slots"]], [(0, 1, a, m), (0, 2, b, m), (2, 3, a, s), (6, 4, b, s)])
        self.assertEqual(d["periods"], 8)
        self.assertEqual(d["days"], [0, 1, 2, 3, 4, 6])          # Saturday was used, so it is shown
        self.assertEqual(d["times"], {"1": {"starts": "07:00", "ends": "07:45"}})          # a time that is not a time is left out
        # a class and a subject that meet in her timetable are the ones she teaches
        linked = {(r["class_id"], r["subject_id"]) for r in self.app.db.execute("SELECT class_id, subject_id FROM class_subjects")}
        self.assertEqual(linked, {(a, m), (b, m), (a, s), (b, s)})
        # saving again replaces the old timetable
        d = self.set_slots([(1, 1, a, m)])
        self.assertEqual(len(d["slots"]), 1)
        self.assertEqual(self.count("SELECT COUNT(*) FROM schedule_times"), 0)

    def test_the_grid_grows_to_hold_a_period_beyond_the_default(self):
        a, m = self.make_class(), self.make_subject()
        self.assertEqual(self.set_slots([(0, 11, a, m)])["periods"], 11)

    def test_a_bad_timetable_is_refused_and_nothing_changes(self):
        a, m = self.make_class(), self.make_subject()
        self.set_slots([(0, 1, a, m)])
        other = self.client()
        self.register(other, "other@example.com")
        foreign_class, foreign_subject = self.make_class("فصل آخر", other), self.make_subject("مادة أخرى", other)
        row = lambda **k: {"day": 0, "period": 2, "class_id": a, "subject_id": m, **k}
        cases = [({"slots": "no"}, 400), ({"slots": [5]}, 400), ({"slots": [row(day=7)]}, 400), ({"slots": [row(period=0)]}, 400), ({"slots": [row(period=13)]}, 400),
                 ({"slots": [row(), row()]}, 400), ({"slots": [row(class_id=foreign_class)]}, 404), ({"slots": [row(subject_id=foreign_subject)]}, 404),
                 ({"slots": [row(class_id=99999)]}, 404), ({"slots": [row()] * 85}, 400)]
        for body, code in cases:
            self.assertEqual(self.api("put", "/api/schedule", body).status_code, code, body)
        self.assertEqual([(s["day"], s["period"]) for s in self.c.get("/api/schedule").get_json()["slots"]], [(0, 1)])

    def test_a_timetable_is_hers_alone(self):
        a, m = self.make_class(), self.make_subject()
        self.set_slots([(0, 1, a, m)])
        other = self.client()
        self.register(other, "other@example.com")
        d = other.get("/api/schedule").get_json()
        self.assertEqual((d["slots"], d["classes"], d["subjects"]), ([], [], []))

    # ---------------------------------------------------------------- importing a file
    def test_a_timetable_file_is_shown_before_anything_is_saved(self):
        a = self.make_class("الصف الأول أ")
        self.make_class("الصف الأول ب")
        self.make_subject("الرياضيات")
        r = self.imp("جدول.xlsx", X.xlsx_bytes({"جدول": self.ACROSS}))
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        d = r.get_json()
        self.assertEqual(len(d["cells"]), 8)
        first = next(c for c in d["cells"] if (c["day"], c["period"]) == (0, 1))
        self.assertEqual((first["class_id"], first["subject_id"], first["subject_name"]), (a, d["subjects"][0]["id"], "الرياضيات"))
        unknown = next(c for c in d["cells"] if c["class_name"] == "ثاني/ب")          # a class she has not made yet
        self.assertIsNone(unknown["class_id"])
        self.assertEqual(d["times"]["1"], {"starts": "07:00", "ends": "07:45"})
        self.assertEqual(d["periods"], 3)
        self.assertEqual(self.count("SELECT COUNT(*) FROM schedule_slots"), 0)          # nothing saved yet
        self.assertEqual(self.count("SELECT COUNT(*) FROM classes"), 2)

    def test_confirming_saves_the_timetable_and_makes_the_new_classes_and_subjects(self):
        a = self.make_class("الصف الأول أ")
        d = self.imp("جدول.xlsx", X.xlsx_bytes({"جدول": self.ACROSS})).get_json()
        r = self.api("post", "/api/schedule/import/confirm", {"cells": d["cells"], "times": d["times"], "periods": d["periods"]})
        self.assertEqual(r.status_code, 200, r.get_data(as_text=True))
        out = r.get_json()
        self.assertEqual(len(out["slots"]), 8)
        names = sorted(c["name"] for c in out["classes"])
        self.assertIn("ثاني/ب", names)
        self.assertIn(a, [c["id"] for c in out["classes"]])
        self.assertIn("العلوم", [s["name"] for s in out["subjects"]])
        self.assertEqual(out["times"]["2"], {"starts": "07:45", "ends": "08:30"})
        self.assertEqual(self.count("SELECT COUNT(DISTINCT class_id || '-' || subject_id) FROM class_subjects"), self.count("SELECT COUNT(DISTINCT class_id || '-' || subject_id) FROM schedule_slots"))

    def test_the_teacher_can_correct_a_cell_before_confirming(self):
        a = self.make_class("الصف الأول أ")
        m = self.make_subject("الرياضيات")
        cells = [{"day": 0, "period": 1, "class_id": a, "subject_id": m}, {"day": 1, "period": 2, "class_name": "الصف الثاني أ", "subject_name": "العلوم"}]
        out = self.api("post", "/api/schedule/import/confirm", {"cells": cells}).get_json()
        self.assertEqual(len(out["slots"]), 2)
        self.assertEqual(sorted(c["name"] for c in out["classes"]), ["الصف الأول أ", "الصف الثاني أ"])
        # the same class name typed again is the class she has, not a second one
        out = self.api("post", "/api/schedule/import/confirm", {"cells": [{"day": 3, "period": 1, "class_name": "الصف الثاني أ", "subject_name": "الرياضيات"}]}).get_json()
        self.assertEqual(len(out["classes"]), 2)
        self.assertEqual(len(out["slots"]), 1)

    def test_a_bad_confirmation_changes_nothing_at_all(self):
        a = self.make_class("الصف الأول أ")
        m = self.make_subject("الرياضيات")
        self.set_slots([(0, 1, a, m)])
        other = self.client()
        self.register(other, "other@example.com")
        foreign = self.make_class("فصل آخر", other)
        good = {"day": 1, "period": 1, "class_name": "فصل جديد", "subject_name": "العلوم"}
        for cells, code in (([], 400), ("no", 400), ([good, {"day": 9, "period": 1, "class_name": "ب ب", "subject_name": "علوم"}], 400),
                            ([good, {"day": 1, "period": 1, "class_name": "ب ب", "subject_name": "علوم"}], 400),          # the same cell twice
                            ([good, {"day": 2, "period": 1, "class_name": "ب ب"}], 400),                                  # no subject
                            ([good, {"day": 2, "period": 1, "class_name": "x", "subject_name": "علوم"}], 400),             # a class name that is not a name
                            ([good, {"day": 2, "period": 1, "class_id": foreign, "subject_id": m}], 404), ([5], 400)):
            self.assertEqual(self.api("post", "/api/schedule/import/confirm", {"cells": cells}).status_code, code, cells)
            self.assertEqual(self.count("SELECT COUNT(*) FROM classes WHERE user_id = (SELECT id FROM users WHERE email = 'a@example.com')"), 1, cells)          # «فصل جديد» was not left behind
            self.assertEqual(self.count("SELECT COUNT(*) FROM schedule_slots"), 1, cells)

    def test_the_other_ways_a_timetable_comes(self):
        word = X.docx_bytes(X._p("جدول المعلمة") + X._tbl(self.ACROSS))
        for name, data in (("t.docx", word), ("t.csv", "\n".join(",".join(r) for r in self.ACROSS).encode("utf-8-sig")),
                           ("t.txt", "الأحد   أول/أ رياضيات   ثاني/ب علوم\nالاثنين   أول/ب رياضيات\nالثلاثاء   أول/أ رياضيات".encode())):
            r = self.imp(name, data)
            self.assertEqual(r.status_code, 200, (name, r.get_data(as_text=True)))
            self.assertGreaterEqual(len(r.get_json()["cells"]), 4, name)

    def test_what_is_not_a_timetable_is_a_sentence(self):
        self.assertEqual(self.imp("a.txt", "مرحبا\nهذا نص عادي".encode()).status_code, 400)
        self.assertIn("جدول", self.imp("a.txt", "مرحبا\nهذا نص عادي".encode()).get_json()["error"])
        r = self.imp("a.xls", b"\xd0\xcf\x11\xe0 old")
        self.assertEqual(r.status_code, 400)
        self.assertIn("xlsx", r.get_json()["error"])
        self.assertEqual(self.imp("a.exe", b"MZ.....").status_code, 400)
        self.assertEqual(self.imp("a.xlsx", b"").status_code, 400)
        self.assertEqual(self.c.post("/api/schedule/import", data={}, headers={"X-CSRF": self.token(self.c)}, content_type="multipart/form-data").status_code, 400)
        big = self.imp("a.txt", b"a" * (10 * 1024 * 1024 + 5))
        self.assertEqual(big.status_code, 413)

    def test_reading_timetables_is_limited_per_hour_and_needs_the_token(self):
        from app import schedule
        for _ in range(30):
            self.imp("a.txt", b"x")
        self.assertEqual(self.imp("a.txt", b"x").status_code, 429)
        schedule.import_limit.hits.clear()
        self.assertEqual(self.c.post("/api/schedule/import", data={"file": (io.BytesIO(b"x"), "a.txt")}, content_type="multipart/form-data").status_code, 403)
        anon = self.client()
        self.assertEqual(anon.post("/api/schedule/import", data={"file": (io.BytesIO(b"x"), "a.txt")}, headers={"X-CSRF": self.token(anon)}, content_type="multipart/form-data").status_code, 401)


# ================================================================ the term and its holidays
class Calendar(Phase2):
    def test_there_is_no_term_until_she_enters_one(self):
        d = self.c.get("/api/calendar").get_json()
        self.assertIsNone(d["term"])
        self.assertEqual((d["ranges"], d["holidays"], d["today"]), ([], 0, "2026-09-06"))

    def test_the_first_and_last_day(self):
        d = self.set_term()
        self.assertEqual((d["term"]["starts"], d["term"]["ends"], d["term"]["weeks"]), (TERM[0], TERM[1], 15))
        self.assertEqual(d["term"]["name"], "الفصل الدراسي")
        d = self.api("put", "/api/calendar/term", {"name": "الفصل الأول", "starts": "2026-09-13", "ends": "2026-12-24"}).get_json()
        self.assertEqual((d["term"]["name"], d["term"]["starts"]), ("الفصل الأول", "2026-09-13"))
        self.assertEqual(self.count("SELECT COUNT(*) FROM terms"), 1)          # changed, not a second one

    def test_dates_that_make_no_sense_are_refused(self):
        for body in ({}, {"starts": "2026-09-06"}, {"starts": "no", "ends": "2026-12-01"}, {"starts": "2026-12-01", "ends": "2026-09-06"}, {"starts": "2026-09-06", "ends": "2026-09-06"},
                     {"starts": "2026-01-01", "ends": "2026-12-31"}):
            r = self.api("put", "/api/calendar/term", body)
            self.assertEqual(r.status_code, 400, body)
            self.assertTrue(r.get_json()["error"])
        self.assertEqual(self.count("SELECT COUNT(*) FROM terms"), 0)

    def test_holidays_are_entered_once_as_a_range(self):
        self.set_term()
        d = self.api("post", "/api/calendar/holidays", {"from": "2026-09-23", "label": "اليوم الوطني"}).get_json()
        self.assertEqual((d["holidays"], d["ranges"][0]["label"], d["ranges"][0]["days"]), (1, "اليوم الوطني", 1))
        d = self.api("post", "/api/calendar/holidays", {"from": "2026-10-04", "to": "2026-10-08", "label": "إجازة"}).get_json()
        self.assertEqual(d["holidays"], 6)
        self.assertEqual([(r["label"], r["from"], r["to"], r["days"]) for r in d["ranges"]], [("اليوم الوطني", "2026-09-23", "2026-09-23", 1), ("إجازة", "2026-10-04", "2026-10-08", 5)])
        # the days next to a range with the same name join it
        d = self.api("post", "/api/calendar/holidays", {"from": "2026-10-09", "to": "2026-10-10", "label": "إجازة"}).get_json()
        self.assertEqual([(r["from"], r["to"], r["days"]) for r in d["ranges"] if r["label"] == "إجازة"], [("2026-10-04", "2026-10-10", 7)])
        self.assertEqual(d["ranges"][-1]["from_text"], "الأحد 4 أكتوبر 2026")

    def test_a_day_entered_twice_is_one_day_with_the_last_name(self):
        self.set_term()
        self.api("post", "/api/calendar/holidays", {"from": "2026-09-23", "label": "أ"})
        d = self.api("post", "/api/calendar/holidays", {"from": "2026-09-23", "label": "ب"}).get_json()
        self.assertEqual((d["holidays"], d["ranges"][0]["label"]), (1, "ب"))

    def test_holidays_need_a_term_and_days_inside_it(self):
        self.assertEqual(self.api("post", "/api/calendar/holidays", {"from": "2026-09-23"}).status_code, 400)
        self.set_term()
        for body in ({}, {"from": "no"}, {"from": "2026-10-05", "to": "2026-10-01"}, {"from": "2027-03-01"}, {"from": "2026-01-01", "to": "2026-05-01"}, {"from": "2026-09-06", "to": "2027-03-01"}):
            r = self.api("post", "/api/calendar/holidays", body)
            self.assertEqual(r.status_code, 400, body)
        # the part of a range that is inside the term is kept
        d = self.api("post", "/api/calendar/holidays", {"from": "2026-12-15", "to": "2026-12-25", "label": "ختام"}).get_json()
        self.assertEqual(d["holidays"], 3)

    def test_removing_holidays_removes_only_hers(self):
        self.set_term()
        d = self.api("post", "/api/calendar/holidays", {"from": "2026-10-04", "to": "2026-10-06", "label": "إجازة"}).get_json()
        ids = d["ranges"][0]["ids"]
        other = self.client()
        self.register(other, "other@example.com")
        self.set_term(c=other)
        self.assertEqual(self.api("delete", "/api/calendar/holidays", {"ids": ids}, other).get_json()["holidays"], 0)
        self.assertEqual(self.c.get("/api/calendar").get_json()["holidays"], 3)          # the other teacher's request did nothing to hers
        d = self.api("delete", "/api/calendar/holidays", {"ids": ids[:1]}).get_json()
        self.assertEqual(d["holidays"], 2)
        self.assertEqual(self.api("delete", "/api/calendar/holidays", {"ids": "no"}).get_json()["holidays"], 2)

    def test_shortening_the_term_drops_the_holidays_that_fell_outside_it(self):
        self.set_term()
        self.api("post", "/api/calendar/holidays", {"from": "2026-12-10", "to": "2026-12-12", "label": "إجازة"})
        self.api("post", "/api/calendar/holidays", {"from": "2026-09-23", "label": "وطني"})
        d = self.set_term(ends="2026-12-11")
        self.assertEqual(d["holidays"], 3)          # 23 Sep, 10 Dec and 11 Dec

    def test_the_term_that_holds_today_is_the_current_one(self):
        from app import terms
        db = self.app.db
        uid = db.execute("SELECT id FROM users").fetchone()[0]
        for name, a, b in (("قديم", "2026-01-01", "2026-05-30"), ("الحالي", "2026-09-01", "2026-12-30"), ("القادم", "2027-02-01", "2027-06-01")):
            db.execute("INSERT INTO terms(user_id, name, starts, ends, created_at) VALUES (?,?,?,?,0)", (uid, name, a, b))
        db.commit()
        self.assertEqual(terms.current(db, uid, D(2026, 9, 6))["name"], "الحالي")
        self.assertEqual(terms.current(db, uid, D(2026, 6, 20))["name"], "الحالي")          # between two terms: the nearest one that has not started
        self.assertEqual(terms.current(db, uid, D(2027, 1, 10))["name"], "القادم")
        self.assertEqual(terms.current(db, uid, D(2027, 8, 1))["name"], "القادم")          # after the last one: the last one
        db.execute("UPDATE terms SET archived = 1 WHERE name = 'القادم'")
        self.assertEqual(terms.current(db, uid, D(2027, 1, 10))["name"], "الحالي")          # an archived term is never the current one
        db.execute("UPDATE terms SET archived = 1")
        self.assertIsNone(terms.current(db, uid, D(2027, 1, 10)))

    def test_a_calendar_is_hers_alone(self):
        self.set_term()
        other = self.client()
        self.register(other, "other@example.com")
        self.assertIsNone(other.get("/api/calendar").get_json()["term"])


# ================================================================ the plan of a class
class PlanTests(Phase2):
    def test_the_plan_needs_a_term_and_a_book(self):
        cid, sid = self.make_class(), self.make_subject()
        self.assertEqual(self.api("post", "/api/plan/build", {"class_id": cid, "subject_id": sid}).status_code, 404)          # she does not teach it yet
        self.set_slots([(0, 1, cid, sid)])
        r = self.api("post", "/api/plan/build", {"class_id": cid, "subject_id": sid})
        self.assertEqual(r.status_code, 400)
        self.assertIn("الفصل الدراسي", r.get_json()["error"])
        self.assertEqual(self.plan(cid, sid)["need"], "term")
        self.set_term()
        self.assertEqual(self.plan(cid, sid)["need"], "book")
        r = self.api("post", "/api/plan/build", {"class_id": cid, "subject_id": sid})
        self.assertEqual(r.status_code, 400)
        self.assertIn("كتابًا", r.get_json()["error"])
        self.confirm(self.outline_book(), [cid])
        self.assertEqual(self.plan(cid, sid)["need"], "build")

    def test_building_lays_the_lessons_over_the_periods_in_the_book_order(self):
        cid, sid, bid = self.scenario()
        d = self.build(cid, sid)
        self.assertIsNone(d["need"])
        self.assertEqual([i["title"] for i in d["items"]], ["الدرس الأول: المقارنة", "الدرس الثاني: الجمع", "الدرس الثالث: الطرح", "الدرس الأول: العادية", "الدرس الثاني: العشرية", "مراجعة الوحدة الثانية"])
        self.assertEqual([i["unit"] for i in d["items"]], ["الوحدة الأولى: الأعداد"] * 3 + ["الوحدة الثانية: الكسور"] * 3)
        self.assertEqual([i["position"] for i in d["items"]], list(range(6)))
        self.assertTrue(all(i["status"] == "pending" and i["periods"] == 1 for i in d["items"]))
        # Sunday period 1 and Tuesday period 2, week after week
        self.assertEqual([self.where(i)[:2] for i in d["items"]], [("2026-09-06", 1), ("2026-09-08", 2), ("2026-09-13", 1), ("2026-09-15", 2), ("2026-09-20", 1), ("2026-09-22", 2)])
        s = d["summary"]
        self.assertEqual((s["done"], s["pending"], s["percent"], s["current"], s["late"], s["unplaced"]), (0, 6, 0, d["items"][0]["id"], [], 0))
        self.assertGreater(s["spare"], 0)
        self.assertEqual((d["class"]["name"], d["subject"]["name"], d["book"]["id"]), ("الصف الأول أ", "الرياضيات", bid))
        self.assertEqual(d["log"][0]["kind"], "build")
        self.assertEqual(d["today"], "2026-09-06")

    def test_building_again_changes_nothing_but_adds_lessons_the_book_gained(self):
        cid, sid, bid = self.scenario()
        first = self.build(cid, sid)
        again = self.build(cid, sid)
        self.assertEqual([i["id"] for i in first["items"]], [i["id"] for i in again["items"]])
        self.assertEqual(self.count("SELECT COUNT(*) FROM plan_log WHERE kind = 'build'"), 1)
        self.act(first["items"][0]["id"], "done")
        # the book gains a lesson in the middle: the plan takes it there, what was done stays done
        self.confirm(bid, [cid], edit=lambda units: units[0]["lessons"].insert(1, {"title": "درس أُضيف", "periods": 1}))
        self.assertEqual(self.plan(cid, sid)["need"], "build")
        d = self.build(cid, sid)
        self.assertEqual([i["title"] for i in d["items"]][:3], ["الدرس الأول: المقارنة", "درس أُضيف", "الدرس الثاني: الجمع"])
        self.assertEqual(d["items"][0]["status"], "done")
        self.assertEqual(d["items"][1]["status"], "pending")
        self.assertEqual(len(d["items"]), 7)
        self.assertEqual(self.count("SELECT COUNT(*) FROM plan_log WHERE kind = 'build'"), 2)

    def test_a_lesson_taken_out_of_the_book_leaves_the_plan_and_the_rest_stay(self):
        cid, sid, bid = self.scenario()
        d = self.build(cid, sid)
        gone = d["items"][2]["book_lesson_id"]
        self.confirm(bid, [cid], edit=lambda units: units[0]["lessons"].pop(2))
        d2 = self.plan(cid, sid)
        self.assertEqual(len(d2["items"]), 5)
        self.assertNotIn(gone, [i["book_lesson_id"] for i in d2["items"]])

    def test_marking_a_lesson_done_moves_what_follows_up_the_periods_and_keeps_the_order(self):
        cid, sid, bid = self.scenario()
        d = self.build(cid, sid)
        ids = [i["id"] for i in d["items"]]
        d = self.act(ids[0], "done")
        s = d["summary"]
        self.assertEqual((s["done"], s["pending"], s["current"]), (1, 5, ids[1]))
        self.assertEqual((d["items"][0]["status"], d["items"][0]["done_on"]), ("done", "2026-09-06"))
        # Sunday's period was used by the first lesson, so the second is Tuesday's
        self.assertEqual(self.where(d["items"][1])[:2], ("2026-09-08", 2))
        self.assertEqual(self.where(d["items"][5])[:2], ("2026-09-22", 2))
        self.assertIsNone(self.where(d["items"][0]))
        self.assertEqual(d["log"][0]["kind"], "done")
        self.assertGreater(s["percent"], 0)
        # a lesson can be marked done on a day that already passed, never on a day that has not come
        self.today = D(2026, 9, 9)
        d = self.act(ids[1], "done", {"date": "2026-09-08"})
        self.assertEqual(d["items"][1]["done_on"], "2026-09-08")
        r = self.api("post", f"/api/plan/{ids[2]}/done", {"date": "2026-09-20"})
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.plan(cid, sid)["items"][2]["status"], "pending")

    def test_undo_brings_a_lesson_back_to_the_next_ones(self):
        cid, sid, bid = self.scenario()
        d = self.build(cid, sid)
        ids = [i["id"] for i in d["items"]]
        self.act(ids[0], "done")
        d = self.act(ids[0], "undo")
        self.assertEqual((d["items"][0]["status"], d["items"][0]["done_on"], d["summary"]["current"]), ("pending", "", ids[0]))
        self.assertEqual(self.where(d["items"][0])[:2], ("2026-09-06", 1))
        self.assertEqual(d["log"][0]["kind"], "undo")

    def test_a_lesson_she_will_not_teach_this_class_is_greyed_not_deleted(self):
        cid, sid, bid = self.scenario()
        d = self.build(cid, sid)
        ids = [i["id"] for i in d["items"]]
        d = self.act(ids[1], "skip")
        self.assertEqual(len(d["items"]), 6)
        self.assertEqual(d["items"][1]["status"], "skipped")
        self.assertEqual(d["summary"]["pending"], 5)
        self.assertIsNone(self.where(d["items"][1]))
        self.assertEqual(self.where(d["items"][2])[:2], ("2026-09-08", 2))          # the next lesson took its place
        self.assertEqual(self.count("SELECT COUNT(*) FROM book_lessons WHERE id = ?", d["items"][1]["book_lesson_id"]), 1)
        d = self.act(ids[1], "restore")
        self.assertEqual(d["items"][1]["status"], "pending")
        self.assertEqual(self.where(d["items"][1])[:2], ("2026-09-08", 2))

    def test_periods_a_lesson_needs_and_a_note_of_her_own(self):
        cid, sid, bid = self.scenario()
        d = self.build(cid, sid)
        ids = [i["id"] for i in d["items"]]
        d = self.act(ids[0], "", {"periods": 2}, "patch")
        self.assertEqual(d["items"][0]["periods"], 2)
        self.assertEqual(self.where(d["items"][0]), ("2026-09-06", 1, "2026-09-08", 2))          # two periods: Sunday's and Tuesday's
        self.assertEqual(self.where(d["items"][1])[:2], ("2026-09-13", 1))
        self.assertEqual(d["summary"]["periods_total"], 7)
        for bad in (0, 7, "x", None):
            self.assertEqual(self.api("patch", f"/api/plan/{ids[0]}", {"periods": bad}).status_code, 400, bad)
        d = self.act(ids[0], "", {"note": "  راجعي الواجب أولًا  " + "ا" * 300}, "patch")
        self.assertTrue(d["items"][0]["note"].startswith("راجعي الواجب أولًا"))
        self.assertEqual(len(d["items"][0]["note"]), 200)
        self.assertEqual(d["items"][0]["periods"], 2)          # saying a note did not touch the periods
        # the book's own number of periods is a suggestion; the plan of this class has its own
        self.assertEqual(self.app.db.execute("SELECT periods FROM book_lessons WHERE id = ?", (d["items"][0]["book_lesson_id"],)).fetchone()[0], 1)

    def test_moving_a_lesson_earlier_or_later_in_her_plan(self):
        cid, sid, bid = self.scenario()
        d = self.build(cid, sid)
        ids = [i["id"] for i in d["items"]]
        d = self.act(ids[2], "move", {"dir": "up"})
        self.assertEqual([i["id"] for i in d["items"]][:3], [ids[0], ids[2], ids[1]])
        self.assertEqual(self.where(d["items"][1])[:2], ("2026-09-08", 2))
        d = self.act(ids[0], "move", {"dir": "up"})          # already first: nothing happens
        self.assertEqual([i["id"] for i in d["items"]][0], ids[0])
        d = self.act(ids[5], "move", {"dir": "down"})          # already last
        self.assertEqual([i["id"] for i in d["items"]][-1], ids[5])
        # the order of the book itself was not touched
        self.assertEqual([r[0] for r in self.app.db.execute("SELECT id FROM book_lessons WHERE book_id = ? ORDER BY position", (bid,))], [i["book_lesson_id"] for i in self.plan(cid, sid)["items"] if False] or [r[0] for r in self.app.db.execute("SELECT id FROM book_lessons WHERE book_id = ? ORDER BY position", (bid,))])
        self.assertEqual(self.app.db.execute("SELECT title FROM book_lessons WHERE book_id = ? ORDER BY position LIMIT 1 OFFSET 1", (bid,)).fetchone()[0], "الدرس الثاني: الجمع")

    def test_i_am_here_marks_the_lessons_before_it_and_starts_from_it(self):
        cid, sid, bid = self.scenario()
        d = self.build(cid, sid)
        ids = [i["id"] for i in d["items"]]
        self.today = D(2026, 10, 4)
        d = self.act(ids[3], "here")
        self.assertEqual([i["status"] for i in d["items"]], ["done"] * 3 + ["pending"] * 3)
        self.assertEqual(d["summary"]["current"], ids[3])
        self.assertEqual(self.where(d["items"][3])[:2], ("2026-10-04", 1))          # the lesson she is at takes the first period from today
        self.assertEqual(d["summary"]["late"], [])
        self.assertEqual(d["log"][0]["kind"], "here")
        self.assertIn("3", d["log"][0]["text"])
        d = self.act(ids[3], "here")          # again: nothing more to mark
        self.assertEqual(d["summary"]["done"], 3)

    def test_a_lesson_not_taught_on_its_day_is_late_until_the_plan_is_laid_out_again(self):
        cid, sid, bid = self.scenario()
        d = self.build(cid, sid)
        ids = [i["id"] for i in d["items"]]
        self.act(ids[0], "done")
        self.today = D(2026, 9, 20)          # two weeks later: the second to fourth lessons were due and not taught
        d = self.plan(cid, sid)
        self.assertEqual(d["summary"]["late"], ids[1:4])
        self.assertEqual([i["late"] for i in d["items"]], [False, True, True, True, False, False])
        self.assertEqual(self.where(d["items"][1])[:2], ("2026-09-20", 1))          # but they are laid over the periods she still has
        self.assertEqual(d["summary"]["current"], ids[1])
        self.assertTrue(d["items"][4]["shifted"] or d["items"][5]["shifted"])
        d = self.api("post", "/api/plan/rebuild", {"class_id": cid, "subject_id": sid}).get_json()
        self.assertEqual(d["summary"]["late"], [])
        self.assertEqual(d["log"][0]["kind"], "rebuild")
        self.assertEqual(len(d["items"]), 6)
        self.assertEqual(d["items"][0]["status"], "done")          # what she taught stays taught

    def test_a_holiday_pushes_the_lessons_after_it_and_forgets_none(self):
        cid, sid, bid = self.scenario()
        before = self.build(cid, sid)
        self.api("post", "/api/calendar/holidays", {"from": "2026-09-08", "to": "2026-09-14", "label": "إجازة"})
        d = self.plan(cid, sid)
        self.assertEqual(len(d["items"]), 6)
        self.assertEqual([self.where(i)[:2] for i in d["items"]][:3], [("2026-09-06", 1), ("2026-09-15", 2), ("2026-09-20", 1)])
        self.assertEqual([i["id"] for i in d["items"]], [i["id"] for i in before["items"]])
        # (phase 3) a holiday is nobody's fault: the days the lessons are due move with it, so a pushed lesson is neither late nor «shifted», and the plan's log says what moved
        self.assertEqual(d["items"][1]["due"]["date"], "2026-09-15")
        self.assertFalse(d["items"][1]["shifted"] or d["items"][1]["late"])
        self.assertEqual(d["log"][0]["kind"], "realign")
        self.assertIn("إجازة", d["log"][0]["text"])

    def test_too_few_periods_are_shown_as_a_shortage_with_ideas_and_no_lesson_is_dropped(self):
        cid, sid, bid = self.scenario(term=False)
        self.set_term(ends="2026-09-20")          # five periods for six lessons
        d = self.build(cid, sid)
        s = d["summary"]
        self.assertEqual((s["periods_left"], s["periods_needed"], s["spare"], s["unplaced"]), (5, 6, -1, 1))
        self.assertEqual(len(d["items"]), 6)
        self.assertIsNone(d["items"][5]["planned"])          # it has no period, yet it is still in the plan
        self.assertEqual(len(d["ideas"]), 1)
        idea = d["ideas"][0]
        self.assertTrue(idea["first_title"] and idea["second_title"])
        self.assertEqual(idea["second"] - idea["first"] >= 0, True)

    def test_sharing_the_periods_that_are_left_by_the_size_of_each_lesson(self):
        cid, sid, bid = self.scenario()
        d = self.build(cid, sid)
        prev = self.c.get(f"/api/plan/spread?class_id={cid}&subject_id={sid}").get_json()
        left = d["summary"]["periods_left"]
        from app import planner
        given = min(left, 6 * planner.MAX_SHARED_PERIODS)          # no lesson is given more than the cap: with plenty of periods the rest stays free
        self.assertEqual((prev["total"], len(prev["items"]), sum(i["to"] for i in prev["items"])), (left, 6, given))
        self.assertEqual((prev["assigned"], prev["spare"]), (given, left - given))
        self.assertTrue(all(1 <= i["to"] <= planner.MAX_SHARED_PERIODS for i in prev["items"]))
        self.assertGreater(left, given)          # (this timetable has more periods than six lessons can use)
        self.assertEqual(self.count("SELECT SUM(periods) FROM plan_items"), 6)          # the preview changed nothing
        d = self.api("post", "/api/plan/spread", {"class_id": cid, "subject_id": sid}).get_json()
        self.assertEqual(sum(i["periods"] for i in d["items"]), given)
        self.assertEqual(d["summary"]["spare"], left - given)
        self.assertEqual(d["log"][0]["kind"], "spread")
        self.assertEqual(d["summary"]["late"], [])

    def test_sharing_when_the_periods_are_not_enough_gives_every_lesson_one(self):
        cid, sid, bid = self.scenario(term=False)
        self.set_term(ends="2026-09-20")          # five periods for six lessons
        self.build(cid, sid)
        prev = self.c.get(f"/api/plan/spread?class_id={cid}&subject_id={sid}").get_json()
        self.assertEqual([i["to"] for i in prev["items"]], [1] * 6)
        self.assertEqual((prev["total"], prev["assigned"], prev["spare"]), (5, 6, -1))          # the screen says the time is short; nothing is dropped

    def test_sharing_needs_a_plan_and_periods(self):
        cid, sid, bid = self.scenario()
        self.assertEqual(self.c.get(f"/api/plan/spread?class_id={cid}&subject_id={sid}").status_code, 400)          # not built yet
        self.assertEqual(self.api("post", "/api/plan/spread", {"class_id": cid, "subject_id": sid}).status_code, 400)
        self.build(cid, sid)
        self.set_slots([])
        r = self.c.get(f"/api/plan/spread?class_id={cid}&subject_id={sid}")
        self.assertEqual(r.status_code, 400)
        self.assertIn("الجدول", r.get_json()["error"])
        self.assertEqual(self.plan(cid, sid)["summary"]["periods_left"], 0)
        self.assertEqual(len(self.plan(cid, sid)["items"]), 6)          # no timetable: the plan is still there, without dates
        self.assertIsNone(self.plan(cid, sid)["items"][0]["planned"])

    def test_the_classes_do_not_share_a_plan(self):
        a, b = self.make_class("الصف الأول أ"), self.make_class("الصف الأول ب")
        m = self.make_subject()
        self.set_slots([(0, 1, a, m), (1, 1, b, m)])
        self.set_term()
        bid = self.outline_book()
        self.confirm(bid, [a, b])
        pa, pb = self.build(a, m), self.build(b, m)
        self.assertEqual(self.count("SELECT COUNT(*) FROM plan_items"), 12)
        self.act(pa["items"][0]["id"], "done")
        self.assertEqual(self.plan(a, m)["summary"]["done"], 1)
        self.assertEqual(self.plan(b, m)["summary"]["done"], 0)
        self.assertEqual(self.where(self.plan(b, m)["items"][0])[:2], ("2026-09-07", 1))
        pairs = {(p["class_name"]): p for p in self.c.get("/api/plan/pairs").get_json()["pairs"]}
        self.assertEqual((pairs["الصف الأول أ"]["percent"] > 0, pairs["الصف الأول ب"]["percent"]), (True, 0))
        self.assertEqual(pairs["الصف الأول أ"]["current"], "الدرس الثاني: الجمع")

    def test_the_pairs_list_says_what_each_one_is_missing(self):
        a, b = self.make_class("الصف الأول أ"), self.make_class("الصف الأول ب")
        m = self.make_subject()
        self.set_slots([(0, 1, a, m), (1, 1, b, m)])
        self.assertEqual([p["need"] for p in self.c.get("/api/plan/pairs").get_json()["pairs"]], ["term", "term"])
        self.set_term()
        self.confirm(self.outline_book(), [a])
        self.assertEqual([p["need"] for p in self.c.get("/api/plan/pairs").get_json()["pairs"]], ["build", "book"])
        self.build(a, m)
        self.assertEqual([p["need"] for p in self.c.get("/api/plan/pairs").get_json()["pairs"]], [None, "book"])

    def test_a_plan_is_hers_alone(self):
        cid, sid, bid = self.scenario()
        d = self.build(cid, sid)
        item = d["items"][0]["id"]
        other = self.client()
        self.register(other, "other@example.com")
        self.assertEqual(other.get("/api/plan/pairs").get_json()["pairs"], [])
        self.assertEqual(other.get(f"/api/plan?class_id={cid}&subject_id={sid}").status_code, 404)
        self.assertEqual(other.get(f"/api/plan/spread?class_id={cid}&subject_id={sid}").status_code, 404)
        for method, url, data in (("post", "/api/plan/build", {"class_id": cid, "subject_id": sid}), ("post", "/api/plan/rebuild", {"class_id": cid, "subject_id": sid}),
                                  ("post", "/api/plan/spread", {"class_id": cid, "subject_id": sid}), ("post", f"/api/plan/{item}/done", {}), ("post", f"/api/plan/{item}/undo", {}),
                                  ("post", f"/api/plan/{item}/skip", {}), ("post", f"/api/plan/{item}/restore", {}), ("patch", f"/api/plan/{item}", {"periods": 3}),
                                  ("post", f"/api/plan/{item}/move", {"dir": "down"}), ("post", f"/api/plan/{item}/here", {}), ("post", f"/api/plan/{item}/lesson", {})):
            self.assertEqual(self.api(method, url, data, other).status_code, 404, (method, url))
        self.assertEqual(self.plan(cid, sid)["summary"]["done"], 0)
        self.assertEqual(self.plan(cid, sid)["items"][0]["periods"], 1)

    def test_the_plan_calls_need_the_token_and_a_signed_in_teacher(self):
        cid, sid, bid = self.scenario()
        item = self.build(cid, sid)["items"][0]["id"]
        self.assertEqual(self.c.post(f"/api/plan/{item}/done", json={}).status_code, 403)
        anon = self.client()
        self.assertEqual(anon.get("/api/today").status_code, 401)
        self.assertEqual(self.api("post", f"/api/plan/{item}/done", {}, anon).status_code, 401)

    # ---------------------------------------------------------------- today
    def test_todays_periods_show_the_lesson_the_plan_puts_in_each(self):
        a, b = self.make_class("الصف الأول أ"), self.make_class("الصف الأول ب")
        m, s = self.make_subject("الرياضيات"), self.make_subject("العلوم")
        self.set_slots([(0, 1, a, m), (0, 2, b, m), (0, 4, a, s), (1, 1, a, m)], times={"1": {"starts": "07:00", "ends": "07:45"}, "2": {"starts": "07:45", "ends": "08:30"}})
        self.set_term()
        self.confirm(self.outline_book(), [a, b])
        self.build(a, m)
        self.build(b, m)
        d = self.c.get("/api/today").get_json()
        self.assertEqual(d["off"], "")
        self.assertEqual([(p["period"], p["class_name"], p["subject_name"], p["state"], p["time"]) for p in d["periods"]],
                         [(1, "الصف الأول أ", "الرياضيات", "now", "07:00–07:45"), (2, "الصف الأول ب", "الرياضيات", "now", "07:45–08:30"), (4, "الصف الأول أ", "العلوم", "now", "")])
        self.assertEqual([p["lesson"]["title"] if p["lesson"] else None for p in d["periods"]], ["الدرس الأول: المقارنة", "الدرس الأول: المقارنة", None])          # no book for the science
        self.today = D(2026, 9, 7)          # Monday: one period
        self.assertEqual([p["period"] for p in self.c.get("/api/today").get_json()["periods"]], [1])
        self.today = D(2026, 9, 9)          # Wednesday: none
        self.assertEqual(self.c.get("/api/today").get_json(), {"periods": [], "off": ""})

    def test_a_lesson_done_today_takes_its_period_and_the_next_lesson_the_next_one(self):
        a, m = self.make_class(), self.make_subject()
        self.set_slots([(0, 1, a, m), (0, 2, a, m), (2, 1, a, m)])
        self.set_term()
        self.confirm(self.outline_book(), [a])
        d = self.build(a, m)
        ids = [i["id"] for i in d["items"]]
        self.assertEqual([self.where(i)[:2] for i in d["items"]][:3], [("2026-09-06", 1), ("2026-09-06", 2), ("2026-09-08", 1)])
        d = self.act(ids[0], "done")
        self.assertEqual([self.where(i)[:2] for i in d["items"][1:4]], [("2026-09-06", 2), ("2026-09-08", 1), ("2026-09-13", 1)])
        periods = self.c.get("/api/today").get_json()["periods"]
        self.assertEqual([(p["period"], p["state"], p["lesson"]["title"]) for p in periods], [(1, "done", "الدرس الأول: المقارنة"), (2, "now", "الدرس الثاني: الجمع")])
        d = self.act(ids[1], "done")
        periods = self.c.get("/api/today").get_json()["periods"]
        self.assertEqual([p["state"] for p in periods], ["done", "done"])
        self.assertEqual(self.where(d["items"][2])[:2], ("2026-09-08", 1))

    def test_a_lesson_of_two_periods_done_today_fills_two_of_todays_periods(self):
        a, m = self.make_class(), self.make_subject()
        self.set_slots([(0, 1, a, m), (0, 2, a, m), (0, 3, a, m)])
        self.set_term()
        self.confirm(self.outline_book(), [a])
        d = self.build(a, m)
        d = self.act(d["items"][0]["id"], "", {"periods": 2}, "patch")
        d = self.act(d["items"][0]["id"], "done")
        periods = self.c.get("/api/today").get_json()["periods"]
        self.assertEqual([(p["state"], p["lesson"]["title"]) for p in periods], [("done", "الدرس الأول: المقارنة"), ("done", "الدرس الأول: المقارنة"), ("now", "الدرس الثاني: الجمع")])

    def test_a_period_that_is_over_is_not_given_to_a_lesson_that_was_not_marked_done(self):
        a, m = self.make_class(), self.make_subject()
        self.set_slots([(0, 1, a, m), (0, 2, a, m)], times={"1": {"starts": "07:00", "ends": "07:45"}, "2": {"starts": "07:45", "ends": "08:30"}})
        self.set_term()
        self.confirm(self.outline_book(), [a])
        self.build(a, m)
        self.clock = datetime.time(8, 0)          # the first period is over, the second is on
        d = self.c.get("/api/today").get_json()
        self.assertEqual([(p["period"], p["state"], p["lesson"]["title"] if p["lesson"] else None) for p in d["periods"]], [(1, "past", None), (2, "now", "الدرس الأول: المقارنة")])
        self.clock = datetime.time(9, 0)
        d = self.c.get("/api/today").get_json()
        self.assertEqual([p["state"] for p in d["periods"]], ["past", "past"])
        plan = self.plan(a, m)
        self.assertEqual(self.where(plan["items"][0])[:2], ("2026-09-13", 1))          # today's periods are over: the lesson waits for the next week

    def test_a_day_nobody_teaches_says_why(self):
        a, m = self.make_class(), self.make_subject()
        self.set_slots([(0, 1, a, m)])
        self.set_term()
        self.api("post", "/api/calendar/holidays", {"from": "2026-09-06", "label": "إجازة الخريف"})
        d = self.c.get("/api/today").get_json()
        self.assertEqual((d["off"], len(d["periods"]), d["periods"][0]["lesson"]), ("إجازة الخريف", 1, None))
        self.today = D(2027, 1, 3)
        self.assertEqual(self.c.get("/api/today").get_json()["off"], "خارج الفصل الدراسي")

    def test_the_first_lesson_never_starts_before_the_term(self):
        cid, sid, bid = self.scenario(term=False)
        self.set_term("2026-09-20", "2026-12-24")
        d = self.build(cid, sid)
        self.assertEqual(self.where(d["items"][0])[:2], ("2026-09-20", 1))
        self.assertEqual(d["summary"]["late"], [])


# ================================================================ a lesson of the book becomes a lesson of the app
class LessonFromBook(Phase2):
    def planned(self):
        """A class with the PDF book (it has text for every lesson) and its plan built."""
        cid, sid = self.make_class(), self.make_subject()
        self.set_slots([(0, 1, cid, sid), (2, 2, cid, sid)])
        self.set_term()
        bid = self.post_book("math.pdf", pdf_book()).get_json()["id"]
        self.confirm(bid, [cid])
        d = self.build(cid, sid)
        return cid, sid, bid, d

    def test_it_becomes_a_lesson_with_questions_and_counts_once(self):
        cid, sid, bid, d = self.planned()
        item = d["items"][0]
        self.assertTrue(item["has_text"])
        r = self.api("post", f"/api/plan/{item['id']}/lesson")
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        lid = r.get_json()["lesson_id"]
        row = self.app.db.execute("SELECT * FROM lessons WHERE id = ?", (lid,)).fetchone()
        self.assertEqual((row["kind"], row["status"], row["subject"], row["title"]), ("book", "ready", "الرياضيات", item["title"]))
        self.assertIn("جملة شرح", row["text"])
        self.assertGreater(self.count("SELECT COUNT(*) FROM questions WHERE lesson_id = ?", lid), 0)
        self.assertEqual(self.count("SELECT COUNT(*) FROM lesson_usage"), 1)
        self.assertEqual(self.plan(cid, sid)["items"][0]["lesson_id"], lid)
        self.assertEqual(self.c.get(f"/lessons/{lid}").status_code, 200)
        self.assertIn(item["title"], self.c.get("/dashboard").get_data(as_text=True))
        # asking again gives the same lesson, not a second one
        again = self.api("post", f"/api/plan/{item['id']}/lesson")
        self.assertEqual((again.status_code, again.get_json()["lesson_id"]), (200, lid))
        self.assertEqual(self.count("SELECT COUNT(*) FROM lessons"), 1)

    def test_deleting_the_lesson_and_making_it_again_does_not_count_twice(self):
        cid, sid, bid, d = self.planned()
        item = d["items"][1]["id"]
        first = self.api("post", f"/api/plan/{item}/lesson").get_json()["lesson_id"]
        self.assertEqual(self.api("delete", f"/api/lessons/{first}").status_code, 200)
        self.assertIsNone(self.plan(cid, sid)["items"][1]["lesson_id"])
        second = self.api("post", f"/api/plan/{item}/lesson").get_json()["lesson_id"]
        self.assertEqual(self.plan(cid, sid)["items"][1]["lesson_id"], second)
        self.assertEqual(self.count("SELECT COUNT(*) FROM lessons"), 1)
        self.assertEqual(self.count("SELECT COUNT(*) FROM lesson_usage"), 1)
        self.assertEqual(self.count("SELECT COUNT(*) FROM lesson_usage WHERE file_key = ?", f"book-{self.plan(cid, sid)['items'][1]['book_lesson_id']}"), 1)

    def test_a_lesson_of_another_book_lesson_counts_separately(self):
        cid, sid, bid, d = self.planned()
        for i in d["items"][:3]:
            self.assertEqual(self.api("post", f"/api/plan/{i['id']}/lesson").status_code, 201)
        self.assertEqual(self.count("SELECT COUNT(*) FROM lesson_usage"), 3)

    def test_her_plans_allowance_is_respected_for_a_new_lesson_only(self):
        cid, sid, bid, d = self.planned()
        first = d["items"][0]["id"]
        self.assertEqual(self.api("post", f"/api/plan/{first}/lesson").status_code, 201)
        self.app.db.execute("UPDATE plans SET max_lessons = 1 WHERE code = 'free'")
        self.app.db.commit()
        r = self.api("post", f"/api/plan/{d['items'][1]['id']}/lesson")
        self.assertEqual(r.status_code, 400)
        self.assertIn("حد الدروس", r.get_json()["error"])
        self.assertEqual(self.count("SELECT COUNT(*) FROM lessons"), 1)
        self.assertEqual(self.api("post", f"/api/plan/{first}/lesson").status_code, 200)          # the one she has is still hers to open

    def test_a_lesson_the_book_has_no_text_for_takes_the_text_she_pastes(self):
        cid, sid, bid = self.scenario()
        d = self.build(cid, sid)
        item = d["items"][0]
        self.assertFalse(item["has_text"])
        r = self.api("post", f"/api/plan/{item['id']}/lesson")
        self.assertEqual(r.status_code, 400)
        self.assertTrue(r.get_json()["need_text"])
        r = self.api("post", f"/api/plan/{item['id']}/lesson", {"text": "قصير"})
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.count("SELECT COUNT(*) FROM lessons"), 0)
        text = "الأعداد الصحيحة تشمل الأعداد الموجبة والسالبة والصفر. نقارن بين عددين صحيحين باستخدام خط الأعداد. العدد الأكبر يقع إلى يمين العدد الأصغر دائمًا."
        r = self.api("post", f"/api/plan/{item['id']}/lesson", {"text": text})
        self.assertEqual(r.status_code, 201, r.get_data(as_text=True))
        self.assertTrue(self.plan(cid, sid)["items"][0]["has_text"])          # kept with the book for the next class that uses it
        self.assertEqual(self.count("SELECT COUNT(*) FROM lesson_usage"), 1)

    def test_a_lesson_made_from_a_book_is_not_a_file_upload(self):
        cid, sid, bid, d = self.planned()
        lid = self.api("post", f"/api/plan/{d['items'][0]['id']}/lesson").get_json()["lesson_id"]
        self.assertEqual(self.count("SELECT COUNT(*) FROM lessons WHERE id = ? AND original_name = 'من الكتاب'", lid), 1)
        self.assertEqual(self.api("post", f"/api/lessons/{lid}/regenerate").status_code, 200)          # the questions can be made again from the text kept
        self.assertEqual(self.count("SELECT COUNT(*) FROM lesson_usage"), 1)
        self.assertEqual(self.app.db.execute("SELECT status FROM lessons WHERE id = ?", (lid,)).fetchone()[0], "ready")


# ================================================================ the screens
class Pages(Phase2):
    PAGES = {"/curriculum": "curriculum.js", "/schedule": "schedule.js", "/calendar": "calendar.js", "/plan": "plan.js"}

    def test_the_screens_open_for_a_teacher_and_send_a_visitor_to_the_login(self):
        bid = self.outline_book()
        urls = list(self.PAGES) + [f"/curriculum/{bid}"]
        for url in urls:
            r = self.c.get(url)
            self.assertEqual(r.status_code, 200, url)
            html = r.get_data(as_text=True)
            self.assertIn('class="plan-nav', html, url)
            self.assertIn("css/plan.css", html, url)
            self.assertEqual(r.headers["Cache-Control"], "no-store", url)
            self.assertEqual(self.client().get(url).status_code, 302, url)
        self.assertEqual(self.c.get("/curriculum/99999").status_code, 404)

    def test_each_screen_loads_its_own_script_and_has_no_inline_code(self):
        bid = self.outline_book()
        pages = dict(self.PAGES)
        pages[f"/curriculum/{bid}"] = "book.js"
        for url, script in pages.items():
            html = self.c.get(url).get_data(as_text=True)
            self.assertIn(f"js/{script}", html, url)
            self.assertNotRegex(html, r"\son[a-z]+\s*=", url)          # no onclick=… (the page policy forbids inline code)
            self.assertNotRegex(html, r"<[a-z]+[^>]*\sstyle\s*=", url)
            self.assertNotIn("<script>", html, url)
            self.assertEqual(self.c.get(f"/static/js/{script}").status_code, 200, script)
        self.assertEqual(self.c.get("/static/css/plan.css").status_code, 200)

    def test_the_screens_name_themselves_in_the_menu(self):
        html = self.c.get("/dashboard").get_data(as_text=True)
        self.assertIn('href="/plan"', html)
        self.assertIn('id="day-card"', html)
        for url, label in (("/curriculum", "المنهج"), ("/schedule", "الجدول"), ("/calendar", "التقويم"), ("/plan", "الخطة")):
            page = self.c.get(url).get_data(as_text=True)
            self.assertRegex(page, r'<a href="%s" class="on" aria-current="page">' % re.escape(url), url)
            self.assertIn(label, page)

    def test_a_visitor_gets_nothing_from_the_api_of_the_new_screens(self):
        anon = self.client()
        for url in ("/api/books", "/api/schedule", "/api/calendar", "/api/plan/pairs", "/api/today", "/api/plan?class_id=1&subject_id=1"):
            self.assertEqual(anon.get(url).status_code, 401, url)


# ================================================================ the home screen and the start screen use the plan
class HomeAndStart(Phase2):
    def planned_with_lesson(self):
        cid, sid = self.make_class(), self.make_subject()
        self.set_slots([(0, 1, cid, sid), (0, 2, cid, sid), (2, 2, cid, sid)], times={"1": {"starts": "07:00", "ends": "07:45"}, "2": {"starts": "07:45", "ends": "08:30"}})
        self.set_term()
        bid = self.post_book("math.pdf", pdf_book()).get_json()["id"]
        self.confirm(bid, [cid])
        d = self.build(cid, sid)
        lid = self.api("post", f"/api/plan/{d['items'][0]['id']}/lesson").get_json()["lesson_id"]
        return cid, sid, d, lid

    def test_nothing_is_suggested_without_a_timetable_or_a_lesson(self):
        self.assertIsNone(self.c.get("/api/start").get_json()["suggest"])
        cid, sid = self.make_class(), self.make_subject()
        self.set_slots([(0, 1, cid, sid)])
        self.set_term()
        self.confirm(self.outline_book(), [cid])
        self.build(cid, sid)
        self.assertIsNone(self.c.get("/api/start").get_json()["suggest"])          # the plan has a lesson for the period, but not yet a lesson of the app

    def test_the_period_that_is_on_now_suggests_its_lesson(self):
        cid, sid, d, lid = self.planned_with_lesson()
        sg = self.c.get("/api/start").get_json()["suggest"]
        self.assertEqual((sg["class_id"], sg["subject_id"], sg["lesson_id"], sg["period"], sg["time"]), (cid, sid, lid, 1, "07:00–07:45"))
        self.assertEqual((sg["class_name"], sg["subject_name"], sg["title"]), ("الصف الأول أ", "الرياضيات", d["items"][0]["title"]))
        # the first period is over and the lesson was not taught: it slides to the period that is on now (nothing is lost, nothing is skipped)
        self.clock = datetime.time(7, 50)
        sg = self.c.get("/api/start").get_json()["suggest"]
        self.assertEqual((sg["period"], sg["lesson_id"], sg["time"]), (2, lid, "07:45–08:30"))
        # every period of the day is over: nothing to suggest
        self.clock = datetime.time(9, 0)
        self.assertIsNone(self.c.get("/api/start").get_json()["suggest"])
        # a lesson already taught is not suggested again
        self.clock = datetime.time(6, 0)
        self.act(d["items"][0]["id"], "done")
        self.assertIsNone(self.c.get("/api/start").get_json()["suggest"])

    def test_the_home_screen_reads_todays_periods_from_the_same_place(self):
        cid, sid, d, lid = self.planned_with_lesson()
        periods = self.c.get("/api/today").get_json()["periods"]
        self.assertEqual([(p["period"], p["state"]) for p in periods], [(1, "now"), (2, "now")])
        self.assertEqual(periods[0]["lesson"]["lesson_id"], lid)
        self.assertIsNone(periods[1]["lesson"]["lesson_id"])
        self.assertEqual((periods[0]["class_id"], periods[0]["subject_id"]), (cid, sid))

    def test_the_setup_cards_know_what_she_has_done(self):
        html = self.c.get("/dashboard").get_data(as_text=True)
        self.assertIn("تحميل المنهج", html)
        self.assertIn("تحميل جدول المعلمة", html)
        self.outline_book()
        a, m = self.make_class(), self.make_subject()
        self.set_slots([(0, 1, a, m)])
        html = self.c.get("/dashboard").get_data(as_text=True)
        self.assertIn("تم ✓", html)


if __name__ == "__main__":
    unittest.main()
