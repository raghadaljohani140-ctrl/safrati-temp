#!/usr/bin/env bash
# Saves a copy of everything the website keeps (owners, adverts, pictures, pledges, commission history, rentals)
# as ONE file in /opt/istiraha-site/backups. It is safe to run while the website is running.
#
#   bash backup.sh      make a copy now (the newest 30 copies are kept; older copies of this folder are removed)
#
# A copy that stays on the same server does not protect you if the server is lost. From time to time download
# the newest file from the backups folder to your own computer.
set -euo pipefail
[ "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" = "/opt/istiraha-site" ] || { echo "ERROR: run from /opt/istiraha-site" >&2; exit 1; }
cd /opt/istiraha-site
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
umask 077
[ "$(docker inspect -f '{{.State.Running}}' istiraha-web 2>/dev/null || true)" = true ] || die "the website is not running."
mkdir -p backups
chmod 700 backups
stamp="$(date +%Y%m%d-%H%M%S)"
part="backups/.new-$stamp.part"
final="backups/istiraha-$stamp.tar.gz"
if ! docker exec istiraha-web python -m istiraha export > "$part"; then
  rm -f -- "$part"
  die "the copy failed. Nothing was saved."
fi
# NOT `grep -q` here: it stops reading at the first match, tar then writes into a closed pipe and `pipefail` calls a good
# copy "not readable" as soon as it holds a few dozen pictures. Plain grep reads the whole list, so tar always finishes.
if ! tar -tzf "$part" 2>/dev/null | grep -x 'istiraha.db' >/dev/null; then
  rm -f -- "$part"
  die "the copy is not readable. Nothing was saved."
fi
mv -- "$part" "$final"
chmod 600 "$final"
echo "Saved: /opt/istiraha-site/$final ($(du -h "$final" | cut -f1))"
# keep the newest 30; only files of this folder that follow our own naming are ever removed
find backups -maxdepth 1 -type f -name 'istiraha-[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]-[0-9][0-9][0-9][0-9][0-9][0-9].tar.gz' | sort | head -n -30 | while read -r old; do
  rm -f -- "$old"
  echo "Removed an old copy: $old"
done
