"""The owner decides his own discount (the site is only a broker): the page «عروضي», what visitors see, who may touch which offer,
and the manager's veto."""
import re
import unittest

from istiraha import repo

from .helpers import Case


def cards_of(html):
    """{offer title: the card's html} of the offer cards on a page."""
    return {re.search(r"<b>([^<]+)</b>", c).group(1): c for c in re.findall(r'<li class="com-item">(.*?)</li>', html, re.S)}


class DiscountRuleTests(unittest.TestCase):
    """repo.discount_for on its own, with plain dictionaries."""
    advert = {"id": 7, "owner_id": 1, "city_id": 1, "category_id": 1}

    def offer(self, **kw):
        base = {"title": "عرض", "percent": 10, "city_id": None, "category_id": None, "listing_id": None, "owner_id": None}
        return {**base, **kw}

    def test_an_offer_of_the_manager_follows_its_city_type_or_advert(self):
        self.assertEqual(repo.discount_for(self.advert, [self.offer(percent=15)])[0], 15)
        self.assertEqual(repo.discount_for(self.advert, [self.offer(percent=15, city_id=2)])[0], 0)
        self.assertEqual(repo.discount_for(self.advert, [self.offer(percent=15, category_id=1)])[0], 15)
        self.assertEqual(repo.discount_for(self.advert, [self.offer(percent=15, listing_id=8)])[0], 0)
        self.assertEqual(repo.discount_for(self.advert, [self.offer(percent=15, listing_id=7)])[0], 15)

    def test_an_offer_of_an_owner_applies_to_his_adverts_only(self):
        mine, theirs = self.offer(percent=30, owner_id=1), self.offer(percent=40, owner_id=2)
        self.assertEqual(repo.discount_for(self.advert, [mine]), (30, "عرض"))
        self.assertEqual(repo.discount_for(self.advert, [theirs])[0], 0)
        # even when the row says otherwise: an owner's offer on somebody else's advert does nothing
        self.assertEqual(repo.discount_for(self.advert, [self.offer(percent=40, owner_id=2, listing_id=7)])[0], 0)
        self.assertEqual(repo.discount_for(self.advert, [theirs, mine])[0], 30)

    def test_the_biggest_discount_wins_and_they_are_never_added(self):
        offers = [self.offer(percent=10), self.offer(percent=25, owner_id=1), self.offer(percent=20, owner_id=1, listing_id=7)]
        self.assertEqual(repo.discount_for(self.advert, offers)[0], 25)
        self.assertEqual(repo.price_after(1000, 25), 750)


class OwnerOffersCase(Case):
    async def world(self, price="1000"):
        owner = await self.make_owner()
        lid = await self.add_listing(owner, title="استراحة النخيل", price=price)
        self.approve(lid)
        return owner, lid

    async def other_owner(self, title="مزرعة الواحة", price="500"):
        owner = await self.make_owner(phone="0559876543", name="أبو خالد", ip="203.0.113.51")
        lid = await self.add_listing(owner, title=title, price=price, whatsapp="0559876543")
        self.approve(lid)
        return owner, lid

    async def add_offer(self, owner, **over):
        form = {"title": "خصم الخريف", "percent": "20", "listing": "", "starts": "2026-10-26", "ends": "2026-12-31", **over}
        return await owner.post("/owner/offers", form, page="/owner/offers")

    def offers(self):
        return self.db.all("SELECT * FROM offers ORDER BY id")


class OwnerPageTests(OwnerOffersCase):
    async def test_the_menu_and_the_front_page_lead_to_the_page_and_it_says_how_a_discount_works(self):
        owner, lid = await self.world()
        await owner.get("/owner")
        self.assertIn('<a href="/owner/offers">عروضي</a>', owner.text)
        self.assertIn('href="/owner/offers">أضف عرضًا</a>', owner.text)               # the card on the front page invites him to the first offer
        await owner.get("/owner/offers")
        self.assertEqual(owner.last.status, 200)
        self.assertIn("<h1>عروضي</h1>", owner.text)
        self.assertIn("ما وضعت أي عرض بعد", owner.text)
        for sentence in ("الخصم قرارك أنت", "تلتزم بالسعر بعد الخصم", "تُحسب على قيمة الإيجار الفعلية بعد الخصم", "يظهر الأكبر فقط",
                         "ينتهي العرض وحده", "للإدارة حق إيقاف أي عرض"):
            self.assertIn(sentence, owner.text)

    async def test_a_visitor_has_no_such_link_and_cannot_open_or_post_to_the_page(self):
        owner, lid = await self.world()
        await self.visitor.get("/")
        self.assertNotIn("/owner/offers", self.visitor.text)
        r = await self.visitor.get("/owner/offers")
        self.assertEqual((r.status, r.headers["Location"]), (303, "/owner/login?next=/owner/offers"))
        r = await self.visitor.go("POST", "/owner/offers", {"title": "خصم", "percent": "50", "starts": "2026-10-26", "ends": "2026-12-31"})
        self.assertEqual(r.status, 303)
        self.assertEqual(len(self.offers()), 0)
        r = await self.visitor.go("POST", "/owner/offer/1/delete", {})
        self.assertEqual(r.status, 303)

    async def test_the_manager_is_not_an_owner(self):
        admin = await self.make_admin()
        r = await admin.get("/owner/offers")
        self.assertEqual(r.status, 303)                                              # the manager's cookie works inside /admin only

    async def test_the_form_lists_his_adverts_only_whatever_their_state_and_without_adverts_it_asks_him_to_add_one(self):
        empty = await self.make_owner(phone="0550000001", name="بدون إعلان", ip="203.0.113.60")
        await empty.get("/owner/offers")
        self.assertIn("أضف استراحتك أولًا", empty.text)
        self.assertNotIn('action="/owner/offers"', empty.text)
        await empty.get("/owner")
        self.assertNotIn("offer-card", empty.text)                                    # nothing to put an offer on yet
        owner, lid = await self.world()
        waiting = await self.add_listing(owner, title="لم تُعتمد بعد")
        other, other_lid = await self.other_owner()
        await owner.get("/owner/offers")
        self.assertRegex(owner.text, rf'<option value="{lid}">استراحة النخيل — ')
        self.assertRegex(owner.text, rf'<option value="{waiting}">لم تُعتمد بعد — ')
        self.assertNotIn("مزرعة الواحة", owner.text)                                  # nobody else's advert is offered
        self.assertIn(">كل إعلاناتي</option>", owner.text)
        self.assertIn('name="starts"', owner.text)
        self.assertIn('value="2026-10-26"', owner.text)                               # «من» starts at today

    async def test_the_form_is_open_when_he_has_no_offers_or_made_a_mistake_and_folded_into_a_button_otherwise(self):
        owner, lid = await self.world()
        await owner.get("/owner/offers")
        self.assertIn('<details class="add-fold" open><summary>+ أضف عرضًا جديدًا</summary>', owner.text)        # nothing to look at yet: the form is right there
        await self.add_offer(owner)
        await owner.get("/owner/offers")
        self.assertIn('<details class="add-fold"><summary>+ أضف عرضًا جديدًا</summary>', owner.text)           # his offers come first, one button adds another
        self.assertLess(owner.text.index("add-fold"), owner.text.index('class="com-list"'))
        r = await self.add_offer(owner, percent="95")
        self.assertEqual(r.status, 400)
        self.assertIn('<details class="add-fold" open>', owner.text)                                              # the mistake and the form are together
        self.assertLess(owner.text.index("نسبة الخصم رقم من 1 إلى 90"), owner.text.index('name="title"'))

    async def test_a_discount_shows_to_visitors_on_the_advert_the_home_page_and_the_offers_page(self):
        owner, lid = await self.world()
        r = await self.add_offer(owner, listing=str(lid))
        self.assertEqual((r.status, r.headers["Location"].split("?")[0]), (303, "/owner/offers"))
        self.assertIn("أضفنا عرضك", await owner.message())
        row = self.db.one("SELECT * FROM offers")
        owner_id = self.db.one("SELECT id FROM users WHERE login = '966551234567'")["id"]
        self.assertEqual((row["owner_id"], row["listing_id"], row["percent"], row["title"], row["active"], row["locked"]),
                         (owner_id, lid, 20, "خصم الخريف", 1, 0))
        self.assertEqual((row["starts_on"], row["ends_on"], row["city_id"], row["category_id"]), ("2026-10-26", "2026-12-31", None, None))
        await self.visitor.get(f"/r/{lid}")
        self.assertIn("خصم 20%", self.visitor.text)
        self.assertIn("800", self.visitor.text)                                      # 1000 minus 20%
        await self.visitor.get("/offers")
        self.assertIn("استراحة النخيل", self.visitor.text)
        self.assertIn("خصم 20%", self.visitor.text)
        await self.visitor.get("/")
        self.assertIn("خصم 20%", self.visitor.text)
        self.assertEqual(self.db.one("SELECT price FROM listings WHERE id = ?", (lid,))["price"], 1000)       # the price he wrote is untouched
        self.assertIn("owner_offer_new", [r["action"] for r in self.db.all("SELECT action FROM audit")])

    async def test_an_offer_for_all_my_adverts_covers_each_of_his_and_nobody_elses(self):
        owner, first = await self.world()
        second = await self.add_listing(owner, title="استراحة الورود", price="600")
        self.approve(second)
        other, foreign = await self.other_owner()
        await self.add_offer(owner, title="خصم الويكند", percent="50")
        row = self.db.one("SELECT * FROM offers")
        self.assertIsNone(row["listing_id"])
        for lid, shown in ((first, True), (second, True), (foreign, False)):
            await self.visitor.get(f"/r/{lid}")
            self.assertEqual("خصم 50%" in self.visitor.text, shown, lid)
        await self.visitor.get("/offers")
        self.assertIn("استراحة النخيل", self.visitor.text)
        self.assertIn("استراحة الورود", self.visitor.text)
        self.assertNotIn("مزرعة الواحة", self.visitor.text)
        await self.visitor.get("/search", price_max="320")                           # 600 minus 50% = 300 passes a budget the full price would not
        self.assertIn("استراحة الورود", self.visitor.text)

    async def test_an_offer_does_not_reach_the_adverts_of_another_owner_even_if_the_row_says_so(self):
        owner, lid = await self.world()
        other, foreign = await self.other_owner()
        owner_id = self.db.one("SELECT id FROM users WHERE login = '966551234567'")["id"]
        self.db.run("INSERT INTO offers(title, percent, listing_id, starts_on, ends_on, owner_id) VALUES ('عرض مدسوس', 90, ?, '2026-10-01', '2026-12-31', ?)", (foreign, owner_id))
        await self.visitor.get(f"/r/{foreign}")
        self.assertNotIn("خصم 90%", self.visitor.text)
        await self.visitor.get("/offers")
        self.assertNotIn("مزرعة الواحة", self.visitor.text)

    async def test_the_biggest_discount_wins_between_the_managers_offer_and_the_owners(self):
        admin = await self.make_admin()
        owner, lid = await self.world()
        other, foreign = await self.other_owner(price="1000")
        await admin.post("/admin/offers", {"title": "خصم المنصة", "percent": "10", "city": "", "category": "", "listing": "", "starts": "2026-10-01", "ends": "2026-12-31"}, page="/admin/offers")
        await self.add_offer(owner, percent="25")
        await self.visitor.get(f"/r/{lid}")
        self.assertIn("خصم 25%", self.visitor.text)
        self.assertIn("750", self.visitor.text)
        await self.visitor.get(f"/r/{foreign}")
        self.assertIn("خصم 10%", self.visitor.text)
        self.assertNotIn("خصم 35%", self.visitor.text)                               # never added together

    async def test_an_offer_that_starts_later_or_has_ended_shows_nothing_to_visitors(self):
        owner, lid = await self.world()
        await self.add_offer(owner, title="يبدأ الشهر القادم", percent="30", starts="2026-11-20", ends="2026-12-31")
        await self.visitor.get(f"/r/{lid}")
        self.assertNotIn("خصم 30%", self.visitor.text)
        self.clock.t += 40 * 86400                                                   # a month and a half later it is running
        await self.visitor.get(f"/r/{lid}")
        self.assertIn("خصم 30%", self.visitor.text)
        self.clock.t += 60 * 86400                                                   # and after its last day it is gone
        await self.visitor.get(f"/r/{lid}")
        self.assertNotIn("خصم 30%", self.visitor.text)


class OwnerFormTests(OwnerOffersCase):
    async def test_each_mistake_gets_its_own_message_and_nothing_he_typed_is_lost(self):
        owner, lid = await self.world()
        other, foreign = await self.other_owner()
        cases = [
            ({"title": "خ"}, "اكتب عنوانًا للعرض"),
            ({"percent": "0"}, "نسبة الخصم رقم من 1 إلى 90"),
            ({"percent": "95"}, "نسبة الخصم رقم من 1 إلى 90"),
            ({"percent": "كثير"}, "نسبة الخصم رقم من 1 إلى 90"),
            ({"percent": "12.5"}, "نسبة الخصم رقم من 1 إلى 90"),
            ({"starts": "", "ends": ""}, "اختر تاريخي"),
            ({"starts": "2026-12-01", "ends": "2026-11-01"}, "تاريخ «إلى» بعد «من»"),
            ({"starts": "2026-09-01", "ends": "2026-10-01"}, "تاريخ «إلى» مضى"),
            ({"ends": "2027-12-31"}, "أقصى مدة للعرض سنة"),
            ({"listing": str(foreign)}, "اختر إعلانًا من إعلاناتك"),
            ({"listing": "9999"}, "اختر إعلانًا من إعلاناتك"),
            ({"listing": "abc"}, "اختر إعلانًا من إعلاناتك"),
        ]
        for over, message in cases:
            r = await self.add_offer(owner, **{"title": "خصم الويكند", **over})
            self.assertEqual(r.status, 400, over)
            self.assertIn(message, owner.text, over)
            typed_title = over.get("title", "خصم الويكند")
            self.assertIn(f'value="{typed_title}"', owner.text, over)                  # the form comes back as he filled it
            self.assertEqual(len(self.offers()), 0, over)
        r = await self.add_offer(owner, title="خصم الويكند", percent="95", listing=str(lid), ends="2026-11-05")
        self.assertIn('value="95"', owner.text)
        self.assertIn('value="2026-11-05"', owner.text)
        self.assertRegex(owner.text, rf'<option value="{lid}" selected>')

    async def test_the_last_day_of_an_offer_can_be_today_and_a_one_day_offer_is_fine(self):
        owner, lid = await self.world()
        r = await self.add_offer(owner, starts="2026-10-26", ends="2026-10-26")
        self.assertEqual(r.status, 303)
        await self.visitor.get(f"/r/{lid}")
        self.assertIn("خصم 20%", self.visitor.text)
        r = await self.add_offer(owner, title="أطول عرض", starts="2026-10-26", ends="2027-10-27")      # a year and a day from today: the longest allowed
        self.assertEqual(r.status, 303)
        r = await self.add_offer(owner, title="أطول من اللازم", starts="2026-10-26", ends="2027-10-28")
        self.assertEqual(r.status, 400)
        self.assertEqual(len(self.offers()), 2)

    async def test_what_a_phone_keyboard_types_is_accepted(self):
        owner, lid = await self.world()
        r = await self.add_offer(owner, title="‏خصم   الخريف‎ ", percent="‏٢٠٪", starts="٢٠٢٦-١٠-٢٦", ends="٢٠٢٦-١٢-٣١")
        self.assertEqual(r.status, 303)
        row = self.db.one("SELECT * FROM offers")
        self.assertEqual((row["title"], row["percent"], row["starts_on"], row["ends_on"]), ("خصم الخريف", 20, "2026-10-26", "2026-12-31"))

    async def test_a_title_is_shown_as_text_and_never_as_markup(self):
        owner, lid = await self.world()
        await self.add_offer(owner, title='<script>alert(1)</script> & "خصم"')
        await owner.get("/owner/offers")
        self.assertNotIn("<script>alert", owner.text)
        self.assertIn("&lt;script&gt;alert(1)&lt;/script&gt; &amp; &quot;خصم&quot;", owner.text)

    async def test_an_owner_keeps_at_most_thirty_offers_and_deleting_makes_room(self):
        owner, lid = await self.world()
        other, foreign = await self.other_owner()
        owner_id = self.db.one("SELECT id FROM users WHERE login = '966551234567'")["id"]
        for i in range(30):
            self.db.run("INSERT INTO offers(title, percent, listing_id, starts_on, ends_on, owner_id, active) VALUES (?, 10, ?, '2026-01-01', '2026-02-01', ?, 0)",
                        (f"قديم {i}", lid, owner_id))
        r = await self.add_offer(owner)
        self.assertEqual(r.status, 400)
        self.assertIn("وصلت للحد الأعلى (30 عرضًا)", owner.text)
        r = await self.add_offer(other, title="عرض الواحة")                           # the limit is each owner's own
        self.assertEqual(r.status, 303)
        first = self.db.one("SELECT id FROM offers WHERE owner_id = ? ORDER BY id", (owner_id,))["id"]
        await owner.post(f"/owner/offer/{first}/delete", page="/owner/offers")
        r = await self.add_offer(owner)
        self.assertEqual(r.status, 303)


class OwnerCardsTests(OwnerOffersCase):
    def put(self, owner_id, lid, title, start, end, active=1, locked=0):
        return self.db.run("INSERT INTO offers(title, percent, listing_id, starts_on, ends_on, active, locked, owner_id) VALUES (?, 15, ?, ?, ?, ?, ?, ?)",
                           (title, lid, start, end, active, locked, owner_id))

    async def test_each_offer_says_where_it_stands_and_offers_only_what_he_may_still_do(self):
        owner, lid = await self.world()
        owner_id = self.db.one("SELECT id FROM users WHERE login = '966551234567'")["id"]
        self.put(owner_id, lid, "جارٍ الآن", "2026-10-01", "2026-12-31")
        self.put(owner_id, lid, "لم يبدأ", "2026-11-10", "2026-11-20")
        self.put(owner_id, lid, "انتهى قبل شهور", "2026-01-01", "2026-02-01")
        self.put(owner_id, lid, "أوقفته أنا", "2026-10-01", "2026-12-31", active=0)
        self.put(owner_id, None, "أوقفته الإدارة", "2026-10-01", "2026-12-31", active=0, locked=1)
        await owner.get("/owner/offers")
        cards = cards_of(owner.text)
        self.assertEqual(len(cards), 5)
        expected = {"جارٍ الآن": ("جارٍ", "إيقاف"), "لم يبدأ": ("يبدأ لاحقًا", "إيقاف"), "انتهى قبل شهور": ("انتهى", None),
                    "أوقفته أنا": ("موقوف", "تفعيل"), "أوقفته الإدارة": ("أوقفته الإدارة", None)}
        for title, (state, button) in expected.items():
            card = cards[title]
            self.assertIn(f">{state}</span>", card, title)
            self.assertIn("15%", card, title)
            self.assertIn("/delete", card, title)                                      # an offer can always be deleted
            self.assertEqual("/toggle" in card, button is not None, title)
            if button:
                self.assertIn(f">{button}</button>", card, title)
        self.assertIn("إعلان: استراحة النخيل", cards["جارٍ الآن"])
        self.assertIn("كل إعلاناتي", cards["أوقفته الإدارة"])
        self.assertIn("لا يمكنك إعادة تفعيله من حسابك", cards["أوقفته الإدارة"])
        self.assertNotIn("لا يمكنك إعادة تفعيله", cards["أوقفته أنا"])
        self.assertNotIn("<table", owner.text)

    async def test_the_front_page_card_counts_only_what_is_running(self):
        owner, lid = await self.world()
        owner_id = self.db.one("SELECT id FROM users WHERE login = '966551234567'")["id"]
        self.put(owner_id, lid, "جارٍ", "2026-10-01", "2026-12-31")
        self.put(owner_id, lid, "لم يبدأ", "2026-11-10", "2026-11-20")
        self.put(owner_id, lid, "انتهى", "2026-01-01", "2026-02-01")
        self.put(owner_id, lid, "موقوف", "2026-10-01", "2026-12-31", active=0)
        self.put(owner_id, lid, "موقوف من الإدارة", "2026-10-01", "2026-12-31", active=0, locked=1)
        await owner.get("/owner")
        self.assertIn("العروض الجارية على استراحاتك: <b>1</b>", owner.text)
        self.assertNotIn("ضع خصمًا على استراحتك", owner.text)

    async def test_somebody_elses_offers_are_not_on_his_page(self):
        owner, lid = await self.world()
        other, foreign = await self.other_owner()
        await self.add_offer(other, title="عرض أبو خالد")
        await owner.get("/owner/offers")
        self.assertNotIn("عرض أبو خالد", owner.text)
        await owner.get("/owner")
        self.assertNotIn("العروض الجارية على استراحاتك", owner.text)


class OwnerControlTests(OwnerOffersCase):
    async def test_he_stops_resumes_and_deletes_his_own_offer(self):
        owner, lid = await self.world()
        await self.add_offer(owner, listing=str(lid))
        oid = self.db.one("SELECT id FROM offers")["id"]
        await owner.post(f"/owner/offer/{oid}/toggle", page="/owner/offers")
        self.assertIn("أوقفنا العرض", await owner.message())
        self.assertEqual(self.db.one("SELECT active, locked FROM offers")["active"], 0)
        await self.visitor.get(f"/r/{lid}")
        self.assertNotIn("خصم 20%", self.visitor.text)
        await owner.post(f"/owner/offer/{oid}/toggle", page="/owner/offers")
        self.assertIn("فعّلنا العرض", await owner.message())
        await self.visitor.get(f"/r/{lid}")
        self.assertIn("خصم 20%", self.visitor.text)
        await owner.post(f"/owner/offer/{oid}/delete", page="/owner/offers")
        self.assertIn("حذفنا العرض", await owner.message())
        self.assertEqual(len(self.offers()), 0)
        await self.visitor.get(f"/r/{lid}")
        self.assertNotIn("خصم 20%", self.visitor.text)

    async def test_an_offer_of_somebody_else_looks_exactly_like_one_that_does_not_exist(self):
        owner, lid = await self.world()
        other, foreign = await self.other_owner()
        await self.add_offer(owner, listing=str(lid))
        oid = self.db.one("SELECT id FROM offers")["id"]
        before = dict(self.db.one("SELECT * FROM offers"))
        for action in ("toggle", "delete"):
            r = await other.post(f"/owner/offer/{oid}/{action}", page="/owner/offers")
            self.assertEqual(r.status, 404, action)
            missing = await other.post(f"/owner/offer/99999/{action}", page="/owner/offers")
            self.assertEqual((missing.status, missing.body), (r.status, r.body), action)
        self.assertEqual(dict(self.db.one("SELECT * FROM offers")), before)

    async def test_an_offer_that_has_ended_cannot_be_started_again(self):
        owner, lid = await self.world()
        owner_id = self.db.one("SELECT id FROM users WHERE login = '966551234567'")["id"]
        oid = self.db.run("INSERT INTO offers(title, percent, listing_id, starts_on, ends_on, active, owner_id) VALUES ('قديم', 10, ?, '2026-01-01', '2026-02-01', 0, ?)", (lid, owner_id))
        r = await owner.post(f"/owner/offer/{oid}/toggle", page="/owner/offers")
        self.assertEqual(r.status, 303)
        self.assertIn("انتهى هذا العرض", await owner.message())
        self.assertEqual(self.db.one("SELECT active FROM offers")["active"], 0)

    async def test_the_pages_forms_need_the_check_token(self):
        owner, lid = await self.world()
        await self.add_offer(owner)
        await owner.get("/owner/offers")
        oid = self.db.one("SELECT id FROM offers")["id"]
        attacks = [("/owner/offers", {"title": "خصم كبير", "percent": "90", "starts": "2026-10-26", "ends": "2026-12-31"}),
                   (f"/owner/offer/{oid}/toggle", {}), (f"/owner/offer/{oid}/delete", {})]
        for path, form in attacks:
            for token in (None, "", "wrong-token"):
                r = await owner.go("POST", path, dict(form) if token is None else {**form, "_csrf": token})
                self.assertEqual(r.status, 403, (path, token))
        self.assertEqual(len(self.offers()), 1)
        self.assertEqual(self.db.one("SELECT active FROM offers")["active"], 1)
        await owner.get("/owner/offers")
        r = await owner.go("POST", "/owner/offers", {"title": "من موقع آخر", "percent": "50", "starts": "2026-10-26", "ends": "2026-12-31", "_csrf": owner.csrf()},
                           headers={"origin": "https://evil.example"})
        self.assertEqual(r.status, 403)
        self.assertEqual(len(self.offers()), 1)

    async def test_the_owner_menu_has_its_own_layout_class_and_the_others_do_not(self):
        owner, lid = await self.world()
        admin = await self.make_admin()
        await owner.get("/owner")
        self.assertIn('<body class="owner-in">', owner.text)
        await self.visitor.get("/offers")
        self.assertIn('<body class="">', self.visitor.text)
        await admin.get("/admin")
        self.assertIn('<body class="admin">', admin.text)


class ManagerOffersTests(OwnerOffersCase):
    async def test_the_manager_sees_every_offer_and_whose_it_is(self):
        admin = await self.make_admin()
        owner, lid = await self.world()
        other, foreign = await self.other_owner()
        await self.add_offer(owner, title="عرض أبو سعد", listing=str(lid))
        await self.add_offer(other, title="عرض أبو خالد")
        await admin.post("/admin/offers", {"title": "عرض المنصة", "percent": "10", "city": "", "category": "", "listing": "", "starts": "2026-10-01", "ends": "2026-12-31"}, page="/admin/offers")
        await admin.get("/admin/offers")
        cards = cards_of(admin.text)
        self.assertEqual(set(cards), {"عرض أبو سعد", "عرض أبو خالد", "عرض المنصة"})
        self.assertIn("من المالك: أبو سعد", cards["عرض أبو سعد"])
        self.assertIn("إعلان: استراحة النخيل", cards["عرض أبو سعد"])
        self.assertIn("من المالك: أبو خالد", cards["عرض أبو خالد"])
        self.assertIn("كل إعلانات المالك", cards["عرض أبو خالد"])
        self.assertIn("من الإدارة", cards["عرض المنصة"])
        self.assertIn("كل الإعلانات", cards["عرض المنصة"])
        self.assertIn("الخصم قرار المالك", admin.text)

    async def test_the_managers_own_form_is_folded_away_until_something_goes_wrong(self):
        admin = await self.make_admin()
        await admin.get("/admin/offers")
        self.assertIn('<details class="more"><summary>إضافة عرض من الإدارة</summary>', admin.text)
        self.assertIn("هذا النموذج لعرض تضعه الإدارة بنفسها", admin.text)
        r = await admin.post("/admin/offers", {"title": "خصم", "percent": "95", "city": "", "category": "", "listing": "", "starts": "2026-10-01", "ends": "2026-12-31"}, page="/admin/offers")
        self.assertEqual(r.status, 400)
        self.assertIn('<details class="more" open>', admin.text)                       # the mistake and what he typed are in front of him
        self.assertIn('value="95"', admin.text)

    async def test_the_manager_stops_an_owners_offer_and_the_owner_cannot_start_it_again(self):
        admin = await self.make_admin()
        owner, lid = await self.world()
        await self.add_offer(owner, title="خصم الخريف", listing=str(lid))
        oid = self.db.one("SELECT id FROM offers")["id"]
        await admin.get("/admin/offers")
        self.assertIn(">إيقاف</button>", cards_of(admin.text)["خصم الخريف"])
        await admin.post(f"/admin/offer/{oid}/toggle", page="/admin/offers")
        self.assertIn("أوقفنا العرض", await admin.message())
        row = self.db.one("SELECT active, locked FROM offers")
        self.assertEqual((row["active"], row["locked"]), (0, 1))
        await self.visitor.get(f"/r/{lid}")
        self.assertNotIn("خصم 20%", self.visitor.text)
        await owner.get("/owner/offers")                                              # he sees it, and has no button to undo it
        card = cards_of(owner.text)["خصم الخريف"]
        self.assertIn(">أوقفته الإدارة</span>", card)
        self.assertNotIn("/toggle", card)
        r = await owner.post(f"/owner/offer/{oid}/toggle", page="/owner/offers")        # nor can he force it
        self.assertEqual(r.status, 303)
        self.assertIn("أوقفته الإدارة", await owner.message())
        row = self.db.one("SELECT active, locked FROM offers")
        self.assertEqual((row["active"], row["locked"]), (0, 1))
        # the manager sees it as stopped by him and can lift the stop; the offer stays off until the owner starts it himself
        await admin.get("/admin/offers")
        card = cards_of(admin.text)["خصم الخريف"]
        self.assertIn(">أوقفته الإدارة</span>", card)
        self.assertIn(">رفع الإيقاف</button>", card)
        self.assertNotIn("/toggle", card)
        await admin.post(f"/admin/offer/{oid}/lift", page="/admin/offers")
        row = self.db.one("SELECT active, locked FROM offers")
        self.assertEqual((row["active"], row["locked"]), (0, 0))
        await self.visitor.get(f"/r/{lid}")
        self.assertNotIn("خصم 20%", self.visitor.text)
        await owner.get("/owner/offers")
        self.assertIn(">تفعيل</button>", cards_of(owner.text)["خصم الخريف"])
        await owner.post(f"/owner/offer/{oid}/toggle", page="/owner/offers")
        await self.visitor.get(f"/r/{lid}")
        self.assertIn("خصم 20%", self.visitor.text)
        actions = [r["action"] for r in self.db.all("SELECT action FROM audit")]
        self.assertIn("offer_stop", actions)
        self.assertIn("offer_lift", actions)

    async def test_the_manager_does_not_switch_on_what_the_owner_switched_off(self):
        admin = await self.make_admin()
        owner, lid = await self.world()
        await self.add_offer(owner, title="خصم الخريف")
        oid = self.db.one("SELECT id FROM offers")["id"]
        await owner.post(f"/owner/offer/{oid}/toggle", page="/owner/offers")
        await admin.get("/admin/offers")
        card = cards_of(admin.text)["خصم الخريف"]
        self.assertIn(">أوقفه المالك</span>", card)
        self.assertNotIn("/toggle", card)
        self.assertNotIn("/lift", card)
        for action in ("toggle", "lift"):                                             # and a stale page cannot do it either
            await admin.post(f"/admin/offer/{oid}/{action}", page="/admin/offers")
            row = self.db.one("SELECT active, locked FROM offers")
            self.assertEqual((row["active"], row["locked"]), (0, 0), action)

    async def test_the_manager_switches_his_own_offers_as_before_and_ended_ones_have_no_switch(self):
        admin = await self.make_admin()
        for title, start, end in (("جارٍ", "2026-10-01", "2026-12-31"), ("انتهى", "2026-01-01", "2026-02-01")):
            self.db.run("INSERT INTO offers(title, percent, starts_on, ends_on) VALUES (?, 15, ?, ?)", (title, start, end))
        await admin.get("/admin/offers")
        cards = cards_of(admin.text)
        self.assertIn(">إيقاف</button>", cards["جارٍ"])
        self.assertNotIn("/toggle", cards["انتهى"])
        await admin.post("/admin/offer/1/toggle", page="/admin/offers")
        row = self.db.one("SELECT active, locked FROM offers WHERE id = 1")
        self.assertEqual((row["active"], row["locked"]), (0, 0))                       # his own offer is only switched off, nobody is locked out of it
        await admin.get("/admin/offers")
        self.assertIn(">تفعيل</button>", cards_of(admin.text)["جارٍ"])
        await admin.post("/admin/offer/1/toggle", page="/admin/offers")
        self.assertEqual(self.db.one("SELECT active FROM offers WHERE id = 1")["active"], 1)
        r = await admin.post("/admin/offer/1/lift", page="/admin/offers")            # nothing to lift on his own offer
        self.assertEqual(self.db.one("SELECT active FROM offers WHERE id = 1")["active"], 1)

    async def test_the_manager_can_delete_any_offer_and_it_is_recorded_and_a_missing_one_is_no_crash(self):
        admin = await self.make_admin()
        owner, lid = await self.world()
        await self.add_offer(owner, title="عرض سيحذف")
        oid = self.db.one("SELECT id FROM offers")["id"]
        await admin.post(f"/admin/offer/{oid}/delete", page="/admin/offers")
        self.assertEqual(len(self.offers()), 0)
        row = self.db.one("SELECT detail FROM audit WHERE action = 'offer_delete'")
        self.assertEqual(row["detail"], "عرض سيحذف (أبو سعد)")
        for action in ("toggle", "lift", "delete"):
            r = await admin.post(f"/admin/offer/{oid}/{action}", page="/admin/offers")
            self.assertEqual(r.status, 303, action)
            self.assertIn("غير موجود", await admin.message(), action)

    async def test_the_latest_operations_show_the_new_actions_in_arabic(self):
        admin = await self.make_admin()
        owner, lid = await self.world()
        await self.add_offer(owner, title="خصم الخريف")
        oid = self.db.one("SELECT id FROM offers")["id"]
        await admin.post(f"/admin/offer/{oid}/toggle", page="/admin/offers")
        await admin.post(f"/admin/offer/{oid}/lift", page="/admin/offers")
        await admin.post(f"/admin/offer/{oid}/delete", page="/admin/offers")
        await admin.get("/admin")
        for words in ("عرض جديد من مالك", "إيقاف عرض مالك", "رفع إيقاف عرض", "حذف عرض"):
            self.assertIn(words, admin.text)
        for key in ("owner_offer_new", "offer_stop", "offer_lift", "offer_delete"):
            self.assertNotIn(key, admin.text)

    async def test_the_page_shows_the_newest_three_hundred_and_says_so(self):
        admin = await self.make_admin()
        owner, lid = await self.world()
        owner_id = self.db.one("SELECT id FROM users WHERE login = '966551234567'")["id"]
        for i in range(305):
            self.db.run("INSERT INTO offers(title, percent, listing_id, starts_on, ends_on, owner_id) VALUES (?, 10, ?, '2026-10-01', '2026-12-31', ?)", (f"عرض {i}", lid, owner_id))
        await admin.get("/admin/offers")
        self.assertEqual(len(re.findall(r'<li class="com-item">', admin.text)), 300)
        self.assertIn("يظهر هنا آخر 300 عرضًا من 305", admin.text)
        self.assertIn("عرض 304", admin.text)
        self.assertNotIn("<b>عرض 0</b>", admin.text)

    async def test_the_manager_forms_need_the_check_token(self):
        admin = await self.make_admin()
        owner, lid = await self.world()
        await self.add_offer(owner)
        oid = self.db.one("SELECT id FROM offers")["id"]
        await admin.get("/admin/offers")
        for action in ("toggle", "lift", "delete"):
            for token in (None, "", "wrong-token"):
                r = await admin.go("POST", f"/admin/offer/{oid}/{action}", {} if token is None else {"_csrf": token})
                self.assertEqual(r.status, 403, (action, token))
        row = self.db.one("SELECT active, locked FROM offers")
        self.assertEqual((row["active"], row["locked"]), (1, 0))
        self.assertEqual(len(self.offers()), 1)

    async def test_an_owner_cannot_reach_the_managers_actions(self):
        owner, lid = await self.world()
        await self.add_offer(owner)
        oid = self.db.one("SELECT id FROM offers")["id"]
        await owner.get("/owner/offers")
        token = owner.csrf()
        for action in ("toggle", "lift", "delete"):
            r = await owner.go("POST", f"/admin/offer/{oid}/{action}", {"_csrf": token})
            self.assertEqual(r.status, 303, action)
            self.assertEqual(r.headers["Location"], "/admin/login", action)
        self.assertEqual(self.db.one("SELECT active, locked FROM offers")["locked"], 0)
        self.assertEqual(len(self.offers()), 1)


if __name__ == "__main__":
    unittest.main()
