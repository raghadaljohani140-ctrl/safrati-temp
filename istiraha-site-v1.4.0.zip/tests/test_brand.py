"""The look of the site: the palette, the logo in the header, the picture shown when a link is shared, and the contrast of every text colour."""
import re
import tempfile
import unittest
from pathlib import Path

from istiraha.app import App
from istiraha.db import Database
from istiraha.settings import Settings
from tests.helpers import Case, Client, make_app

ROOT = Path(__file__).resolve().parent.parent
CSS = (ROOT / "istiraha" / "static" / "app.css").read_text(encoding="utf-8")


def tokens() -> dict:
    block = re.search(r":root\{(.*?)\n\}", CSS, re.S).group(1)
    return {name: value.strip() for name, value in re.findall(r"--([a-z-]+):\s*([^;]+);", block)}


def colour(name: str) -> str:
    """The #rrggbb of a palette token (following a var(--other) once)."""
    value = tokens()[name]
    ref = re.fullmatch(r"var\(--([a-z-]+)\)", value)
    value = tokens()[ref.group(1)] if ref else value
    if re.fullmatch(r"#[0-9a-f]{3}", value):
        value = "#" + "".join(ch * 2 for ch in value[1:])
    assert re.fullmatch(r"#[0-9a-f]{6}", value), (name, value)
    return value


def luminance(hex_colour: str) -> float:
    def channel(i):
        c = int(hex_colour[i:i + 2], 16) / 255
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * channel(1) + 0.7152 * channel(3) + 0.0722 * channel(5)


def contrast(a: str, b: str) -> float:
    hi, lo = sorted((luminance(a), luminance(b)), reverse=True)
    return (hi + 0.05) / (lo + 0.05)


class PaletteTests(unittest.TestCase):
    def test_the_palette_is_the_brand_palette(self):
        self.assertEqual(colour("pool"), "#2457c5")                # royal blue: links, main and secondary buttons, headings of the main elements
        self.assertEqual(colour("bg"), "#f7f9fc")                  # the page
        self.assertEqual(colour("sun"), "#f59e0b")                 # orange: the important buttons («أضف استراحتك») and the discount badge
        self.assertEqual(colour("navy"), "#172554")                # navy: the text
        self.assertEqual(colour("ink"), colour("navy"))
        self.assertEqual(colour("card"), "#ffffff")                # the cards

    def test_the_old_turquoise_and_the_grid_are_gone(self):
        self.assertNotRegex(CSS, r"(?i)#0b7a84|#0a4f58|#d9eef0|#10292d|#53696d|#eef5f5|#f29e38|#0e8a94|#0a5c66")
        self.assertIsNone(re.search(r"\b1px\s*,\s*transparent\s+1px", CSS), "a grid of thin lines is back in a background")      # the way the old grid was drawn

    def test_orange_carries_navy_text_never_white(self):
        self.assertRegex(CSS, r"\.btn\.sun\{[^}]*color:var\(--navy\)")
        self.assertRegex(CSS, r"\.badge\{[^}]*color:var\(--navy\)")
        self.assertLess(contrast("#ffffff", colour("sun")), 3)       # why: white on the orange would be hard to read

    def test_every_text_colour_is_readable_where_it_is_used(self):
        """WCAG AA (4.5 to 1) for each text colour on each surface the stylesheet puts it on."""
        surfaces = {"card": colour("card"), "page": colour("bg"), "mist": colour("mist"), "soft": colour("pool-soft")}
        pairs = []
        for text in ("ink", "muted", "pool", "pool-deep"):               # body text, secondary text, links, deep links and chips
            for name, surface in surfaces.items():
                pairs.append((text, colour(text), name, surface))
        for text, surface in (("ok", "ok-bg"), ("warn", "warn-bg"), ("bad", "bad-bg"), ("sun-deep", "warn-bg")):    # status notices and tags
            pairs.append((text, colour(text), surface, colour(surface)))
        pairs += [("white", "#ffffff", "pool (buttons)", colour("pool")), ("white", "#ffffff", "pool-deep (hover)", colour("pool-deep")),
                  ("white", "#ffffff", "navy (manager's bar)", colour("navy")), ("navy", colour("navy"), "sun (orange buttons)", colour("sun"))]
        green = re.search(r"\.btn\.wa\{background:(#[0-9a-f]{6})", CSS).group(1)
        pairs.append(("white", "#ffffff", "the WhatsApp button", green))
        for text_name, text, surface_name, surface in pairs:
            self.assertGreaterEqual(contrast(text, surface), 4.5, f"{text_name} {text} on {surface_name} {surface}: {contrast(text, surface):.2f}")


class LogoTests(Case):
    async def test_the_header_carries_the_logo(self):
        await self.visitor.get("/")
        text = self.visitor.text
        self.assertRegex(text, r'<a class="brand" href="/"><img class="mark" src="/static/logo-mark\.webp\?v=[\d.]+" width="50" height="44" alt="">'
                               r'<img class="word" src="/static/logo-word\.webp\?v=[\d.]+" width="105" height="30" alt="استراحتي"></a>')
        self.assertIn('<meta name="theme-color" content="#2457C5">', text)
        for icon in ("favicon-32.png", "favicon-48.png", "apple-touch-icon.png"):
            self.assertIn(f"/static/{icon}?v=", text)

    async def test_the_managers_bar_writes_the_name_beside_the_emblem(self):
        admin = await self.make_admin()
        await admin.get("/admin")
        self.assertIn('<img class="mark" src="/static/logo-mark.webp', admin.text)
        self.assertIn("<span>استراحتي</span></a>", admin.text)
        self.assertNotIn("logo-word", admin.text)                    # the lettering is dark blue: unreadable on the navy bar

    async def test_a_renamed_site_writes_its_own_name(self):
        app, _ = make_app(site_name="ركن الاستراحات")
        self.addCleanup(app.db.close)
        self.addCleanup(app._tmp.cleanup)
        client = Client(app)
        await client.get("/")
        self.assertIn("<span>ركن الاستراحات</span></a>", client.text)
        self.assertNotIn("logo-word", client.text)                   # the picture spells «استراحتي» only

    async def test_the_pictures_are_served_with_the_right_type(self):
        for name, kind in (("logo-mark.webp", "image/webp"), ("logo-word.webp", "image/webp"), ("share.jpg", "image/jpeg"),
                           ("favicon-32.png", "image/png"), ("favicon-48.png", "image/png"), ("apple-touch-icon.png", "image/png"),
                           ("favicon.svg", "image/svg+xml")):
            response = await self.visitor.get(f"/static/{name}")
            self.assertEqual((name, response.status, response.content_type), (name, 200, kind))
            self.assertGreater(len(response.body), 500, name)

    async def test_a_page_without_a_picture_is_shared_with_the_logo(self):
        await self.visitor.get("/")
        self.assertRegex(self.visitor.text, r'<meta property="og:image" content="https://rest\.example/static/share\.jpg\?v=[\d.]+">')

    async def test_without_a_site_address_no_share_picture_is_promised(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        db = Database(":memory:")
        self.addCleanup(db.close)
        client = Client(App(Settings(data_dir=Path(tmp.name), site_url="", cookie_secure=True), db))
        await client.get("/")
        self.assertEqual(client.last.status, 200)
        self.assertNotIn("og:image", client.text)                    # a link preview needs a full address


if __name__ == "__main__":
    unittest.main()
