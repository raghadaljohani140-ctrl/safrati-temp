#!/usr/bin/env bash
# Creates the manager account of the website, or changes its password (and ends its old sessions).
# Run it yourself: the name and password are typed in this terminal (the password is hidden) and go straight into
# the website's own database. They are not written in any file and nobody else sees them.
set -euo pipefail
[ "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" = "/opt/istiraha-site" ] || { echo "ERROR: run from /opt/istiraha-site" >&2; exit 1; }
cd /opt/istiraha-site
[ "$(docker inspect -f '{{.State.Running}}' istiraha-web 2>/dev/null || true)" = true ] || { echo "ERROR: the website is not running. Run first:  bash install.sh" >&2; exit 1; }
exec docker exec -it istiraha-web python -m istiraha create-admin
