#!/usr/bin/env bash
# Puts a copy made by backup.sh back. It REPLACES the website's data with the copy; the data that was there is not
# deleted: it stays in the same data volume next to the new data, in files and folders ending in .before-restore.
#
#   bash restore.sh backups/istiraha-20261027-101500.tar.gz
set -euo pipefail
[ "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" = "/opt/istiraha-site" ] || { echo "ERROR: run from /opt/istiraha-site" >&2; exit 1; }
cd /opt/istiraha-site
die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
file="${1:-}"
[ -n "$file" ] && [ -f "$file" ] || die "usage: bash restore.sh backups/istiraha-YYYYMMDD-HHMMSS.tar.gz"
# NOT `grep -q`: see backup.sh (a copy with many pictures would be refused as "not a copy")
tar -tzf "$file" 2>/dev/null | grep -x 'istiraha.db' >/dev/null || die "this file is not a copy made by backup.sh. Nothing was changed."
[ -f .tunnel.env ] || : > .tunnel.env
echo "This replaces ALL the website's data (owners, adverts, pictures, pledges, commissions) with: $file"
read -r -p "Type YES to continue: " answer || exit 1
[ "$answer" = "YES" ] || die "cancelled. Nothing was changed."
docker compose -p istiraha stop web
if docker compose -p istiraha run --rm --no-deps -T web python -m istiraha import --force < "$file"; then
  docker compose -p istiraha up -d web
  echo "Done. The website is running again with the copy."
else
  docker compose -p istiraha up -d web
  die "the copy could not be restored; the website was started again with the data it had. Nothing was lost."
fi
