"""Offers (discounts). The site is only a broker, so the discount is the owner's decision: he makes his own offers on the page «عروضي», and
the manager sees every offer, his own and the owners', and can stop any of them. An offer is a display on the price visitors see: it never
changes the price the owner wrote, and the commission is still worked out on the rent that is actually recorded."""
from __future__ import annotations

from datetime import timedelta

from . import repo, ui, util
from .app import Ctx, html_page, not_found
from .server import redirect
from .ui import e
from .views_admin import tag
from .views_founders import box as founders_box

MAX_PER_OWNER = 30            # offers one owner can keep (he deletes the old ones to add more)
MAX_DAYS_AHEAD = 366          # an offer cannot run past a year from today
MAX_SHOWN = 300               # the manager's page shows the newest ones

_COLUMNS = ("title", "percent", "listing", "starts", "ends")


def _offers(db, where: str = "1", args: tuple = (), limit: int = MAX_SHOWN):
    """Offers with the names the cards need. `where` is always written in this file, never typed by anybody."""
    return db.all(f"""SELECT o.*, c.name AS city, g.name AS category, l.title AS listing, u.name AS owner_name
                      FROM offers o LEFT JOIN cities c ON c.id = o.city_id LEFT JOIN categories g ON g.id = o.category_id
                      LEFT JOIN listings l ON l.id = o.listing_id LEFT JOIN users u ON u.id = o.owner_id
                      WHERE {where} ORDER BY o.id DESC LIMIT ?""", (*args, limit))


def _state(o, today: str, admin: bool) -> tuple[str, str]:
    """(colour, words) saying where an offer stands."""
    if o["locked"]:
        return "bad", "أوقفته الإدارة"
    if not o["active"]:
        return ("muted", "أوقفه المالك") if admin and o["owner_id"] else ("muted", "موقوف")
    if o["ends_on"] < today:
        return "muted", "انتهى"
    if o["starts_on"] > today:
        return "warn", "يبدأ لاحقًا"
    return "ok", "جارٍ"


def _buttons(o, today: str, admin: bool) -> list[tuple[str, str]]:
    """[(action, words)] an offer's card offers. The owner decides his discount, so the manager can only veto an owner's offer
    («toggle» stops it and the owner cannot start it again) and lift his veto (the owner then starts it himself)."""
    ended = o["ends_on"] < today
    if admin and o["owner_id"]:
        if o["locked"]:
            acts = [("lift", "رفع الإيقاف")]
        else:
            acts = [("toggle", "إيقاف")] if o["active"] and not ended else []
    elif o["locked"] or ended:
        acts = []
    else:
        acts = [("toggle", "إيقاف" if o["active"] else "تفعيل")]
    return acts + [("delete", "حذف")]


def _card(ctx: Ctx, o, today: str, admin: bool) -> str:
    """One offer as a card: a six-column table ran off a phone's screen and hid its buttons."""
    base = "/admin" if admin else "/owner"
    if o["listing"]:
        scope = f'إعلان: {o["listing"]}'
    elif o["owner_id"]:
        scope = "كل إعلانات المالك" if admin else "كل إعلاناتي"
    else:
        scope = " · ".join(x for x in (o["city"], o["category"]) if x) or "كل الإعلانات"
    lines = f'<small>ينطبق على: {e(scope)}</small>'
    if admin:
        lines += f'<small>{"من المالك: " + e(o["owner_name"]) if o["owner_id"] else "من الإدارة"}</small>'
    lines += f'<small>من {e(ui.day_text(o["starts_on"]))} إلى {e(ui.day_text(o["ends_on"]))}</small>'
    if o["locked"] and not admin:
        lines += "<small>لا يمكنك إعادة تفعيله من حسابك، للاستفسار تواصل مع الإدارة.</small>"
    forms = "".join(
        f'<form method="post" action="{base}/offer/{o["id"]}/{act}" class="inline">{ui.csrf_input(ctx.csrf)}'
        f'<button class="link{" bad" if act == "delete" else ""}" type="submit">{words}</button></form>'
        for act, words in _buttons(o, today, admin))
    return (f'<li class="com-item"><div class="com-main"><div class="com-top"><b>{e(o["title"])}</b><b class="com-amt">{o["percent"]}%</b></div>'
            f'{lines}<div class="com-sub">{tag(*_state(o, today, admin))}{forms}</div></div></li>')


def register(app) -> None:
    db = app.db

    def admin_page(ctx: Ctx, title: str, body: str, status: int = 200):
        return html_page(ctx, title, body, status, noindex=True, admin=True, extra_class="admin")

    # ================================================================== the owner: «عروضي»
    @app.route("GET", "/owner/offers", "owner")
    async def owner_offers(ctx: Ctx, error: str = "", values: dict | None = None, status: int = 200):
        uid, today = ctx.owner["id"], ctx.today().isoformat()
        typed = values or {}
        mine = _offers(db, "o.owner_id = ?", (uid,))
        adverts = [(r["id"], f'{r["title"]} — {r["city"]}') for r in db.all(
            "SELECT l.id, l.title, c.name AS city FROM listings l JOIN cities c ON c.id = l.city_id WHERE l.owner_id = ? ORDER BY l.id DESC", (uid,))]
        shown = (f'<ul class="com-list">{"".join(_card(ctx, o, today, False) for o in mine)}</ul>' if mine
                 else '<p class="muted">ما وضعت أي عرض بعد.</p>')
        if adverts:
            # at the top, folded into one button while he has offers to look at (open at once when he has none or something was wrong)
            form = f"""<details class="add-fold"{" open" if error or typed or not mine else ""}><summary>+ أضف عرضًا جديدًا</summary>
<form method="post" action="/owner/offers" class="stack panel">{ui.csrf_input(ctx.csrf)}
<div class="row2">{ui.field("عنوان العرض", "title", typed.get("title", ""), required=True, hint="مثل: خصم الويكند", attrs='maxlength="60"')}{ui.field("نسبة الخصم %", "percent", typed.get("percent", ""), required=True, hint="رقم من 1 إلى 90", attrs='inputmode="numeric"')}</div>
{ui.select("يشمل", "listing", adverts, typed.get("listing", ""), blank="كل إعلاناتي")}
<div class="row2">{ui.field("من", "starts", typed.get("starts", today), type="date", required=True)}{ui.field("إلى", "ends", typed.get("ends", ""), type="date", required=True, attrs=f'min="{today}"')}</div>
<button class="btn sun" type="submit">أضف العرض</button></form></details>"""
        else:
            form = ('<section class="empty"><h2>أضف استراحتك أولًا</h2><p>العرض يكون على إعلان من إعلاناتك.</p>'
                    '<a class="btn sun" href="/owner/new">أضف استراحتك</a></section>')
        how = """<details class="more"><summary>كيف يعمل الخصم؟</summary><ul class="how">
<li>يظهر الخصم للزوار على سعر استراحتك في الرئيسية وصفحة «العروض» وصفحة الإعلان، ولا يغيّر السعر الذي كتبته أنت.</li>
<li>الخصم قرارك أنت، وتلتزم بالسعر بعد الخصم مع العميل. والعمولة تُحسب على قيمة الإيجار الفعلية بعد الخصم.</li>
<li>إذا انطبق أكثر من عرض على استراحتك يظهر الأكبر فقط، ولا تُجمع النسب.</li>
<li>ينتهي العرض وحده بعد تاريخ «إلى»، وتقدر توقفه أو تحذفه في أي وقت.</li>
<li>للإدارة حق إيقاف أي عرض غير مناسب.</li></ul></details>"""
        body = f"""{ui.notice("ok", ctx.flash())}{ui.notice("bad", error)}<div class="head"><h1>عروضي</h1></div>
<p class="muted">ضع خصمًا على استراحتك ليظهر للزوار بجانب السعر.</p>
{form}{shown}{how}"""
        return html_page(ctx, "عروضي", body, status, noindex=True)

    @app.route("POST", "/owner/offers", "owner")
    async def owner_offer_add(ctx: Ctx):
        f, uid, today = ctx.request, ctx.owner["id"], ctx.today()
        typed = {k: f.field(k).strip() for k in _COLUMNS}                      # kept in the form when something is wrong

        def refuse(problem: str):
            return owner_offers(ctx, problem, typed, 400)

        title, pct = util.clean_text(f.field("title"))[:60], util.parse_int(f.field("percent"), 1, 90)
        start, end = util.parse_date(f.field("starts")), util.parse_date(f.field("ends"))
        raw = f.field("listing").strip()
        lid = util.parse_int(raw, 1, 10**9) if raw else None
        if len(title) < 3:
            return await refuse("اكتب عنوانًا للعرض (3 أحرف على الأقل)")
        if not pct:
            return await refuse("نسبة الخصم رقم من 1 إلى 90")
        if not start or not end or end < start:
            return await refuse("اختر تاريخي «من» و«إلى»، وتاريخ «إلى» بعد «من» أو مثله")
        if end < today:
            return await refuse("تاريخ «إلى» مضى، اختر تاريخًا من اليوم فصاعدًا")
        if end > today + timedelta(days=MAX_DAYS_AHEAD):
            return await refuse("أقصى مدة للعرض سنة من اليوم")
        if raw:
            advert = repo.any_listing(db, lid) if lid else None
            if not advert or advert["owner_id"] != uid:
                return await refuse("اختر إعلانًا من إعلاناتك")                  # the same words for an advert that is not his and one that is not there
        if db.one("SELECT COUNT(*) AS n FROM offers WHERE owner_id = ?", (uid,))["n"] >= MAX_PER_OWNER:
            return await refuse(f"وصلت للحد الأعلى ({MAX_PER_OWNER} عرضًا). احذف عروضًا قديمة لتضيف غيرها")
        db.run("INSERT INTO offers(title, percent, listing_id, starts_on, ends_on, owner_id) VALUES (?,?,?,?,?,?)",
               (title, pct, lid, start.isoformat(), end.isoformat(), uid))
        db.audit(uid, "owner_offer_new", f"{title} {pct}%")
        return redirect("/owner/offers?msg=أضفنا عرضك، ويظهر للزوار من تاريخ البداية")

    @app.route("POST", r"/owner/offer/(\d{1,9})/(toggle|delete)", "owner")
    async def owner_offer_edit(ctx: Ctx, raw: str, action: str):
        o = db.one("SELECT * FROM offers WHERE id = ? AND owner_id = ?", (int(raw), ctx.owner["id"]))
        if not o:
            return not_found(ctx)                                               # an offer of somebody else looks exactly like one that is not there
        if action == "delete":
            db.run("DELETE FROM offers WHERE id = ?", (o["id"],))
            return redirect("/owner/offers?msg=حذفنا العرض")
        if o["locked"]:
            return redirect("/owner/offers?msg=أوقفته الإدارة، تواصل معها للاستفسار")
        if o["ends_on"] < ctx.today().isoformat():
            return redirect("/owner/offers?msg=انتهى هذا العرض، احذفه وأضف عرضًا جديدًا")
        db.run("UPDATE offers SET active = 1 - active WHERE id = ?", (o["id"],))
        return redirect("/owner/offers?msg=" + ("أوقفنا العرض، لا يظهر للزوار" if o["active"] else "فعّلنا العرض"))

    # ================================================================== the manager: «العروض»
    @app.route("GET", "/admin/offers", "admin")
    async def offers_page(ctx: Ctx, error: str = "", values: dict | None = None, status: int = 200):
        today = ctx.today().isoformat()
        typed = values or {}
        rows = _offers(db)
        total = db.one("SELECT COUNT(*) AS n FROM offers")["n"]
        shown = (f'<ul class="com-list">{"".join(_card(ctx, o, today, True) for o in rows)}</ul>' if rows
                 else '<p class="muted">لا توجد عروض بعد. أضف أول عرض من النموذج أدناه.</p>')
        more = f'<p class="muted">يظهر هنا آخر {MAX_SHOWN} عرضًا من {total}.</p>' if total > len(rows) else ""
        cities = [(c["id"], c["name"]) for c in db.all("SELECT * FROM cities WHERE active = 1 ORDER BY sort, id")]
        cats = [(c["id"], c["name"]) for c in db.all("SELECT * FROM categories WHERE active = 1 ORDER BY sort, id")]
        adverts = [(r["id"], f'{r["title"]} — {r["city"]}') for r in db.all(
            "SELECT l.id, l.title, c.name AS city FROM listings l JOIN cities c ON c.id = l.city_id WHERE l.review = 'approved' ORDER BY l.id DESC LIMIT 300")]
        form = f"""<form method="post" action="/admin/offers" class="stack panel"><h2>عرض جديد من الإدارة</h2>{ui.csrf_input(ctx.csrf)}
<p class="muted">الخصم قرار المالك وهو يضيفه بنفسه من حسابه («عروضي»). هذا النموذج لعرض تضعه الإدارة بنفسها.</p>
<div class="row2">{ui.field("عنوان العرض", "title", typed.get("title", ""), required=True, hint="مثل: خصم الويكند", attrs='maxlength="60"')}{ui.field("نسبة الخصم %", "percent", typed.get("percent", ""), required=True, hint="رقم من 1 إلى 90", attrs='inputmode="numeric"')}</div>
<div class="row3">{ui.select("المدينة (اختياري)", "city", cities, typed.get("city", ""), blank="كل المدن")}{ui.select("النوع (اختياري)", "category", cats, typed.get("category", ""), blank="كل الأنواع")}{ui.select("إعلان محدد (اختياري)", "listing", adverts, typed.get("listing", ""), blank="كل الإعلانات")}</div>
<div class="row2">{ui.field("من", "starts", typed.get("starts", ctx.today().isoformat()), type="date", required=True)}{ui.field("إلى", "ends", typed.get("ends", ""), type="date", required=True)}</div>
<button class="btn" type="submit">إضافة العرض</button></form>"""
        # the form stays folded away (the owners make their own offers) unless something was typed in it or went wrong
        folded = f'<details class="more"{" open" if error or typed else ""}><summary>إضافة عرض من الإدارة</summary>{form}</details>'
        how = """<details class="more"><summary>كيف تعمل العروض؟</summary><ul class="how">
<li>العرض خصم يظهر للزوار على سعر الإعلان، في صفحة «العروض» وفي الرئيسية وفي صفحة الإعلان، ولا يغيّر السعر الذي كتبه المالك.</li>
<li>إذا انطبق أكثر من عرض على إعلان يظهر الأكبر فقط. وينتهي العرض وحده بعد تاريخ «إلى».</li>
<li>عرض المالك لا ينطبق إلا على إعلاناته هو.</li>
<li>إذا أوقفت عرض مالك يبقى موقوفًا ولا يقدر المالك يفعّله حتى ترفع الإيقاف، وبعد رفعه يفعّله المالك بنفسه. وعرض أوقفه المالك بنفسه لا تقدر تفعّله أنت.</li>
<li>عروضك أنت يمكن أن تشمل كل الإعلانات أو مدينة أو نوعًا أو إعلانًا بعينه.</li></ul></details>"""
        # the founders' offer is the platform's own marketing offer, kept in a box of its own above the discounts (it is not one of them)
        body = f"""{ui.notice("ok", ctx.flash())}{ui.notice("bad", error)}<h1>العروض والخصومات</h1>
{founders_box(db, ctx.today())}<h2>خصومات الاستراحات</h2>
<p class="muted">الخصم قرار المالك، وهو يضيف عروض استراحاته بنفسه من حسابه، وتظهر هنا كلها مع اسم صاحبها وتقدر توقف أي عرض منها.</p>
{shown}{more}{folded}{how}"""
        return admin_page(ctx, "العروض", body, status)

    @app.route("POST", "/admin/offers", "admin")
    async def offer_add(ctx: Ctx):
        f = ctx.request
        title, pct = f.field("title").strip()[:60], util.parse_int(f.field("percent"), 1, 90)
        start, end = util.parse_date(f.field("starts")), util.parse_date(f.field("ends"))
        city, cat = util.parse_int(f.field("city"), 1, 10**9), util.parse_int(f.field("category"), 1, 10**9)
        lid = util.parse_int(f.field("listing"), 1, 10**9) if f.field("listing").strip() else None
        typed = {k: f.field(k).strip() for k in ("title", "percent", "city", "category", "listing", "starts", "ends")}      # kept in the form when something is wrong
        if len(title) < 3 or not pct or not start or not end or end < start:
            return await offers_page(ctx, "اكتب عنوانًا ونسبة بين 1 و90 وتاريخين صحيحين (تاريخ «إلى» بعد «من»)", typed, 400)
        if lid and not repo.any_listing(db, lid):
            return await offers_page(ctx, "الإعلان المختار غير موجود", typed, 400)
        db.run("INSERT INTO offers(title, percent, city_id, category_id, listing_id, starts_on, ends_on) VALUES (?,?,?,?,?,?,?)",
               (title, pct, city, cat, lid, start.isoformat(), end.isoformat()))
        db.audit(ctx.admin["id"], "offer_new", f"{title} {pct}%")
        return redirect("/admin/offers?msg=أضفنا العرض")

    @app.route("POST", r"/admin/offer/(\d{1,9})/(toggle|lift|delete)", "admin")
    async def offer_edit(ctx: Ctx, raw: str, action: str):
        o = db.one("SELECT o.*, u.name AS owner_name FROM offers o LEFT JOIN users u ON u.id = o.owner_id WHERE o.id = ?", (int(raw),))
        if not o:
            return redirect("/admin/offers?msg=هذا العرض غير موجود")
        who = f' ({o["owner_name"]})' if o["owner_id"] else ""
        if action == "delete":
            db.run("DELETE FROM offers WHERE id = ?", (o["id"],))
            db.audit(ctx.admin["id"], "offer_delete", f'{o["title"]}{who}')
            return redirect("/admin/offers?msg=حذفنا العرض")
        if action == "lift":                                     # the manager lets the owner start his own offer again; it stays off until the owner starts it
            if not (o["owner_id"] and o["locked"]):
                return redirect("/admin/offers?msg=هذا العرض ليس موقوفًا من الإدارة")
            db.run("UPDATE offers SET locked = 0 WHERE id = ?", (o["id"],))
            db.audit(ctx.admin["id"], "offer_lift", f'{o["title"]}{who}')
            return redirect("/admin/offers?msg=رفعنا الإيقاف، ويقدر المالك يفعّل عرضه")
        if o["owner_id"]:                                        # an owner's offer: the manager can only stop it, and then the owner cannot start it
            if o["locked"] or not o["active"]:
                return redirect("/admin/offers?msg=هذا العرض موقوف أصلًا")
            db.run("UPDATE offers SET active = 0, locked = 1 WHERE id = ?", (o["id"],))
            db.audit(ctx.admin["id"], "offer_stop", f'{o["title"]}{who}')
            return redirect("/admin/offers?msg=أوقفنا العرض، ولا يقدر المالك يفعّله حتى ترفع الإيقاف")
        db.run("UPDATE offers SET active = 1 - active WHERE id = ?", (o["id"],))
        return redirect("/admin/offers?msg=تم")
