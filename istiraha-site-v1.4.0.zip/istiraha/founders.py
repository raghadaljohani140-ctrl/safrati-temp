"""The founders' offer («عرض المؤسسين»): the first 100 adverts pay no commission for one full year.

What this module does, and what it leaves alone:
 * an advert that is approved while the offer runs gets one row in `founder_exemptions` holding the first and the last day of ITS OWN year
   (the year starts the day the advert gets it, never on the day the site or the campaign started);
 * the hundred is counted from those rows, never from a typed number, and the database itself refuses a 101st row;
 * a rental dated inside an advert's year is recorded as «معفاة» (waived), the state the site already had for a commission nobody expects.
   The commission rate, the pledge and every rental outside the year are not touched: when the year is over the agreed rate applies again.
The site has no booking and no online payment: the manager writes the rentals down himself, and this is where the free year shows up.
It only imports the database and the small helpers, so the pages and the repository can both use it."""
from __future__ import annotations

from datetime import date, timedelta

from . import util
from .db import Database

CAP = 100                      # the same number as the trigger in MIGRATION_V4 (a test keeps the two together)
SETTING = "founders_on"        # the settings key: "1" while the offer runs; "0" (or nothing) while it is paused. It starts paused.

NAME = "عرض المؤسسين"
TITLE = f"عرض المؤسسين — أول {CAP} استراحة بدون عمولة لمدة سنة كاملة!"
HEADLINE = f"🎁 سجّل استراحتك الآن واحصل على سنة كاملة بدون عمولة — لأول {CAP} استراحة فقط!"
DESCRIPTION = (f"تحصل كل استراحة من أول {CAP} استراحة مؤهلة على سنة كاملة بدون عمولة للمنصة. تبدأ السنة من تاريخ تفعيل الإعفاء "
               "لتلك الاستراحة، وبعد اكتمالها تُطبّق العمولة المعتمدة في المنصة.")

# the terms as the manager reads them (the seven rules of the offer, in his words) and, shorter, as a visitor reads them on the home page
TERMS_ADMIN = (
    f"العرض مخصص لأول {CAP} استراحة مؤهلة فقط. المؤهلة هي الاستراحة التي يُعتمد إعلانها وينشر في المنصة أثناء ما يكون العرض نشطًا.",
    "تحصل كل استراحة مستفيدة على سنة كاملة بدون عمولة للمنصة.",
    "تبدأ السنة من تاريخ تفعيل الإعفاء الخاص بالاستراحة (يوم اعتماد إعلانها)، وليس من تاريخ إطلاق الموقع أو بداية الحملة الإعلانية.",
    "بعد اكتمال السنة ينتهي الإعفاء وتُطبّق العمولة المعتمدة في المنصة.",
    f"لا يُمنح الإعفاء للاستراحة رقم {CAP + 1}: يرفضه النظام، وتحميه قاعدة البيانات نفسها.",
    "عدد المستفيدين والمقاعد المتبقية يُحسبان من السجلات الفعلية، لا من رقم مكتوب باليد.",
    "تاريخ بداية الإعفاء ونهايته محفوظان لكل استراحة بشكل مستقل ولا يتغيران.",
)
HOW_ADMIN = (
    "المنصة لا تستقبل حجوزات ولا مدفوعات، وأنت من تسجّل عمليات التأجير. عند تسجيل عملية بتاريخ داخل سنة إعفاء الاستراحة تُسجَّل «معفاة» تلقائيًا ولا تدخل في الأرباح.",
    "عملية بتاريخ بعد نهاية السنة (أو قبل بدايتها) تُحسب عليها العمولة المتفق عليها كالمعتاد.",
    "عمليات سُجلت قبل منح الإعفاء لا تتغير وحدها، وتقدر تعدّل حالة سدادها بنفسك من صفحة العملية.",
    "إيقاف العرض لا يلغي إعفاء أخذته استراحة: يستمر حتى تاريخ نهايته. الإيقاف يمنع المنح الجديد ويخفي الإعلان من الرئيسية فقط.",
    "الاستراحة تأخذ مقعدها عند نشر إعلانها، فإن كان النشر عندك «تلقائيًا» يأخذ مقعدًا أي إعلان ينزل بصورة. اختر «بعد موافقتي» من الإعدادات إن أردت مراجعة كل إعلان قبل أن يأخذ مقعدًا.",
)
TERMS_PUBLIC = (
    f"العرض لأول {CAP} استراحة فقط، والمقاعد بالأسبقية: تُحجز للاستراحة عند اعتماد إعلانها ونشره في المنصة.",
    "كل استراحة مستفيدة لا تُحسب عليها عمولة للمنصة سنة كاملة، تبدأ من تاريخ تفعيل الإعفاء لها وليس من تاريخ إطلاق الحملة.",
    "بعد انتهاء السنة تُطبّق العمولة المعتمدة في المنصة.",
    "الاتفاق على السعر والدفع يبقى بينك وبين العميل مباشرة.",
)

STATE_LABELS = {"active": "ساري", "ended": "منتهٍ"}
STATE_KIND = {"active": "ok", "ended": "muted"}


# ---- the switch and the count ---------------------------------------------------------------------------------------------
def is_on(db: Database) -> bool:
    return db.setting(SETTING) == "1"


def set_on(db: Database, on: bool) -> None:
    db.put_setting(SETTING, "1" if on else "0")


def taken(db: Database) -> int:
    """The adverts that got their free year, counted from the rows themselves."""
    return db.one("SELECT COUNT(*) AS n FROM founder_exemptions")["n"]


def left(db: Database) -> int:
    return max(0, CAP - taken(db))


def running(db: Database) -> bool:
    """The offer is switched on and a seat is still free: the only time the home page shows the advert."""
    return is_on(db) and taken(db) < CAP


# ---- one advert's year ----------------------------------------------------------------------------------------------------
def last_day(start: date) -> date:
    """The last day of a full year that begins on `start`: the day before the next anniversary (so 28 Oct 2026 runs to 27 Oct 2027).
    A year that begins on 29 February has no such day next year, so its anniversary is 1 March and it runs to 28 February."""
    try:
        anniversary = start.replace(year=start.year + 1)
    except ValueError:
        anniversary = date(start.year + 1, 3, 1)
    return anniversary - timedelta(days=1)


def state_of(row, today_iso: str) -> str:
    """"active" while the last day has not passed (the last day itself still counts), "ended" after it."""
    return "ended" if row["ends_on"] < today_iso else "active"


def exemption_of(db: Database, listing_id: int):
    return db.one("SELECT * FROM founder_exemptions WHERE listing_id = ?", (listing_id,))


def covering(db: Database, listing_id: int, day_iso: str):
    """The advert's free year when `day_iso` falls inside it (both the first and the last day count), else None."""
    return db.one("SELECT * FROM founder_exemptions WHERE listing_id = ? AND starts_on <= ? AND ends_on >= ?", (listing_id, day_iso, day_iso))


def of_owner(db: Database, owner_id: int) -> list:
    return db.all("""SELECT f.*, l.title FROM founder_exemptions f JOIN listings l ON l.id = f.listing_id
                     WHERE l.owner_id = ? ORDER BY f.id""", (owner_id,))


# ---- giving the free year -------------------------------------------------------------------------------------------------
def grant(db: Database, listing_id: int, today: date, now: float, admin_id: int | None = None) -> bool:
    """Gives an approved advert its free year, starting `today`, if it has none yet and a seat is free. True when it did.
    It checks and inserts in ONE statement, so two adverts approved together cannot both take the last seat; the trigger of the
    database is a second lock behind this one. It does not look at the on/off switch: the callers decide that."""
    end = last_day(today)
    done = db.conn.execute(
        """INSERT INTO founder_exemptions(listing_id, starts_on, ends_on, granted_at, granted_by)
           SELECT l.id, ?, ?, ?, ? FROM listings l
           WHERE l.id = ? AND l.review = 'approved'
             AND NOT EXISTS (SELECT 1 FROM founder_exemptions f WHERE f.listing_id = l.id)
             AND (SELECT COUNT(*) FROM founder_exemptions) < ?""",
        (today.isoformat(), end.isoformat(), now, admin_id, listing_id, CAP)).rowcount
    if done != 1:
        return False
    title = db.one("SELECT title FROM listings WHERE id = ?", (listing_id,))["title"]
    db.audit(admin_id, "founders_grant", f"{title} · مقعد {taken(db)} من {CAP} · من {today.isoformat()} إلى {end.isoformat()}")
    return True


def grant_if_open(db: Database, listing_id: int, today: date, now: float, admin_id: int | None = None) -> bool:
    """What approving an advert does: it gets the free year only while the offer is switched on."""
    return is_on(db) and grant(db, listing_id, today, now, admin_id)


def refusal(db: Database, listing) -> str:
    """Why this advert cannot be given the free year by hand right now, in words for the manager ("" when it can)."""
    if exemption_of(db, listing["id"]):
        return "هذا الإعلان نال إعفاءه من قبل"
    if not is_on(db):
        return "العرض متوقف، فعّله أولًا"
    if listing["review"] != "approved":
        return "الإعلان غير معتمد بعد، ويأخذ إعفاءه تلقائيًا عند اعتماده"
    if taken(db) >= CAP:
        return f"اكتملت المقاعد ({CAP} من {CAP})"
    return ""


# ---- what the manager reads -----------------------------------------------------------------------------------------------
def beneficiaries(db: Database) -> list:
    """Every advert with a free year, in the order they got it (the first seat first)."""
    return db.all("""SELECT f.*, l.title, l.owner_id, c.name AS city, u.name AS owner_name
                     FROM founder_exemptions f JOIN listings l ON l.id = f.listing_id JOIN cities c ON c.id = l.city_id JOIN users u ON u.id = l.owner_id
                     ORDER BY f.id""")


def summary(db: Database, today: date) -> dict:
    """The figures of the offer, all from the rows: seats taken and left, years running and over, and the rentals that were waived inside a year."""
    count = taken(db)
    active = db.one("SELECT COUNT(*) AS n FROM founder_exemptions WHERE ends_on >= ?", (today.isoformat(),))["n"]
    waived = db.one("""SELECT COUNT(*) AS n, COALESCE(SUM(r.commission_halalas), 0) AS halalas FROM rentals r
                       JOIN founder_exemptions f ON f.listing_id = r.listing_id
                       WHERE r.pay_status = 'waived' AND r.status != 'cancelled' AND r.rental_date >= f.starts_on AND r.rental_date <= f.ends_on""")
    return {"on": is_on(db), "cap": CAP, "taken": count, "left": max(0, CAP - count), "active": active, "ended": count - active,
            "waived_rentals": waived["n"], "waived_halalas": waived["halalas"]}


def days_text(ends_on: str, today: date) -> str:
    """How long the year has left, in words ("" when it is over)."""
    end = util.parse_date(ends_on)
    if not end or end < today:
        return ""
    n = (end - today).days
    if n == 0:
        return "ينتهي اليوم"
    if n == 1:
        return "ينتهي غدًا"
    if n == 2:
        return "متبقي يومان"
    return f"متبقي {n} أيام" if n <= 10 else f"متبقي {n} يومًا"
