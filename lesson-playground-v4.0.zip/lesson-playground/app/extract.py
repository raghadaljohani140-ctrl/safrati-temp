"""Reading a lesson file into plain text: PDF, PowerPoint (.pptx) and page pictures (JPG / PNG). All free and local: nothing leaves the server."""
import io
import re
import unicodedata

from . import meta as lesson_meta, pdfgeo

KINDS = {"pdf": "pdf", "pptx": "pptx", "jpg": "image", "jpeg": "image", "png": "image"}
MIN_CHARS = 40          # less than this and the file has no readable text


class ExtractError(Exception):
    pass


def detect(filename: str, head: bytes) -> str:
    """The kind of file by its extension AND its first bytes (a renamed file is refused)."""
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    kind = KINDS.get(ext)
    if kind == "pdf" and head[:5] == b"%PDF-":
        return "pdf"
    if kind == "pptx" and head[:4] == b"PK\x03\x04":
        return "pptx"
    if kind == "image" and (head[:3] == b"\xff\xd8\xff" or head[:8] == b"\x89PNG\r\n\x1a\n"):
        return "image"
    raise ExtractError("نوع الملف غير مدعوم. ارفعي PDF أو PowerPoint (pptx) أو صورة JPG/PNG")


_COMMON = ("في من على التي الذي الذين هو هي إلى عن أن إن هذا هذه ذلك كل ما مع لا أو ثم بين عند حتى بعد قبل قد لم لن كان كانت يكون تكون أي بعض غير كما لكن إذا عليه عليها منه منها فيه فيها به بها له لها هم هن نحن أنا أنت هل ماذا لماذا كيف أول ثاني وهو وهي وفي ومن وعلى ولا وقد أيضا حيث عندما بدون خلال مثل جميع عدة هناك الله").split()
_DIAC = re.compile("[\u064b-\u065f\u0670\u0640]")


def _plain(word: str) -> str:
    """A word with one spelling for every look-alike letter, so that «على» and «علي» (or a final ة / ه) count as the same word."""
    word = _DIAC.sub("", arabic_letters(word.strip(".,،:؛؟!?()[]«»\"'-–—")))
    return word.translate(str.maketrans({"ى": "ي", "ة": "ه", "أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا"}))


_COMMON_SET = set()          # filled on first use


def _reversed_arabic(text: str) -> bool:
    """Some PDFs hand the letters over in visual order (every Arabic line comes out backwards). Spot it two ways: common words standing there reversed
    («يف», «نم»), or the article «ال» that starts a third of Arabic words standing at the END of words as «لا»."""
    if not _COMMON_SET:
        _COMMON_SET.update(_plain(w) for w in _COMMON)
    words = [_plain(w) for w in text.split()]
    words = [w for w in words if w]
    fwd = sum(1 for w in words if w in _COMMON_SET)
    rev = sum(1 for w in words if w[::-1] in _COMMON_SET and w not in _COMMON_SET)
    if rev >= 3 and rev > fwd * 1.3:
        return True
    al_fwd = sum(1 for w in words if len(w) > 3 and w.startswith("ال"))
    al_rev = sum(1 for w in words if len(w) > 3 and w.endswith("لا") and not w.startswith("ال"))
    return al_rev >= 5 and al_rev > al_fwd * 2


_NORM = str.maketrans({"ى": "ي", "ة": "ه", "أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا"})
_ONLY_LETTERS = re.compile("[^\u0621-\u064a\u0671-\u06d3]")
_MARKS = "\u064b-\u065f\u0670"


def _quality(text: str):
    """How much the text reads like Arabic written the right way round: about +0.7 for normal text, about -0.7 for backwards text; None when there are too few
    words to tell. Signs of the right way: common small words, the article «ال» opening a word, ة closing one. Signs of backwards: the same words reversed,
    «لا» closing a word, and ة opening one (which Arabic never does)."""
    if not _COMMON_SET:
        _COMMON_SET.update(_plain(w) for w in _COMMON)
    n = good = bad = 0
    for tok in text.split():
        w = _ONLY_LETTERS.sub("", _DIAC.sub("", arabic_letters(tok)))
        if len(w) < 2:
            continue
        n += 1
        p = w.translate(_NORM)
        if p in _COMMON_SET:
            good += 2
        elif p[::-1] in _COMMON_SET:
            bad += 2
        if len(p) > 3:
            if p.startswith("ال"):
                good += 1
            elif p.endswith("لا"):
                bad += 1
        if len(w) > 2:
            if w.endswith("ة"):
                good += 1
            elif w.startswith("ة"):
                bad += 3
    return (good - bad) / n if n >= 8 else None


def _letters(text: str) -> int:
    """How many Arabic letters the text holds (shaped forms counted as the letters they stand for)."""
    return sum(1 for c in unicodedata.normalize("NFKC", text) if "\u0621" <= c <= "\u064a")


def _fix_marks(text: str) -> str:
    """Marks (fatha, damma, shadda...) come AFTER their letter. Some readers hand them over before it, and then words start with a mark (which no real word
    does): put every such mark behind the letter it belongs to."""
    toks = text.split()
    starts = sum(1 for t in toks if t and ("\u064b" <= t[0] <= "\u065f" or t[0] == "\u0670"))
    if starts < 2:
        return text
    return re.sub("([%s]+)([^\\s%s])" % (_MARKS, _MARKS), r"\2\1", text)


def _words_backwards(text: str) -> str:
    """Every word turned round on its own, the words keeping their places."""
    return _fix_marks("\n".join(" ".join(w[::-1] for w in line.split(" ")) for line in text.splitlines()))


def _fix_visual_order(text: str, force: bool = False) -> str:
    """Turn shaped letters back into normal ones, and a backwards line the right way round (numbers and Latin words keep their own order)."""
    text = unicodedata.normalize("NFKC", text)
    letters = [c for c in text if "\u0600" <= c <= "\u06ff"]
    if len(letters) < 20:
        return text
    shaped = sum(1 for c in text if "\ufb50" <= c <= "\ufdff" or "\ufe70" <= c <= "\ufeff")
    if shaped or force or _reversed_arabic(text):
        fixed = []
        for line in text.splitlines():
            line = line[::-1]
            fixed.append(re.sub(r"[A-Za-z0-9][A-Za-z0-9.,%/:-]*", lambda m: m.group(0)[::-1], line))
        text = "\n".join(fixed)
    return text


def _reflow(text: str) -> str:
    """A PDF breaks every paragraph into lines: join a full-width line that does not end a sentence with the one after it (short lines are titles)."""
    out = []
    for line in text.splitlines():
        line = line.strip()
        if out and line and len(out[-1]) >= 45 and not lesson_meta.FIELD.search(out[-1] + "\n") and not lesson_meta.FIELD.search(line + "\n") and not re.search(r"[.!؟?:؛]$", out[-1]) and not re.match(r"^[•\-–—*·●▪◦\d]+[\).]?\s", line):
            out[-1] += " " + line
        else:
            out.append(line)
    return "\n".join(out)


_LETTER_MAP = str.maketrans({
    "\u06cc": "\u064a", "\u06d2": "\u064a", "\u06d3": "\u064a",                        # Persian / Urdu yeh -> Arabic yeh
    "\u06be": "\u0647", "\u06c1": "\u0647", "\u06c0": "\u0647", "\u06d5": "\u0647",    # the other hehs a bad font map gives -> Arabic heh
    "\u06a9": "\u0643", "\u06aa": "\u0643",                                      # Persian keheh -> Arabic kaf
    "\u0640": None, "\u200c": None, "\u200d": None, "\u00ad": None, "\u061c": None,      # tatweel, joiners and hidden marks that break words
})
_MID_ALEF_MAQSURA = re.compile("\u0649(?=[\u0621-\u064a\u0671-\u06d3])")


def arabic_letters(text: str) -> str:
    """Make every Arabic letter the one the font can join. Many PDFs hand over yeh as alef-maqsura (ى) or heh as a Urdu heh (ھ): they show as cut-off letters in the middle of a word."""
    text = unicodedata.normalize("NFKC", text).translate(_LETTER_MAP)
    return _MID_ALEF_MAQSURA.sub("\u064a", text)


def clean(text: str) -> str:
    text = arabic_letters(text)
    text = text.replace("\x00", "").replace("‏", "").replace("‎", "").replace(" ", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _arabic_share(text: str) -> float:
    letters = [c for c in text if c.isalpha()]
    return sum(1 for c in letters if "\u0600" <= c <= "\u06ff") / len(letters) if letters else 0.0


def _page_by_position(page) -> str:
    """Lines rebuilt from where each piece of text sits on the page. Some PDFs store an Arabic line left-to-right (its words reversed): then the pieces
    come in rising x and the line must be read backwards; a PDF that stores it in reading order has falling x and is left as it is."""
    frags = []

    def visit(text, cm, tm, font, size):
        t = text.replace("\n", " ").strip()
        if t:
            x = tm[4] * cm[0] + tm[5] * cm[2] + cm[4]
            y = tm[4] * cm[1] + tm[5] * cm[3] + cm[5]
            frags.append([x, y, size or 10, t])
    page.extract_text(visitor_text=visit)
    lines = []                                   # [y, size, [fragments in file order]]
    for x, y, size, t in frags:
        for ln in lines:
            if abs(ln[0] - y) <= max(2.0, ln[1] * 0.45):
                ln[2].append((x, t))
                break
        else:
            lines.append([y, size, [(x, t)]])
    out = []
    for y, size, parts in sorted(lines, key=lambda ln: -ln[0]):
        joined = " ".join(t for _, t in parts)
        if len(parts) > 1 and _arabic_share(joined) > 0.5:
            steps = [b[0] - a[0] for a, b in zip(parts, parts[1:])]
            if sum(1 for d in steps if d > 0) > 0.7 * len(steps):
                parts = parts[::-1]
                joined = " ".join(t for _, t in parts)
        out.append(joined)
    return "\n".join(out)


def _legacy_pdf(reader) -> str:
    """The first reader: pypdf's own text, repaired by what the file looks like (words in the wrong order, lines backwards)."""
    raw = [(p.extract_text() or "") for p in reader.pages[:200]]
    joined = unicodedata.normalize("NFKC", "\n".join(raw))
    backwards = _arabic_share(joined) > 0.5 and _reversed_arabic(joined)          # one program wrote the whole file, so one decision for all of it
    pages = []
    for p, text in zip(reader.pages[:200], raw):
        if backwards:
            pages.append(_fix_visual_order(text, force=True))
            continue
        if _arabic_share(unicodedata.normalize("NFKC", text)) > 0.5:
            try:
                text = _page_by_position(p) or text
            except Exception:
                pass                                   # positions unreadable: keep the plain text
        pages.append(text)
    return "\n\n".join(_reflow(_fix_visual_order(p)) if not backwards else _reflow(p) for p in pages)


def _pdf_text(data: bytes):
    """(text, warning). The warning is set when the letters of an Arabic file could not be put the right way round with confidence."""
    from pypdf import PdfReader
    try:
        reader = PdfReader(io.BytesIO(data))
        if reader.is_encrypted:
            raise ExtractError("ملف PDF محمي بكلمة مرور")
        sample, seen = "", []
        for p in reader.pages[:12]:                    # the first pages with some text tell what language the file is in
            seen.append(p.extract_text() or "")
            sample += "\n" + seen[-1]
            if len(sample) > 600:
                break
        if not _arabic_share(unicodedata.normalize("NFKC", sample)) > 0.3:
            return _legacy_pdf(reader), ""
        # Arabic: read the letters where they sit on the page (the same for every program), and keep the older reader as a second opinion
        pages = pdfgeo.pages(data)
        geo = "\n\n".join(_reflow(p) for p in pages) if pages else ""
        if geo and (len(geo.strip()) < MIN_CHARS or _letters(" ".join(pages[:len(seen)])) < 0.6 * _letters(" ".join(seen))):
            geo = ""                                   # it missed text the plain reader found: do not rely on it alone
        q = _quality(geo) if geo else None
        if geo and (q is None or q >= 0.2):
            return _fix_marks(geo), ""
        cands = [("geo", geo)] if geo else []
        cands.append(("old", _legacy_pdf(reader)))
        for name, t in list(cands):
            cands.append((name + "/words", _words_backwards(t)))
            cands.append((name + "/lines", _reflow(_fix_visual_order(t, force=True))))
        scored = []
        for order, (name, t) in enumerate(cands):
            score = _quality(t)
            scored.append((0.0 if score is None else score, -order, t))
        best = max(scored)
        text = _fix_marks(best[2])
        warn = "" if best[0] >= 0.0 else "لم نستطع ضبط اتجاه الحروف في هذا الملف بثقة، فقد تظهر بعض الكلمات معكوسة. جرّبي حفظه من جديد بصيغة PDF (طباعة إلى PDF)، أو ارفعيه PowerPoint أو صورة"
        return text, warn
    except ExtractError:
        raise
    except Exception:
        raise ExtractError("تعذرت قراءة ملف PDF، قد يكون تالفًا")


def from_pdf(data: bytes) -> str:
    return _pdf_text(data)[0]


def from_pptx(data: bytes) -> str:
    from pptx import Presentation
    try:
        prs = Presentation(io.BytesIO(data))
    except Exception:
        raise ExtractError("تعذرت قراءة ملف PowerPoint، تأكدي أنه بصيغة pptx وليس ppt القديمة")
    out = []
    for slide in list(prs.slides)[:200]:
        parts = []
        for shape in slide.shapes:
            if shape.has_text_frame:
                parts.append("\n".join(p.text for p in shape.text_frame.paragraphs if p.text.strip()))
            if getattr(shape, "has_table", False) and shape.has_table:
                for row in shape.table.rows:
                    parts.append(" — ".join(c.text.strip() for c in row.cells if c.text.strip()))
        if slide.has_notes_slide:
            parts.append(slide.notes_slide.notes_text_frame.text)
        out.append("\n".join(x for x in parts if x.strip()))
    return "\n\n".join(out)


def from_image(data: bytes) -> str:
    """Free OCR with Tesseract. Arabic needs its language pack on the server (tesseract-ocr-ara, installed by the Dockerfile)."""
    try:
        import pytesseract
        from PIL import Image
        img = Image.open(io.BytesIO(data))
        img.load()
        if img.width * img.height > 40_000_000:
            raise ExtractError("الصورة كبيرة جدًا")
        langs = pytesseract.get_languages()
        use = "+".join(x for x in ("ara", "eng") if x in langs)
        if not use:
            raise ExtractError("قراءة الصور غير متاحة على هذا الخادم")
        text = pytesseract.image_to_string(img.convert("L"), lang=use)
    except ExtractError:
        raise
    except Exception:
        raise ExtractError("تعذرت قراءة الصورة")
    if len(text.strip()) < MIN_CHARS and "ara" not in langs:
        raise ExtractError("لم نستطع قراءة الصورة: قراءة العربية من الصور تحتاج حزمة اللغة العربية على الخادم. ارفعي الدرس PDF أو PowerPoint أو صورة أوضح")
    return text


def read(kind: str, data: bytes):
    """(the lesson text without its subject / class header, {"subject", "grade", "warn"} for what the header names and what the reader doubts)."""
    warn = ""
    if kind == "pdf":
        text, warn = _pdf_text(data)
    else:
        text = {"pptx": from_pptx, "image": from_image}[kind](data)
    text, details = lesson_meta.split_header(clean(text))
    if len(text) < MIN_CHARS:
        raise ExtractError("لم نجد نصًا كافيًا في الملف. إن كان صفحات ممسوحة ضوئيًا فجرّبي صورًا أوضح أو ملفًا فيه نص")
    if warn:
        details = dict(details, warn=warn)
    return text, details


def extract(kind: str, data: bytes) -> str:
    return read(kind, data)[0]
