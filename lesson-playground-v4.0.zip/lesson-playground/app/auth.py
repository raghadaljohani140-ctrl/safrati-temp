import re

from flask import Blueprint, current_app, g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from .db import now, setting
from .security import EMAIL, Limiter, login_required

bp = Blueprint("auth", __name__)
login_limit = Limiter(8, 600)
register_limit = Limiter(5, 3600)
register_day_limit = Limiter(20, 86400)
DUMMY = generate_password_hash("not-a-real-password")


def _page(template, **kw):
    return render_template(template, **kw)


@bp.get("/")
def home():
    if g.user:
        return redirect(url_for("lessons.dashboard"))
    return _page("home.html")


CLOSED = "التسجيل الجديد متوقف مؤقتًا. جرّبي لاحقًا"


def registrations_open() -> bool:
    return setting(current_app.db, "registrations_open", "1") != "0"          # the manager can close new sign-ups from the platform settings


@bp.get("/register")
def register():
    return _page("auth.html", mode="register", error="" if registrations_open() else CLOSED, form={})


@bp.post("/register")
def register_post():
    f = request.form
    name, email, pw = f.get("name", "").strip()[:60], f.get("email", "").strip().lower(), f.get("password", "")
    err = ""
    if not registrations_open():
        err = CLOSED
    elif not (register_limit.allow(request.remote_addr) and register_day_limit.allow(request.remote_addr)):
        err = "محاولات كثيرة، جرّبي لاحقًا"
    elif len(name) < 2:
        err = "اكتبي اسمك"
    elif not EMAIL.match(email):
        err = "اكتبي بريدًا إلكترونيًا صحيحًا"
    elif len(pw) < 8:
        err = "كلمة المرور 8 خانات على الأقل"
    elif pw != f.get("password2", pw):
        err = "كلمتا المرور غير متطابقتين"
    elif f.get("terms") != "1":
        err = "لازم توافقين على الشروط والخصوصية"
    elif current_app.db.execute("SELECT 1 FROM users WHERE email = ?", (email,)).fetchone():
        err = "هذا البريد مسجل من قبل، سجّلي دخولك"
    if err:
        return _page("auth.html", mode="register", error=err, form={"name": name, "email": email}), 400
    cur = current_app.db.execute("INSERT INTO users(email, name, pass_hash, created_at) VALUES (?,?,?,?)",
                                 (email, name, generate_password_hash(pw), now()))
    current_app.db.commit()
    session.clear()
    session["uid"] = cur.lastrowid
    return redirect(url_for("lessons.dashboard"))


@bp.get("/login")
def login():
    return _page("auth.html", mode="login", error="", form={})


@bp.post("/login")
def login_post():
    email, pw = request.form.get("email", "").strip().lower(), request.form.get("password", "")
    key = (request.remote_addr, email)
    if not login_limit.allow(key):
        return _page("auth.html", mode="login", error="محاولات كثيرة، انتظري 10 دقائق ثم أعيدي", form={"email": email}), 429
    row = current_app.db.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
    ok = check_password_hash(row["pass_hash"] if row else DUMMY, pw)       # the same work whether or not the e-mail exists
    if not (row and ok):
        return _page("auth.html", mode="login", error="البريد أو كلمة المرور غير صحيحة", form={"email": email}), 400
    login_limit.reset(key)
    session.clear()
    session["uid"] = row["id"]
    return redirect(url_for("lessons.dashboard"))


@bp.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("auth.home"))


@bp.get("/terms")
def terms():
    return _page("terms.html")
