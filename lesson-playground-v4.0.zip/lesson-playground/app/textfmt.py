"""Counting in Arabic the way a teacher writes it: سؤال واحد، سؤالان، 3 أسئلة، 11 سؤالًا (the same rule is in app.js for the pages built in the browser)."""


def count(n, one: str, two: str, few: str, many: str) -> str:
    """one: the noun alone for 1 («سؤال واحد»); two: the dual for 2; few: the plural after 3 to 10 and for 0; many: the singular accusative after 11 and over."""
    try:
        n = int(n)
    except (TypeError, ValueError):
        n = 0
    if n == 1:
        return one
    if n == 2:
        return two
    if 3 <= n <= 10 or n == 0:
        return f"{n} {few}"
    return f"{n} {many}"


def questions(n) -> str:
    return count(n, "سؤال واحد", "سؤالان", "أسئلة", "سؤالًا")


def students(n) -> str:
    return count(n, "طالب واحد", "طالبان", "طلاب", "طالبًا")
