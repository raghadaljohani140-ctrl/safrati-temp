import json
import sqlite3
import threading
import time

SCHEMA = """
CREATE TABLE IF NOT EXISTS plans(
  code TEXT PRIMARY KEY, name TEXT NOT NULL, max_lessons INTEGER NOT NULL, max_decks INTEGER NOT NULL,
  price_month INTEGER NOT NULL DEFAULT 0, price_year INTEGER NOT NULL DEFAULT 0, purchasable INTEGER NOT NULL DEFAULT 0,
  ai_quota INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, email TEXT NOT NULL UNIQUE, name TEXT NOT NULL, pass_hash TEXT NOT NULL,
  plan_code TEXT NOT NULL DEFAULT 'free' REFERENCES plans(code),
  ai_consent INTEGER NOT NULL DEFAULT 0, created_at REAL NOT NULL, plan_expires REAL NOT NULL DEFAULT 0, is_admin INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS lessons(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL, original_name TEXT NOT NULL, stored_name TEXT NOT NULL, kind TEXT NOT NULL,
  text TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'processing', error TEXT NOT NULL DEFAULT '',
  engine TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL, updated_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS lessons_user ON lessons(user_id);
CREATE TABLE IF NOT EXISTS questions(
  id INTEGER PRIMARY KEY, lesson_id INTEGER NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('qa','mcq','tf','cloze','short','review')),
  question TEXT NOT NULL, answer TEXT NOT NULL DEFAULT '', options TEXT NOT NULL DEFAULT '[]',
  evidence TEXT NOT NULL DEFAULT '', clear INTEGER NOT NULL DEFAULT 1, manual INTEGER NOT NULL DEFAULT 0,
  position INTEGER NOT NULL DEFAULT 0, created_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS questions_lesson ON questions(lesson_id);
CREATE TABLE IF NOT EXISTS decks(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  lesson_id INTEGER NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  title TEXT NOT NULL, games TEXT NOT NULL DEFAULT '[]', question_ids TEXT NOT NULL DEFAULT '[]',
  created_at REAL NOT NULL, updated_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS decks_user ON decks(user_id);
CREATE TABLE IF NOT EXISTS classes(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL, created_at REAL NOT NULL, UNIQUE(user_id, name));
CREATE TABLE IF NOT EXISTS students(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  class_id INTEGER REFERENCES classes(id) ON DELETE CASCADE,
  name TEXT NOT NULL, created_at REAL NOT NULL, UNIQUE(class_id, name));
CREATE TABLE IF NOT EXISTS results(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  deck_id INTEGER REFERENCES decks(id) ON DELETE SET NULL, deck_title TEXT NOT NULL DEFAULT '',
  question_id INTEGER, question TEXT NOT NULL DEFAULT '', game TEXT NOT NULL DEFAULT '', kind TEXT NOT NULL DEFAULT '',
  correct INTEGER NOT NULL CHECK (correct IN (0,1)), run TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL,
  UNIQUE(student_id, deck_id, question_id, run));
CREATE INDEX IF NOT EXISTS results_student ON results(student_id);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS subscription_requests(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan_code TEXT NOT NULL REFERENCES plans(code), period TEXT NOT NULL CHECK (period IN ('month','year')),
  amount INTEGER NOT NULL, ref_code TEXT NOT NULL DEFAULT '', payer_name TEXT NOT NULL DEFAULT '', transfer_date TEXT NOT NULL DEFAULT '',
  receipt TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','confirmed','rejected')),
  note TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL, decided_at REAL NOT NULL DEFAULT 0, starts_at REAL NOT NULL DEFAULT 0, ends_at REAL NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS subreq_user ON subscription_requests(user_id);
CREATE TABLE IF NOT EXISTS ai_usage(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, lesson_id INTEGER, model TEXT NOT NULL,
  input_tokens INTEGER NOT NULL, output_tokens INTEGER NOT NULL, cost INTEGER NOT NULL, created_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS aiusage_user ON ai_usage(user_id, created_at);
CREATE TABLE IF NOT EXISTS expenses(
  id INTEGER PRIMARY KEY, kind TEXT NOT NULL CHECK (kind IN ('fixed','variable')), title TEXT NOT NULL, amount INTEGER NOT NULL,
  month TEXT NOT NULL, ended_month TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL);
CREATE TABLE IF NOT EXISTS plan_events(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, kind TEXT NOT NULL CHECK (kind IN ('extend','grant','stop')),
  plan_code TEXT NOT NULL DEFAULT '', days INTEGER NOT NULL DEFAULT 0, note TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS planevents_user ON plan_events(user_id);
"""

PLANS = [  # prices are in halalas (100 = 1 riyal), VAT included. Paid by bank transfer, confirmed by the manager. Only used to FILL a missing plan: what the manager edits is kept.
    ("free", "مجانية", 3, 5, 0, 0, 0, 0, ""),
    ("monthly", "شهرية", 30, 100, 2900, 0, 1, 40, "month"),
    ("yearly", "سنوية", 400, 2000, 0, 24900, 1, 40, "year"),
]
ADDED = (("lessons", "subject", "TEXT NOT NULL DEFAULT ''"), ("lessons", "grade", "TEXT NOT NULL DEFAULT ''"), ("plans", "ai_quota", "INTEGER NOT NULL DEFAULT 0"),
         ("users", "plan_expires", "REAL NOT NULL DEFAULT 0"), ("users", "is_admin", "INTEGER NOT NULL DEFAULT 0"), ("plans", "period", "TEXT NOT NULL DEFAULT ''"),
         ("ai_usage", "cost_nano", "INTEGER NOT NULL DEFAULT 0"), ("decks", "auto", "INTEGER NOT NULL DEFAULT 0"),
         ("users", "plan_started", "REAL NOT NULL DEFAULT 0"))


class Rows:
    """The answer to one statement, read to the end while the connection was held, so no other thread can touch it half way.
    It is used the way a cursor is: fetchone / fetchall / fetchmany, a for-loop, lastrowid and rowcount."""
    __slots__ = ("_rows", "_i", "lastrowid", "rowcount", "description")

    def __init__(self, cur, rows):
        self._rows, self._i = rows, 0
        self.lastrowid = getattr(cur, "lastrowid", None)
        self.rowcount = getattr(cur, "rowcount", -1)
        self.description = getattr(cur, "description", None)

    def fetchone(self):
        if self._i >= len(self._rows):
            return None
        self._i += 1
        return self._rows[self._i - 1]

    def fetchall(self):
        rows, self._i = self._rows[self._i:], len(self._rows)
        return rows

    def fetchmany(self, size=1):
        rows = self._rows[self._i:self._i + size]
        self._i += len(rows)
        return rows

    def __iter__(self):
        return iter(self.fetchall())


class SafeConn:
    """One SQLite connection that several threads can share without breaking each other.

    The server runs 2 processes x 4 threads, and every request asks the same question first (who is signed in), so two threads often ran the very same
    statement on the same connection at the same moment. Python's sqlite3 then fails now and then with "bad parameter or other API misuse" (measured:
    about 2 calls in 100 with 8 threads), which showed up as a page whose stylesheet or script came back as an error. Every statement now runs, and is
    read to its end, while one lock is held. Statements are short, so waiting for the lock costs nothing you can feel; nothing about the data, the tables
    or the way commits work changes."""

    def __init__(self, conn):
        self._c = conn
        self._lock = threading.RLock()

    def execute(self, sql, params=()):
        with self._lock:
            cur = self._c.execute(sql, params)
            return Rows(cur, cur.fetchall())

    def executemany(self, sql, seq):
        with self._lock:
            cur = self._c.executemany(sql, seq)
            return Rows(cur, [])

    def executescript(self, script):
        with self._lock:
            cur = self._c.executescript(script)
            return Rows(cur, [])

    def commit(self):
        with self._lock:
            self._c.commit()

    def rollback(self):
        with self._lock:
            self._c.rollback()

    def close(self):
        with self._lock:
            self._c.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        with self._lock:
            return self._c.__exit__(*exc)

    def __getattr__(self, name):                       # in_transaction, total_changes, ... read straight from the real connection
        return getattr(self._c, name)


def connect(path):
    conn = sqlite3.connect(str(path), timeout=15, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return SafeConn(conn)


def init(conn):
    conn.executescript(SCHEMA)
    added = []
    for table, col, ddl in ADDED:
        if col not in [r[1] for r in conn.execute(f"PRAGMA table_info({table})")]:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {ddl}")        # a database made by an earlier version
            added.append((table, col))
    _classes_for_old_students(conn)
    conn.executemany("INSERT OR IGNORE INTO plans(code, name, max_lessons, max_decks, price_month, price_year, purchasable, ai_quota, period) VALUES (?,?,?,?,?,?,?,?,?)", PLANS)
    for code, *_, quota, period in PLANS:
        if ("plans", "ai_quota") in added:
            conn.execute("UPDATE plans SET ai_quota = ? WHERE code = ?", (quota, code))
        conn.execute("UPDATE plans SET period = ? WHERE code = ? AND period = ''", (period, code))          # the plan's period was never stored before
    conn.commit()


def _classes_for_old_students(conn):
    """Version 3 had one list of students per teacher. Put that list into a first class («الفصل الأول») so nothing is lost, and let the same name live in two classes."""
    cols = [r[1] for r in conn.execute("PRAGMA table_info(students)")]
    if "class_id" in cols:
        return
    conn.commit()
    conn.execute("PRAGMA foreign_keys = OFF")           # the old table is replaced while its results still point at the students' ids
    try:
        conn.executescript("""
BEGIN;
CREATE TABLE students_new(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  class_id INTEGER REFERENCES classes(id) ON DELETE CASCADE,
  name TEXT NOT NULL, created_at REAL NOT NULL, UNIQUE(class_id, name));
INSERT INTO classes(user_id, name, created_at) SELECT DISTINCT user_id, 'الفصل الأول', strftime('%s','now') FROM students;
INSERT INTO students_new(id, user_id, class_id, name, created_at)
  SELECT s.id, s.user_id, (SELECT c.id FROM classes c WHERE c.user_id = s.user_id AND c.name = 'الفصل الأول'), s.name, s.created_at FROM students s;
DROP TABLE students;
ALTER TABLE students_new RENAME TO students;
COMMIT;""")
    finally:
        conn.execute("PRAGMA foreign_keys = ON")


def setting(conn, key, default=""):
    row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    return row[0] if row else default


def put_setting(conn, key, value):
    conn.execute("INSERT INTO settings(key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value", (key, str(value)))
    conn.commit()


def now():
    return time.time()


def jload(text, default):
    try:
        return json.loads(text)
    except (TypeError, ValueError):
        return default
