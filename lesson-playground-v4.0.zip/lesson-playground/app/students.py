"""The teacher's own list of students (names she types herself) and how each one did in the questions she asked them. No student accounts: this is her notebook."""
from flask import Blueprint, abort, current_app, g, jsonify, render_template, request

from .db import jload, now
from .lessons import mine
from .security import login_required

bp = Blueprint("students", __name__)
MAX_STUDENTS = 600
MAX_CLASSES = 30
LEVELS = ((85, "ممتاز"), (65, "جيد"), (0, "يحتاج إلى دعم"))


def body() -> dict:
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}


def toint(v) -> int:
    try:
        return int(v)
    except (TypeError, ValueError):
        return 0


def level(pct):
    return None if pct is None else next(name for floor, name in LEVELS if pct >= floor)


def student_row(sid):
    row = current_app.db.execute("SELECT * FROM students WHERE id = ? AND user_id = ?", (sid, g.user["id"])).fetchone()
    if not row:
        abort(404)                      # another teacher's student looks exactly like one that does not exist
    return row


def class_row(cid):
    row = current_app.db.execute("SELECT * FROM classes WHERE id = ? AND user_id = ?", (cid, g.user["id"])).fetchone()
    if not row:
        abort(404)
    return row


def default_class():
    """A teacher who never made a class (an older page, or the first name she types) gets «الفصل الأول»."""
    db = current_app.db
    row = db.execute("SELECT id FROM classes WHERE user_id = ? ORDER BY id LIMIT 1", (g.user["id"],)).fetchone()
    if row:
        return row["id"]
    cur = db.execute("INSERT INTO classes(user_id, name, created_at) VALUES (?,?,?)", (g.user["id"], "الفصل الأول", now()))
    db.commit()
    return cur.lastrowid


def clean_name(value) -> str:
    return " ".join(str(value or "").split())[:60]


def listing(class_id=None):
    sql = """SELECT s.id, s.name, s.class_id, COUNT(r.id) AS answered, COALESCE(SUM(r.correct), 0) AS correct
             FROM students s LEFT JOIN results r ON r.student_id = s.id WHERE s.user_id = ?"""
    args = [g.user["id"]]
    if class_id:
        sql += " AND s.class_id = ?"
        args.append(class_id)
    out = []
    for r in current_app.db.execute(sql + " GROUP BY s.id ORDER BY s.name", args).fetchall():
        pct = round(100 * r["correct"] / r["answered"]) if r["answered"] else None
        out.append({"id": r["id"], "name": r["name"], "class_id": r["class_id"], "answered": r["answered"], "correct": r["correct"], "percent": pct, "level": level(pct)})
    return out


def classes_list():
    rows = current_app.db.execute("""SELECT c.id, c.name, COUNT(s.id) AS n FROM classes c LEFT JOIN students s ON s.class_id = c.id
                                     WHERE c.user_id = ? GROUP BY c.id ORDER BY c.id""", (g.user["id"],)).fetchall()
    return [{"id": r["id"], "name": r["name"], "count": r["n"]} for r in rows]


@bp.get("/students")
@login_required
def page():
    return render_template("students.html")


@bp.get("/api/students")
@login_required
def students():
    return jsonify(students=listing(toint(request.args.get("class_id")) or None), classes=classes_list())


@bp.get("/api/classes")
@login_required
def classes():
    return jsonify(classes=classes_list())


@bp.post("/api/classes")
@login_required
def add_class():
    name = clean_name(body().get("name"))
    if len(name) < 2:
        return jsonify(error="اكتبي اسم الفصل (حرفان على الأقل)"), 400
    if current_app.db.execute("SELECT COUNT(*) FROM classes WHERE user_id = ?", (g.user["id"],)).fetchone()[0] >= MAX_CLASSES:
        return jsonify(error=f"الحد الأقصى {MAX_CLASSES} فصلًا"), 400
    try:
        cur = current_app.db.execute("INSERT INTO classes(user_id, name, created_at) VALUES (?,?,?)", (g.user["id"], name, now()))
        current_app.db.commit()
    except Exception:
        return jsonify(error="يوجد فصل بهذا الاسم"), 409
    return jsonify(id=cur.lastrowid, classes=classes_list()), 201


@bp.patch("/api/classes/<int:cid>")
@login_required
def rename_class(cid):
    class_row(cid)
    name = clean_name(body().get("name"))
    if len(name) < 2:
        return jsonify(error="اكتبي اسم الفصل"), 400
    try:
        current_app.db.execute("UPDATE classes SET name = ? WHERE id = ?", (name, cid))
        current_app.db.commit()
    except Exception:
        return jsonify(error="يوجد فصل بهذا الاسم"), 409
    return jsonify(saved=True)


@bp.delete("/api/classes/<int:cid>")
@login_required
def delete_class(cid):
    class_row(cid)
    current_app.db.execute("DELETE FROM classes WHERE id = ?", (cid,))          # its students and their results go with it
    current_app.db.commit()
    return jsonify(ok=True)


@bp.post("/api/students")
@login_required
def add():
    d = body()
    names = d.get("names") if isinstance(d.get("names"), list) else [d.get("name")]
    db = current_app.db
    cid = class_row(toint(d.get("class_id")))["id"] if d.get("class_id") else default_class()
    have = db.execute("SELECT COUNT(*) FROM students WHERE user_id = ?", (g.user["id"],)).fetchone()[0]
    added = skipped = 0
    for raw in names:
        name = clean_name(raw)
        if len(name) < 2:
            skipped += 1
            continue
        if have + added >= MAX_STUDENTS:
            return jsonify(error=f"الحد الأقصى {MAX_STUDENTS} طالبًا"), 400
        try:
            db.execute("INSERT INTO students(user_id, class_id, name, created_at) VALUES (?,?,?,?)", (g.user["id"], cid, name, now()))
            added += 1
        except Exception:
            skipped += 1                # the same name twice
    db.commit()
    if not added:
        return jsonify(error="اكتبي اسمًا جديدًا (حرفان على الأقل ولا يتكرر)"), 400
    return jsonify(added=added, skipped=skipped, students=listing(), classes=classes_list()), 201


@bp.patch("/api/students/<int:sid>")
@login_required
def rename(sid):
    student_row(sid)
    name = clean_name(body().get("name"))
    if len(name) < 2:
        return jsonify(error="اكتبي اسمًا صحيحًا"), 400
    try:
        current_app.db.execute("UPDATE students SET name = ? WHERE id = ?", (name, sid))
        current_app.db.commit()
    except Exception:
        return jsonify(error="يوجد طالب بهذا الاسم في الفصل"), 409
    return jsonify(saved=True)


@bp.delete("/api/students/<int:sid>")
@login_required
def remove(sid):
    student_row(sid)
    current_app.db.execute("DELETE FROM students WHERE id = ?", (sid,))          # his results go with him
    current_app.db.commit()
    return jsonify(ok=True)


@bp.post("/api/results")
@login_required
def record():
    d = body()
    db = current_app.db
    student = student_row(toint(d.get("student_id")))
    deck = mine("decks", toint(d.get("deck_id")))
    qid = toint(d.get("question_id"))
    if qid not in jload(deck["question_ids"], []):
        return jsonify(error="السؤال ليس من هذا العرض"), 400
    q = db.execute("SELECT kind, question FROM questions WHERE id = ? AND user_id = ?", (qid, g.user["id"])).fetchone()
    if not q:
        return jsonify(error="السؤال غير موجود"), 404
    run = str(d.get("run", ""))[:40]
    correct = 1 if d.get("correct") in (True, 1, "1") else 0
    db.execute("""INSERT INTO results(user_id, student_id, deck_id, deck_title, question_id, question, game, kind, correct, run, created_at)
                  VALUES (?,?,?,?,?,?,?,?,?,?,?)
                  ON CONFLICT(student_id, deck_id, question_id, run) DO UPDATE SET correct = excluded.correct, game = excluded.game, created_at = excluded.created_at""",
               (g.user["id"], student["id"], deck["id"], deck["title"], qid, q["question"][:200], str(d.get("game", ""))[:20], q["kind"], correct, run, now()))
    db.commit()
    return jsonify(ok=True)


@bp.get("/api/students/<int:sid>/results")
@login_required
def results(sid):
    s = student_row(sid)
    db = current_app.db
    decks = db.execute("""SELECT deck_title, COUNT(*) AS answered, SUM(correct) AS correct, MAX(created_at) AS last FROM results WHERE student_id = ?
                          GROUP BY COALESCE(deck_id, deck_title) ORDER BY last DESC""", (sid,)).fetchall()
    recent = db.execute("SELECT deck_title, question, correct, created_at FROM results WHERE student_id = ? ORDER BY created_at DESC, id DESC LIMIT 40", (sid,)).fetchall()
    return jsonify(name=s["name"], decks=[{"title": r["deck_title"], "answered": r["answered"], "correct": r["correct"], "percent": round(100 * r["correct"] / r["answered"]), "last": r["last"]} for r in decks],
                   recent=[{"deck": r["deck_title"], "question": r["question"], "correct": bool(r["correct"]), "at": r["created_at"]} for r in recent])


@bp.delete("/api/students/<int:sid>/results")
@login_required
def clear_results(sid):
    student_row(sid)
    current_app.db.execute("DELETE FROM results WHERE student_id = ?", (sid,))
    current_app.db.commit()
    return jsonify(ok=True)
