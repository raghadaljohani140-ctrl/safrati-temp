(function () {
  const holder = document.getElementById('classes'), none = document.getElementById('no-classes'), detail = document.getElementById('detail');
  let openId = null;
  const fmt = t => new Date(t * 1000).toLocaleDateString('ar-SA', {day: 'numeric', month: 'short'});

  async function load() {
    const d = await api('GET', '/api/students');
    holder.replaceChildren(); none.hidden = !!d.classes.length;
    d.classes.forEach(c => holder.append(classCard(c, d.students.filter(s => s.class_id === c.id))));
    if (openId && !d.students.some(s => s.id === openId)) { openId = null; detail.hidden = true; }
  }

  function classCard(c, list) {
    const card = el('section', {class: 'card class-card'});
    const name = el('input', {value: c.name, maxlength: 60, class: 'cell-in class-title', 'aria-label': 'اسم الفصل'}); const saved = el('span', {class: 'saved'});
    name.addEventListener('change', async () => { try { await api('PATCH', '/api/classes/' + c.id, {name: name.value}); saved.textContent = 'تم الحفظ ✓'; } catch (e) { saved.textContent = e.message; name.value = c.name; } });
    const del = el('button', {class: 'btn ghost small danger', type: 'button', text: 'حذف الفصل'});
    del.addEventListener('click', async () => { if (!confirm('حذف «' + c.name + '» وكل طلابه ونتائجهم؟ لا يمكن التراجع.')) return; await api('DELETE', '/api/classes/' + c.id); load(); });
    card.append(el('div', {class: 'class-head'}, name, saved, el('small', {class: 'muted', text: arS(list.length)}), del));

    const area = el('textarea', {rows: 3, maxlength: 6000, placeholder: 'اكتبي اسم طالب في كل سطر', 'aria-label': 'أسماء الطلاب'});
    const add = el('button', {class: 'btn', type: 'submit', text: 'إضافة الأسماء إلى ' + c.name}); const err = el('p', {class: 'note bad', role: 'alert', hidden: true});
    const form = el('form', {class: 'stack'}, el('label', {}, 'الأسماء تحت هذا الفصل', area), add, err);
    form.addEventListener('submit', async e => {
      e.preventDefault(); err.hidden = true;
      try { await api('POST', '/api/students', {class_id: c.id, names: area.value.split('\n').map(x => x.trim()).filter(Boolean)}); load(); }
      catch (x) { err.textContent = x.message; err.hidden = false; }
    });
    card.append(form);

    if (!list.length) card.append(el('p', {class: 'muted', text: 'لا توجد أسماء في هذا الفصل بعد.'}));
    else {
      const tb = el('tbody'); list.forEach(s => tb.append(row(s)));
      card.append(el('div', {class: 'tbl-wrap'}, el('table', {class: 'tbl'}, el('thead', {}, el('tr', {}, ...['الاسم', 'الأسئلة', 'الصحيحة', 'النسبة', 'المستوى', ''].map(t => el('th', {text: t})))), tb)));
    }
    return card;
  }

  function row(s) {
    const tr = el('tr'); const name = el('input', {value: s.name, maxlength: 60, 'aria-label': 'اسم الطالب', class: 'cell-in'}); const saved = el('span', {class: 'saved'});
    name.addEventListener('change', async () => {
      try { await api('PATCH', '/api/students/' + s.id, {name: name.value}); saved.textContent = 'تم الحفظ ✓'; setTimeout(load, 600); }
      catch (e) { saved.textContent = e.message; name.value = s.name; }
    });
    const show = el('button', {class: 'btn ghost small', type: 'button', text: 'النتائج'}); show.addEventListener('click', () => openDetail(s.id));
    const del = el('button', {class: 'btn ghost small danger', type: 'button', text: 'حذف'});
    del.addEventListener('click', async () => { if (!confirm('حذف ' + s.name + ' ونتائجه؟')) return; await api('DELETE', '/api/students/' + s.id); load(); });
    tr.append(el('td', {}, name, saved), el('td', {text: s.answered}), el('td', {text: s.correct}), el('td', {text: s.percent == null ? '—' : s.percent + '%'}),
      el('td', {}, s.level ? el('span', {class: 'lvl l' + (s.percent >= 85 ? 'a' : s.percent >= 65 ? 'b' : 'c'), text: s.level}) : '—'), el('td', {class: 'acts'}, show, del));
    return tr;
  }

  async function openDetail(id) {
    openId = id; const d = await api('GET', '/api/students/' + id + '/results');
    document.getElementById('d-name').textContent = 'نتائج ' + d.name;
    const decks = document.getElementById('d-decks'); decks.replaceChildren();
    if (!d.decks.length) decks.append(el('tr', {}, el('td', {colspan: 4, class: 'muted', text: 'لا توجد نتائج بعد. اختاري هذا الطالب أثناء العرض.'})));
    d.decks.forEach(x => decks.append(el('tr', {}, el('td', {text: x.title}), el('td', {text: x.answered}), el('td', {text: x.correct}), el('td', {text: x.percent + '%'}))));
    const list = document.getElementById('d-recent'); list.replaceChildren();
    d.recent.forEach(x => list.append(el('li', {}, el('b', {text: x.correct ? '✔ ' : '✘ '}), x.question, el('small', {class: 'muted', text: ' · ' + x.deck + ' · ' + fmt(x.at)}))));
    detail.hidden = false; detail.scrollIntoView({behavior: 'smooth', block: 'nearest'});
  }
  document.getElementById('d-clear').addEventListener('click', async () => {
    if (!openId || !confirm('مسح كل نتائج هذا الطالب؟ لا يمكن التراجع.')) return;
    await api('DELETE', '/api/students/' + openId + '/results'); await load(); openDetail(openId);
  });
  document.getElementById('add-class').addEventListener('submit', async e => {
    e.preventDefault(); const err = document.getElementById('class-err'); err.hidden = true; const input = document.getElementById('class-name');
    try { await api('POST', '/api/classes', {name: input.value}); input.value = ''; load(); } catch (x) { err.textContent = x.message; err.hidden = false; }
  });
  load().catch(e => { none.hidden = false; none.textContent = e.message; });
})();
