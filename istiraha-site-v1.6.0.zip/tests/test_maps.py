"""The map: the place of an advert (database, typing, saving), the list / map views of the search, «الأقرب إليك», the headers the map pages need,
and the promises that an advert without a place and a change of place never break or re-open anything."""
import html as htmllib
import re
import sqlite3
import tempfile
import unittest
from pathlib import Path
from urllib.parse import parse_qsl, urlsplit

from istiraha import db as dbmod
from istiraha import repo, settings as settingsmod, util
from istiraha.db import Database
from istiraha.server import PERMISSIONS, PERMISSIONS_WITH_PLACE, SECURITY_HEADERS
from tests.helpers import NOW, Case

RIYADH = (24.7136, 46.6753)


def attrs(text: str) -> list[dict]:
    """The adverts a map page hands to its script: one dict of data-* attributes per pin."""
    out = []
    for tag in re.findall(r"<li (data-id=[^>]*)></li>", text):
        out.append({k: htmllib.unescape(v) for k, v in re.findall(r'data-([a-z]+)="([^"]*)"', tag)})
    return out


def hrefs(text: str) -> list[str]:
    return [htmllib.unescape(h) for h in re.findall(r'href="([^"]*)"', text)]


def query(url: str) -> dict:
    return dict(parse_qsl(urlsplit(url).query))


# ---- the numbers ----------------------------------------------------------------------------------------------
class NumbersTests(unittest.TestCase):
    def test_a_coordinate_is_read_from_any_digits_and_never_guessed(self):
        for text, want in (("24.7136", 24.7136), ("٢٤٫٧١٣٦", 24.7136), ("24,7136", 24.7136), (" 24.7136 ", 24.7136), ("‎46.6753‏", 46.6753),
                           ("-5.5", -5.5), ("−5.5", -5.5), ("24.12345678", 24.123457), ("90", 90.0)):
            self.assertEqual(util.parse_coord(text, -90, 90), want, text)
        for bad in ("", "abc", "NaN", "inf", "1e3", "24.7.1", "24.7136,46.6753", "91", "-90.1", "24°42'", "0x10", "24.", ".5", "--5", "+5"):
            self.assertIsNone(util.parse_coord(bad, -90, 90), bad)
        self.assertIsNone(util.parse_coord("181", -180, 180))
        self.assertEqual(util.parse_coord("180", -180, 180), 180.0)

    def test_a_pair_copied_from_a_map_app_is_split(self):
        self.assertEqual(util.split_pair("24.7136, 46.6753"), ("24.7136", "46.6753"))
        self.assertEqual(util.split_pair("24.7136,46.6753"), ("24.7136", "46.6753"))
        self.assertEqual(util.split_pair("24.7136 46.6753"), ("24.7136", "46.6753"))
        self.assertEqual(util.split_pair("24.7136;46.6753"), ("24.7136", "46.6753"))
        self.assertIsNone(util.split_pair("24,7136"))                  # one number with a decimal comma is not a pair
        self.assertIsNone(util.split_pair("24.7136"))
        self.assertIsNone(util.split_pair("1 2 3"))

    def test_the_kingdom_box_catches_the_usual_slips(self):
        self.assertTrue(util.in_kingdom(*RIYADH))
        self.assertTrue(util.in_kingdom(21.4858, 39.1925))
        self.assertTrue(util.in_kingdom(16.8892, 42.5511))             # Jazan, the south
        self.assertTrue(util.in_kingdom(28.3835, 36.5662))             # Tabuk, the north
        self.assertFalse(util.in_kingdom(46.6753, 24.7136))            # the two numbers swapped
        self.assertFalse(util.in_kingdom(0, 0))
        self.assertFalse(util.in_kingdom(-24.7136, 46.6753))           # a lost minus sign the other way
        self.assertFalse(util.in_kingdom(30.0444, 31.2357))            # Cairo

    def test_the_distance_is_the_real_one(self):
        self.assertEqual(util.distance_km(*RIYADH, *RIYADH), 0)
        self.assertAlmostEqual(util.distance_km(*RIYADH, 21.4858, 39.1925), 845.1, delta=2)         # Riyadh to Jeddah
        self.assertAlmostEqual(util.distance_km(24.0, 46.0, 25.0, 46.0), 111.2, delta=0.3)           # one degree of latitude
        self.assertAlmostEqual(util.distance_km(*RIYADH, 24.8136, 46.6753), 11.12, delta=0.05)
        self.assertEqual(util.distance_km(10, 20, 30, 40), util.distance_km(30, 40, 10, 20))
        self.assertGreater(util.distance_km(0, 0, 0, 180), 20000)                                   # the other side of the earth: no error on the way

    def test_a_distance_is_said_short(self):
        self.assertEqual(util.distance_text(0.4), "أقل من 1 كم")
        self.assertEqual(util.distance_text(3.44), "3.4 كم")
        self.assertEqual(util.distance_text(9.96), "10.0 كم")
        self.assertEqual(util.distance_text(27.6), "28 كم")


# ---- the database -------------------------------------------------------------------------------------------------
class MigrationTests(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.addCleanup(self.dir.cleanup)
        self.path = Path(self.dir.name) / "istiraha.db"

    def make_fourth_release(self, extra=""):
        """What 1.5.x left on a server: the tables of the first four releases at version 4, with an owner, two adverts and a rental in them."""
        conn = sqlite3.connect(self.path)
        for statement in (dbmod.SCHEMA_V1 + dbmod.MIGRATION_V2 + dbmod.MIGRATION_V3 + dbmod.MIGRATION_V4).split(";\n"):
            if statement.strip():
                conn.execute(statement)
        conn.execute("INSERT INTO users(role, login, name, pass_hash, created_at) VALUES ('owner', '966551234567', 'أبو سعد', 'x', 1)")
        conn.execute("INSERT INTO cities(name) VALUES ('الرياض')")
        conn.execute("INSERT INTO categories(name) VALUES ('استراحة')")
        for i in (1, 2):
            conn.execute("INSERT INTO consents(owner_id, listing_id, pledge_version, pledge_text, basis_points, accepted_at) VALUES (1, ?, 1, 'x', 1000, 1)", (i,))
            conn.execute("""INSERT INTO listings(owner_id, consent_id, title, city_id, category_id, price, whatsapp, review, map_url, created_at, updated_at)
                            VALUES (1, ?, ?, 1, 1, 500, '966551234567', 'approved', 'https://maps.app.goo.gl/abc', 1, 1)""", (i, f"استراحة قديمة {i}"))
        conn.execute("""INSERT INTO rentals(listing_id, owner_id, consent_id, basis_points, rent, commission_halalas, rental_date, due_date, created_at)
                        VALUES (1, 1, 1, 1000, 500, 5000, '2026-10-01', '2026-10-10', 1)""")
        if extra:
            conn.execute(extra)
        conn.execute("PRAGMA user_version = 4")
        conn.commit()
        conn.close()

    def test_a_version_four_database_gains_the_place_columns_and_loses_nothing(self):
        self.make_fourth_release()
        db = Database(self.path)
        self.addCleanup(db.close)
        self.assertEqual(db.one("PRAGMA user_version")[0], dbmod.SCHEMA_VERSION)
        self.assertEqual(dbmod.SCHEMA_VERSION, 5)
        rows = db.all("SELECT id, title, review, map_url, price, lat, lng FROM listings ORDER BY id")
        self.assertEqual([(r["title"], r["review"], r["map_url"], r["price"]) for r in rows],
                         [("استراحة قديمة 1", "approved", "https://maps.app.goo.gl/abc", 500), ("استراحة قديمة 2", "approved", "https://maps.app.goo.gl/abc", 500)])
        self.assertEqual([(r["lat"], r["lng"]) for r in rows], [(None, None), (None, None)])        # every old advert has no place yet, as it never had
        self.assertEqual(db.one("SELECT commission_halalas FROM rentals")["commission_halalas"], 5000)
        self.assertEqual(db.one("SELECT COUNT(*) AS n FROM users")["n"], 1)

    def test_the_columns_of_an_upgraded_database_and_a_new_one_are_the_same(self):
        self.make_fourth_release()
        upgraded = Database(self.path)
        fresh = Database(":memory:")
        self.addCleanup(upgraded.close)
        self.addCleanup(fresh.close)
        columns = lambda d: [(r["name"], r["type"], r["notnull"], r["dflt_value"]) for r in d.all("PRAGMA table_info(listings)")]
        self.assertEqual(columns(upgraded), columns(fresh))
        self.assertEqual(columns(fresh)[-2:], [("lat", "REAL", 0, None), ("lng", "REAL", 0, None)])

    def test_the_database_itself_refuses_a_place_outside_the_earth(self):
        db = Database(":memory:")
        self.addCleanup(db.close)
        db.run("INSERT INTO users(role, login, name, pass_hash, created_at) VALUES ('owner', '966551234567', 'x', 'x', 1)")
        db.run("INSERT INTO consents(owner_id, listing_id, pledge_version, pledge_text, basis_points, accepted_at) VALUES (1, 1, 1, 'x', 1000, 1)")
        insert = "INSERT INTO listings(owner_id, consent_id, title, city_id, category_id, price, whatsapp, created_at, updated_at, lat, lng) VALUES (1, 1, 'x', 1, 1, 5, '9665', 1, 1, ?, ?)"
        db.run(insert, (24.7, 46.6))
        db.run(insert, (None, None))
        for bad in ((91, 0), (-90.5, 0), (0, 181), (0, -180.5)):
            with self.assertRaises(sqlite3.IntegrityError, msg=str(bad)):
                db.run(insert, bad)
        with self.assertRaises(sqlite3.IntegrityError):
            db.run("UPDATE listings SET lat = 200 WHERE id = 1")

    def test_a_failed_upgrade_leaves_the_version_four_database_as_it_was(self):
        self.make_fourth_release("ALTER TABLE listings ADD COLUMN lng REAL")             # a clash on the second column, after the first was added
        with self.assertRaises(sqlite3.OperationalError):
            Database(self.path)
        conn = sqlite3.connect(self.path)
        self.assertEqual(conn.execute("PRAGMA user_version").fetchone()[0], 4)
        self.assertNotIn("lat", [r[1] for r in conn.execute("PRAGMA table_info(listings)")])      # rolled back with the rest
        self.assertEqual(conn.execute("SELECT COUNT(*) FROM listings").fetchone()[0], 2)
        conn.close()

    def test_opening_it_again_changes_nothing_and_an_older_program_is_refused(self):
        self.make_fourth_release()
        Database(self.path).close()
        db = Database(self.path)
        self.addCleanup(db.close)
        self.assertEqual(db.one("SELECT COUNT(*) AS n FROM listings")["n"], 2)
        db.run("UPDATE listings SET lat = 24.7, lng = 46.6 WHERE id = 1")
        db.close()
        self.assertEqual(sqlite3.connect(self.path).execute("PRAGMA user_version").fetchone()[0], 5)       # (the 1.5.x program refuses version 5: restore the backup to go back)


# ---- what an owner types ------------------------------------------------------------------------------------------
class ValidationTests(Case):
    def check(self, **extra):
        form = {"title": "استراحة الواحة", "city": "1", "category": "1", "price": "500", "unit": "night", "whatsapp": "0551234567", **extra}
        return repo.validate_listing(self.db, form)

    def test_no_place_is_fine(self):
        v, errors = self.check()
        self.assertEqual((v["lat"], v["lng"], errors), (None, None, {}))
        v, errors = self.check(lat="", lng="")
        self.assertEqual((v["lat"], v["lng"], errors), (None, None, {}))
        self.assertTrue(v["place_given"])
        self.assertFalse(self.check()[0]["place_given"])             # a page from before the maps sends neither box

    def test_a_place_is_read_whatever_the_digits(self):
        for lat, lng in (("24.7136", "46.6753"), ("٢٤٫٧١٣٦", "٤٦٫٦٧٥٣"), (" 24,7136 ", "46,6753")):
            v, errors = self.check(lat=lat, lng=lng)
            self.assertEqual((v["lat"], v["lng"], errors), (24.7136, 46.6753, {}))
        v, errors = self.check(lat="24.7136, 46.6753")                # the pair pasted into the first box
        self.assertEqual((v["lat"], v["lng"], errors), (24.7136, 46.6753, {}))

    def test_a_wrong_place_is_refused_and_shown_back_as_typed(self):
        for lat, lng in (("24.7136", ""), ("", "46.6753"), ("abc", "46.6"), ("24.7", "x"), ("24.7,46.6,5", ""), ("95", "46.6")):
            v, errors = self.check(lat=lat, lng=lng)
            self.assertIn("lat", errors, (lat, lng))
            self.assertIn("الأرقام", errors["lat"])
            self.assertEqual((v["lat"], v["lng"]), (lat.strip(), lng.strip()))
        v, errors = self.check(lat="46.6753", lng="24.7136")          # swapped: a place, but not in the Kingdom
        self.assertIn("خارج المملكة", errors["lat"])
        self.assertIn("خارج المملكة", self.check(lat="0", lng="0")[1]["lat"])
        self.assertIn("خارج المملكة", self.check(lat="30.0444", lng="31.2357")[1]["lat"])

    def test_the_place_is_not_one_of_the_fields_that_send_an_advert_back_to_review(self):
        self.assertNotIn("lat", repo.REVIEWED_FIELDS)
        self.assertNotIn("lng", repo.REVIEWED_FIELDS)
        self.assertIn("map_url", repo.REVIEWED_FIELDS)               # the owner's own link still does, as before


# ---- the owner side -----------------------------------------------------------------------------------------------
class OwnerPlaceTests(Case):
    def place(self, lid):
        row = self.db.one("SELECT lat, lng FROM listings WHERE id = ?", (lid,))
        return row["lat"], row["lng"]

    async def edit(self, owner, lid, **fields):
        await owner.get(f"/owner/listing/{lid}/edit")
        row = self.db.one("SELECT * FROM listings WHERE id = ?", (lid,))
        form = {"title": row["title"], "city": str(row["city_id"]), "category": str(row["category_id"]), "price": str(row["price"]), "unit": row["unit"],
                "whatsapp": "0551234567", "district": row["district"], "description": row["description"], "amenities": ["1", "2"], **fields}
        return await owner.post(f"/owner/listing/{lid}/edit", form)

    async def test_a_new_advert_can_be_added_with_its_place(self):
        owner = await self.make_owner()
        lid = await self.add_listing(owner, lat="24.7136", lng="46.6753")
        self.assertEqual(self.place(lid), RIYADH)
        lid2 = await self.add_listing(owner, title="استراحة بلا موقع")
        self.assertEqual(self.place(lid2), (None, None))             # the place is optional

    async def test_a_wrong_place_stops_the_new_advert_with_the_message_on_the_numbers(self):
        owner = await self.make_owner()
        await owner.get("/owner/new")
        await owner.post("/owner/new", {"agree": "1", "version": str(self.db.pledge()["version"]), "bp": str(self.db.commission_bp())})
        action = owner.location
        await owner.get(action)
        r = await owner.post(action, {"title": "استراحة الواحة", "city": "1", "category": "1", "price": "500", "unit": "night", "whatsapp": "0551234567",
                                       "lat": "46.6753", "lng": "24.7136"})
        self.assertEqual(r.status, 400)
        self.assertIn("هذا الموقع خارج المملكة", owner.text)
        self.assertIn('value="46.6753"', owner.text)                 # what he typed is still there
        self.assertIn('<details class="more" open>', owner.text)     # and the numbers are open so he sees the message
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM listings")["n"], 0)

    async def test_the_edit_page_shows_the_place_and_the_picker(self):
        owner = await self.make_owner()
        lid = await self.add_listing(owner, lat="24.7136", lng="46.6753")
        await owner.get(f"/owner/listing/{lid}/edit")
        self.assertIn('id="f-lat"', owner.text)
        self.assertIn('value="24.7136"', owner.text)
        self.assertIn('value="46.6753"', owner.text)
        self.assertIn("تم تحديد الموقع ✓", owner.text)
        self.assertIn('id="picker"', owner.text)
        self.assertIn("غيّر الموقع على الخريطة", owner.text)
        self.assertIn('data-tiles="https://tile.openstreetmap.org/{z}/{x}/{y}.png"', owner.text)
        self.assertIn("/static/vendor/leaflet/leaflet.js", owner.text)
        self.assertIn("/static/map.js", owner.text)
        centers = htmllib.unescape(re.search(r'data-centers="([^"]*)"', owner.text).group(1))
        self.assertIn('"1": [24.7136, 46.6753]', centers)           # Riyadh: the picker opens there for a city
        other = await self.add_listing(owner, title="استراحة ثانية")
        await owner.get(f"/owner/listing/{other}/edit")
        self.assertIn("لم تحدد الموقع بعد", owner.text)
        self.assertIn("حدد الموقع على الخريطة", owner.text)

    async def test_the_place_can_be_set_changed_and_cleared_without_going_back_to_review(self):
        self.db.set_auto_publish(False)                               # the manager reviews every advert: the strictest setting
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        self.approve(lid)
        self.assertEqual((await self.edit(owner, lid, lat="24.7136", lng="46.6753")).status, 303)
        self.assertEqual(self.place(lid), RIYADH)
        self.assertEqual(self.db.one("SELECT review FROM listings WHERE id = ?", (lid,))["review"], "approved")      # still published
        self.assertNotIn("أُعيد الإعلان للمراجعة", await owner.message())
        await self.edit(owner, lid, lat="24.8136", lng="46.7")
        self.assertEqual(self.place(lid), (24.8136, 46.7))
        self.assertEqual(self.db.one("SELECT review FROM listings WHERE id = ?", (lid,))["review"], "approved")
        await self.edit(owner, lid, lat="", lng="")
        self.assertEqual(self.place(lid), (None, None))
        self.assertEqual(self.db.one("SELECT review FROM listings WHERE id = ?", (lid,))["review"], "approved")
        # the title still does (the rule for the reviewed fields is as it was)
        await self.edit(owner, lid, title="اسم جديد للاستراحة", lat="24.8", lng="46.7")
        self.assertEqual(self.db.one("SELECT review FROM listings WHERE id = ?", (lid,))["review"], "pending")

    async def test_saving_the_form_without_the_place_boxes_keeps_the_place(self):
        owner = await self.make_owner()
        lid = await self.add_listing(owner, lat="24.7136", lng="46.6753")
        await owner.get(f"/owner/listing/{lid}/edit")
        row = self.db.one("SELECT * FROM listings WHERE id = ?", (lid,))
        r = await owner.post(f"/owner/listing/{lid}/edit", {"title": row["title"], "city": "1", "category": "1", "price": "900", "unit": "night",
                                                             "whatsapp": "0551234567", "amenities": ["1"]})              # a page from before the maps: no lat, no lng
        self.assertEqual(r.status, 303)
        self.assertEqual(self.place(lid), RIYADH)
        self.assertEqual(self.db.one("SELECT price FROM listings WHERE id = ?", (lid,))["price"], 900)

    async def test_a_wrong_place_on_an_edit_changes_nothing(self):
        owner = await self.make_owner()
        lid = await self.add_listing(owner, lat="24.7136", lng="46.6753")
        r = await self.edit(owner, lid, lat="0", lng="0", price="999")
        self.assertEqual(r.status, 400)
        self.assertEqual(self.place(lid), RIYADH)
        self.assertEqual(self.db.one("SELECT price FROM listings WHERE id = ?", (lid,))["price"], 800)

    async def test_a_change_of_place_is_written_in_the_log_and_no_other_edit_is(self):
        owner = await self.make_owner()
        lid = await self.add_listing(owner, lat="24.7136", lng="46.6753")
        logged = lambda: [dict(r) for r in self.db.all("SELECT action, detail FROM audit WHERE action = 'listing_location'")]
        self.assertEqual(logged(), [])                                 # a new advert's first place is not a change
        await self.edit(owner, lid, lat="24.7136", lng="46.6753", price="850")        # the same place: nothing to log
        self.assertEqual(logged(), [])
        await self.edit(owner, lid, lat="24.9", lng="46.7")
        self.assertEqual(logged(), [{"action": "listing_location", "detail": str(lid)}])
        self.assertIn("listing_location", repo.AUDIT_LABELS)
        admin = await self.make_admin()
        await admin.get("/admin")
        self.assertIn(repo.AUDIT_LABELS["listing_location"], admin.text)

    async def test_nobody_else_can_change_the_place(self):
        owner = await self.make_owner()
        lid = await self.add_listing(owner, lat="24.7136", lng="46.6753")
        other = await self.make_owner(phone="0557654321", name="غيره", ip="203.0.113.51")
        await other.get(f"/owner/listing/{lid}/edit")
        self.assertEqual(other.last.status, 404)
        r = await other.go("POST", f"/owner/listing/{lid}/edit", {"_csrf": other.csrf(), "title": "x", "lat": "25", "lng": "46"})
        self.assertEqual(r.status, 404)
        self.assertEqual(self.place(lid), RIYADH)

    async def test_the_review_note_no_longer_calls_the_place_a_reason_for_review(self):
        self.db.set_auto_publish(False)
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        self.approve(lid)
        await owner.get(f"/owner/listing/{lid}/edit")
        self.assertIn("أو رابط الموقع أو", owner.text)
        self.assertIn("تعديل السعر أو موقعه على الخريطة لا يحتاج مراجعة", owner.text)

    async def test_the_dashboard_and_the_advert_page_ask_for_the_missing_place(self):
        owner = await self.make_owner()
        old = await self.add_listing(owner, title="استراحة قديمة")
        await owner.get("/owner")
        self.assertIn("«استراحة قديمة» بدون موقع على الخريطة", owner.text)
        self.assertIn(f'href="/owner/listing/{old}/edit#place"', owner.text)
        await owner.get(f"/owner/listing/{old}")
        self.assertIn("موقعها على الخريطة غير محدد", owner.text)
        second = await self.add_listing(owner, title="استراحة ثانية")
        await owner.get("/owner")
        self.assertIn("2 من استراحاتك بدون موقع على الخريطة", owner.text)
        await self.edit(owner, old, lat="24.7136", lng="46.6753")
        await self.edit(owner, second, lat="24.7136", lng="46.6753")
        await owner.get("/owner")
        self.assertNotIn("بدون موقع على الخريطة", owner.text)
        await owner.get(f"/owner/listing/{old}")
        self.assertIn("موقعها محدد على الخريطة", owner.text)

    async def test_the_manager_sees_the_place_on_the_advert_page(self):
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        admin = await self.make_admin()
        await admin.get(f"/admin/listing/{lid}")
        self.assertIn("لم يحدده المالك بعد", admin.text)
        await self.edit(owner, lid, lat="24.7136", lng="46.6753")
        await admin.get(f"/admin/listing/{lid}")
        self.assertIn("24.713600, 46.675300", admin.text)
        self.assertIn("https://www.google.com/maps/search/?api=1&amp;query=24.713600,46.675300", admin.text)


# ---- the visitor side -----------------------------------------------------------------------------------------
class SearchMapTests(Case):
    async def setUp_world(self):
        """Five published adverts at known distances north of Riyadh's middle, one with no place, one in Jeddah, and some that are not public."""
        self.owner = await self.make_owner()
        self.ids = {}
        spots = {"قريبة": (24.7236, 46.6753), "متوسطة": (24.8136, 46.6753), "بعيدة": (25.0136, 46.6753), "أبعد": (25.4136, 46.6753),
                 "بلا موقع": (None, None), "جدة": (21.4858, 39.1925)}
        for name, (lat, lng) in spots.items():
            extra = {} if lat is None else {"lat": str(lat), "lng": str(lng)}
            lid = await self.add_listing(self.owner, title=f"استراحة {name}", city=2 if name == "جدة" else 1, **extra)
            self.approve(lid)
            self.db.run("INSERT INTO photos(listing_id, filename, position, created_at) VALUES (?, ?, 0, 1)", (lid, f"cover{lid:05d}abcdef.jpg"))
            self.ids[name] = lid
        for name, review in (("قيد المراجعة", "pending"), ("مرفوضة", "rejected"), ("موقوفة", "stopped")):
            lid = await self.add_listing(self.owner, title=f"استراحة {name}", lat="24.72", lng="46.68")
            self.db.run("UPDATE listings SET review = ? WHERE id = ?", (review, lid))
            self.ids[name] = lid
        paused = await self.add_listing(self.owner, title="استراحة متوقفة مؤقتًا", lat="24.72", lng="46.68")
        self.approve(paused)
        self.db.run("UPDATE listings SET owner_active = 0 WHERE id = ?", (paused,))
        self.ids["متوقفة"] = paused

    async def asyncSetUp(self):
        await super().asyncSetUp()
        await self.setUp_world()

    def titles(self, text):
        return re.findall(r'<a class="card" href="/r/\d+">.*?<h3>([^<]*)</h3>', text, re.S)

    async def test_the_map_shows_every_published_advert_with_a_place_and_only_those(self):
        await self.visitor.get("/search", view="map")
        self.assertEqual(self.visitor.last.status, 200)
        pins = attrs(self.visitor.text)
        self.assertEqual(sorted(p["title"] for p in pins), sorted(f"استراحة {n}" for n in ("قريبة", "متوسطة", "بعيدة", "أبعد", "جدة")))
        for hidden in ("بلا موقع", "قيد المراجعة", "مرفوضة", "موقوفة", "متوقفة"):
            self.assertNotIn(f"استراحة {hidden}", self.visitor.text.replace("بلا موقع</a>", ""), hidden)
        self.assertIn("5 على الخريطة", self.visitor.text)
        self.assertIn("1 استراحة تطابق بحثك لم يحدد صاحبها موقعها على الخريطة بعد", self.visitor.text)       # the one with no place is said, not hidden
        near = next(p for p in pins if p["title"] == "استراحة قريبة")
        self.assertEqual((near["id"], near["lat"], near["lng"], near["price"], near["unit"], near["place"]),
                         (str(self.ids["قريبة"]), "24.723600", "46.675300", "800", "ليلة", "الرياض · استراحة"))
        self.assertEqual(near["image"], f"cover{self.ids['قريبة']:05d}abcdef.jpg")
        self.assertEqual(near["away"], "")

    async def test_the_pins_carry_the_discount_and_the_price_after_it(self):
        self.db.run("INSERT INTO offers(title, percent, starts_on, ends_on, listing_id) VALUES ('خصم', 25, '2026-10-01', '2026-12-31', ?)", (self.ids["قريبة"],))
        await self.visitor.get("/search", view="map")
        near = next(p for p in attrs(self.visitor.text) if p["title"] == "استراحة قريبة")
        self.assertEqual((near["price"], near["was"], near["discount"]), ("600", "800", "25"))

    async def test_an_advert_with_no_place_never_breaks_the_list_and_stays_in_it(self):
        await self.visitor.get("/search")
        self.assertIn("استراحة بلا موقع", self.visitor.text)
        self.assertEqual(len(self.titles(self.visitor.text)), 6)
        self.assertNotIn("تبعد", self.visitor.text)                  # no distance without the visitor's place
        r = await self.visitor.get(f"/r/{self.ids['بلا موقع']}")
        self.assertEqual(r.status, 200)
        self.assertNotIn("google.com/maps", self.visitor.text)       # nothing to open on a map app: no button at all

    async def test_a_half_written_place_is_treated_as_none(self):
        self.db.run("UPDATE listings SET lng = NULL WHERE id = ?", (self.ids["قريبة"],))
        await self.visitor.get("/search", view="map")
        self.assertNotIn("استراحة قريبة", [p["title"] for p in attrs(self.visitor.text)])
        await self.visitor.get("/search", lat="24.7136", lng="46.6753", km="50")
        self.assertNotIn("استراحة قريبة", self.visitor.text)

    async def test_the_toggle_keeps_the_search_in_both_directions(self):
        await self.visitor.get("/search", city="1", category="1", price_max="900", sort="cheap", district="حي", amenity=["1", "2"], offers="1")
        links = hrefs(self.visitor.text)
        to_map = next(h for h in links if "view=map" in h and h.startswith("/search"))
        self.assertEqual({k: v for k, v in parse_qsl(urlsplit(to_map).query) if k != "amenity"},
                         {"city": "1", "category": "1", "sort": "cheap", "price_max": "900", "district": "حي", "offers": "1", "view": "map"})
        self.assertEqual([v for k, v in parse_qsl(urlsplit(to_map).query) if k == "amenity"], ["1", "2"])
        await self.visitor.get(to_map)
        back = next(h for h in hrefs(self.visitor.text) if h.startswith("/search") and "view=map" not in h and "city=1" in h)
        self.assertEqual(query(back), {"city": "1", "category": "1", "sort": "cheap", "price_max": "900", "district": "حي", "offers": "1", "amenity": "2"})
        self.assertIn("aria-current=\"page\">عرض الخريطة</a>", self.visitor.text)
        # the filter form on the map page sends the map along, so «تحديث النتائج» does not fall back to the list
        self.assertIn('<input type="hidden" name="view" value="map">', self.visitor.text)
        await self.visitor.get("/search")
        self.assertNotIn('name="view"', self.visitor.text)
        self.assertIn('aria-current="page">عرض القائمة</a>', self.visitor.text)

    async def test_filters_apply_to_the_map_too(self):
        await self.visitor.get("/search", view="map", city="2")
        self.assertEqual([p["title"] for p in attrs(self.visitor.text)], ["استراحة جدة"])
        await self.visitor.get("/search", view="map", city="1", price_max="500")
        self.assertEqual(attrs(self.visitor.text), [])
        self.assertIn("ما فيه استراحات بموقع محدد تطابق بحثك", self.visitor.text)
        self.assertNotIn('id="browse-map"', self.visitor.text)       # an empty map is not drawn: the message says what to do

    async def test_near_me_keeps_the_adverts_within_the_distance_nearest_first_with_their_distance(self):
        await self.visitor.get("/search", lat="24.7136", lng="46.6753", km="25")
        self.assertEqual(self.titles(self.visitor.text), ["استراحة قريبة", "استراحة متوسطة"])          # 1.1 km and 11.1 km; the one 33 km away is out
        self.assertIn("تبعد 1.1 كم عن موقعك", self.visitor.text)
        self.assertIn("تبعد 11 كم عن موقعك", self.visitor.text)
        self.assertIn("2 نتيجة", self.visitor.text)
        await self.visitor.get("/search", lat="24.7136", lng="46.6753", km="5")
        self.assertEqual(self.titles(self.visitor.text), ["استراحة قريبة"])
        await self.visitor.get("/search", lat="24.7136", lng="46.6753", km="10")
        self.assertEqual(self.titles(self.visitor.text), ["استراحة قريبة"])
        await self.visitor.get("/search", lat="24.7136", lng="46.6753", km="50")
        self.assertEqual(self.titles(self.visitor.text), ["استراحة قريبة", "استراحة متوسطة", "استراحة بعيدة"])
        self.assertNotIn("استراحة بلا موقع", self.visitor.text)      # it cannot be near anybody

    async def test_the_distance_defaults_to_twenty_five_and_only_the_four_choices_exist(self):
        for km in ("", "abc", "7", "1000", "-5"):
            await self.visitor.get("/search", lat="24.7136", lng="46.6753", km=km)
            self.assertEqual(self.titles(self.visitor.text), ["استراحة قريبة", "استراحة متوسطة"], km)
        await self.visitor.get("/search", lat="24.7136", lng="46.6753", km="25")
        radii = re.findall(r'<a href="([^"]*)"(?: aria-current="true")?>(\d+) كم</a>', self.visitor.text)
        self.assertEqual([r for _, r in radii], ["5", "10", "25", "50"])
        self.assertEqual([query(htmllib.unescape(h))["km"] for h, _ in radii], ["5", "10", "25", "50"])
        self.assertEqual(len(re.findall(r'aria-current="true">(\d+) كم', self.visitor.text)), 1)
        self.assertIn('aria-current="true">25 كم</a>', self.visitor.text)
        self.assertEqual(repo.RADII, (5, 10, 25, 50))

    async def test_a_bad_place_in_the_address_is_ignored(self):
        for q in ({"lat": "abc", "lng": "46.6"}, {"lat": "24.7"}, {"lat": "99", "lng": "46.6"}, {"lat": "24.7", "lng": "181"}, {"lng": "46.6"}):
            await self.visitor.get("/search", **q)
            self.assertEqual(self.visitor.last.status, 200, q)
            self.assertEqual(len(self.titles(self.visitor.text)), 6, q)
            self.assertNotIn("تبعد", self.visitor.text)
            self.assertIn('id="near-btn"', self.visitor.text)          # he is offered the button again

    async def test_the_place_is_kept_to_a_hundred_metres_in_every_link(self):
        await self.visitor.get("/search", lat="24.71361234567", lng="46.67531234567", km="10")
        links = [h for h in hrefs(self.visitor.text) if h.startswith("/search") and "lat=" in h]
        self.assertTrue(links)
        for link in links:
            q = query(link)
            self.assertEqual((q["lat"], q["lng"]), ("24.714", "46.675"))

    async def test_near_me_survives_the_toggle_the_filters_and_the_pager(self):
        await self.visitor.get("/search", lat="24.7136", lng="46.6753", km="50", city="1")
        to_map = next(h for h in hrefs(self.visitor.text) if "view=map" in h and h.startswith("/search"))
        self.assertEqual(query(to_map), {"city": "1", "view": "map", "lat": "24.714", "lng": "46.675", "km": "50"})
        for name in ("lat", "lng", "km"):
            self.assertIn(f'<input type="hidden" name="{name}"', self.visitor.text)
        await self.visitor.get(to_map)
        pins = attrs(self.visitor.text)
        self.assertEqual([p["title"] for p in pins], ["استراحة قريبة", "استراحة متوسطة", "استراحة بعيدة"])
        self.assertEqual([p["away"] for p in pins], ["1.1 كم", "11 كم", "33 كم"])
        self.assertIn('data-me="24.714,46.675" data-km="50"', self.visitor.text)
        cancel = next(h for h in hrefs(self.visitor.text) if h.startswith("/search") and "lat=" not in h and "view=map" in h and "city=1" in h)
        self.assertEqual(query(cancel), {"city": "1", "view": "map"})

    async def test_nearest_first_is_the_default_and_the_visitor_can_choose_another_order(self):
        await self.visitor.get("/search", lat="24.7136", lng="46.6753", km="50")
        self.assertIn('<option value="near" selected>الأقرب إليك</option>', self.visitor.text)
        await self.visitor.get("/search", lat="24.7136", lng="46.6753", km="50", sort="dear")
        self.assertIn('<option value="dear" selected>', self.visitor.text)
        link = next(h for h in hrefs(self.visitor.text) if "view=map" in h)
        self.assertEqual(query(link)["sort"], "dear")                  # his choice is kept
        await self.visitor.get("/search", sort="near")                  # without a place there is no «nearest»
        self.assertNotIn('value="near"', self.visitor.text)
        self.assertIn('<option value="new" selected>', self.visitor.text)

    async def test_nothing_within_the_distance_says_how_far_the_nearest_is(self):
        await self.visitor.get("/search", lat="21.5", lng="39.2", km="5", city="1")            # in Jeddah, asking for the Riyadh adverts
        self.assertIn("ما لقينا استراحات ضمن 5 كم من موقعك", self.visitor.text)
        self.assertRegex(self.visitor.text, r"أقرب استراحة تطابق بحثك تبعد \d+ كم عن موقعك")
        self.assertIn("وسّع المسافة إلى 10 كم", self.visitor.text)
        self.assertIn("عرض كل الاستراحات", self.visitor.text)
        await self.visitor.get("/search", lat="21.5", lng="39.2", km="50", city="1", view="map")
        self.assertIn("ما لقينا استراحات ضمن 50 كم من موقعك", self.visitor.text)
        self.assertNotIn("وسّع المسافة", self.visitor.text)            # 50 is the widest
        self.assertIn('id="browse-map"', self.visitor.text)             # the map is still drawn, with his place and the circle
        self.assertIn('data-me="21.500,39.200" data-km="50"', self.visitor.text)

    async def test_a_page_of_the_list_keeps_the_place(self):
        for i in range(14):
            lid = await self.add_listing(self.owner, title=f"استراحة إضافية {i}", lat="24.72", lng="46.68")
            self.approve(lid)
        await self.visitor.get("/search", lat="24.7136", lng="46.6753", km="25")
        nxt = next(h for h in hrefs(self.visitor.text) if "page=2" in h)
        self.assertEqual(query(nxt), {"lat": "24.714", "lng": "46.675", "km": "25", "page": "2"})
        await self.visitor.get(nxt)
        self.assertIn("صفحة 2 من 2", self.visitor.text)
        self.assertIn("تبعد", self.visitor.text)

    async def test_the_map_page_carries_the_map_and_nothing_runs_from_the_page(self):
        r = await self.visitor.get("/search", view="map")
        text = self.visitor.text
        self.assertIn('id="browse-map"', text)
        self.assertIn('data-tiles="https://tile.openstreetmap.org/{z}/{x}/{y}.png"', text)
        self.assertIn('/static/vendor/leaflet/leaflet.css?v=1.9.4', text)
        self.assertLess(text.index("leaflet.js"), text.index("map.js"))
        self.assertLess(text.index("map.js"), text.index("app.js"))
        self.assertNotRegex(text, r"<script(?![^>]*\bsrc=)")           # no inline script
        self.assertNotRegex(text, r"\sstyle=")                          # no inline style (the policy forbids them)
        self.assertNotRegex(text, r"\sonclick=|\sonload=|javascript:")
        self.assertIn("<noscript>", text)
        self.assertIn('id="pins" hidden', text)

    async def test_every_text_in_a_pin_is_escaped(self):
        lid = await self.add_listing(self.owner, title='استراحة "<b>خطر</b>" & ٣', lat="24.72", lng="46.68")
        self.approve(lid)
        await self.visitor.get("/search", view="map")
        self.assertNotIn("<b>خطر</b>", self.visitor.text)
        self.assertIn('data-title="استراحة &quot;&lt;b&gt;خطر&lt;/b&gt;&quot; &amp; ٣"', self.visitor.text)

    async def test_the_map_is_capped_and_says_so(self):
        import istiraha.views_public as vp
        original = vp.MAP_PINS
        self.addCleanup(setattr, vp, "MAP_PINS", original)
        self.assertEqual(original, 500)
        vp.MAP_PINS = 3
        await self.visitor.get("/search", view="map")
        self.assertEqual(len(attrs(self.visitor.text)), 3)
        self.assertIn("نعرض أول 3 استراحة", self.visitor.text)
        self.assertIn("5 على الخريطة", self.visitor.text)            # the count says how many there are, not how many are drawn
        vp.MAP_PINS = 5
        await self.visitor.get("/search", view="map")
        self.assertEqual(len(attrs(self.visitor.text)), 5)
        self.assertNotIn("نعرض أول", self.visitor.text)


# ---- headers, files, settings -------------------------------------------------------------------------------------
class HeaderTests(Case):
    def headers(self, response):
        from istiraha.server import SECURITY_HEADERS as base
        return {**base, **response.headers}

    async def test_only_the_pages_that_need_the_map_change_the_headers(self):
        for path in ("/", "/offers", "/terms", "/privacy", "/owner/login", "/admin/login", "/static/app.css", "/robots.txt", "/healthz"):
            r = await self.visitor.get(path)
            self.assertNotIn("Content-Security-Policy", r.headers, path)
            self.assertNotIn("Permissions-Policy", r.headers, path)
            self.assertEqual(self.headers(r)["Permissions-Policy"], PERMISSIONS, path)
        self.assertEqual(PERMISSIONS, "geolocation=(), camera=(self), microphone=(), payment=(), usb=()")           # as it was before the maps
        self.assertNotIn("openstreetmap", SECURITY_HEADERS["Content-Security-Policy"])

    async def test_the_list_may_ask_for_the_place_but_loads_no_outside_picture(self):
        r = await self.visitor.get("/search")
        self.assertEqual(r.headers["Permissions-Policy"], PERMISSIONS_WITH_PLACE)
        self.assertNotIn("Content-Security-Policy", r.headers)         # the default policy: no outside host at all
        self.assertNotIn("leaflet", self.visitor.text)                 # and the library is not even sent

    async def test_the_map_page_adds_its_picture_server_to_the_image_rule_and_nothing_else(self):
        r = await self.visitor.get("/search", view="map")
        csp = r.headers["Content-Security-Policy"]
        self.assertEqual(csp, SECURITY_HEADERS["Content-Security-Policy"].replace("img-src 'self' data: blob:", "img-src 'self' data: blob: https://tile.openstreetmap.org"))
        self.assertEqual(r.headers["Permissions-Policy"], PERMISSIONS_WITH_PLACE)
        self.assertNotIn("Referrer-Policy", r.headers)                 # the page keeps «same-origin»; only the map pictures say who asked (in the script)
        self.assertEqual(SECURITY_HEADERS["Referrer-Policy"], "same-origin")
        self.assertIn("script-src 'self'", csp)
        self.assertNotRegex(csp, r"script-src[^;]*https?:")

    async def test_the_owner_form_pages_get_the_same_map_headers(self):
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        r = await owner.get(f"/owner/listing/{lid}/edit")
        self.assertIn("https://tile.openstreetmap.org", r.headers["Content-Security-Policy"])
        self.assertEqual(r.headers["Permissions-Policy"], PERMISSIONS_WITH_PLACE)
        for path in ("/owner", f"/owner/listing/{lid}", "/owner/offers", "/owner/commissions"):
            r = await owner.get(path)
            self.assertNotIn("Content-Security-Policy", r.headers, path)
            self.assertNotIn("Permissions-Policy", r.headers, path)

    async def test_a_chosen_picture_server_is_what_the_policy_and_the_page_use(self):
        owner = await self.make_owner()
        self.approve(await self.add_listing(owner, lat="24.7136", lng="46.6753"))
        self.app.settings = settingsmod.load_settings({"MAP_TILE_URL": "https://{s}.tiles.example.net/v1/{z}/{x}/{y}{r}.png?key=Abc-123", "MAP_CREDIT": "© Example Maps"})
        r = await self.visitor.get("/search", view="map")
        self.assertIn("img-src 'self' data: blob: https://*.tiles.example.net;", r.headers["Content-Security-Policy"])
        self.assertNotIn("openstreetmap", r.headers["Content-Security-Policy"])
        self.assertIn('data-tiles="https://{s}.tiles.example.net/v1/{z}/{x}/{y}{r}.png?key=Abc-123"', self.visitor.text)
        self.assertIn('data-credit="© Example Maps"', self.visitor.text)
        await self.visitor.get("/privacy")
        self.assertIn("tiles.example.net", self.visitor.text)

    async def test_the_privacy_page_tells_the_truth_about_the_place_and_the_map(self):
        await self.visitor.get("/privacy")
        self.assertIn("الموقع والخريطة", self.visitor.text)
        self.assertIn("tile.openstreetmap.org", self.visitor.text)
        self.assertIn("ولا نحفظه", self.visitor.text)

    async def test_the_library_is_served_from_its_own_folders_and_nothing_else_is(self):
        for path, kind in (("/static/vendor/leaflet/leaflet.js", "text/javascript"), ("/static/vendor/leaflet/leaflet.css", "text/css"),
                           ("/static/vendor/leaflet/images/marker-icon.png", "image/png"), ("/static/map.js", "text/javascript"),
                           ("/static/vendor/leaflet/LICENSE.txt", "text/plain")):
            r = await self.visitor.get(path)
            self.assertEqual((r.status, r.content_type.split(";")[0]), (200, kind), path)
        r = await self.visitor.get("/static/vendor/leaflet/leaflet.js")
        self.assertEqual(r.headers["Cache-Control"], "public, max-age=31536000, immutable")
        self.assertEqual((await self.visitor.get("/static/map.js")).headers["Cache-Control"], "public, max-age=3600")
        for path in ("/static/vendor/leaflet/../../app.py", "/static/vendor/leaflet/%2e%2e/app.css", "/static/vendor/nope.js", "/static/vendor/leaflet/images/../../../app.css",
                     "/static/vendor/leaflet/", "/static/vendor/leaflet", "/static/vendor", "/static/other/leaflet.js", "/static/vendor/leaflet/images/x/y.png",
                     "/static/vendor/leaflet/leaflet.js.map", "/static/vendor/leaflet/..", "/static/vendor/leaflet/images/.."):
            self.assertEqual((await self.visitor.get(path)).status, 404, path)

    async def test_the_site_does_not_write_the_visitors_place_in_its_log(self):
        import logging
        with self.assertLogs("istiraha", level="DEBUG") as logs:
            logging.getLogger("istiraha").info("probe")
            await self.visitor.get("/search", lat="24.7136", lng="46.6753", km="25")
        self.assertNotIn("24.71", " ".join(logs.output))


class SettingsTests(unittest.TestCase):
    def test_the_defaults_are_openstreetmap_and_no_extra_credit(self):
        s = settingsmod.load_settings({})
        self.assertEqual(s.map_tile_url, "https://tile.openstreetmap.org/{z}/{x}/{y}.png")
        self.assertEqual((s.map_tile_origin, s.map_credit), ("https://tile.openstreetmap.org", ""))

    def test_another_provider_is_a_setting_not_a_release(self):
        s = settingsmod.load_settings({"MAP_TILE_URL": "https://tiles.stadiamaps.com/tiles/osm_bright/{z}/{x}/{y}{r}.png?api_key=abc-123", "MAP_CREDIT": " © Stadia Maps © OpenMapTiles "})
        self.assertEqual(s.map_tile_origin, "https://tiles.stadiamaps.com")
        self.assertEqual(s.map_credit, "© Stadia Maps © OpenMapTiles")
        self.assertEqual(settingsmod.load_settings({"MAP_TILE_URL": "https://{s}.tile.example.com/{z}/{x}/{y}.png"}).map_tile_origin, "https://*.tile.example.com")

    def test_an_unsafe_or_incomplete_address_stops_the_start(self):
        for bad in ("http://tile.openstreetmap.org/{z}/{x}/{y}.png", "https://tile.openstreetmap.org/{z}/{x}.png", "https://tile.openstreetmap.org/",
                    "https://evil.example/\"onerror=x/{z}/{x}/{y}.png", "https://localhost/{z}/{x}/{y}.png", "https://a.example/ {z}/{x}/{y}",
                    "https://user:pass@a.example/{z}/{x}/{y}.png", "https://a.example:99999999/{z}/{x}/{y}.png", "//a.example/{z}/{x}/{y}.png",
                    "https://a.example/{z}/{x}/{y}.png<script>", "javascript:alert(1)//{z}{x}{y}", "https://a.example;img-src */{z}/{x}/{y}.png"):
            with self.assertRaises(settingsmod.ConfigError, msg=bad):
                settingsmod.load_settings({"MAP_TILE_URL": bad})

    def test_the_credit_is_plain_text(self):
        s = settingsmod.load_settings({"MAP_CREDIT": "© <b>Maps</b>\n" + "x" * 300})
        self.assertNotIn("<", s.map_credit)
        self.assertLessEqual(len(s.map_credit), 120)
        self.assertNotIn("\n", s.map_credit)


MAP_JS = (Path(__file__).resolve().parent.parent / "istiraha" / "static" / "map.js").read_text(encoding="utf-8")


class PageAndScriptTests(Case):
    """What the pages hand to map.js and what map.js may do with it. The script itself is exercised on real phones (see the release notes); these
    keep the two halves agreeing, and each one is a mistake that was really made once and found only in a browser."""

    async def test_the_address_of_the_pictures_is_on_the_box_or_on_the_window_that_holds_the_box(self):
        owner = await self.make_owner()
        lid = await self.add_listing(owner, lat="24.7136", lng="46.6753")
        self.approve(lid)
        await self.visitor.get("/search", view="map")
        self.assertRegex(self.visitor.text, r'<div id="browse-map"[^>]* data-tiles="https://tile\.openstreetmap\.org/\{z\}/\{x\}/\{y\}\.png"')
        await owner.get(f"/owner/listing/{lid}/edit")
        window = re.search(r'<div class="picker" id="picker"[^>]*>', owner.text)
        self.assertIsNotNone(window)
        self.assertIn(" data-tiles=", window.group(0))
        self.assertGreater(owner.text.index('id="pick-map"'), window.end())          # the map box is inside that window
        self.assertIn("closest('[data-tiles]')", MAP_JS)                                # and the script looks for the address up there

    def test_the_picker_jumps_it_never_glides(self):
        """A second request to move the map that comes while the library is still gliding is dropped: «موقعي الحالي» then did nothing."""
        picker = MAP_JS[MAP_JS.index("function pick("):]
        calls = re.findall(r"\.setView\([^;]*;", picker)
        self.assertGreaterEqual(len(calls), 4)
        for call in calls:
            self.assertTrue("jump" in call or "animate: false" in call, call)

    def test_the_circle_of_the_distance_is_not_asked_its_size_before_the_map_has_a_view(self):
        """Asking a circle for its bounds before it is on a loaded map is an error; it stopped the whole map after «الأقرب إليك»."""
        self.assertNotIn(".getBounds()", MAP_JS)
        self.assertIn("toBounds(", MAP_JS)

    def test_a_map_that_could_not_be_made_says_so(self):
        self.assertIn("تعذّر عرض الخريطة الآن", MAP_JS)

    async def test_the_filters_and_the_near_button_share_a_row_on_the_map_page(self):
        await self.visitor.get("/search", view="map")
        self.assertRegex(self.visitor.text, r'(?s)<div class="tools"><section class="near".*?</details></div>')
        await self.visitor.get("/search", view="map", lat="24.7136", lng="46.6753", km="10")
        self.assertRegex(self.visitor.text, r'(?s)<div class="tools"><section class="near on".*?</details></div>')

    async def test_the_way_back_sits_next_to_the_label_before_the_four_distances(self):
        await self.visitor.get("/search", lat="24.7136", lng="46.6753", km="10")
        text = self.visitor.text
        self.assertLess(text.index("القريبة من موقعك"), text.index("إلغاء تحديد موقعي"))
        self.assertLess(text.index("إلغاء تحديد موقعي"), text.index('aria-label="المسافة"'))

    async def test_the_two_numbers_of_a_place_read_left_to_right_inside_the_sentence(self):
        owner = await self.make_owner()
        lid = await self.add_listing(owner, lat="24.7136", lng="46.6753")
        await owner.get(f"/owner/listing/{lid}/edit")
        self.assertIn("تم تحديد الموقع ✓ (\u206624.7136, 46.6753\u2069)", owner.text)


class ListingPageTests(Case):
    async def test_a_pinned_advert_offers_the_map_app_when_the_owner_gave_no_link(self):
        owner = await self.make_owner()
        lid = await self.add_listing(owner, lat="24.7136", lng="46.6753")
        self.approve(lid)
        await self.visitor.get(f"/r/{lid}")
        self.assertIn('href="https://www.google.com/maps/search/?api=1&amp;query=24.713600,46.675300"', self.visitor.text)
        self.assertIn("الموقع على الخريطة", self.visitor.text)

    async def test_the_owners_own_link_is_still_the_one_that_is_used(self):
        owner = await self.make_owner()
        lid = await self.add_listing(owner, lat="24.7136", lng="46.6753", map_url="https://maps.app.goo.gl/abcdef")
        self.approve(lid)
        await self.visitor.get(f"/r/{lid}")
        self.assertIn('href="https://maps.app.goo.gl/abcdef"', self.visitor.text)
        self.assertNotIn("api=1&amp;query", self.visitor.text)

    async def test_the_home_page_leads_to_the_map(self):
        await self.visitor.get("/")
        self.assertIn('href="/search?view=map"', self.visitor.text)
        self.assertIn("تصفّح الاستراحات على الخريطة", self.visitor.text)


if __name__ == "__main__":
    unittest.main()
