"""Pages anyone can open without an account: home, search, one advert, offers, the files."""
from __future__ import annotations

from urllib.parse import urlencode

from . import founders, images, repo, ui, util
from .app import STATIC_DIR, STATIC_TYPES, Ctx, html_page, map_headers, not_found
from .server import Response, text_response
from .ui import e, num

TERMS = [
    ("ما هذه المنصة", "منصة للتعريف بالاستراحات المعروضة للإيجار داخل المملكة. تعرض الإعلانات كما يدخلها أصحابها، ولا تكون طرفًا في عقد الإيجار بين العميل وصاحب الاستراحة."),
    ("الحجز والدفع", "يتم التواصل والاتفاق على الحجز والسعر والدفع مباشرة بين العميل وصاحب الاستراحة عبر واتساب. تأكد من التفاصيل والتاريخ قبل أي دفع."),
    ("أصحاب الاستراحات", "يلتزم صاحب الاستراحة بصحة بياناته وصوره، وبسداد العمولة المستحقة للمنصة وفق التعهد الإلكتروني الذي يوافق عليه قبل نشر إعلانه. والعروض والخصومات التي يضعها على إعلانه قراره هو، ويلتزم بها مع العميل."),
    ("حق المنصة", "للمنصة مراجعة الإعلانات وقبولها أو رفضها أو إيقافها عند مخالفتها للشروط أو عند ورود شكاوى موثوقة."),
    ("تنبيه", "هذه الصفحة نص مبدئي ويجب مراجعته قانونيًا قبل إطلاق المنصة رسميًا."),
]
PRIVACY = [
    ("ما نحفظه", "حساب صاحب الاستراحة (الاسم ورقم الجوال وكلمة المرور مشفّرة)، وبيانات إعلانه وصوره، وسجل موافقته على التعهد."),
    ("الزوار", "تصفح الاستراحات والبحث لا يحتاج حسابًا، ولا نحفظ بيانات شخصية للزائر. نحسب عدد المشاهدات والضغط على زر واتساب بدون ربطها بشخص."),
    ("الصور", "نحذف من الصور المرفوعة بيانات الكاميرا والموقع الجغرافي المخزنة داخلها."),
    ("رقم الواتساب", "رقم صاحب الاستراحة يظهر للزوار لأنه وسيلة التواصل الأساسية. لا تضع رقمًا لا تريد نشره."),
]


MAP_PINS = 500          # most adverts on one map (a young site is far below this; it only guards the size of the page)


def privacy_sections(map_host: str) -> list[tuple[str, str]]:
    """The privacy page: the fixed sections and the one about the map, which names the server the map pictures really come from."""
    return PRIVACY + [
        ("الموقع والخريطة",
         "عند الضغط على «الأقرب إليك» يطلب المتصفح إذنك أولًا، ونستخدم موقعك لحساب المسافة فقط، ولا نحفظه ولا نربطه بأحد. "
         f"تُحمَّل صور الخريطة من خادم الخرائط ({map_host})، فيرى عنوان جهازك والمنطقة التي تعرضها، كأي موقع فيه خريطة. "
         "موقع الاستراحة على الخريطة يضعه صاحبها بنفسه، وهو ظاهر للجميع."),
    ]


def register(app) -> None:
    db = app.db

    @app.route("GET", "/")
    async def home(ctx: Ctx):
        today = ctx.today()
        data = repo.homepage(db, today)
        cities = db.all("SELECT * FROM cities WHERE active = 1 ORDER BY sort, id")
        cats = db.all("SELECT * FROM categories WHERE active = 1 ORDER BY sort, id")
        amen = db.all("SELECT * FROM amenities WHERE active = 1 ORDER BY sort, id")
        hero = f"""
<section class="hero">
<div class="hero-copy"><h1>استراحتك المناسبة، من صاحبها مباشرة</h1>
<p>ابحث بالمدينة والسعر والتاريخ، وتواصل مع صاحب الاستراحة على واتساب بدون حساب.</p></div>
<form class="search" method="get" action="/search" role="search">
<div class="row2">{ui.select("المدينة", "city", [(c["id"], c["name"]) for c in cities], blank="كل المدن")}
{ui.select("نوع الاستراحة", "category", [(c["id"], c["name"]) for c in cats], blank="الكل")}</div>
<div class="row2">{ui.field("أعلى سعر (ر.س)", "price_max", type="number", attrs='inputmode="numeric" min="1" placeholder="مثال: 1500"')}
{ui.field("تاريخ الإيجار", "date", type="date", attrs=f'min="{today.isoformat()}"')}</div>
<details class="more"><summary>المزيد من الخيارات</summary>
{ui.field("الحي", "district", attrs='maxlength="60" placeholder="اسم الحي"')}
<p class="lbl">المرافق</p>{ui.checks("amenity", [(a["id"], a["name"]) for a in amen], set())}</details>
<button class="btn big" type="submit">ابحث عن استراحة</button>
<p class="alt"><a href="/search?view=map">🗺️ أو تصفّح الاستراحات على الخريطة</a></p></form></section>"""
        # the founders' offer: its advert shows only while the manager has the offer on AND a seat is really free; both numbers are counted now
        taken = founders.taken(db)
        banner = ui.founders_banner(taken, founders.CAP - taken) if founders.is_on(db) and taken < founders.CAP else ""
        parts = [hero, banner]

        def section(title: str, items: list[dict], more: str = "") -> str:
            if not items:
                return ""
            cards = "".join(ui.card(i, repo.amenities_of(db, i["id"])) for i in items)
            link = f'<a class="more-link" href="{more}">عرض الكل</a>' if more else ""
            return f'<section class="block"><div class="head"><h2>{e(title)}</h2>{link}</div><div class="grid">{cards}</div></section>'

        parts.append(section("الاستراحات المميزة", data["featured"], "/search?featured=1"))
        parts.append(section("العروض والخصومات", data["deals"], "/offers"))
        parts.append(section("أحدث الاستراحات", data["latest"], "/search"))
        if not any(data.values()):
            parts.append('<section class="empty"><h2>لا توجد استراحات منشورة بعد</h2><p>كن أول من يضيف استراحته في المنصة.</p>'
                         '<a class="btn sun" href="/owner/new">أضف استراحتك</a></section>')
        parts.append('<section class="owner-cta"><div><h2>عندك استراحة؟</h2><p>أضفها بنفسك خلال دقائق، ويتواصل معك العملاء مباشرة على واتساب.</p></div>'
                     '<a class="btn sun" href="/owner/new">أضف استراحتك</a></section>')
        return html_page(ctx, "", "".join(parts), canonical="/", extra_class="home")

    def _place(q) -> tuple[tuple[float, float] | None, int]:
        """The visitor's place and distance from the address (lat, lng, km): (None, 0) when there is none, or it is not a place on earth.
        The place is kept to three decimals (about a hundred metres): no more is needed to say what is near, and less travels in a link."""
        lat, lng = util.parse_coord(q.get("lat", ""), -90, 90), util.parse_coord(q.get("lng", ""), -180, 180)
        if lat is None or lng is None:
            return None, 0
        km = util.parse_int(q.get("km", ""), 1, 1000)
        return (round(lat, 3), round(lng, 3)), (km if km in repo.RADII else repo.DEFAULT_RADIUS)

    def _filters(request) -> dict:
        q = request.query
        near, km = _place(q)
        wanted = q.get("sort")
        sort = wanted if wanted in repo.SORTS or (near and wanted == repo.SORT_NEAR[0]) else ("near" if near else "new")      # nearest first once he gave his place
        return dict(
            city=util.parse_int(q.get("city", ""), 1, 10**6), category=util.parse_int(q.get("category", ""), 1, 10**6),
            district=q.get("district", "").strip()[:60], price_min=util.parse_int(q.get("price_min", ""), 1, 10**7, util.PRICE_WORDS),
            price_max=util.parse_int(q.get("price_max", ""), 1, 10**7, util.PRICE_WORDS), on=util.parse_date(q.get("date", "")),
            amenities=[n for n in (util.parse_int(x, 1, 10**6) for x in request.query_list("amenity")) if n],
            offers_only=q.get("offers") == "1", featured_only=q.get("featured") == "1",
            sort=sort, query=q.get("q", "").strip()[:60], near=near, km=km if near else None,
        )

    def _pairs(f: dict) -> list[tuple[str, str]]:
        """The search as address parts: the same ones the form sends, so a link made from them gives the same results."""
        default_sort = "near" if f["near"] else "new"
        pairs = [("city", f["city"]), ("category", f["category"]), ("sort", f["sort"] if f["sort"] != default_sort else ""),
                 ("price_min", f["price_min"]), ("price_max", f["price_max"]), ("date", f["on"].isoformat() if f["on"] else ""),
                 ("district", f["district"]), ("offers", "1" if f["offers_only"] else ""), ("featured", "1" if f["featured_only"] else ""),
                 ("q", f["query"]), *[("amenity", a) for a in f["amenities"]]]
        return [(k, v) for k, v in pairs if v]

    def _url(f: dict, view: str, *, place: bool = True, km: int | None = None) -> str:
        """The search page with the same filters, in the list or on the map, with or without the visitor's place (and another distance)."""
        pairs = _pairs(f)
        if view == "map":
            pairs.append(("view", "map"))
        if place and f["near"]:
            pairs += [("lat", f"{f['near'][0]:.3f}"), ("lng", f"{f['near'][1]:.3f}"), ("km", str(km or f["km"]))]
        return "/search" + ("?" + urlencode(pairs) if pairs else "")

    def _pin(i: dict) -> str:
        """One advert on the map as the page hands it to the script: all in attributes (nothing is run from the page itself)."""
        attrs = {"id": i["id"], "lat": f"{i['lat']:.6f}", "lng": f"{i['lng']:.6f}", "title": i["title"], "price": num(i["final_price"]),
                 "was": num(i["price"]) if i["discount"] else "", "discount": i["discount"] or "", "unit": repo.UNIT_SHORT.get(i["unit"], ""),
                 "image": i["cover"] or "", "place": f"{i['city_name']} · {i['category_name']}",
                 "away": util.distance_text(i["km"]) if i.get("km") is not None else ""}
        return "<li " + " ".join(f'data-{k}="{e(v)}"' for k, v in attrs.items()) + "></li>"

    def _near_block(f: dict, view: str) -> str:
        """«الأقرب إليك»: the button that asks for the visitor's place (the script shows it only if the phone can say where it is), or, once he
        gave it, the four distances, what is shown, and the way back."""
        if not f["near"]:
            return ('<section class="near" aria-label="الأقرب إليك"><button class="btn ghost" type="button" id="near-btn" hidden '
                    f'data-href="{e(_url(f, view, place=False))}">📍 الأقرب إليك</button><p class="hint" id="near-msg" role="status"></p></section>')
        radii = "".join(f'<a href="{e(_url(f, view, km=r))}"' + (' aria-current="true"' if r == f["km"] else "") + f">{r} كم</a>" for r in repo.RADII)
        return ('<section class="near on" aria-label="الأقرب إليك"><p>📍 القريبة من موقعك، ضمن:</p>'
                f'<a class="btn ghost small" href="{e(_url(f, view, place=False))}">إلغاء تحديد موقعي</a>'
                f'<nav class="seg" aria-label="المسافة">{radii}</nav></section>')

    def _nothing_near(f: dict, view: str, today) -> str:
        """No advert within the chosen distance: how far the nearest one is, and the two ways out (a wider distance, or all the adverts)."""
        fit = {k: v for k, v in f.items() if k not in ("near", "km")}
        far = repo.nearest_km(db, today, f["near"], **fit)
        wider = next((r for r in repo.RADII if r > f["km"]), None)
        line = f"أقرب استراحة تطابق بحثك تبعد {util.distance_text(far)} عن موقعك." if far is not None else "لا توجد استراحات بموقع محدد تطابق بحثك."
        more = f'<a class="btn" href="{e(_url(f, view, km=wider))}">وسّع المسافة إلى {wider} كم</a> ' if wider and far is not None else ""
        return (f'<section class="empty"><h2>ما لقينا استراحات ضمن {f["km"]} كم من موقعك</h2><p>{e(line)}</p>'
                f'{more}<a class="btn ghost" href="{e(_url(f, view, place=False))}">عرض كل الاستراحات</a></section>')

    @app.route("GET", "/search")
    async def search(ctx: Ctx):
        request = ctx.request
        f = _filters(request)
        view = "map" if request.query.get("view") == "map" else "list"
        page = util.parse_int(request.query.get("page", "1"), 1, 500) or 1
        today = ctx.today()
        cities = db.all("SELECT * FROM cities WHERE active = 1 ORDER BY sort, id")
        cats = db.all("SELECT * FROM categories WHERE active = 1 ORDER BY sort, id")
        amen = db.all("SELECT * FROM amenities WHERE active = 1 ORDER BY sort, id")
        chosen = set(f["amenities"])
        sorts = ([repo.SORT_NEAR] if f["near"] else []) + list(repo.SORTS.items())
        keep = ""                                       # what the form must send again, or the new results would lose the map and his place
        if view == "map":
            keep += '<input type="hidden" name="view" value="map">'
        if f["near"]:
            keep += "".join(f'<input type="hidden" name="{n}" value="{e(x)}">' for n, x in (("lat", f"{f['near'][0]:.3f}"), ("lng", f"{f['near'][1]:.3f}"), ("km", f["km"])))
        form = f"""<form class="filters" method="get" action="/search">{keep}
<div class="row2 keep">{ui.select("المدينة", "city", [(c["id"], c["name"]) for c in cities], f["city"] or "", blank="كل المدن")}
{ui.select("النوع", "category", [(c["id"], c["name"]) for c in cats], f["category"] or "", blank="الكل")}</div>
<div class="row2 keep">{ui.field("من (ر.س)", "price_min", f["price_min"] or "", type="number", attrs='inputmode="numeric" min="1"')}
{ui.field("إلى (ر.س)", "price_max", f["price_max"] or "", type="number", attrs='inputmode="numeric" min="1"')}</div>
<div class="row2">{ui.field("تاريخ الإيجار", "date", f["on"].isoformat() if f["on"] else "", type="date", attrs=f'min="{today.isoformat()}"')}
{ui.select("الترتيب", "sort", sorts, f["sort"])}</div>
<details class="more"{" open" if chosen or f["district"] or f["offers_only"] else ""}><summary>المزيد من الخيارات</summary>
{ui.field("الحي", "district", f["district"], attrs='maxlength="60"')}
{ui.checks("amenity", [(a["id"], a["name"]) for a in amen], chosen)}
<label class="chk"><input type="checkbox" name="offers" value="1"{" checked" if f["offers_only"] else ""}><span>العروض والخصومات فقط</span></label></details>
<button class="btn big" type="submit">تحديث النتائج</button></form>"""
        list_href, map_href = _url(f, "list"), _url(f, "map")
        toggle = ('<nav class="seg view" aria-label="طريقة العرض">'
                  f'<a href="{e(list_href)}"' + (' aria-current="page"' if view == "list" else "") + '>عرض القائمة</a>'
                  f'<a href="{e(map_href)}"' + (' aria-current="page"' if view == "map" else "") + '>عرض الخريطة</a></nav>')
        near_html = _near_block(f, view)
        if view == "map":
            pins = repo.matching(db, today, **{**f, "located_only": True})
            missing = 0 if f["near"] else len(repo.matching(db, today, **{**f, "sort": "new"})) - len(pins)
            shown = pins[:MAP_PINS]
            active = len([1 for k, _ in _pairs(f) if k != "sort"])
            fold = f'<details class="more fold"><summary>تصفية النتائج{f" ({active})" if active else ""}</summary>{form}</details>'
            notes = ""
            if len(pins) > MAP_PINS:
                notes += f'<p class="muted fine">نعرض أول {num(MAP_PINS)} استراحة. حدّد المدينة أو اضغط «الأقرب إليك» لتضييق الخريطة.</p>'
            if missing:
                notes += (f'<p class="muted fine">{num(missing)} استراحة تطابق بحثك لم يحدد صاحبها موقعها على الخريطة بعد، '
                          f'تجدها في <a href="{e(list_href)}">عرض القائمة</a>.</p>')
            if f["near"]:
                body_top = _nothing_near(f, "map", today) if not pins else ""
            else:
                body_top = ""
            if not pins and not f["near"]:
                content = ('<section class="empty"><h2>ما فيه استراحات بموقع محدد تطابق بحثك</h2>'
                           f'<p>جرّب تغيير الفلاتر، أو تصفح <a href="{e(list_href)}">القائمة</a> فهي تعرض كل الاستراحات.</p></section>')
            else:
                settings = ctx.settings
                me = f' data-me="{f["near"][0]:.3f},{f["near"][1]:.3f}" data-km="{f["km"]}"' if f["near"] else ""
                content = (f'<section class="mapbox" aria-label="خريطة الاستراحات">'
                           f'<div id="browse-map" class="map" dir="ltr" role="region" aria-label="خريطة الاستراحات" data-tiles="{e(settings.map_tile_url)}" '
                           f'data-credit="{e(settings.map_credit)}"{me}></div>'
                           '<p class="map-status" id="map-status" role="status"></p>'
                           '<div id="pin-slot" class="pinslot" aria-live="polite"><p class="muted">اضغط على علامة السعر لتظهر بطاقة الاستراحة.</p></div>'
                           f'<ul id="pins" hidden>{"".join(_pin(i) for i in shown)}</ul></section>'
                           f'<noscript><p class="note">الخريطة تحتاج تشغيل JavaScript في المتصفح. <a href="{e(list_href)}">اعرض القائمة</a> بدلًا منها.</p></noscript>')
            body = (f'<h1 class="title">الاستراحات <small>{num(len(pins))} على الخريطة</small></h1>{toggle}<div class="tools">{near_html}{fold}</div>'
                    f'{body_top}{content}{notes}')
            head, scripts = ui.map_assets()
            return html_page(ctx, "الاستراحات على الخريطة", body, noindex=bool(request.query), canonical="/search", head=head, scripts=scripts,
                             headers=map_headers(ctx))
        items, total = repo.search(db, today, page=page, **f)
        if items:
            cards = "".join(ui.card(i, repo.amenities_of(db, i["id"])) for i in items)
            results = f'<div class="grid">{cards}</div>'
        elif f["near"]:
            results = _nothing_near(f, "list", today)
        else:
            results = ('<section class="empty"><h2>ما لقينا استراحات بهذه الشروط</h2>'
                       '<p>جرّب مدينة أخرى، أو ارفع السعر، أو أزل بعض المرافق.</p><a class="btn ghost" href="/search">إزالة الفلاتر</a></section>')
        body = (f'<h1 class="title">الاستراحات <small>{num(total)} نتيجة</small></h1>{toggle}{near_html}{form}{results}'
                f'{ui.pager(page, total, list_href)}')
        return html_page(ctx, "ابحث عن استراحة", body, noindex=bool(request.query), canonical="/search", headers=map_headers(ctx, tiles=False))

    @app.route("GET", "/offers")
    async def offers(ctx: Ctx):
        items, total = repo.search(db, ctx.today(), offers_only=True, sort="deal", page=util.parse_int(ctx.request.query.get("page", "1"), 1, 500) or 1)
        cards = "".join(ui.card(i, repo.amenities_of(db, i["id"])) for i in items)
        content = f'<div class="grid">{cards}</div>' if items else '<section class="empty"><h2>لا توجد عروض الآن</h2><p>تابعنا قريبًا.</p><a class="btn ghost" href="/search">تصفح كل الاستراحات</a></section>'
        return html_page(ctx, "العروض والخصومات", f'<h1 class="title">العروض والخصومات</h1>{content}{ui.pager(1, total, "/offers")}', canonical="/offers")

    @app.route("GET", r"/r/(\d{1,9})")
    async def listing(ctx: Ctx, raw_id: str):
        lid = int(raw_id)
        item = repo.public_listing(db, lid, ctx.today())
        owner_view = False
        if item is None:
            # the owner and the admin may open an advert that is not public yet
            row = repo.any_listing(db, lid)
            if row and ((ctx.owner and ctx.owner["id"] == row["owner_id"]) or ctx.admin):
                owner_view = True
                item = {**row, **{"discount": 0, "final_price": row["price"], "offer_title": ""}}
            else:
                return not_found(ctx)
        else:
            db.run("UPDATE listings SET views = views + 1 WHERE id = ?", (lid,))
        photos = repo.photos_of(db, lid)
        names = repo.amenities_of(db, lid)
        blocks = [b for b in repo.blocks_of(db, lid) if b["end_date"] >= ctx.today().isoformat()]
        site = ctx.base_url
        link = util.whatsapp_link(item["whatsapp"], item["title"], f"{site}/r/{lid}" if site else "")
        if photos:
            main = f'<img id="main-photo" src="/media/{e(photos[0]["filename"])}" alt="{e(item["title"])}" width="1200" height="900">'
            thumbs = "".join(
                f'<a href="/media/{e(p["filename"])}" class="th" data-full="/media/{e(p["filename"])}"><img src="/media/{e(p["filename"])}" alt="" loading="lazy" width="160" height="120"></a>'
                for p in photos) if len(photos) > 1 else ""
            gallery = f'<div class="gallery"><div class="main-shot">{main}</div>{"<div class=thumbs>" + thumbs + "</div>" if thumbs else ""}</div>'
        else:
            gallery = '<div class="gallery"><div class="main-shot noimg" aria-hidden="true"></div></div>'
        unit = repo.UNITS.get(item["unit"], "")
        deal = (f'<p class="deal">عرض: {e(item["offer_title"])} — خصم {item["discount"]}%</p>' if item["discount"] else "")
        facts = [f'<li><b>المدينة</b>{e(item["city_name"])}</li>']
        if item["district"]:
            facts.append(f'<li><b>الحي</b>{e(item["district"])}</li>')
        facts.append(f'<li><b>النوع</b>{e(item["category_name"])}</li>')
        if item["capacity"]:
            facts.append(f'<li><b>السعة</b>حتى {num(item["capacity"])} شخص</li>')
        facts.append(f'<li><b>السعر</b>{ui.price_html(item)}</li>')
        facts.append(f'<li><b>مدة الإيجار</b>{e(unit)}</li>')
        chips = "".join(f"<li>{e(a)}</li>" for a in names)
        blocked = ""
        if blocks:
            blocked = ('<h2>تواريخ غير متاحة</h2><ul class="blocked">' + "".join(
                f'<li>{e(ui.day_text(b["start_date"]))}' + (f' — {e(ui.day_text(b["end_date"]))}' if b["end_date"] != b["start_date"] else "") + "</li>"
                for b in blocks[:12]) + "</ul>")
        note = f'<h2>الأوقات المتاحة</h2><p>{e(item["availability_note"])}</p>' if item["availability_note"] else ""
        mapbtn = (f'<a class="btn ghost" href="{e(item["map_url"])}" target="_blank" rel="noopener noreferrer">الموقع على الخريطة</a>' if item["map_url"] else "")
        if not mapbtn and item.get("lat") is not None and item.get("lng") is not None:          # no link of his own: the pin he set opens the map app
            nav = f"https://www.google.com/maps/search/?api=1&query={item['lat']:.6f},{item['lng']:.6f}"
            mapbtn = f'<a class="btn ghost" href="{e(nav)}" target="_blank" rel="noopener noreferrer">الموقع على الخريطة</a>'
        status = ""
        if owner_view:
            status = ui.notice("warn", f"هذه معاينة: حالة الإعلان «{repo.REVIEW_LABELS[item['review']]}»" + ("، وهو موقوف من صاحبه" if not item["owner_active"] else ""))
        body = f"""{status}<article class="detail">
{gallery}
<div class="d-main"><h1>{e(item["title"])}</h1><p class="where">{e(item["city_name"])}{" · " + e(item["district"]) if item["district"] else ""}</p>{deal}
<ul class="facts">{"".join(facts)}</ul>
{"<h2>المرافق والخدمات</h2><ul class=chips>" + chips + "</ul>" if chips else ""}
{"<h2>الوصف</h2><p class=desc>" + e(item["description"]) + "</p>" if item["description"] else ""}
{note}{blocked}
<div class="actions">{mapbtn}<button class="btn ghost" type="button" data-copy="{e(site + '/r/' + str(lid) if site else '')}">نسخ رابط الإعلان</button></div>
<p class="fine">السعر والتوفر يؤكدهما صاحب الاستراحة عند التواصل. الحجز والدفع يتمان بينك وبينه مباشرة.</p></div>
<div class="buy"><div><span class="lbl">يبدأ من</span>{ui.price_html(item)}</div>
<a class="btn wa" id="wa" data-id="{lid}" href="{e(link)}" target="_blank" rel="noopener noreferrer">تواصل واتساب للحجز</a></div></article>"""
        desc = (item["description"] or f"{item['category_name']} للإيجار في {item['city_name']}")[:150]
        cover = f"{site}/media/{photos[0]['filename']}" if photos and site else ""
        return html_page(ctx, item["title"], body, description=desc, canonical=f"/r/{lid}", image=cover, noindex=owner_view, extra_class="detail-page")

    @app.route("POST", r"/api/click/(\d{1,9})", "public")
    async def click(ctx: Ctx, raw_id: str):
        if app.click_limit.allow(ctx.request.ip):
            db.run("UPDATE listings SET clicks = clicks + 1 WHERE id = ? AND review = 'approved'", (int(raw_id),))
        return Response(204, b"", "text/plain")

    @app.route("GET", "/terms")
    async def terms(ctx: Ctx):
        return html_page(ctx, "الشروط والأحكام", _doc("الشروط والأحكام", TERMS), canonical="/terms")

    @app.route("GET", "/privacy")
    async def privacy(ctx: Ctx):
        host = ctx.settings.map_tile_origin.removeprefix("https://").replace("*.", "")
        return html_page(ctx, "الخصوصية", _doc("سياسة الخصوصية", privacy_sections(host)), canonical="/privacy")

    @app.route("GET", r"/media/([A-Za-z0-9]{8,64}\.(?:jpg|png|webp))")
    async def media(ctx: Ctx, name: str):
        path = app.settings.uploads_dir / name
        try:
            data = path.read_bytes()
        except OSError:
            return not_found(ctx)
        return Response(200, data, images.CONTENT_TYPES[name.rsplit(".", 1)[1]], {"Cache-Control": "public, max-age=31536000, immutable"})

    @app.route("GET", r"/static/((?:vendor/leaflet/(?:images/)?)?[A-Za-z0-9_.-]{1,60})")
    async def static(ctx: Ctx, name: str):
        path = STATIC_DIR / name
        kind = STATIC_TYPES.get(path.suffix)
        if kind is None or not path.is_file():
            return not_found(ctx)
        # the map library never changes under the same address (its pages ask for it with ?v=its version): a year is safe, and saves a phone's data
        cache = "public, max-age=31536000, immutable" if name.startswith("vendor/") else "public, max-age=3600"
        return Response(200, path.read_bytes(), kind, {"Cache-Control": cache})

    @app.route("GET", "/robots.txt")
    async def robots(ctx: Ctx):
        site = ctx.settings.site_url
        text = "User-agent: *\nDisallow: /admin\nDisallow: /owner\nDisallow: /api/\n" + (f"Sitemap: {site}/sitemap.xml\n" if site else "")
        return Response(200, text.encode(), "text/plain; charset=utf-8", {"Cache-Control": "public, max-age=3600"})

    @app.route("GET", "/sitemap.xml")
    async def sitemap(ctx: Ctx):
        site = ctx.settings.site_url
        if not site:
            return not_found(ctx)
        urls = [f"{site}/", f"{site}/search", f"{site}/offers"] + [f"{site}/r/{r['id']}" for r in db.all(
            "SELECT l.id FROM listings l JOIN cities c ON c.id = l.city_id WHERE l.review = 'approved' AND l.owner_active = 1 ORDER BY l.id DESC LIMIT 5000")]
        xml = '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' + "".join(
            f"<url><loc>{e(u)}</loc></url>" for u in urls) + "</urlset>"
        return Response(200, xml.encode(), "application/xml; charset=utf-8", {"Cache-Control": "public, max-age=3600"})

    @app.route("GET", "/healthz")
    async def healthz(ctx: Ctx):
        db.one("SELECT 1")
        return text_response(200, "ok")


def _doc(title: str, sections: list[tuple[str, str]]) -> str:
    return f'<article class="doc"><h1>{e(title)}</h1>' + "".join(f"<h2>{e(h)}</h2><p>{e(p)}</p>" for h, p in sections) + "</article>"
