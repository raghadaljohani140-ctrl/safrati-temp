"""The website's JSON answers, built on the bot's price engine and the offline fake provider (today is 2026-10-26)."""
import asyncio
import json
import re
import unittest
from datetime import date
from unittest import mock

from safrati import data, texts, tp
from safrati import dates as dts
from safrati.db import ORIGINS
from safrati.tp import TPError
from safrati.web import api
from safrati.web.api import WebApp
from safrati.web.server import Request
from safrati.web.settings import WebSettings
from tests.fakes import MARKER, NOW, TP_TOKEN, TRS, FakeTP

TODAY = date(2026, 10, 26)


def make(fake: FakeTP | None = None, *, token: str = TP_TOKEN, **settings) -> tuple[WebApp, FakeTP]:
    fake = fake or FakeTP()
    client = tp.TravelpayoutsClient(token, MARKER, TRS, "sar", transport=fake.transport, clock=lambda: NOW)
    app = WebApp(WebSettings(tp_token=token, tp_marker=MARKER, tp_trs=TRS, **settings), client, clock=lambda: NOW, static={})
    return app, fake


async def call(app: WebApp, path: str, **query):
    response = await app.handle(Request("GET", path, {k: str(v) for k, v in query.items()}, {}, "203.0.113.5"))
    assert TP_TOKEN.encode() not in response.body, "the price token must never reach a visitor"
    assert TP_TOKEN not in "".join(response.headers.values())
    if response.content_type.startswith("application/json"):
        return response, json.loads(response.body)
    return response, response.body


class Case(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.app, self.fake = make()


class MetaTests(Case):
    async def test_meta_has_everything_the_page_needs(self):
        res, body = await call(self.app, "/api/meta")
        self.assertEqual(res.status, 200)
        self.assertEqual(res.headers["Cache-Control"], "public, max-age=300")
        self.assertTrue(body["prices"])
        self.assertEqual(body["today"], "2026-10-26")
        self.assertEqual([o["code"] for o in body["origins"]], list(ORIGINS))
        self.assertTrue(all(o["name"] for o in body["origins"]))
        self.assertEqual(len(body["destinations"]), len(data.destinations()))
        first = body["destinations"][0]
        for key in ("iata", "name", "country", "cc", "flag", "tags", "visa", "en"):
            self.assertIn(key, first)
        for key in ("status", "label", "short", "level", "free"):
            self.assertIn(key, first["visa"])
        self.assertTrue({d["iata"] for d in body["destinations"]} >= set(body["popular"]))
        self.assertEqual(len(body["months"]), 12)
        self.assertEqual(body["months"][0]["key"], "2026-10")
        self.assertEqual(body["stays"], [3, 5, 7, 10, 14])
        self.assertEqual(body["links"], {"bot": "https://t.me/SafratiTravel_bot", "channel": ""})
        self.assertTrue(body["regions"] and body["tags"])
        self.assertRegex(body["visa_checked"], r"^\d{4}-\d{2}-\d{2}$")

    async def test_meta_shows_the_channel_when_one_is_set(self):
        app, _ = make(channel_url="https://t.me/deals_channel", bot_username="OtherBot_bot")
        _, body = await call(app, "/api/meta")
        self.assertEqual(body["links"], {"bot": "https://t.me/OtherBot_bot", "channel": "https://t.me/deals_channel"})

    async def test_no_price_token_means_prices_are_off_and_nothing_is_fetched(self):
        app, fake = make(token="")
        _, body = await call(app, "/api/meta")
        self.assertFalse(body["prices"])
        res, body = await call(app, "/api/cheap")
        self.assertEqual((res.status, body["error"]), (503, "busy"))
        self.assertEqual(fake.calls, [])

    async def test_unknown_paths_are_404_json(self):
        for path in ("/api/nothing", "/admin", "/.env", "/safrati/web/api.py", "/../etc/passwd", "/static/app.js", "/api/"):
            res, body = await call(self.app, path)
            self.assertEqual(res.status, 404, path)
            self.assertEqual(body["error"], "not_found")

    async def test_health_check_needs_no_provider(self):
        res, body = await call(self.app, "/healthz")
        self.assertEqual((res.status, body), (200, b"ok"))
        self.assertEqual(self.fake.calls, [])


class UnderstandTests(Case):
    async def kind(self, text: str, **extra) -> dict:
        res, body = await call(self.app, "/api/understand", q=text, **extra)
        self.assertEqual(res.status, 200, text)
        return body

    async def test_a_city_leads_to_its_page(self):
        body = await self.kind("دبي")
        self.assertEqual((body["kind"], body["dests"]), ("dest", ["DXB"]))

    async def test_month_stay_and_exact_dates_are_read(self):
        body = await self.kind("إسطنبول ديسمبر")
        self.assertEqual((body["kind"], body["dests"], body["month"]), ("dest", ["IST"], "2026-12"))
        body = await self.kind("القاهرة 5 أيام")
        self.assertEqual((body["dests"], body["stay"]), (["CAI"], 5))
        body = await self.kind("بانكوك 15 ديسمبر")
        self.assertEqual((body["dests"], body["depart"]), (["BKK"], "2026-12-15"))
        body = await self.kind("دبي ذهاب فقط 15 ديسمبر")
        self.assertTrue(body["one_way"])

    async def test_a_country_offers_its_cities(self):
        body = await self.kind("تركيا")
        self.assertEqual(body["kind"], "choices")
        self.assertEqual(set(body["dests"]), {"IST", "TZX", "AYT"})

    async def test_cheapest_and_weekend_requests_are_lists(self):
        self.assertEqual((await self.kind("أرخص رحلة"))["kind"], "cheap")
        weekend = await self.kind("ويكند")
        self.assertEqual((weekend["kind"], weekend["weekend"]), ("weekend", True))
        europe = await self.kind("اوروبا بميزانية 3000")
        self.assertEqual((europe["kind"], europe["regions"], europe["cap"]), ("cheap", ["europe"], 1200))

    async def test_a_bare_city_of_departure_changes_the_origin(self):
        body = await self.kind("من جده")
        self.assertEqual((body["kind"], body["origin"]), ("origin", "JED"))
        body = await self.kind("من جدة الى دبي")
        self.assertEqual((body["kind"], body["origin"], body["dests"]), ("dest", "JED", ["DXB"]))

    async def test_far_dates_come_with_the_same_explanation_as_the_bot(self):
        body = await self.kind("دبي 20 أكتوبر")
        self.assertEqual(body["problem"], api.PROBLEMS["far"])

    async def test_nonsense_is_none_and_typos_get_suggestions(self):
        self.assertEqual((await self.kind("xyz"))["kind"], "none")
        body = await self.kind("اسطنبل")
        self.assertIn(body["kind"], ("suggest", "dest"))

    async def test_the_examples_shown_on_the_home_page_all_lead_somewhere(self):
        script = (api.STATIC_DIR / "app.js").read_text(encoding="utf-8")
        found = re.search(r"const EXAMPLES = \[(.*?)\];", script, re.S)
        examples = re.findall(r"'([^']+)'", found.group(1))
        self.assertGreaterEqual(len(examples), 4)
        for text in examples:
            self.assertIn((await self.kind(text))["kind"], ("dest", "cheap", "weekend", "choices"), text)

    async def test_empty_and_huge_queries(self):
        for q in ("", "   "):
            res, body = await call(self.app, "/api/understand", q=q)
            self.assertEqual((res.status, body["error"]), (400, "query"))
        res, _ = await call(self.app, "/api/understand", q="دبي " * 500)
        self.assertEqual(res.status, 200)


class DestinationTests(Case):
    async def test_the_destination_page_data(self):
        res, body = await call(self.app, "/api/dest", d="IST", o="RUH")
        self.assertEqual(res.status, 200)
        self.assertEqual(res.headers["Cache-Control"], "private, max-age=120")
        self.assertEqual((body["origin"], body["origin_name"], body["dest"]["iata"], body["empty"]), ("RUH", "الرياض", "IST", False))
        prices = [t["price"] for t in body["top"]]
        self.assertEqual(prices, sorted(prices))
        self.assertEqual((len(prices), prices[0]), (api.TOP_DAYS, 1100))
        self.assertEqual(body["top"][0]["book"], "/go?o=RUH&d=IST&date=2026-12-12&ret=2026-12-19")
        self.assertEqual(body["default_month"], "2026-12")
        self.assertEqual(list(body["calendars"]), dts.month_choices(TODAY, api.OVERVIEW_MONTHS))
        self.assertEqual(body["bot"], "https://t.me/SafratiTravel_bot?start=d_IST")
        self.assertRegex(body["visa_checked"], r"^\d{4}-\d{2}-\d{2}$")
        self.assertTrue(body["visa_official"] == "" or body["visa_official"].startswith("https://"))

    async def test_verdict_compares_with_the_usual_price(self):
        _, body = await call(self.app, "/api/dest", d="IST", o="RUH")
        v = body["verdict"]
        self.assertIn(v["level"], api.VERDICT)
        self.assertGreater(v["samples"], 10)
        self.assertTrue(v["text"])

    async def test_month_bars_mark_the_cheapest_month(self):
        _, body = await call(self.app, "/api/dest", d="IST", o="RUH")
        bars = body["months"]
        self.assertEqual([b["key"] for b in bars], list(body["calendars"]))
        low = min(b["price"] for b in bars)
        self.assertTrue(all(b["best"] == (b["price"] == low) for b in bars))
        self.assertTrue(all(1 <= b["bar"] <= 5 for b in bars))

    async def test_calendars_have_future_days_in_a_sunday_first_grid(self):
        _, body = await call(self.app, "/api/dest", d="IST", o="RUH")
        october = body["calendars"]["2026-10"]
        self.assertTrue(all(d["d"] >= 27 for d in october["days"]))          # nothing before tomorrow
        december = body["calendars"]["2026-12"]
        self.assertEqual(december["label"], "ديسمبر 2026")
        weeks = december["weeks"]
        self.assertTrue(all(len(w) == 7 for w in weeks))
        numbers = [n for w in weeks for n, _ in w if n]
        self.assertEqual(numbers, list(range(1, 32)))
        self.assertEqual([n for n, _ in weeks[0]][:3], [0, 0, 1])               # 1 December 2026 is a Tuesday: Sunday first
        tiers = {d["t"] for d in december["days"]}
        self.assertTrue(tiers <= {"low", "mid", "high"} and "low" in tiers)
        cheapest = min(december["days"], key=lambda d: d["p"])
        self.assertEqual((cheapest["d"], cheapest["t"]), (12, "low"))
        self.assertEqual(december["best"], {"date": "2026-12-12", "price": 1100})

    async def test_services_have_no_emoji_and_point_at_our_own_redirect(self):
        _, body = await call(self.app, "/api/dest", d="IST", o="RUH")
        self.assertEqual(body["services"], [{"id": "esim", "label": "إنترنت للسفر eSIM — Airalo", "go": "/go?svc=esim"}])

    async def test_a_trip_length_without_tickets_falls_back_with_a_note(self):
        _, body = await call(self.app, "/api/dest", d="IST", o="RUH", stay=5)
        self.assertIn("5 أيام", body["note"])
        self.assertTrue(body["top"])
        _, body = await call(self.app, "/api/dest", d="IST", o="RUH", stay=7)
        self.assertEqual(body["note"], "")
        self.assertTrue(all(t["stay"] == 7 for t in body["top"]))

    async def test_weekend_trips_leave_on_thursday_and_come_back_two_days_later(self):
        self.fake.weekend_deals.add(("RUH", "IST"))
        _, body = await call(self.app, "/api/dest", d="IST", o="RUH", weekend=1)
        self.assertTrue(body["weekend"])
        self.assertEqual(body["note"], "")
        for t in body["top"]:
            self.assertEqual(date.fromisoformat(t["date"]).weekday(), 3)
            self.assertEqual(t["stay"], 2)

    async def test_weekend_without_tickets_falls_back_to_any_stay(self):
        self.fake.stays = (7,)                              # week-long trips only: none of them is a weekend
        _, body = await call(self.app, "/api/dest", d="IST", o="RUH", weekend=1)
        self.assertEqual(body["note"], api.NOTE_WEEKEND_MISS)
        self.assertTrue(body["top"])

    async def test_a_route_without_any_price_is_empty_not_an_error(self):
        res, body = await call(self.app, "/api/dest", d="LON", o="JED")
        self.assertEqual(res.status, 200)
        self.assertTrue(body["empty"])
        self.assertEqual((body["top"], body["months"], body["services"], body["verdict"]), ([], [], [], None))

    async def test_bad_parameters_are_400(self):
        for query in ({"d": "IST", "o": "XXX"}, {"d": "ZZZ"}, {"d": ""}, {"d": "IST", "stay": "abc"}, {"d": "IST", "stay": "1"},
                      {"d": "IST", "stay": "31"}, {"d": "IST", "stay": "-5"}, {}):
            res, body = await call(self.app, "/api/dest", **query)
            self.assertEqual(res.status, 400, query)
            self.assertFalse(body["ok"])
        self.assertEqual(self.fake.calls, [])                       # nothing was fetched for a bad request

    async def test_lowercase_codes_are_accepted(self):
        res, body = await call(self.app, "/api/dest", d="ist", o="ruh")
        self.assertEqual((res.status, body["dest"]["iata"]), (200, "IST"))


class CalendarTests(Case):
    async def test_a_month_beyond_the_first_six(self):
        res, body = await call(self.app, "/api/calendar", d="IST", o="RUH", m="2027-06")
        self.assertEqual(res.status, 200)
        self.assertEqual((body["label"], body["name"]), ("يونيو 2027", "يونيو"))
        self.assertEqual(len(body["days"]), 28)
        self.assertEqual(body["best"], {"date": "2027-06-12", "price": 1100})

    async def test_month_is_required_and_must_be_in_range(self):
        for m in ("", "2026-1", "2026-13", "junk", "2020-01", "2030-01", "2026-09", "2027-10"):
            res, body = await call(self.app, "/api/calendar", d="IST", o="RUH", m=m)
            self.assertEqual((res.status, body["ok"]), (400, False), m)

    async def test_the_last_month_offered_is_allowed(self):
        last = dts.month_choices(TODAY, api.CALENDAR_MONTHS)[-1]
        res, _ = await call(self.app, "/api/calendar", d="IST", o="RUH", m=last)
        self.assertEqual(res.status, 200)


class DayTests(Case):
    async def test_an_exact_round_trip(self):
        res, body = await call(self.app, "/api/day", d="IST", o="RUH", date="2026-12-12", ret="2026-12-19")
        self.assertEqual(res.status, 200)
        self.assertTrue(body["exact"])
        self.assertEqual(body["note"], "")
        offer = body["offers"][0]
        self.assertEqual((offer["date"], offer["ret"], offer["price"], offer["stay"]), ("2026-12-12", "2026-12-19", 1130, 7))   # the exact lookup costs 30 more in the fake
        self.assertEqual(body["live"], "/go?o=RUH&d=IST&date=2026-12-12&ret=2026-12-19&live=1")
        self.assertEqual(body["bot"], "https://t.me/SafratiTravel_bot?start=d_IST_20261212_20261219")

    async def test_one_way(self):
        _, body = await call(self.app, "/api/day", d="IST", o="RUH", date="2026-12-12", one_way=1)
        self.assertEqual(body["offers"][0]["ret"], "")
        self.assertTrue(body["bot"].endswith("d_IST_20261212_o"))
        self.assertNotIn("&ret=", body["live"])

    async def test_a_cheaper_nearby_day_is_suggested_only_when_it_saves_enough(self):
        self.fake.exact_extra = 400
        _, body = await call(self.app, "/api/day", d="IST", o="RUH", date="2026-12-15", ret="2026-12-22")
        hint = body["hint"]
        self.assertEqual((hint["date"], hint["saving"]), ("2026-12-12", 430))
        self.fake.exact_extra = 0
        app, _ = make()
        _, body = await call(app, "/api/day", d="IST", o="RUH", date="2026-12-12", ret="2026-12-19")
        self.assertIsNone(body["hint"])

    async def test_when_the_exact_day_is_unknown_the_nearest_days_are_shown(self):
        self.fake.exact_missing.add("2026-12-12")
        _, body = await call(self.app, "/api/day", d="IST", o="RUH", date="2026-12-12", ret="2026-12-19")
        self.assertFalse(body["exact"])
        self.assertEqual(body["note"], api.NOTE_ROUND_MISS)
        self.assertTrue(body["offers"])
        self.assertLessEqual(len(body["offers"]), api.DATE_ROWS)

    async def test_bad_dates_are_400_with_a_reason(self):
        cases = [
            ({"date": "2026-10-20"}, api.PROBLEMS["past"]),
            ({"date": "2030-01-01"}, api.PROBLEMS["far"]),
            ({"date": "2026-12-12", "ret": "2026-12-12"}, "تاريخ العودة لازم يكون بعد الذهاب"),
            ({"date": "2026-12-12", "ret": "2026-12-10"}, "تاريخ العودة لازم يكون بعد الذهاب"),
            ({"date": "2026-02-30"}, "التاريخ غير صحيح"),
            ({"date": "12/12/2026"}, "التاريخ غير صحيح"),
            ({"date": "2026-12-12", "ret": "soon"}, "التاريخ غير صحيح"),
            ({}, "التاريخ مطلوب"),
        ]
        for query, message in cases:
            res, body = await call(self.app, "/api/day", d="IST", o="RUH", **query)
            self.assertEqual((res.status, body["message"]), (400, message), query)
        self.assertEqual(self.fake.calls, [])


class ListTests(Case):
    async def test_cheapest_places_from_a_city(self):
        res, body = await call(self.app, "/api/cheap", o="RUH")
        self.assertEqual(res.status, 200)
        items = body["items"]
        prices = [i["price"] for i in items]
        self.assertEqual(prices, sorted(prices))
        self.assertEqual(len(items), api.LIST_SIZE)
        self.assertEqual((items[0]["iata"], items[0]["price"]), ("DXB", 700))
        for key in ("name", "country", "flag", "visa", "date", "ret"):
            self.assertIn(key, items[0])
        self.assertEqual((body["cap"], body["over"]), (0, False))

    async def test_each_city_of_departure_has_its_own_prices(self):
        _, body = await call(self.app, "/api/cheap", o="JED")
        self.assertEqual({i["iata"] for i in body["items"]}, {"IST", "DXB", "CAI", "BKK"})
        self.assertEqual(body["origin_name"], "جدة")

    async def test_filters(self):
        _, body = await call(self.app, "/api/cheap", o="RUH", region="europe")
        self.assertEqual({i["iata"] for i in body["items"]}, {"SJJ", "PAR", "LON", "ZRH"})
        _, body = await call(self.app, "/api/cheap", o="RUH", tag="beach")
        self.assertEqual({i["iata"] for i in body["items"]}, {"AYT", "MLE"})
        _, body = await call(self.app, "/api/cheap", o="RUH", visa=1)
        self.assertTrue(body["items"] and all(i["visa"]["free"] for i in body["items"]))
        self.assertNotIn("MLE", {i["iata"] for i in body["items"]})

    async def test_a_price_limit_and_the_honest_fallback(self):
        _, body = await call(self.app, "/api/cheap", o="RUH", max=1000)
        self.assertEqual(([i["iata"] for i in body["items"]], body["over"], body["cap"]), (["DXB", "AMM", "CAI", "BEY", "TBS"], False, 1000))
        _, body = await call(self.app, "/api/cheap", o="RUH", max=100)
        self.assertTrue(body["over"])
        self.assertEqual(len(body["items"]), api.LIST_SIZE)               # the cheapest are shown anyway, and the page says so

    async def test_one_month_only(self):
        _, body = await call(self.app, "/api/cheap", o="RUH", m="2026-11")
        self.assertTrue(body["items"])
        self.assertTrue(all(i["date"].startswith("2026-11") for i in body["items"]))

    async def test_bad_filters_are_400(self):
        for query in ({"max": "99"}, {"max": "1000001"}, {"max": "abc"}, {"max": "-5"}, {"region": "mars"}, {"tag": "mars"}, {"o": "XXX"}, {"m": "2026-1"}, {"m": "2031-01"}):
            res, body = await call(self.app, "/api/cheap", **query)
            self.assertEqual((res.status, body["ok"]), (400, False), query)

    async def test_weekend_list(self):
        self.fake.weekend_deals.update({("RUH", "DXB"), ("RUH", "CAI")})
        res, body = await call(self.app, "/api/weekend", o="RUH")
        self.assertEqual(res.status, 200)
        self.assertFalse(body["pending"])
        self.assertEqual([i["iata"] for i in body["items"]][:2], ["DXB", "CAI"])
        for i in body["items"]:
            self.assertGreater(date.fromisoformat(i["ret"]), date.fromisoformat(i["date"]))
        self.assertEqual(res.headers["Cache-Control"], "private, max-age=120")

    async def test_weekend_list_that_is_still_loading_says_so_and_is_not_cached(self):
        with mock.patch.object(self.app.tp, "weekend_deals", side_effect=TPError("still loading")):
            res, body = await call(self.app, "/api/weekend", o="RUH")
        self.assertEqual((res.status, body["pending"], body["items"]), (200, True, []))
        self.assertEqual(res.headers["Cache-Control"], "no-store")

    async def test_other_weekend_errors_are_not_hidden(self):
        with mock.patch.object(self.app.tp, "weekend_deals", side_effect=TPError("provider down")):
            res, body = await call(self.app, "/api/weekend", o="RUH")
        self.assertEqual((res.status, body["error"]), (503, "busy"))


class FailureTests(Case):
    async def test_a_provider_failure_is_a_polite_503_with_retry_after(self):
        self.fake.status = 500
        for path, query in (("/api/cheap", {}), ("/api/dest", {"d": "IST"}), ("/api/day", {"d": "IST", "date": "2026-12-12"}),
                            ("/api/calendar", {"d": "IST", "m": "2026-12"})):
            res, body = await call(self.app, path, **query)
            self.assertEqual(res.status, 503, path)
            self.assertEqual(body["error"], "busy")
            self.assertEqual(res.headers["Retry-After"], "10")
            self.assertNotIn("500", body["message"])
            self.assertNotIn("boom", body["message"])

    async def test_too_many_lookups_at_once_are_told_to_retry(self):
        with mock.patch.object(api, "GATE", 1), mock.patch.object(api, "GATE_WAIT", 0.05):
            app, _ = make()
            await app._gate.acquire()
            res, body = await call(app, "/api/cheap")
            self.assertEqual((res.status, body["error"], res.headers["Retry-After"]), (503, "busy", "5"))
            app._gate.release()
            self.assertEqual((await call(app, "/api/cheap"))[0].status, 200)

    async def test_a_crowd_asking_the_same_thing_costs_the_provider_almost_nothing(self):
        results = await asyncio.gather(*[call(self.app, "/api/cheap", o="RUH") for _ in range(40)])
        self.assertEqual({r.status for r, _ in results}, {200})
        self.assertLessEqual(len(self.fake.price_calls()), 3)
        results = await asyncio.gather(*[call(self.app, "/api/dest", d="IST", o="RUH") for _ in range(40)])
        self.assertEqual({r.status for r, _ in results}, {200})
        self.assertLessEqual(len(self.fake.price_calls()), 9)


class RedirectTests(Case):
    async def test_a_flight_goes_to_the_partner_link_with_nothing_remembered(self):
        res, _ = await call(self.app, "/go", o="RUH", d="IST", date="2026-12-12", ret="2026-12-19")
        self.assertEqual(res.status, 302)
        location = res.headers["Location"]
        self.assertTrue(location.startswith("https://tp.media/r?marker=123456&trs=654321"))
        self.assertEqual(res.headers["Cache-Control"], "no-store")
        self.assertEqual(res.headers["Referrer-Policy"], "no-referrer")

    async def test_live_search_does_not_look_prices_up_first(self):
        res, _ = await call(self.app, "/go", o="RUH", d="IST", date="2026-12-12", live=1)
        self.assertEqual(res.status, 302)
        self.assertEqual(self.fake.price_calls(), [])
        self.assertIn("aviasales.com", res.headers["Location"])

    async def test_when_partner_links_fail_the_plain_search_with_our_marker_is_used(self):
        self.fake.links_http = (500, {})
        res, _ = await call(self.app, "/go", o="RUH", d="IST", date="2026-12-12", ret="2026-12-19", live=1)
        self.assertEqual(res.status, 302)
        location = res.headers["Location"]
        self.assertTrue(location.startswith("https://www.aviasales.com/search/"))
        self.assertIn("marker=123456", location)

    async def test_a_link_to_a_stranger_is_never_followed(self):
        with mock.patch.object(self.app.tp, "booking_url", return_value="https://evil.example/phish"):
            res, _ = await call(self.app, "/go", o="RUH", d="IST", date="2026-12-12", ret="2026-12-19")
        self.assertEqual(res.status, 302)
        self.assertNotIn("evil", res.headers["Location"])
        self.assertIn("aviasales.com", res.headers["Location"])
        with mock.patch.object(self.app.tp, "partner_links", return_value={}):
            res, _ = await call(self.app, "/go", svc="esim")
        self.assertEqual(res.status, 404)

    def test_only_https_links_to_the_partners_are_allowed(self):
        ok = ["https://tp.media/r?x=1", "https://www.aviasales.com/search/x", "https://sub.travelpayouts.com/a", "https://TP.MEDIA/x",
              "https://www.airalo.com/", "https://www.tiqets.com/x", "https://gettransfer.com/x"]
        bad = ["http://tp.media/r", "https://evil.com/tp.media", "https://tp.media.evil.com/", "https://eviltp.media/", "javascript:alert(1)",
               "//tp.media/x", "https://evil.com@evil.org/", "ftp://tp.media/x", "", "tp.media", "data:text/html,x"]
        for url in ok:
            self.assertTrue(WebApp._allowed(url), url)
        for url in bad:
            self.assertFalse(WebApp._allowed(url), url)

    async def test_extra_services(self):
        res, _ = await call(self.app, "/go", svc="esim")
        self.assertEqual(res.status, 302)
        self.assertIn("airalo.com", res.headers["Location"])
        for svc in ("nothing", "../x", "esim%00"):
            res, _ = await call(self.app, "/go", svc=svc)
            self.assertEqual(res.status, 404, svc)
        app, fake = make()
        fake.link_error = "unsupported domain"
        res, _ = await call(app, "/go", svc="esim")
        self.assertEqual(res.status, 404)

    async def test_bad_requests_never_redirect(self):
        cases = [
            {"o": "RUH", "d": "ZZZ", "date": "2026-12-12"},
            {"o": "XXX", "d": "IST", "date": "2026-12-12"},
            {"o": "RUH", "d": "IST"},
            {"o": "RUH", "d": "IST", "date": "2026-10-20"},
            {"o": "RUH", "d": "IST", "date": "2026-12-12", "ret": "2026-12-01"},
            {"o": "RUH", "d": "IST", "date": "nonsense"},
        ]
        for query in cases:
            res, body = await call(self.app, "/go", **query)
            self.assertEqual(res.status, 400, query)
            self.assertNotIn("Location", res.headers)


class ConstantsTests(unittest.TestCase):
    def test_the_website_uses_the_same_rules_as_the_bot(self):
        from safrati import app as bot
        from safrati import trip, ui
        self.assertEqual(api.HORIZON_SHIFT, bot.HORIZON_SHIFT)
        self.assertEqual(api.WEEKEND_MONTHS, bot.WEEKEND_MONTHS)
        self.assertEqual(api.TRIP_SHARE, bot.TRIP_SHARE)
        self.assertEqual(api.POPULAR, bot.POPULAR)
        self.assertEqual(api.OVERVIEW_MONTHS, trip.OVERVIEW_MONTHS)
        self.assertEqual(api.CALENDAR_MONTHS, trip.CALENDAR_MONTHS)
        self.assertEqual(api.HINT_MIN_SAVING, trip.HINT_MIN_SAVING)
        self.assertEqual(api.HINT_MIN_SHARE, trip.HINT_MIN_SHARE)
        self.assertEqual(api.DATE_ROWS, ui.DATE_ROWS)
        self.assertEqual(api.STAYS, ui.STAYS)

    def test_every_visa_status_has_a_label_and_the_texts_exist(self):
        statuses = {info.status for info in (data.visa_for(d.cc) for d in data.destinations()) if info}
        self.assertTrue(statuses <= set(api.VISA), statuses - set(api.VISA))
        for key in ("great", "good", "typical", "high"):
            self.assertIn(key, api.VERDICT)
        self.assertTrue(set(texts.REGION_LABELS) and set(texts.TAG_NAMES))


if __name__ == "__main__":
    unittest.main()
