import re
from pathlib import Path

from istiraha import security, util
from tests.helpers import NOW, Case, Client, fake_jpeg, fake_png


class AccountTests(Case):
    async def test_registration_rules(self):
        c = Client(self.app)
        await c.get("/owner/register")
        bad = [({"name": "", "phone": "0551234567", "password": "Owner-pass-1"}, "اكتب اسمك"),
               ({"name": "أبو سعد", "phone": "12345", "password": "Owner-pass-1"}, "رقم جوال سعودي"),
               ({"name": "أبو سعد", "phone": "0551234567", "password": "123"}, "قصيرة"),
               ({"name": "أبو سعد", "phone": "0551234567", "password": "12345678"}, "ضعيفة")]
        for form, word in bad:
            r = await c.post("/owner/register", {**form, "website": ""})
            self.assertEqual(r.status, 200, form)
            self.assertIn(word, c.text)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM users")["n"], 0)
        r = await c.post("/owner/register", {"name": "أبو سعد", "phone": "٠٥٥١٢٣٤٥٦٧", "password": "Owner-pass-1", "website": ""})
        self.assertEqual((r.status, r.headers["Location"]), (303, "/owner/new"))
        user = self.db.one("SELECT * FROM users")
        self.assertEqual((user["role"], user["login"]), ("owner", "966551234567"))
        self.assertNotIn("Owner-pass-1", user["pass_hash"])
        cookie = [x for x in r.cookies if x.startswith("ist_o=")][0]
        for flag in ("HttpOnly", "Secure", "SameSite=Lax", "Path=/"):
            self.assertIn(flag, cookie)

    async def test_the_same_number_cannot_register_twice(self):
        await self.make_owner()
        c = Client(self.app, "203.0.113.99")
        await c.get("/owner/register")
        await c.post("/owner/register", {"name": "آخر", "phone": "+966551234567", "password": "Owner-pass-2", "website": ""})
        self.assertIn("مسجل من قبل", c.text)

    async def test_robots_that_fill_the_hidden_field_are_turned_away(self):
        c = Client(self.app)
        await c.get("/owner/register")
        r = await c.post("/owner/register", {"name": "روبوت", "phone": "0551234567", "password": "Owner-pass-1", "website": "http://spam"})
        self.assertEqual(r.headers["Location"], "/")
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM users")["n"], 0)

    async def test_registration_is_rate_limited(self):
        c = Client(self.app, "203.0.113.77")
        await c.get("/owner/register")
        for i in range(self.app.settings.register_per_hour):
            await c.post("/owner/register", {"name": "أبو سعد", "phone": f"05500000{i:02d}", "password": "Owner-pass-1", "website": ""}, page="/owner/register")
            c.jar.pop("ist_o", None)
        await c.post("/owner/register", {"name": "أبو سعد", "phone": "0559999999", "password": "Owner-pass-1", "website": ""}, page="/owner/register")
        self.assertIn("محاولات كثيرة", c.text)

    async def test_login_and_logout(self):
        await self.make_owner()
        c = Client(self.app, "203.0.113.60")
        r = await c.go("GET", "/owner")
        self.assertEqual((r.status, r.headers["Location"]), (303, "/owner/login?next=/owner"))
        await c.get("/owner/login")
        await c.post("/owner/login", {"phone": "0551234567", "password": "wrong-pass-1"})
        self.assertIn("بيانات الدخول غير صحيحة", c.text)
        r = await c.post("/owner/login", {"phone": "0551234567", "password": "Owner-pass-1", "next": "/owner/new"})
        self.assertEqual((r.status, r.headers["Location"]), (303, "/owner/new"))
        c.jar.pop("ist_o")
        r = await c.post("/owner/login", {"phone": "0551234567", "password": "Owner-pass-1", "next": "https://evil.example"}, page="/owner/login")
        self.assertEqual(r.headers["Location"], "/owner")                                   # never sent to another site
        self.assertEqual((await c.get("/owner")).status, 200)
        before = self.db.one("SELECT COUNT(*) AS n FROM sessions")["n"]
        await c.post("/owner/logout", page="/owner")
        self.assertEqual((await c.get("/owner")).status, 303)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM sessions")["n"], before - 1)

    async def test_five_wrong_passwords_lock_the_account_for_a_while(self):
        await self.make_owner()
        c = Client(self.app, "203.0.113.61")
        await c.get("/owner/login")
        for _ in range(5):
            await c.post("/owner/login", {"phone": "0551234567", "password": "wrong-pass-1"})
        await c.post("/owner/login", {"phone": "0551234567", "password": "Owner-pass-1"})
        self.assertIn("مقفل", c.text)
        self.clock.t += 16 * 60
        r = await c.post("/owner/login", {"phone": "0551234567", "password": "Owner-pass-1"})
        self.assertEqual(r.status, 303)

    async def test_login_attempts_from_one_address_are_limited(self):
        c = Client(self.app, "203.0.113.62")
        await c.get("/owner/login")
        for _ in range(self.app.settings.login_per_minute):
            await c.post("/owner/login", {"phone": "0550000000", "password": "x" * 9})
        await c.post("/owner/login", {"phone": "0550000000", "password": "x" * 9})
        self.assertIn("محاولات كثيرة", c.text)

    async def test_an_unknown_number_and_a_wrong_password_look_the_same(self):
        await self.make_owner()
        c = Client(self.app, "203.0.113.63")
        await c.get("/owner/login")
        await c.post("/owner/login", {"phone": "0558888888", "password": "wrong-pass-1"})
        a = re.search(r'class="note bad"[^>]*>([^<]+)', c.text).group(1)
        await c.post("/owner/login", {"phone": "0551234567", "password": "wrong-pass-1"})
        b = re.search(r'class="note bad"[^>]*>([^<]+)', c.text).group(1)
        self.assertEqual(a, b)

    async def test_sessions_expire(self):
        owner = await self.make_owner()
        self.assertEqual((await owner.get("/owner")).status, 200)
        self.clock.t += 31 * 86400
        self.assertEqual((await owner.get("/owner")).status, 303)


class PledgeTests(Case):
    async def test_the_pledge_page_shows_the_rate_the_example_and_the_text(self):
        owner = await self.make_owner()
        await owner.get("/owner/new")
        html = owner.text
        self.assertIn("نسبة العمولة الحالية", html)
        self.assertIn("10%", html)
        self.assertIn("وقيمة الإيجار 500 ريال، فالعمولة المستحقة 50 ريال", html)
        self.assertIn("أتعهد وأوافق على شروط استخدام المنصة", html)
        self.assertIn("أتعهد وأوافق وأضيف استراحتي", html)

    async def test_the_form_cannot_be_reached_without_agreeing(self):
        owner = await self.make_owner()
        for path in ("/owner/consent/1", "/owner/consent/999"):
            r = await owner.get(path)
            self.assertEqual((r.status, r.headers["Location"]), (303, "/owner/new"))
        await owner.get("/owner/new")
        r = await owner.post("/owner/new", {"version": "1", "bp": "1000"})                 # the box is not ticked
        self.assertEqual(r.status, 400)
        self.assertIn("لازم تحدد الموافقة", owner.text)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM consents")["n"], 0)
        r = await owner.post("/owner/listing/1/edit", {"title": "x"})                          # nor can an advert be created some other way
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM listings")["n"], 0)

    async def test_the_agreement_is_saved_with_everything_that_was_shown(self):
        owner = await self.make_owner()
        await owner.get("/owner/new")
        r = await owner.post("/owner/new", {"agree": "1", "version": "1", "bp": "1000"})
        self.assertEqual(r.status, 303)
        c = self.db.one("SELECT * FROM consents")
        self.assertEqual((c["basis_points"], c["pledge_version"], c["accepted_at"]), (1000, 1, NOW))
        self.assertIn("أتعهد وأوافق على شروط استخدام المنصة", c["pledge_text"])
        self.assertEqual(c["owner_id"], self.db.one("SELECT id FROM users")["id"])
        self.assertTrue(c["ip_fingerprint"] and "203.0.113" not in c["ip_fingerprint"])
        self.assertEqual(c["user_agent"], "test-browser")
        lid = await self.add_listing(owner)
        self.assertEqual(self.db.one("SELECT consent_id FROM listings WHERE id = ?", (lid,))["consent_id"], 2)
        self.assertEqual(self.db.one("SELECT listing_id FROM consents WHERE id = 2")["listing_id"], lid)

    async def test_an_agreement_for_an_old_page_is_refused_when_the_rate_changed_meanwhile(self):
        owner = await self.make_owner()
        admin = await self.make_admin()
        await owner.get("/owner/new")
        token = owner.csrf()
        await admin.post("/admin/commission", {"percent": "20"}, page="/admin/commission")
        r = await owner.go("POST", "/owner/new", {"agree": "1", "version": "1", "bp": "1000", "_csrf": token})
        self.assertEqual(r.status, 400)
        self.assertIn("تغيّرت نسبة العمولة", owner.text)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM consents")["n"], 0)
        self.assertIn("20%", owner.text)

    async def test_each_new_advert_needs_its_own_agreement(self):
        owner = await self.make_owner()
        await self.add_listing(owner, "الأولى")
        await self.add_listing(owner, "الثانية")
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM consents")["n"], 2)
        ids = {r["consent_id"] for r in self.db.all("SELECT consent_id FROM listings")}
        self.assertEqual(len(ids), 2)
        r = await owner.get("/owner/consent/1")                                                 # one agreement opens one advert only
        self.assertEqual(r.status, 303)

    async def test_nobody_can_use_another_owner_s_agreement(self):
        a = await self.make_owner("0551111111", ip="203.0.113.11")
        b = await self.make_owner("0552222222", ip="203.0.113.12")
        await a.get("/owner/new")
        await a.post("/owner/new", {"agree": "1", "version": "1", "bp": "1000"})
        cid = int(re.search(r"/consent/(\d+)", a.location).group(1))
        r = await b.get(f"/owner/consent/{cid}")
        self.assertEqual(r.status, 303)
        r = await b.post(f"/owner/consent/{cid}", {"title": "x"}, page="/owner")
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM listings")["n"], 0)


class ListingFormTests(Case):
    async def open_form(self, owner):
        await owner.get("/owner/new")
        await owner.post("/owner/new", {"agree": "1", "version": "1", "bp": str(self.db.commission_bp())})
        action = owner.location
        await owner.get(action)
        return action

    async def test_validation_messages(self):
        owner = await self.make_owner()
        action = await self.open_form(owner)
        base = {"title": "استراحة جميلة", "city": "1", "category": "1", "price": "500", "unit": "night", "whatsapp": "0551234567"}
        cases = [({"title": "ab"}, "اسم الاستراحة"), ({"city": ""}, "اختر المدينة"), ({"category": "999"}, "اختر نوع"), ({"price": "0"}, "سعر الإيجار"),
                 ({"price": "abc"}, "سعر الإيجار"), ({"unit": "year"}, "اختر مدة"), ({"whatsapp": "0112345678"}, "رقم جوال سعودي"),
                 ({"map_url": "http://evil.example/x"}, "رابط خرائط"), ({"map_url": "https://evil.example/maps"}, "رابط خرائط"), ({"capacity": "-3"}, "عدد الأشخاص"),
                 ({"description": "ا" * 2001}, "الوصف طويل")]
        for change, word in cases:
            r = await owner.post(action, {**base, **change})
            self.assertEqual(r.status, 400, change)
            self.assertIn(word, owner.text, change)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM listings")["n"], 0)
        r = await owner.post(action, {**base, "map_url": "https://maps.app.goo.gl/abc123", "capacity": "30"})
        self.assertEqual(r.status, 303)
        row = self.db.one("SELECT * FROM listings")
        self.assertEqual((row["review"], row["whatsapp"], row["capacity"], row["price"]), ("pending", "966551234567", 30, 500))

    async def test_the_values_typed_before_a_mistake_stay_in_the_form(self):
        owner = await self.make_owner()
        action = await self.open_form(owner)
        await owner.post(action, {"title": "استراحة الوادي", "city": "2", "category": "1", "price": "", "unit": "week", "whatsapp": "0551234567", "amenities": ["1", "2"]})
        self.assertIn('value="استراحة الوادي"', owner.text)
        self.assertRegex(owner.text, r'<option value="2" selected>')
        self.assertRegex(owner.text, r'name="amenities" value="1" checked')

    async def test_numbers_typed_on_a_phone_are_understood(self):
        """What an iPhone with an Arabic keyboard really sends: Arabic digits, a unit word, invisible direction marks around the text."""
        owner = await self.make_owner()
        action = await self.open_form(owner)
        base = {"title": "استراحة الغدير", "city": "1", "category": "1", "unit": "night"}
        form = {**base, "price": "\u200f٣٠٠ ريال\u200e", "capacity": "١٠ أشخاص", "whatsapp": "\u200f٠٥٥١٢٣٤٥٦٧\u200e",
                "map_url": "موقع الاستراحة \u200ehttps://maps.app.goo.gl/abc123"}
        r = await owner.post(action, form)
        self.assertEqual(r.status, 303, owner.text[:400])
        row = self.db.one("SELECT * FROM listings")
        self.assertEqual((row["price"], row["capacity"], row["whatsapp"], row["map_url"]), (300, 10, "966551234567", "https://maps.app.goo.gl/abc123"))
        for price, capacity in (("300 ر.س", "10 اشخاص"), ("300.00", "10"), ("1,500", "")):
            r = await owner.post(await self.open_form(owner), {**base, "price": price, "capacity": capacity, "whatsapp": "0551234567"})
            self.assertEqual(r.status, 303, (price, capacity))
        self.assertEqual([x["price"] for x in self.db.all("SELECT price FROM listings ORDER BY id")], [300, 300, 300, 1500])

    async def test_a_refused_value_stays_in_the_box_and_the_message_says_what_to_write(self):
        owner = await self.make_owner()
        action = await self.open_form(owner)
        form = {"title": "استراحة الوادي", "city": "1", "category": "1", "unit": "night", "price": "3 آلاف", "capacity": "عشرة",
                "whatsapp": "055", "map_url": "http://x.example/a"}
        r = await owner.post(action, form)
        self.assertEqual(r.status, 400)
        for typed in ("3 آلاف", "عشرة", "055", "http://x.example/a"):
            self.assertIn(f'value="{typed}"', owner.text)                           # the box shows what was typed, not an empty field
        self.assertIn("بالأرقام فقط، مثل 800", owner.text)
        self.assertIn("بالأرقام فقط، مثل 20", owner.text)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM listings")["n"], 0)       # "3 آلاف" is never guessed as 3 riyals
        r = await owner.post(action, {**form, "price": "3000", "capacity": "20", "whatsapp": "0551234567", "map_url": ""})
        self.assertEqual(r.status, 303)
        self.assertEqual(self.db.one("SELECT price, capacity FROM listings")["price"], 3000)

    async def test_editing_the_price_keeps_it_published_but_editing_the_text_sends_it_back(self):
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        self.approve(lid)
        row = self.db.one("SELECT * FROM listings WHERE id = ?", (lid,))
        form = {"title": row["title"], "city": str(row["city_id"]), "category": str(row["category_id"]), "price": "950", "unit": "night",
                "whatsapp": "0551234567", "district": row["district"], "description": row["description"], "amenities": ["1", "2"]}
        r = await owner.post(f"/owner/listing/{lid}/edit", form, page=f"/owner/listing/{lid}/edit")
        self.assertEqual(r.status, 303)
        row = self.db.one("SELECT * FROM listings WHERE id = ?", (lid,))
        self.assertEqual((row["price"], row["review"]), (950, "approved"))
        await owner.post(f"/owner/listing/{lid}/edit", {**form, "description": "وصف جديد"}, page=f"/owner/listing/{lid}/edit")
        self.assertEqual(self.db.one("SELECT review FROM listings WHERE id = ?", (lid,))["review"], "pending")
        self.assertEqual((await self.visitor.get(f"/r/{lid}")).status, 404)

    async def test_a_stopped_advert_cannot_be_put_back_by_editing(self):
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        self.db.run("UPDATE listings SET review = 'stopped', review_note = 'مخالفة' WHERE id = ?", (lid,))
        row = self.db.one("SELECT * FROM listings WHERE id = ?", (lid,))
        form = {"title": "عنوان جديد للإعلان", "city": str(row["city_id"]), "category": str(row["category_id"]), "price": "700", "unit": "night", "whatsapp": "0551234567"}
        await owner.post(f"/owner/listing/{lid}/edit", form, page=f"/owner/listing/{lid}/edit")
        self.assertEqual(self.db.one("SELECT review FROM listings WHERE id = ?", (lid,))["review"], "stopped")

    async def test_pause_and_resume_are_the_owner_s_to_use_only_on_a_published_advert(self):
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        await owner.get(f"/owner/listing/{lid}")
        self.assertNotIn("إيقاف الإعلان مؤقتًا", owner.text)                              # still waiting for review
        self.approve(lid)
        await owner.get(f"/owner/listing/{lid}")
        self.assertIn("إيقاف الإعلان مؤقتًا", owner.text)
        await owner.post(f"/owner/listing/{lid}/pause")
        await owner.get(f"/owner/listing/{lid}")
        self.assertIn("إعادة تفعيل الإعلان", owner.text)


class IsolationTests(Case):
    async def test_an_owner_sees_and_touches_only_his_own_adverts(self):
        a = await self.make_owner("0551111111", ip="203.0.113.11")
        b = await self.make_owner("0552222222", ip="203.0.113.12")
        lid = await self.add_listing(a, "إعلان أ")
        await self.add_listing(b, "إعلان ب")
        await b.get("/owner")
        self.assertIn("إعلان ب", b.text)
        self.assertNotIn("إعلان أ", b.text)
        for path in (f"/owner/listing/{lid}", f"/owner/listing/{lid}/edit", f"/owner/listing/{lid}/reconsent"):
            self.assertEqual((await b.get(path)).status, 404, path)
        for action in ("pause", "resume", "edit", "block", "photo"):
            await b.get("/owner")
            r = await b.post(f"/owner/listing/{lid}/{action}", {"title": "اختراق", "start": "2026-12-01", "end": "2026-12-02"})
            self.assertEqual(r.status, 404, action)
        row = self.db.one("SELECT title, owner_active FROM listings WHERE id = ?", (lid,))
        self.assertEqual((row["title"], row["owner_active"]), ("إعلان أ", 1))
        self.assertEqual((await b.get(f"/r/{lid}")).status, 404)                       # not even the preview of someone else's pending advert

    async def test_owners_cannot_enter_the_admin_area(self):
        owner = await self.make_owner()
        for path in ("/admin", "/admin/commission", "/admin/owners", "/admin/listings", "/admin/rentals", "/admin/settings", "/admin/offers"):
            r = await owner.get(path)
            self.assertEqual((r.status, r.headers["Location"]), (303, "/admin/login"), path)
        # an owner's cookie, even sent to the admin pages, is not an admin session
        owner.jar["ist_a"] = owner.jar["ist_o"]
        self.assertEqual((await owner.get("/admin")).status, 303)
        await owner.get("/owner")
        r = await owner.post("/admin/commission", {"percent": "1"})
        self.assertNotEqual(r.status, 200)
        self.assertEqual(self.db.commission_bp(), 1000)

    async def test_an_admin_login_is_not_an_owner_login(self):
        admin = await self.make_admin()
        self.assertEqual((await admin.get("/owner")).status, 303)
        c = Client(self.app, "203.0.113.64")
        await c.get("/owner/login")
        await c.post("/owner/login", {"phone": "manager", "password": "Str0ng-pass!"})
        self.assertIn("بيانات الدخول غير صحيحة", c.text)


class PhotoTests(Case):
    async def setUp2(self):
        owner = await self.make_owner()
        return owner, await self.add_listing(owner)

    async def test_a_picture_is_stored_without_its_hidden_data_and_shown(self):
        owner, lid = await self.setUp2()
        r = await owner.post(f"/owner/listing/{lid}/photo", files=[("photo", "IMG_0001.JPG", fake_jpeg())], page=f"/owner/listing/{lid}")
        self.assertEqual(r.status, 303)
        photo = self.db.one("SELECT * FROM photos")
        self.assertRegex(photo["filename"], r"^[0-9a-f]{32}\.jpg$")                         # the name the visitor chose is never used
        stored = (self.app.settings.uploads_dir / photo["filename"]).read_bytes()
        self.assertNotIn(b"GPS", stored)
        self.approve(lid)
        r = await self.visitor.get(f"/media/{photo['filename']}")
        self.assertEqual((r.status, r.content_type), (200, "image/jpeg"))
        self.assertNotIn(b"GPS", r.body)
        await self.visitor.get(f"/r/{lid}")
        self.assertIn(f"/media/{photo['filename']}", self.visitor.text)
        await self.visitor.get("/search")
        self.assertIn(f"/media/{photo['filename']}", self.visitor.text)

    async def test_several_pictures_png_and_the_cover(self):
        owner, lid = await self.setUp2()
        await owner.post(f"/owner/listing/{lid}/photo", files=[("photo", "a.jpg", fake_jpeg()), ("photo", "b.png", fake_png())], page=f"/owner/listing/{lid}")
        rows = self.db.all("SELECT * FROM photos ORDER BY position")
        self.assertEqual([r["filename"].rsplit(".", 1)[1] for r in rows], ["jpg", "png"])
        await owner.post(f"/owner/listing/{lid}/photo/{rows[1]['id']}/cover", page=f"/owner/listing/{lid}")
        first = self.db.one("SELECT filename FROM photos ORDER BY position, id LIMIT 1")["filename"]
        self.assertEqual(first, rows[1]["filename"])
        await owner.post(f"/owner/listing/{lid}/photo/{rows[1]['id']}/delete", page=f"/owner/listing/{lid}")
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM photos")["n"], 1)
        self.assertFalse((self.app.settings.uploads_dir / rows[1]["filename"]).exists())

    async def test_bad_files_are_refused(self):
        owner, lid = await self.setUp2()
        for name, data in (("a.jpg", b"<?php echo 1;"), ("b.jpg", b"<html><script>alert(1)</script>"), ("c.gif", b"GIF89a" + b"\x00" * 50), ("d.jpg", fake_jpeg(10, 10)),
                           ("e.svg", b"<svg xmlns='http://www.w3.org/2000/svg'><script>1</script></svg>")):
            r = await owner.post(f"/owner/listing/{lid}/photo", files=[("photo", name, data)], page=f"/owner/listing/{lid}")
            self.assertEqual(r.status, 303, name)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM photos")["n"], 0)
        self.assertEqual(list(self.app.settings.uploads_dir.glob("*")) if self.app.settings.uploads_dir.exists() else [], [])

    async def test_the_fetch_upload_answers_in_plain_text(self):
        owner, lid = await self.setUp2()
        await owner.get(f"/owner/listing/{lid}")
        token = owner.csrf()
        r = await owner.go("POST", f"/owner/listing/{lid}/photo", {"_csrf": token}, files=[("photo", "x.jpg", fake_jpeg())], headers={"x-requested-with": "fetch"})
        self.assertEqual((r.status, r.body.decode()), (200, "تم رفع 1 صورة"))
        r = await owner.go("POST", f"/owner/listing/{lid}/photo", {"_csrf": token}, files=[("photo", "x.jpg", b"nope")], headers={"x-requested-with": "fetch"})
        self.assertEqual(r.status, 400)

    async def test_the_number_of_pictures_is_limited(self):
        owner, lid = await self.setUp2()
        for i in range(self.app.settings.max_photos):
            await owner.post(f"/owner/listing/{lid}/photo", files=[("photo", "x.jpg", fake_jpeg())], page=f"/owner/listing/{lid}")
        await owner.post(f"/owner/listing/{lid}/photo", files=[("photo", "x.jpg", fake_jpeg())], page=f"/owner/listing/{lid}")
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM photos")["n"], self.app.settings.max_photos)
        self.assertIn("الحد الأعلى", await owner.message())

    async def test_a_new_picture_on_a_published_advert_sends_it_to_review(self):
        owner, lid = await self.setUp2()
        self.approve(lid)
        await owner.post(f"/owner/listing/{lid}/photo", files=[("photo", "x.jpg", fake_jpeg())], page=f"/owner/listing/{lid}")
        self.assertEqual(self.db.one("SELECT review FROM listings WHERE id = ?", (lid,))["review"], "pending")

    async def test_only_the_owner_can_delete_a_picture(self):
        owner, lid = await self.setUp2()
        other = await self.make_owner("0552222222", ip="203.0.113.12")
        await owner.post(f"/owner/listing/{lid}/photo", files=[("photo", "x.jpg", fake_jpeg())], page=f"/owner/listing/{lid}")
        pid = self.db.one("SELECT id FROM photos")["id"]
        await other.get("/owner")
        r = await other.post(f"/owner/listing/{lid}/photo/{pid}/delete")
        self.assertEqual(r.status, 404)
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM photos")["n"], 1)


class AvailabilityTests(Case):
    async def test_add_and_remove_a_taken_period(self):
        owner = await self.make_owner()
        lid = await self.add_listing(owner)
        self.approve(lid)
        await owner.post(f"/owner/listing/{lid}/block", {"start": "2026-12-20", "end": "2026-12-22"}, page=f"/owner/listing/{lid}")
        await owner.post(f"/owner/listing/{lid}/block", {"start": "2027-01-05", "end": ""}, page=f"/owner/listing/{lid}")        # one day
        rows = self.db.all("SELECT * FROM blocked_dates ORDER BY id")
        self.assertEqual([(r["start_date"], r["end_date"]) for r in rows], [("2026-12-20", "2026-12-22"), ("2027-01-05", "2027-01-05")])
        await self.visitor.get(f"/r/{lid}")
        self.assertIn("تواريخ غير متاحة", self.visitor.text)
        await owner.post(f"/owner/listing/{lid}/block", {"start": "2026-12-25", "end": "2026-12-24"}, page=f"/owner/listing/{lid}")
        self.assertIn("تاريخ غير صحيح", await owner.message())
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM blocked_dates")["n"], 2)
        await owner.post(f"/owner/listing/{lid}/block/{rows[0]['id']}/delete", page=f"/owner/listing/{lid}")
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM blocked_dates")["n"], 1)


class PasswordChangeTests(Case):
    async def test_only_a_signed_in_owner_can_open_it(self):
        self.assertEqual((await self.visitor.get("/owner/password")).status, 303)
        admin = await self.make_admin()
        self.assertEqual((await admin.get("/owner/password")).status, 303)             # an admin session is not an owner session
        owner = await self.make_owner()
        r = await owner.get("/owner/password")
        self.assertEqual(r.status, 200)
        self.assertIn("تغيير كلمة المرور", owner.text)
        await owner.get("/owner")
        self.assertIn("/owner/password", owner.text)                                   # reachable from the owner's page

    async def test_changing_it_ends_the_other_sessions_but_not_this_one(self):
        owner = await self.make_owner()
        other = Client(self.app, "203.0.113.77")                                       # the same owner on another phone
        await other.get("/owner/login")
        await other.post("/owner/login", {"phone": "0551234567", "password": "Owner-pass-1"})
        self.assertEqual((await other.get("/owner")).status, 200)
        r = await owner.post("/owner/password", {"current": "Owner-pass-1", "new": "Brand-new-pass-2", "again": "Brand-new-pass-2"}, page="/owner/password")
        self.assertEqual((r.status, r.headers["Location"].split("?")[0]), (303, "/owner"))
        self.assertIn("تم تغيير كلمة المرور", await owner.message())
        self.assertEqual((await owner.get("/owner")).status, 200)                      # still signed in here
        self.assertEqual((await other.get("/owner")).status, 303)                      # signed out there
        self.assertEqual(self.db.one("SELECT COUNT(*) AS n FROM audit WHERE action = 'owner_password'")["n"], 1)
        fresh = Client(self.app, "203.0.113.78")
        await fresh.get("/owner/login")
        r = await fresh.post("/owner/login", {"phone": "0551234567", "password": "Owner-pass-1"})
        self.assertEqual(r.status, 200)                                               # the old password no longer works
        r = await fresh.post("/owner/login", {"phone": "0551234567", "password": "Brand-new-pass-2"})
        self.assertEqual(r.status, 303)
        stored = self.db.one("SELECT pass_hash FROM users WHERE login = '966551234567'")["pass_hash"]
        self.assertNotIn("Brand-new-pass-2", stored)
        self.assertTrue(security.check_password("Brand-new-pass-2", stored))

    async def test_mistakes_change_nothing(self):
        owner = await self.make_owner()
        before = self.db.one("SELECT pass_hash FROM users WHERE login = '966551234567'")["pass_hash"]
        cases = [
            ({"current": "wrong-pass-1", "new": "Brand-new-pass-2", "again": "Brand-new-pass-2"}, "كلمة المرور الحالية غير صحيحة"),
            ({"current": "Owner-pass-1", "new": "Brand-new-pass-2", "again": "Another-pass-3"}, "غير متطابقتين"),
            ({"current": "Owner-pass-1", "new": "short", "again": "short"}, "قصيرة"),
            ({"current": "Owner-pass-1", "new": "12345678", "again": "12345678"}, "ضعيفة"),
            ({"current": "", "new": "Brand-new-pass-2", "again": "Brand-new-pass-2"}, "غير صحيحة"),
        ]
        for form, expected in cases:
            r = await owner.post("/owner/password", form, page="/owner/password")
            self.assertEqual(r.status, 200, form)
            self.assertIn(expected, owner.text, form)
            self.assertEqual(self.db.one("SELECT pass_hash FROM users WHERE login = '966551234567'")["pass_hash"], before)

    async def test_guessing_the_current_password_here_locks_the_account_like_the_login_page(self):
        owner = await self.make_owner()
        for _ in range(5):
            await owner.post("/owner/password", {"current": "guess-guess-1", "new": "Brand-new-pass-2", "again": "Brand-new-pass-2"}, page="/owner/password")
        await owner.post("/owner/password", {"current": "Owner-pass-1", "new": "Brand-new-pass-2", "again": "Brand-new-pass-2"}, page="/owner/password")
        self.assertIn("مقفل", owner.text)
        self.assertTrue(security.check_password("Owner-pass-1", self.db.one("SELECT pass_hash FROM users WHERE login = '966551234567'")["pass_hash"]))

    async def test_a_form_without_the_check_token_is_refused(self):
        owner = await self.make_owner()
        r = await owner.go("POST", "/owner/password", {"current": "Owner-pass-1", "new": "Brand-new-pass-2", "again": "Brand-new-pass-2"})
        self.assertEqual(r.status, 403)
        self.assertTrue(security.check_password("Owner-pass-1", self.db.one("SELECT pass_hash FROM users WHERE login = '966551234567'")["pass_hash"]))

    async def test_the_temporary_password_from_the_admin_can_be_replaced_by_the_owner(self):
        owner = await self.make_owner()
        admin = await self.make_admin()
        oid = self.db.one("SELECT id FROM users WHERE login = '966551234567'")["id"]
        await admin.post(f"/admin/owner/{oid}/reset", page=f"/admin/owner/{oid}")
        temp = re.search(r"\(تظهر مرة واحدة\): ([A-Za-z0-9_-]+)", admin.text).group(1)
        fresh = Client(self.app, "203.0.113.79")
        await fresh.get("/owner/login")
        self.assertEqual((await fresh.post("/owner/login", {"phone": "0551234567", "password": temp})).status, 303)
        r = await fresh.post("/owner/password", {"current": temp, "new": "My-own-pass-9", "again": "My-own-pass-9"}, page="/owner/password")
        self.assertEqual(r.status, 303)
        again = Client(self.app, "203.0.113.80")
        await again.get("/owner/login")
        self.assertEqual((await again.post("/owner/login", {"phone": "0551234567", "password": temp})).status, 200)       # the temporary one is dead
        self.assertEqual((await again.post("/owner/login", {"phone": "0551234567", "password": "My-own-pass-9"})).status, 303)
