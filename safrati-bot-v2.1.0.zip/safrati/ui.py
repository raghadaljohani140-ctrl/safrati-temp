"""Small helpers shared by the screens: constants, button rows and price shortcuts."""
from __future__ import annotations

from .telegram import button
from .tp import Offer, to_sar

STAYS = (3, 5, 7, 10, 14)             # "how many days" choices on the results screen
TRIP_LENGTHS = (0, 3, 5, 7, 10, 14)    # days between going and coming back; 0 = one way
DATE_ROWS = 5                          # cheapest days listed with their prices
BOOKING_BUTTONS = 3                    # booking buttons under a result
MAX_WATCHES = 8                        # price alerts one person may keep
PAD = "·"                              # Telegram refuses empty button text, so blanks are dots


def footer() -> list[dict]:
    return [button("🎲 فاجئني", data="sur"), button("🏠 القائمة", data="menu")]


def chunk(items: list, size: int) -> list[list]:
    return [items[i:i + size] for i in range(0, len(items), size)]


def sar(offer: Offer) -> float:
    """The ticket price in riyals (0 when it cannot be converted)."""
    return to_sar(offer.price, offer.currency) or 0.0


def strip_url_buttons(markup: dict) -> dict:
    rows = [[b for b in row if "url" not in b] for row in markup.get("inline_keyboard", [])]
    return {"inline_keyboard": [r for r in rows if r]}


def swap_button(markup: dict | None, old_data: set[str], new: dict) -> dict | None:
    if not markup:
        return None
    rows = []
    for row in markup.get("inline_keyboard", []):
        rows.append([new if b.get("callback_data") in old_data else b for b in row])
    return {"inline_keyboard": rows}
