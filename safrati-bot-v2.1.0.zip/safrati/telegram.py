"""Minimal Telegram Bot API client over HTTPS long polling (standard library only).

The bot token is part of the Telegram URL, so errors are scrubbed before they can reach a log.
"""
from __future__ import annotations

import asyncio
import json
import logging
import http.client
import urllib.error
import urllib.request
from typing import Any, Callable

log = logging.getLogger("safrati.telegram")

API = "https://api.telegram.org"
Transport = Callable[[str, bytes, float], "tuple[int, bytes]"]
BOUNDARY = "safratiFormBoundary7c1e5a"          # separates the parts of a file upload (sendPhoto)


class TelegramError(Exception):
    def __init__(self, message: str, status: int = 0, retry_after: int = 0):
        super().__init__(message)
        self.status = status
        self.retry_after = retry_after


def multipart_body(fields: dict[str, Any], files: dict[str, tuple[str, bytes, str]]) -> bytes:
    """A multipart/form-data body: text fields (objects are sent as JSON) and files {name: (filename, bytes, type)}."""
    out = bytearray()
    for name, value in fields.items():
        text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)
        out += f'--{BOUNDARY}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n'.encode() + text.encode("utf-8") + b"\r\n"
    for name, (filename, content, kind) in files.items():
        out += (
            f'--{BOUNDARY}\r\nContent-Disposition: form-data; name="{name}"; filename="{filename}"\r\n'
            f"Content-Type: {kind}\r\n\r\n"
        ).encode() + content + b"\r\n"
    out += f"--{BOUNDARY}--\r\n".encode()
    return bytes(out)


def _urllib_transport(url: str, body: bytes, timeout: float):
    kind = f"multipart/form-data; boundary={BOUNDARY}" if body.startswith(f"--{BOUNDARY}".encode()) else "application/json"
    req = urllib.request.Request(url, data=body, method="POST", headers={"Content-Type": kind})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read()
    except (urllib.error.URLError, TimeoutError, OSError, http.client.HTTPException) as exc:
        raise TelegramError(f"network error: {type(exc).__name__}") from None


def button(text: str, *, data: str | None = None, url: str | None = None) -> dict:
    b: dict[str, Any] = {"text": text}
    if url:
        b["url"] = url
    else:
        b["callback_data"] = data or "noop"
    return b


def keyboard(rows: list[list[dict]]) -> dict:
    return {"inline_keyboard": rows}


class TelegramAPI:
    def __init__(self, token: str, *, transport: Transport | None = None):
        self._token = token
        self._transport = transport or _urllib_transport

    def _scrub(self, text: str) -> str:
        return text.replace(self._token, "***")

    async def call(
        self, method: str, params: dict | None = None, *, timeout: float = 15.0,
        files: dict[str, tuple[str, bytes, str]] | None = None,
    ) -> Any:
        url = f"{API}/bot{self._token}/{method}"
        if files:
            body = multipart_body(params or {}, files)
            timeout = max(timeout, 40.0)
        else:
            body = json.dumps(params or {}, ensure_ascii=False).encode()
        status, raw = await asyncio.to_thread(self._transport, url, body, timeout)
        try:
            payload = json.loads(raw.decode("utf-8"))
        except ValueError:
            raise TelegramError(f"{method}: bad response ({status})", status) from None
        if payload.get("ok"):
            return payload.get("result")
        desc = self._scrub(str(payload.get("description") or ""))[:200]
        retry = int((payload.get("parameters") or {}).get("retry_after") or 0)
        raise TelegramError(f"{method}: {payload.get('error_code', status)} {desc}", int(payload.get("error_code", status)), retry)

    # ---- helpers -----------------------------------------------------
    async def get_me(self) -> dict:
        return await self.call("getMe")

    async def get_updates(self, offset: int, timeout: int = 25) -> list[dict]:
        return await self.call(
            "getUpdates",
            {"offset": offset, "timeout": timeout, "allowed_updates": ["message", "callback_query"]},
            timeout=timeout + 10,
        )

    async def send_message(self, chat_id: int | str, text: str, markup: dict | None = None) -> dict:
        params: dict[str, Any] = {
            "chat_id": chat_id,
            "text": text,
            "parse_mode": "HTML",
            "link_preview_options": {"is_disabled": True},
        }
        if markup:
            params["reply_markup"] = markup
        return await self._with_retry("sendMessage", params)

    async def send_photo(self, chat_id: int | str, photo: bytes, caption: str, markup: dict | None = None) -> dict:
        params: dict[str, Any] = {"chat_id": str(chat_id), "caption": caption, "parse_mode": "HTML"}
        if markup:
            params["reply_markup"] = markup
        return await self._with_retry("sendPhoto", params, files={"photo": ("welcome.png", photo, "image/png")})

    async def edit_message(self, chat_id: int, message_id: int, text: str, markup: dict | None = None) -> dict | None:
        params: dict[str, Any] = {
            "chat_id": chat_id,
            "message_id": message_id,
            "text": text,
            "parse_mode": "HTML",
            "link_preview_options": {"is_disabled": True},
        }
        if markup:
            params["reply_markup"] = markup
        try:
            return await self._with_retry("editMessageText", params)
        except TelegramError as exc:
            if "not modified" in str(exc):
                return None
            raise

    async def answer_callback(self, callback_id: str, text: str | None = None) -> None:
        params: dict[str, Any] = {"callback_query_id": callback_id}
        if text:
            params["text"] = text
        try:
            await self.call("answerCallbackQuery", params)
        except TelegramError as exc:  # expired callbacks are harmless
            log.debug("answerCallbackQuery: %s", exc)

    async def edit_markup(self, chat_id: int, message_id: int, markup: dict) -> None:
        try:
            await self._with_retry(
                "editMessageReplyMarkup", {"chat_id": chat_id, "message_id": message_id, "reply_markup": markup}
            )
        except TelegramError as exc:
            if "not modified" not in str(exc):
                raise

    async def send_action(self, chat_id: int, action: str = "typing") -> None:
        try:
            await self.call("sendChatAction", {"chat_id": chat_id, "action": action}, timeout=8)
        except TelegramError as exc:
            log.debug("sendChatAction: %s", exc)

    async def delete_message(self, chat_id: int, message_id: int) -> None:
        try:
            await self.call("deleteMessage", {"chat_id": chat_id, "message_id": message_id})
        except TelegramError as exc:
            log.debug("deleteMessage: %s", exc)

    async def get_chat_member(self, chat_id: int | str, user_id: int) -> dict:
        return await self.call("getChatMember", {"chat_id": chat_id, "user_id": user_id})

    async def delete_webhook(self) -> None:
        await self.call("deleteWebhook", {"drop_pending_updates": False})

    async def set_profile_texts(self, description: str, short: str) -> None:
        await self.call("setMyDescription", {"description": description})
        await self.call("setMyShortDescription", {"short_description": short})

    async def set_commands(self, commands: list[tuple[str, str]]) -> None:
        await self.call("setMyCommands", {"commands": [{"command": c, "description": d} for c, d in commands]})

    async def _with_retry(self, method: str, params: dict, files: dict | None = None) -> Any:
        for attempt in range(3):
            try:
                return await self.call(method, params, files=files)
            except TelegramError as exc:
                if exc.status == 429 and attempt < 2:
                    await asyncio.sleep(min(exc.retry_after or 1, 10))
                    continue
                raise
