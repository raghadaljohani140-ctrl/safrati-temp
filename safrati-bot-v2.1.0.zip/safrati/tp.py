"""Travelpayouts client (Aviasales Data API + partner links), standard library only.

Prices come from the provider's own cache of recent searches, never from this code.
The API token travels in a header, never in a URL, and is never logged.
"""
from __future__ import annotations

import asyncio
import gzip
import io
import json
import logging
import time
import http.client
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import date
from typing import Callable

from . import __version__

log = logging.getLogger("safrati.tp")

BASE = "https://api.travelpayouts.com"
SITE = "https://www.aviasales.com"
PRICES_PATH = "/aviasales/v3/prices_for_dates"
LINKS_PATH = "/links/v1/create"
CONVERTIBLE = ("sar", "usd")  # currencies the bot can show in riyals
MIN_STAY_DAYS = 3  # open searches skip round trips shorter than this
SAR_PER_USD = 3.75  # the riyal is pegged to the dollar

MAX_BODY = 12 * 1024 * 1024      # larger answers are refused, compressed or not
MAX_CACHED_ROWS = 20000          # memory guard for cached price rows (the container has 256 MB)
MAX_CALENDARS = 400

LINK_OK_TTL = 24 * 3600
LINK_FAIL_TTL = 10 * 60

WEEKEND_BUDGET = 8.0             # seconds a weekend lookup may take; slower parts finish in the background for the next person
WEEKEND_LANES = 4                # destinations asked about one by one at the same time (the rest of the 6 stay free for other people)

Transport = Callable[[str, str, dict, "bytes | None", float], "tuple[int, bytes]"]


class TPError(Exception):
    def __init__(self, message: str, status: int = 0):
        super().__init__(message)
        self.status = status


@dataclass(frozen=True)
class Offer:
    origin: str
    destination: str
    price: float
    currency: str
    airline: str
    departure_at: str
    return_at: str
    transfers: int
    link: str
    duration: int = 0     # minutes, outbound flight including connections (0 = unknown)


def _read_body(resp) -> bytes:
    raw = resp.read(MAX_BODY + 1)
    if len(raw) > MAX_BODY:
        raise TPError("answer too large")
    if (resp.headers.get("Content-Encoding") or "").lower() == "gzip":
        with gzip.GzipFile(fileobj=io.BytesIO(raw)) as handle:
            raw = handle.read(MAX_BODY + 1)
        if len(raw) > MAX_BODY:
            raise TPError("answer too large")
    return raw


def _urllib_transport(method: str, url: str, headers: dict, body: bytes | None, timeout: float):
    req = urllib.request.Request(url, data=body, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, _read_body(resp)
    except urllib.error.HTTPError as exc:
        return exc.code, _read_body(exc)
    except (urllib.error.URLError, TimeoutError, OSError, http.client.HTTPException, EOFError) as exc:
        raise TPError(f"network error: {type(exc).__name__}") from None


def with_marker(url: str, marker: str) -> str:
    """Fallback affiliate tagging: add ?marker=<id> when the links API is not configured."""
    if not marker:
        return url
    parts = urllib.parse.urlsplit(url)
    query = urllib.parse.parse_qsl(parts.query, keep_blank_values=True)
    if not any(k == "marker" for k, _ in query):
        query.append(("marker", marker))
    return urllib.parse.urlunsplit(parts._replace(query=urllib.parse.urlencode(query)))


def month_keys(now: float | None = None, count: int = 3) -> list[str]:
    t = time.gmtime(now if now is not None else time.time())
    year, month = t.tm_year, t.tm_mon
    out = []
    for _ in range(count):
        out.append(f"{year:04d}-{month:02d}")
        month += 1
        if month == 13:
            year, month = year + 1, 1
    return out


class TravelpayoutsClient:
    def __init__(
        self,
        token: str,
        marker: str = "",
        trs: str = "",
        currency: str = "sar",
        *,
        market: str = "",
        show_all: bool = False,
        cache_seconds: int = 1800,
        transport: Transport | None = None,
        clock: Callable[[], float] = time.time,
        timeout: float = 15.0,
    ):
        self._token = token
        self.marker = marker
        self.trs = trs
        self.currency = currency.lower()
        self.market = market.lower()
        self.show_all = show_all
        self._ttl = cache_seconds
        self._transport = transport or _urllib_transport
        self._clock = clock
        self._timeout = timeout
        self._cache: dict[tuple, tuple[float, list[Offer]]] = {}
        self._rows = 0
        self._cal: dict[tuple, tuple[float, dict[str, Offer]]] = {}
        self._sem = asyncio.Semaphore(6)    # be polite: a few provider calls at a time
        self._lane = asyncio.Semaphore(WEEKEND_LANES)
        self._inflight: dict[tuple, asyncio.Future] = {}
        self._links: dict[str, tuple[float, str | None]] = {}
        self._cooldown_until = 0.0
        self._cooldown_status = 0
        self._fail_streak = 0
        self.currency_fallback_used = False
        self.link_issue = ""          # why the provider refused the last partner link (short, no secrets)
        self.weekend_pending = 0       # parts of the last weekend lookup that were still running when it answered

    @property
    def enabled(self) -> bool:
        return bool(self._token)

    @property
    def links_api(self) -> bool:
        return bool(self._token and self.marker.isdigit() and self.trs.isdigit())

    # ---- low level ---------------------------------------------------
    async def _call(self, method: str, path: str, params: dict | None = None, body: dict | None = None):
        url = BASE + path
        if params:
            url += "?" + urllib.parse.urlencode(params)
        headers = {"X-Access-Token": self._token, "Accept": "application/json",
                   "Accept-Encoding": "gzip", "User-Agent": f"safrati-bot/{__version__}"}
        data = None
        if body is not None:
            data = json.dumps(body).encode()
            headers["Content-Type"] = "application/json"
        status, raw = await asyncio.to_thread(self._transport, method, url, headers, data, self._timeout)
        try:
            payload = json.loads(raw.decode("utf-8")) if raw else {}
        except ValueError:
            payload = {}
        if not isinstance(payload, dict):
            payload = {}
        return status, payload

    @staticmethod
    def _raise_for(status: int, payload: dict) -> None:
        if status in (401, 403):
            raise TPError("token rejected by Travelpayouts", status)
        if status == 429:
            raise TPError("rate limit reached", status)
        if status >= 400 or payload.get("success") is False:
            detail = str(payload.get("error") or payload.get("message") or "")[:120]
            raise TPError(f"api error {status} {detail}".strip(), status)

    def _trip(self, status: int) -> None:
        """Stop calling the provider for a short while after failures, so users get fast answers.

        Auth problems and rate limits trip at once; other failures need two in a row, so one
        timeout among three parallel month requests does not block the other two.
        """
        if status in (401, 403, 429):
            self._cooldown_until = self._clock() + (60 if status != 429 else 15)
            self._cooldown_status = status
            return
        self._fail_streak += 1
        if self._fail_streak >= 2:
            self._cooldown_until = self._clock() + 15
            self._cooldown_status = status

    def _guard(self) -> None:
        if self._clock() < self._cooldown_until:
            raise TPError("provider temporarily unavailable", self._cooldown_status)

    # ---- prices ------------------------------------------------------
    def _params(self, cur: str, origin, destination, month, unique: bool, limit: int,
                return_at=None, one_way: bool = False, all_results: bool = False) -> dict:
        p: dict = {
            "currency": cur,
            "sorting": "price",
            "limit": limit,
            "one_way": "true" if one_way else "false",
            "unique": "true" if unique else "false",
            "show_to_affiliates": "false" if (self.show_all or all_results) else "true",
            "direct": "false",   # flights with a connection are fine
        }
        if origin:
            p["origin"] = origin
        if destination:
            p["destination"] = destination
        if month:
            p["departure_at"] = month
        if return_at and not one_way:
            p["return_at"] = return_at
        if self.market:
            p["market"] = self.market
        return p

    async def prices(
        self,
        *,
        origin: str | None = None,
        destination: str | None = None,
        month: str | None = None,
        unique: bool = True,
        limit: int = 100,
        return_at: str | None = None,
        one_way: bool = False,
        min_stay: int = 0,
        max_stay: int = 0,
        cache: bool = True,
    ) -> list[Offer]:
        """`month` is the provider's departure_at: YYYY-MM or one exact day YYYY-MM-DD.

        min_stay / max_stay (days between going and coming back) are applied here, not by the provider."""
        key = (origin, destination, month, unique, limit, return_at, one_way, min_stay, max_stay)
        if cache:
            hit = self._cache.get(key)
            if hit and self._clock() - hit[0] < self._ttl:
                return hit[1]
        task = self._inflight.get(key)
        if task is None:
            task = asyncio.ensure_future(
                self._fetch_prices(key, origin, destination, month, unique, limit, return_at, one_way,
                                   min_stay, max_stay, cache)
            )
            self._inflight[key] = task
            task.add_done_callback(lambda _t, k=key: self._inflight.pop(k, None))
        return await asyncio.shield(task)

    async def _get(self, params_for) -> tuple[int, dict]:
        async with self._sem:
            return await self._call("GET", PRICES_PATH, params_for)

    async def _fetch_prices(self, key: tuple, origin, destination, month, unique: bool, limit: int,
                            return_at=None, one_way: bool = False, min_stay: int = 0, max_stay: int = 0,
                            cache: bool = True) -> list[Offer]:
        self._guard()
        cur = self.currency
        payload: dict = {}
        for attempt in range(2):
            try:
                status, payload = await self._get(
                    self._params(cur, origin, destination, month, unique, limit, return_at, one_way)
                )
            except TPError:
                self._trip(0)
                raise
            if status in (400, 422) and cur != "usd" and "currenc" in json.dumps(payload).lower():
                log.warning("currency %s rejected, falling back to usd", cur)
                cur = "usd"
                self.currency, self.currency_fallback_used = "usd", True
                continue
            try:
                self._raise_for(status, payload)
            except TPError as exc:
                self._trip(exc.status)
                raise
            self._fail_streak = 0
            got = str(payload.get("currency") or cur).lower()
            if got not in CONVERTIBLE and cur != "usd" and attempt == 0:
                log.warning("provider answered in %s, retrying in usd", got)
                cur = "usd"
                self.currency, self.currency_fallback_used = "usd", True
                continue
            break

        if not payload.get("data") and destination and not self.show_all:
            # nothing among the partner-visible prices: ask once for everything the provider has on this route
            try:
                status2, payload2 = await self._get(
                    self._params(cur, origin, destination, month, unique, limit, return_at, one_way, all_results=True)
                )
                if status2 == 200 and payload2.get("data"):
                    payload = payload2
            except TPError as exc:
                log.info("wider price lookup failed: %s", exc)
        got = str(payload.get("currency") or cur).lower()
        offers: list[Offer] = []
        for row in payload.get("data") or []:
            if not isinstance(row, dict):
                continue
            dep = str(row.get("departure_at") or "")[:10]
            back = str(row.get("return_at") or "")[:10]
            if not one_way and back:
                stay = _stay_days(dep, back)
                # same-day returns are bad data; short hops are skipped unless the caller allows them
                if stay < max(1, min_stay) or (max_stay and stay > max_stay):
                    continue
            try:
                offers.append(
                    Offer(
                        origin=str(row.get("origin") or origin or "").upper(),
                        destination=str(row["destination"]).upper(),
                        price=float(row["price"]),
                        currency=got,
                        airline=str(row.get("airline") or ""),
                        departure_at=str(row.get("departure_at") or ""),
                        return_at=str(row.get("return_at") or ""),
                        transfers=int(row.get("transfers") or 0),
                        link=str(row.get("link") or ""),
                        duration=int(row.get("duration_to") or 0),
                    )
                )
            except (KeyError, TypeError, ValueError, AttributeError):
                continue
        if cache:
            self._remember(key, offers)
        return offers

    def _remember(self, key: tuple, offers: list[Offer]) -> None:
        old = self._cache.pop(key, None)
        if old:
            self._rows -= len(old[1])
        self._cache[key] = (self._clock(), offers)
        self._rows += len(offers)
        while self._cache and (len(self._cache) > 2000 or self._rows > MAX_CACHED_ROWS):
            _, (_, dropped) = next(iter(self._cache.items()))
            self._rows -= len(dropped)
            self._cache.pop(next(iter(self._cache)))

    # ---- calendars: the cheapest ticket for every day of a month ----------
    @staticmethod
    def stay_window(stay: int | None, weekend: bool, one_way: bool) -> tuple[int, int]:
        """(shortest, longest) stay in days. 0 as the longest means no upper limit."""
        if one_way:
            return 0, 0
        if weekend:
            return 2, 3
        if stay:
            return max(1, stay - 1), stay + 1       # "about N days" means N-1 to N+1
        return MIN_STAY_DAYS, 0

    async def calendar(
        self, origin: str, destination: str, month: str, *, one_way: bool = False, stay: int | None = None,
        weekend: bool = False,
    ) -> dict[str, Offer]:
        """{"2026-12-15": cheapest Offer leaving that day} for one month (YYYY-MM). Cached in a compact form."""
        lo, hi = self.stay_window(stay, weekend, one_way)
        key = ("cal", origin, destination, month, one_way, lo, hi, weekend)
        hit = self._cal.get(key)
        if hit and self._clock() - hit[0] < self._ttl:
            return hit[1]
        task = self._inflight.get(key)
        if task is None:
            task = asyncio.ensure_future(self._build_calendar(key, origin, destination, month, one_way, lo, hi, weekend))
            self._inflight[key] = task
            task.add_done_callback(lambda _t, k=key: self._inflight.pop(k, None))
        return await asyncio.shield(task)

    async def _build_calendar(self, key, origin, destination, month, one_way, lo, hi, weekend) -> dict[str, Offer]:
        offers = await self.prices(
            origin=origin, destination=destination, month=month, unique=False, limit=1000, one_way=one_way,
            min_stay=lo, max_stay=hi, cache=False,
        )
        days: dict[str, Offer] = {}
        for offer in offers:
            day = offer.departure_at[:10]
            if not day or not day.startswith(month) or to_sar(offer.price, offer.currency) is None:
                continue
            if weekend and not is_weekend_trip(offer):
                continue
            cur = days.get(day)
            if cur is None or _sar(offer) < _sar(cur):
                days[day] = offer
        self._cal[key] = (self._clock(), days)
        while len(self._cal) > MAX_CALENDARS:
            self._cal.pop(next(iter(self._cal)))
        return days

    async def calendars(self, origin: str, destination: str, months: list[str], **kw) -> dict[str, dict[str, Offer]]:
        """Calendars for several months. A month that failed is left out; all failing raises the first error."""
        results = await asyncio.gather(
            *(self.calendar(origin, destination, m, **kw) for m in months), return_exceptions=True
        )
        out = {m: r for m, r in zip(months, results) if not isinstance(r, BaseException)}
        errors = [r for r in results if isinstance(r, BaseException)]
        if not out and errors:
            raise errors[0]
        return out

    async def month_minimums(
        self, origin: str, destination: str, months: list[str], *, one_way: bool = False, stay: int | None = None
    ) -> dict[str, Offer]:
        """The cheapest ticket of each month: {"2026-12": Offer}. Months without any price are left out."""
        cals = await self.calendars(origin, destination, months, one_way=one_way, stay=stay)
        return {m: min(cal.values(), key=_sar) for m, cal in cals.items() if cal}

    # ---- the older, simpler lookups ----------------------------------------
    async def cheapest_from(self, origin: str, months: list[str]) -> dict[str, Offer]:
        """Cheapest known round trip from `origin` to each destination across the given months."""
        results = await asyncio.gather(
            *(self.prices(origin=origin, month=m, unique=True, limit=100, min_stay=1) for m in months),
            return_exceptions=True,
        )
        best: dict[str, Offer] = {}
        errors = [r for r in results if isinstance(r, BaseException)]
        for res in results:
            if isinstance(res, BaseException):
                continue
            for offer in res:
                cur = best.get(offer.destination)
                if cur is None or _sar(offer) < _sar(cur):
                    best[offer.destination] = offer
        if not best and errors:
            raise errors[0]
        return best

    async def cheapest_to(self, origin: str, destination: str, months: list[str]) -> Offer | None:
        cals = await self.calendars(origin, destination, months)
        offers = [o for cal in cals.values() for o in cal.values()]
        return min(offers, key=_sar) if offers else None

    async def cheapest_dates(
        self, origin: str, destination: str, months: list[str], *, one_way: bool = False, top: int = 5,
        stay: int | None = None, weekend: bool = False,
    ) -> list[Offer]:
        """The cheapest distinct departure days to `destination` across the given months."""
        cals = await self.calendars(origin, destination, months, one_way=one_way, stay=stay, weekend=weekend)
        offers = [o for cal in cals.values() for o in cal.values()]
        return sorted(offers, key=_sar)[:top]

    async def departures(self, origin: str, depart: date, ret: date) -> dict[str, Offer]:
        """The cheapest ticket to every destination for one exact pair of days (used for weekend trips)."""
        offers = await self.prices(
            origin=origin, month=depart.isoformat(), return_at=ret.isoformat(), unique=True, limit=100
        )
        best: dict[str, Offer] = {}
        for offer in offers:
            if to_sar(offer.price, offer.currency) is None:
                continue
            cur = best.get(offer.destination)
            if cur is None or _sar(offer) < _sar(cur):
                best[offer.destination] = offer
        return best

    async def weekend_deals(
        self, origin: str, months: list[str], earliest: str = "", *, known=None, extra=(), budget: float | None = None,
    ) -> dict[str, Offer]:
        """The cheapest Thursday/Friday-to-Saturday/Sunday trip to each destination in the given months,
        leaving on `earliest` (an ISO date) or later.

        One big request per month for the whole origin, then the destinations in `extra` one by one: the big
        request returns only the cheapest thousand tickets, and cheap short flights inside the country can fill
        all of them. `known` limits the answer to places the caller can show. Whatever has not arrived after
        `budget` seconds keeps loading in the background, so the next look is complete."""
        if not months:
            return {}
        budget = WEEKEND_BUDGET if budget is None else budget
        tasks = [
            asyncio.ensure_future(self.prices(origin=origin, month=m, unique=False, limit=1000, min_stay=2, max_stay=3, cache=False))
            for m in months
        ]
        tasks += [
            asyncio.ensure_future(self._weekend_route(origin, d, m)) for m in months for d in extra if d != origin
        ]
        _done, pending = await asyncio.wait(tasks, timeout=budget)
        self.weekend_pending = len(pending)
        for task in pending:
            task.add_done_callback(_retrieve)           # nobody waits for it now; its answer lands in the cache
        best: dict[str, Offer] = {}
        errors: list[BaseException] = []
        for task in tasks:
            if task in pending or task.cancelled():
                continue
            if task.exception() is not None:
                errors.append(task.exception())
                continue
            result = task.result()
            for offer in (result if isinstance(result, list) else result.values()):
                if known is not None and offer.destination not in known:
                    continue
                if offer.departure_at[:10] < earliest or not is_weekend_trip(offer):
                    continue
                if to_sar(offer.price, offer.currency) is None:
                    continue
                cur = best.get(offer.destination)
                if cur is None or _sar(offer) < _sar(cur):
                    best[offer.destination] = offer
        if not best:
            if errors:
                raise errors[0]
            if pending:
                raise TPError("still loading")
        return best

    async def _weekend_route(self, origin: str, destination: str, month: str) -> dict[str, Offer]:
        async with self._lane:
            return await self.calendar(origin, destination, month, weekend=True)

    def _exact_from_calendars(self, origin, destination, depart: str, ret: str | None, one_way: bool) -> list[Offer]:
        now = self._clock()
        found: list[Offer] = []
        for key, (stamp, days) in self._cal.items():
            if now - stamp >= self._ttl or key[1:5] != (origin, destination, depart[:7], one_way):
                continue
            offer = days.get(depart)
            if offer and (ret is None or one_way or offer.return_at[:10] == ret):
                found.append(offer)
        return sorted(found, key=_sar)[:1]

    async def exact(
        self, origin: str, destination: str, depart: str, ret: str | None = None, *, one_way: bool = False
    ) -> list[Offer]:
        """Known prices for one exact day (and return day). May be empty: the data is cached searches."""
        cached = self._exact_from_calendars(origin, destination, depart, ret, one_way)
        if cached:
            return cached
        offers = await self.prices(
            origin=origin, destination=destination, month=depart, unique=False, limit=10,
            return_at=ret, one_way=one_way,
        )
        return sorted(offers, key=_sar)

    # ---- partner links ----------------------------------------------
    @staticmethod
    def search_url(origin: str, destination: str, depart: date, ret: date | None = None) -> str:
        """Live Aviasales search for exact dates (connections included): /search/RUH1512LON22121"""
        back = ret.strftime("%d%m") if ret else ""
        return f"{SITE}/search/{origin}{depart.strftime('%d%m')}{destination}{back}1"

    @staticmethod
    def site_url(offer_link: str) -> str:
        """Search page for the same route and dates. The cached ticket token (t=) is dropped, because the
        cached ticket is often sold out by the time someone opens it; the search shows what is on sale now."""
        if offer_link.startswith("http"):
            full = offer_link
        else:
            full = SITE + (offer_link if offer_link.startswith("/") else "/" + offer_link)
        parts = urllib.parse.urlsplit(full)
        if parts.path.startswith("/search/"):
            query = [(k, v) for k, v in urllib.parse.parse_qsl(parts.query, keep_blank_values=True) if k != "t"]
            full = urllib.parse.urlunsplit(parts._replace(query=urllib.parse.urlencode(query)))
        return full

    async def partner_links(
        self, urls: list[str], *, marker_fallback: bool = False, fresh: bool = False
    ) -> dict[str, str | None]:
        """Turn plain URLs into partner URLs. A program the account has not joined gives None.

        With marker_fallback, a failed conversion falls back to url?marker=<id> (flight links only).
        With fresh, answers remembered from earlier are ignored (used by the admin check).
        """
        now = self._clock()
        out: dict[str, str | None] = {}
        todo: list[str] = []
        for url in dict.fromkeys(urls):
            hit = None if fresh else self._links.get(url)
            if hit and hit[0] > now:
                out[url] = hit[1]
            else:
                todo.append(url)

        if todo and self.links_api:
            for i in range(0, len(todo), 10):
                chunk = todo[i:i + 10]
                created = await self._create_links(chunk)
                for url in chunk:
                    value = created.get(url)
                    ttl = LINK_OK_TTL if value else LINK_FAIL_TTL
                    self._links[url] = (self._clock() + ttl, value)
                    out[url] = value
            while len(self._links) > 2000:
                self._links.pop(next(iter(self._links)))
        else:
            for url in todo:
                out[url] = None

        if marker_fallback and self.marker:
            for url, value in list(out.items()):
                if not value:
                    out[url] = with_marker(url, self.marker)
        return out

    async def _create_links(self, urls: list[str]) -> dict[str, str | None]:
        result: dict[str, str | None] = {}
        self.link_issue = ""
        try:
            status, payload = await self._call(
                "POST",
                LINKS_PATH,
                body={
                    "trs": int(self.trs),
                    "marker": int(self.marker),
                    "shorten": False,
                    "links": [{"url": u} for u in urls],
                },
            )
        except TPError as exc:
            log.warning("partner links failed: %s", exc)
            self.link_issue = str(exc)[:80]
            return result
        if status != 200:
            log.warning("partner links api status %s", status)
            self.link_issue = (str(payload.get("error") or payload.get("message") or payload.get("code") or "") or f"http {status}")[:80]
            return result
        entries = (payload.get("result") or {}).get("links") or []
        for index, entry in enumerate(entries):
            if not isinstance(entry, dict):
                continue
            url = entry.get("url") if entry.get("url") in urls else (urls[index] if index < len(urls) else None)
            if url is None:
                continue
            if entry.get("code") == "success" and entry.get("partner_url"):
                result[url] = str(entry["partner_url"])
            else:
                note = str(entry.get("message") or entry.get("code"))[:80]
                log.info("no partner link for one url: %s", note)
                self.link_issue = self.link_issue or note
        return result

    async def booking_url(self, offer: Offer) -> str:
        url = self.site_url(offer.link)
        res = await self.partner_links([url], marker_fallback=True)
        return res.get(url) or url

    # ---- diagnostics -------------------------------------------------
    def set_market(self, market: str) -> None:
        """Switch the provider's data source ("" = let the provider decide by the departure city). Forgets old answers."""
        market = market.strip().lower()
        if market != self.market:
            self.market = market
            self._cache.clear()
            self._cal.clear()
            self._rows = 0

    async def probe_days(self, origin: str, destination: str, month: str, market: str) -> int:
        """How many different departure days the provider knows for one route and month under one market.

        Used by the admin check that compares markets. Not cached, and a failure here never trips the cool-down."""
        params = self._params(self.currency, origin, destination, month, False, 1000)
        params.pop("market", None)
        if market:
            params["market"] = market
        status, payload = await self._get(params)
        self._raise_for(status, payload)
        days = set()
        for row in payload.get("data") or []:
            if not isinstance(row, dict):
                continue
            dep, back = str(row.get("departure_at") or "")[:10], str(row.get("return_at") or "")[:10]
            if dep and back and _stay_days(dep, back) >= MIN_STAY_DAYS:
                days.add(dep)
        return len(days)

    async def diagnose(self, origin: str, destination: str, month: str) -> dict:
        """One live probe used by the admin /diag command. Never returns secrets."""
        report: dict = {"token_set": self.enabled, "links_api": self.links_api, "currency": self.currency}
        report["links_missing"] = [
            name for name, ok in (("token", self._token), ("marker", self.marker.isdigit()), ("trs", self.trs.isdigit())) if not ok
        ]
        if not self.enabled:
            return report
        self._cooldown_until = 0.0
        try:
            offers = await self.prices(origin=origin, destination=destination, month=month, unique=False, limit=5)
        except TPError as exc:
            report["error"] = str(exc)
            return report
        report["offers"] = len(offers)
        report["currency"] = self.currency
        report["fallback"] = self.currency_fallback_used
        if offers:
            cheapest = min(offers, key=_sar)
            report["cheapest"] = f"{round(cheapest.price):,} {cheapest.currency.upper()}"
            if self.links_api:
                url = self.site_url(cheapest.link)
                link = (await self.partner_links([url], fresh=True)).get(url)
                report["partner_link"] = bool(link)
                if link:
                    report["partner_host"] = urllib.parse.urlsplit(link).netloc
                else:
                    report["partner_issue"] = self.link_issue
        return report


def is_weekend_trip(offer: Offer) -> bool:
    """Leaves on a Thursday or Friday and is back on a Saturday or Sunday (the Saudi weekend break)."""
    try:
        going = date.fromisoformat(offer.departure_at[:10])
        back = date.fromisoformat(offer.return_at[:10])
    except ValueError:
        return False
    return going.weekday() in (3, 4) and back.weekday() in (5, 6) and 2 <= (back - going).days <= 3


def _stay_days(dep: str, back: str) -> int:
    """Days between going and coming back; 0 when either date cannot be read."""
    try:
        return (date.fromisoformat(back) - date.fromisoformat(dep)).days
    except ValueError:
        return 0


def to_sar(price: float, currency: str) -> float | None:
    """Riyals for a price, or None when the currency cannot be converted."""
    currency = currency.lower()
    if currency == "sar":
        return price
    if currency == "usd":
        return price * SAR_PER_USD
    return None


def _retrieve(task: "asyncio.Future") -> None:
    """Mark a background result as looked at, so a late failure does not print a warning."""
    if not task.cancelled():
        task.exception()


def _sar(offer: Offer) -> float:
    """Comparable price; unknown currencies sort last."""
    value = to_sar(offer.price, offer.currency)
    return float("inf") if value is None else value
