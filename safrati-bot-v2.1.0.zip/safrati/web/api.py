"""The website's pages and JSON answers, built on the same price engine as the Telegram bot.

Nothing here stores anything about a visitor. Booking links are made only when a visitor presses a booking button."""
from __future__ import annotations

import asyncio
import hashlib
import logging
import re
import time
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path
from urllib.parse import urlsplit

from .. import __version__, data, texts
from .. import dates as dts
from .. import insights as ins
from ..db import ORIGINS, SAUDI_TZ
from ..tp import Offer, TPError, TravelpayoutsClient, month_keys, to_sar, with_marker
from .server import Request, Response, error_response, json_response
from .settings import WebSettings

log = logging.getLogger("safrati.web")

STATIC_DIR = Path(__file__).parent / "static"

# The same rules as the Telegram bot (a test keeps them equal), written here so the website does not have to load the bot.
HORIZON_SHIFT = 7 * 86400       # "cheapest now" skips flights leaving in the next few days
WEEKEND_MONTHS = 2
OVERVIEW_MONTHS = 6             # months of calendars sent together with a destination
CALENDAR_MONTHS = 12            # months a visitor can browse
DATE_ROWS = 5
STAYS = (3, 5, 7, 10, 14)       # "how many days" choices
TRIP_SHARE = 0.4                # part of a whole-trip budget that may go to the flight ticket
POPULAR = ("DXB", "IST", "CAI", "LON", "PAR", "KUL", "BKK", "TBS")

TOP_DAYS = DATE_ROWS
LIST_SIZE = 12
MIN_CAP, MAX_CAP = 100, 1_000_000
MAX_QUERY = 200
GATE = 24                       # price lookups running at the same moment; the rest wait a little, then are told to retry
GATE_WAIT = 3.0                 # seconds a visitor waits for a free place before being told the website is busy
REDIRECT_HOSTS = (              # partner links may lead only here
    "tp.media", "travelpayouts.com", "aviasales.com", "airalo.com", "tiqets.com", "gettransfer.com",
)
ISO_DAY = re.compile(r"^\d{4}-\d{2}-\d{2}$")
ISO_MONTH = re.compile(r"^\d{4}-\d{2}$")

VISA = {       # status: (full label, level, short label)
    "free": ("بدون تأشيرة مسبقة", "ok", "بدون تأشيرة"),
    "gcc": ("بدون تأشيرة (بالهوية الوطنية)", "ok", "بدون تأشيرة"),
    "arrival": ("تأشيرة عند الوصول (وقد تتوفر إلكترونيًا)", "warn", "تأشيرة عند الوصول"),
    "evisa": ("تأشيرة إلكترونية تُستخرج قبل السفر", "warn", "تأشيرة إلكترونية"),
    "required": ("تأشيرة مسبقة من السفارة أو مركز التقديم", "bad", "تأشيرة مسبقة"),
    "check": ("المصادر مختلفة، تأكد من السفارة قبل الحجز", "warn", "تأكد من السفارة"),
}
VERDICT = {
    "great": "سعر ممتاز! أرخص بحوالي {pct}% من المعتاد لهذا المسار",
    "good": "سعر جيد، أقل من المعتاد بحوالي {pct}%",
    "typical": "سعر عادي لهذا المسار",
    "high": "السعر مرتفع شوي مقارنة بباقي الأيام، جرّب تواريخ ثانية أو نبّهني في تيليجرام",
}
PROBLEMS = {"past": "هذا التاريخ فات أو قريب جدًا، اختر يوم من بكرة وما بعد", "far": "التاريخ بعيد، نبحث لمدة 11 شهر قدّام تقريبًا"}
NOTE_EXACT_MISS = "ما لقينا سعرًا محفوظًا لهذا اليوم بالضبط، فهذه أقرب الأسعار في نفس الشهر."
NOTE_ROUND_MISS = "ما لقينا سعرًا لهذه الأيام بالضبط، فهذه أقرب الأسعار حولها."
NOTE_WEEKEND_MISS = "ما لقينا رحلات ويكند بأسعار محفوظة لهذا المسار، فهذه أرخص الأيام بأي مدة."
HINT_MIN_SAVING = 60
HINT_MIN_SHARE = 0.06


class BadRequest(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code, self.message = code, message


@dataclass(frozen=True)
class Asset:
    body: bytes
    content_type: str
    etag: str
    cache: str

    def respond(self, request: Request) -> Response:
        headers = {"ETag": self.etag, "Cache-Control": self.cache}
        if request.headers.get("if-none-match") == self.etag:
            return Response(304, b"", self.content_type, headers)
        return Response(200, self.body, self.content_type, headers)


TYPES = {
    ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8",
    ".svg": "image/svg+xml", ".png": "image/png", ".txt": "text/plain; charset=utf-8",
    ".webmanifest": "application/manifest+json", ".xml": "application/xml; charset=utf-8",
}
TEXTUAL = (".html", ".webmanifest", ".txt", ".xml")


def _blocks(text: str, **on: bool) -> str:
    """Keep what sits between <!--NAME--> and <!--/NAME--> only when that name is switched on.

    SITE: the website's own address is known. NOSITE: it is not (a temporary address). CHANNEL: a Telegram channel is set."""
    for name, keep in on.items():
        text = re.sub(rf"<!--{name}-->(.*?)<!--/{name}-->", r"\1" if keep else "", text, flags=re.S)
    return text


def load_static(settings: WebSettings, directory: Path = STATIC_DIR) -> dict[str, Asset]:
    """Every file of the static folder, kept in memory. Visitors can reach only these names."""
    fill = {
        "{{VERSION}}": __version__, "{{BOT_URL}}": settings.bot_url,
        "{{CHANNEL_URL}}": settings.channel_url or settings.bot_url, "{{SITE}}": settings.site_url,
    }
    assets: dict[str, Asset] = {}
    for path in sorted(directory.iterdir()):
        kind = TYPES.get(path.suffix)
        if not path.is_file() or kind is None:
            continue
        body = path.read_bytes()
        if path.suffix in TEXTUAL:
            text = body.decode("utf-8")
            for key, value in fill.items():
                text = text.replace(key, value)
            body = _blocks(
                text, SITE=bool(settings.site_url), NOSITE=not settings.site_url, CHANNEL=bool(settings.channel_url)
            ).encode("utf-8")
            if not body.strip():
                continue                      # a file that only makes sense with the website's own address
        cache = "no-cache" if path.suffix in (".html", ".webmanifest", ".txt", ".xml") else "public, max-age=86400"
        asset = Asset(body, kind, 'W/"' + hashlib.sha1(body).hexdigest()[:20] + '"', cache)
        assets["/" + path.name] = asset
        if path.name == "index.html":
            assets["/"] = asset
    if "/" not in assets:
        raise FileNotFoundError("the website has no index.html")
    return assets


def sar(offer: Offer) -> float:
    """The ticket price in riyals (0 when it cannot be converted)."""
    return to_sar(offer.price, offer.currency) or 0.0


def _plain(label: str) -> str:
    """'📶 eSIM — Airalo' -> 'eSIM — Airalo' (the website draws its own icons)."""
    return re.sub(r"^[\W_]+", "", label)


def _visa(dest: data.Destination) -> dict:
    info = data.visa_for(dest.cc)
    label, level, short = VISA.get(info.status if info else "check", VISA["check"])
    return {"status": info.status if info else "check", "label": label, "short": short, "level": level, "free": texts.visa_ok(dest)}


def _dest_json(dest: data.Destination) -> dict:
    return {
        "iata": dest.iata, "name": dest.ar, "country": dest.country_ar, "cc": dest.cc, "flag": dest.flag,
        "tags": list(dest.tags), "visa": _visa(dest),
    }


def _stay_days(dep: str, back: str) -> int:
    try:
        return (date.fromisoformat(back) - date.fromisoformat(dep)).days
    except ValueError:
        return 0


class WebApp:
    def __init__(self, settings: WebSettings, tp: TravelpayoutsClient, *, clock=time.time, static: dict[str, Asset] | None = None):
        self.settings = settings
        self.tp = tp
        self.clock = clock
        self._static = static if static is not None else load_static(settings)
        self._gate = asyncio.Semaphore(GATE)
        self._routes = {
            "/api/meta": self.meta, "/api/understand": self.understand, "/api/dest": self.dest,
            "/api/calendar": self.calendar, "/api/day": self.day, "/api/cheap": self.cheap,
            "/api/weekend": self.weekend, "/go": self.go,
        }

    # ------------------------------------------------------------------
    # routing
    # ------------------------------------------------------------------
    async def handle(self, request: Request) -> Response:
        if request.path == "/healthz":
            return Response(200, b"ok", "text/plain; charset=utf-8", {"Cache-Control": "no-store"})
        asset = self._static.get(request.path)
        if asset is not None:
            return asset.respond(request)
        route = self._routes.get(request.path)
        if route is None:
            return error_response(404, "not_found", "الصفحة غير موجودة")
        try:
            await asyncio.wait_for(self._gate.acquire(), GATE_WAIT)
        except asyncio.TimeoutError:
            return error_response(503, "busy", "الخدمة مشغولة الآن، جرّب بعد قليل", {"Retry-After": "5"})
        try:
            return await route(request)
        except BadRequest as exc:
            return error_response(400, exc.code, exc.message)
        except TPError as exc:
            log.warning("web: provider problem: %s", exc)
            return error_response(503, "busy", "تعذّر جلب الأسعار الآن، جرّب بعد قليل", {"Retry-After": "10"})
        finally:
            self._gate.release()

    # ------------------------------------------------------------------
    # small helpers
    # ------------------------------------------------------------------
    def _today(self) -> date:
        return datetime.fromtimestamp(self.clock(), SAUDI_TZ).date()

    def _earliest(self) -> str:
        return (self._today() + timedelta(days=dts.MIN_AHEAD_DAYS)).isoformat()

    def _need_prices(self) -> None:
        if not self.tp.enabled:
            raise TPError("prices are switched off")

    @staticmethod
    def _origin(request: Request) -> str:
        origin = (request.query.get("o") or "RUH").upper()
        if origin not in ORIGINS:
            raise BadRequest("origin", "مدينة الانطلاق غير معروفة")
        return origin

    @staticmethod
    def _dest(request: Request) -> data.Destination:
        dest = data.by_iata().get((request.query.get("d") or "").upper())
        if dest is None:
            raise BadRequest("dest", "الوجهة غير معروفة")
        return dest

    @staticmethod
    def _stay(request: Request) -> int:
        raw = request.query.get("stay") or "0"
        if not raw.isdigit() or not (int(raw) == 0 or 2 <= int(raw) <= 30):
            raise BadRequest("stay", "مدة الرحلة غير صحيحة")
        return int(raw)

    def _month(self, request: Request, key: str = "m", *, required: bool = False) -> str | None:
        raw = request.query.get(key) or ""
        if not raw:
            if required:
                raise BadRequest("month", "الشهر مطلوب")
            return None
        if not ISO_MONTH.match(raw) or raw not in dts.month_choices(self._today(), CALENDAR_MONTHS):
            raise BadRequest("month", "الشهر غير صحيح أو خارج المدة المتاحة")
        return raw

    @staticmethod
    def _day(request: Request, key: str, *, required: bool = False) -> date | None:
        raw = request.query.get(key) or ""
        if not raw:
            if required:
                raise BadRequest("date", "التاريخ مطلوب")
            return None
        if not ISO_DAY.match(raw):
            raise BadRequest("date", "التاريخ غير صحيح")
        try:
            return date.fromisoformat(raw)
        except ValueError:
            raise BadRequest("date", "التاريخ غير صحيح") from None

    def _filters(self, request: Request) -> tuple[str | None, str | None, bool]:
        region = request.query.get("region") or None
        if region and region not in texts.REGION_LABELS:
            raise BadRequest("region", "المنطقة غير معروفة")
        tag = request.query.get("tag") or None
        if tag and tag not in texts.TAG_NAMES:
            raise BadRequest("tag", "النوع غير معروف")
        return region, tag, request.query.get("visa") == "1"

    @staticmethod
    def _wanted(dest: data.Destination, region, tag, visa_only) -> bool:
        if region and not data.in_region(dest, (region,)):
            return False
        if tag and tag not in dest.tags:
            return False
        return not (visa_only and not texts.visa_ok(dest))

    def _offer(self, o: Offer, origin: str, tier: str | None = None, index: int = 0) -> dict:
        dep, back = o.departure_at[:10], o.return_at[:10]
        out = {
            "date": dep, "ret": back, "price": round(sar(o)), "stay": _stay_days(dep, back) if back else 0,
            "airline": texts.AIRLINES.get(o.airline.upper(), o.airline), "stops": o.transfers,
            "stops_text": texts.stops_text(o.transfers), "duration": texts.fmt_duration(o.duration),
            "book": f"/go?o={origin}&d={o.destination}&date={dep}" + (f"&ret={back}" if back else "") + (f"&i={index}" if index else ""),
        }
        if tier:
            out["tier"] = tier
        return out

    # ------------------------------------------------------------------
    # /api/meta
    # ------------------------------------------------------------------
    async def meta(self, request: Request) -> Response:
        today = self._today()
        _, verified, _ = data.visa_table()
        payload = {
            "ok": True, "version": __version__, "prices": self.tp.enabled, "today": today.isoformat(),
            "min_date": (today + timedelta(days=dts.MIN_AHEAD_DAYS)).isoformat(),
            "max_date": (today + timedelta(days=dts.MAX_AHEAD_DAYS)).isoformat(),
            "origins": [{"code": c, "name": texts.ORIGIN_NAMES[c]} for c in ORIGINS],
            "destinations": [{**_dest_json(d), "en": d.en} for d in data.destinations()],
            "popular": [c for c in POPULAR if c in data.by_iata()],
            "regions": [{"key": k, "label": _plain(v)} for k, v in texts.REGION_LABELS.items()],
            "tags": [{"key": k, "label": v} for k, v in texts.TAG_NAMES.items()],
            "months": [{"key": k, "label": texts.month_label(k)} for k in dts.month_choices(today, CALENDAR_MONTHS)],
            "stays": list(STAYS), "visa_checked": verified,
            "links": {"bot": self.settings.bot_url, "channel": self.settings.channel_url},
        }
        return json_response(payload, cache="public, max-age=300")

    # ------------------------------------------------------------------
    # /api/understand: the same reading of free text as the Telegram bot
    # ------------------------------------------------------------------
    async def understand(self, request: Request) -> Response:
        text = (request.query.get("q") or "").strip()[:MAX_QUERY]
        if not text:
            raise BadRequest("query", "اكتب وجهتك أولًا")
        today = self._today()
        intent = data.understand(text, today)
        wish = intent.dates
        problem = dts.problem(wish, today) if wish.has_dates else None
        out: dict = {
            "ok": True, "origin": intent.origin, "dests": [d.iata for d in intent.destinations],
            "month": wish.month_key, "depart": wish.depart.isoformat() if wish.depart else "",
            "ret": wish.ret.isoformat() if wish.ret else "", "one_way": wish.one_way, "stay": wish.stay or 0,
            "weekend": wish.weekend, "regions": list(intent.regions), "tags": list(intent.tags),
            "problem": PROBLEMS.get(problem, "") if problem else "",
            "budget": intent.budget or 0, "ticket_only": bool(intent.ticket_only),
            "cap": (intent.budget if intent.ticket_only else round(intent.budget * TRIP_SHARE)) if intent.budget else 0,
        }
        if len(intent.destinations) == 1:
            out["kind"] = "dest"
        elif intent.destinations:
            out["kind"] = "choices"
        elif wish.weekend:
            out["kind"] = "weekend"
        elif intent.cheapest or intent.regions or intent.tags or intent.budget:
            out["kind"] = "cheap"
        elif data.bare_origin(text):
            out["kind"] = "origin"
            out["origin"] = data.bare_origin(text)
        else:
            near = data.suggest(intent.rest or text)
            out["kind"] = "suggest" if near else "none"
            out["suggest"] = [d.iata for d in near]
        return json_response(out)

    # ------------------------------------------------------------------
    # calendars
    # ------------------------------------------------------------------
    def _month_view(self, month: str, cal: dict[str, Offer]) -> dict:
        earliest = self._earliest()
        days = {d: o for d, o in cal.items() if d >= earliest and sar(o) > 0}
        prices = [sar(o) for o in days.values()]
        cuts = ins.tier_cuts(prices) if len(prices) >= 3 else None
        cheapest = min(prices) if prices else 0.0
        items = []
        for iso in sorted(days):
            o = days[iso]
            price = sar(o)
            tier = ins.tier_of(price, cuts) if cuts else ("low" if price <= cheapest else "mid")
            back = o.return_at[:10]
            items.append({
                "d": int(iso[8:10]), "p": round(price), "r": back, "n": _stay_days(iso, back) if back else 0, "t": tier,
                "a": texts.AIRLINES.get(o.airline.upper(), o.airline), "s": texts.stops_text(o.transfers), "u": texts.fmt_duration(o.duration),
            })
        best = min(days.values(), key=sar) if days else None
        return {
            "label": texts.month_label(month), "name": texts.MONTHS[int(month[5:]) - 1],
            "weeks": [[[d, 1 if ok else 0] for d, ok in week] for week in dts.month_grid(month, self._today())],
            "days": items,
            "best": {"date": best.departure_at[:10], "price": round(sar(best))} if best else None,
        }

    async def calendar(self, request: Request) -> Response:
        self._need_prices()
        origin, dest, stay = self._origin(request), self._dest(request), self._stay(request)
        month = self._month(request, required=True)
        weekend = request.query.get("weekend") == "1"
        cal = await self.tp.calendar(origin, dest.iata, month, stay=stay or None, weekend=weekend)
        return json_response({"ok": True, "month": month, **self._month_view(month, cal)}, cache="private, max-age=120")

    async def _services(self) -> list[dict]:
        if not self.tp.links_api:
            return []
        try:
            found = await self.tp.partner_links([p.url for p in data.partners()])
        except Exception:      # noqa: BLE001 - extras never break the answer
            return []
        return [{"id": p.id, "label": _plain(p.label), "go": f"/go?svc={p.id}"} for p in data.partners() if found.get(p.url)]

    async def dest(self, request: Request) -> Response:
        self._need_prices()
        origin, dest, stay = self._origin(request), self._dest(request), self._stay(request)
        weekend = request.query.get("weekend") == "1"
        months = dts.month_choices(self._today(), OVERVIEW_MONTHS)
        earliest = self._earliest()

        async def fetch(length: int, only_weekends: bool):
            cals = await self.tp.calendars(origin, dest.iata, months, stay=length or None, weekend=only_weekends)
            days = sorted(
                (o for cal in cals.values() for day, o in cal.items() if day >= earliest and sar(o) > 0), key=sar
            )
            return cals, days

        note = ""
        cals, days = await fetch(stay, weekend)
        if not days and stay and not weekend:
            cals, days = await fetch(0, False)
            if days:
                note = f"ما لقينا رحلات بمدة قريبة من {texts.days_text(stay)}، فهذه أرخص الأيام بأي مدة."
        if not days and weekend:
            cals, days = await fetch(stay, False)
            if days:
                note = NOTE_WEEKEND_MISS

        views = {m: self._month_view(m, cals[m]) for m in months if m in cals}
        tier_of_day = {f"{m}-{d['d']:02d}": d["t"] for m, v in views.items() for d in v["days"]}
        bars = []
        for m in months:
            view = views.get(m)
            if view and view["best"]:
                bars.append({"key": m, "name": view["name"], "price": view["best"]["price"]})
        if bars:
            low, high = min(b["price"] for b in bars), max(b["price"] for b in bars)
            for b in bars:
                b["bar"] = ins.bar_length(b["price"], low, high)
                b["best"] = len(bars) > 1 and b["price"] == low
        verdict = ins.verdict(sar(days[0]), [sar(o) for o in days]) if days else None
        official = data.visa_official(dest.cc)
        payload = {
            "ok": True, "origin": origin, "origin_name": texts.ORIGIN_NAMES[origin], "dest": _dest_json(dest),
            "stay": stay, "weekend": weekend, "note": note, "empty": not days,
            "visa_official": official or "", "visa_checked": data.visa_table()[1],
            "verdict": (
                {"level": verdict.level, "pct": verdict.saving, "typical": verdict.typical, "samples": verdict.samples,
                 "text": VERDICT[verdict.level].format(pct=abs(verdict.saving))}
                if verdict else None
            ),
            "top": [self._offer(o, origin, tier_of_day.get(o.departure_at[:10])) for o in days[:TOP_DAYS]],
            "months": bars, "calendars": views,
            "default_month": days[0].departure_at[:7] if days else months[0],
            "services": await self._services() if days else [],
            "bot": f"{self.settings.bot_url}?start=d_{dest.iata}",
        }
        return json_response(payload, cache="private, max-age=120")

    # ------------------------------------------------------------------
    # one exact day
    # ------------------------------------------------------------------
    async def day(self, request: Request) -> Response:
        self._need_prices()
        origin, dest = self._origin(request), self._dest(request)
        depart = self._day(request, "date", required=True)
        one_way = request.query.get("one_way") == "1"
        back = None if one_way else self._day(request, "ret")
        wish = dts.DateWish(depart=depart, ret=back, one_way=one_way)
        problem = dts.problem(wish, self._today())
        if problem or (back and back <= depart):
            raise BadRequest("date", PROBLEMS.get(problem or "", "تاريخ العودة لازم يكون بعد الذهاب"))
        month = depart.strftime("%Y-%m")
        offers = await self.tp.exact(origin, dest.iata, depart.isoformat(), back.isoformat() if back else None, one_way=one_way)
        offers = [o for o in offers if sar(o) > 0][:3]
        note, hint = "", None
        if not offers:
            cals = await self.tp.calendars(origin, dest.iata, [month], one_way=one_way)
            earliest = self._earliest()
            near = [o for cal in cals.values() for d, o in cal.items() if d >= earliest and sar(o) > 0]
            near.sort(key=lambda o: abs((date.fromisoformat(o.departure_at[:10]) - depart).days))
            offers = sorted(near[:DATE_ROWS], key=lambda o: o.departure_at)
            note = NOTE_ROUND_MISS if back else NOTE_EXACT_MISS
        else:
            hint = await self._cheaper_nearby(origin, dest, depart, back, one_way, month, offers[0])
        live = f"/go?o={origin}&d={dest.iata}&date={depart.isoformat()}" + (f"&ret={back.isoformat()}" if back else "") + "&live=1"
        payload = {
            "ok": True, "origin": origin, "origin_name": texts.ORIGIN_NAMES[origin], "dest": _dest_json(dest),
            "date": depart.isoformat(), "ret": back.isoformat() if back else "", "exact": bool(offers) and not note,
            "offers": [self._offer(o, origin, index=i) for i, o in enumerate(offers)],
            "note": note, "hint": hint, "live": live,
            "bot": f"{self.settings.bot_url}?start=d_{dest.iata}_{depart.strftime('%Y%m%d')}"
                   + (f"_{back.strftime('%Y%m%d')}" if back else ("_o" if one_way else "")),
        }
        return json_response(payload, cache="private, max-age=120")

    async def _cheaper_nearby(self, origin, dest, depart: date, back: date | None, one_way: bool, month: str, best: Offer) -> dict | None:
        length = (back - depart).days if back and not one_way else None
        try:
            cals = await self.tp.calendars(origin, dest.iata, [month], one_way=one_way, stay=length if length and length >= 2 else None)
        except TPError:
            return None
        earliest, here = self._earliest(), depart.isoformat()
        others = [o for d, o in cals.get(month, {}).items() if d >= earliest and d != here and sar(o) > 0]
        if not others:
            return None
        cheapest = min(others, key=sar)
        saving = round(sar(best) - sar(cheapest))
        if saving >= max(HINT_MIN_SAVING, sar(best) * HINT_MIN_SHARE):
            return {**self._offer(cheapest, origin), "saving": saving}
        return None

    # ------------------------------------------------------------------
    # lists: cheapest places and weekend trips
    # ------------------------------------------------------------------
    @staticmethod
    def _cap(request: Request) -> int:
        raw = request.query.get("max") or ""
        if not raw:
            return 0
        if not raw.isdigit() or not MIN_CAP <= int(raw) <= MAX_CAP:
            raise BadRequest("max", "الحد الأعلى للسعر غير صحيح")
        return int(raw)

    def _rows(self, offers: dict[str, Offer], region, tag, visa_only, cap: int = 0) -> tuple[list[dict], bool]:
        """The cheapest places, and whether none of them is within the wished price (then the cheapest are shown anyway)."""
        rows = []
        for dest in data.destinations():
            offer = offers.get(dest.iata)
            if offer is None or not self._wanted(dest, region, tag, visa_only):
                continue
            price = to_sar(offer.price, offer.currency)
            if price is None or price <= 0:
                continue
            rows.append((price, dest, offer))
        rows.sort(key=lambda r: r[0])
        within = [r for r in rows if r[0] <= cap] if cap else rows
        over = bool(cap and rows and not within)
        chosen = (within or rows)[:LIST_SIZE]
        return [
            {**_dest_json(d), "price": round(p), "date": o.departure_at[:10], "ret": o.return_at[:10]}
            for p, d, o in chosen
        ], over

    async def cheap(self, request: Request) -> Response:
        self._need_prices()
        origin = self._origin(request)
        region, tag, visa_only = self._filters(request)
        cap = self._cap(request)
        month = self._month(request)
        months = [month] if month else month_keys(self.clock() + HORIZON_SHIFT, 3)
        offers = await self.tp.cheapest_from(origin, months)
        offers = {k: o for k, o in offers.items() if to_sar(o.price, o.currency) is not None}
        items, over = self._rows(offers, region, tag, visa_only, cap)
        return json_response(
            {"ok": True, "origin": origin, "origin_name": texts.ORIGIN_NAMES[origin], "items": items, "cap": cap, "over": over},
            cache="private, max-age=120",
        )

    async def weekend(self, request: Request) -> Response:
        self._need_prices()
        origin = self._origin(request)
        region, tag, visa_only = self._filters(request)
        cap = self._cap(request)
        pending = False
        try:
            deals = await self.tp.weekend_deals(
                origin, month_keys(self.clock() + 86400, WEEKEND_MONTHS), self._earliest(),
                known=frozenset(data.by_iata()), extra=data.weekend_destinations(),
            )
        except TPError as exc:
            if "still loading" not in str(exc):
                raise
            deals, pending = {}, True
        pending = pending or self.tp.weekend_pending > 0
        items, over = self._rows(deals, region, tag, visa_only, cap)
        return json_response(
            {"ok": True, "origin": origin, "origin_name": texts.ORIGIN_NAMES[origin], "pending": pending,
             "items": items, "cap": cap, "over": over},
            cache="no-store" if pending else "private, max-age=120",
        )

    # ------------------------------------------------------------------
    # /go: the booking button. The partner link is made now, for this click only.
    # ------------------------------------------------------------------
    @staticmethod
    def _allowed(url: str) -> bool:
        parts = urlsplit(url)
        host = (parts.hostname or "").lower()
        return parts.scheme == "https" and any(host == h or host.endswith("." + h) for h in REDIRECT_HOSTS)

    @staticmethod
    def _redirect(url: str) -> Response:
        return Response(302, b"", "text/plain; charset=utf-8", {"Location": url, "Cache-Control": "no-store", "Referrer-Policy": "no-referrer"})

    async def go(self, request: Request) -> Response:
        service = request.query.get("svc")
        if service:
            partner = next((p for p in data.partners() if p.id == service), None)
            link = (await self.tp.partner_links([partner.url])).get(partner.url) if partner else None
            if not link or not self._allowed(link):
                return error_response(404, "not_found", "الخدمة غير متاحة الآن")
            return self._redirect(link)
        self._need_prices()
        origin, dest = self._origin(request), self._dest(request)
        depart = self._day(request, "date", required=True)
        back = self._day(request, "ret")
        if dts.problem(dts.DateWish(depart=depart, ret=back), self._today()) or (back and back <= depart):
            raise BadRequest("date", "التاريخ غير صحيح")
        index = int(request.query.get("i") or 0) if (request.query.get("i") or "0").isdigit() else 0
        offers: list[Offer] = []
        if request.query.get("live") != "1":
            found = await self.tp.exact(origin, dest.iata, depart.isoformat(), back.isoformat() if back else None, one_way=back is None)
            offers = [o for o in found if sar(o) > 0 and o.link]
        if offers:
            url = await self.tp.booking_url(offers[min(index, len(offers) - 1)])
        else:
            plain = self.tp.search_url(origin, dest.iata, depart, back)
            url = (await self.tp.partner_links([plain], marker_fallback=True)).get(plain) or plain
        if not self._allowed(url):
            url = with_marker(self.tp.search_url(origin, dest.iata, depart, back), self.tp.marker)
        return self._redirect(url)
