"""The website's HTTP server: a small, strict HTTP/1.1 server on asyncio (standard library only).

It faces the internet, so it answers GET and HEAD only, closes every connection after one answer, and puts a
limit on the size and the time of everything. It never logs addresses or query strings and keeps nothing on disk."""
from __future__ import annotations

import asyncio
import contextlib
import email.utils
import gzip
import ipaddress
import json
import logging
import re
import time
from dataclasses import dataclass, field
from typing import Awaitable, Callable
from urllib.parse import parse_qsl, urlsplit

log = logging.getLogger("safrati.web")

MAX_HEAD = 16 * 1024            # bytes of request line and headers
MAX_HEADERS = 64
MAX_QUERY_FIELDS = 24
MAX_VALUE = 300                 # characters of one query value
READ_TIMEOUT = 10.0
WRITE_TIMEOUT = 15.0
HANDLER_TIMEOUT = 28.0
MAX_CONNECTIONS = 256
MAX_TRACKED_CLIENTS = 20000
GZIP_MIN = 1024                 # smaller answers are sent as they are
GZIP_TYPES = ("text/", "application/json", "application/manifest+json", "application/xml", "image/svg+xml")

REASONS = {
    200: "OK", 204: "No Content", 302: "Found", 304: "Not Modified", 400: "Bad Request", 404: "Not Found",
    405: "Method Not Allowed", 408: "Request Timeout", 429: "Too Many Requests", 431: "Request Header Fields Too Large",
    500: "Internal Server Error", 503: "Service Unavailable", 504: "Gateway Timeout",
}

SECURITY_HEADERS = {
    "Content-Security-Policy": (
        "default-src 'none'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; "
        "font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; manifest-src 'self'; "
        "base-uri 'none'; form-action 'self'; frame-ancestors 'none'"
    ),
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "geolocation=(), camera=(), microphone=(), payment=(), usb=()",
    "Cross-Origin-Opener-Policy": "same-origin",
    "Strict-Transport-Security": "max-age=15552000",       # browsers use it on https only; the website is always opened through https
}

_REQUEST_LINE = re.compile(r"^([A-Z]{3,10}) (\S{1,2048}) HTTP/1\.[01]$")
_LOGGABLE_PATH = re.compile(r"^[A-Za-z0-9._/-]{1,60}$")      # anything else is shown as "(other)": a visitor cannot write into the log
_HEADER_LINE = re.compile(r"^([!#$%&'*+.^_`|~0-9A-Za-z-]{1,60}):[ \t]*(.{0,4000}?)[ \t]*$")


@dataclass
class Request:
    method: str
    path: str
    query: dict[str, str]
    headers: dict[str, str]
    ip: str = ""


@dataclass
class Response:
    status: int = 200
    body: bytes = b""
    content_type: str = "application/json; charset=utf-8"
    headers: dict[str, str] = field(default_factory=dict)


Handler = Callable[[Request], Awaitable[Response]]


def json_response(payload: dict, status: int = 200, *, cache: str = "no-store", headers: dict | None = None) -> Response:
    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return Response(status, body, headers={"Cache-Control": cache, **(headers or {})})


def error_response(status: int, code: str, message: str, headers: dict | None = None) -> Response:
    return json_response({"ok": False, "error": code, "message": message}, status, headers=headers)


class RateLimiter:
    """A token bucket for each visitor. It remembers a bounded number of visitors, in memory only."""

    def __init__(self, per_minute: float, burst: float, clock: Callable[[], float] = time.monotonic):
        self.rate = per_minute / 60.0
        self.burst = float(burst)
        self._clock = clock
        self._buckets: dict[str, tuple[float, float]] = {}

    def take(self, key: str, cost: float = 1.0) -> float:
        """0.0 when allowed, otherwise the seconds to wait."""
        now = self._clock()
        tokens, last = self._buckets.pop(key, (self.burst, now))
        tokens = min(self.burst, tokens + (now - last) * self.rate)
        if tokens >= cost:
            self._buckets[key] = (tokens - cost, now)
            wait = 0.0
        else:
            self._buckets[key] = (tokens, now)
            wait = (cost - tokens) / self.rate
        while len(self._buckets) > MAX_TRACKED_CLIENTS:
            self._buckets.pop(next(iter(self._buckets)))     # the one not seen for the longest time
        return wait


def client_key(ip: str) -> str:
    """One key for one visitor; an IPv6 visitor is counted by its /64 block, because a person gets billions of addresses."""
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return ip[:64]
    if isinstance(addr, ipaddress.IPv6Address):
        if addr.ipv4_mapped:
            return str(addr.ipv4_mapped)
        return str(ipaddress.ip_network((addr, 64), strict=False))
    return str(addr)


def parse_request(head: bytes, peer: str, real_ip_header: str = "") -> Request | Response:
    """The request, or the error response to send."""
    try:
        text = head.decode("latin-1")
    except UnicodeDecodeError:       # latin-1 never fails; kept for clarity
        return error_response(400, "bad_request", "طلب غير صحيح")
    lines = text.split("\r\n")
    match = _REQUEST_LINE.match(lines[0])
    if not match:
        return error_response(400, "bad_request", "طلب غير صحيح")
    method, target = match.group(1), match.group(2)
    headers: dict[str, str] = {}
    for line in lines[1:]:
        if not line:
            continue
        found = _HEADER_LINE.match(line)
        if not found or len(headers) >= MAX_HEADERS:
            return error_response(400, "bad_request", "طلب غير صحيح")
        headers.setdefault(found.group(1).lower(), found.group(2))
    if method not in ("GET", "HEAD"):
        return error_response(405, "method", "الطريقة غير مسموحة", {"Allow": "GET, HEAD"})
    if not target.startswith("/") or target.startswith("//"):
        return error_response(400, "bad_request", "طلب غير صحيح")
    try:
        parts = urlsplit(target)
        pairs = parse_qsl(parts.query, keep_blank_values=True, max_num_fields=MAX_QUERY_FIELDS, encoding="utf-8", errors="replace")
    except ValueError:
        return error_response(400, "bad_request", "طلب غير صحيح")
    query = {k[:40]: v[:MAX_VALUE] for k, v in pairs}
    ip = peer
    if real_ip_header and headers.get(real_ip_header):
        ip = headers[real_ip_header].split(",")[0].strip()[:64] or peer
    return Request(method, parts.path, query, headers, ip)


class WebServer:
    def __init__(
        self, handler: Handler, *, real_ip_header: str = "", api_per_minute: int = 60,
        static_per_minute: int = 240, clock: Callable[[], float] = time.monotonic,
    ):
        self._handler = handler
        self._real_ip_header = real_ip_header.lower()
        self._api_limit = RateLimiter(api_per_minute, burst=max(10, api_per_minute // 2), clock=clock)
        self._static_limit = RateLimiter(static_per_minute, burst=60, clock=clock)
        self._open = 0
        self._server: asyncio.AbstractServer | None = None
        self.stats = {"served": 0, "limited": 0, "errors": 0}

    async def start(self, host: str, port: int) -> int:
        self._server = await asyncio.start_server(self._client, host, port, limit=MAX_HEAD, backlog=128)
        return self.port

    @property
    def port(self) -> int:
        return self._server.sockets[0].getsockname()[1] if self._server and self._server.sockets else 0

    async def close(self) -> None:
        if self._server:
            self._server.close()
            await self._server.wait_closed()

    # ---- one connection ----------------------------------------------------------------
    async def _client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        if self._open >= MAX_CONNECTIONS:
            writer.close()
            return
        self._open += 1
        try:
            await asyncio.wait_for(self._exchange(reader, writer), READ_TIMEOUT + HANDLER_TIMEOUT + WRITE_TIMEOUT)
        except (asyncio.TimeoutError, ConnectionError, asyncio.IncompleteReadError, OSError):
            pass
        except Exception:      # noqa: BLE001 - one bad connection must never stop the server
            self.stats["errors"] += 1
            log.exception("web: unexpected error")
        finally:
            self._open -= 1
            writer.close()
            with contextlib.suppress(Exception):
                await asyncio.wait_for(writer.wait_closed(), 2)

    async def _exchange(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        started = time.monotonic()
        peer = (writer.get_extra_info("peername") or ("",))[0]
        try:
            head = await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), READ_TIMEOUT)
        except asyncio.LimitOverrunError:
            await self._send(writer, error_response(431, "too_large", "الطلب كبير"), False)
            return
        parsed = parse_request(head, peer, self._real_ip_header)
        if isinstance(parsed, Response):
            await self._send(writer, parsed, False)
            return
        request = parsed
        is_api = request.path.startswith("/api/") or request.path == "/go"
        limiter = self._api_limit if is_api else self._static_limit
        wait = limiter.take(client_key(request.ip))
        if wait > 0:
            self.stats["limited"] += 1
            response = error_response(
                429, "rate_limited", "طلبات كثيرة، انتظر قليلًا ثم جرّب", {"Retry-After": str(int(wait) + 1)}
            )
        else:
            try:
                response = await asyncio.wait_for(self._handler(request), HANDLER_TIMEOUT)
            except asyncio.TimeoutError:
                response = error_response(504, "timeout", "الخدمة بطيئة الآن، جرّب بعد قليل")
            except Exception:      # noqa: BLE001
                self.stats["errors"] += 1
                log.exception("web: handler failed")
                response = error_response(500, "internal", "حدث خطأ، جرّب بعد قليل")
        self.stats["served"] += 1
        await self._send(writer, response, request.method == "HEAD", "gzip" in request.headers.get("accept-encoding", "").lower())
        level = logging.INFO if is_api else logging.DEBUG
        shown = request.path if _LOGGABLE_PATH.match(request.path) else "(other)"
        log.log(level, "%s %s %d %dms", request.method, shown, response.status, (time.monotonic() - started) * 1000)

    async def _send(self, writer: asyncio.StreamWriter, response: Response, head_only: bool, gzip_ok: bool = False) -> None:
        body, extra = response.body, {}
        if gzip_ok and response.status == 200 and len(body) >= GZIP_MIN and response.content_type.startswith(GZIP_TYPES):
            body, extra = gzip.compress(body, 5, mtime=0), {"Content-Encoding": "gzip"}
        headers = {
            **SECURITY_HEADERS,
            "Content-Type": response.content_type,
            "Content-Length": str(len(body)),
            "Connection": "close",
            "Date": email.utils.formatdate(usegmt=True),
            "Vary": "Accept-Encoding",
            **extra,
            **response.headers,
        }
        lines = [f"HTTP/1.1 {response.status} {REASONS.get(response.status, 'OK')}"]
        lines += [f"{k}: {v}" for k, v in headers.items() if "\r" not in v and "\n" not in v]
        raw = ("\r\n".join(lines) + "\r\n\r\n").encode("latin-1", "replace")
        writer.write(raw if head_only or response.status == 304 else raw + body)
        await asyncio.wait_for(writer.drain(), WRITE_TIMEOUT)
