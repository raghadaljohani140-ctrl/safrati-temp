"""Run the website:  python -m safrati.web      Docker health check:  python -m safrati.web --check"""
from __future__ import annotations

import asyncio
import logging
import signal
import sys
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from typing import Callable

from ..config import ConfigError
from ..logsafe import ScrubbingFormatter
from ..tp import TravelpayoutsClient, _urllib_transport
from .api import WebApp
from .budget import Budget
from .server import WebServer
from .settings import WebSettings, load_web_settings

log = logging.getLogger("safrati.web")

LEVELS = {
    "DEBUG": logging.DEBUG, "INFO": logging.INFO, "WARN": logging.WARNING, "WARNING": logging.WARNING,
    "ERROR": logging.ERROR, "CRITICAL": logging.CRITICAL, "FATAL": logging.CRITICAL,
}


def setup_logging(settings: WebSettings) -> None:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(
        ScrubbingFormatter([settings.tp_token], "%(asctime)s %(levelname)s %(name)s: %(message)s")
    )
    root = logging.getLogger()
    root.handlers[:] = [handler]
    root.setLevel(LEVELS.get(settings.log_level, logging.INFO))      # an unknown word never stops the start
    logging.getLogger("asyncio").setLevel(logging.WARNING)


def check(settings: WebSettings) -> int:
    """Exit code 0 when the website answers."""
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{settings.port}/healthz", timeout=5) as resp:
            return 0 if resp.status == 200 else 1
    except Exception:      # noqa: BLE001
        return 1


async def serve(settings: WebSettings, *, stop: asyncio.Event | None = None, on_start: Callable[[int], None] | None = None) -> int:
    """Run until SIGTERM / SIGINT (or until `stop` is set, which is how the tests end it)."""
    budget = Budget(settings.upstream_per_minute)
    tp = TravelpayoutsClient(
        settings.tp_token, settings.tp_marker, settings.tp_trs, settings.currency,
        market=settings.tp_market, show_all=settings.tp_show_all, cache_seconds=settings.cache_minutes * 60,
        transport=budget.wrap(_urllib_transport),
    )
    app = WebApp(settings, tp)
    server = WebServer(app.handle, real_ip_header=settings.real_ip_header, api_per_minute=settings.rate_per_minute)
    port = await server.start(settings.host, settings.port)
    log.info(
        "website started on port %d | prices=%s partner_links=%s market=%s",
        port, "on" if tp.enabled else "off", "on" if tp.links_api else "off", tp.market or "auto",
    )
    loop = asyncio.get_running_loop()
    loop.set_default_executor(ThreadPoolExecutor(max_workers=12, thread_name_prefix="web"))
    if stop is None:
        stop = asyncio.Event()
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(sig, stop.set)
    if on_start:
        on_start(port)
    await stop.wait()
    await server.close()
    log.info("website stopped")
    return 0


def main() -> None:
    try:
        settings = load_web_settings()
    except ConfigError as exc:
        print(f"configuration error: {exc}", file=sys.stderr)
        sys.exit(2)
    if "--check" in sys.argv:
        sys.exit(check(settings))
    setup_logging(settings)
    sys.exit(asyncio.run(serve(settings)))


if __name__ == "__main__":
    main()
