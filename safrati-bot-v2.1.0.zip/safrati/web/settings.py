"""Settings of the website. It runs in its own container: it needs the price token, never the Telegram bot token."""
from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Mapping

from ..config import CHANNEL_URL_RE, ConfigError, _int

BOT_NAME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]{4,31}$")
SITE_URL_RE = re.compile(r"^https://[A-Za-z0-9.-]{3,100}$")
HEADER_RE = re.compile(r"^[A-Za-z0-9-]{1,40}$")


@dataclass(frozen=True)
class WebSettings:
    tp_token: str = ""
    tp_marker: str = ""
    tp_trs: str = ""
    currency: str = "sar"
    tp_market: str = ""
    tp_show_all: bool = False
    cache_minutes: int = 30
    channel_url: str = ""
    bot_username: str = "SafratiTravel_bot"
    host: str = "0.0.0.0"
    port: int = 8088
    real_ip_header: str = ""       # e.g. CF-Connecting-IP behind a Cloudflare tunnel; empty = use the connection's own address
    rate_per_minute: int = 60      # price lookups one visitor may start per minute
    upstream_per_minute: int = 240  # price-provider calls the whole website may make per minute (the bot shares the account's allowance)
    site_url: str = ""             # https://your-domain, optional
    log_level: str = "INFO"

    @property
    def bot_url(self) -> str:
        return f"https://t.me/{self.bot_username}"


def load_web_settings(env: Mapping[str, str] | None = None) -> WebSettings:
    env = os.environ if env is None else env
    marker = (env.get("TP_MARKER") or "").strip()
    trs = (env.get("TP_TRS") or "").strip()
    if marker and not marker.isdigit():
        raise ConfigError("TP_MARKER must be digits only")
    if trs and not trs.isdigit():
        raise ConfigError("TP_TRS must be digits only")
    currency = (env.get("CURRENCY") or "sar").strip().lower()
    if not re.fullmatch(r"[a-z]{3}", currency):
        raise ConfigError("CURRENCY must be a 3-letter code such as sar or usd")
    market = (env.get("TP_MARKET") or "").strip().lower()
    if market and not re.fullmatch(r"[a-z]{2}", market):
        raise ConfigError("TP_MARKET must be a 2-letter code or empty")
    channel = (env.get("CHANNEL_URL") or "").strip()
    if channel and not CHANNEL_URL_RE.match(channel):
        raise ConfigError("CHANNEL_URL must look like https://t.me/name")
    bot = (env.get("BOT_USERNAME") or "SafratiTravel_bot").strip().lstrip("@")
    if not BOT_NAME_RE.match(bot):
        raise ConfigError("BOT_USERNAME must be the bot's Telegram username")
    site = (env.get("WEB_SITE_URL") or "").strip().rstrip("/")
    if site and not SITE_URL_RE.match(site):
        raise ConfigError("WEB_SITE_URL must look like https://example.com")
    header = (env.get("WEB_REAL_IP_HEADER") or "").strip().lower()
    if header and not HEADER_RE.match(header):
        raise ConfigError("WEB_REAL_IP_HEADER must be a header name such as CF-Connecting-IP")
    return WebSettings(
        tp_token=(env.get("TP_TOKEN") or "").strip(),
        tp_marker=marker,
        tp_trs=trs,
        currency=currency,
        tp_market=market,
        tp_show_all=(env.get("TP_SHOW_ALL") or "").strip().lower() in ("1", "true", "yes"),
        cache_minutes=_int(env, "CACHE_MINUTES", 30, 1, 1440),
        channel_url=channel,
        bot_username=bot,
        host=(env.get("WEB_HOST") or "0.0.0.0").strip(),
        port=_int(env, "WEB_PORT", 8088, 1, 65535),
        real_ip_header=header,
        rate_per_minute=_int(env, "WEB_RATE_PER_MINUTE", 60, 5, 6000),
        upstream_per_minute=_int(env, "WEB_UPSTREAM_PER_MINUTE", 240, 30, 600),
        site_url=site,
        log_level=(env.get("LOG_LEVEL") or "INFO").strip().upper(),
    )
