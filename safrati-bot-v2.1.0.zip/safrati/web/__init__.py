"""The Safrati website: the same price engine as the Telegram bot, for visitors with a browser."""
