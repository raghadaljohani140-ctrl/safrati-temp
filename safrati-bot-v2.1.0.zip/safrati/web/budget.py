"""One shared allowance of price-provider calls for the whole website.

The Telegram bot uses the same provider account, so a crowd of visitors must not be able to use up its allowance:
when the website's share is spent, lookups fail fast (the website then answers "busy") instead of reaching the provider."""
from __future__ import annotations

import threading
import time
from typing import Callable

from ..tp import TPError


class Budget:
    def __init__(self, per_minute: int, burst: int | None = None, clock: Callable[[], float] = time.monotonic):
        self.rate = per_minute / 60.0
        self.burst = float(burst if burst is not None else max(20, per_minute // 4))
        self._clock = clock
        self._tokens = self.burst
        self._last = clock()
        self._lock = threading.Lock()       # the provider is called from worker threads
        self.refused = 0

    def take(self) -> bool:
        with self._lock:
            now = self._clock()
            self._tokens = min(self.burst, self._tokens + (now - self._last) * self.rate)
            self._last = now
            if self._tokens >= 1.0:
                self._tokens -= 1.0
                return True
            self.refused += 1
            return False

    def wrap(self, transport):
        """A provider transport that spends from this budget before every call."""

        def guarded(method, url, headers, body, timeout):
            if not self.take():
                raise TPError("website budget reached")
            return transport(method, url, headers, body, timeout)

        return guarded
