"""Bot logic: understands the user's message, finds prices, answers with cards and buttons."""
from __future__ import annotations

import asyncio
import calendar
import collections
import contextlib
import dataclasses
import hmac
import logging
import random
import time
import urllib.parse
from datetime import date, datetime, timedelta
from pathlib import Path

from . import data, texts
from . import dates as dts
from .alerts import AlertsMixin
from .channel import ChannelMixin
from .config import Settings
from .db import DB, ORIGINS, SAUDI_TZ
from .market import MarketMixin
from .telegram import TelegramAPI, TelegramError, button, keyboard
from .tp import Offer, TPError, TravelpayoutsClient, month_keys, to_sar, with_marker
from .trip import TripMixin, parse_trip_payload
from .ui import STAYS, TRIP_LENGTHS, chunk, footer, strip_url_buttons, swap_button

log = logging.getLogger("safrati.app")

TRIP_SHARE = 0.4           # part of a whole-trip budget that may go to the flight ticket
LIST_SIZE = 5
HORIZON_SHIFT = 7 * 86400  # skip flights leaving in the next few days
MAX_TEXT = 300
MAX_CHOICES = 6
MAX_SAVED = 30
POLL_TIMEOUT = 20
RATE_WINDOW = 60.0      # seconds
RATE_MAX = 30           # updates one person may send inside the window
MAX_TRACKED = 20000
CHEAP_SIZE = 8
WEEKEND_MONTHS = 2
REGION_ROWS = (("all", "arab", "caucasus"), ("asia", "europe", "africa"))

TAG_CODE = {
    "beach": "b", "mountains": "m", "nature": "n", "shopping": "s", "calm": "c",
    "adventure": "a", "food": "f", "family": "y", "culture": "u",
}
CODE_TAG = {v: k for k, v in TAG_CODE.items()}
MOODS = ("beach", "mountains", "nature", "shopping", "calm", "adventure")

POPULAR = ("DXB", "IST", "CAI", "LON", "PAR", "KUL", "BKK", "TBS")

COMMANDS = [
    ("start", "القائمة الرئيسية"),
    ("search", "ابحث عن رحلة"),
    ("cheap", "أرخص الرحلات الآن"),
    ("weekend", "أرخص رحلات الويكند"),
    ("alerts", "تنبيهات الأسعار"),
    ("surprise", "فاجئني"),
    ("saved", "وجهاتي المحفوظة"),
    ("settings", "الإعدادات"),
    ("about", "عن البوت"),
    ("privacy", "الخصوصية"),
]

Candidate = tuple  # (Destination, Offer | None, sar | None)


def _codes(tags) -> str:
    return "".join(TAG_CODE[t] for t in tags if t in TAG_CODE)


def _tags(codes: str) -> tuple[str, ...]:
    return tuple(CODE_TAG[c] for c in codes if c in CODE_TAG)


# kept under their old names for the tests and for readability inside this module
_strip_url_buttons = strip_url_buttons
_swap_button = swap_button
_footer = footer


class SafratiBot(TripMixin, AlertsMixin, ChannelMixin, MarketMixin):
    def __init__(
        self,
        settings: Settings,
        api: TelegramAPI,
        db: DB,
        tp: TravelpayoutsClient,
        *,
        bot_username: str = "",
        bot_id: int = 0,
        clock=time.time,
        rng: random.Random | None = None,
    ):
        self.settings = settings
        self.api = api
        self.db = db
        self.tp = tp
        self.bot_username = bot_username
        self.bot_id = bot_id
        self.clock = clock
        self.rng = rng or random.Random()
        self._locks: dict[int, asyncio.Lock] = {}
        self._sem = asyncio.Semaphore(8)
        self._tasks: set[asyncio.Task] = set()
        self._admin_fails: dict[int, list[float]] = {}
        self._last_list: dict[int, list[str]] = {}
        self._last_wish: dict[int, dts.DateWish] = {}
        self._last_dest: dict[int, str] = {}
        self._pending: dict[int, tuple[int, float]] = {}      # person -> (alert waiting for a target price, deadline)
        self._draft: tuple[str, dict, str] | None = None      # the deals post an admin is looking at
        self._hits: dict[int, collections.deque] = {}
        self.rate_max = RATE_MAX
        self.apply_saved_market()

    # ------------------------------------------------------------------
    # sending
    # ------------------------------------------------------------------
    async def say(self, chat_id: int, text: str, markup: dict | None = None) -> None:
        try:
            await self.api.send_message(chat_id, text, markup)
        except TelegramError as exc:
            if exc.status == 400 and markup and "BUTTON_URL" in str(exc).upper():
                log.warning("a booking button url was rejected by Telegram; sending without it")
                await self.api.send_message(chat_id, text, strip_url_buttons(markup))
                return
            raise

    async def show(self, chat_id: int, text: str, markup: dict | None, edit_mid: int | None) -> None:
        """Edit the message in place when possible, otherwise send a new one."""
        if edit_mid is not None:
            try:
                await self.api.edit_message(chat_id, edit_mid, text, markup)
                return
            except TelegramError as exc:
                log.info("edit failed (%s); sending a new message", exc.status)
        await self.say(chat_id, text, markup)

    def menu_markup(self) -> dict:
        rows = [
            [button("✈️ ابحث عن رحلة", data="go")],
            [button("🔥 أرخص الآن", data="cheap"), button("🌙 ويكند", data="we")],
            [button("🎲 فاجئني", data="sur"), button("💰 حسب ميزانيتي", data="bp")],
            [button("🔔 تنبيهاتي", data="al"), button("⭐ محفوظاتي", data="sl")],
        ]
        last = [button("⚙️ الإعدادات", data="st")]
        if self.bot_username:
            link = "https://t.me/" + self.bot_username
            text = "سفرتي ✈️ أرخص رحلات الطيران بتقويم أسعار وتنبيهات"
            share = "https://t.me/share/url?url=" + urllib.parse.quote(link, safe="") + "&text=" + urllib.parse.quote(text, safe="")
            last.append(button("📣 شارك البوت", url=share))
        rows.append(last)
        if self.settings.channel_url:
            rows.append([button("📢 قناة سفرتي", url=self.settings.channel_url)])
        return keyboard(rows)

    async def send_welcome(self, chat_id: int) -> None:
        await self.say(chat_id, texts.WELCOME, self.menu_markup())

    async def send_menu(self, chat_id: int) -> None:
        await self.say(chat_id, texts.MENU_PROMPT, self.menu_markup())

    def onboarding_markup(self, payload: str = "") -> dict:
        tail = (":" + payload) if payload else ""
        buttons = [button(texts.ORIGIN_NAMES[code], data=f"ob:{code}{tail}") for code in ORIGINS]
        return keyboard(chunk(buttons, 3))

    # ------------------------------------------------------------------
    # update plumbing
    # ------------------------------------------------------------------
    @staticmethod
    def _user_id(update: dict) -> int | None:
        node = update.get("callback_query") or update.get("message") or {}
        uid = (node.get("from") or {}).get("id")
        return uid if isinstance(uid, int) else None

    def _limited(self, uid: int) -> bool:
        """True when this person is sending too fast (checked before any work is done)."""
        now = time.monotonic()
        window = self._hits.setdefault(uid, collections.deque())
        while window and now - window[0] > RATE_WINDOW:
            window.popleft()
        if len(window) >= self.rate_max:
            return True
        window.append(now)
        if len(self._hits) > MAX_TRACKED:
            for key in [k for k, v in self._hits.items() if not v or now - v[-1] > RATE_WINDOW]:
                self._hits.pop(key, None)
        return False

    def _set_last(self, uid: int, iatas: list[str]) -> None:
        if len(self._last_list) > MAX_TRACKED:
            self._last_list.clear()
        self._last_list[uid] = iatas

    async def process(self, update: dict) -> None:
        uid = self._user_id(update)
        if uid is None:
            return
        if self._limited(uid):
            callback = update.get("callback_query")
            if callback:
                await self.api.answer_callback(str(callback.get("id") or ""))
            return
        lock = self._locks.setdefault(uid, asyncio.Lock())
        async with self._sem, lock:
            try:
                await self._dispatch(update)
            except TelegramError as exc:
                level = logging.INFO if exc.status in (400, 403) else logging.WARNING
                log.log(level, "telegram call failed: %s", exc)
            except Exception:  # noqa: BLE001 - one bad update must never stop the bot
                log.exception("update failed")
                await self._apologize(update)
        if len(self._locks) > 5000:
            for key in [k for k, v in self._locks.items() if not v.locked()]:
                self._locks.pop(key, None)
        if len(self._pending) > MAX_TRACKED:
            self._pending.clear()

    async def _apologize(self, update: dict) -> None:
        node = update.get("callback_query", {}).get("message") or update.get("message") or {}
        chat_id = (node.get("chat") or {}).get("id")
        if chat_id is None:
            return
        with contextlib.suppress(TelegramError):
            await self.api.send_message(chat_id, texts.ERROR)

    async def _dispatch(self, update: dict) -> None:
        if update.get("callback_query"):
            await self.on_callback(update["callback_query"])
        elif update.get("message"):
            await self.on_message(update["message"])

    # ------------------------------------------------------------------
    # messages
    # ------------------------------------------------------------------
    async def on_message(self, msg: dict) -> None:
        chat = msg.get("chat") or {}
        sender = msg.get("from") or {}
        if chat.get("type") != "private" or sender.get("is_bot"):
            return
        uid, chat_id = sender.get("id"), chat.get("id")
        if not isinstance(uid, int) or not isinstance(chat_id, int):
            return
        self.db.touch_user(uid)
        text = msg.get("text")
        if not isinstance(text, str) or not text.strip():
            await self.say(chat_id, texts.NOT_MESSAGE, self.menu_markup())
            return
        text = text.strip()[:MAX_TEXT]
        if text.startswith("/"):
            head, _, arg = text.partition(" ")
            await self.on_command(uid, chat_id, msg, head[1:].split("@")[0].lower(), arg.strip())
            return
        await self.on_text(uid, chat_id, text)

    async def on_command(self, uid: int, chat_id: int, msg: dict, cmd: str, arg: str) -> None:
        self._pending.pop(uid, None)                 # a command ends any "type the price" wait
        if cmd == "start":
            await self.on_start(uid, chat_id, arg)
        elif cmd in ("menu", "help"):
            await self.send_welcome(chat_id)
        elif cmd == "about":
            await self.say(chat_id, texts.ABOUT, keyboard([[button("🏠 القائمة", data="menu")]]))
        elif cmd == "privacy":
            await self.say(chat_id, texts.PRIVACY, keyboard([[button("🏠 القائمة", data="menu")]]))
        elif cmd == "surprise":
            await self.show_surprise(chat_id, uid)
        elif cmd == "saved":
            await self.show_saved(chat_id, uid)
        elif cmd == "search":
            await self.show_where(chat_id)
        elif cmd == "cheap":
            await self.show_cheapest(chat_id, uid)
        elif cmd == "weekend":
            await self.show_weekend(chat_id, uid)
        elif cmd in ("alerts", "alert"):
            await self.show_alerts(chat_id, uid)
        elif cmd == "settings":
            await self.show_settings(chat_id, uid)
        elif cmd == "budget":
            await self.say(chat_id, texts.BUDGET_PROMPT, keyboard([[button("🏠 القائمة", data="menu")]]))
        elif cmd == "admin":
            await self.claim_admin(uid, chat_id, msg, arg)
        elif cmd in ("stats", "diag", "market", "deals", "welcome", "autopost", "backup"):
            if not self.db.is_admin(uid):
                await self.say(chat_id, texts.ADMIN_ONLY)
            elif cmd == "stats":
                await self.say(chat_id, texts.stats_text(self.db.stats(), self.popular_lines(), self.db.kv_get("alerts_sent", "0")))
            elif cmd == "diag":
                await self.run_diag(chat_id)
            elif cmd == "market":
                await self.market_command(chat_id, arg)
            elif cmd == "deals":
                await self.deals_preview(chat_id, uid)
            elif cmd == "welcome":
                await self.welcome_preview(chat_id)
            elif cmd == "autopost":
                await self.autopost_command(chat_id, arg)
            else:
                await self.backup_command(chat_id)
        else:
            await self.say(chat_id, texts.UNKNOWN, self.menu_markup())

    def popular_lines(self) -> list[tuple[str, int]]:
        by = data.by_iata()
        return [(f"{by[i].flag} {by[i].ar}", n) for i, n in self.db.top_popular(5) if i in by]

    def _today(self) -> date:
        return datetime.fromtimestamp(self.clock(), SAUDI_TZ).date()

    # ---- /start and first run ------------------------------------------------------------------------
    @staticmethod
    def _start_target(payload: str):
        """What a /start link asks for: ("trip", dest, wish), ("weekend",), ("cheap",) or None."""
        payload = payload.strip()[:64]
        if payload == "w":
            return ("weekend",)
        if payload == "c":
            return ("cheap",)
        parsed = parse_trip_payload(payload)
        return ("trip", *parsed) if parsed else None

    async def on_start(self, uid: int, chat_id: int, payload: str) -> None:
        user = self.db.touch_user(uid)
        target = self._start_target(payload)
        if not user["onboarded"]:
            await self.say(chat_id, texts.ONBOARD_ASK, self.onboarding_markup(payload.strip()[:48] if target else ""))
            return
        if target:
            await self._open_target(chat_id, uid, user["origin"], target)
        else:
            await self.send_welcome(chat_id)

    async def _open_target(self, chat_id: int, uid: int, origin: str, target) -> None:
        if target[0] == "trip":
            wish = target[2]
            if wish.has_dates and dts.problem(wish, self._today()):
                await self.send_welcome(chat_id)
                return
            await self.show_trip(chat_id, uid, target[1], origin, wish)
        elif target[0] == "weekend":
            await self.show_weekend(chat_id, uid)
        else:
            await self.show_cheapest(chat_id, uid)

    # ---- free text -----------------------------------------------------------------------------------
    async def on_text(self, uid: int, chat_id: int, text: str) -> None:
        user = self.db.touch_user(uid)
        origin = user["origin"]
        today = self._today()

        if await self.take_target(chat_id, uid, text):       # an alert is waiting for a typed price
            return

        # "1".."9": the person is picking from the list we just showed
        if text.isdigit() and len(text) == 1:
            last = self._last_list.get(uid) or []
            index = int(text) - 1
            if 0 <= index < len(last) and last[index] in data.by_iata():
                wish = self._last_wish.get(uid) or dts.DateWish()
                await self.show_trip(chat_id, uid, data.by_iata()[last[index]], origin, wish)
                return

        intent = data.understand(text, today)
        wish = intent.dates
        if wish.depart and not wish.ret and wish.stay and not wish.one_way:     # "دبي 15/12 5 ايام"
            wish = dataclasses.replace(wish, ret=wish.depart + timedelta(days=wish.stay), stay=None)

        # only a departure city ("المدينة المنورة" or "من جدة"): remember it as the origin
        if not (intent.destinations or intent.budget or wish.has_dates or wish.weekend or intent.regions):
            only = data.bare_origin(text)
            if not only and intent.origin and not (intent.cheapest or intent.tags or wish.stay):
                only = intent.origin
            if only:
                self.db.set_origin(uid, only)
                await self.say(chat_id, texts.origin_set(only), self.menu_markup())
                return

        if intent.origin and intent.origin != origin:
            self.db.set_origin(uid, intent.origin)
            origin = intent.origin

        why = dts.problem(wish, today) if wish.has_dates else None
        if why:
            await self.say(chat_id, texts.DATE_PROBLEM[why], self.menu_markup())
            return

        if intent.destinations:
            if len(intent.destinations) == 1:
                await self.show_trip(chat_id, uid, intent.destinations[0], origin, wish)
            else:
                await self.show_choices(chat_id, uid, list(intent.destinations), origin, wish)
            return
        if wish.weekend:
            await self.show_weekend(chat_id, uid, regions=intent.regions)
            return
        if intent.regions and not intent.budget:
            months = [wish.month_key] if wish.has_dates else None
            await self.show_cheapest(chat_id, uid, regions=intent.regions, months=months)
            return
        if intent.budget:
            months = [wish.month_key] if wish.has_dates else None
            await self.show_budget(
                chat_id, uid, intent.budget, intent.tags, intent.ticket_only, origin=origin, months=months,
                regions=intent.regions,
            )
            return
        if wish.has_dates or wish.stay:
            if data.suggest(intent.rest):                   # "لندون 15/12": a misspelt place beside the dates
                await self.maybe_suggest(chat_id, intent.rest, wish)
                return
            iata = self._last_dest.get(uid)
            if iata in data.by_iata():
                await self.show_trip(chat_id, uid, data.by_iata()[iata], origin, wish)
            else:
                await self.say(chat_id, texts.WHERE_PROMPT, self.where_markup())
            return
        if intent.cheapest:
            await self.show_cheapest(chat_id, uid)
            return
        if intent.tags:
            await self.show_surprise(chat_id, uid, intent.tags, origin=origin)
            return

        kind = data.small_talk(text)
        if kind == "surprise":
            await self.show_surprise(chat_id, uid, origin=origin)
        elif kind in ("greeting", "help"):
            await self.send_welcome(chat_id)
        elif kind == "thanks":
            await self.say(chat_id, texts.THANKS_REPLY, self.menu_markup())
        elif kind == "settings":
            await self.show_settings(chat_id, uid)
        elif kind == "saved":
            await self.show_saved(chat_id, uid)
        elif kind == "alerts":
            await self.show_alerts(chat_id, uid)
        else:
            await self.maybe_suggest(chat_id, text, wish)

    async def maybe_suggest(self, chat_id: int, text: str, wish: dts.DateWish) -> None:
        """A misspelt place name: ask "تقصد X؟" with a button instead of giving up."""
        options = list(data.suggest(text))[:3]
        if not options:
            await self.say(chat_id, texts.UNKNOWN, self.menu_markup())
            return
        rows = [[button(f"{d.flag} {d.ar}", data=self._enc(d, wish))] for d in options]
        rows.append(footer())
        await self.say(chat_id, texts.suggest_text(options), keyboard(rows))

    # ------------------------------------------------------------------
    # callbacks
    # ------------------------------------------------------------------
    async def on_callback(self, cb: dict) -> None:
        cb_id = str(cb.get("id") or "")
        uid = (cb.get("from") or {}).get("id")
        msg = cb.get("message") or {}
        chat = msg.get("chat") or {}
        chat_id, mid = chat.get("id"), msg.get("message_id")
        if not isinstance(uid, int) or not isinstance(chat_id, int) or chat.get("type") != "private":
            await self.api.answer_callback(cb_id)
            return
        self.db.touch_user(uid)
        kind, _, arg = str(cb.get("data") or "")[:64].partition(":")
        mid = mid if isinstance(mid, int) else None

        if kind in ("sv", "us"):
            await self._cb_save(cb_id, chat_id, mid, uid, arg, save=(kind == "sv"), markup=msg.get("reply_markup"))
            return
        await self.api.answer_callback(cb_id)
        self._pending.pop(uid, None)

        user = self.db.touch_user(uid)
        origin = user["origin"]
        dest = (
            data.by_iata().get(arg.split(":")[0])
            if kind in ("d", "visa", "svc", "dp", "dm", "dd", "dr", "dy", "dw", "cal", "cd", "ov", "oc", "wa")
            else None
        )

        if kind == "menu":
            await self.send_menu(chat_id)
        elif kind == "ob":
            await self._cb_onboard(chat_id, uid, arg)
        elif kind == "sur":
            await self.show_surprise(chat_id, uid, _tags(arg), origin=origin)
        elif kind == "mood":
            await self.show_surprise(chat_id, uid, _tags(arg[:1]), origin=origin)
        elif kind == "bp":
            await self.say(chat_id, texts.BUDGET_PROMPT, keyboard([[button("🏠 القائمة", data="menu")]]))
        elif kind == "bud":
            parsed = self._parse_budget(arg)
            if parsed:
                budget, ticket_only, tags = parsed
                await self.show_budget(chat_id, uid, budget, tags, ticket_only, origin=origin, edit_mid=mid)
        elif kind == "go":
            await self.show_where(chat_id)
        elif kind == "cheap":
            await self.show_cheapest(chat_id, uid)
        elif kind == "ch":
            region, _, month_token = arg.partition(":")
            month = dts.decode_month(month_token) if month_token and month_token != "-" else None
            if region == "all" or region in data.REGION_CC:
                regions = () if region == "all" else (region,)
                await self.show_cheapest(chat_id, uid, regions=regions, months=[month] if month else None, edit_mid=mid)
        elif kind == "we":
            await self.show_weekend(chat_id, uid, edit_mid=mid)
        elif kind == "al":
            await self.show_alerts(chat_id, uid, edit_mid=mid)
        elif kind == "x":
            return
        elif kind == "d" and dest:
            wish = self._wish_from(arg)
            if wish is None or dts.problem(wish, self._today()):
                await self.say(chat_id, texts.BAD_BUTTON, self.menu_markup())
            else:
                await self.show_trip(chat_id, uid, dest, origin, wish)
        elif kind == "cd" and dest:
            parts = arg.split(":")          # IST:20261212:20261219 (a day picked in the calendar)
            wish = dts.decode_when(parts[1], parts[2], False) if len(parts) == 3 else None
            if wish and wish.depart and not dts.problem(wish, self._today()):
                await self.show_trip(chat_id, uid, dest, origin, wish, edit_mid=mid, count=False)
            else:
                await self.say(chat_id, texts.BAD_BUTTON, self.menu_markup())
        elif kind == "cal" and dest:
            parts = arg.split(":")          # IST:202612:7
            month = dts.decode_month(parts[1]) if len(parts) == 3 else None
            stay = int(parts[2]) if len(parts) == 3 and parts[2].isdigit() else -1
            if month and (stay == 0 or 2 <= stay <= 30):
                await self.show_calendar(chat_id, dest, origin, month, stay, mid)
            else:
                await self.say(chat_id, texts.BAD_BUTTON, self.menu_markup())
        elif kind == "ov" and dest:
            parts = arg.split(":")          # IST:7
            if len(parts) == 2 and parts[1].isdigit() and (int(parts[1]) == 0 or 2 <= int(parts[1]) <= 30):
                await self.show_overview(chat_id, dest, origin, int(parts[1]), mid)
            else:
                await self.say(chat_id, texts.BAD_BUTTON, self.menu_markup())
        elif kind == "dy" and dest:
            parts = arg.split(":")          # IST:7:202612 or IST:7:-
            month = dts.decode_month(parts[2]) if len(parts) == 3 and parts[2] != "-" else None
            ok = len(parts) == 3 and parts[1].isdigit() and int(parts[1]) in STAYS and (parts[2] == "-" or month)
            wish = dts.DateWish(month=month) if month else dts.DateWish()
            if ok and not dts.problem(wish, self._today()):
                await self.show_trip(chat_id, uid, dest, origin, wish, stay=int(parts[1]))
            else:
                await self.say(chat_id, texts.BAD_BUTTON, self.menu_markup())
        elif kind == "dw" and dest:
            parts = arg.split(":")          # IST:- or IST:202612
            month = dts.decode_month(parts[1]) if len(parts) == 2 and parts[1] != "-" else None
            wish = dts.DateWish(month=month, weekend=True)
            if len(parts) == 2 and (parts[1] == "-" or month) and not dts.problem(wish, self._today()):
                await self.show_trip(chat_id, uid, dest, origin, wish)
            else:
                await self.say(chat_id, texts.BAD_BUTTON, self.menu_markup())
        elif kind == "wa" and dest:
            await self._cb_watch(chat_id, uid, dest, arg)
        elif kind == "wt":
            if arg.isdigit():
                await self.ask_target(chat_id, uid, int(arg))
        elif kind == "wd":
            if arg.isdigit():
                self.db.delete_watch(int(arg), uid)
                await self.show_alerts(chat_id, uid, edit_mid=mid)
        elif kind == "wo":
            if arg.isdigit():
                await self.open_watch(chat_id, uid, int(arg))
        elif kind == "dp" and dest:
            await self.show_month_picker(chat_id, dest, mid)
        elif kind == "dm" and dest:
            month = dts.decode_month(arg.split(":")[1]) if arg.count(":") == 1 else None
            if month in dts.month_choices(self._today(), 12):
                await self.show_day_picker(chat_id, dest, month, mid)
            else:
                await self.say(chat_id, texts.BAD_BUTTON, self.menu_markup())
        elif kind == "dd" and dest:
            day = dts.decode_day(arg.split(":")[1]) if arg.count(":") == 1 else None
            if day and not dts.problem(dts.DateWish(depart=day), self._today()):
                await self.show_return_picker(chat_id, dest, day, mid)
            else:
                await self.say(chat_id, texts.BAD_BUTTON, self.menu_markup())
        elif kind == "dr" and dest:
            parts = arg.split(":")
            day = dts.decode_day(parts[1]) if len(parts) == 3 else None
            if day and parts[2].isdigit() and int(parts[2]) in TRIP_LENGTHS and not dts.problem(
                dts.DateWish(depart=day), self._today()
            ):
                n = int(parts[2])
                wish = dts.DateWish(depart=day, ret=day + timedelta(days=n) if n else None, one_way=n == 0)
                await self.show_trip(chat_id, uid, dest, origin, wish)
            else:
                await self.say(chat_id, texts.BAD_BUTTON, self.menu_markup())
        elif kind == "oc" and dest:
            await self.show_origin_picker(chat_id, uid, dest, mid)
        elif kind == "ox":
            code, _, iata = arg.partition(":")
            target = data.by_iata().get(iata)
            if code in ORIGINS and target:
                self.db.set_origin(uid, code)
                await self.show_trip(chat_id, uid, target, code, edit_mid=mid, count=False)
            else:
                await self.say(chat_id, texts.BAD_BUTTON, self.menu_markup())
        elif kind == "visa" and dest:
            rows = []
            official = data.visa_official(dest.cc)
            if official and data.visa_for(dest.cc) and data.visa_for(dest.cc).status not in ("free", "gcc"):
                rows.append([button("🌐 الموقع الرسمي للتقديم", url=official)])
            rows.append([button("🏠 القائمة", data="menu")])
            await self.say(chat_id, texts.visa_detail(dest), keyboard(rows))
        elif kind == "svc" and dest:
            await self.show_services(chat_id, dest)
        elif kind == "sl":
            await self.show_saved(chat_id, uid)
        elif kind == "st":
            await self.show_settings(chat_id, uid, edit_mid=mid)
        elif kind == "og" and arg in ORIGINS:
            self.db.set_origin(uid, arg)
            await self.show_settings(chat_id, uid, edit_mid=mid)
        elif kind == "vo" and arg in ("0", "1"):
            self.db.set_visa_only(uid, arg == "1")
            await self.show_settings(chat_id, uid, edit_mid=mid)
        elif kind == "pub":
            await self.publish_callback(chat_id, uid, mid, arg)
        elif kind == "mk":
            await self.market_callback(chat_id, uid, arg)

    async def _cb_onboard(self, chat_id: int, uid: int, arg: str) -> None:
        code, _, payload = arg.partition(":")
        if code not in ORIGINS:
            await self.say(chat_id, texts.BAD_BUTTON, self.menu_markup())
            return
        self.db.set_origin(uid, code)          # also marks the person as onboarded
        target = self._start_target(payload) if payload else None
        if target:
            await self._open_target(chat_id, uid, code, target)
            return
        done = texts.ONBOARD_DONE.format(city=texts.ORIGIN_NAMES[code])
        await self.say(chat_id, done, self.menu_markup())

    async def _cb_watch(self, chat_id: int, uid: int, dest: data.Destination, arg: str) -> None:
        parts = arg.split(":")      # IST:<dep|w>:<ret>:<oneway>:<stay>
        if len(parts) != 5 or parts[3] not in ("0", "1") or not parts[4].isdigit():
            await self.say(chat_id, texts.BAD_BUTTON, self.menu_markup())
            return
        stay = int(parts[4])
        if parts[1] == "w":
            wish = dts.DateWish(weekend=True)
        else:
            wish = dts.decode_when(parts[1], parts[2], parts[3] == "1")
        if wish is None or (stay and not 2 <= stay <= 30) or (wish.has_dates and dts.problem(wish, self._today())):
            await self.say(chat_id, texts.BAD_BUTTON, self.menu_markup())
            return
        await self.create_watch(chat_id, uid, dest, wish, stay)

    @staticmethod
    def _parse_budget(arg: str) -> tuple[int, bool, tuple[str, ...]] | None:
        parts = arg.split(":")
        if len(parts) != 3 or parts[1] not in ("t", "f"):
            return None
        try:
            budget = int(parts[0])
        except ValueError:
            return None
        if not 300 <= budget <= 1_000_000:
            return None
        return budget, parts[1] == "t", _tags(parts[2])

    async def _cb_save(self, cb_id: str, chat_id: int, mid: int | None, uid: int, iata: str, *, save: bool, markup) -> None:
        dest = data.by_iata().get(iata)
        if dest is None:
            await self.api.answer_callback(cb_id)
            return
        if save:
            if len(self.db.saved_list(uid)) >= MAX_SAVED and not self.db.is_saved(uid, iata):
                await self.api.answer_callback(cb_id, "قائمتك ممتلئة، احذف وجهة أولًا")
                return
            self.db.save(uid, iata)
        else:
            self.db.unsave(uid, iata)
        await self.api.answer_callback(cb_id, texts.SAVED_TOAST if save else texts.UNSAVED_TOAST)
        if mid is not None and markup:
            new = (
                button("💔 إزالة", data="us:" + iata) if save else button("❤️ احفظ", data="sv:" + iata)
            )
            updated = swap_button(markup, {"sv:" + iata, "us:" + iata}, new)
            if updated:
                try:
                    await self.api.edit_markup(chat_id, mid, updated)
                except TelegramError as exc:
                    log.info("could not refresh buttons: %s", exc.status)

    # ------------------------------------------------------------------
    # prices and candidates
    # ------------------------------------------------------------------
    def _quota(self, uid: int) -> bool:
        return self.db.is_admin(uid) or self.db.use_search(uid, self.settings.daily_search_limit)

    def _months(self) -> list[str]:
        return month_keys(self.clock() + HORIZON_SHIFT, 3)

    async def _offers(self, origin: str, months: list[str] | None = None) -> tuple[dict[str, Offer], bool]:
        if not self.tp.enabled:
            return {}, False
        try:
            offers = await self.tp.cheapest_from(origin, months or self._months())
        except TPError as exc:
            log.warning("prices unavailable: %s", exc)
            return {}, False
        # a price in a currency we cannot turn into riyals is worse than no price at all
        offers = {k: o for k, o in offers.items() if to_sar(o.price, o.currency) is not None}
        return offers, bool(offers)

    @staticmethod
    def _candidates(offers: dict[str, Offer], live: bool, tags, visa_only: bool, regions=()) -> list[Candidate]:
        out: list[Candidate] = []
        for dest in data.destinations():
            if tags and not set(tags) & set(dest.tags):
                continue
            if regions and not data.in_region(dest, tuple(regions)):
                continue
            if visa_only and not texts.visa_ok(dest):
                continue
            offer, price = None, None
            if live:
                offer = offers.get(dest.iata)
                if offer is None:
                    continue
                price = to_sar(offer.price, offer.currency)
                if price is None:
                    continue
            out.append((dest, offer, price))
        return out

    def _pick(self, uid: int, pool: list[Candidate], n: int) -> list[Candidate]:
        """Random picks that prefer destinations this person has not been shown yet."""
        seen = self.db.seen_set(uid)
        fresh = [c for c in pool if c[0].iata not in seen]
        if len(fresh) < min(n, len(pool)):
            self.db.clear_seen(uid)
            fresh = list(pool)
        chosen = self.rng.sample(fresh, min(n, len(fresh)))
        for c in chosen:
            self.db.mark_seen(uid, c[0].iata)
        return chosen

    # ------------------------------------------------------------------
    # screens
    # ------------------------------------------------------------------
    async def show_surprise(self, chat_id: int, uid: int, tags=(), *, origin: str | None = None) -> None:
        user = self.db.touch_user(uid)
        origin = origin or user["origin"]
        if not self._quota(uid):
            await self.say(chat_id, texts.LIMIT_REACHED, self.menu_markup())
            return
        await self.api.send_action(chat_id)
        offers, live = await self._offers(origin)
        visa_only = bool(user["visa_only"])
        cands = self._candidates(offers, live, tags, visa_only)
        note = ""
        if tags and not cands:
            cands = self._candidates(offers, live, (), visa_only)
            tags = ()
            note = texts.NOTE_RELAXED if cands else ""
        if not cands:
            await self.say(chat_id, texts.NO_RESULT_VISA if visa_only else texts.NO_RESULT, self.menu_markup())
            return
        dest, offer, _ = self._pick(uid, cands, 1)[0]
        state = "ok" if offer else ("error" if self.tp.enabled else "off")
        again = "sur:" + _codes(tags) if tags else "sur"
        await self.send_card(chat_id, uid, dest, offer, origin, state, note=note, again=again)

    async def show_choices(
        self, chat_id: int, uid: int, dests: list[data.Destination], origin: str, wish: dts.DateWish | None = None
    ) -> None:
        wish = wish or dts.DateWish()
        if not self._quota(uid):
            await self.say(chat_id, texts.LIMIT_REACHED, self.menu_markup())
            return
        await self.api.send_action(chat_id)
        offers, _live = await self._offers(origin)
        rows = []
        for dest in dests[:MAX_CHOICES]:
            offer = offers.get(dest.iata)
            rows.append((dest, to_sar(offer.price, offer.currency) if offer else None))
        buttons = []
        for dest, price in rows:
            label = f"{dest.flag} {dest.ar}" + (f" — {round(price):,} ر.س" if price is not None else "")
            buttons.append([button(label, data=self._enc(dest, wish))])
        buttons.append(footer())
        self._set_last(uid, [d.iata for d, _ in rows])
        self._last_wish[uid] = wish
        await self.say(chat_id, texts.choices(rows, origin), keyboard(buttons))

    async def show_budget(
        self,
        chat_id: int,
        uid: int,
        budget: int,
        tags=(),
        ticket_only: bool = False,
        *,
        origin: str | None = None,
        edit_mid: int | None = None,
        months: list[str] | None = None,
        regions=(),
    ) -> None:
        user = self.db.touch_user(uid)
        origin = origin or user["origin"]
        if not self._quota(uid):
            await self.say(chat_id, texts.LIMIT_REACHED, self.menu_markup())
            return
        await self.api.send_action(chat_id)
        offers, live = await self._offers(origin, months)
        visa_only = bool(user["visa_only"])
        cands = self._candidates(offers, live, tags, visa_only, regions)
        notes: list[str] = []
        if tags and not cands:
            cands = self._candidates(offers, live, (), visa_only, regions)
            tags = ()
            if cands:
                notes.append(texts.NOTE_RELAXED)
        if not cands:
            await self.say(chat_id, texts.NO_RESULT_VISA if visa_only else texts.NO_RESULT, self.menu_markup())
            return

        if live:
            cap = float(budget) if ticket_only else budget * TRIP_SHARE
            within = [c for c in cands if c[2] <= cap]
            if within:
                rows = sorted(self._pick(uid, within, LIST_SIZE), key=lambda c: c[2])
                can_reroll = len(within) > LIST_SIZE
            else:
                rows = sorted(cands, key=lambda c: c[2])[:LIST_SIZE]
                can_reroll = False
            text = texts.budget_list(budget, cap, ticket_only, rows, bool(within), origin)
        else:
            tiers = ("low",) if budget < 2500 else ("low", "mid") if budget < 6000 else ("low", "mid", "high")
            pool = [c for c in cands if c[0].cost in tiers] or cands
            order = {"low": 0, "mid": 1, "high": 2}
            rows = sorted(self._pick(uid, pool, LIST_SIZE), key=lambda c: (order.get(c[0].cost, 3), c[0].ar))
            can_reroll = len(pool) > LIST_SIZE
            text = texts.budget_tiers(budget, [c[0] for c in rows])
        if notes:
            text += "\n\n" + "\n".join(notes)

        codes = _codes(tags)
        mode, other = ("t", "f") if ticket_only else ("f", "t")
        self._set_last(uid, [c[0].iata for c in rows])
        self._last_wish.pop(uid, None)
        kb = [[button(str(i), data="d:" + c[0].iata) for i, c in enumerate(rows, 1)]]
        control = []
        if can_reroll:
            control.append(button("🔄 غيّرها", data=f"bud:{budget}:{mode}:{codes}"))
        if live:
            control.append(
                button("💼 للرحلة كلها" if ticket_only else "🎫 للتذكرة فقط", data=f"bud:{budget}:{other}:{codes}")
            )
        if control:
            kb.append(control)
        kb.append([button("🏠 القائمة", data="menu")])
        await self.show(chat_id, text, keyboard(kb), edit_mid)

    def where_markup(self) -> dict:
        by = data.by_iata()
        picks = [by[c] for c in POPULAR if c in by]
        rows = chunk([button(f"{d.flag} {d.ar}", data="d:" + d.iata) for d in picks], 2)
        rows.append([button("🔥 أرخص الرحلات الآن", data="cheap"), button("🌙 ويكند", data="we")])
        rows.append(footer())
        return keyboard(rows)

    async def show_where(self, chat_id: int) -> None:
        await self.say(chat_id, texts.WHERE_PROMPT, self.where_markup())

    async def show_cheapest(
        self, chat_id: int, uid: int, *, regions=(), months: list[str] | None = None, edit_mid: int | None = None
    ) -> None:
        user = self.db.touch_user(uid)
        origin, visa_only = user["origin"], bool(user["visa_only"])
        if not self._quota(uid):
            await self.say(chat_id, texts.LIMIT_REACHED, self.menu_markup())
            return
        await self.api.send_action(chat_id)
        offers, live = await self._offers(origin, months)
        cands = self._candidates(offers, live, (), visa_only, regions) if live else []
        if not cands:
            if not self.tp.enabled or not live:
                await self.say(chat_id, texts.BUSY, self.menu_markup())
            else:
                await self.say(chat_id, texts.NO_RESULT_VISA if visa_only else texts.NO_RESULT, self.menu_markup())
            return
        rows = sorted(cands, key=lambda c: c[2])[:CHEAP_SIZE]
        self._set_last(uid, [c[0].iata for c in rows])
        self._last_wish.pop(uid, None)
        numbers = [button(str(i), data="d:" + c[0].iata) for i, c in enumerate(rows, 1)]
        kb = chunk(numbers, 4)
        region = regions[0] if len(regions) == 1 else None
        month_token = dts.encode_month(months[0]) if months and len(months) == 1 else "-"
        for line in REGION_ROWS:
            kb.append([
                button(
                    ("✔ " if (key == "all" and not regions) or key == region else "")
                    + ("🔥 الكل" if key == "all" else texts.REGION_LABELS[key]),
                    data=f"ch:{key}:{month_token}",
                )
                for key in line
            ])
        kb.append([button("🌙 ويكند", data="we"), button("🏠 القائمة", data="menu")])
        month = months[0] if months and len(months) == 1 else None
        await self.show(chat_id, texts.cheap_list(origin, rows, visa_only, region, month), keyboard(kb), edit_mid)

    async def weekend_offers(self, origin: str) -> dict[str, Offer]:
        """The cheapest weekend trip to every destination the bot can show (one lookup for the screen, the post and /diag)."""
        return await self.tp.weekend_deals(
            origin, month_keys(self.clock() + 86400, WEEKEND_MONTHS), self._earliest(),
            known=frozenset(data.by_iata()), extra=data.weekend_destinations(),
        )

    async def show_weekend(
        self, chat_id: int, uid: int, *, regions=(), edit_mid: int | None = None
    ) -> None:
        """The cheapest Thursday/Friday-to-Saturday/Sunday trips from the person's city."""
        user = self.db.touch_user(uid)
        origin, visa_only = user["origin"], bool(user["visa_only"])
        if not self._quota(uid):
            await self.say(chat_id, texts.LIMIT_REACHED, self.menu_markup())
            return
        if not self.tp.enabled:
            await self.say(chat_id, texts.BUSY, self.menu_markup())
            return
        await self.api.send_action(chat_id)
        try:
            deals = await self.weekend_offers(origin)
        except TPError as exc:
            log.warning("weekend lookup failed: %s", exc)
            await self.say(chat_id, texts.BUSY, self.menu_markup())
            return
        earliest = self._earliest()
        by = data.by_iata()
        rows = []
        for iata, offer in deals.items():
            dest = by.get(iata)
            if dest is None or offer.departure_at[:10] < earliest:
                continue
            if regions and not data.in_region(dest, tuple(regions)):
                continue
            if visa_only and not texts.visa_ok(dest):
                continue
            rows.append((dest, offer, to_sar(offer.price, offer.currency)))
        rows.sort(key=lambda r: r[2])
        rows = rows[:CHEAP_SIZE]
        footer_row = [button("🔥 أرخص الرحلات", data="cheap"), button("🏠 القائمة", data="menu")]
        if not rows:
            await self.show(chat_id, texts.WEEKEND_EMPTY, keyboard([footer_row]), edit_mid)
            return
        self._set_last(uid, [r[0].iata for r in rows])
        self._last_wish.pop(uid, None)
        numbers = []
        for i, (dest, offer, _price) in enumerate(rows, 1):
            dep = dts.decode_day(offer.departure_at[:10].replace("-", ""))
            back = dts.decode_day(offer.return_at[:10].replace("-", ""))
            numbers.append(button(str(i), data=f"d:{dest.iata}:{dts.encode_day(dep)}:{dts.encode_day(back)}"))
        kb = chunk(numbers, 4)
        kb.append(footer_row)
        await self.show(chat_id, texts.weekend_list(origin, rows, visa_only), keyboard(kb), edit_mid)

    async def show_saved(self, chat_id: int, uid: int) -> None:
        by = data.by_iata()
        dests = [by[i] for i in self.db.saved_list(uid) if i in by][:MAX_SAVED]
        if not dests:
            await self.say(chat_id, texts.SAVED_EMPTY, self.menu_markup())
            return
        self._set_last(uid, [d.iata for d in dests])
        numbers = [button(str(i), data="d:" + d.iata) for i, d in enumerate(dests, 1)]
        kb = chunk(numbers, 5)
        kb.append([button("🏠 القائمة", data="menu")])
        await self.say(chat_id, texts.saved_list(dests), keyboard(kb))

    async def show_settings(self, chat_id: int, uid: int, *, edit_mid: int | None = None) -> None:
        user = self.db.touch_user(uid)
        origin, visa_only = user["origin"], bool(user["visa_only"])
        rows = chunk(
            [button(("✔ " if code == origin else "") + texts.ORIGIN_NAMES[code], data="og:" + code) for code in ORIGINS], 3
        )
        rows.append([button("🛂 بدون تأشيرة فقط: " + ("✅ مفعّل" if visa_only else "متوقف"), data="vo:" + ("0" if visa_only else "1"))])
        rows.append([button("🏠 القائمة", data="menu")])
        await self.show(chat_id, texts.settings_text(origin, visa_only), keyboard(rows), edit_mid)

    async def show_services(self, chat_id: int, dest: data.Destination) -> None:
        _flight, services = await self._links_for(None)
        if not services:
            await self.say(chat_id, texts.NO_RESULT, keyboard([footer()]))
            return
        rows = [[button(label, url=url)] for label, url in services]
        rows.append(footer())
        await self.say(chat_id, texts.services_text(dest), keyboard(rows))

    # ------------------------------------------------------------------
    # cards and links
    # ------------------------------------------------------------------
    async def _links_for(self, offer: Offer | None) -> tuple[tuple[str, bool] | None, list[tuple[str, str]]]:
        """Booking link for the offer (url, is_affiliate) and the partner services that are available."""
        flight_url = self.tp.site_url(offer.link) if offer and offer.link else None
        partners = data.partners()
        urls = ([flight_url] if flight_url else []) + [p.url for p in partners]
        if not urls or not self.tp.enabled:
            return None, []
        try:
            found = await self.tp.partner_links(urls)
        except Exception:  # noqa: BLE001 - links are a bonus, never break the answer
            log.warning("partner links unavailable", exc_info=False)
            found = {}
        flight = None
        if flight_url:
            partner = found.get(flight_url)
            if partner:
                flight = (partner, True)
            elif self.tp.marker:
                flight = (with_marker(flight_url, self.tp.marker), True)
            else:
                flight = (flight_url, False)
        services = [(p.label, found[p.url]) for p in partners if found.get(p.url)]
        return flight, services

    async def send_card(
        self,
        chat_id: int,
        uid: int,
        dest: data.Destination,
        offer: Offer | None,
        origin: str,
        state: str = "ok",
        *,
        note: str = "",
        again: str = "sur",
    ) -> None:
        text = texts.offer_card(dest, offer, origin, state)
        if note:
            text += "\n\n" + note
        flight, services = await self._links_for(offer)
        rows = []
        if flight:
            url, affiliate = flight
            rows.append([button("✈️ احجز الآن (رابط شريك)" if affiliate else "✈️ افتح الرحلة", url=url)])
        saved = self.db.is_saved(uid, dest.iata)
        rows.append([
            button("💔 إزالة" if saved else "❤️ احفظ", data=("us:" if saved else "sv:") + dest.iata),
            button("🛂 التأشيرة", data="visa:" + dest.iata),
        ])
        if services:
            rows.append([button("🧳 خدمات الرحلة", data="svc:" + dest.iata)])
        rows.append([button("📅 حدّد التاريخ", data="dp:" + dest.iata), button("📆 تقويم الأسعار", data=f"cal:{dest.iata}:{dts.encode_month(self._first_month(offer))}:0")])
        rows.append([button("🎲 غيّرها", data=again), button("🏠 القائمة", data="menu")])
        await self.say(chat_id, text, keyboard(rows))

    def _first_month(self, offer: Offer | None) -> str:
        if offer and offer.departure_at[:7].count("-") == 1:
            return offer.departure_at[:7]
        return dts.month_choices(self._today(), 1)[0]

    # ------------------------------------------------------------------
    # admin
    # ------------------------------------------------------------------
    async def claim_admin(self, uid: int, chat_id: int, msg: dict, code: str) -> None:
        configured = self.settings.admin_code
        if not configured or self.db.kv_get("admin_code_used") == "1" or not code:
            await self.say(chat_id, texts.ADMIN_OFF)
            return
        now = self.clock()
        recent = [t for t in self._admin_fails.get(uid, []) if now - t < 3600]
        if len(recent) >= 5:
            await self.say(chat_id, texts.ADMIN_BAD)
            return
        if not hmac.compare_digest(code.encode(), configured.encode()):
            recent.append(now)
            self._admin_fails[uid] = recent
            await self.say(chat_id, texts.ADMIN_BAD)
            return
        self.db.add_admin(uid)
        self.db.kv_set("admin_code_used", "1")
        message_id = msg.get("message_id")
        if isinstance(message_id, int):
            await self.api.delete_message(chat_id, message_id)  # the message contains the code
        await self.say(chat_id, texts.ADMIN_OK)

    async def run_diag(self, chat_id: int) -> None:
        report = await self.tp.diagnose("RUH", "IST", self._months()[0])
        extras: list[tuple[str, bool | None]] = []
        if self.tp.links_api:
            partners = data.partners()
            found = await self.tp.partner_links([p.url for p in partners], fresh=True)
            extras = [
                (p.label, True) if found.get(p.url) else (p.label + texts.SERVICE_OFF, None) for p in partners
            ]
        extras += await self.diag_prices()
        extras += await self.diag_extras()
        await self.say(chat_id, texts.diag_text(report, extras))

    async def diag_prices(self) -> list[tuple[str, bool | None]]:
        """Checks of the lookups the calendar and the weekend list depend on, with how much data each one finds."""
        if not self.tp.enabled:
            return []
        month = self.sample_month()
        out: list[tuple[str, bool | None]] = []
        market = self.tp.market
        out.append((texts.diag_market(market), True if market else None))
        try:
            days = await self.tp.calendar("RUH", "IST", month)
            total = calendar.monthrange(int(month[:4]), int(month[5:7]))[1]
            out.append((f"تقويم الأسعار ({texts.MONTHS[int(month[5:]) - 1]}): {len(days)} يوم من {total}", bool(days)))
        except TPError as exc:
            out.append((f"تقويم الأسعار: {exc}", False))
        started = time.monotonic()
        try:
            deals = await self.weekend_offers("RUH")
            note = texts.WEEKEND_PARTIAL if self.tp.weekend_pending else ""
            out.append((f"رحلات الويكند: {len(deals)} وجهة ({time.monotonic() - started:.1f} ث){note}", bool(deals)))
        except TPError as exc:
            out.append((f"رحلات الويكند: {exc}", False))
        return out

    # ------------------------------------------------------------------
    # long polling
    # ------------------------------------------------------------------
    def beat(self) -> None:
        with contextlib.suppress(OSError):
            Path(self.settings.heartbeat_path).write_text(str(int(self.clock())))

    def _spawn(self, coro) -> None:
        task = asyncio.create_task(coro)
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    async def serve(self, stop: asyncio.Event) -> None:
        offset = int(self.db.kv_get("offset", "0") or 0)
        backoff = 1.0
        self.beat()
        background = [
            asyncio.create_task(self.alerts_loop(stop)),
            asyncio.create_task(self.channel_loop(stop)),
            asyncio.create_task(self.maintenance_loop(stop)),
        ]
        try:
            while not stop.is_set():
                poll = asyncio.create_task(self.api.get_updates(offset, timeout=POLL_TIMEOUT))
                waiter = asyncio.create_task(stop.wait())
                await asyncio.wait({poll, waiter}, return_when=asyncio.FIRST_COMPLETED)
                if stop.is_set():
                    poll.cancel()
                    break
                waiter.cancel()
                try:
                    updates = poll.result()
                except Exception as exc:  # noqa: BLE001 - polling must survive any network or parsing problem
                    log.warning("getUpdates failed: %s", exc if isinstance(exc, TelegramError) else type(exc).__name__)
                    if isinstance(exc, TelegramError) and exc.status == 401:
                        log.error("Telegram rejected the bot token; stopping")
                        stop.set()
                        break
                    await self._sleep(stop, backoff)
                    backoff = min(backoff * 2, 30.0)
                    continue
                backoff = 1.0
                self.beat()
                for update in updates:
                    offset = max(offset, int(update.get("update_id", 0)) + 1)
                    self._spawn(self.process(update))
                if updates:
                    self.db.kv_set("offset", str(offset))
        finally:
            for task in background:
                task.cancel()
            await asyncio.gather(*background, return_exceptions=True)
        await self.drain()

    @staticmethod
    async def _sleep(stop: asyncio.Event, seconds: float) -> None:
        with contextlib.suppress(asyncio.TimeoutError):
            await asyncio.wait_for(stop.wait(), timeout=seconds)

    async def drain(self, timeout: float = 10.0) -> None:
        if self._tasks:
            await asyncio.wait(set(self._tasks), timeout=timeout)
