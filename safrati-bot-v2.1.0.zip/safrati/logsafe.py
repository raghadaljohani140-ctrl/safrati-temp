"""Logging that cannot print a secret, even inside a traceback."""
from __future__ import annotations

import logging

MIN_SECRET_LEN = 6


class ScrubbingFormatter(logging.Formatter):
    def __init__(self, secrets, fmt: str | None = None, datefmt: str | None = None):
        super().__init__(fmt, datefmt)
        self._secrets = sorted({s for s in secrets if s and len(s) >= MIN_SECRET_LEN}, key=len, reverse=True)

    def format(self, record: logging.LogRecord) -> str:
        text = super().format(record)
        for secret in self._secrets:
            text = text.replace(secret, "***")
        return text


def secrets_of(settings) -> list[str]:
    values = [settings.bot_token, settings.tp_token, settings.admin_code]
    if ":" in settings.bot_token:
        values.append(settings.bot_token.split(":", 1)[1])
    return [v for v in values if v]
