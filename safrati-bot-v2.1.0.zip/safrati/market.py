"""Admin tool: which price "market" knows the most flights for Saudi cities.

The provider's cache is made of what people searched on its sites in the last two days, and the market says whose
searches are used. Left on automatic it follows the departure city, which can end up with very few Saudi routes.
`/market` compares a few markets on popular routes and lets the admin switch with one tap."""
from __future__ import annotations

import asyncio
import calendar
import logging
import re

from . import texts
from .telegram import button, keyboard

log = logging.getLogger("safrati.market")

MARKETS = ("", "us", "ru", "sa", "ae", "en", "ar", "uk", "eg", "tr")     # "" = the provider decides by the departure city
PROBE_ROUTES = (("RUH", "IST"), ("RUH", "LON"), ("JED", "CAI"), ("DMM", "DXB"))
PROBE_SECONDS = 60
_CODE = re.compile(r"[a-z]{2}")


def recommendation(scores: dict[str, int | None], current: str) -> str | None:
    """The market worth switching to: clearly richer than the current one (a few days more is just noise)."""
    known = {m: n for m, n in scores.items() if n is not None}
    if not known:
        return None
    best = max(known, key=lambda m: (known[m], m == current))
    have = known.get(current, 0)
    if best != current and known[best] >= have + 10 and known[best] >= have * 1.5:
        return best
    return None


class MarketMixin:
    """Mixed into SafratiBot."""

    def apply_saved_market(self) -> None:
        """Use the market an admin chose with /market (it wins over TP_MARKET in .env)."""
        saved = (self.db.kv_get("market", "") or "").strip().lower()
        if saved and _CODE.fullmatch(saved):
            self.tp.set_market(saved)

    def sample_month(self) -> str:
        """A month with most of its days still ahead, so the number of priced days can be read against its length."""
        months = self._months()
        year, month = int(months[0][:4]), int(months[0][5:7])
        days = calendar.monthrange(year, month)[1]
        today = self._today()
        left = days - today.day if (today.year, today.month) == (year, month) else days
        return months[0] if left >= 12 else months[1]

    async def market_command(self, chat_id: int, arg: str) -> None:
        arg = arg.strip().lower()
        if arg in ("auto", "تلقائي", "-"):
            await self.set_market(chat_id, "")
        elif _CODE.fullmatch(arg):
            await self.set_market(chat_id, arg)
        elif arg:
            await self.say(chat_id, texts.MARKET_USAGE)
        else:
            await self.probe_markets(chat_id)

    async def market_callback(self, chat_id: int, uid: int, arg: str) -> None:
        if not self.db.is_admin(uid):
            await self.say(chat_id, texts.ADMIN_ONLY)
        elif arg == "-":
            await self.set_market(chat_id, "")
        elif _CODE.fullmatch(arg):
            await self.set_market(chat_id, arg)
        else:
            await self.say(chat_id, texts.BAD_BUTTON, self.menu_markup())

    async def set_market(self, chat_id: int, code: str) -> None:
        self.db.kv_set("market", code)
        self.tp.set_market(code or self.settings.tp_market)
        await self.say(chat_id, texts.market_changed(self.tp.market))

    async def probe_markets(self, chat_id: int) -> None:
        if not self.tp.enabled:
            await self.say(chat_id, texts.MARKET_NONE)
            return
        await self.say(chat_id, texts.MARKET_WAIT)
        month = self.sample_month()
        current = self.tp.market
        candidates = tuple(dict.fromkeys((*MARKETS, current)))
        jobs = [(m, o, d) for m in candidates for o, d in PROBE_ROUTES]
        try:
            results = await asyncio.wait_for(
                asyncio.gather(*(self.tp.probe_days(o, d, month, m) for m, o, d in jobs), return_exceptions=True),
                PROBE_SECONDS,
            )
        except asyncio.TimeoutError:
            await self.say(chat_id, texts.MARKET_NONE)
            return
        scores: dict[str, int | None] = {}
        for (market, _o, _d), result in zip(jobs, results):
            if isinstance(result, BaseException):
                scores.setdefault(market, None)
                continue
            scores[market] = (scores.get(market) or 0) + result
        if all(v is None for v in scores.values()):
            await self.say(chat_id, texts.MARKET_NONE)
            return
        best = recommendation(scores, current)
        text = texts.market_report(month, scores, current, len(PROBE_ROUTES), best)
        rows = []
        if best is not None:
            rows.append([button(f"✅ استخدم {texts.market_name(best)}", data=f"mk:{best or '-'}")])
        if current:
            rows.append([button("🔄 رجوع للتلقائي", data="mk:-")])
        rows.append([button("🏠 القائمة", data="menu")])
        await self.say(chat_id, text, keyboard(rows))
