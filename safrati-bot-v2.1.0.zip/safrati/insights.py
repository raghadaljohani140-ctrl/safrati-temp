"""Small pure helpers that turn raw prices into something a person can read at a glance.

No network and no state here, so every rule is easy to test.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .tp import Offer

TIER_EMOJI = {"low": "🟢", "mid": "🟡", "high": "🔴"}


def percentile(sorted_values: list[float], q: float) -> float:
    """Linear-interpolated percentile of an already sorted list (q between 0 and 1)."""
    if not sorted_values:
        return 0.0
    if len(sorted_values) == 1:
        return float(sorted_values[0])
    pos = max(0.0, min(1.0, q)) * (len(sorted_values) - 1)
    low = int(pos)
    high = min(low + 1, len(sorted_values) - 1)
    return sorted_values[low] + (sorted_values[high] - sorted_values[low]) * (pos - low)


def median(values: list[float]) -> float:
    return percentile(sorted(values), 0.5)


def tier_cuts(prices: list[float]) -> tuple[float, float]:
    """The prices at the lower and the upper third of the list."""
    ordered = sorted(prices)
    return percentile(ordered, 1 / 3), percentile(ordered, 2 / 3)


def tier_of(price: float, cuts: tuple[float, float]) -> str:
    low, high = cuts
    if price <= low:
        return "low"
    if price <= high:
        return "mid"
    return "high"


@dataclass(frozen=True)
class Verdict:
    level: str      # great | good | typical | high
    saving: int     # percent below the typical price (negative when above it)
    typical: int    # the typical price
    samples: int    # how many day-prices it was compared with


def verdict(best: float, population: list[float], min_samples: int = 8) -> Verdict | None:
    """How the best price compares with the typical price of the same route over the same period.

    It describes the prices found now; it does not predict what will happen next."""
    if best <= 0 or len(population) < min_samples:
        return None
    typical = median(population)
    if typical <= 0:
        return None
    saving = round((1 - best / typical) * 100)
    if saving >= 25:
        level = "great"
    elif saving >= 10:
        level = "good"
    elif saving >= -5:
        level = "typical"
    else:
        level = "high"
    return Verdict(level, saving, round(typical), len(population))


def bar_length(value: float, lowest: float, highest: float, width: int = 5) -> int:
    """1..width: the cheapest value gets the shortest bar and the dearest the longest."""
    if highest <= lowest:
        return (width + 1) // 2
    return 1 + round((value - lowest) / (highest - lowest) * (width - 1))


@dataclass
class TripView:
    """Everything the trip screen needs to show for one destination."""

    offers: list[Offer] = field(default_factory=list)
    note: str = ""
    state: str = "ok"                       # ok | none | error | off
    verdict: Verdict | None = None
    months: list[tuple[str, Offer]] = field(default_factory=list)      # month key -> its cheapest ticket
    hint: tuple[Offer, int] | None = None   # a cheaper nearby day for an exact search: (ticket, riyals saved)


def next_reference(price: int, reference: int | None) -> int:
    """The price a later drop is measured against: it follows the price up, so a return to a lower price is news."""
    if reference is None or price > reference * 1.08:
        return price
    return reference


def alert_decision(price: int, *, target: int | None, base: int | None, notified: int | None) -> str | None:
    """'target' when the wanted price is reached, 'drop' on a real fall, otherwise None.

    With a target: tell the person once it is reached, and again only for a further fall of 3% or more.
    Without a target: tell them when the price is 8% or more under the reference price (`base`, which
    follows the price up and is reset to the price each time the person is told)."""
    if price <= 0:
        return None
    if target:
        if price <= target and (notified is None or price <= notified * 0.97):
            return "target"
        return None
    if base and price <= base * 0.92:
        return "drop"
    return None
