"""The channel (opt-in daily deals post) and the bot's daily housekeeping (database backups)."""
from __future__ import annotations

import asyncio
import contextlib
import hashlib
import logging
import re
from datetime import datetime
from pathlib import Path

from . import data, texts
from . import dates as dts
from .db import SAUDI_TZ
from .telegram import TelegramError, button, keyboard
from .tp import TPError, to_sar
from .trip import trip_payload

log = logging.getLogger("safrati.channel")

POST_HOUR = 10                 # Saudi time of the daily post
POST_ROWS = 5
MIN_POST_ROWS = 3              # fewer priced destinations than this and nothing is posted
MAX_POST_FAILS = 3             # the automatic post switches itself off after this many failures in a row
CHANNEL_CHECK = 300            # seconds between looks at the clock
BACKUP_HOUR = 4
BACKUPS_KEPT = 3
# who the daily post is for, by weekday (Monday = 0). Thursday is the weekend edition.
POST_ORIGINS = ("RUH", "JED", "DMM", "RUH", "JED", "DMM", "RUH")
WEEKEND_WEEKDAY = 3

_CHANNEL = re.compile(r"https://t\.me/([A-Za-z][A-Za-z0-9_]{4,31})")


class ChannelMixin:
    """Mixed into SafratiBot."""

    # ------------------------------------------------------------------
    # the channel
    # ------------------------------------------------------------------
    def channel_chat(self) -> str | None:
        """@name of the channel, when CHANNEL_URL is a public link (an invite link cannot be posted to)."""
        match = _CHANNEL.fullmatch(self.settings.channel_url or "")
        return "@" + match.group(1) if match else None

    def autopost_on(self) -> bool:
        return self.db.kv_get("autopost") == "1"

    async def build_deals_post(self, origin: str, edition: str) -> tuple[str, dict, str] | None:
        """(text, buttons, fingerprint) of a deals post, or None when there is not enough to say."""
        if not self.tp.enabled:
            return None
        rows = []
        try:
            if edition == "weekend":
                deals = await self.weekend_offers(origin)
            else:
                deals, _ = await self._offers(origin)
        except TPError as exc:
            log.info("deals post: no prices (%s)", exc)
            return None
        earliest = self._earliest()
        by = data.by_iata()
        for iata, offer in deals.items():
            dest = by.get(iata)
            price = to_sar(offer.price, offer.currency)
            if dest is None or price is None or offer.departure_at[:10] < earliest:
                continue
            rows.append((dest, offer, price))
        rows.sort(key=lambda r: r[2])
        rows = rows[:POST_ROWS]
        if len(rows) < MIN_POST_ROWS:
            return None
        text = texts.channel_post(origin, rows, edition)
        buttons = []
        for dest, offer, price in rows:
            dep = dts.decode_day(offer.departure_at[:10].replace("-", ""))
            back = dts.decode_day(offer.return_at[:10].replace("-", "")) if offer.return_at else None
            wish = dts.DateWish(depart=dep, ret=back) if dep else dts.DateWish()
            buttons.append([button(f"✈️ {dest.ar} — {round(price):,} ر.س", url=self.deep_link(trip_payload(dest, wish)))])
        buttons.append([button("🤖 افتح سفرتي: تقويم الأسعار والتنبيهات", url=f"https://t.me/{self.bot_username}")])
        fingerprint = hashlib.sha1(
            "|".join(f"{d.iata}{round(p)}{o.departure_at[:10]}" for d, o, p in rows).encode()
        ).hexdigest()[:16]
        return text, keyboard(buttons), fingerprint

    def post_plan(self) -> tuple[str, str]:
        """(origin, edition) of today's post."""
        today = self._today()
        edition = "weekend" if today.weekday() == WEEKEND_WEEKDAY else "daily"
        return POST_ORIGINS[today.weekday()], edition

    async def deals_preview(self, chat_id: int, uid: int, origin: str | None = None) -> None:
        plan_origin, edition = self.post_plan()
        origin = origin or plan_origin
        built = await self.build_deals_post(origin, edition)
        if built is None:
            await self.say(chat_id, texts.DEALS_NONE)
            return
        text, markup, fingerprint = built
        self._draft = (text, markup, fingerprint)
        confirm = [[button("📢 انشر في القناة الآن", data="pub:ok")]] if self.channel_chat() else []
        await self.say(chat_id, text, keyboard(markup["inline_keyboard"] + confirm))

    def welcome_markup(self) -> dict | None:
        if not self.bot_username:
            return None
        return keyboard([[button(texts.WELCOME_BUTTON, url=f"https://t.me/{self.bot_username}")]])

    async def welcome_preview(self, chat_id: int) -> None:
        """The channel's welcome post (a picture with a button that opens the bot), shown to the admin first."""
        image = data.welcome_image()
        if image is None:
            await self.say(chat_id, texts.WELCOME_NO_IMAGE)
            return
        rows = (self.welcome_markup() or {}).get("inline_keyboard", [])
        if self.channel_chat():
            rows = rows + [[button("📢 انشر في القناة الآن", data="pub:welcome")]]
        await self.api.send_photo(chat_id, image, texts.WELCOME_POST, keyboard(rows) if rows else None)
        await self.say(chat_id, texts.WELCOME_PREVIEW)

    async def publish_welcome(self, chat_id: int) -> None:
        channel = self.channel_chat()
        image = data.welcome_image()
        if not channel:
            await self.say(chat_id, texts.AUTOPOST_NO_CHANNEL)
            return
        if image is None:
            await self.say(chat_id, texts.WELCOME_NO_IMAGE)
            return
        try:
            await self.api.send_photo(channel, image, texts.WELCOME_POST, self.welcome_markup())
        except TelegramError as exc:
            log.warning("could not post the welcome picture to the channel: %s", exc)
            await self.say(chat_id, texts.channel_failed(str(exc.status)))
            return
        await self.say(chat_id, texts.DEALS_POSTED)

    async def publish_callback(self, chat_id: int, uid: int, mid: int | None, arg: str = "") -> None:
        if not self.db.is_admin(uid):
            await self.say(chat_id, texts.ADMIN_ONLY)
            return
        if arg == "welcome":
            await self.publish_welcome(chat_id)
            return
        draft = self._draft
        channel = self.channel_chat()
        if not draft or not channel:
            await self.say(chat_id, texts.DEALS_NO_DRAFT)
            return
        try:
            await self.api.send_message(channel, draft[0], draft[1])
        except TelegramError as exc:
            log.warning("could not post to the channel: %s", exc)
            await self.say(chat_id, texts.channel_failed(str(exc.status)))
            return
        self.db.kv_set("last_post_hash", draft[2])
        self._draft = None
        await self.say(chat_id, texts.DEALS_POSTED)

    async def autopost_command(self, chat_id: int, arg: str) -> None:
        arg = arg.strip().lower()
        channel = self.channel_chat()
        if arg in ("on", "تشغيل", "1"):
            if not channel:
                await self.say(chat_id, texts.AUTOPOST_NO_CHANNEL)
                return
            self.db.kv_set("autopost", "1")
            self.db.kv_set("post_fails", "0")
            await self.say(chat_id, texts.autopost_status(True, channel, POST_HOUR))
        elif arg in ("off", "ايقاف", "0"):
            self.db.kv_set("autopost", "0")
            await self.say(chat_id, texts.autopost_status(False, channel, POST_HOUR))
        else:
            await self.say(chat_id, texts.autopost_status(self.autopost_on(), channel, POST_HOUR))

    async def channel_ready(self) -> tuple[bool, str]:
        """(can the bot post there, short reason) - used by /diag."""
        channel = self.channel_chat()
        if not channel:
            return False, "رابط القناة غير عام"
        if not self.bot_id:
            return False, "رقم البوت غير معروف"
        try:
            member = await self.api.get_chat_member(channel, self.bot_id)
        except TelegramError as exc:
            return False, f"تعذّر فحص القناة ({exc.status}): تأكد أن البوت مشرف فيها وأن الرابط صحيح"
        status = member.get("status")
        if status == "creator":
            return True, ""
        if status == "administrator" and member.get("can_post_messages", False):
            return True, ""
        return False, "ضع البوت مشرفًا في القناة مع صلاحية النشر"

    async def diag_extras(self) -> list[tuple[str, bool | None]]:
        if not self.settings.channel_url:
            return []
        ready, why = await self.channel_ready()
        out: list[tuple[str, bool | None]] = [("النشر في القناة" + (f" — {why}" if why else ""), ready)]
        if not self.autopost_on():
            out.append(("النشر التلقائي: متوقف (اختياري) — فعّله بـ /autopost on", None))
        elif ready:
            out.append((f"النشر التلقائي: يعمل (يوميًا بعد الساعة {POST_HOUR}:00)", True))
        else:
            out.append(("النشر التلقائي: مفعّل لكن القناة غير جاهزة", False))
        return out

    # ------------------------------------------------------------------
    # background loops
    # ------------------------------------------------------------------
    async def channel_loop(self, stop: asyncio.Event) -> None:
        while not stop.is_set():
            try:
                await self.channel_tick()
            except Exception:  # noqa: BLE001 - the loop must outlive any single bad pass
                log.exception("channel pass failed")
            await self._sleep(stop, CHANNEL_CHECK)

    async def channel_tick(self) -> bool:
        """Post today's deals if it is time. Returns True when something was posted."""
        channel = self.channel_chat()
        if not (self.autopost_on() and channel):
            return False
        now = _saudi_now(self.clock())
        today = now.date().isoformat()
        if now.hour < POST_HOUR or self.db.kv_get("last_post_day") == today:
            return False
        origin, edition = self.post_plan()
        built = await self.build_deals_post(origin, edition)
        if built is None:
            return False                              # not enough prices yet; try again at the next look
        text, markup, fingerprint = built
        if self.db.kv_get("last_post_hash") == fingerprint:
            self.db.kv_set("last_post_day", today)    # the same deals as yesterday: say nothing new
            return False
        try:
            await self.api.send_message(channel, text, markup)
        except TelegramError as exc:
            fails = self.db.kv_incr("post_fails")
            log.warning("channel post failed (%s), failure %s of %s", exc.status, fails, MAX_POST_FAILS)
            if fails >= MAX_POST_FAILS:
                self.db.kv_set("autopost", "0")
                await self._tell_admins(texts.channel_failed(str(exc.status)))
            return False
        self.db.kv_set("post_fails", "0")
        self.db.kv_set("last_post_day", today)
        self.db.kv_set("last_post_hash", fingerprint)
        return True

    async def _tell_admins(self, text: str) -> None:
        for uid in self.db.admin_ids():
            with contextlib.suppress(TelegramError):
                await self.api.send_message(uid, text)

    # ------------------------------------------------------------------
    # backups
    # ------------------------------------------------------------------
    def backup_dir(self) -> Path | None:
        path = self.settings.db_path
        if not path or path == ":memory:":
            return None
        return Path(path).parent / "backups"

    def make_backup(self) -> Path | None:
        folder = self.backup_dir()
        if folder is None:
            return None
        folder.mkdir(parents=True, exist_ok=True)
        stamp = _saudi_now(self.clock()).strftime("%Y%m%d-%H%M")
        target = folder / f"safrati-{stamp}.db"
        self.db.backup_to(str(target))
        for old in sorted(folder.glob("safrati-*.db"))[:-BACKUPS_KEPT]:
            with contextlib.suppress(OSError):
                old.unlink()
        return target

    async def backup_command(self, chat_id: int) -> None:
        try:
            target = await asyncio.to_thread(self.make_backup)
        except Exception:  # noqa: BLE001 - report instead of crashing the handler
            log.exception("backup failed")
            await self.say(chat_id, texts.BACKUP_FAILED)
            return
        if target is None:
            await self.say(chat_id, texts.BACKUP_FAILED)
            return
        await self.say(chat_id, texts.backup_done(target.name, target.stat().st_size))

    async def maintenance_loop(self, stop: asyncio.Event) -> None:
        while not stop.is_set():
            try:
                now = _saudi_now(self.clock())
                today = now.date().isoformat()
                if now.hour >= BACKUP_HOUR and self.db.kv_get("last_backup_day") != today:
                    if await asyncio.to_thread(self.make_backup) is not None:
                        self.db.kv_set("last_backup_day", today)
            except Exception:  # noqa: BLE001
                log.exception("maintenance failed")
            await self._sleep(stop, 3600)


def _saudi_now(timestamp: float) -> datetime:
    return datetime.fromtimestamp(timestamp, SAUDI_TZ)
