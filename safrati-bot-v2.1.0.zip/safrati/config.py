"""Settings read from environment variables (docker compose loads them from .env)."""
from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Mapping

BOT_TOKEN_RE = re.compile(r"^\d{6,}:[A-Za-z0-9_-]{30,}$")
CHANNEL_URL_RE = re.compile(r"^https://t\.me/[A-Za-z0-9_+]{3,64}$")


class ConfigError(Exception):
    """Raised for a missing or malformed setting. Messages never contain secrets."""


@dataclass(frozen=True)
class Settings:
    bot_token: str
    tp_token: str = ""
    tp_marker: str = ""
    tp_trs: str = ""
    currency: str = "sar"
    db_path: str = "/data/safrati.db"
    heartbeat_path: str = "/data/heartbeat"
    daily_search_limit: int = 40
    cache_minutes: int = 30
    admin_code: str = ""
    log_level: str = "INFO"
    tp_market: str = ""
    tp_show_all: bool = False
    channel_url: str = ""

    @property
    def prices_enabled(self) -> bool:
        return bool(self.tp_token)

    @property
    def links_api_enabled(self) -> bool:
        return bool(self.tp_token and self.tp_marker.isdigit() and self.tp_trs.isdigit())


def _int(env: Mapping[str, str], name: str, default: int, low: int, high: int) -> int:
    raw = (env.get(name) or "").strip()
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError as exc:
        raise ConfigError(f"{name} must be a whole number") from exc
    if not low <= value <= high:
        raise ConfigError(f"{name} must be between {low} and {high}")
    return value


def load_settings(env: Mapping[str, str] | None = None) -> Settings:
    env = os.environ if env is None else env
    token = (env.get("BOT_TOKEN") or "").strip()
    if not token:
        raise ConfigError("BOT_TOKEN is missing")
    if not BOT_TOKEN_RE.match(token):
        raise ConfigError("BOT_TOKEN does not look like a Telegram bot token")

    marker = (env.get("TP_MARKER") or "").strip()
    trs = (env.get("TP_TRS") or "").strip()
    if marker and not marker.isdigit():
        raise ConfigError("TP_MARKER must be digits only")
    if trs and not trs.isdigit():
        raise ConfigError("TP_TRS must be digits only")

    currency = (env.get("CURRENCY") or "sar").strip().lower()
    if not re.fullmatch(r"[a-z]{3}", currency):
        raise ConfigError("CURRENCY must be a 3-letter code such as sar or usd")

    market = (env.get("TP_MARKET") or "").strip().lower()
    if market and not re.fullmatch(r"[a-z]{2}", market):
        raise ConfigError("TP_MARKET must be a 2-letter code or empty")

    channel = (env.get("CHANNEL_URL") or "").strip()
    if channel and not CHANNEL_URL_RE.match(channel):
        raise ConfigError("CHANNEL_URL must look like https://t.me/name")

    admin_code = (env.get("ADMIN_CODE") or "").strip()
    if admin_code and len(admin_code) < 8:
        raise ConfigError("ADMIN_CODE must be at least 8 characters")

    return Settings(
        bot_token=token,
        tp_token=(env.get("TP_TOKEN") or "").strip(),
        tp_marker=marker,
        tp_trs=trs,
        currency=currency,
        db_path=(env.get("DB_PATH") or "/data/safrati.db").strip(),
        heartbeat_path=(env.get("HEARTBEAT_PATH") or "/data/heartbeat").strip(),
        daily_search_limit=_int(env, "DAILY_SEARCH_LIMIT", 40, 1, 1000),
        cache_minutes=_int(env, "CACHE_MINUTES", 30, 1, 1440),
        admin_code=admin_code,
        log_level=(env.get("LOG_LEVEL") or "INFO").strip().upper(),
        tp_market=market,
        tp_show_all=(env.get("TP_SHOW_ALL") or "").strip().lower() in ("1", "true", "yes"),
        channel_url=channel,
    )
