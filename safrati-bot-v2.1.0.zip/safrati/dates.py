"""Dates: reading them out of free Arabic/English text, and the small calendar helpers the buttons need.

Standard library only. The text given to parse_dates must already be normalised with data.norm_keep
(Arabic digits turned into ASCII, diacritics removed, alef/ya/ta-marbuta unified, lower-cased).
"""
from __future__ import annotations

import calendar
import re
from dataclasses import dataclass, field
from datetime import date, timedelta

MIN_AHEAD_DAYS = 1      # earliest departure: tomorrow
MAX_AHEAD_DAYS = 330    # the provider's price cache does not reach much further than this
SUNDAY_FIRST = 6

_MONTHS: dict[str, int] = {
    # Gulf / Egypt
    "يناير": 1, "فبراير": 2, "مارس": 3, "ابريل": 4, "مايو": 5, "يونيو": 6, "يوليو": 7, "اغسطس": 8,
    "سبتمبر": 9, "اكتوبر": 10, "نوفمبر": 11, "ديسمبر": 12,
    # Levant
    "كانون الثاني": 1, "شباط": 2, "اذار": 3, "نيسان": 4, "ايار": 5, "حزيران": 6, "تموز": 7, "اب": 8,
    "ايلول": 9, "تشرين الاول": 10, "تشرين الثاني": 11, "كانون الاول": 12,
    # English
    "january": 1, "jan": 1, "february": 2, "feb": 2, "march": 3, "mar": 3, "april": 4, "apr": 4, "may": 5,
    "june": 6, "jun": 6, "july": 7, "jul": 7, "august": 8, "aug": 8, "september": 9, "sept": 9, "sep": 9,
    "october": 10, "oct": 10, "november": 11, "nov": 11, "december": 12, "dec": 12,
}
# words that are also ordinary words: they only count as a month when a day number sits next to them
_NEEDS_A_DAY = {"اب", "may", "mar", "jan", "feb", "apr", "jun", "jul", "aug", "sep", "sept", "oct", "nov", "dec"}


def _alternation(names) -> str:
    return "|".join(r"\s+".join(map(re.escape, n.split(" "))) for n in sorted(names, key=len, reverse=True))


_MONTH = _alternation(_MONTHS)
_MONTH_ALONE = _alternation(n for n in _MONTHS if n not in _NEEDS_A_DAY)

_TO = r"(?:-|–|—|الي|حتي|لين|to)"
# a number followed by one of these is an amount, not a day: "3/4 ريال". «يومين» and the week words are left out on
# purpose, because "20/12 يومين" and "20/12 اسبوع" are a date followed by how long the trip lasts.
_UNIT_AFTER = (
    r"(?!\s*(?:يوم(?!ين)|ايام|ليل|ليال|ليله|شهر|اشهر|سنه|سنوات|ساعه|ساعات|ريال|الف|الاف|k\b|ك\b|"
    r"شخص|اشخاص|افراد|فرد|اطفال|كيلو|%))"
)
_PRE = r"[وبلف]?"   # one-letter prefixes: "في ديسمبر" is spaced, "بديسمبر" and "لديسمبر" are not

_ISO = re.compile(r"(?<![\d/.\-])(20\d{2})-(\d{1,2})-(\d{1,2})(?!\d)")
_NUM_RANGE = re.compile(
    rf"(?<![\d/.\-])(\d{{1,2}})[/\-.](\d{{1,2}})\s*{_TO}\s*(\d{{1,2}})[/\-.](\d{{1,2}})(?![\d/.\-]\d)"
)
_DMY = re.compile(r"(?<![\d/.\-])(\d{1,2})[/\-.](\d{1,2})[/\-.](20\d{2}|\d{2})(?!\d)")
_DM = re.compile(r"(?<![\d/.\-])(\d{1,2})[/\-](\d{1,2})(?!\d)(?![/\-.]\d)" + _UNIT_AFTER)
_DAYS_RANGE_MONTH = re.compile(
    rf"(?<!\d)(\d{{1,2}})\s*{_TO}\s*(\d{{1,2}})\s*(?:من\s*)?(?:شهر\s*)?{_PRE}({_MONTH})(?!\w)(?:\s*(20\d{{2}}))?"
)
_DAY_MONTH = re.compile(
    rf"(?<!\d)(\d{{1,2}})\s*(?:من\s*)?(?:شهر\s*)?{_PRE}({_MONTH})(?!\w)(?:\s*(20\d{{2}}))?"
)
_MONTH_DAY = re.compile(rf"(?<!\w){_PRE}({_MONTH})\s+(\d{{1,2}})(?!\d)" + _UNIT_AFTER)
_MONTH_NUM = re.compile(r"(?<!\w)شهر\s*(\d{1,2})(?!\d)")
_MONTH_ONLY = re.compile(rf"(?<!\w){_PRE}({_MONTH_ALONE})(?!\w)(?:\s*(20\d{{2}}))?")

_TOMORROW = re.compile(r"(?<!\w)(?:بكره|بكرا|غدا|باكر)(?!\w)")
_AFTER = re.compile(r"(?<!\w)بعد\s*(?:(\d{1,3})\s*(?:يوم|ايام)|(اسبوعين|اسبوع|شهرين|شهر))(?!\w)")
_AFTER_DAYS = {"اسبوع": 7, "اسبوعين": 14, "شهر": 30, "شهرين": 60}
_ONE_WAY = re.compile(
    r"(?<!\w)(?:(?:ذهاب|رايح|رايحه)\s*(?:فقط|بس|لا غير)|اتجاه\s*واحد|one\s*way|oneway|"
    r"(?:بدون|من غير|بلا)\s*(?:عوده|رجوع|رجعه))(?!\w)"
)

_NEXT_MONTH = re.compile(r"(?<!\w)(?:ال)?شهر\s+(?:ال)?(?:جاي|جايه|قادم|قادمه)(?!\w)")
_THIS_MONTH = re.compile(
    r"(?<!\w)(?:(?:هذا|هاذا|هذي|هذه|هاذي)\s+(?:ال)?شهر|هالشهر|هلشهر|(?:ال)?شهر\s+(?:هذا|هاذا|ذا|الحالي))(?!\w)"
)

_WEEKEND = re.compile(
    r"(?<!\w)(?:(?:لل|[وبلف]?(?:ال)?)(?:ويكند|وكند|ويك\s*اند|weekend|week\s*end)"
    r"|(?:نهايه|نهايات|اخر)\s+(?:ال)?(?:اسبوع|اسبوعين))(?!\w)"
)

_WORD_DAYS = {"ثلاثه": 3, "اربعه": 4, "خمسه": 5, "سته": 6, "سبعه": 7, "ثمانيه": 8, "تسعه": 9, "عشره": 10}
_STAY_NUM = re.compile(r"(?<![\w/.\-])(?:لمده\s*|مده\s*)?(\d{1,2})\s*(?:يوم|ايام|ليله|ليال|ليالي)(?!\w)")
_STAY_WORD = re.compile(
    r"(?<!\w)(?:لمده\s*|مده\s*)?(" + "|".join(_WORD_DAYS) + r")\s*(?:ايام|يوم|ليال|ليالي)(?!\w)"
)
_STAY_TWO = re.compile(r"(?<!\w)(?:لمده\s*|مده\s*)?(يومين)(?!\w)")
_STAY_WEEKS = re.compile(
    r"(?<!\w)(?:لمده\s*|مده\s*)?(?:(\d)\s*اسابيع|(ثلاثه|اربعه)\s*اسابيع|(اسبوعين|اسبوعان)|(اسبوع))(?!\w)"
)
MIN_STAY_TEXT, MAX_STAY_TEXT = 2, 30       # a trip length typed in words or digits outside this range is ignored


@dataclass(frozen=True)
class DateWish:
    """What the person asked for: an exact day (and maybe a return day), or just a month, and/or one way.

    `stay` is a wished trip length in days and `weekend` a wish for a Thursday/Friday-to-weekend trip;
    neither counts as "dates" (has_dates stays False for them)."""

    depart: date | None = None
    ret: date | None = None
    month: str | None = None       # "YYYY-MM", only when no exact day was given
    one_way: bool = False
    stay: int | None = None
    weekend: bool = False

    @property
    def has_dates(self) -> bool:
        return self.depart is not None or self.month is not None

    @property
    def month_key(self) -> str | None:
        return self.depart.strftime("%Y-%m") if self.depart else self.month


@dataclass
class _Hit:
    pos: int
    days: list[date] = field(default_factory=list)
    month: str | None = None


def _scan(pattern: re.Pattern, text: str) -> tuple[str, list[re.Match]]:
    """All matches of the pattern, and the text with those parts replaced by spaces (positions stay put)."""
    matches = list(pattern.finditer(text))
    return pattern.sub(lambda m: " " * (m.end() - m.start()), text), matches


def _explicit(year: int, month: int, day: int) -> date | None:
    try:
        return date(year, month, day)
    except ValueError:
        return None


def _next_day(day: int, month: int, ref: date) -> date | None:
    """The first date with this day and month that is not before `ref`."""
    if not 1 <= month <= 12:
        return None
    for year in (ref.year, ref.year + 1, ref.year + 2):
        candidate = _explicit(year, month, day)
        if candidate is not None and candidate >= ref:
            return candidate
    return None


def _month_number(name: str) -> int:
    return _MONTHS[re.sub(r"\s+", " ", name)]


def _month_key(month: int, year: int | None, ref: date) -> str:
    if year is None:
        year = ref.year if month >= ref.month else ref.year + 1
    return f"{year:04d}-{month:02d}"


def _days(*values: date | None) -> list[date]:
    return [v for v in values if v is not None]


def _add_months(day: date, count: int) -> str:
    index = day.year * 12 + (day.month - 1) + count
    return f"{index // 12:04d}-{index % 12 + 1:02d}"


def _weeks(m: re.Match) -> int:
    if m.group(1):
        return int(m.group(1)) * 7
    if m.group(2):
        return _WORD_DAYS[m.group(2)] * 7
    return 14 if m.group(3) else 7


def parse_dates(text: str, today: date) -> tuple[DateWish, str]:
    """Find dates in `text`. Returns what was found and the text with those parts blanked out."""
    work = text
    hits: list[_Hit] = []

    work, found = _scan(_ISO, work)
    for m in found:
        y, mo, d = map(int, m.groups())
        hits.append(_Hit(m.start(), _days(_explicit(y, mo, d))))

    work, found = _scan(_NUM_RANGE, work)
    for m in found:
        d1, m1, d2, m2 = map(int, m.groups())
        first = _next_day(d1, m1, today)
        second = _next_day(d2, m2, first or today)
        hits.append(_Hit(m.start(), _days(first, second)))

    work, found = _scan(_DMY, work)
    for m in found:
        d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        hits.append(_Hit(m.start(), _days(_explicit(y + 2000 if y < 100 else y, mo, d))))

    work, found = _scan(_DM, work)
    for m in found:
        hits.append(_Hit(m.start(), _days(_next_day(int(m.group(1)), int(m.group(2)), today))))

    work, found = _scan(_DAYS_RANGE_MONTH, work)
    for m in found:
        d1, d2, mo = int(m.group(1)), int(m.group(2)), _month_number(m.group(3))
        year = int(m.group(4)) if m.group(4) else None
        second = _explicit(year, mo, d2) if year else _next_day(d2, mo, today)
        first = None
        if second is not None:
            if d2 >= d1:
                first = _explicit(second.year, mo, d1)
            else:                                           # "28 - 3 يناير": the first day is in the month before
                before = (second.year - 1, 12) if mo == 1 else (second.year, mo - 1)
                first = _explicit(before[0], before[1], d1)
        hits.append(_Hit(m.start(), _days(first, second)))

    work, found = _scan(_DAY_MONTH, work)
    for m in found:
        d, mo = int(m.group(1)), _month_number(m.group(2))
        year = int(m.group(3)) if m.group(3) else None
        hits.append(_Hit(m.start(), _days(_explicit(year, mo, d) if year else _next_day(d, mo, today))))

    work, found = _scan(_MONTH_DAY, work)
    for m in found:
        hits.append(_Hit(m.start(), _days(_next_day(int(m.group(2)), _month_number(m.group(1)), today))))

    work, found = _scan(_MONTH_NUM, work)
    for m in found:
        if 1 <= int(m.group(1)) <= 12:
            hits.append(_Hit(m.start(), month=_month_key(int(m.group(1)), None, today)))

    work, found = _scan(_MONTH_ONLY, work)
    for m in found:
        year = int(m.group(2)) if m.group(2) else None
        hits.append(_Hit(m.start(), month=_month_key(_month_number(m.group(1)), year, today)))

    work, found = _scan(_NEXT_MONTH, work)
    for m in found:
        hits.append(_Hit(m.start(), month=_add_months(today, 1)))

    work, found = _scan(_THIS_MONTH, work)
    for m in found:
        hits.append(_Hit(m.start(), month=_add_months(today, 0)))

    work, found = _scan(_TOMORROW, work)
    for m in found:
        hits.append(_Hit(m.start(), _days(today + timedelta(days=1))))

    work, found = _scan(_AFTER, work)
    for m in found:
        days = int(m.group(1)) if m.group(1) else _AFTER_DAYS[m.group(2)]
        hits.append(_Hit(m.start(), _days(today + timedelta(days=days))))

    work, found = _scan(_ONE_WAY, work)
    one_way = bool(found)

    work, found = _scan(_WEEKEND, work)
    weekend = bool(found)

    stay = None
    for pattern, reader in (
        (_STAY_NUM, lambda m: int(m.group(1))),
        (_STAY_WORD, lambda m: _WORD_DAYS[m.group(1)]),
        (_STAY_TWO, lambda m: 2),
        (_STAY_WEEKS, _weeks),
    ):
        work, found = _scan(pattern, work)
        for m in found:
            days_wished = reader(m)
            if stay is None and MIN_STAY_TEXT <= days_wished <= MAX_STAY_TEXT:
                stay = days_wished

    hits.sort(key=lambda h: h.pos)
    days = [d for h in hits for d in h.days]
    depart = ret = None
    if days:
        depart = days[0]
        if len(days) > 1:
            ret = days[1]
            if ret < depart:                # typed the other way round
                depart, ret = ret, depart
    month = None if depart else next((h.month for h in hits if h.month), None)
    if depart and ret:
        stay = None                         # exact days already say how long the trip is
    return DateWish(depart=depart, ret=ret, month=month, one_way=one_way, stay=stay, weekend=weekend), work


def problem(wish: DateWish, today: date) -> str | None:
    """'past' or 'far' when the request cannot be searched, otherwise None."""
    earliest = today + timedelta(days=MIN_AHEAD_DAYS)
    latest = today + timedelta(days=MAX_AHEAD_DAYS)
    if wish.depart:
        if wish.depart < earliest:
            return "past"
        if wish.depart > latest:
            return "far"
        if wish.ret and wish.ret > latest + timedelta(days=60):
            return "far"
    elif wish.month:
        year, month = int(wish.month[:4]), int(wish.month[5:])
        if date(year, month, calendar.monthrange(year, month)[1]) < earliest:
            return "past"
        if date(year, month, 1) > latest:
            return "far"
    return None


# ---- calendar helpers for the buttons ----------------------------------------------------------------
def month_choices(today: date, count: int = 6) -> list[str]:
    """Month keys in which the person can still travel, starting from the current one."""
    earliest = today + timedelta(days=MIN_AHEAD_DAYS)
    latest = today + timedelta(days=MAX_AHEAD_DAYS)
    out: list[str] = []
    year, month = today.year, today.month
    for _ in range(24):
        first = date(year, month, 1)
        last = date(year, month, calendar.monthrange(year, month)[1])
        if first > latest or len(out) >= count:
            break
        if last >= earliest:
            out.append(f"{year:04d}-{month:02d}")
        year, month = (year + 1, 1) if month == 12 else (year, month + 1)
    return out


def month_grid(month_key: str, today: date) -> list[list[tuple[int, bool]]]:
    """Weeks (Sunday first) of (day number, selectable). Day number 0 pads the first and last week."""
    year, month = int(month_key[:4]), int(month_key[5:])
    earliest = today + timedelta(days=MIN_AHEAD_DAYS)
    latest = today + timedelta(days=MAX_AHEAD_DAYS)
    weeks = calendar.Calendar(firstweekday=SUNDAY_FIRST).monthdayscalendar(year, month)
    return [[(d, bool(d) and earliest <= date(year, month, d) <= latest) for d in week] for week in weeks]


def encode_day(day: date | None) -> str:
    return day.strftime("%Y%m%d") if day else "-"


def decode_day(token: str) -> date | None:
    if len(token) == 8 and token.isdigit():
        return _explicit(int(token[:4]), int(token[4:6]), int(token[6:]))
    return None


def encode_month(month_key: str) -> str:
    return month_key.replace("-", "")


def decode_month(token: str) -> str | None:
    if len(token) == 6 and token.isdigit() and 1 <= int(token[4:]) <= 12:
        return f"{token[:4]}-{token[4:]}"
    return None


def encode_when(wish: DateWish) -> tuple[str, str]:
    """The two button tokens that carry a request: (departure day or month, return day)."""
    if wish.depart:
        return encode_day(wish.depart), encode_day(wish.ret)
    if wish.month:
        return encode_month(wish.month), "-"
    return "-", "-"


def decode_when(dep: str, ret: str, one_way: bool) -> DateWish | None:
    """Rebuild a request from button tokens; None when the tokens are malformed."""
    if dep == "-":
        return DateWish(one_way=one_way) if ret == "-" else None
    day = decode_day(dep)
    if day is not None:
        back = decode_day(ret) if ret != "-" else None
        if ret != "-" and back is None:
            return None
        return DateWish(depart=day, ret=None if one_way else back, one_way=one_way)
    month = decode_month(dep)
    if month is not None and ret == "-":
        return DateWish(month=month, one_way=one_way)
    return None
