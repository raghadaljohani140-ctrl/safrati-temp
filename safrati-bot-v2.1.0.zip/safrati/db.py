"""Tiny SQLite store. Keeps only Telegram numeric ids and the user's own settings."""
from __future__ import annotations

import sqlite3
import threading
from datetime import date, datetime, timedelta, timezone

# Saudi Arabia is UTC+3 all year (no daylight saving), so a fixed offset needs no timezone database.
SAUDI_TZ = timezone(timedelta(hours=3))


def saudi_today() -> date:
    return datetime.now(SAUDI_TZ).date()


SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
    tg_id      INTEGER PRIMARY KEY,
    origin     TEXT    NOT NULL DEFAULT 'RUH',
    visa_only  INTEGER NOT NULL DEFAULT 0,
    created_at TEXT    NOT NULL,
    last_seen  TEXT    NOT NULL,
    onboarded  INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS saved(
    tg_id    INTEGER NOT NULL,
    iata     TEXT    NOT NULL,
    saved_at TEXT    NOT NULL,
    PRIMARY KEY (tg_id, iata)
);
CREATE TABLE IF NOT EXISTS seen(
    tg_id   INTEGER NOT NULL,
    iata    TEXT    NOT NULL,
    seen_at TEXT    NOT NULL,
    PRIMARY KEY (tg_id, iata)
);
CREATE TABLE IF NOT EXISTS usage(
    tg_id INTEGER NOT NULL,
    day   TEXT    NOT NULL,
    n     INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (tg_id, day)
);
CREATE TABLE IF NOT EXISTS admins(tg_id INTEGER PRIMARY KEY);
CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS watches(
    id         INTEGER PRIMARY KEY,
    tg_id      INTEGER NOT NULL,
    origin     TEXT    NOT NULL,
    dest       TEXT    NOT NULL,
    scope      TEXT    NOT NULL,
    stay       INTEGER NOT NULL DEFAULT 0,
    target     INTEGER,
    base       INTEGER,
    last_price INTEGER,
    last_day   TEXT,
    notified   INTEGER,
    created_at TEXT    NOT NULL,
    checked_at TEXT,
    expires    TEXT    NOT NULL,
    UNIQUE (tg_id, origin, dest, scope, stay)
);
CREATE INDEX IF NOT EXISTS watches_user ON watches(tg_id);
CREATE INDEX IF NOT EXISTS watches_due ON watches(checked_at);
CREATE TABLE IF NOT EXISTS popular(iata TEXT PRIMARY KEY, n INTEGER NOT NULL DEFAULT 0);
"""

ORIGINS = ("RUH", "JED", "DMM", "MED", "AHB", "GIZ", "TIF", "ELQ", "TUU")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def iso_utc(timestamp: float) -> str:
    """A Unix time in the same text form the tables use, so the two can be compared as text."""
    return datetime.fromtimestamp(timestamp, timezone.utc).isoformat(timespec="seconds")


class DB:
    def __init__(self, path: str):
        self._lock = threading.Lock()
        self._con = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self._con.row_factory = sqlite3.Row
        with self._lock:
            if path != ":memory:":
                self._con.execute("PRAGMA journal_mode=WAL")
            self._con.execute("PRAGMA synchronous=NORMAL")
            self._con.executescript(SCHEMA)
            self._migrate()

    def _migrate(self) -> None:
        columns = {row["name"] for row in self._con.execute("PRAGMA table_info(users)")}
        if "onboarded" not in columns:
            # a database from before version 2: everyone in it has already used the bot
            self._con.execute("ALTER TABLE users ADD COLUMN onboarded INTEGER NOT NULL DEFAULT 0")
            self._con.execute("UPDATE users SET onboarded=1")

    def close(self) -> None:
        with self._lock:
            self._con.close()

    # ---- users -------------------------------------------------------
    def touch_user(self, tg_id: int) -> sqlite3.Row:
        now = _now()
        with self._lock:
            self._con.execute(
                "INSERT INTO users(tg_id, created_at, last_seen) VALUES(?,?,?) "
                "ON CONFLICT(tg_id) DO UPDATE SET last_seen=excluded.last_seen",
                (tg_id, now, now),
            )
            return self._con.execute("SELECT * FROM users WHERE tg_id=?", (tg_id,)).fetchone()

    def set_origin(self, tg_id: int, origin: str) -> None:
        if origin not in ORIGINS:
            raise ValueError("unknown origin")
        self.touch_user(tg_id)
        with self._lock:
            self._con.execute("UPDATE users SET origin=?, onboarded=1 WHERE tg_id=?", (origin, tg_id))

    def set_visa_only(self, tg_id: int, value: bool) -> None:
        self.touch_user(tg_id)
        with self._lock:
            self._con.execute("UPDATE users SET visa_only=? WHERE tg_id=?", (1 if value else 0, tg_id))

    # ---- saved -------------------------------------------------------
    def save(self, tg_id: int, iata: str) -> None:
        with self._lock:
            self._con.execute(
                "INSERT OR IGNORE INTO saved(tg_id, iata, saved_at) VALUES(?,?,?)", (tg_id, iata, _now())
            )

    def unsave(self, tg_id: int, iata: str) -> None:
        with self._lock:
            self._con.execute("DELETE FROM saved WHERE tg_id=? AND iata=?", (tg_id, iata))

    def is_saved(self, tg_id: int, iata: str) -> bool:
        with self._lock:
            row = self._con.execute("SELECT 1 FROM saved WHERE tg_id=? AND iata=?", (tg_id, iata)).fetchone()
        return row is not None

    def saved_list(self, tg_id: int) -> list[str]:
        with self._lock:
            rows = self._con.execute(
                "SELECT iata FROM saved WHERE tg_id=? ORDER BY saved_at DESC", (tg_id,)
            ).fetchall()
        return [r["iata"] for r in rows]

    # ---- seen --------------------------------------------------------
    def mark_seen(self, tg_id: int, iata: str) -> None:
        with self._lock:
            self._con.execute(
                "INSERT OR REPLACE INTO seen(tg_id, iata, seen_at) VALUES(?,?,?)", (tg_id, iata, _now())
            )

    def seen_set(self, tg_id: int) -> set[str]:
        with self._lock:
            rows = self._con.execute("SELECT iata FROM seen WHERE tg_id=?", (tg_id,)).fetchall()
        return {r["iata"] for r in rows}

    def clear_seen(self, tg_id: int) -> None:
        with self._lock:
            self._con.execute("DELETE FROM seen WHERE tg_id=?", (tg_id,))

    # ---- daily usage -------------------------------------------------
    def use_search(self, tg_id: int, limit: int, today: date | None = None) -> bool:
        """Count one search. Returns False (and counts nothing) once the daily limit is reached."""
        day = (today or saudi_today()).isoformat()
        with self._lock:
            row = self._con.execute("SELECT n FROM usage WHERE tg_id=? AND day=?", (tg_id, day)).fetchone()
            used = row["n"] if row else 0
            if used >= limit:
                return False
            self._con.execute(
                "INSERT INTO usage(tg_id, day, n) VALUES(?,?,1) "
                "ON CONFLICT(tg_id, day) DO UPDATE SET n=n+1",
                (tg_id, day),
            )
            self._con.execute("DELETE FROM usage WHERE day < date(?, '-7 day')", (day,))
            return True

    def set_onboarded(self, tg_id: int) -> None:
        self.touch_user(tg_id)
        with self._lock:
            self._con.execute("UPDATE users SET onboarded=1 WHERE tg_id=?", (tg_id,))

    # ---- price watches -----------------------------------------------
    def add_watch(
        self, tg_id: int, origin: str, dest: str, scope: str, stay: int, base: int | None, expires: str,
        at: str | None = None,
    ) -> tuple[int, bool]:
        """(watch id, created). The same route, scope and stay for the same person is stored once."""
        now = at or _now()
        with self._lock:
            cur = self._con.execute(
                "INSERT OR IGNORE INTO watches(tg_id, origin, dest, scope, stay, base, last_price, created_at, "
                "checked_at, expires) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (tg_id, origin, dest, scope, stay, base, base, now, now, expires),   # the price was just looked at
            )
            created = cur.rowcount == 1
            row = self._con.execute(
                "SELECT id FROM watches WHERE tg_id=? AND origin=? AND dest=? AND scope=? AND stay=?",
                (tg_id, origin, dest, scope, stay),
            ).fetchone()
        return row["id"], created

    def watch_count(self, tg_id: int) -> int:
        with self._lock:
            return self._con.execute("SELECT COUNT(*) c FROM watches WHERE tg_id=?", (tg_id,)).fetchone()["c"]

    def watches_of(self, tg_id: int) -> list[sqlite3.Row]:
        with self._lock:
            return self._con.execute("SELECT * FROM watches WHERE tg_id=? ORDER BY id", (tg_id,)).fetchall()

    def get_watch(self, watch_id: int, tg_id: int | None = None) -> sqlite3.Row | None:
        with self._lock:
            if tg_id is None:
                return self._con.execute("SELECT * FROM watches WHERE id=?", (watch_id,)).fetchone()
            return self._con.execute("SELECT * FROM watches WHERE id=? AND tg_id=?", (watch_id, tg_id)).fetchone()

    def delete_watch(self, watch_id: int, tg_id: int) -> bool:
        with self._lock:
            cur = self._con.execute("DELETE FROM watches WHERE id=? AND tg_id=?", (watch_id, tg_id))
        return cur.rowcount == 1

    def set_watch_target(self, watch_id: int, tg_id: int, target: int | None) -> bool:
        with self._lock:
            cur = self._con.execute(
                "UPDATE watches SET target=?, notified=NULL WHERE id=? AND tg_id=?", (target, watch_id, tg_id)
            )
        return cur.rowcount == 1

    def due_watches(self, before: str, limit: int) -> list[sqlite3.Row]:
        """Watches last looked at before `before` (an ISO time), oldest first."""
        with self._lock:
            return self._con.execute(
                "SELECT * FROM watches WHERE checked_at IS NULL OR checked_at < ? "
                "ORDER BY checked_at IS NOT NULL, checked_at, id LIMIT ?",
                (before, limit),
            ).fetchall()

    def record_check(
        self, watch_id: int, *, price: int | None, day: str | None, base: int | None, notified: int | None,
        at: str | None = None,
    ) -> None:
        with self._lock:
            self._con.execute(
                "UPDATE watches SET checked_at=?, last_price=COALESCE(?, last_price), last_day=COALESCE(?, last_day), "
                "base=COALESCE(?, base), notified=COALESCE(?, notified) WHERE id=?",
                (at or _now(), price, day, base, notified, watch_id),
            )

    def drop_user_watches(self, tg_id: int) -> int:
        with self._lock:
            cur = self._con.execute("DELETE FROM watches WHERE tg_id=?", (tg_id,))
        return cur.rowcount

    def purge_watches(self, today: date) -> int:
        with self._lock:
            cur = self._con.execute("DELETE FROM watches WHERE expires < ?", (today.isoformat(),))
        return cur.rowcount

    # ---- popularity (which destinations people look at) --------------
    def bump_popular(self, iata: str) -> None:
        with self._lock:
            self._con.execute(
                "INSERT INTO popular(iata, n) VALUES(?,1) ON CONFLICT(iata) DO UPDATE SET n=n+1", (iata,)
            )

    def top_popular(self, limit: int = 5) -> list[tuple[str, int]]:
        with self._lock:
            rows = self._con.execute("SELECT iata, n FROM popular ORDER BY n DESC, iata LIMIT ?", (limit,)).fetchall()
        return [(r["iata"], r["n"]) for r in rows]

    # ---- backup ------------------------------------------------------
    def backup_to(self, path: str) -> None:
        """A consistent copy of the whole database (safe while the bot is running)."""
        with self._lock:
            target = sqlite3.connect(path)
            try:
                self._con.backup(target)
            finally:
                target.close()

    # ---- admins / kv / stats ----------------------------------------
    def add_admin(self, tg_id: int) -> None:
        with self._lock:
            self._con.execute("INSERT OR IGNORE INTO admins(tg_id) VALUES(?)", (tg_id,))

    def is_admin(self, tg_id: int) -> bool:
        with self._lock:
            return self._con.execute("SELECT 1 FROM admins WHERE tg_id=?", (tg_id,)).fetchone() is not None

    def admin_ids(self) -> list[int]:
        with self._lock:
            return [r["tg_id"] for r in self._con.execute("SELECT tg_id FROM admins ORDER BY tg_id")]

    def admin_count(self) -> int:
        with self._lock:
            return self._con.execute("SELECT COUNT(*) c FROM admins").fetchone()["c"]

    def kv_get(self, key: str, default: str | None = None) -> str | None:
        with self._lock:
            row = self._con.execute("SELECT v FROM kv WHERE k=?", (key,)).fetchone()
        return row["v"] if row else default

    def kv_set(self, key: str, value: str) -> None:
        with self._lock:
            self._con.execute("INSERT OR REPLACE INTO kv(k, v) VALUES(?,?)", (key, value))

    def kv_incr(self, key: str, by: int = 1) -> int:
        with self._lock:
            row = self._con.execute("SELECT v FROM kv WHERE k=?", (key,)).fetchone()
            try:
                value = int(row["v"]) if row else 0
            except ValueError:
                value = 0
            value += by
            self._con.execute("INSERT OR REPLACE INTO kv(k, v) VALUES(?,?)", (key, str(value)))
        return value

    def stats(self, today: date | None = None, now: datetime | None = None) -> dict[str, int]:
        day = (today or saudi_today()).isoformat()
        # the same text form the tables use (T and +00:00), so the comparison below is a true time comparison
        since = ((now or datetime.now(timezone.utc)) - timedelta(days=1)).isoformat(timespec="seconds")
        with self._lock:
            users = self._con.execute("SELECT COUNT(*) c FROM users").fetchone()["c"]
            active = self._con.execute("SELECT COUNT(*) c FROM users WHERE last_seen >= ?", (since,)).fetchone()["c"]
            searches = self._con.execute("SELECT COALESCE(SUM(n),0) s FROM usage WHERE day=?", (day,)).fetchone()["s"]
            saved = self._con.execute("SELECT COUNT(*) c FROM saved").fetchone()["c"]
            watches = self._con.execute("SELECT COUNT(*) c FROM watches").fetchone()["c"]
            watchers = self._con.execute("SELECT COUNT(DISTINCT tg_id) c FROM watches").fetchone()["c"]
            new_today = self._con.execute("SELECT COUNT(*) c FROM users WHERE created_at >= ?", (since,)).fetchone()["c"]
        return {
            "users": users, "active_24h": active, "searches_today": searches, "saved": saved,
            "watches": watches, "watchers": watchers, "new_24h": new_today,
        }
