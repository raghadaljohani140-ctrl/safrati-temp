"""Price alerts: people ask to be told when a trip gets cheaper, and a background loop keeps watching."""
from __future__ import annotations

import asyncio
import calendar
import logging
import re
from datetime import date, timedelta

from . import data, texts
from . import dates as dts
from . import insights as ins
from .db import iso_utc
from .telegram import TelegramError, button, keyboard
from .tp import Offer, TPError, month_keys
from .trip import watch_scope, wish_of_scope
from .ui import MAX_WATCHES, footer, sar

log = logging.getLogger("safrati.alerts")

ALERT_FIRST_DELAY = 45        # seconds after start before the first pass
ALERT_TICK = 600              # seconds between passes
ALERT_EVERY = 3 * 3600        # a watch is looked at about every three hours
ALERT_BATCH = 60              # watches handled in one pass (a pass every 10 minutes keeps about a thousand fresh)
ANY_LIFETIME_DAYS = 90        # open-ended alerts end after this long
TARGET_MIN, TARGET_MAX = 100, 100_000
PENDING_TTL = 300             # seconds the bot waits for a typed target price

_NUMBER = re.compile(r"^\d{3,6}$")


def watch_expiry(scope: str, today: date) -> str:
    """The last day a watch is worth keeping (an ISO date)."""
    kind, _, rest = scope.partition(":")
    if kind == "m" and len(rest) == 7:
        year, month = int(rest[:4]), int(rest[5:])
        return date(year, month, calendar.monthrange(year, month)[1]).isoformat()
    if kind == "e":
        return rest.split(":")[0]
    if kind == "o":
        return rest
    return (today + timedelta(days=ANY_LIFETIME_DAYS)).isoformat()


class AlertsMixin:
    """Mixed into SafratiBot."""

    # ------------------------------------------------------------------
    # looking up the price of a watch
    # ------------------------------------------------------------------
    async def watch_price(self, origin: str, iata: str, scope: str, stay: int = 0) -> Offer | None:
        """The cheapest ticket that matches what a watch stands for (None when there is no price)."""
        kind, _, rest = scope.partition(":")
        length = stay or None
        earliest = self._earliest()
        months = month_keys(self.clock() + 86400, 3)
        if scope == "any":
            offers = await self.tp.cheapest_dates(origin, iata, months, stay=length, top=60)
        elif scope == "w":
            offers = await self.tp.cheapest_dates(origin, iata, months, weekend=True, top=60)
        elif kind == "m":
            offers = await self.tp.cheapest_dates(origin, iata, [rest], stay=length, top=60)
        elif kind == "e" and rest.count(":") == 1:
            dep, ret = rest.split(":")
            return self._cheapest(await self.tp.exact(origin, iata, dep, ret), "")
        elif kind == "o":
            return self._cheapest(await self.tp.exact(origin, iata, rest, None, one_way=True), "")
        else:
            return None
        return self._cheapest(offers, earliest)

    @staticmethod
    def _cheapest(offers: list[Offer], earliest: str) -> Offer | None:
        usable = [o for o in offers if sar(o) > 0 and o.departure_at[:10] >= earliest]
        return min(usable, key=sar) if usable else None

    # ------------------------------------------------------------------
    # creating, listing, changing
    # ------------------------------------------------------------------
    async def create_watch(
        self, chat_id: int, uid: int, dest: data.Destination, wish: dts.DateWish, stay: int
    ) -> None:
        origin = self.db.touch_user(uid)["origin"]
        scope = watch_scope(wish)
        if not self.tp.enabled:
            await self.say(chat_id, texts.NOTE_NO_PRICE["off"], keyboard([footer()]))
            return
        known = any(
            w["dest"] == dest.iata and w["origin"] == origin and w["scope"] == scope and w["stay"] == stay
            for w in self.db.watches_of(uid)
        )
        if not known and self.db.watch_count(uid) >= MAX_WATCHES:
            await self.say(
                chat_id, texts.WATCH_LIMIT.format(n=MAX_WATCHES),
                keyboard([[button("🔔 تنبيهاتي", data="al")], footer()]),
            )
            return
        price = None
        try:
            offer = await self.watch_price(origin, dest.iata, scope, stay)
            price = round(sar(offer)) if offer else None
        except TPError as exc:
            log.info("no price when creating an alert: %s", exc)
        watch_id, created = self.db.add_watch(
            uid, origin, dest.iata, scope, stay, price, watch_expiry(scope, self._today()), at=iso_utc(self.clock())
        )
        rows = [
            [button("🎯 حدّد سعر معين", data=f"wt:{watch_id}")],
            [button("🔔 تنبيهاتي", data="al"), button("🏠 القائمة", data="menu")],
        ]
        await self.say(chat_id, texts.watch_created(dest, origin, scope, stay, price, created), keyboard(rows))

    async def show_alerts(self, chat_id: int, uid: int, *, edit_mid: int | None = None) -> None:
        by = data.by_iata()
        rows = [(by[w["dest"]], w) for w in self.db.watches_of(uid) if w["dest"] in by]
        if not rows:
            kb = keyboard([[button("✈️ ابحث عن رحلة", data="go")], footer()])
            await self.show(chat_id, texts.ALERTS_EMPTY, kb, edit_mid)
            return
        buttons = []
        for i, (_dest, w) in enumerate(rows, 1):
            buttons.append([
                button(f"✈️ {i}", data=f"wo:{w['id']}"),
                button(f"🎯 {i}", data=f"wt:{w['id']}"),
                button(f"🗑 {i}", data=f"wd:{w['id']}"),
            ])
        buttons.append(footer())
        await self.show(chat_id, texts.alerts_list(rows, MAX_WATCHES), keyboard(buttons), edit_mid)

    async def open_watch(self, chat_id: int, uid: int, watch_id: int) -> None:
        w = self.db.get_watch(watch_id, uid)
        dest = data.by_iata().get(w["dest"]) if w else None
        wish = wish_of_scope(w["scope"]) if w else None
        if not w or dest is None or wish is None:
            await self.say(chat_id, texts.BAD_BUTTON, self.menu_markup())
            return
        await self.show_trip(chat_id, uid, dest, w["origin"], wish, w["stay"] or None)

    async def ask_target(self, chat_id: int, uid: int, watch_id: int) -> None:
        w = self.db.get_watch(watch_id, uid)
        if not w:
            await self.say(chat_id, texts.BAD_BUTTON, self.menu_markup())
            return
        self._pending[uid] = (watch_id, self.clock() + PENDING_TTL)
        dest = data.by_iata().get(w["dest"])
        text = (texts.watch_detail(dest, w) + "\n\n" if dest else "") + texts.TARGET_PROMPT
        await self.say(chat_id, text, keyboard([[button("⬅️ تنبيهاتي", data="al")]]))

    def pending_target(self, uid: int) -> int | None:
        """The alert that is waiting for a typed price, if the wait has not run out."""
        pending = self._pending.get(uid)
        if not pending:
            return None
        if self.clock() > pending[1]:
            self._pending.pop(uid, None)
            return None
        return pending[0]

    async def take_target(self, chat_id: int, uid: int, text: str) -> bool:
        """Handle a message while an alert waits for its target price. False means: not for the alert."""
        watch_id = self.pending_target(uid)
        if watch_id is None:
            return False
        cleaned = data.norm_keep(text).replace(",", "").replace(" ", "")
        if not re.fullmatch(r"\d{1,7}", cleaned):
            self._pending.pop(uid, None)          # something else was typed: stop waiting, handle it normally
            return False
        target = int(cleaned)
        w = self.db.get_watch(watch_id, uid)
        dest = data.by_iata().get(w["dest"]) if w else None
        if not w or dest is None:
            self._pending.pop(uid, None)
            await self.say(chat_id, texts.BAD_BUTTON, self.menu_markup())
            return True
        if not TARGET_MIN <= target <= TARGET_MAX:
            await self.say(chat_id, texts.TARGET_BAD)
            return True
        now = w["last_price"]
        if now and target >= now:
            hint = max(TARGET_MIN, int(now * 0.9) // 10 * 10)
            await self.say(chat_id, texts.TARGET_TOO_HIGH.format(now=now, hint=hint))
            return True
        self.db.set_watch_target(watch_id, uid, target)
        self._pending.pop(uid, None)
        await self.say(chat_id, texts.target_set(dest, target), keyboard([[button("🔔 تنبيهاتي", data="al")], footer()]))
        return True

    # ------------------------------------------------------------------
    # the background pass
    # ------------------------------------------------------------------
    async def check_alerts(self) -> int:
        """Look at the watches that are due and tell people about drops. Returns how many messages were sent."""
        if not self.tp.enabled:
            return 0
        self.db.purge_watches(self._today())
        due = self.db.due_watches(iso_utc(self.clock() - ALERT_EVERY), ALERT_BATCH)
        groups: dict[tuple, list] = {}
        for w in due:
            groups.setdefault((w["origin"], w["dest"], w["scope"], w["stay"]), []).append(w)
        sent = 0
        for key, watches in groups.items():
            try:
                offer = await self.watch_price(*key)
            except TPError as exc:
                log.info("alert lookup failed (%s); will try again later", exc)
                continue
            for w in watches:
                sent += await self._judge(w, offer)
            await asyncio.sleep(0)
        return sent

    async def _judge(self, w, offer: Offer | None) -> int:
        at = iso_utc(self.clock())
        if offer is None:
            self.db.record_check(w["id"], price=None, day=None, base=None, notified=None, at=at)
            return 0
        price = round(sar(offer))
        first = w["base"] is None
        reference = ins.next_reference(price, w["base"])
        kind = "first" if first else ins.alert_decision(
            price, target=w["target"], base=reference, notified=w["notified"]
        )
        notified = None
        if kind:
            before = None if first else (w["base"] or w["last_price"])
            if await self._notify(w, offer, price, kind, before):
                notified = price
                reference = price
        self.db.record_check(w["id"], price=price, day=offer.departure_at[:10], base=reference, notified=notified, at=at)
        return 1 if notified else 0

    async def _notify(self, w, offer: Offer, price: int, kind: str, before: int | None) -> bool:
        dest = data.by_iata().get(w["dest"])
        if dest is None:
            return False
        if offer.link:
            plain = self.tp.site_url(offer.link)
        else:
            plain = self.tp.search_url(w["origin"], w["dest"], date.fromisoformat(offer.departure_at[:10]))
        found = await self._partner_urls([plain])
        rows = [
            [button(f"✈️ احجز — {price:,} ر.س", url=self._wrap(plain, found))],
            [button("🔕 إيقاف التنبيه", data=f"wd:{w['id']}"), button("🔔 تنبيهاتي", data="al")],
        ]
        text = texts.alert_message(dest, w, offer, price, kind, before)
        try:
            await self.say(w["tg_id"], text, keyboard(rows))
        except TelegramError as exc:
            if exc.status in (400, 403):
                dropped = self.db.drop_user_watches(w["tg_id"])
                log.info("user cannot be reached (%s); removed %s alert(s)", exc.status, dropped)
            else:
                log.warning("could not send an alert: %s", exc)
            return False
        self.db.kv_incr("alerts_sent")
        return True

    async def alerts_loop(self, stop: asyncio.Event) -> None:
        await self._sleep(stop, ALERT_FIRST_DELAY)
        while not stop.is_set():
            try:
                await self.check_alerts()
            except Exception:  # noqa: BLE001 - the loop must outlive any single bad pass
                log.exception("alert pass failed")
            await self._sleep(stop, ALERT_TICK)
