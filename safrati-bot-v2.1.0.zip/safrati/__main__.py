"""Entry point: python -m safrati"""
from __future__ import annotations

import asyncio
import logging
import signal
import sys
from concurrent.futures import ThreadPoolExecutor

from . import texts
from .app import COMMANDS, SafratiBot
from .config import ConfigError, Settings, load_settings
from .db import DB
from .logsafe import ScrubbingFormatter, secrets_of
from .telegram import TelegramAPI, TelegramError
from .tp import TravelpayoutsClient

log = logging.getLogger("safrati")


def setup_logging(settings: Settings) -> None:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(
        ScrubbingFormatter(secrets_of(settings), "%(asctime)s %(levelname)s %(name)s: %(message)s")
    )
    root = logging.getLogger()
    root.handlers[:] = [handler]
    root.setLevel(getattr(logging, settings.log_level, logging.INFO))
    logging.getLogger("asyncio").setLevel(logging.WARNING)


async def run(settings: Settings) -> int:
    api = TelegramAPI(settings.bot_token)
    try:
        me = await api.get_me()
    except TelegramError as exc:
        log.error("cannot start: %s", exc)
        return 1
    username = str(me.get("username") or "")

    db = DB(settings.db_path)
    tp = TravelpayoutsClient(
        settings.tp_token,
        settings.tp_marker,
        settings.tp_trs,
        settings.currency,
        market=settings.tp_market,
        show_all=settings.tp_show_all,
        cache_seconds=settings.cache_minutes * 60,
    )
    bot = SafratiBot(settings, api, db, tp, bot_username=username, bot_id=int(me.get("id") or 0))
    try:
        await api.delete_webhook()
        await api.set_commands(COMMANDS)
        await api.set_profile_texts(texts.PROFILE_DESCRIPTION, texts.PROFILE_SHORT)
    except TelegramError as exc:
        log.warning("setup call failed: %s", exc)

    log.info(
        "started as @%s | prices=%s partner_links=%s market=%s",
        username, "on" if tp.enabled else "off", "on" if tp.links_api else "off", tp.market or "auto",
    )
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    # long polling keeps one thread busy all the time; leave plenty for price and Telegram calls
    loop.set_default_executor(ThreadPoolExecutor(max_workers=16, thread_name_prefix="safrati"))
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, stop.set)
    await bot.serve(stop)
    db.close()
    log.info("stopped")
    return 0


def main() -> None:
    try:
        settings = load_settings()
    except ConfigError as exc:
        print(f"configuration error: {exc}", file=sys.stderr)
        sys.exit(78)
    setup_logging(settings)
    sys.exit(asyncio.run(run(settings)))


if __name__ == "__main__":
    main()
