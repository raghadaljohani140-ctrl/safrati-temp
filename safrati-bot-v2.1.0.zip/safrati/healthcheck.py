"""Docker health check: the bot touches a heartbeat file after every successful poll."""
import os
import sys
import time

PATH = os.environ.get("HEARTBEAT_PATH", "/data/heartbeat")
MAX_AGE = 120

try:
    age = time.time() - os.path.getmtime(PATH)
except OSError:
    sys.exit(1)
sys.exit(0 if age < MAX_AGE else 1)
