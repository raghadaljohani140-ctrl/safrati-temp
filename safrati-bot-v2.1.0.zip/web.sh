#!/usr/bin/env bash
# Safrati website: switch it on with a free temporary link, move it to your own domain, or switch it off.
#
#   bash web.sh quick     start the website with a free temporary public link (it changes if the server restarts)
#   bash web.sh link      show the website's address again
#   bash web.sh domain    serve the website on your own domain (asks for the domain and the Cloudflare tunnel token)
#   bash web.sh status    is it running?
#   bash web.sh stop      switch the website off (the bot keeps running)
#
# Safety: runs only inside /opt/safrati-bot and only touches the Docker project "safrati"
# (containers safrati-web, safrati-tunnel, safrati-domain). No port of the server is opened: visitors reach the
# website only through the tunnel, which connects out from inside the project. The website never receives the
# Telegram token. The tunnel token is typed with hidden input and kept only in .tunnel.env (root-only).
set -euo pipefail

APP_DIR="/opt/safrati-bot"
PROJECT="safrati"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$APP_DIR/.env"
TUNNEL_FILE="$APP_DIR/.tunnel.env"

die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
say() { printf '%s\n' "$*"; }

[ "$HERE" = "$APP_DIR" ] || die "this script must live in $APP_DIR (it is in $HERE). Nothing was changed."
cd "$APP_DIR"
umask 077

command -v docker >/dev/null 2>&1 || die "docker is not installed on this server."
docker compose version >/dev/null 2>&1 || die "the 'docker compose' plugin is missing."
command -v curl >/dev/null 2>&1 || die "curl is not installed on this server."

# ---------------------------------------------------------------- helpers
env_get() { [ -f "$ENV_FILE" ] && grep -m1 "^$1=" "$ENV_FILE" | cut -d= -f2- || true; }

env_set() { # NAME VALUE  (values are validated before they get here, so they never contain newlines)
  local tmp
  tmp="$(mktemp "$APP_DIR/.env.XXXXXX")"
  if [ -f "$ENV_FILE" ]; then grep -v "^$1=" "$ENV_FILE" > "$tmp" || true; fi
  printf '%s=%s\n' "$1" "$2" >> "$tmp"
  chmod 600 "$tmp"
  mv "$tmp" "$ENV_FILE"
}

mode() { # off | quick | domain
  case "$(env_get SAFRATI_WEB)" in
    quick)  echo quick ;;
    domain) echo domain ;;
    *)      echo off ;;
  esac
}

compose() { # the bot, plus the website and its tunnel when they are switched on
  case "$(mode)" in
    quick)  docker compose -p "$PROJECT" --profile web --profile quick "$@" ;;
    domain) docker compose -p "$PROJECT" --profile web --profile domain "$@" ;;
    *)      docker compose -p "$PROJECT" "$@" ;;
  esac
}

compose_all() { # every part of the website, switched on or not (to stop or replace them)
  docker compose -p "$PROJECT" --profile web --profile quick --profile domain "$@"
}

need_install() {
  [ -f "$ENV_FILE" ] && [ -n "$(env_get BOT_TOKEN)" ] || die "the bot is not installed yet. Run first:  bash install.sh"
}

prepare_files() { # compose reads this file for the domain tunnel; it must exist (empty is fine)
  [ -f "$TUNNEL_FILE" ] || : > "$TUNNEL_FILE"
  chmod 600 "$TUNNEL_FILE"
}

check_memory() { # the website and its tunnel need about 150 MB: never squeeze the other projects on this server
  local kb mb
  [ "$(mode)" = off ] || return 0                    # already running: its memory is already counted
  kb="$(awk '/^MemAvailable:/ {print $2}' "${SAFRATI_MEMINFO:-/proc/meminfo}" 2>/dev/null || true)"
  [[ "$kb" =~ ^[0-9]+$ ]] || return 0                # cannot tell: carry on
  mb=$((kb / 1024))
  if [ "$mb" -lt 200 ]; then
    die "only $mb MB of memory is free on this server. The website needs about 150 MB and starting it could slow down the other projects here. Nothing was changed."
  fi
  say "Free memory: $mb MB (the website needs about 150 MB)."
}

valid() { # NAME VALUE -> exit 0 when the value has the right shape
  case "$1" in
    DOMAIN)        [[ "$2" =~ ^([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,24}$ ]] && [ "${#2}" -le 100 ] ;;
    TUNNEL_TOKEN)  [[ "$2" =~ ^[A-Za-z0-9=_+/-]{60,1500}$ ]] ;;
    *)             return 1 ;;
  esac
}

ASKED=""
ask() { # NAME PROMPT SECRET(1|0)  -> sets ASKED
  local name="$1" prompt="$2" secret="$3" value="" attempts=0
  while true; do
    if [ "$secret" = 1 ]; then
      read -r -s -p "$prompt (typing is hidden, paste then Enter): " value || die "input was closed."
      echo
    else
      read -r -p "$prompt: " value || die "input was closed."
    fi
    value="${value//[[:space:]]/}"
    if [ "$name" = DOMAIN ]; then
      value="${value,,}"
      value="${value#https://}"
      value="${value%/}"
    fi
    if valid "$name" "$value"; then
      ASKED="$value"
      say "  OK, received ${#value} characters"
      return 0
    fi
    attempts=$((attempts + 1))
    [ "$attempts" -lt 5 ] || die "that did not look right 5 times. Nothing was changed."
    say "  that does not look right (received ${#value} characters). Try again."
  done
}

wait_for_web() { # the website reports its start in its log
  local i logs line
  for i in $(seq 1 30); do
    logs="$(docker logs safrati-web 2>&1 || true)"
    line="$(printf '%s\n' "$logs" | grep "website started on port" | tail -n 1 || true)"
    if [ -n "$line" ]; then
      say "The website is running:"
      say "$line"
      return 0
    fi
    sleep 2
  done
  say "The website did not report that it started within 60 seconds. Last log lines:"
  docker logs --tail 20 safrati-web 2>&1 || true
  return 1
}

quick_url() { # the newest temporary address in the tunnel's log (the address of Cloudflare's own API does not count)
  local logs
  logs="$(docker logs safrati-tunnel 2>&1 || true)"
  printf '%s\n' "$logs" | grep -o 'https://[a-z0-9-]*\.trycloudflare\.com' | grep -v '^https://api\.' | tail -n 1 || true
}

wait_for_url() { # prints the address
  local i url
  for i in $(seq 1 30); do
    url="$(quick_url)"
    if [ -n "$url" ]; then printf '%s\n' "$url"; return 0; fi
    sleep 2
  done
  return 1
}

public_ok() { # ADDRESS -> exit 0 when the website answers from the internet
  local out
  out="$(printf 'url = "%s/healthz"\nsilent\nmax-time = 15\n' "$1" | curl -K - 2>/dev/null || true)"
  [ "$out" = "ok" ]
}

wait_public() { # ADDRESS -> a new address can take a short while to become reachable
  local i
  for i in $(seq 1 20); do
    if public_ok "$1"; then return 0; fi
    sleep 3
  done
  return 1
}

# ---------------------------------------------------------------- commands
cmd_quick() {
  need_install
  check_memory
  prepare_files
  [ -n "$(env_get TP_TOKEN)" ] || say "note: TP_TOKEN is empty, so the website has no prices yet. Add it with:  bash install.sh set TP_TOKEN"
  compose_all rm -sf tunnel-domain >/dev/null 2>&1 || true
  env_set SAFRATI_WEB quick
  env_set WEB_SITE_URL ""
  say "Building and starting the website (the first time takes 1 to 3 minutes)..."
  compose up -d --build web tunnel
  wait_for_web || exit 1
  say "Waiting for the public link..."
  local url
  url="$(wait_for_url)" || {
    say "The tunnel did not show a link within 60 seconds. Last log lines:"
    docker logs --tail 20 safrati-tunnel 2>&1 || true
    exit 1
  }
  say ""
  say "Website link (open it on your phone):"
  say "  $url"
  if wait_public "$url"; then
    say "It answers from the internet."
  else
    say "It does not answer yet. Wait a minute and open it again. If it still fails:  bash web.sh status"
  fi
  say ""
  say "This link is temporary and changes if the server restarts. Show it again with:  bash web.sh link"
}

cmd_domain() {
  need_install
  check_memory
  prepare_files
  say "Before this step, in your Cloudflare account (the free plan is enough):"
  say "  1) add your domain to Cloudflare"
  say "  2) Zero Trust > Networks > Tunnels > Create a tunnel > Cloudflared. Copy the long token after --token."
  say "  3) in the tunnel, add a public hostname for your domain: type HTTP, URL  web:8088"
  say ""
  ask DOMAIN "Your domain (example: flights.example.com)" 0
  local domain="$ASKED" token tmp
  ask TUNNEL_TOKEN "Tunnel token" 1
  token="$ASKED"
  tmp="$(mktemp "$APP_DIR/.tunnel.env.XXXXXX")"
  printf 'TUNNEL_TOKEN=%s\n' "$token" > "$tmp"
  chmod 600 "$tmp"
  mv "$tmp" "$TUNNEL_FILE"
  compose_all rm -sf tunnel >/dev/null 2>&1 || true
  env_set WEB_SITE_URL "https://$domain"
  env_set SAFRATI_WEB domain
  say "Building and starting the website..."
  compose up -d --build web tunnel-domain
  wait_for_web || exit 1
  local i logs connected=0
  for i in $(seq 1 30); do
    logs="$(docker logs safrati-domain 2>&1 || true)"
    if printf '%s\n' "$logs" | grep -q "Registered tunnel connection"; then connected=1; break; fi
    sleep 2
  done
  if [ "$connected" != 1 ]; then
    say "The tunnel did not connect within 60 seconds. Last log lines:"
    docker logs --tail 15 safrati-domain 2>&1 || true
    say "Check the token (bash web.sh domain again) and that the public hostname points to  web:8088"
    exit 1
  fi
  say "The tunnel is connected."
  say ""
  say "Website address:  https://$domain"
  if wait_public "https://$domain"; then
    say "It answers from the internet."
  else
    say "It does not answer yet (a new name can take a few minutes). Try again later:  bash web.sh status"
  fi
}

cmd_link() {
  case "$(mode)" in
    quick)
      local url
      url="$(quick_url)"
      [ -n "$url" ] || die "no link in the tunnel log yet. Try again in a minute, or run:  bash web.sh status"
      say "$url" ;;
    domain) say "$(env_get WEB_SITE_URL)" ;;
    *)      say "The website is off. Start it with:  bash web.sh quick" ;;
  esac
}

cmd_status() {
  say "Website: $(mode)"
  [ "$(mode)" != off ] || { say "It is off. Start it with:  bash web.sh quick"; return 0; }
  compose ps
  say "--- website log ---"
  docker logs --tail 8 safrati-web 2>&1 || true
  say "--- address ---"
  cmd_link
}

cmd_stop() {
  need_install
  compose_all rm -sf web tunnel tunnel-domain
  env_set SAFRATI_WEB off
  say "The website is off. The bot keeps running."
}

case "${1:-}" in
  quick)  cmd_quick ;;
  link)   cmd_link ;;
  domain) cmd_domain ;;
  status) cmd_status ;;
  stop)   cmd_stop ;;
  *)      die "usage: bash web.sh quick | link | domain | status | stop" ;;
esac
