# سفرتي — Safrati travel bot (v2.1.0)

An independent Telegram bot (`@SafratiTravel_bot`) for Saudi travellers. It answers «وين أسافر وكم يكلف؟» with real recent flight
prices and booking links: a price **calendar** with cheap/normal/dear days, the **cheapest month**, **weekend** trips,
**price alerts** that message you when a trip gets cheaper, shareable trip links, and an optional daily deals post for a channel.
Arabic interface. Since v2.1.0 the same price engine also runs as a **website** that anyone can open (see "Website" below).

Pure Python standard library, plain Docker containers, no open ports, no third-party packages.

## Isolation (what this bot does and does not touch)

| Thing | Name |
|---|---|
| Folder | `/opt/safrati-bot` (the scripts refuse to run anywhere else) |
| Docker project | `safrati` |
| Container / image | `safrati-bot` / `safrati-bot:local` |
| Data volume | `safrati_safrati_data` (SQLite file `safrati.db`, plus `backups/`) |
| Network ports | none (it polls Telegram, nothing connects in) |
| Limits | 256 MB RAM, half a CPU, read-only filesystem, no capabilities |
| Website (only after `bash web.sh quick` / `domain`) | containers `safrati-web` and `safrati-tunnel` (or `safrati-domain`), same project, same network, still **no published port** |

Every `docker compose` command in these files carries `-p safrati`. Nothing here reads, writes
or restarts any other project, reverse proxy, firewall rule or volume on the machine.

## Install and update

```bash
mkdir -p /opt/safrati-bot && cd /opt/safrati-bot
# put the files of this package here, then:
bash install.sh
```

`install.sh` first shows the server's name and asks you to confirm it is the right one (type `y`), then asks for
the secrets with hidden input and writes them only to `.env` (chmod 600).
It checks the Telegram token with Telegram and the price token with Travelpayouts before starting.

**Updating** is the same command in the same folder with the new files on top: `.env` and the data volume are kept
(an older database is upgraded automatically, and people who already used the bot skip the first-run question).

Change one value later: `bash install.sh set TP_TRS` (also `BOT_TOKEN`, `TP_TOKEN`, `TP_MARKER`, `CHANNEL_URL`).
Status: `bash status.sh`. Remove: `bash uninstall.sh` (add `--purge` to delete the data volume too; it removes the website
parts as well and leaves the public `cloudflared` image alone).

## Settings (`.env`)

| Name | Meaning |
|---|---|
| `BOT_TOKEN` | Telegram bot token (required) |
| `TP_TOKEN` | Travelpayouts API token; without it the bot still suggests places but shows no prices |
| `TP_MARKER`, `TP_TRS` | Travelpayouts partner ID and project ID; both are needed for partner (commission) links |
| `CHANNEL_URL` | Optional channel link. A public link (`https://t.me/name`) also allows the automatic deals post |
| `CURRENCY` | Price currency, default `sar` (falls back to `usd` automatically if refused) |
| `DAILY_SEARCH_LIMIT` | Searches per person per day, default 40 |
| `CACHE_MINUTES` | How long price answers are reused, default 30 |
| `TP_MARKET` | Price market (two letters, for example `us`). Empty = the provider decides by the departure city. Easier: let the admin compare markets with `/market` and switch with one tap (the choice is kept in the database and wins over this setting) |
| `TP_SHOW_ALL` | Tuning knob for the price source |
| `ADMIN_CODE` | One-time code for `/admin <code>`; burned after first use |
| `SAFRATI_WEB`, `WEB_SITE_URL` | Set by `web.sh` (website off / quick / domain, and its address). Don't edit by hand |
| `BOT_USERNAME` | The bot's username for the website's «افتح في تلغرام» buttons (`install.sh` fills it in) |
| `WEB_RATE_PER_MINUTE` | Price lookups one visitor may start per minute, default 60 |
| `WEB_UPSTREAM_PER_MINUTE` | Price-provider calls the whole website may make per minute, default 240 (the bot uses the same Travelpayouts allowance) |
| `WEB_REAL_IP_HEADER` | Header that carries the visitor's address behind the tunnel, default `CF-Connecting-IP` |

## Website

The same price engine as the bot, as a page anyone can open in a browser: type «دبي» or «إسطنبول ديسمبر», or open a
destination from the cheapest-now lists (with region, visa and budget filters); every destination has a **price calendar**
with the cheapest day marked, a bar per month, trip lengths, the weekend edition, the visa note, and booking buttons that
carry the partner link. Arabic, right-to-left, built for phones, light and dark, installable on the home screen.

Switch it on (it opens nothing on the server; a Cloudflare tunnel connects out from inside the project):

```bash
bash web.sh quick     # a free temporary link (https://….trycloudflare.com): to try it on your phone
bash web.sh link      # show the link again
bash web.sh domain    # your own domain: asks for the domain and the Cloudflare tunnel token (hidden input)
bash web.sh status
bash web.sh stop      # website off; the bot is not touched
```

The temporary link changes whenever the server restarts and Cloudflare gives no uptime promise: it is for testing.
For a permanent address buy a domain, add it to Cloudflare (free plan), create a tunnel in Zero Trust with a public
hostname that points to `http://web:8088`, then run `bash web.sh domain`. `install.sh` updates keep the website running.
`web.sh` refuses to start the website when the server has less than 200 MB of free memory, so the other projects on it are not squeezed.

How it is kept safe and cheap:

* **Isolated**: its own container from the same image (`python -m safrati.web`), read-only filesystem, no capabilities,
  192 MB. It is given the price settings only: never the Telegram token or the admin code. The tunnel token lives in
  `.tunnel.env` and only the domain tunnel container reads it.
* **Strict page**: no inline script or style (the Content-Security-Policy allows only the site's own files and Google
  Fonts), no cookies, `GET`/`HEAD` only, no query strings or visitor addresses in the log. The partner redirect `/go`
  only ever leaves for the allowed partner hosts.
* **Shared allowance**: the bot and the website use one Travelpayouts account. The website has its own per-minute budget
  (`WEB_UPSTREAM_PER_MINUTE`), identical questions are answered once for everybody (cache plus in-flight sharing), each
  visitor is rate-limited, and when the budget is spent the page says it is busy instead of taking the bot's share.
* **Honest prices**: same rules as the bot — cached recent searches labelled with their age, never live fares, nothing
  invented; a destination without prices says so and offers the bot or another month.
* With `WEB_SITE_URL` empty (the temporary link) the page asks search engines not to index it; with a real domain it
  publishes `robots.txt`, a sitemap and a preview image for chat apps.

Files: `safrati/web/` (`server.py` HTTP server, `api.py` JSON answers on top of the bot's engine, `budget.py`, `static/` the
page). Routes: `/api/meta /api/understand /api/dest /api/calendar /api/day /api/cheap /api/weekend`, `/go`, `/healthz`.

## What people get

* **First run**: one question, «من أي مدينة تسافر؟», then the menu. A shared trip link survives that question.
* **A destination** (`دبي`, `اسطنبول`, a misspelling gets «تقصد…؟»): the cheapest days in the next three months with
  flight time and stops, a **price verdict** (🟢 ممتاز / جيد، 🟡 عادي) compared with the typical price of the same route,
  a bar per month with the cheapest month starred, and one-tap trip lengths (3, 5, 7, 10, 14 days or weekend).
* **Dates**: `دبي 15/12 - 22/12`, `لندن ديسمبر`, `دبي الشهر الجاي`, `دبي 5 ايام`, `دبي اسبوع`, `دبي ويكند`, `بكرة`,
  `ذهاب فقط`, or the month → day → length buttons. For exact dates the bot also points out a cheaper departure in the
  same month when the saving is worth it (at least 60 riyals and 6%).
* **📆 Price calendar** (up to 12 months ahead): every day with a price is marked 🟢 cheap, 🟡 normal or 🔴 dear relative to
  that month; tapping a day opens that exact trip with its booking link. **📊 Cheapest month** compares six months.
* **🔔 Price alerts** (up to 8 per person): for a destination, a month, a weekend, a trip length or exact dates. The bot
  checks about every 3 hours and writes when the price falls 8% or more below the reference price, when it reaches a
  target the person typed, or when a first price appears for a route that had none. Alerts end with their dates (open
  alerts after 90 days) and disappear if the person blocks the bot.
* **🌙 Weekend**: the cheapest Thursday/Friday → Saturday/Sunday trips from the person's city. The provider's
  "everything from this city" answer is often full of short flights inside the country, so the popular weekend places
  (Gulf, Egypt, Jordan, Lebanon, Turkey, Caucasus) are also asked about one by one. If the provider is slow the list
  shows what has arrived and the rest completes in the background for the next person.
* **🔥 Cheapest now**, with region chips (Arab world, Caucasus, Asia, Europe, Africa) and months; also by text
  (`ارخص رحلات اوروبا`, `ارخص رحلات القوقاز ديسمبر`).
* **💰 By budget** (`4000`, `بحر 6000`, `5000 للتذكرة`): destinations whose ticket fits; a whole-trip budget keeps 40% for the ticket.
* **📤 Sharing**: every trip has a share button; the link opens that destination and dates for whoever taps it
  (`/start d_IST_20261215_20261222`, also `w` for weekend and `c` for cheapest).
* **Visa** status per country for Saudi citizens with the date it was checked (`safrati/data/visa_sa.json`; where sources
  disagreed the bot says to check with the embassy), and optional service links (eSIM, tours, transfers).

Commands: `/start /search /cheap /weekend /alerts /surprise /saved /settings /about /privacy`.

## How it works

* Text is understood by rules (Arabic normalisation, destination aliases, budget numbers, stay lengths, months,
  regions, taste words, "من جدة"-style origins, close misspellings). No AI service is called, so there is no per-message cost.
* Prices come from Travelpayouts' Aviasales Data API (`prices_for_dates`): cached recent searches, up to 48 hours old,
  never live fares. Every price is labelled «وقت البحث». One request returns a whole month of a route, which the bot turns
  into the calendar, the month bars and the verdict. The verdict compares with the other days found for the same route; it is
  not a forecast. Round trips shorter than 3 days are ignored unless the person asked for a weekend.
* If the provider is down the bot says so and falls back to suggestions by cost level; it never invents a price.
* Booking and service buttons use Travelpayouts partner links (`/links/v1/create`), falling back to the plain marker.
* Stored per person: Telegram numeric id, origin city, a visa filter flag, saved destinations, destinations already shown,
  a daily search counter, and the alerts they created (route, dates, target price). Message text is never stored,
  and no names, usernames or phone numbers are collected.

## Admin

Send `/admin <code>` once from your own Telegram account (the code is printed by `install.sh`).

| Command | What it does |
|---|---|
| `/stats` | Users, active/new in 24 h, searches today, saved places, alerts, most searched destinations |
| `/diag` | Live check: price connection, partner links (and why one is refused), how many days of a month have prices, the weekend lookup (count and seconds), the price market, and the channel set-up. ✅ works, ❌ broken, ⚪ not set up (optional) |
| `/market` | Compares price markets on four Saudi routes and shows which knows the most days; a button switches to it. `/market us` sets one, `/market auto` goes back |
| `/deals` | Preview the channel post; the button under it publishes it |
| `/welcome` | Preview the channel's welcome picture (with a button that opens the bot); the button under it publishes it |
| `/autopost on` / `off` | Daily deals post to the channel (off by default) |
| `/backup` | A database copy right now |

**Channel post** (optional): set `CHANNEL_URL` to the public link, add the bot to the channel as an administrator with the
«Post messages» right, check `/diag`, preview with `/deals`, then `/autopost on`. It posts once a day after 10:00 Saudi
time (Thursday: the weekend edition), skips days when fewer than three prices are found or nothing changed, and
switches itself off and tells the admins after three failed posts in a row.

**Backups**: once a day after 04:00 Saudi time the bot writes `backups/safrati-YYYYMMDD-HHMM.db` next to the database and
keeps the newest three. They are plain SQLite files inside the data volume.

## Tests

```bash
python3 -m unittest discover -s tests -t .
```

All tests run offline against fake Telegram and Travelpayouts servers, and walk every button the bot can show. The website has
its own tests (HTTP parsing and limits, every JSON answer, the page's security rules and colour contrast, the container
set-up, and the scripts against a fake Docker).
