#!/usr/bin/env bash
# Shows only the Safrati bot (and its website, when it is switched on): container state and the last log lines.
# Logs never contain secrets.
set -euo pipefail
[ "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" = "/opt/safrati-bot" ] || { echo "ERROR: run from /opt/safrati-bot" >&2; exit 1; }
cd /opt/safrati-bot
web="$( (grep -m1 '^SAFRATI_WEB=' .env 2>/dev/null || true) | cut -d= -f2-)"
case "$web" in
  quick|domain) docker compose -p safrati --profile web --profile "$web" ps ;;
  *)            web=""; docker compose -p safrati ps ;;
esac
echo "--- last log lines ---"
docker logs --tail 25 safrati-bot 2>&1
if [ -n "$web" ]; then
  echo "--- website ---"
  docker logs --tail 8 safrati-web 2>&1 || true
  echo "address:"
  bash web.sh link || true
fi
