#!/usr/bin/env bash
# Stops and removes ONLY the Safrati containers (the bot, and the website with its tunnel if you switched them on) and the project's network.
#   bash uninstall.sh            keep the bot's data (users, saved places)
#   bash uninstall.sh --purge    also delete the data volume and the image built for the bot
# The folder /opt/safrati-bot and its .env stay; delete the folder yourself if you want it gone.
# The public cloudflared image that the tunnel downloaded is left alone (other projects may use it):
#   docker rmi cloudflare/cloudflared:2026.9.3
set -euo pipefail
[ "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" = "/opt/safrati-bot" ] || { echo "ERROR: run from /opt/safrati-bot" >&2; exit 1; }
cd /opt/safrati-bot
case "${1:-}" in
  "")
    docker compose -p safrati --profile web --profile quick --profile domain down ;;
  --purge)
    docker compose -p safrati --profile web --profile quick --profile domain down --volumes
    docker rmi safrati-bot:local >/dev/null 2>&1 || true ;;
  *)
    echo "usage: bash uninstall.sh [--purge]" >&2; exit 1 ;;
esac
echo "Safrati bot and website removed. Other projects were not touched."
