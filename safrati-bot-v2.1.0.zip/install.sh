#!/usr/bin/env bash
# Safrati bot installer / updater.
#
#   bash install.sh              first install, or update to the files in this folder (keeps .env and data)
#   bash install.sh set NAME     change one setting later (TP_TOKEN, TP_MARKER, TP_TRS, CHANNEL_URL, BOT_TOKEN)
#
# Safety: runs only inside /opt/safrati-bot and only touches the Docker project "safrati"
# (container safrati-bot, volume safrati_safrati_data, image safrati-bot:local; and, once you switched the
# website on with web.sh, the containers safrati-web, safrati-tunnel / safrati-domain).
# Secrets are typed with hidden input and saved only in .env (root-only, chmod 600).
set -euo pipefail

APP_DIR="/opt/safrati-bot"
PROJECT="safrati"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$APP_DIR/.env"

die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
say() { printf '%s\n' "$*"; }

[ "$HERE" = "$APP_DIR" ] || die "this script must live in $APP_DIR (it is in $HERE). Nothing was changed."
cd "$APP_DIR"
umask 077

command -v docker >/dev/null 2>&1 || die "docker is not installed on this server."
docker compose version >/dev/null 2>&1 || die "the 'docker compose' plugin is missing."
command -v curl >/dev/null 2>&1 || die "curl is not installed on this server."

# ---------------------------------------------------------------- helpers
valid() { # NAME VALUE -> exit 0 when the value has the right shape
  case "$1" in
    BOT_TOKEN)         [[ "$2" =~ ^[0-9]{6,}:[A-Za-z0-9_-]{30,}$ ]] ;;
    TP_TOKEN)          [[ "$2" =~ ^[A-Za-z0-9_-]{16,128}$ ]] ;;
    TP_MARKER|TP_TRS)  [[ "$2" =~ ^[0-9]{3,12}$ ]] ;;
    CHANNEL_URL)       [[ "$2" =~ ^https://t\.me/[A-Za-z0-9_+]{3,64}$ ]] ;;
    *)                 return 1 ;;
  esac
}

ASKED=""
ask() { # NAME PROMPT SECRET(1|0) REQUIRED(1|0) [DEFAULT]  -> sets ASKED
  local name="$1" prompt="$2" secret="$3" required="$4" default="${5:-}" value=""
  while true; do
    if [ "$secret" = 1 ]; then
      read -r -s -p "$prompt (typing is hidden, paste then Enter): " value || die "input was closed."
      echo
    else
      read -r -p "$prompt: " value || die "input was closed."
    fi
    value="${value//[[:space:]]/}"
    if [ -z "$value" ]; then
      if [ -n "$default" ]; then value="$default"
      elif [ "$required" = 0 ]; then ASKED=""; say "  skipped"; return 0
      else say "  a value is required."; continue
      fi
    fi
    if valid "$name" "$value"; then
      ASKED="$value"
      say "  OK, received ${#value} characters"
      return 0
    fi
    say "  that does not look right (received ${#value} characters). Try again."
  done
}

BOT_NAME=""
check_bot_token() { # prints nothing secret; sets BOT_NAME
  local out
  out="$(printf 'url = "https://api.telegram.org/bot%s/getMe"\n' "$1" | curl -sS -m 20 -K - 2>/dev/null || true)"
  case "$out" in
    *'"ok":true'*)
      BOT_NAME="$(printf '%s' "$out" | sed -n 's/.*"username":"\([^"]*\)".*/\1/p')"
      return 0 ;;
    *) return 1 ;;
  esac
}

check_tp_token() { # warns only; a temporary failure must not block the install
  local code
  code="$(printf 'url = "https://api.travelpayouts.com/aviasales/v3/prices_for_dates?origin=RUH&destination=IST&currency=sar&one_way=false&limit=1"\nheader = "X-Access-Token: %s"\nsilent\noutput = "/dev/null"\nwrite-out = "%%{http_code}"\nmax-time = 20\n' "$1" | curl -K - 2>/dev/null || true)"
  case "$code" in
    200) say "  Travelpayouts accepted the token." ;;
    401|403) say "  note: this quick check got HTTP $code from Travelpayouts. It can be a false alarm; send /diag to the bot after it starts to see if prices work. If not, run: bash install.sh set TP_TOKEN" ;;
    *) say "  note: could not confirm the Travelpayouts token now (HTTP ${code:-none}). The bot's /diag command will test it." ;;
  esac
}

env_get() { [ -f "$ENV_FILE" ] && grep -m1 "^$1=" "$ENV_FILE" | cut -d= -f2- || true; }

env_set() { # NAME VALUE  (values are validated before they get here, so they never contain newlines)
  local tmp
  tmp="$(mktemp "$APP_DIR/.env.XXXXXX")"
  if [ -f "$ENV_FILE" ]; then grep -v "^$1=" "$ENV_FILE" > "$tmp" || true; fi
  printf '%s=%s\n' "$1" "$2" >> "$tmp"
  chmod 600 "$tmp"
  mv "$tmp" "$ENV_FILE"
}

gen_code() { od -An -N8 -tx1 /dev/urandom | tr -d ' \n'; }

web_mode() { # off | quick | domain  (switched with web.sh)
  case "$(env_get SAFRATI_WEB)" in
    quick)  echo quick ;;
    domain) echo domain ;;
    *)      echo off ;;
  esac
}

compose() { # the bot, plus the website and its tunnel when they are switched on
  case "$(web_mode)" in
    quick)  docker compose -p "$PROJECT" --profile web --profile quick "$@" ;;
    domain) docker compose -p "$PROJECT" --profile web --profile domain "$@" ;;
    *)      docker compose -p "$PROJECT" "$@" ;;
  esac
}

prepare_files() { # compose reads this file for the domain tunnel; it must exist (empty is fine)
  [ -f "$APP_DIR/.tunnel.env" ] || : > "$APP_DIR/.tunnel.env"
  chmod 600 "$APP_DIR/.tunnel.env"
}

start_bot() {
  say "Building and starting the bot (the first build takes 1 to 3 minutes)..."
  prepare_files
  compose up -d --build
  local i logs line
  for i in $(seq 1 30); do
    logs="$(docker logs safrati-bot 2>&1 || true)"
    line="$(printf '%s\n' "$logs" | grep "started as @" | tail -n 1 || true)"
    if [ -n "$line" ]; then
      say "The bot is running:"
      say "$line"
      return 0
    fi
    sleep 2
  done
  say "The bot did not report that it started within 60 seconds. Last log lines:"
  docker logs --tail 20 safrati-bot 2>&1 || true
  return 1
}

# ---------------------------------------------------------------- set one value
if [ "${1:-}" = "set" ]; then
  name="${2:-}"
  case "$name" in
    BOT_TOKEN|TP_TOKEN)  secret=1 ;;
    TP_MARKER|TP_TRS|CHANNEL_URL) secret=0 ;;
    *) die "usage: bash install.sh set BOT_TOKEN|TP_TOKEN|TP_MARKER|TP_TRS|CHANNEL_URL" ;;
  esac
  [ -f "$ENV_FILE" ] || die "no .env yet. Run: bash install.sh"
  ask "$name" "New value for $name" "$secret" 1
  if [ "$name" = "BOT_TOKEN" ] && ! check_bot_token "$ASKED"; then die "Telegram rejected this token. Nothing was changed."; fi
  [ "$name" = "TP_TOKEN" ] && check_tp_token "$ASKED"
  env_set "$name" "$ASKED"
  say "$name updated. Restarting the bot..."
  prepare_files
  services=""
  [ "$(web_mode)" = off ] || services="bot web"
  # shellcheck disable=SC2086  # empty means "everything that is switched on"
  compose up -d --force-recreate $services
  sleep 5
  docker logs --tail 5 safrati-bot 2>&1 || true
  exit 0
fi

[ -z "${1:-}" ] || die "unknown option. Use: bash install.sh   or   bash install.sh set NAME"

# ---------------------------------------------------------------- first-time setup
NEW_ADMIN_CODE=""
if [ -f "$ENV_FILE" ] && [ -n "$(env_get BOT_TOKEN)" ]; then
  say "Keeping your existing settings in .env (use 'bash install.sh set NAME' to change one)."
else
  say "This server is: $(hostname 2>/dev/null || echo unknown)"
  say "The bot will be installed here, in $APP_DIR, on its own and separate from every other project."
  read -r -p "Is this the right server? Type y then Enter to continue (anything else cancels): " reply || die "input was closed."
  case "$reply" in
    y|Y|yes|YES|Yes) ;;
    *) die "cancelled. No container was started and no setting was saved." ;;
  esac
  say ""
  say "First-time setup. Nothing you type here is shown on screen or sent anywhere except the service it belongs to."
  say ""
  say "1/5  Telegram bot token (from BotFather)"
  attempts=0
  while true; do
    ask BOT_TOKEN "Bot token" 1 1
    if check_bot_token "$ASKED"; then say "  Telegram says this is @${BOT_NAME}."; break; fi
    attempts=$((attempts + 1))
    [ "$attempts" -lt 5 ] || die "Telegram did not accept the token 5 times (or this server cannot reach Telegram). Nothing was changed."
    say "  Telegram did not accept this token. Copy it again from BotFather."
  done
  bot_token="$ASKED"
  say ""
  say "2/5  Travelpayouts API token (Enter to skip; prices will be off until you add it)"
  ask TP_TOKEN "API token" 1 0
  tp_token="$ASKED"
  [ -z "$tp_token" ] || check_tp_token "$tp_token"
  say ""
  say "3/5  Travelpayouts partner ID (digits; Enter to skip)"
  ask TP_MARKER "Partner ID" 0 0
  tp_marker="$ASKED"
  say ""
  say "4/5  Travelpayouts project ID (digits; Enter to skip, partner links need it)"
  ask TP_TRS "Project ID" 0 0
  tp_trs="$ASKED"
  say ""
  say "5/5  Telegram channel link (Enter to use https://t.me/safrati_travel)"
  ask CHANNEL_URL "Channel link" 0 0 "https://t.me/safrati_travel"
  channel="$ASKED"

  NEW_ADMIN_CODE="$(gen_code)"
  tmp="$(mktemp "$APP_DIR/.env.XXXXXX")"
  {
    printf 'BOT_TOKEN=%s\n' "$bot_token"
    printf 'TP_TOKEN=%s\n' "$tp_token"
    printf 'TP_MARKER=%s\n' "$tp_marker"
    printf 'TP_TRS=%s\n' "$tp_trs"
    printf 'CHANNEL_URL=%s\n' "$channel"
    printf 'CURRENCY=sar\n'
    [[ "$BOT_NAME" =~ ^[A-Za-z][A-Za-z0-9_]{4,31}$ ]] && printf 'BOT_USERNAME=%s\n' "$BOT_NAME"
    printf 'ADMIN_CODE=%s\n' "$NEW_ADMIN_CODE"
  } > "$tmp"
  chmod 600 "$tmp"
  mv "$tmp" "$ENV_FILE"
  say ""
  say "Settings saved in $ENV_FILE (readable by root only)."
fi

chmod 600 "$ENV_FILE"
say ""
start_bot || exit 1

say ""
say "Containers of this project:"
compose ps
say ""
if [ "$(web_mode)" != off ]; then
  say "The website is switched on too (mode: $(web_mode)). Its address:  bash web.sh link"
else
  say "Website (optional, with a free temporary link):  bash web.sh quick"
fi
say ""
if [ -n "$NEW_ADMIN_CODE" ]; then
  say "Your one-time admin code:  $NEW_ADMIN_CODE"
  say "In Telegram, open your bot and send:  /admin $NEW_ADMIN_CODE"
  say "The code stops working after the first use. Do not post screenshots of this screen."
  say "Then send /diag to the bot to test the price connection."
fi
say "Done."
