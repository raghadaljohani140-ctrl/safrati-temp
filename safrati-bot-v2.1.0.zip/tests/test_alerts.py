"""Price alerts: creating them, the typed target price, the lists, and the background pass that watches prices."""
import asyncio
import unittest
from datetime import date

from safrati import alerts as alerts_mod
from safrati import data
from safrati import dates as dts
from safrati import texts
from safrati.alerts import ALERT_EVERY, PENDING_TTL, watch_expiry
from safrati.trip import watch_scope, wish_of_scope
from safrati.ui import MAX_WATCHES
from tests.fakes import NOW
from tests.helpers import html_errors
from tests.test_app import AppCase

ROUTE = ("RUH", "IST")          # the route most tests watch: 1,100 riyals at its cheapest in the fake data
STEP = ALERT_EVERY + 60         # long enough for a watch to be due again


class ScopeTests(unittest.TestCase):
    def test_scope_round_trip(self):
        cases = [
            (dts.DateWish(), "any"),
            (dts.DateWish(weekend=True), "w"),
            (dts.DateWish(month="2026-12"), "m:2026-12"),
            (dts.DateWish(depart=date(2026, 12, 15), ret=date(2026, 12, 22)), "e:2026-12-15:2026-12-22"),
            (dts.DateWish(depart=date(2026, 12, 15), one_way=True), "o:2026-12-15"),
        ]
        for wish, scope in cases:
            self.assertEqual(watch_scope(wish), scope)
            self.assertEqual(watch_scope(wish_of_scope(scope)), scope)

    def test_unknown_scopes_are_refused(self):
        for bad in ("", "x", "m:2026", "m:2026-13", "e:2026-12-15", "e:2026-12-15:bad", "o:", "o:2026-13-45", "e:1:2:3"):
            self.assertIsNone(wish_of_scope(bad), bad)

    def test_expiry_is_the_last_day_worth_watching(self):
        today = date(2026, 10, 26)
        self.assertEqual(watch_expiry("any", today), "2027-01-24")             # open-ended alerts end after 90 days
        self.assertEqual(watch_expiry("w", today), "2027-01-24")
        self.assertEqual(watch_expiry("m:2026-12", today), "2026-12-31")
        self.assertEqual(watch_expiry("m:2028-02", today), "2028-02-29")        # leap year
        self.assertEqual(watch_expiry("e:2026-12-15:2026-12-22", today), "2026-12-15")
        self.assertEqual(watch_expiry("o:2026-11-05", today), "2026-11-05")


class AlertCase(AppCase):
    """A bot whose clock the test moves by hand (the bot and the price client share it)."""

    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.t = NOW
        self.bot.clock = lambda: self.t
        self.tp._clock = lambda: self.t

    def later(self, seconds: float = STEP) -> None:
        self.t += seconds

    def shown(self) -> dict:
        """The newest message, whether it was sent or edited in place."""
        return [p for m, p in self.tg.calls if m in ("sendMessage", "editMessageText")][-1]

    async def watch_from_card(self, uid: int, text: str = "اسطنبول") -> int:
        """Open a destination by name, press «نبهني» on its card and return the new watch's id."""
        await self.say(uid, text)
        press = next(c for c in self.data_buttons(self.shown()) if c.startswith("wa:"))
        await self.tap(uid, press)
        return self.db.watches_of(uid)[-1]["id"]

    def drop_price(self, factor: float, route=ROUTE) -> None:
        self.fake.factor[route] = factor


class CreatingTests(AlertCase):
    async def test_the_alert_button_stores_a_watch_with_todays_price(self):
        watch_id = await self.watch_from_card(1)
        msg = self.last()
        self.assertIn("بنبهك لما ينزل السعر", msg["text"])
        self.assertIn("1,100 ر.س", msg["text"])
        self.assertEqual(html_errors(msg["text"]), [])
        row = self.db.get_watch(watch_id, 1)
        self.assertEqual(
            (row["origin"], row["dest"], row["scope"], row["stay"], row["base"], row["last_price"]),
            ("RUH", "IST", "any", 0, 1100, 1100),
        )
        self.assertEqual(row["expires"], "2027-01-24")
        self.assertIn(f"wt:{watch_id}", self.data_buttons(msg))
        self.assertIn("al", self.data_buttons(msg))

    async def test_the_same_alert_is_stored_once(self):
        await self.watch_from_card(1)
        await self.tap(1, "wa:IST:-:-:0:0")               # the card's own button
        self.assertIn("موجود عندي من قبل", self.last()["text"])
        self.assertEqual(self.db.watch_count(1), 1)

    async def test_every_kind_of_alert_can_be_created(self):
        self.fake.weekend_deals.add(("RUH", "DXB"))
        cases = {
            "wa:IST:20261215:20261222:0:0": ("e:2026-12-15:2026-12-22", 0, "2026-12-15"),
            "wa:IST:20261215:-:1:0": ("o:2026-12-15", 0, "2026-12-15"),
            "wa:IST:202612:-:0:7": ("m:2026-12", 7, "2026-12-31"),
            "wa:DXB:w:-:0:0": ("w", 0, "2027-01-24"),
            "wa:CAI:-:-:0:7": ("any", 7, "2027-01-24"),
        }
        for payload, (scope, stay, expires) in cases.items():
            await self.tap(1, payload)
        rows = {(r["dest"], r["scope"]): r for r in self.db.watches_of(1)}
        self.assertEqual(len(rows), 5)
        for payload, (scope, stay, expires) in cases.items():
            iata = payload.split(":")[1]
            row = rows[(iata, scope)]
            self.assertEqual((row["stay"], row["expires"]), (stay, expires), payload)
            self.assertGreater(row["last_price"] or 0, 0, payload)         # the fake has a price for each of them
        for message in self.tg.sent():
            self.assertEqual(html_errors(message["text"]), [])

    async def test_an_alert_without_a_price_yet_is_still_kept(self):
        self.fake.routes["RUH"].pop("IST")
        watch_id = await self.watch_from_card(1)
        self.assertIn("ما عندي سعر محفوظ", self.last()["text"])
        row = self.db.get_watch(watch_id, 1)
        self.assertIsNone(row["base"])
        self.assertIsNone(row["last_price"])

    async def test_garbage_buttons_are_harmless(self):
        for payload in (
            "wa:IST", "wa:IST:x:y:0:0", "wa:IST:20261215:20261222:2:0", "wa:IST:20261215:20261222:0:99",
            "wa:IST:20261215:20261222:0:-1", "wa:IST:20200101:20200105:0:0", "wa:ZZZ:-:-:0:0", "wa:IST:-:20261215:0:0",
            "wa:IST:20261215:xx:0:0", "wa:IST:w:-:0:abc", "wt:abc", "wt:99999", "wt:", "wd:abc", "wd:99999", "wo:99999",
            "wo:0", "wo:abc", "al:junk",
        ):
            await self.tap(1, payload)                       # none of these may raise
        self.assertEqual(self.db.watch_count(1), 0)
        for message in self.tg.sent():
            self.assertEqual(html_errors(message["text"]), [])

    async def test_at_most_eight_alerts_per_person(self):
        iatas = ["IST", "TZX", "AYT", "DXB", "CAI", "TBS", "BAK", "SJJ"]
        self.assertEqual(len(iatas), MAX_WATCHES)
        for iata in iatas:
            await self.tap(1, f"wa:{iata}:-:-:0:0")
        self.assertEqual(self.db.watch_count(1), MAX_WATCHES)
        await self.tap(1, "wa:BKK:-:-:0:0")
        self.assertIn(f"({MAX_WATCHES})", self.last()["text"])
        self.assertEqual(self.db.watch_count(1), MAX_WATCHES)
        await self.tap(1, "wa:IST:-:-:0:0")                  # an existing one is not "a new one over the limit"
        self.assertIn("موجود عندي من قبل", self.last()["text"])
        await self.tap(2, "wa:BKK:-:-:0:0")                  # the limit is per person
        self.assertEqual(self.db.watch_count(2), 1)

    async def test_without_a_price_provider_no_alert_is_created(self):
        self.build(tp_enabled=False)
        await self.tap(1, "wa:IST:-:-:0:0")
        self.assertEqual(self.db.watch_count(1), 0)
        self.assertIn(texts.NOTE_NO_PRICE["off"], self.last()["text"])
        self.assertEqual(await self.bot.check_alerts(), 0)


class ListTests(AlertCase):
    async def test_empty_list_explains_how_to_start(self):
        await self.say(1, "/alerts")
        self.assertEqual(self.last()["text"], texts.ALERTS_EMPTY)
        self.assertIn("go", self.data_buttons(self.last()))

    async def test_list_open_and_delete(self):
        first = await self.watch_from_card(1, "اسطنبول")
        second = await self.watch_from_card(1, "دبي")
        await self.say(1, "/alerts")
        msg = self.last()
        self.assertIn(f"(2/{MAX_WATCHES})", msg["text"])
        self.assertIn(data.by_iata()["IST"].ar, msg["text"])
        self.assertIn(data.by_iata()["DXB"].ar, msg["text"])
        self.assertEqual(html_errors(msg["text"]), [])
        buttons = self.data_buttons(msg)
        for prefix in ("wo", "wt", "wd"):
            self.assertIn(f"{prefix}:{first}", buttons)
            self.assertIn(f"{prefix}:{second}", buttons)

        self.tg.reset()
        await self.tap(1, f"wd:{first}", message_id=77)
        edited = self.tg.of("editMessageText")
        self.assertEqual(len(edited), 1)
        self.assertEqual(edited[0]["message_id"], 77)                       # the list is refreshed in place
        self.assertIn(f"(1/{MAX_WATCHES})", edited[0]["text"])
        self.assertIsNone(self.db.get_watch(first, 1))

        self.tg.reset()
        await self.tap(1, f"wo:{second}")
        self.assertIn("دبي", self.shown()["text"])                          # opens the trip the alert stands for
        self.assertIn("wa:DXB:-:-:0:0", self.data_buttons(self.shown()))

    async def test_nobody_can_touch_another_persons_alert(self):
        mine = await self.watch_from_card(1)
        await self.tap(2, f"wd:{mine}")
        await self.tap(2, f"wo:{mine}")
        await self.tap(2, f"wt:{mine}")
        self.assertIsNotNone(self.db.get_watch(mine, 1))
        self.assertIsNone(self.bot.pending_target(2))
        await self.say(2, "900")                                           # not taken as a target for someone else's alert
        self.assertIsNone(self.db.get_watch(mine, 1)["target"])

    async def test_list_shows_the_target_and_the_last_price(self):
        watch_id = await self.watch_from_card(1)
        self.db.set_watch_target(watch_id, 1, 900)
        await self.say(1, "/alerts")
        self.assertIn("الهدف 900 ر.س", self.last()["text"])
        self.assertIn("الحين 1,100 ر.س", self.last()["text"])

    async def test_free_text_about_alerts_opens_the_list(self):
        await self.say(1, "تنبيهاتي")
        self.assertEqual(self.last()["text"], texts.ALERTS_EMPTY)


class TargetPriceTests(AlertCase):
    async def start(self) -> int:
        watch_id = await self.watch_from_card(1)
        await self.tap(1, f"wt:{watch_id}")
        self.assertIn(texts.TARGET_PROMPT, self.last()["text"])
        self.assertEqual(self.bot.pending_target(1), watch_id)
        return watch_id

    async def test_a_typed_price_becomes_the_target(self):
        watch_id = await self.start()
        await self.say(1, "900")
        self.assertEqual(self.db.get_watch(watch_id, 1)["target"], 900)
        self.assertIn("900 ر.س", self.last()["text"])
        self.assertIsNone(self.bot.pending_target(1))
        self.assertEqual(html_errors(self.last()["text"]), [])

    async def test_arabic_digits_and_thousand_separators_are_understood(self):
        watch_id = await self.start()
        await self.say(1, "٩٥٠")
        self.assertEqual(self.db.get_watch(watch_id, 1)["target"], 950)

    async def test_a_price_above_the_current_one_is_refused_with_a_hint(self):
        watch_id = await self.start()
        await self.say(1, "1500")
        self.assertIn("1,100", self.last()["text"])
        self.assertIn("990", self.last()["text"])
        self.assertIsNone(self.db.get_watch(watch_id, 1)["target"])
        self.assertEqual(self.bot.pending_target(1), watch_id)             # still waiting: the person can type again
        await self.say(1, "1000")
        self.assertEqual(self.db.get_watch(watch_id, 1)["target"], 1000)

    async def test_a_silly_price_is_refused(self):
        watch_id = await self.start()
        await self.say(1, "50")
        self.assertEqual(self.last()["text"], texts.TARGET_BAD)
        self.assertIsNone(self.db.get_watch(watch_id, 1)["target"])
        self.assertEqual(self.bot.pending_target(1), watch_id)

    async def test_other_text_ends_the_wait_and_is_handled_normally(self):
        await self.start()
        await self.say(1, "دبي")
        self.assertIsNone(self.bot.pending_target(1))
        self.assertIn("دبي", self.last()["text"])

    async def test_a_command_ends_the_wait(self):
        await self.start()
        await self.say(1, "/menu")
        self.assertIsNone(self.bot.pending_target(1))
        await self.say(1, "900")                                           # now an ordinary budget
        self.assertIn("ميزانيتك 900", self.last()["text"])

    async def test_the_wait_runs_out(self):
        watch_id = await self.start()
        self.later(PENDING_TTL + 1)
        await self.say(1, "900")
        self.assertIsNone(self.db.get_watch(watch_id, 1)["target"])
        self.assertIn("ميزانيتك 900", self.last()["text"])

    async def test_pressing_a_button_ends_the_wait(self):
        await self.start()
        await self.tap(1, "menu")
        self.assertIsNone(self.bot.pending_target(1))

    async def test_the_alert_can_vanish_while_waiting(self):
        watch_id = await self.start()
        self.db.delete_watch(watch_id, 1)
        await self.say(1, "900")
        self.assertEqual(self.last()["text"], texts.BAD_BUTTON)
        self.assertIsNone(self.bot.pending_target(1))


class WorkerTests(AlertCase):
    async def test_nothing_happens_before_a_watch_is_due(self):
        await self.watch_from_card(1)
        self.tg.reset()
        self.drop_price(0.5)
        self.assertEqual(await self.bot.check_alerts(), 0)
        self.later(3600)
        self.assertEqual(await self.bot.check_alerts(), 0)
        self.assertEqual(self.tg.sent(), [])

    async def test_a_real_drop_is_reported_once(self):
        watch_id = await self.watch_from_card(1)
        self.tg.reset()
        self.drop_price(0.8)                                               # 1,100 -> 880
        self.later()
        self.assertEqual(await self.bot.check_alerts(), 1)
        msg = self.tg.sent_to(1)[-1]
        self.assertIn("نزل السعر", msg["text"])
        self.assertIn("880 ر.س", msg["text"])
        self.assertIn("كان 1,100 ر.س", msg["text"])
        self.assertIn("نزل 20%", msg["text"])
        self.assertEqual(html_errors(msg["text"]), [])
        buttons = self.tg.buttons(msg)
        self.assertTrue(buttons[0]["url"].startswith("https://tp.media/r?marker="))            # the booking link
        self.assertIn("880", buttons[0]["text"])
        self.assertIn(f"wd:{watch_id}", self.data_buttons(msg))                                # stop the alert
        row = self.db.get_watch(watch_id, 1)
        self.assertEqual((row["base"], row["notified"], row["last_price"]), (880, 880, 880))
        self.assertEqual(self.db.kv_get("alerts_sent"), "1")

        self.tg.reset()
        self.later()
        self.assertEqual(await self.bot.check_alerts(), 0)                 # the same price again is not news
        self.drop_price(0.78)                                              # 858: only 2.5% lower
        self.later()
        self.assertEqual(await self.bot.check_alerts(), 0)
        self.drop_price(0.6)                                               # 660: a further real drop
        self.later()
        self.assertEqual(await self.bot.check_alerts(), 1)
        self.assertIn("كان 880 ر.س", self.tg.sent_to(1)[-1]["text"])

    async def test_a_small_drop_is_not_reported(self):
        await self.watch_from_card(1)
        self.tg.reset()
        self.drop_price(0.95)
        self.later()
        self.assertEqual(await self.bot.check_alerts(), 0)
        self.assertEqual(self.tg.sent(), [])

    async def test_going_back_down_after_a_rise_is_reported(self):
        watch_id = await self.watch_from_card(1)
        self.tg.reset()
        self.drop_price(1.5)                                               # 1,650: the reference follows the price up
        self.later()
        self.assertEqual(await self.bot.check_alerts(), 0)
        self.assertEqual(self.db.get_watch(watch_id, 1)["base"], 1650)
        self.drop_price(1.0)                                               # back to 1,100: 33% under the new reference
        self.later()
        self.assertEqual(await self.bot.check_alerts(), 1)
        self.assertIn("كان 1,650 ر.س", self.tg.sent_to(1)[-1]["text"])

    async def test_target_price_is_reported_when_reached_and_again_only_for_a_further_fall(self):
        watch_id = await self.watch_from_card(1)
        self.db.set_watch_target(watch_id, 1, 900)
        self.tg.reset()
        self.drop_price(0.9)                                               # 990: not there yet
        self.later()
        self.assertEqual(await self.bot.check_alerts(), 0)
        self.drop_price(0.8)                                               # 880: below 900
        self.later()
        self.assertEqual(await self.bot.check_alerts(), 1)
        self.assertIn("وصل لهدفك", self.tg.sent_to(1)[-1]["text"])
        self.later()
        self.assertEqual(await self.bot.check_alerts(), 0)                 # still 880: already told
        self.drop_price(0.79)                                              # 869: 1% lower, not news
        self.later()
        self.assertEqual(await self.bot.check_alerts(), 0)
        self.drop_price(0.7)                                               # 770: 12% lower than the last notice
        self.later()
        self.assertEqual(await self.bot.check_alerts(), 1)

    async def test_the_first_price_of_a_route_without_one_is_reported(self):
        self.fake.routes["RUH"].pop("IST")
        watch_id = await self.watch_from_card(1)
        self.tg.reset()
        self.later()
        self.assertEqual(await self.bot.check_alerts(), 0)                 # still no price: nothing to say
        self.assertIsNone(self.db.get_watch(watch_id, 1)["base"])
        self.fake.routes["RUH"]["IST"] = 1100
        self.later()
        self.assertEqual(await self.bot.check_alerts(), 1)
        self.assertIn("ظهر سعر", self.tg.sent_to(1)[-1]["text"])
        row = self.db.get_watch(watch_id, 1)
        self.assertEqual((row["base"], row["last_price"]), (1100, 1100))
        self.later()
        self.assertEqual(await self.bot.check_alerts(), 0)

    async def test_exact_date_and_month_alerts_are_judged_on_their_own_dates(self):
        await self.tap(1, "wa:IST:20261215:20261222:0:0")
        await self.tap(1, "wa:IST:202611:-:0:0")
        self.tg.reset()
        self.drop_price(0.5)
        self.later()
        self.assertEqual(await self.bot.check_alerts(), 2)
        texts_sent = " ".join(m["text"] for m in self.tg.sent_to(1))
        self.assertIn("15 ديسمبر ← 22 ديسمبر", texts_sent)

    async def test_people_watching_the_same_trip_are_all_told(self):
        await self.watch_from_card(1)
        await self.watch_from_card(2)
        self.tg.reset()
        before = len(self.fake.price_calls())
        self.drop_price(0.8)
        self.later()
        self.assertEqual(await self.bot.check_alerts(), 2)
        self.assertEqual(len(self.tg.sent_to(1)), 1)
        self.assertEqual(len(self.tg.sent_to(2)), 1)
        self.assertLessEqual(len(self.fake.price_calls()) - before, 3)     # one lookup for both (three months), not two

    async def test_a_person_who_blocked_the_bot_loses_the_alerts_and_others_are_unaffected(self):
        await self.watch_from_card(1)
        await self.tap(1, "wa:DXB:-:-:0:0")
        await self.watch_from_card(2)
        self.drop_price(0.8)
        self.tg.blocked.add(1)
        self.later()
        self.assertEqual(await self.bot.check_alerts(), 1)                 # only person 2 got a message
        self.assertEqual(self.db.watch_count(1), 0)
        self.assertEqual(self.db.watch_count(2), 1)
        self.assertEqual(self.db.get_watch(self.db.watches_of(2)[0]["id"], 2)["notified"], 880)

    async def test_other_telegram_errors_keep_the_alert_for_a_retry(self):
        watch_id = await self.watch_from_card(1)
        self.drop_price(0.8)
        self.tg.fail_always["sendMessage"] = (500, "Internal error")
        self.later()
        self.assertEqual(await self.bot.check_alerts(), 0)
        self.assertEqual(self.db.watch_count(1), 1)
        self.assertIsNone(self.db.get_watch(watch_id, 1)["notified"])      # not marked as told
        self.tg.fail_always.clear()
        self.later()
        self.assertEqual(await self.bot.check_alerts(), 1)                 # told on the next pass

    async def test_alerts_whose_dates_have_passed_are_removed(self):
        await self.tap(1, "wa:IST:20261030:20261106:0:0")
        await self.watch_from_card(1)
        self.assertEqual(self.db.watch_count(1), 2)
        self.later(5 * 86400)                                              # it is now 31 October
        await self.bot.check_alerts()
        self.assertEqual([w["scope"] for w in self.db.watches_of(1)], ["any"])

    async def test_open_alerts_end_after_ninety_days(self):
        await self.watch_from_card(1)
        self.later(91 * 86400)
        await self.bot.check_alerts()
        self.assertEqual(self.db.watch_count(1), 0)

    async def test_a_provider_failure_does_not_lose_or_complete_the_check(self):
        watch_id = await self.watch_from_card(1)
        checked = self.db.get_watch(watch_id, 1)["checked_at"]
        self.fake.status = 500
        self.later()
        self.assertEqual(await self.bot.check_alerts(), 0)
        self.assertEqual(self.db.get_watch(watch_id, 1)["checked_at"], checked)      # still due
        self.fake.status = 200
        self.drop_price(0.8)
        self.later(60)                                                     # past the provider's short cool-down
        self.assertEqual(await self.bot.check_alerts(), 1)

    async def test_a_pass_handles_a_limited_number_of_watches(self):
        await self.tap(1, "wa:IST:-:-:0:0")
        await self.tap(1, "wa:DXB:-:-:0:0")
        await self.tap(1, "wa:CAI:-:-:0:0")
        old = alerts_mod.ALERT_BATCH
        alerts_mod.ALERT_BATCH = 2
        try:
            self.fake.factor.update({("RUH", "IST"): 0.5, ("RUH", "DXB"): 0.5, ("RUH", "CAI"): 0.5})
            self.later()
            self.assertEqual(await self.bot.check_alerts(), 2)
            self.assertEqual(await self.bot.check_alerts(), 1)             # the third is picked up by the next pass
            self.assertEqual(await self.bot.check_alerts(), 0)
        finally:
            alerts_mod.ALERT_BATCH = old

    async def test_the_background_loop_runs_and_stops_cleanly(self):
        stop = asyncio.Event()
        stop.set()
        await asyncio.wait_for(self.bot.alerts_loop(stop), 2)
        stop = asyncio.Event()
        passes = []

        async def once():
            passes.append(1)
            stop.set()
            return 0

        self.bot.check_alerts = once
        old = alerts_mod.ALERT_FIRST_DELAY
        alerts_mod.ALERT_FIRST_DELAY = 0
        try:
            await asyncio.wait_for(self.bot.alerts_loop(stop), 2)
        finally:
            alerts_mod.ALERT_FIRST_DELAY = old
        self.assertEqual(passes, [1])

    async def test_a_crash_in_one_pass_does_not_kill_the_loop(self):
        stop = asyncio.Event()
        calls = []

        async def broken():
            calls.append(1)
            if len(calls) == 2:
                stop.set()
            raise RuntimeError("boom")

        self.bot.check_alerts = broken
        olds = alerts_mod.ALERT_FIRST_DELAY, alerts_mod.ALERT_TICK
        alerts_mod.ALERT_FIRST_DELAY = alerts_mod.ALERT_TICK = 0
        try:
            with self.assertLogs("safrati.alerts", level="ERROR"):
                await asyncio.wait_for(self.bot.alerts_loop(stop), 2)
        finally:
            alerts_mod.ALERT_FIRST_DELAY, alerts_mod.ALERT_TICK = olds
        self.assertEqual(len(calls), 2)


if __name__ == "__main__":
    unittest.main()
