import unittest
from datetime import date

from safrati import data
from safrati import dates as dts

TODAY = date(2026, 10, 26)


def parse(text):
    return dts.parse_dates(data.norm_keep(text), TODAY)


class ParseTests(unittest.TestCase):
    def test_numeric_range_with_return(self):
        wish, rest = parse("دبي 15/12 - 22/12")
        self.assertEqual((wish.depart, wish.ret), (date(2026, 12, 15), date(2026, 12, 22)))
        self.assertEqual(rest.strip(), "دبي")

    def test_single_day_and_year_rollover(self):
        self.assertEqual(parse("اسطنبول 20-12")[0].depart, date(2026, 12, 20))
        self.assertEqual(parse("لندن 5/1")[0].depart, date(2027, 1, 5))   # January already passed this year

    def test_iso_and_arabic_digits(self):
        self.assertEqual(parse("2026-12-03")[0].depart, date(2026, 12, 3))
        self.assertEqual(parse("١٥/١٢")[0].depart, date(2026, 12, 15))

    def test_month_name_and_month_only(self):
        wish, rest = parse("ديسمبر 4000")
        self.assertEqual(wish.month, "2026-12")
        self.assertIn("4000", rest)
        self.assertEqual(parse("يناير")[0].month, "2027-01")

    def test_days_range_inside_a_month(self):
        wish, _ = parse("من 15 الى 22 ديسمبر")
        self.assertEqual((wish.depart, wish.ret), (date(2026, 12, 15), date(2026, 12, 22)))
        wish, _ = parse("28 - 3 يناير")
        self.assertEqual((wish.depart, wish.ret), (date(2026, 12, 28), date(2027, 1, 3)))

    def test_relative_words(self):
        self.assertEqual(parse("بكرة")[0].depart, date(2026, 10, 27))
        self.assertEqual(parse("بعد اسبوعين")[0].depart, date(2026, 11, 9))

    def test_numbers_that_are_not_dates(self):
        for text in ("5-10 ايام", "2.5 الف", "4000", "5000 ريال"):
            self.assertFalse(parse(text)[0].has_dates, text)

    def test_one_way(self):
        wish, _ = parse("دبي 15/12 ذهاب فقط")
        self.assertTrue(wish.one_way)
        self.assertEqual(wish.depart, date(2026, 12, 15))
        self.assertIsNone(wish.ret)

    def test_impossible_day_is_not_a_date(self):
        self.assertFalse(parse("31/2")[0].has_dates)

    def test_problem(self):
        self.assertEqual(dts.problem(dts.DateWish(depart=date(2026, 10, 26)), TODAY), "past")
        self.assertEqual(dts.problem(dts.DateWish(depart=date(2028, 1, 1)), TODAY), "far")
        self.assertEqual(dts.problem(dts.DateWish(month="2026-09"), TODAY), "past")
        self.assertIsNone(dts.problem(dts.DateWish(depart=date(2026, 12, 15)), TODAY))
        self.assertIsNone(dts.problem(dts.DateWish(), TODAY))


class StayWeekendMonthTests(unittest.TestCase):
    """«كم يوم»، الويكند، والشهر الجاي: the phrases people use instead of exact dates."""

    def test_trip_length_in_digits_and_words(self):
        cases = {
            "دبي 5 ايام": 5, "دبي ٥ ايام": 5, "دبي 7 ليال": 7, "دبي 10 ليالي": 10, "دبي مدة 4 ايام": 4, "دبي لمدة 6 ايام": 6,
            "دبي ثلاثة ايام": 3, "دبي عشرة ايام": 10, "دبي يومين": 2, "دبي اسبوع": 7, "دبي لمدة اسبوع": 7,
            "دبي اسبوعين": 14, "دبي 3 اسابيع": 21, "دبي ثلاثة اسابيع": 21, "دبي 30 يوم": 30,
        }
        for text, days in cases.items():
            self.assertEqual(parse(text)[0].stay, days, text)

    def test_lengths_out_of_range_are_ignored(self):
        for text in ("دبي 1 يوم", "دبي 31 يوم", "دبي 45 يوم", "دبي 99 ايام"):
            self.assertIsNone(parse(text)[0].stay, text)

    def test_a_trip_length_is_not_a_date_and_does_not_count_as_one(self):
        wish, rest = parse("دبي 5 ايام")
        self.assertFalse(wish.has_dates)
        self.assertEqual(rest.strip(), "دبي")

    def test_a_length_beside_a_month_or_a_day(self):
        wish, _ = parse("دبي ديسمبر 5 ايام")
        self.assertEqual((wish.month, wish.stay), ("2026-12", 5))
        wish, _ = parse("دبي 15/12 اسبوع")
        self.assertEqual((wish.depart, wish.ret, wish.stay), (date(2026, 12, 15), None, 7))
        wish, _ = parse("دبي 20/12 يومين")
        self.assertEqual((wish.depart, wish.stay), (date(2026, 12, 20), 2))
        wish, _ = parse("دبي ديسمبر 20 اسبوعين")
        self.assertEqual((wish.depart, wish.stay), (date(2026, 12, 20), 14))

    def test_exact_days_make_the_length_redundant(self):
        wish, _ = parse("دبي 15/12 - 22/12 اسبوع")
        self.assertEqual((wish.depart, wish.ret, wish.stay), (date(2026, 12, 15), date(2026, 12, 22), None))

    def test_numbers_inside_dates_and_amounts_are_not_lengths(self):
        for text in ("دبي 20/12 يوم", "3/4 ايام", "5000 ريال", "2.5 الف"):
            self.assertIsNone(parse(text)[0].stay, text)
        self.assertEqual(parse("دبي 3/4 ريال")[0].depart, None)                 # a fraction of a riyal, not the 3rd of April

    def test_weekend_words(self):
        for text in ("ويكند", "دبي الويكند", "دبي ويك اند", "دبي weekend", "دبي للويكند", "دبي بالويكند",
                     "دبي نهاية الاسبوع", "دبي نهايه الاسبوع", "دبي اخر الاسبوع", "دبي الويك اند الجاي"):
            wish, _ = parse(text)
            self.assertTrue(wish.weekend, text)
            self.assertFalse(wish.has_dates, text)

    def test_weekend_is_not_triggered_by_other_words(self):
        for text in ("دبي اسبوع", "دبي 4000", "دبي الاسبوع الجاي", "اسبوعي", "دبي نهاية"):
            self.assertFalse(parse(text)[0].weekend, text)

    def test_weekend_can_come_with_a_month(self):
        wish, _ = parse("ويكند ديسمبر")
        self.assertEqual((wish.weekend, wish.month), (True, "2026-12"))
        wish, _ = parse("ويكند الشهر الجاي")
        self.assertEqual((wish.weekend, wish.month), (True, "2026-11"))

    def test_next_and_this_month(self):
        for text in ("دبي الشهر الجاي", "دبي شهر جاي", "دبي الشهر القادم", "دبي الشهر القادمه"):
            self.assertEqual(parse(text)[0].month, "2026-11", text)
        for text in ("دبي هذا الشهر", "دبي هالشهر", "دبي الشهر الحالي", "دبي شهر هذا"):
            self.assertEqual(parse(text)[0].month, "2026-10", text)

    def test_next_month_crosses_the_year(self):
        december = date(2026, 12, 15)
        wish, _ = dts.parse_dates(data.norm_keep("دبي الشهر الجاي"), december)
        self.assertEqual(wish.month, "2027-01")

    def test_an_explicit_day_beats_a_month_phrase(self):
        wish, _ = parse("دبي 15/12 الشهر الجاي")
        self.assertEqual(wish.depart, date(2026, 12, 15))
        self.assertIsNone(wish.month)

    def test_a_budget_next_to_these_phrases_is_left_alone(self):
        for text in ("ويكند 3000", "5 ايام 3000", "الشهر الجاي 3000"):
            _wish, rest = parse(text)
            self.assertIn("3000", rest, text)


class CalendarTests(unittest.TestCase):
    def test_month_choices_start_now_and_are_limited(self):
        keys = dts.month_choices(TODAY, 6)
        self.assertEqual(keys[0], "2026-10")
        self.assertEqual(len(keys), 6)

    def test_grid_marks_past_days_unselectable(self):
        grid = dts.month_grid("2026-10", TODAY)
        flat = {d: ok for week in grid for d, ok in week if d}
        self.assertFalse(flat[26])
        self.assertTrue(flat[27])
        self.assertTrue(all(len(week) == 7 for week in grid))

    def test_tokens_round_trip(self):
        wish = dts.DateWish(depart=date(2026, 12, 15), ret=date(2026, 12, 22))
        self.assertEqual(dts.decode_when(*dts.encode_when(wish), False), wish)
        month = dts.DateWish(month="2026-12")
        self.assertEqual(dts.decode_when(*dts.encode_when(month), False), month)

    def test_malformed_tokens(self):
        for dep, ret in (("20261340", "-"), ("abc", "-"), ("-", "20261215"), ("20261215", "zz"), ("202613", "-")):
            self.assertIsNone(dts.decode_when(dep, ret, False), (dep, ret))


if __name__ == "__main__":
    unittest.main()
