import json
import unittest
from collections import defaultdict
from datetime import date

from safrati import data, texts


class UnderstandTests(unittest.TestCase):
    def check(self, text, *, budget=None, dests=None, origin=None, tags=None, ticket=None):
        got = data.understand(text)
        self.assertEqual(got.budget, budget, text)
        if dests is not None:
            self.assertEqual(sorted(d.iata for d in got.destinations), sorted(dests), text)
        if origin is not None:
            self.assertEqual(got.origin, origin, text)
        if tags is not None:
            self.assertEqual(sorted(got.tags), sorted(tags), text)
        if ticket is not None:
            self.assertEqual(got.ticket_only, ticket, text)

    def test_budgets(self):
        self.check("5000", budget=5000, dests=[])
        self.check("ميزانيتي ٥٠٠٠ ريال", budget=5000)
        self.check("5,000 ريال بحر", budget=5000, tags=["beach"])
        self.check("خمسة الاف", budget=5000)
        self.check("3 الاف وهدوء", budget=3000, tags=["calm"])
        self.check("7 ايام", budget=None)
        self.check("ميزانيتي المالية 4000", budget=4000, dests=[])
        self.check("عندي 12 يوم", budget=None)
        self.check("100", budget=None)

    def test_ticket_only_words(self):
        self.check("5000 للتذكرة", budget=5000, ticket=True)
        self.check("ميزانيتي 5000", budget=5000, ticket=False)

    def test_destinations(self):
        self.check("لتركيا", dests=["IST", "TZX", "AYT"])
        self.check("الى اسطنبول من جدة", dests=["IST"], origin="JED")
        self.check("بدبي", dests=["DXB"])
        self.check("المغرب", dests=["CMN", "RAK"])
        self.check("عمان", dests=["MCT", "AMM"])
        self.check("طرابزون", dests=["TZX"])
        self.check("من الدمام الى بانكوك 6000", budget=6000, dests=["BKK"], origin="DMM")
        self.check("Istanbul", dests=["IST"])

    def test_origin_needs_the_word_from(self):
        self.check("جدة", dests=[], origin=None)

    def test_small_talk(self):
        cases = {
            "فاجئني": "surprise", "فاجني": "surprise", "مرحبا": "greeting", "السلام عليكم": "greeting",
            "شكرا": "thanks", "اعدادات": "settings", "محفوظاتي": "saved", "مساعدة": "help",
            "ودي اسافر": "surprise", "xyz qwerty": None,
        }
        for text, kind in cases.items():
            self.assertEqual(data.small_talk(text), kind, text)

    def test_tags(self):
        self.check("ابغا جبال وثلج", tags=["mountains"])
        self.check("تسوق وطعام", tags=["shopping", "food"])


class RegionAndWordTests(unittest.TestCase):
    def regions(self, text):
        return data.understand(text).regions

    def test_regions_are_found_in_free_text(self):
        cases = {
            "اوروبا": ("europe",), "رحلات اوروبا": ("europe",), "باوروبا": ("europe",), "شنغن": ("europe",),
            "الخليج": ("gulf",), "دول الخليج": ("gulf",), "القوقاز": ("caucasus",), "اسيا": ("asia",), "لاسيا": ("asia",),
            "وسط اسيا": ("central_asia",), "الدول العربيه": ("arab",), "افريقيا": ("africa",), "امريكا": ("america",),
        }
        for text, expected in cases.items():
            self.assertEqual(self.regions(text), expected, text)

    def test_central_asia_is_not_also_read_as_asia(self):
        self.assertEqual(self.regions("وسط اسيا"), ("central_asia",))
        self.assertEqual(sorted(self.regions("وسط اسيا واوروبا")), ["central_asia", "europe"])

    def test_no_region_in_ordinary_text(self):
        for text in ("دبي", "5000", "ويكند", "عربي", "ارخص رحله"):
            self.assertEqual(self.regions(text), (), text)

    def test_in_region_uses_the_country(self):
        by = data.by_iata()
        self.assertTrue(data.in_region(by["LON"], ("europe",)))
        self.assertTrue(data.in_region(by["DXB"], ("gulf",)))
        self.assertTrue(data.in_region(by["CAI"], ("arab", "africa")))
        self.assertTrue(data.in_region(by["TBS"], ("caucasus",)))
        self.assertFalse(data.in_region(by["BKK"], ("europe", "gulf")))
        self.assertFalse(data.in_region(by["DXB"], ()))

    def test_every_region_has_destinations_and_labels(self):
        from safrati import texts
        for region in data.REGION_CC:
            members = [d for d in data.destinations() if data.in_region(d, (region,))]
            self.assertTrue(members, region)
            self.assertIn(region, texts.REGION_LABELS)
            self.assertIn(region, texts.REGION_TITLES)

    def test_cheapest_words(self):
        for text in ("ارخص", "ارخص رحله", "الارخص", "اوفر", "رخيص", "ارخص الرحلات", "طيران رخيص"):
            self.assertTrue(data.understand(text).cheapest, text)
        for text in ("دبي", "غالي", "5000"):
            self.assertFalse(data.understand(text).cheapest, text)

    def test_alerts_small_talk(self):
        for text in ("تنبيهاتي", "تنبيهات", "نبهني", "تنبيه"):
            self.assertEqual(data.small_talk(text), "alerts", text)

    def test_a_region_beside_a_month_and_a_budget(self):
        got = data.understand("اوروبا ديسمبر 5000")
        self.assertEqual((got.regions, got.dates.month, got.budget), (("europe",), "2026-12", 5000))

    def test_the_text_left_after_dates_is_available(self):
        got = data.understand("لندون 15/12")
        self.assertEqual(got.rest.strip(), "لندون")
        self.assertFalse(got.destinations)


class WelcomeExamplesTests(unittest.TestCase):
    """Every example in the welcome message must do what the message says."""

    TODAY = date(2026, 10, 26)

    def examples(self):
        import re
        return re.findall(r"<b>([^<]+)</b>", "".join(l for l in texts.WELCOME.splitlines(True) if l.startswith("•")))

    def test_the_welcome_message_has_examples(self):
        self.assertGreaterEqual(len(self.examples()), 6)

    def test_each_example_is_understood(self):
        for example in self.examples():
            got = data.understand(example, self.TODAY)
            understood = (
                got.destinations or got.regions or got.cheapest or got.dates.weekend or got.dates.has_dates
                or got.budget or got.origin or data.bare_origin(example)
            )
            self.assertTrue(understood, example)

    def test_the_longer_examples_give_what_they_promise(self):
        got = data.understand("لندن الشهر الجاي 7 ايام", self.TODAY)
        self.assertEqual([d.iata for d in got.destinations], ["LON"])
        self.assertEqual((got.dates.month, got.dates.stay), ("2026-11", 7))
        got = data.understand("اسطنبول 15/12 - 22/12", self.TODAY)
        self.assertEqual([d.iata for d in got.destinations], ["IST"])
        self.assertTrue(got.dates.depart and got.dates.ret)
        self.assertEqual(data.understand("من جدة", self.TODAY).origin, "JED")


class SuggestTests(unittest.TestCase):
    def test_close_misspellings_are_suggested(self):
        cases = {"اسطمبول": "IST", "لندون": "LON", "باريز": "PAR"}
        for text, iata in cases.items():
            self.assertEqual([d.iata for d in data.suggest(text)], [iata], text)

    def test_exact_names_and_nonsense_are_not_suggested_for_anything_else(self):
        for text in ("xqzvbn", "ابغا", "", "   ", "ا", "قطار", "قطارات", "كلمه اخرى جدا طويله بالفعل"):
            self.assertEqual(data.suggest(text), (), text)

    def test_long_sentences_are_never_guessed(self):
        self.assertEqual(data.suggest("ابغا اسافر الى لندون مع العائله"), ())


class DataIntegrityTests(unittest.TestCase):
    def test_destination_records(self):
        seen = set()
        for d in data.destinations():
            self.assertRegex(d.iata, r"^[A-Z]{3}$")
            self.assertNotIn(d.iata, seen)
            seen.add(d.iata)
            self.assertRegex(d.cc, r"^[A-Z]{2}$")
            self.assertIn(d.cost, texts.COST_TEXT)
            self.assertTrue(d.tags, d.iata)
            for tag in d.tags:
                self.assertIn(tag, texts.TAG_NAMES, d.iata)
            self.assertTrue(d.ar and d.country_ar and d.en)
        self.assertGreaterEqual(len(seen), 50)

    def test_every_destination_has_a_visa_entry(self):
        table, verified, sources = data.visa_table()
        self.assertRegex(verified, r"^\d{4}-\d{2}-\d{2}$")
        self.assertTrue(sources)
        for d in data.destinations():
            self.assertIn(d.cc, table, d.iata)
        for cc, info in table.items():
            self.assertIn(info.status, texts.VISA_SHORT, cc)
            if info.status == "check":
                self.assertFalse(info.agreed, cc)

    def test_shared_aliases_belong_to_one_country(self):
        owners = defaultdict(set)
        for d in data.destinations():
            for alias in {d.ar, d.en, *d.aliases}:
                key = data.norm(alias)
                owners[key].add(d)
        allowed = {"عمان"}  # the country Oman and the city Amman sound the same on purpose
        for key, dests in owners.items():
            if len(dests) > 1 and key not in allowed:
                self.assertEqual(len({d.cc for d in dests}), 1, f"{key}: {[d.iata for d in dests]}")

    def test_tag_vocabularies_agree(self):
        self.assertEqual(set(data.TAG_WORDS), set(texts.TAG_NAMES))
        self.assertEqual(set(texts.TAG_LABELS), set(texts.TAG_NAMES))
        from safrati.app import TAG_CODE
        self.assertEqual(set(TAG_CODE), set(texts.TAG_NAMES))
        self.assertEqual(len(set(TAG_CODE.values())), len(TAG_CODE))

    def test_partners_are_https_and_unique(self):
        ids = set()
        for p in data.partners():
            self.assertTrue(p.url.startswith("https://"))
            self.assertNotIn(p.id, ids)
            ids.add(p.id)

    def test_json_files_are_valid_utf8(self):
        for name in ("destinations.json", "visa_sa.json", "partners.json"):
            json.loads((data.DATA_DIR / name).read_text(encoding="utf-8"))

    def test_origin_cities_have_names(self):
        from safrati.db import ORIGINS
        self.assertEqual(set(ORIGINS), set(texts.ORIGIN_NAMES))
        self.assertEqual(set(ORIGINS), set(data.ORIGIN_WORDS))


if __name__ == "__main__":
    unittest.main()


class ConfigTests(unittest.TestCase):
    def test_optional_settings(self):
        from safrati.config import ConfigError, load_settings
        base = {"BOT_TOKEN": "123456789:" + "A" * 35}
        s = load_settings({**base, "TP_SHOW_ALL": "1", "TP_MARKET": "SA", "CACHE_MINUTES": "10", "DAILY_SEARCH_LIMIT": "5"})
        self.assertTrue(s.tp_show_all)
        self.assertEqual((s.tp_market, s.cache_minutes, s.daily_search_limit), ("sa", 10, 5))
        self.assertFalse(load_settings(base).tp_show_all)
        self.assertEqual(load_settings(base).currency, "sar")
        for bad in ({"TP_MARKET": "saudi"}, {"CURRENCY": "riyal"}, {"DAILY_SEARCH_LIMIT": "0"}, {"CACHE_MINUTES": "abc"}, {"TP_MARKER": "12ab"}, {"TP_TRS": "x"}):
            with self.assertRaises(ConfigError):
                load_settings({**base, **bad})
        with self.assertRaises(ConfigError):
            load_settings({})

    def test_errors_do_not_echo_values(self):
        from safrati.config import ConfigError, load_settings
        with self.assertRaises(ConfigError) as ctx:
            load_settings({"BOT_TOKEN": "123456789:" + "A" * 35, "TP_MARKER": "SECRETVALUE"})
        self.assertNotIn("SECRETVALUE", str(ctx.exception))
