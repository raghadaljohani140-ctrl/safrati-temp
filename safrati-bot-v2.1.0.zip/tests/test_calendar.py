import asyncio
import gzip
import json
import time
import unittest
from datetime import date

from safrati import tp
from tests.fakes import MARKER, NOW, TP_TOKEN, TRS, FakeTP


def make(fake: FakeTP, **kw) -> tp.TravelpayoutsClient:
    kw.setdefault("clock", lambda: NOW)
    return tp.TravelpayoutsClient(TP_TOKEN, MARKER, TRS, "sar", transport=fake.transport, **kw)


class CalendarTests(unittest.IsolatedAsyncioTestCase):
    async def test_one_call_gives_the_cheapest_ticket_of_every_day(self):
        fake = FakeTP()
        cal = await make(fake).calendar("RUH", "IST", "2026-12")
        self.assertEqual(len(fake.price_calls()), 1)
        self.assertIn("limit=1000", fake.price_calls()[0][1])
        self.assertEqual(len(cal), 28)
        self.assertEqual(cal["2026-12-12"].price, 1100 + (12 % 3) * 50)       # the cheapest day of the fake
        self.assertEqual(min(o.price for o in cal.values()), cal["2026-12-12"].price)
        self.assertTrue(all(day.startswith("2026-12") for day in cal))

    async def test_default_calendar_skips_trips_shorter_than_three_days(self):
        fake = FakeTP()
        fake.short_deals.add(("RUH", "IST"))
        client = make(fake)
        cal = await client.calendar("RUH", "IST", "2026-12")
        offers = cal["2026-12-20"]
        self.assertGreaterEqual((date.fromisoformat(offers.return_at[:10]) - date.fromisoformat(offers.departure_at[:10])).days, 3)

    async def test_stay_window_filters_the_calendar(self):
        client = make(FakeTP())
        week = await client.calendar("RUH", "IST", "2026-12", stay=7)
        self.assertTrue(week)
        for o in week.values():
            self.assertIn((date.fromisoformat(o.return_at[:10]) - date.fromisoformat(o.departure_at[:10])).days, (6, 7, 8))
        self.assertEqual(await client.calendar("RUH", "IST", "2026-12", stay=14), {})

    async def test_weekend_calendar_only_has_thursdays_and_fridays_with_short_stays(self):
        fake = FakeTP()
        fake.weekend_deals.add(("RUH", "DXB"))
        cal = await make(fake).calendar("RUH", "DXB", "2026-12", weekend=True)
        self.assertTrue(cal)
        for day, o in cal.items():
            self.assertIn(date.fromisoformat(day).weekday(), (3, 4))
            self.assertIn(date.fromisoformat(o.return_at[:10]).weekday(), (5, 6))      # back on Saturday or Sunday
            self.assertIn((date.fromisoformat(o.return_at[:10]) - date.fromisoformat(day)).days, (2, 3))

    async def test_is_weekend_trip(self):
        def trip(dep, ret):
            return tp.Offer("RUH", "DXB", 500, "sar", "XY", dep + "T10:00:00+03:00", ret + "T10:00:00+03:00", 0, "")
        self.assertTrue(tp.is_weekend_trip(trip("2026-12-03", "2026-12-05")))     # Thursday -> Saturday
        self.assertTrue(tp.is_weekend_trip(trip("2026-12-03", "2026-12-06")))     # Thursday -> Sunday
        self.assertTrue(tp.is_weekend_trip(trip("2026-12-04", "2026-12-06")))     # Friday -> Sunday
        self.assertFalse(tp.is_weekend_trip(trip("2026-12-03", "2026-12-07")))    # back on Monday
        self.assertFalse(tp.is_weekend_trip(trip("2026-12-02", "2026-12-05")))    # leaves on a Wednesday
        self.assertFalse(tp.is_weekend_trip(trip("2026-12-04", "2026-12-05")))    # Friday -> Saturday is only one day
        self.assertFalse(tp.is_weekend_trip(trip("2026-12-03", "")))

    async def test_weekend_deals_cover_many_destinations_in_one_request_per_month(self):
        fake = FakeTP()
        fake.weekend_deals.update({("RUH", "DXB"), ("RUH", "CAI"), ("RUH", "IST")})
        client = make(fake)
        deals = await client.weekend_deals("RUH", ["2026-11", "2026-12"])
        self.assertEqual({"DXB", "CAI", "IST"} <= set(deals), True)
        self.assertEqual(len(fake.price_calls()), 2)
        for offer in deals.values():
            self.assertTrue(tp.is_weekend_trip(offer))
        self.assertTrue(all("limit=1000" in c[1] and "destination" not in c[1] for c in fake.price_calls()))

    async def test_weekend_deals_fail_only_when_every_month_fails(self):
        fake = FakeTP()
        fake.weekend_deals.add(("RUH", "DXB"))
        client = make(fake)
        fake.status = 500
        with self.assertRaises(tp.TPError):
            await client.weekend_deals("RUH", ["2026-11"])

    async def test_calendar_is_cached_and_shared_by_concurrent_callers(self):
        fake = FakeTP()
        client = make(fake)
        await asyncio.gather(*(client.calendar("RUH", "IST", "2026-12") for _ in range(5)))
        await client.calendar("RUH", "IST", "2026-12")
        self.assertEqual(len(fake.price_calls()), 1)

    async def test_raw_rows_are_not_kept_in_memory_for_calendars(self):
        client = make(FakeTP())
        await client.calendar("RUH", "IST", "2026-12")
        self.assertEqual(client._rows, 0)

    async def test_row_cache_is_capped(self):
        client = make(FakeTP())
        old = tp.MAX_CACHED_ROWS
        tp.MAX_CACHED_ROWS = 50
        try:
            for month in ("2026-11", "2026-12", "2027-01", "2027-02"):
                await client.prices(origin="RUH", month=month, unique=True, limit=100)
            self.assertLessEqual(client._rows, 50)
        finally:
            tp.MAX_CACHED_ROWS = old

    async def test_month_minimums_and_failed_months(self):
        fake = FakeTP()
        client = make(fake)
        mins = await client.month_minimums("RUH", "IST", ["2026-11", "2026-12", "2027-01"])
        self.assertEqual(sorted(mins), ["2026-11", "2026-12", "2027-01"])
        self.assertEqual(mins["2026-12"].price, 1100)
        fake.status = 500
        with self.assertRaises(tp.TPError):
            await make(fake).month_minimums("RUH", "IST", ["2027-03"])

    async def test_exact_day_is_served_from_a_cached_calendar(self):
        fake = FakeTP()
        client = make(fake)
        cal = await client.calendar("RUH", "IST", "2026-12")
        offer = cal["2026-12-12"]
        calls = len(fake.price_calls())
        got = await client.exact("RUH", "IST", "2026-12-12", offer.return_at[:10])
        self.assertEqual(got, [offer])
        self.assertEqual(len(fake.price_calls()), calls)
        await client.exact("RUH", "IST", "2026-12-12", "2026-12-30")            # a different return: ask the provider
        self.assertEqual(len(fake.price_calls()), calls + 1)

    async def test_departures_gives_the_cheapest_per_destination_for_one_pair_of_days(self):
        fake = FakeTP()
        got = await make(fake).departures("RUH", date(2026, 12, 3), date(2026, 12, 5))
        self.assertIn("DXB", got)
        self.assertIn("departure_at=2026-12-03", fake.price_calls()[0][1])
        self.assertIn("return_at=2026-12-05", fake.price_calls()[0][1])
        self.assertEqual(len(got), len({o.destination for o in got.values()}))


class WeekendLookupTests(unittest.IsolatedAsyncioTestCase):
    PLACES = ("DXB", "CAI", "IST", "AMM")

    def fake(self, places=("DXB", "CAI", "IST")) -> FakeTP:
        fake = FakeTP()
        fake.stays = (7, 10)                                  # no weekend trips except the ones listed below
        fake.weekend_deals.update({("RUH", d) for d in places})
        return fake

    async def test_places_are_asked_about_one_by_one_when_the_big_answer_is_crowded_out(self):
        fake = self.fake()
        fake.crowd = 2500                                     # cheap flights inside the country fill the thousand rows
        client = make(fake)
        alone = await client.weekend_deals("RUH", ["2026-11", "2026-12"])
        self.assertEqual(alone, {})                           # the big request alone finds nothing
        client = make(fake)
        deals = await client.weekend_deals("RUH", ["2026-11", "2026-12"], extra=self.PLACES)
        self.assertEqual(set(deals), {"DXB", "CAI", "IST"})   # AMM has no weekend trip in the fake
        self.assertTrue(all(tp.is_weekend_trip(o) for o in deals.values()))

    async def test_each_place_costs_one_request_per_month_and_is_remembered(self):
        fake = self.fake()
        client = make(fake)
        await client.weekend_deals("RUH", ["2026-11", "2026-12"], extra=self.PLACES)
        self.assertEqual(len(fake.price_calls()), 2 + len(self.PLACES) * 2)     # the big requests + every place and month
        await client.weekend_deals("RUH", ["2026-11", "2026-12"], extra=self.PLACES)
        self.assertEqual(len(fake.price_calls()), 2 + len(self.PLACES) * 2 + 2)   # only the big ones are repeated

    async def test_the_origin_is_never_asked_about_itself(self):
        fake = self.fake()
        await make(fake).weekend_deals("RUH", ["2026-11"], extra=("RUH", "DXB"))
        self.assertEqual(sum("destination=RUH" in c[1] for c in fake.price_calls()), 0)

    async def test_only_known_places_are_kept(self):
        fake = self.fake()
        deals = await make(fake).weekend_deals("RUH", ["2026-11"], extra=self.PLACES, known={"DXB", "IST"})
        self.assertEqual(set(deals), {"DXB", "IST"})

    async def test_the_same_place_in_two_months_gives_the_cheaper_trip(self):
        fake = self.fake(("DXB",))
        deals = await make(fake).weekend_deals("RUH", ["2026-11", "2026-12"], extra=("DXB",))
        november = await make(fake).weekend_deals("RUH", ["2026-11"], extra=("DXB",))
        december = await make(fake).weekend_deals("RUH", ["2026-12"], extra=("DXB",))
        self.assertEqual(deals["DXB"].price, min(november["DXB"].price, december["DXB"].price))

    async def test_trips_before_the_earliest_day_are_left_out(self):
        fake = self.fake(("DXB",))
        deals = await make(fake).weekend_deals("RUH", ["2026-11"], earliest="2026-11-20", extra=("DXB",))
        self.assertTrue(deals)
        self.assertTrue(all(o.departure_at[:10] >= "2026-11-20" for o in deals.values()))

    async def test_a_slow_part_does_not_hold_the_answer_and_finishes_in_the_background(self):
        fake = self.fake()
        fake.crowd = 2500                                     # so the big request cannot find them first
        fake.slow[("RUH", "CAI")] = 0.4                       # the provider is slow for one place
        client = make(fake)
        started = time.monotonic()
        deals = await client.weekend_deals("RUH", ["2026-11"], extra=self.PLACES, budget=0.1)
        self.assertLess(time.monotonic() - started, 0.35)
        self.assertEqual(set(deals), {"DXB", "IST"})          # what had arrived
        self.assertEqual(client.weekend_pending, 1)
        await asyncio.sleep(0.6)                              # ... the slow one lands in the cache meanwhile
        calls = len(fake.price_calls())
        deals = await client.weekend_deals("RUH", ["2026-11"], extra=self.PLACES, budget=0.1)
        self.assertEqual(set(deals), {"DXB", "CAI", "IST"})
        self.assertEqual(client.weekend_pending, 0)
        self.assertEqual(len(fake.price_calls()), calls + 1)  # only the big request was asked again

    async def test_nothing_ready_in_time_is_reported_as_still_loading(self):
        fake = self.fake()
        for place in self.PLACES:
            fake.slow[("RUH", place)] = 0.3
        fake.slow[("RUH", None)] = 0.3
        with self.assertRaises(tp.TPError) as caught:
            await make(fake).weekend_deals("RUH", ["2026-11"], extra=self.PLACES, budget=0.05)
        self.assertIn("still loading", str(caught.exception))
        await asyncio.sleep(0.5)                              # let the background work end before the loop closes

    async def test_it_fails_only_when_everything_fails(self):
        fake = self.fake()
        fake.status = 500
        with self.assertRaises(tp.TPError):
            await make(fake).weekend_deals("RUH", ["2026-11"], extra=self.PLACES)

    async def test_one_failing_place_does_not_spoil_the_rest(self):
        fake = self.fake()
        real = fake._prices

        def flaky(params):
            if params.get("destination") == "CAI":
                return 500, b"{}"
            return real(params)

        fake._prices = flaky
        deals = await make(fake).weekend_deals("RUH", ["2026-11"], extra=self.PLACES)
        self.assertTrue({"DXB", "IST"} <= set(deals))

    async def test_no_months_means_no_trips(self):
        self.assertEqual(await make(self.fake()).weekend_deals("RUH", [], extra=self.PLACES), {})


class GzipTests(unittest.TestCase):
    def test_gzip_answers_are_decoded_and_size_is_limited(self):
        class Resp:
            def __init__(self, body, enc):
                self._body, self.headers = body, {"Content-Encoding": enc}

            def read(self, n=-1):
                return self._body[:n] if n >= 0 else self._body

        payload = json.dumps({"data": ["x" * 100] * 10}).encode()
        self.assertEqual(tp._read_body(Resp(gzip.compress(payload), "gzip")), payload)
        self.assertEqual(tp._read_body(Resp(payload, "")), payload)
        old = tp.MAX_BODY
        tp.MAX_BODY = 100
        try:
            with self.assertRaises(tp.TPError):
                tp._read_body(Resp(gzip.compress(payload), "gzip"))
            with self.assertRaises(tp.TPError):
                tp._read_body(Resp(b"x" * 500, ""))
        finally:
            tp.MAX_BODY = old


if __name__ == "__main__":
    unittest.main()
