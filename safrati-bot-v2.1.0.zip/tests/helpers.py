import re
from html.parser import HTMLParser

ALLOWED_TAGS = {"b", "i", "u", "s", "code", "pre", "a", "em", "strong"}
_ENTITY = re.compile(r"&(?!(?:amp|lt|gt|quot|#\d+|#x[0-9a-fA-F]+);)")


class _Check(HTMLParser):
    def __init__(self):
        super().__init__()
        self.stack: list[str] = []
        self.errors: list[str] = []

    def handle_starttag(self, tag, attrs):
        if tag not in ALLOWED_TAGS:
            self.errors.append(f"tag not allowed by Telegram: {tag}")
        self.stack.append(tag)

    def handle_endtag(self, tag):
        if not self.stack or self.stack.pop() != tag:
            self.errors.append(f"unbalanced </{tag}>")


def html_errors(text: str) -> list[str]:
    parser = _Check()
    parser.feed(text)
    parser.close()
    errors = list(parser.errors)
    if parser.stack:
        errors.append(f"unclosed: {parser.stack}")
    if _ENTITY.search(text):
        errors.append("raw ampersand")
    return errors
