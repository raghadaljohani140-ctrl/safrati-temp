import unittest
from datetime import date

from safrati.db import DB, saudi_today


class DBTests(unittest.TestCase):
    def setUp(self):
        self.db = DB(":memory:")
        self.addCleanup(self.db.close)

    def test_user_defaults_and_updates(self):
        row = self.db.touch_user(1)
        self.assertEqual(row["origin"], "RUH")
        self.assertEqual(row["visa_only"], 0)
        self.db.set_origin(1, "JED")
        self.db.set_visa_only(1, True)
        row = self.db.touch_user(1)
        self.assertEqual((row["origin"], row["visa_only"]), ("JED", 1))
        with self.assertRaises(ValueError):
            self.db.set_origin(1, "XXX")

    def test_saved(self):
        self.db.save(1, "IST")
        self.db.save(1, "IST")
        self.db.save(1, "DXB")
        self.assertTrue(self.db.is_saved(1, "IST"))
        self.assertEqual(sorted(self.db.saved_list(1)), ["DXB", "IST"])
        self.db.unsave(1, "IST")
        self.assertFalse(self.db.is_saved(1, "IST"))
        self.assertEqual(self.db.saved_list(2), [])

    def test_seen(self):
        self.db.mark_seen(1, "IST")
        self.db.mark_seen(1, "IST")
        self.assertEqual(self.db.seen_set(1), {"IST"})
        self.db.clear_seen(1)
        self.assertEqual(self.db.seen_set(1), set())

    def test_daily_limit(self):
        day = date(2026, 10, 26)
        self.assertTrue(self.db.use_search(1, 2, day))
        self.assertTrue(self.db.use_search(1, 2, day))
        self.assertFalse(self.db.use_search(1, 2, day))
        self.assertTrue(self.db.use_search(2, 2, day))             # other user unaffected
        self.assertTrue(self.db.use_search(1, 2, date(2026, 10, 27)))  # next day resets

    def test_old_usage_is_pruned(self):
        self.db.use_search(1, 5, date(2026, 10, 1))
        self.db.use_search(1, 5, date(2026, 10, 26))
        rows = self.db._con.execute("SELECT day FROM usage").fetchall()
        self.assertEqual([r["day"] for r in rows], ["2026-10-26"])

    def test_admin_and_kv(self):
        self.assertFalse(self.db.is_admin(1))
        self.db.add_admin(1)
        self.assertTrue(self.db.is_admin(1))
        self.assertEqual(self.db.admin_count(), 1)
        self.assertIsNone(self.db.kv_get("x"))
        self.db.kv_set("x", "1")
        self.db.kv_set("x", "2")
        self.assertEqual(self.db.kv_get("x"), "2")

    def test_stats(self):
        self.db.touch_user(1)
        self.db.touch_user(2)
        self.db.save(1, "IST")
        self.db.use_search(1, 5, saudi_today())
        stats = self.db.stats()
        self.assertEqual((stats["users"], stats["saved"], stats["searches_today"]), (2, 1, 1))

    def test_database_holds_nothing_but_ids_and_settings(self):
        tables = {r["name"] for r in self.db._con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        columns = set()
        for t in tables:
            columns |= {r["name"] for r in self.db._con.execute(f"PRAGMA table_info({t})")}
        for forbidden in ("name", "username", "phone", "email", "text", "message", "first_name"):
            self.assertNotIn(forbidden, columns)


class WatchTests(unittest.TestCase):
    def setUp(self):
        self.db = DB(":memory:")
        self.addCleanup(self.db.close)

    def test_add_is_idempotent_per_route_scope_and_stay(self):
        a, created = self.db.add_watch(1, "RUH", "IST", "any", 0, 1100, "2027-01-30")
        b, again = self.db.add_watch(1, "RUH", "IST", "any", 0, 900, "2027-02-28")
        self.assertTrue(created)
        self.assertFalse(again)
        self.assertEqual(a, b)
        self.assertEqual(self.db.get_watch(a)["base"], 1100)          # the first price is kept
        c, created = self.db.add_watch(1, "RUH", "IST", "any", 7, 1100, "2027-01-30")
        self.assertTrue(created)
        self.assertNotEqual(a, c)
        self.assertEqual(self.db.watch_count(1), 2)
        self.assertEqual(self.db.watch_count(2), 0)

    def test_a_person_only_reaches_their_own_watches(self):
        wid, _ = self.db.add_watch(1, "RUH", "DXB", "m:2026-12", 0, 700, "2026-12-31")
        self.assertIsNone(self.db.get_watch(wid, 2))
        self.assertFalse(self.db.delete_watch(wid, 2))
        self.assertFalse(self.db.set_watch_target(wid, 2, 500))
        self.assertTrue(self.db.set_watch_target(wid, 1, 500))
        self.assertEqual(self.db.get_watch(wid, 1)["target"], 500)
        self.assertTrue(self.db.delete_watch(wid, 1))
        self.assertEqual(self.db.watches_of(1), [])

    def test_due_watches_oldest_first_and_record_check(self):
        t1, t2, t3 = "2026-01-01T00:00:00+00:00", "2026-01-02T00:00:00+00:00", "2026-01-03T00:00:00+00:00"
        first, _ = self.db.add_watch(1, "RUH", "IST", "any", 0, 1000, "2027-01-30", at=t1)
        second, _ = self.db.add_watch(1, "RUH", "DXB", "any", 0, 700, "2027-01-30", at=t2)
        self.assertEqual([w["id"] for w in self.db.due_watches("9999-01-01", 10)], [first, second])
        self.assertEqual([w["id"] for w in self.db.due_watches(t2, 10)], [first])      # checked before t2
        self.assertEqual(self.db.due_watches(t1, 10), [])                              # nothing is older than t1
        self.db.record_check(first, price=950, day="2026-12-12", base=None, notified=None, at=t3)
        row = self.db.get_watch(first)
        self.assertEqual((row["last_price"], row["last_day"], row["base"], row["notified"]), (950, "2026-12-12", 1000, None))
        self.assertEqual(row["checked_at"], t3)
        self.assertEqual([w["id"] for w in self.db.due_watches("9999-01-01", 10)], [second, first])
        self.assertEqual(len(self.db.due_watches("9999-01-01", 1)), 1)                 # the limit holds
        self.db.record_check(first, price=None, day=None, base=950, notified=950)
        row = self.db.get_watch(first)
        self.assertEqual((row["last_price"], row["base"], row["notified"]), (950, 950, 950))

    def test_target_resets_the_last_notice(self):
        wid, _ = self.db.add_watch(1, "RUH", "IST", "any", 0, 1000, "2027-01-30")
        self.db.record_check(wid, price=900, day=None, base=None, notified=900)
        self.db.set_watch_target(wid, 1, 800)
        self.assertIsNone(self.db.get_watch(wid)["notified"])

    def test_expired_and_blocked_users(self):
        self.db.add_watch(1, "RUH", "IST", "e:2026-11-01:2026-11-08", 0, 1000, "2026-11-01")
        self.db.add_watch(1, "RUH", "DXB", "any", 0, 700, "2027-01-30")
        self.db.add_watch(2, "RUH", "DXB", "any", 0, 700, "2027-01-30")
        self.assertEqual(self.db.purge_watches(date(2026, 11, 2)), 1)
        self.assertEqual(self.db.purge_watches(date(2026, 11, 1)), 0)
        self.assertEqual(self.db.drop_user_watches(1), 1)
        self.assertEqual(self.db.watch_count(2), 1)

    def test_popularity_counter_and_kv_incr(self):
        for iata in ("IST", "DXB", "IST"):
            self.db.bump_popular(iata)
        self.assertEqual(self.db.top_popular(5), [("IST", 2), ("DXB", 1)])
        self.assertEqual(self.db.kv_incr("alerts_sent"), 1)
        self.assertEqual(self.db.kv_incr("alerts_sent", 4), 5)
        self.db.kv_set("alerts_sent", "oops")
        self.assertEqual(self.db.kv_incr("alerts_sent"), 1)

    def test_stats_count_watches_and_new_users(self):
        self.db.touch_user(1)
        self.db.add_watch(1, "RUH", "IST", "any", 0, 1000, "2027-01-30")
        self.db.add_watch(1, "RUH", "DXB", "any", 0, 700, "2027-01-30")
        stats = self.db.stats()
        self.assertEqual((stats["watches"], stats["watchers"], stats["new_24h"]), (2, 1, 1))

    def test_active_and_new_users_are_counted_over_a_true_24_hours(self):
        from datetime import datetime, timedelta, timezone
        now = datetime(2026, 10, 26, 12, 0, 0, tzinfo=timezone.utc)

        def stamp(hours_ago):
            return (now - timedelta(hours=hours_ago)).isoformat(timespec="seconds")

        for uid, seen_hours_ago, created_hours_ago in ((1, 2, 2), (2, 23, 100), (3, 25, 100), (4, 40, 100), (5, 0.5, 0.5)):
            self.db.touch_user(uid)
            self.db._con.execute(
                "UPDATE users SET last_seen=?, created_at=? WHERE tg_id=?", (stamp(seen_hours_ago), stamp(created_hours_ago), uid)
            )
        stats = self.db.stats(now=now)
        self.assertEqual(stats["users"], 5)
        self.assertEqual(stats["active_24h"], 3)               # 2, 23 and 0.5 hours ago; not 25 or 40
        self.assertEqual(stats["new_24h"], 2)                  # joined 2 and 0.5 hours ago


class MigrationTests(unittest.TestCase):
    def test_old_database_gets_the_onboarding_column_and_old_users_count_as_onboarded(self):
        import os
        import sqlite3
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "old.db")
            con = sqlite3.connect(path)
            con.executescript(
                "CREATE TABLE users(tg_id INTEGER PRIMARY KEY, origin TEXT NOT NULL DEFAULT 'RUH', "
                "visa_only INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, last_seen TEXT NOT NULL);"
                "INSERT INTO users(tg_id, created_at, last_seen) VALUES(7, '2026-01-01', '2026-01-01');"
            )
            con.commit()
            con.close()
            db = DB(path)
            self.assertEqual(db.touch_user(7)["onboarded"], 1)
            self.assertEqual(db.touch_user(8)["onboarded"], 0)
            db.set_onboarded(8)
            self.assertEqual(db.touch_user(8)["onboarded"], 1)
            db.close()
            db = DB(path)                       # opening it again changes nothing
            self.assertEqual(db.touch_user(8)["onboarded"], 1)
            db.close()

    def test_backup_is_a_readable_copy(self):
        import os
        import tempfile
        db = DB(":memory:")
        db.touch_user(5)
        db.save(5, "IST")
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "copy.db")
            db.backup_to(path)
            copy = DB(path)
            self.assertEqual(copy.saved_list(5), ["IST"])
            copy.close()
        db.close()


if __name__ == "__main__":
    unittest.main()
