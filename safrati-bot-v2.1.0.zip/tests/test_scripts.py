"""Runs install.sh / web.sh / status.sh / uninstall.sh against fake docker and curl programs.

The real scripts only work inside /opt/safrati-bot, so the tests copy them to a temporary folder and
change only the APP_DIR line. The guard itself is tested on the untouched copy.
"""
import os
import re
import shutil
import stat
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
GOOD_BOT = "123456789:" + "ABCDEFGHIJ" * 3 + "KLMNO"
GOOD_TP = "tp" + "0123456789abcdef" * 2

FAKE_DOCKER = r"""#!/usr/bin/env bash
echo "docker $*" >> "$FAKE_LOG"
case "$1 $2" in
  "compose version") echo "Docker Compose version v2.0.0"; exit 0 ;;
esac
if [ "$1" = "logs" ]; then
  target="${@: -1}"
  case "$target" in
    safrati-bot)
      [ "${FAKE_NO_START:-0}" = 1 ] || echo "2026-10-26 INFO safrati: started as @SafratiTravel_bot | prices=on partner_links=on"
      [ "${FAKE_BIG_LOGS:-0}" = 1 ] && for i in $(seq 1 20000); do echo "filler log line number $i to make the output large"; done ;;
    safrati-web)
      [ "${FAKE_NO_WEB:-0}" = 1 ] || echo "2026-10-27 INFO safrati.web: website started on port 8088 | prices=on partner_links=on market=auto" ;;
    safrati-tunnel)
      echo "INF Requesting new quick Tunnel on trycloudflare.com..."
      echo "ERR failed to request quick Tunnel: Post \"https://api.trycloudflare.com/tunnel\": EOF"
      [ "${FAKE_NO_URL:-0}" = 1 ] || echo "INF |  https://quiet-river-1234.trycloudflare.com  |" ;;
    safrati-domain)
      if [ "${FAKE_BAD_TUNNEL:-0}" = 1 ]; then echo "ERR Provided Tunnel token is not valid."; else echo "INF Registered tunnel connection connIndex=0"; fi ;;
    *) echo "WRONG CONTAINER $target" >&2; exit 9 ;;
  esac
  exit 0
fi
if [ "$1" = "compose" ] && [ "$2" = "-p" ]; then
  [ "$3" = "safrati" ] || { echo "WRONG PROJECT $3" >&2; exit 9; }
  shift 3
  while [ "$1" = "--profile" ]; do
    case "$2" in web|quick|domain) ;; *) echo "UNKNOWN PROFILE $2" >&2; exit 9 ;; esac
    shift 2
  done
  case "$1" in
    ps) echo "NAME  STATUS"; echo "safrati-bot  running" ;;
    up|down|rm) ;;
    *) echo "UNEXPECTED compose command: $*" >&2; exit 9 ;;
  esac
  exit 0
fi
if [ "$1" = "rmi" ]; then
  [ "$2" = "safrati-bot:local" ] || { echo "WRONG IMAGE $2" >&2; exit 9; }
  exit 0
fi
echo "UNEXPECTED docker call: $*" >&2
exit 9
"""

FAKE_CURL = r"""#!/usr/bin/env bash
cfg="$(cat)"
echo "curl $*" >> "$FAKE_LOG"
case "$cfg" in
  *api.telegram.org*)
    if [ "${FAKE_BAD_TG:-0}" = always ]; then echo '{"ok":false,"error_code":401}'; exit 0; fi
    if [ "${FAKE_BAD_TG:-0}" = 1 ] && [ ! -f "$FAKE_STATE/tg_retry" ]; then touch "$FAKE_STATE/tg_retry"; echo '{"ok":false,"error_code":401}'; exit 0; fi
    echo '{"ok":true,"result":{"id":1,"is_bot":true,"username":"SafratiTravel_bot"}}' ;;
  *api.travelpayouts.com*) printf '%s' "${FAKE_TP_CODE:-200}" ;;
  *trycloudflare.com/healthz*|*flights.example.com/healthz*) [ "${FAKE_PUBLIC:-1}" = 0 ] || printf ok ;;
esac
"""


class ScriptCase(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.app = self.tmp / "app"
        self.app.mkdir()
        self.bin = self.tmp / "bin"
        self.bin.mkdir()
        self.state = self.tmp / "state"
        self.state.mkdir()
        self.log = self.tmp / "calls.log"
        self.log.write_text("")
        self.meminfo = self.tmp / "meminfo"
        self.set_memory(2_000_000)
        for name, body in (("docker", FAKE_DOCKER), ("curl", FAKE_CURL), ("sleep", "#!/bin/sh\nexit 0\n")):
            path = self.bin / name
            path.write_text(body)
            path.chmod(path.stat().st_mode | stat.S_IEXEC)
        for name in ("install.sh", "web.sh", "status.sh", "uninstall.sh"):
            text = (ROOT / name).read_text()
            text = text.replace('APP_DIR="/opt/safrati-bot"', f'APP_DIR="{self.app}"')
            text = text.replace('= "/opt/safrati-bot" ]', f'= "{self.app}" ]').replace("cd /opt/safrati-bot", f"cd {self.app}")
            (self.app / name).write_text(text)

    def run_script(self, args, stdin="", env_extra=None, cwd=None, script_dir=None):
        env = dict(os.environ)
        env.update({"PATH": f"{self.bin}:{env['PATH']}", "FAKE_LOG": str(self.log), "FAKE_STATE": str(self.state),
                    "SAFRATI_MEMINFO": str(self.meminfo)})
        env.update(env_extra or {})
        return subprocess.run(
            ["bash", *args], input=stdin, capture_output=True, text=True, env=env,
            cwd=cwd or script_dir or self.app, timeout=60,
        )

    def set_memory(self, kb: int) -> None:
        self.meminfo.write_text(f"MemTotal:        4000000 kB\nMemFree:          100000 kB\nMemAvailable:   {kb:>8} kB\n")

    def calls(self) -> list[str]:
        return [line for line in self.log.read_text().splitlines()]

    def answers(self, bot=GOOD_BOT, tp=GOOD_TP, marker="123456", trs="654321", channel="", confirm=True):
        """What a person types on a first install: 'y' for the right-server question, then the five settings."""
        return ("y\n" if confirm else "") + "\n".join([bot, tp, marker, trs, channel]) + "\n"


class InstallTests(ScriptCase):
    def test_real_scripts_are_pinned_to_the_bot_folder_and_project(self):
        install = (ROOT / "install.sh").read_text()
        self.assertIn('APP_DIR="/opt/safrati-bot"', install)
        self.assertIn('PROJECT="safrati"', install)
        for name in ("install.sh", "web.sh", "status.sh", "uninstall.sh"):
            text = (ROOT / name).read_text()
            for call in re.findall(r"docker compose[^\n]*", text):
                if call.startswith("docker compose version"):
                    continue
                self.assertTrue("-p safrati" in call or '-p "$PROJECT"' in call, f"{name}: {call}")

    def test_refuses_to_run_outside_the_bot_folder_and_changes_nothing(self):
        other = self.tmp / "elsewhere"
        other.mkdir()
        shutil.copy(ROOT / "install.sh", other / "install.sh")
        result = self.run_script([str(other / "install.sh")], cwd=other)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("/opt/safrati-bot", result.stderr)
        self.assertEqual(sorted(p.name for p in other.iterdir()), ["install.sh"])
        self.assertEqual(self.calls(), [])

    def test_first_install_creates_private_env_and_starts_only_this_project(self):
        result = self.run_script(["install.sh"], stdin=self.answers())
        out = result.stdout + result.stderr
        self.assertEqual(result.returncode, 0, out)
        env_file = self.app / ".env"
        self.assertEqual(stat.S_IMODE(env_file.stat().st_mode), 0o600)
        values = dict(line.split("=", 1) for line in env_file.read_text().splitlines())
        self.assertEqual(values["BOT_TOKEN"], GOOD_BOT)
        self.assertEqual(values["TP_TOKEN"], GOOD_TP)
        self.assertEqual((values["TP_MARKER"], values["TP_TRS"]), ("123456", "654321"))
        self.assertEqual(values["CHANNEL_URL"], "https://t.me/safrati_travel")
        self.assertRegex(values["ADMIN_CODE"], r"^[0-9a-f]{16}$")
        # secrets are never echoed
        self.assertNotIn(GOOD_BOT, out)
        self.assertNotIn(GOOD_TP, out)
        self.assertIn(f"/admin {values['ADMIN_CODE']}", out)
        self.assertIn("started as @SafratiTravel_bot", out)
        self.assertIn("Telegram says this is @SafratiTravel_bot", out)
        self.assertIn("Travelpayouts accepted the token", out)
        docker_calls = [c for c in self.calls() if c.startswith("docker")]
        self.assertIn("docker compose -p safrati up -d --build", docker_calls)
        for call in docker_calls:
            self.assertTrue(
                call.startswith(("docker compose version", "docker compose -p safrati ", "docker logs safrati-bot")), call
            )
            self.assertNotIn("--profile", call)             # the website is off until web.sh switches it on
        # no leftovers
        self.assertEqual([p.name for p in self.app.iterdir() if p.name.startswith(".env.") and p.name != ".env.example"], [])

    def test_wrong_server_answer_cancels_before_anything_is_saved_or_started(self):
        for reply in ("n\n", "\n", "no\n"):
            result = self.run_script(["install.sh"], stdin=reply + self.answers(confirm=False))
            self.assertNotEqual(result.returncode, 0, reply)
            self.assertIn("This server is:", result.stdout)
            self.assertIn("cancelled", result.stderr)
            self.assertFalse((self.app / ".env").exists())
            self.assertEqual([c for c in self.calls() if c != "docker compose version"], [], reply)
        closed = self.run_script(["install.sh"], stdin="")
        self.assertNotEqual(closed.returncode, 0)
        self.assertFalse((self.app / ".env").exists())

    def test_second_run_keeps_settings_and_does_not_show_the_admin_code_again(self):
        self.run_script(["install.sh"], stdin=self.answers())
        before = (self.app / ".env").read_text()
        result = self.run_script(["install.sh"], stdin="")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual((self.app / ".env").read_text(), before)
        self.assertIn("Keeping your existing settings", result.stdout)
        self.assertNotIn("/admin ", result.stdout)

    def test_bad_input_is_asked_again(self):
        stdin = "y\nnot-a-token\n" + self.answers(confirm=False)
        result = self.run_script(["install.sh"], stdin=stdin)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("does not look right", result.stdout)

    def test_telegram_rejecting_the_token_asks_again(self):
        stdin = self.answers() + self.answers(confirm=False)
        result = self.run_script(["install.sh"], stdin=stdin, env_extra={"FAKE_BAD_TG": "1"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("did not accept this token", result.stdout)
        self.assertEqual((self.app / ".env").read_text().count("BOT_TOKEN="), 1)

    def test_optional_values_can_be_skipped(self):
        result = self.run_script(["install.sh"], stdin=self.answers(tp="", marker="", trs=""))
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        text = (self.app / ".env").read_text()
        self.assertIn("TP_TOKEN=\n", text)
        self.assertIn("TP_TRS=\n", text)

    def test_travelpayouts_rejection_is_a_warning_not_a_failure(self):
        result = self.run_script(["install.sh"], stdin=self.answers(), env_extra={"FAKE_TP_CODE": "401"})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("this quick check got HTTP 401 from Travelpayouts", result.stdout)

    def test_start_detection_survives_very_long_logs(self):
        result = self.run_script(["install.sh"], stdin=self.answers(), env_extra={"FAKE_BIG_LOGS": "1"})
        self.assertEqual(result.returncode, 0, result.stdout[-500:] + result.stderr[-500:])
        self.assertIn("The bot is running", result.stdout)

    def test_gives_up_after_five_rejected_tokens(self):
        result = self.run_script(["install.sh"], stdin="y\n" + (GOOD_BOT + "\n") * 6, env_extra={"FAKE_BAD_TG": "always"})
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("5 times", result.stderr)
        self.assertFalse((self.app / ".env").exists())
        self.assertFalse([c for c in self.calls() if c.startswith("docker compose -p")])

    def test_failure_to_start_is_reported(self):
        result = self.run_script(["install.sh"], stdin=self.answers(), env_extra={"FAKE_NO_START": "1"})
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("did not report that it started", result.stdout)

    def test_set_changes_one_value_and_recreates_only_this_project(self):
        self.run_script(["install.sh"], stdin=self.answers(trs=""))
        self.log.write_text("")
        result = self.run_script(["install.sh", "set", "TP_TRS"], stdin="777888\n")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        text = (self.app / ".env").read_text()
        self.assertIn("TP_TRS=777888\n", text)
        self.assertIn(f"BOT_TOKEN={GOOD_BOT}\n", text)
        self.assertEqual(text.count("TP_TRS="), 1)
        self.assertIn("docker compose -p safrati up -d --force-recreate", self.calls())
        self.assertEqual(stat.S_IMODE((self.app / ".env").stat().st_mode), 0o600)

    def test_set_rejects_unknown_names(self):
        self.run_script(["install.sh"], stdin=self.answers())
        result = self.run_script(["install.sh", "set", "ADMIN_CODE"], stdin="x\n")
        self.assertNotEqual(result.returncode, 0)

    def test_status_and_uninstall_only_touch_this_project(self):
        self.run_script(["install.sh"], stdin=self.answers())
        self.log.write_text("")
        self.assertEqual(self.run_script(["status.sh"]).returncode, 0)
        self.assertEqual(self.run_script(["uninstall.sh"]).returncode, 0)
        self.assertEqual(self.run_script(["uninstall.sh", "--purge"]).returncode, 0)
        self.assertNotEqual(self.run_script(["uninstall.sh", "--everything"]).returncode, 0)
        calls = self.calls()
        everything = "docker compose -p safrati --profile web --profile quick --profile domain"
        self.assertIn(f"{everything} down", calls)
        self.assertIn(f"{everything} down --volumes", calls)
        self.assertIn("docker rmi safrati-bot:local", calls)
        for call in calls:
            self.assertNotIn("prune", call)
            self.assertNotIn("system", call)
            self.assertNotIn("--rmi", call)             # the public cloudflared image may belong to other projects


QUICK_URL = "https://quiet-river-1234.trycloudflare.com"
TOKEN = "eyJhIjoi" + "QWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo" * 4 + "=="           # shaped like a tunnel token, obviously fake
WEB = "docker compose -p safrati --profile web"
EVERYTHING = "docker compose -p safrati --profile web --profile quick --profile domain"


class WebScriptTests(ScriptCase):
    def setUp(self):
        super().setUp()
        self.assertEqual(self.run_script(["install.sh"], stdin=self.answers()).returncode, 0)
        self.log.write_text("")

    def env(self) -> dict:
        return dict(line.split("=", 1) for line in (self.app / ".env").read_text().splitlines())

    def quick(self, **env_extra):
        return self.run_script(["web.sh", "quick"], env_extra=env_extra)

    def domain(self, domain="Flights.Example.com", token=TOKEN, **env_extra):
        return self.run_script(["web.sh", "domain"], stdin=f"{domain}\n{token}\n", env_extra=env_extra)

    def docker_calls(self) -> list[str]:
        return [c for c in self.calls() if c.startswith("docker")]

    # ---- guards
    def test_it_refuses_to_run_outside_the_bot_folder_and_changes_nothing(self):
        other = self.tmp / "elsewhere"
        other.mkdir()
        shutil.copy(ROOT / "web.sh", other / "web.sh")
        result = self.run_script([str(other / "web.sh"), "quick"], cwd=other)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("/opt/safrati-bot", result.stderr)
        self.assertEqual(sorted(p.name for p in other.iterdir()), ["web.sh"])
        self.assertEqual(self.calls(), [])

    def test_it_needs_the_bot_installed_first(self):
        (self.app / ".env").unlink()
        for command in ("quick", "domain", "stop"):
            result = self.run_script(["web.sh", command], stdin="x\n")
            self.assertNotEqual(result.returncode, 0, command)
            self.assertIn("bash install.sh", result.stderr)
        self.assertEqual([c for c in self.docker_calls() if " up " in c], [])

    def test_unknown_commands_show_the_usage(self):
        for args in ([], ["start"], ["quick-now"]):
            result = self.run_script(["web.sh", *args])
            self.assertNotEqual(result.returncode, 0, args)
            self.assertIn("usage: bash web.sh", result.stderr)
        self.assertEqual([c for c in self.docker_calls() if " up " in c], [])

    # ---- the free temporary link
    def test_quick_starts_the_website_and_prints_the_link(self):
        result = self.quick()
        out = result.stdout + result.stderr
        self.assertEqual(result.returncode, 0, out)
        self.assertIn(QUICK_URL, out)
        self.assertNotIn("api.trycloudflare.com", out)
        self.assertIn("website started on port 8088", out)
        self.assertIn("It answers from the internet", out)
        values = self.env()
        self.assertEqual((values["SAFRATI_WEB"], values["WEB_SITE_URL"], values["BOT_TOKEN"]), ("quick", "", GOOD_BOT))
        self.assertEqual(stat.S_IMODE((self.app / ".env").stat().st_mode), 0o600)
        tunnel_file = self.app / ".tunnel.env"
        self.assertEqual((tunnel_file.read_text(), stat.S_IMODE(tunnel_file.stat().st_mode)), ("", 0o600))
        calls = self.docker_calls()
        self.assertIn(f"{WEB} --profile quick up -d --build web tunnel", calls)
        self.assertIn(f"{EVERYTHING} rm -sf tunnel-domain", calls)
        for call in calls:
            self.assertTrue(call.startswith(("docker compose -p safrati ", "docker compose version", "docker logs safrati-web", "docker logs safrati-tunnel")), call)
        for secret in (GOOD_BOT, GOOD_TP):
            self.assertNotIn(secret, out)
        self.assertEqual([p.name for p in self.app.iterdir() if p.name.startswith((".env.", ".tunnel.env.")) and p.name != ".env.example"], [])

    def test_it_will_not_squeeze_the_other_projects_on_a_server_that_is_short_of_memory(self):
        self.set_memory(150 * 1024)
        before = (self.app / ".env").read_text()
        for command, stdin in (("quick", ""), ("domain", f"flights.example.com\n{TOKEN}\n")):
            result = self.run_script(["web.sh", command], stdin=stdin)
            self.assertNotEqual(result.returncode, 0, command)
            self.assertIn("only 150 MB of memory is free", result.stderr)
            self.assertIn("Nothing was changed", result.stderr)
        self.assertEqual((self.app / ".env").read_text(), before)
        self.assertEqual((self.app / ".tunnel.env").read_text(), "")            # no token was stored either
        self.assertEqual([c for c in self.docker_calls() if " up " in c], [])
        self.set_memory(210 * 1024)
        self.assertEqual(self.quick().returncode, 0)

    def test_the_memory_check_never_blocks_when_it_cannot_tell_or_when_the_website_already_runs(self):
        self.meminfo.write_text("garbage\n")
        self.assertEqual(self.quick().returncode, 0)
        self.meminfo.unlink()
        self.assertEqual(self.quick().returncode, 0)
        self.set_memory(50 * 1024)                  # low now, but the website is what is using it
        again = self.quick()
        self.assertEqual(again.returncode, 0, again.stdout + again.stderr)
        self.assertNotIn("Free memory", again.stdout)

    def test_quick_says_so_when_the_link_does_not_answer_yet(self):
        result = self.quick(FAKE_PUBLIC="0")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn(QUICK_URL, result.stdout)
        self.assertIn("does not answer yet", result.stdout)

    def test_quick_shows_the_tunnel_log_when_no_link_appears(self):
        result = self.quick(FAKE_NO_URL="1")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("did not show a link", result.stdout)
        self.assertIn("docker logs --tail 20 safrati-tunnel", self.calls())

    def test_quick_stops_there_when_the_website_does_not_start(self):
        result = self.quick(FAKE_NO_WEB="1")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("did not report that it started", result.stdout)
        self.assertNotIn("docker logs safrati-tunnel", self.calls())

    def test_quick_warns_about_missing_prices_but_still_starts(self):
        text = "\n".join(line for line in (self.app / ".env").read_text().splitlines() if not line.startswith("TP_TOKEN=")) + "\nTP_TOKEN=\n"
        (self.app / ".env").write_text(text)
        result = self.quick()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("TP_TOKEN is empty", result.stdout)

    def test_link_and_status(self):
        off = self.run_script(["web.sh", "link"])
        self.assertEqual(off.returncode, 0)
        self.assertIn("The website is off", off.stdout)
        self.assertIn("Website: off", self.run_script(["web.sh", "status"]).stdout)
        self.quick()
        self.log.write_text("")
        self.assertEqual(self.run_script(["web.sh", "link"]).stdout.strip(), QUICK_URL)
        status = self.run_script(["web.sh", "status"])
        self.assertEqual(status.returncode, 0, status.stderr)
        self.assertIn("Website: quick", status.stdout)
        self.assertIn(QUICK_URL, status.stdout)
        self.assertIn(f"{WEB} --profile quick ps", self.calls())
        overall = self.run_script(["status.sh"])
        self.assertEqual(overall.returncode, 0, overall.stderr)
        self.assertIn(QUICK_URL, overall.stdout)
        self.assertIn("website started on port", overall.stdout)

    # ---- updates keep the website
    def test_updating_the_bot_keeps_the_website_running(self):
        self.quick()
        self.log.write_text("")
        result = self.run_script(["install.sh"])
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn(f"{WEB} --profile quick up -d --build", self.calls())
        self.assertIn(f"{WEB} --profile quick ps", self.calls())
        self.assertIn("website is switched on too (mode: quick)", result.stdout)
        self.log.write_text("")
        result = self.run_script(["install.sh", "set", "TP_TRS"], stdin="777888\n")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn(f"{WEB} --profile quick up -d --force-recreate bot web", self.calls())      # the tunnel (and its link) is left alone

    def test_stop_switches_the_website_off_for_good(self):
        self.quick()
        self.log.write_text("")
        result = self.run_script(["web.sh", "stop"])
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn(f"{EVERYTHING} rm -sf web tunnel tunnel-domain", self.calls())
        self.assertEqual(self.env()["SAFRATI_WEB"], "off")
        self.assertIn("The bot keeps running", result.stdout)
        self.log.write_text("")
        self.assertEqual(self.run_script(["install.sh"]).returncode, 0)
        self.assertIn("docker compose -p safrati up -d --build", self.calls())          # no website parts any more
        self.assertFalse([c for c in self.calls() if "--profile" in c])

    # ---- your own domain
    def test_domain_connects_the_tunnel_and_keeps_the_token_private(self):
        result = self.domain(domain="https://Flights.Example.com/")
        out = result.stdout + result.stderr
        self.assertEqual(result.returncode, 0, out)
        self.assertIn("Website address:  https://flights.example.com", out)
        self.assertIn("The tunnel is connected", out)
        self.assertIn("It answers from the internet", out)
        self.assertNotIn(TOKEN, out)
        tunnel_file = self.app / ".tunnel.env"
        self.assertEqual((tunnel_file.read_text(), stat.S_IMODE(tunnel_file.stat().st_mode)), (f"TUNNEL_TOKEN={TOKEN}\n", 0o600))
        values = self.env()
        self.assertEqual((values["SAFRATI_WEB"], values["WEB_SITE_URL"]), ("domain", "https://flights.example.com"))
        self.assertNotIn(TOKEN, (self.app / ".env").read_text())            # the bot's own settings file never holds it
        calls = self.docker_calls()
        self.assertIn(f"{WEB} --profile domain up -d --build web tunnel-domain", calls)
        self.assertIn(f"{EVERYTHING} rm -sf tunnel", calls)
        for call in calls:
            self.assertNotIn(TOKEN, call)
        self.assertEqual(self.run_script(["web.sh", "link"]).stdout.strip(), "https://flights.example.com")

    def test_domain_asks_again_for_a_wrong_name_or_token_and_gives_up_after_five(self):
        result = self.run_script(["web.sh", "domain"], stdin=f"not a domain\nexample\nflights.example.com\nshort\n{TOKEN}\n")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("does not look right", result.stdout)
        self.assertEqual(self.env()["WEB_SITE_URL"], "https://flights.example.com")
        before = (self.app / ".env").read_text()
        self.log.write_text("")
        gave_up = self.run_script(["web.sh", "domain"], stdin="x\n" * 6)
        self.assertNotEqual(gave_up.returncode, 0)
        self.assertIn("5 times", gave_up.stderr)
        self.assertEqual((self.app / ".env").read_text(), before)
        self.assertEqual([c for c in self.docker_calls() if " up " in c], [])

    def test_domain_reports_a_tunnel_that_does_not_connect(self):
        result = self.domain(FAKE_BAD_TUNNEL="1")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("did not connect", result.stdout)
        self.assertIn("Provided Tunnel token is not valid", result.stdout)
        self.assertNotIn(TOKEN, result.stdout + result.stderr)

    def test_domain_may_need_a_few_minutes_before_it_answers(self):
        result = self.domain(FAKE_PUBLIC="0")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("does not answer yet", result.stdout)

    def test_going_back_and_forth_between_the_two_modes(self):
        self.assertEqual(self.domain().returncode, 0)
        self.log.write_text("")
        result = self.quick()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        values = self.env()
        self.assertEqual((values["SAFRATI_WEB"], values["WEB_SITE_URL"]), ("quick", ""))           # a temporary link is never presented as the real address
        self.assertIn(f"{EVERYTHING} rm -sf tunnel-domain", self.calls())
        self.assertEqual(self.run_script(["web.sh", "link"]).stdout.strip(), QUICK_URL)


if __name__ == "__main__":
    unittest.main()
