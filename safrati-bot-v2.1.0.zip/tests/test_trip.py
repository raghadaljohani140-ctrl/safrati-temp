import re

from safrati import data
from tests.helpers import html_errors
from tests.test_app import AppCase


def all_callbacks(app, msg):
    return [b["callback_data"] for b in app.tg.buttons(msg) if "callback_data" in b]


class TripTests(AppCase):
    def last(self):
        """The newest message shown, whether it was sent or edited in place."""
        shown = [p for m, p in self.tg.calls if m in ("sendMessage", "editMessageText")]
        return shown[-1]

    async def test_destination_alone_lists_cheapest_days(self):
        await self.say(1, "اسطنبول")
        msg = self.last()
        self.assertIn("أرخص الأيام", msg["text"])
        self.assertGreaterEqual(len(re.findall(r"^\d\. 📅", msg["text"], re.M)), 2)
        self.assertEqual(html_errors(msg["text"]), [])
        self.assertIn("dp:IST", all_callbacks(self, msg))
        self.assertLessEqual(len(self.url_buttons(msg)), 3)
        for cb in all_callbacks(self, msg):
            self.assertLessEqual(len(cb.encode()), 64)

    async def test_exact_dates_in_text(self):
        await self.say(1, "دبي 15/12 - 22/12")
        msg = self.last()
        self.assertIn("15 ديسمبر ← 22 ديسمبر", msg["text"])
        self.assertNotIn("ما لقيت سعرًا", msg["text"])
        exact = [c for c in self.fake.price_calls() if "departure_at=2026-12-15" in c[1]]
        self.assertEqual(len(exact), 1)
        self.assertIn("return_at=2026-12-22", exact[0][1])

    async def test_exact_miss_falls_back_to_the_month(self):
        self.fake.exact_missing.add("2026-12-15")
        await self.say(1, "دبي 15/12")
        msg = self.last()
        self.assertIn("ما لقيت سعرًا محفوظًا لهذا اليوم", msg["text"])
        self.assertIn("ديسمبر", msg["text"])
        self.assertTrue(self.url_buttons(msg))

    async def test_month_only(self):
        await self.say(1, "لندن ديسمبر")
        msg = self.last()
        self.assertIn("شهر ديسمبر 2026", msg["text"])
        self.assertTrue(all("2026-12" in c[1] for c in self.fake.price_calls() if "departure_at" in c[1]))

    async def test_one_way_sends_one_way_flag(self):
        await self.say(1, "دبي 15/12 ذهاب فقط")
        call = self.fake.price_calls()[-1]
        self.assertIn("one_way=true", call[1])
        self.assertNotIn("return_at", call[1])
        self.assertIn("ذهاب فقط", self.last()["text"])

    async def test_past_and_far_dates_are_refused_without_a_search(self):
        for text, word in (("دبي 20/10/2026", "فات"), ("دبي 1/1/2029", "بعيد")):
            before = len(self.fake.price_calls())
            await self.say(1, text)
            self.assertIn(word, self.last()["text"])
            self.assertEqual(len(self.fake.price_calls()), before, text)

    async def test_dates_alone_use_the_last_destination(self):
        await self.say(1, "اسطنبول")
        await self.say(1, "20/12")
        self.assertIn("سطنبول", self.last()["text"])
        self.assertIn("20 ديسمبر", self.last()["text"])

    async def test_dates_alone_without_destination_ask_where(self):
        await self.say(1, "20/12")
        self.assertIn("إلى أين", self.last()["text"])

    async def test_bare_city_sets_origin(self):
        await self.say(1, "المدينة المنورة")
        self.assertIn("المدينة المنورة", self.last()["text"])
        self.assertEqual(self.db.touch_user(1)["origin"], "MED")
        await self.say(1, "دبي")
        self.assertTrue(all("origin=MED" in c[1] for c in self.fake.price_calls()[-3:]))

    async def test_picker_chain_month_day_length(self):
        await self.tap(1, "dp:IST")
        self.assertIn("اختر شهر السفر", self.last()["text"])
        months = [c for c in all_callbacks(self, self.last()) if c.startswith("dm:IST:")]
        self.assertTrue(months)
        await self.tap(1, "dm:IST:202612")
        days = [c for c in all_callbacks(self, self.last()) if c.startswith("dd:IST:")]
        self.assertIn("dd:IST:20261215", days)
        await self.tap(1, "dd:IST:20261215")
        lengths = [c for c in all_callbacks(self, self.last()) if c.startswith("dr:IST:20261215:")]
        self.assertEqual(len(lengths), 6)
        self.tg.reset()
        await self.tap(1, "dr:IST:20261215:7")
        msg = self.last()
        self.assertIn("15 ديسمبر ← 22 ديسمبر", msg["text"])

    async def test_picker_past_days_are_not_clickable(self):
        await self.tap(1, "dm:IST:202610")
        cbs = all_callbacks(self, self.last())
        self.assertNotIn("dd:IST:20261026", cbs)
        self.assertIn("dd:IST:20261027", cbs)

    async def test_garbage_callbacks_are_harmless(self):
        for payload in (
            "dd:IST:99999999", "dd:IST:20200101", "dr:IST:20261215:99", "dr:IST:xx:7", "dm:IST:209912", "dm:IST",
            "d:IST:bad:-", "d:IST:20261215", "d:IST:20261215:-:9", "dp:ZZZ", "dd::", "dr", "x", "go:::", "d:IST:20200101:-",
        ):
            await self.tap(1, payload)       # must not raise
        for m in self.tg.sent():
            self.assertEqual(html_errors(m["text"]), [])

    async def test_d_button_carries_dates(self):
        await self.say(1, "تركيا 15/12")
        d_buttons = [c for c in all_callbacks(self, self.last()) if c.startswith("d:")]
        self.assertTrue(all(c.endswith(":20261215:-") for c in d_buttons), d_buttons)
        await self.tap(1, d_buttons[0])
        self.assertIn("15 ديسمبر", self.last()["text"])

    async def test_number_pick_keeps_dates(self):
        await self.say(1, "تركيا 15/12")
        await self.say(1, "1")
        self.assertIn("15 ديسمبر", self.last()["text"])

    async def test_cheapest_now_list(self):
        await self.tap(1, "cheap")
        msg = self.last()
        self.assertIn("أرخص الرحلات الآن", msg["text"])
        prices = [int(x.replace(",", "")) for x in re.findall(r"من ([\d,]+) ر\.س", msg["text"])]
        self.assertEqual(prices, sorted(prices))
        self.assertTrue(prices)
        self.assertTrue(any(c.startswith("d:") for c in all_callbacks(self, msg)))

    async def test_cheapest_now_respects_visa_filter(self):
        self.db.set_visa_only(1, True)
        await self.tap(1, "cheap")
        msg = self.last()
        for d in data.destinations():
            if f"<b>{d.flag} {d.ar}</b>" in msg["text"]:
                self.assertIn("✅", msg["text"])

    async def test_search_costs_one_quota_unit(self):
        self.settings = self.settings.__class__(**{**self.settings.__dict__, "daily_search_limit": 1})
        self.bot.settings = self.settings
        await self.say(1, "دبي")
        await self.say(1, "لندن")
        self.assertIn("وصلت للحد اليومي", self.last()["text"])

    async def test_prices_off_still_answers(self):
        self.build(tp_enabled=False)
        await self.say(1, "دبي 15/12")
        msg = self.last()
        self.assertIn("غير مفعّل", msg["text"])
        self.assertEqual(html_errors(msg["text"]), [])

    async def test_provider_down_still_answers(self):
        self.fake.status = 500
        await self.say(1, "دبي 15/12")
        self.assertIn("تعذّر", self.last()["text"])
        await self.tap(1, "cheap")
        self.assertTrue(self.last()["text"])

    async def test_budget_with_month_searches_that_month(self):
        await self.say(1, "5000 ديسمبر")
        self.assertTrue(self.fake.price_calls())
        self.assertTrue(all("departure_at=2026-12" in c[1] for c in self.fake.price_calls()))

    async def test_stay_buttons_filter_by_days(self):
        await self.say(1, "اسطنبول")
        cbs = all_callbacks(self, self.last())
        self.assertIn("dy:IST:7:-", cbs)
        self.assertEqual(len([c for c in cbs if c.startswith("dy:IST:")]), 5)
        await self.tap(1, "dy:IST:7:-")
        self.assertIn("حوالي 7 أيام", self.last()["text"])
        await self.tap(1, "dy:IST:5:-")
        self.assertIn("ما لقيت أسعارًا محفوظة لمدة حوالي 5 أيام", self.last()["text"])   # the fake only has 7-day trips
        self.assertTrue(self.url_buttons(self.last()))      # ...so the wider answer is shown instead of nothing

    async def test_stay_buttons_keep_the_month_and_reject_garbage(self):
        await self.say(1, "لندن ديسمبر")
        self.assertIn("dy:LON:7:202612", all_callbacks(self, self.last()))
        for payload in ("dy:LON:99:-", "dy:LON:7", "dy:LON:7:xx", "dy:LON:x:-", "dy:LON:7:209912", "dy::"):
            await self.tap(1, payload)
        self.assertTrue(all(len(c.encode()) <= 64 for c in all_callbacks(self, self.last())))

    async def test_visa_screen_links_the_official_site_only_when_a_visa_is_needed(self):
        await self.tap(1, "visa:PAR")
        self.assertIn("https://france-visas.gouv.fr", self.url_buttons(self.last()))
        await self.tap(1, "visa:IST")
        self.assertEqual(self.url_buttons(self.last()), [])
        await self.tap(1, "visa:DXB")
        self.assertEqual(self.url_buttons(self.last()), [])

    async def test_official_links_are_https_government_style(self):
        from safrati import data as d
        for dest in d.destinations():
            url = d.visa_official(dest.cc)
            if url:
                self.assertTrue(url.startswith("https://"), url)

    async def test_no_cached_price_with_dates_gives_a_live_search_link_from_the_same_city(self):
        self.db.set_origin(1, "MED")                 # the fake has no routes from MED
        await self.say(1, "لندن 15/12 - 22/12")
        msg = self.last()
        import urllib.parse
        links = [urllib.parse.unquote(u) for u in self.url_buttons(msg)]
        self.assertTrue(any("https://www.aviasales.com/search/MED1512LON22121" in u for u in links), links)
        self.assertTrue(any(u.startswith("https://tp.media/r?marker=") for u in self.url_buttons(msg)))
        self.assertIn("🔎 بحث مباشر (يشمل التوقف)", [b["text"] for b in self.tg.buttons(msg)])
        self.assertEqual(self.db.touch_user(1)["origin"], "MED")

    async def test_no_cached_price_without_dates_points_to_the_date_picker(self):
        self.db.set_origin(1, "MED")
        await self.say(1, "لندن")
        msg = self.last()
        self.assertIn("dp:LON", all_callbacks(self, msg))
        self.assertFalse(any(c.startswith("do:") for c in all_callbacks(self, msg)))

    async def test_provider_requests_connections_and_widens_when_empty(self):
        self.fake.hidden.add(("RUH", "LON"))          # only visible with show_to_affiliates=false
        await self.say(1, "لندن")
        self.assertTrue(self.url_buttons(self.last()))
        urls = [c[1] for c in self.fake.price_calls()]
        self.assertTrue(all("direct=false" in u for u in urls))
        self.assertTrue(any("show_to_affiliates=false" in u for u in urls))

