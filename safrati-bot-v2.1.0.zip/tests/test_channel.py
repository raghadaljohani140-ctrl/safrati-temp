"""The channel post, the opt-in automatic posting, and the daily database backup."""
import asyncio
import calendar
import re
import sqlite3
import tempfile
import unittest
from pathlib import Path

from safrati import channel as channel_mod
from safrati import texts
from safrati.channel import BACKUPS_KEPT, MAX_POST_FAILS
from tests.fakes import NOW
from tests.helpers import html_errors
from tests.test_app import AppCase

CHANNEL = "@safrati_travel"
ADMIN = 9


def saudi(year, month, day, hour, minute=0) -> int:
    """A Unix time for a clock reading in Saudi Arabia (UTC+3)."""
    return calendar.timegm((year, month, day, hour, minute, 0)) - 3 * 3600


class ChannelCase(AppCase):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.t = NOW                                       # Monday 26 October 2026, 15:00 in Saudi Arabia
        self.bot.clock = lambda: self.t
        self.tp._clock = lambda: self.t
        self.db.add_admin(ADMIN)
        self.bot.bot_id = 1

    def channel_posts(self) -> list[dict]:
        return self.tg.sent_to(CHANNEL)

    def enable(self) -> None:
        self.db.kv_set("autopost", "1")


class ChannelAddressTests(ChannelCase):
    async def test_only_a_public_link_can_be_posted_to(self):
        self.assertEqual(self.bot.channel_chat(), CHANNEL)
        for url in ("https://t.me/+AbCdEfGh1234", ""):
            self.build(CHANNEL_URL=url)
            self.assertIsNone(self.bot.channel_chat(), url)

    async def test_a_name_that_is_too_short_is_not_a_channel(self):
        self.build(CHANNEL_URL="https://t.me/abc")
        self.assertIsNone(self.bot.channel_chat())


class DealsPostTests(ChannelCase):
    async def test_the_daily_post_lists_the_cheapest_trips_with_deep_links(self):
        built = await self.bot.build_deals_post("RUH", "daily")
        text, markup, fingerprint = built
        self.assertIn("أرخص رحلات اليوم", text)
        self.assertIn("من الرياض", text)
        self.assertEqual(html_errors(text), [])
        prices = [int(p.replace(",", "")) for p in re.findall(r"من ([\d,]+) ر\.س", text)]
        self.assertEqual(len(prices), 5)
        self.assertEqual(prices, sorted(prices))
        self.assertIn(texts.DISCLOSURE, text)
        rows = markup["inline_keyboard"]
        self.assertEqual(len(rows), 6)
        urls = [b["url"] for row in rows for b in row]
        self.assertTrue(all(u.startswith("https://t.me/SafratiTravel_bot") for u in urls))
        self.assertTrue(all("?start=d_" in u for u in urls[:5]))
        self.assertEqual(urls[5], "https://t.me/SafratiTravel_bot")
        self.assertEqual(len(fingerprint), 16)

    async def test_a_deep_link_from_the_post_opens_that_exact_trip(self):
        _text, markup, _fp = await self.bot.build_deals_post("RUH", "daily")
        link = markup["inline_keyboard"][0][0]["url"]
        payload = link.split("?start=")[1]
        self.assertLessEqual(len(payload), 64)
        self.db.set_onboarded(1)
        await self.say(1, "/start " + payload)
        shown = [p for m, p in self.tg.calls if m in ("sendMessage", "editMessageText")][-1]
        self.assertIn("ذهاب وعودة", shown["text"])
        self.assertTrue(any(payload.split("_")[1] in cb for cb in self.data_buttons(shown)))

    async def test_the_weekend_edition_only_has_weekend_trips(self):
        self.fake.weekend_deals.update({("RUH", d) for d in ("DXB", "CAI", "IST", "AMM")})
        text, markup, _fp = await self.bot.build_deals_post("RUH", "weekend")
        self.assertIn("أرخص رحلات الويكند", text)
        self.assertIn(texts.WEEKEND_RULE, text)
        for button in markup["inline_keyboard"][:-1]:
            self.assertIn("?start=d_", button[0]["url"])

    async def test_not_enough_prices_means_no_post(self):
        self.fake.routes["RUH"] = {"DXB": 700, "CAI": 900}
        self.assertIsNone(await self.bot.build_deals_post("RUH", "daily"))
        self.assertIsNone(await self.bot.build_deals_post("RUH", "weekend"))

    async def test_a_provider_failure_means_no_post(self):
        self.fake.status = 500
        self.assertIsNone(await self.bot.build_deals_post("RUH", "daily"))

    async def test_without_a_price_provider_there_is_no_post(self):
        self.build(tp_enabled=False)
        self.assertIsNone(await self.bot.build_deals_post("RUH", "daily"))

    async def test_the_plan_rotates_the_city_and_makes_thursday_the_weekend_edition(self):
        seen = {}
        for day in range(26, 33):                               # Monday 26 October .. Sunday 1 November
            self.t = saudi(2026, 10, day, 12) if day <= 31 else saudi(2026, 11, 1, 12)
            seen[self.bot._today().weekday()] = self.bot.post_plan()
        self.assertEqual(set(seen), set(range(7)))
        self.assertEqual(seen[3], ("RUH", "weekend"))
        self.assertTrue(all(edition == "daily" for wd, (_o, edition) in seen.items() if wd != 3))
        self.assertGreater(len({origin for origin, _ in seen.values()}), 1)


class PreviewAndManualPostTests(ChannelCase):
    async def test_deals_preview_is_for_admins_only(self):
        await self.say(1, "/deals")
        self.assertEqual(self.last()["text"], texts.ADMIN_ONLY)

    async def test_admin_previews_then_publishes(self):
        await self.say(ADMIN, "/deals")
        preview = self.last()
        self.assertIn("أرخص رحلات اليوم", preview["text"])
        self.assertIn("pub:ok", self.data_buttons(preview))
        self.assertEqual(self.channel_posts(), [])                         # a preview posts nothing

        await self.tap(1, "pub:ok")                                         # an ordinary person pressing it
        self.assertEqual(self.last()["text"], texts.ADMIN_ONLY)
        self.assertEqual(self.channel_posts(), [])

        await self.tap(ADMIN, "pub:ok")
        posts = self.channel_posts()
        self.assertEqual(len(posts), 1)
        self.assertEqual(posts[0]["text"], preview["text"])
        self.assertEqual(self.tg.sent_to(ADMIN)[-1]["text"], texts.DEALS_POSTED)
        self.assertIsNotNone(self.db.kv_get("last_post_hash"))

        await self.tap(ADMIN, "pub:ok")                                     # nothing left to publish
        self.assertEqual(self.tg.sent_to(ADMIN)[-1]["text"], texts.DEALS_NO_DRAFT)
        self.assertEqual(len(self.channel_posts()), 1)

    async def test_a_failed_manual_post_is_explained(self):
        await self.say(ADMIN, "/deals")
        self.tg.blocked.add(CHANNEL)
        await self.tap(ADMIN, "pub:ok")
        self.assertIn("تعذّر النشر في القناة", self.tg.sent_to(ADMIN)[-1]["text"])
        self.assertIn("403", self.tg.sent_to(ADMIN)[-1]["text"])
        self.assertIsNone(self.db.kv_get("last_post_hash"))

    async def test_preview_says_so_when_there_is_not_enough_to_post(self):
        self.fake.routes["RUH"] = {"DXB": 700}
        await self.say(ADMIN, "/deals")
        self.assertEqual(self.last()["text"], texts.DEALS_NONE)

    async def test_with_a_private_channel_the_preview_cannot_be_published(self):
        self.build(CHANNEL_URL="https://t.me/+AbCdEfGh1234")
        self.db.add_admin(ADMIN)
        await self.say(ADMIN, "/deals")
        self.assertNotIn("pub:ok", self.data_buttons(self.last()))
        await self.tap(ADMIN, "pub:ok")
        self.assertEqual(self.last()["text"], texts.DEALS_NO_DRAFT)


class AutopostCommandTests(ChannelCase):
    async def test_status_on_and_off(self):
        await self.say(ADMIN, "/autopost")
        self.assertIn("متوقف", self.last()["text"])
        self.assertIn(CHANNEL, self.last()["text"])
        await self.say(ADMIN, "/autopost on")
        self.assertIn("مفعّل", self.last()["text"])
        self.assertTrue(self.bot.autopost_on())
        await self.say(ADMIN, "/autopost off")
        self.assertIn("متوقف", self.last()["text"])
        self.assertFalse(self.bot.autopost_on())
        await self.say(ADMIN, "/autopost تشغيل")
        self.assertTrue(self.bot.autopost_on())
        await self.say(ADMIN, "/autopost ايقاف")
        self.assertFalse(self.bot.autopost_on())

    async def test_turning_it_on_clears_old_failures(self):
        self.db.kv_set("post_fails", "2")
        await self.say(ADMIN, "/autopost on")
        self.assertEqual(self.db.kv_get("post_fails"), "0")

    async def test_not_for_ordinary_people(self):
        await self.say(1, "/autopost on")
        self.assertEqual(self.last()["text"], texts.ADMIN_ONLY)
        self.assertFalse(self.bot.autopost_on())

    async def test_it_cannot_be_turned_on_without_a_public_channel(self):
        self.build(CHANNEL_URL="https://t.me/+AbCdEfGh1234")
        self.db.add_admin(ADMIN)
        await self.say(ADMIN, "/autopost on")
        self.assertEqual(self.last()["text"], texts.AUTOPOST_NO_CHANNEL)
        self.assertFalse(self.bot.autopost_on())


class AutopostTickTests(ChannelCase):
    async def test_nothing_is_posted_while_it_is_off(self):
        self.assertFalse(await self.bot.channel_tick())
        self.assertEqual(self.channel_posts(), [])

    async def test_it_waits_for_the_posting_hour(self):
        self.enable()
        self.t = saudi(2026, 10, 26, 9, 30)
        self.assertFalse(await self.bot.channel_tick())
        self.t = saudi(2026, 10, 26, 10, 0)
        self.assertTrue(await self.bot.channel_tick())
        self.assertEqual(len(self.channel_posts()), 1)

    async def test_one_post_a_day(self):
        self.enable()
        self.assertTrue(await self.bot.channel_tick())
        self.assertEqual(self.db.kv_get("last_post_day"), "2026-10-26")
        self.assertFalse(await self.bot.channel_tick())
        self.assertEqual(len(self.channel_posts()), 1)
        self.assertEqual(self.db.kv_get("post_fails"), "0")

    async def test_the_same_deals_as_last_time_are_not_posted_again(self):
        self.enable()
        self.assertTrue(await self.bot.channel_tick())
        self.t += 86400                                                      # Tuesday: another city, so other deals
        self.db.kv_set("last_post_hash", (await self.bot.build_deals_post(*self.bot.post_plan()))[2])
        self.assertFalse(await self.bot.channel_tick())
        self.assertEqual(len(self.channel_posts()), 1)
        self.assertEqual(self.db.kv_get("last_post_day"), "2026-10-27")      # ... but the day is marked as handled
        self.assertFalse(await self.bot.channel_tick())

    async def test_tuesday_is_posted_from_another_city(self):
        self.enable()
        self.t += 86400
        self.assertTrue(await self.bot.channel_tick())
        self.assertIn("من جدة", self.channel_posts()[0]["text"])

    async def test_thursday_is_the_weekend_edition(self):
        self.enable()
        self.fake.weekend_deals.update({("RUH", d) for d in ("DXB", "CAI", "IST", "AMM")})
        self.t = saudi(2026, 10, 29, 12)
        self.assertTrue(await self.bot.channel_tick())
        self.assertIn("أرخص رحلات الويكند", self.channel_posts()[0]["text"])

    async def test_a_day_without_enough_prices_is_retried_later(self):
        self.enable()
        self.fake.routes["RUH"] = {"DXB": 700}
        self.assertFalse(await self.bot.channel_tick())
        self.assertIsNone(self.db.kv_get("last_post_day"))
        self.fake.routes["RUH"] = {"DXB": 700, "CAI": 900, "IST": 1100}
        self.t += 3600                                                       # the price cache has expired by the next look
        self.assertTrue(await self.bot.channel_tick())

    async def test_repeated_failures_switch_it_off_and_tell_the_admins(self):
        self.enable()
        self.tg.blocked.add(CHANNEL)
        for expected in (1, 2):
            self.assertFalse(await self.bot.channel_tick())
            self.assertEqual(self.db.kv_get("post_fails"), str(expected))
            self.assertTrue(self.bot.autopost_on())
        self.assertEqual(self.tg.sent_to(ADMIN), [])
        self.assertFalse(await self.bot.channel_tick())
        self.assertEqual(MAX_POST_FAILS, 3)
        self.assertFalse(self.bot.autopost_on())
        told = self.tg.sent_to(ADMIN)
        self.assertEqual(len(told), 1)
        self.assertIn("أوقفت النشر التلقائي", told[0]["text"])
        self.assertIsNone(self.db.kv_get("last_post_day"))

    async def test_a_success_resets_the_failure_count(self):
        self.enable()
        self.tg.blocked.add(CHANNEL)
        await self.bot.channel_tick()
        self.assertEqual(self.db.kv_get("post_fails"), "1")
        self.tg.blocked.clear()
        self.assertTrue(await self.bot.channel_tick())
        self.assertEqual(self.db.kv_get("post_fails"), "0")

    async def test_the_loop_survives_a_failing_pass_and_stops_on_request(self):
        stop = asyncio.Event()
        calls = []

        async def broken():
            calls.append(1)
            if len(calls) == 2:
                stop.set()
            raise RuntimeError("boom")

        self.bot.channel_tick = broken
        old = channel_mod.CHANNEL_CHECK
        channel_mod.CHANNEL_CHECK = 0
        try:
            with self.assertLogs("safrati.channel", level="ERROR"):
                await asyncio.wait_for(self.bot.channel_loop(stop), 2)
        finally:
            channel_mod.CHANNEL_CHECK = old
        self.assertEqual(len(calls), 2)


class ChannelReadinessTests(ChannelCase):
    async def test_the_bot_must_be_an_admin_who_can_post(self):
        self.assertEqual(await self.bot.channel_ready(), (True, ""))
        self.tg.member = {"status": "creator"}
        self.assertEqual(await self.bot.channel_ready(), (True, ""))
        self.tg.member = {"status": "administrator", "can_post_messages": False}
        ok, why = await self.bot.channel_ready()
        self.assertFalse(ok)
        self.assertIn("صلاحية النشر", why)
        self.tg.member = {"status": "member"}
        self.assertFalse((await self.bot.channel_ready())[0])
        self.tg.member = {"status": "left"}
        self.assertFalse((await self.bot.channel_ready())[0])

    async def test_problems_are_named(self):
        self.tg.fail_always["getChatMember"] = (400, "Bad Request: chat not found")
        ok, why = await self.bot.channel_ready()
        self.assertFalse(ok)
        self.assertIn("400", why)
        self.assertIn("تأكد أن البوت مشرف", why)                             # tells the admin what to do
        self.bot.bot_id = 0
        self.assertEqual(await self.bot.channel_ready(), (False, "رقم البوت غير معروف"))
        self.build(CHANNEL_URL="https://t.me/+AbCdEfGh1234")
        self.assertEqual(await self.bot.channel_ready(), (False, "رابط القناة غير عام"))

    async def test_diag_reports_the_channel_when_one_is_configured(self):
        await self.say(1, "/diag")
        self.assertEqual(self.last()["text"], texts.ADMIN_ONLY)
        await self.say(ADMIN, "/diag")
        report = self.last()["text"]
        self.assertIn("✅ النشر في القناة", report)
        self.assertIn("⚪ النشر التلقائي: متوقف (اختياري)", report)           # off is not an error
        self.assertNotIn("❌ النشر التلقائي", report)
        self.enable()
        await self.say(ADMIN, "/diag")
        self.assertIn("✅ النشر التلقائي: يعمل (يوميًا بعد الساعة 10:00)", self.last()["text"])
        self.tg.member = {"status": "member"}
        await self.say(ADMIN, "/diag")
        report = self.last()["text"]
        self.assertIn("❌ النشر في القناة", report)
        self.assertIn("❌ النشر التلقائي: مفعّل لكن القناة غير جاهزة", report)
        self.assertEqual(html_errors(report), [])

    async def test_diag_says_nothing_about_a_channel_when_none_is_configured(self):
        self.build(CHANNEL_URL="")
        self.db.add_admin(ADMIN)
        await self.say(ADMIN, "/diag")
        self.assertNotIn("القناة", self.last()["text"])


class BackupTests(ChannelCase):
    def use_folder(self) -> Path:
        folder = tempfile.TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        self.build(DB_PATH=str(Path(folder.name) / "safrati.db"))
        self.db.add_admin(ADMIN)
        self.bot.clock = lambda: self.t
        self.t = NOW
        return Path(folder.name)

    async def test_a_backup_is_a_real_copy_of_the_database(self):
        folder = self.use_folder()
        self.db.set_origin(5, "JED")
        self.db.save(5, "IST")
        target = self.bot.make_backup()
        self.assertEqual(target.parent, folder / "backups")
        self.assertRegex(target.name, r"^safrati-20261026-1500\.db$")
        con = sqlite3.connect(target)
        try:
            self.assertEqual(con.execute("SELECT origin FROM users WHERE tg_id=5").fetchone(), ("JED",))
            self.assertEqual(con.execute("SELECT iata FROM saved WHERE tg_id=5").fetchone(), ("IST",))
        finally:
            con.close()

    async def test_only_the_newest_copies_are_kept(self):
        folder = self.use_folder()
        for _ in range(BACKUPS_KEPT + 3):
            self.bot.make_backup()
            self.t += 120
        names = sorted(p.name for p in (folder / "backups").glob("safrati-*.db"))
        self.assertEqual(len(names), BACKUPS_KEPT)
        self.assertEqual(names[-1], "safrati-20261026-1510.db")
        self.assertEqual(BACKUPS_KEPT, 3)

    async def test_no_backup_for_an_in_memory_database(self):
        self.build(DB_PATH=":memory:")
        self.assertIsNone(self.bot.make_backup())

    async def test_the_backup_command(self):
        self.use_folder()
        await self.say(1, "/backup")
        self.assertEqual(self.last()["text"], texts.ADMIN_ONLY)
        await self.say(ADMIN, "/backup")
        self.assertIn("نسخة احتياطية", self.last()["text"])
        self.assertIn("safrati-20261026-1500.db", self.last()["text"])
        self.assertEqual(html_errors(self.last()["text"]), [])

    async def test_a_backup_that_cannot_be_made_is_reported(self):
        self.build(DB_PATH=":memory:")
        self.db.add_admin(ADMIN)
        await self.say(ADMIN, "/backup")
        self.assertEqual(self.last()["text"], texts.BACKUP_FAILED)
        blocker = tempfile.NamedTemporaryFile()
        self.addCleanup(blocker.close)
        self.build(DB_PATH=str(Path(blocker.name) / "x" / "safrati.db"))        # the "folder" is really a file
        self.db.add_admin(ADMIN)
        with self.assertLogs("safrati.channel", level="ERROR"):
            await self.say(ADMIN, "/backup")
        self.assertEqual(self.last()["text"], texts.BACKUP_FAILED)

    async def wait_for(self, condition, seconds=3.0):
        for _ in range(int(seconds / 0.02)):
            if condition():
                return True
            await asyncio.sleep(0.02)
        return False

    async def test_the_daily_job_backs_up_once_after_four_in_the_morning(self):
        folder = self.use_folder()
        self.t = saudi(2026, 10, 26, 3, 30)
        stop = asyncio.Event()
        task = asyncio.create_task(self.bot.maintenance_loop(stop))
        await asyncio.sleep(0.1)
        self.assertEqual(list((folder / "backups").glob("*.db")) if (folder / "backups").exists() else [], [])
        stop.set()
        await asyncio.wait_for(task, 2)

        self.t = saudi(2026, 10, 26, 4, 10)
        stop = asyncio.Event()
        task = asyncio.create_task(self.bot.maintenance_loop(stop))
        self.assertTrue(await self.wait_for(lambda: self.db.kv_get("last_backup_day") == "2026-10-26"))
        stop.set()
        await asyncio.wait_for(task, 2)
        self.assertEqual(len(list((folder / "backups").glob("*.db"))), 1)

        stop = asyncio.Event()                                              # the same day again: nothing new
        task = asyncio.create_task(self.bot.maintenance_loop(stop))
        await asyncio.sleep(0.1)
        stop.set()
        await asyncio.wait_for(task, 2)
        self.assertEqual(len(list((folder / "backups").glob("*.db"))), 1)


if __name__ == "__main__":
    unittest.main()
