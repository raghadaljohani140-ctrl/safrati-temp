"""The bot must be self-contained: no secrets in files, nothing that touches other projects."""
import logging
import os
import re
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

from safrati.logsafe import ScrubbingFormatter, secrets_of
from safrati.config import load_settings
from safrati.telegram import TelegramAPI, TelegramError
from tests.fakes import BOT_TOKEN, TP_TOKEN

ROOT = Path(__file__).resolve().parent.parent
SKIP_DIRS = {"tests", "__pycache__", ".git"}


def package_files():
    for path in ROOT.rglob("*"):
        if path.is_file() and not (set(path.relative_to(ROOT).parts) & SKIP_DIRS):
            if path.suffix in {".zip", ".pyc"}:
                continue
            yield path


# other projects on the same machine are named here only by pieces, so this file never matches itself
OTHER_PROJECTS = ["a" + "qar", "maz" + "ad", "maz" + "aad", "عق" + "ار", "مز" + "اد", "mazad" + "-bot"]


class FileScanTests(unittest.TestCase):
    def test_no_telegram_bot_token_or_api_key_inside_any_file(self):
        token = re.compile(r"\b\d{8,10}:[A-Za-z0-9_-]{35}\b")
        long_hex = re.compile(r"\b[0-9a-fA-F]{32,}\b")
        for path in package_files():
            text = path.read_text(encoding="utf-8", errors="ignore")
            self.assertIsNone(token.search(text), f"token-like string in {path}")
            self.assertIsNone(long_hex.search(text), f"long hex string in {path}")

    def test_nothing_refers_to_the_other_projects(self):
        for path in package_files():
            text = path.read_text(encoding="utf-8", errors="ignore").lower()
            for word in OTHER_PROJECTS:
                self.assertNotIn(word, text, f"{word!r} found in {path}")

    def test_no_env_file_or_database_in_the_folder(self):
        names = {p.name for p in package_files()}
        self.assertNotIn(".env", names)
        self.assertFalse([n for n in names if n.endswith((".db", ".db-wal", ".db-shm"))])

    def test_scripts_only_mention_their_own_folder(self):
        for name in ("install.sh", "status.sh", "uninstall.sh", "docker-compose.yml", "Dockerfile"):
            text = (ROOT / name).read_text()
            for path in re.findall(r"/opt/[A-Za-z0-9_.-]+", text):
                self.assertEqual(path, "/opt/safrati-bot", f"{name}: {path}")
            for forbidden in ("docker.sock", "network_mode", "privileged", "--privileged", "pid: host", "/var/run", "prune", "rm -rf", "chmod -R", "ufw", "iptables", "systemctl", "apt-get", "apt "):
                self.assertNotIn(forbidden, text, f"{name}: {forbidden}")


class ComposeTests(unittest.TestCase):
    def setUp(self):
        self.compose = (ROOT / "docker-compose.yml").read_text()

    def test_isolation_settings(self):
        for needle in (
            "name: safrati", "container_name: safrati-bot", "image: safrati-bot:local", "restart: unless-stopped",
            "env_file: .env", "read_only: true", "cap_drop:", "- ALL", "no-new-privileges:true",
            "mem_limit: 256m", "cpus: 0.5", "safrati_data:/data",
        ):
            self.assertIn(needle, self.compose)

    def test_publishes_no_ports_and_mounts_nothing_from_the_host(self):
        self.assertNotIn("ports:", self.compose)
        self.assertNotIn("expose:", self.compose)
        mounts = re.findall(r"^\s+- (\S+:/\S+)\s*$", self.compose, flags=re.M)
        self.assertEqual(mounts, ["safrati_data:/data"])
        self.assertNotRegex(self.compose, r"(\./|/)[A-Za-z0-9_./-]+:/")

    def test_dockerfile_installs_nothing_from_the_internet(self):
        text = (ROOT / "Dockerfile").read_text()
        self.assertNotIn("pip", text)
        self.assertNotIn("curl", text)
        self.assertNotIn("ADD ", text)
        self.assertIn("USER safrati", text)
        self.assertIn("COPY safrati/ /app/safrati/", text)

    def test_env_never_enters_the_image(self):
        ignore = (ROOT / ".dockerignore").read_text().split()
        self.assertIn(".env", ignore)
        self.assertNotIn(".env", (ROOT / "Dockerfile").read_text())


class SecretHandlingTests(unittest.TestCase):
    def settings(self):
        return load_settings({"BOT_TOKEN": BOT_TOKEN, "TP_TOKEN": TP_TOKEN, "ADMIN_CODE": "adm1n-code-123"})

    def test_formatter_masks_secrets_everywhere_including_tracebacks(self):
        formatter = ScrubbingFormatter(secrets_of(self.settings()), "%(message)s")
        try:
            raise RuntimeError(f"failed calling https://api.telegram.org/bot{BOT_TOKEN}/getMe with {TP_TOKEN}")
        except RuntimeError:
            record = logging.LogRecord("x", logging.ERROR, __file__, 1, f"token {BOT_TOKEN} code adm1n-code-123", None, sys.exc_info())
        out = formatter.format(record)
        for secret in (BOT_TOKEN, BOT_TOKEN.split(":")[1], TP_TOKEN, "adm1n-code-123"):
            self.assertNotIn(secret, out)
        self.assertIn("***", out)

    def test_telegram_errors_never_contain_the_token(self):
        def transport(url, body, timeout):
            return 401, ('{"ok": false, "error_code": 401, "description": "bad %s"}' % BOT_TOKEN).encode()

        api = TelegramAPI(BOT_TOKEN, transport=transport)
        import asyncio
        with self.assertRaises(TelegramError) as ctx:
            asyncio.run(api.call("getMe"))
        self.assertNotIn(BOT_TOKEN, str(ctx.exception))

    def test_network_errors_do_not_leak_the_url(self):
        import urllib.error
        from unittest import mock
        from safrati import telegram, tp

        err = urllib.error.URLError(f"cannot reach https://api.telegram.org/bot{BOT_TOKEN}/getMe")
        with mock.patch("urllib.request.urlopen", side_effect=err):
            with self.assertRaises(TelegramError) as t1:
                telegram._urllib_transport(f"https://api.telegram.org/bot{BOT_TOKEN}/getMe", b"{}", 1)
            with self.assertRaises(tp.TPError) as t2:
                tp._urllib_transport("GET", "https://api.travelpayouts.com/x", {"X-Access-Token": TP_TOKEN}, None, 1)
        self.assertNotIn(BOT_TOKEN, str(t1.exception))
        self.assertNotIn(TP_TOKEN, str(t2.exception))

    def test_bad_config_is_reported_without_echoing_the_value(self):
        env = dict(os.environ, BOT_TOKEN="SECRET-LOOKING-VALUE-THAT-IS-WRONG", PYTHONPATH=str(ROOT))
        result = subprocess.run([sys.executable, "-m", "safrati"], env=env, capture_output=True, text=True, cwd=ROOT, timeout=30)
        self.assertEqual(result.returncode, 78)
        self.assertNotIn("SECRET-LOOKING-VALUE", result.stdout + result.stderr)
        self.assertIn("configuration error", result.stderr)


class HealthcheckTests(unittest.TestCase):
    def run_check(self, path):
        env = dict(os.environ, HEARTBEAT_PATH=str(path), PYTHONPATH=str(ROOT))
        return subprocess.run([sys.executable, "-m", "safrati.healthcheck"], env=env, cwd=ROOT, timeout=30).returncode

    def test_fresh_stale_and_missing_heartbeat(self):
        with tempfile.TemporaryDirectory() as tmp:
            beat = Path(tmp) / "hb"
            self.assertEqual(self.run_check(beat), 1)
            beat.write_text("1")
            self.assertEqual(self.run_check(beat), 0)
            old = time.time() - 600
            os.utime(beat, (old, old))
            self.assertEqual(self.run_check(beat), 1)


if __name__ == "__main__":
    unittest.main()
