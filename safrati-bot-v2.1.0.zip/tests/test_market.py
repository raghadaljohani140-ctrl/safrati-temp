"""The admin's price-market check (/market), and how /diag reports the price lookups and partner links."""
import calendar
import random

from safrati import texts
from safrati.app import SafratiBot
from safrati.market import MARKETS, PROBE_ROUTES
from tests.fakes import MARKER, TP_TOKEN, TRS
from tests.helpers import html_errors
from tests.test_app import AppCase

ADMIN = 9


class MarketCase(AppCase):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.db.add_admin(ADMIN)

    def shown(self) -> dict:
        return [p for m, p in self.tg.calls if m in ("sendMessage", "editMessageText")][-1]

    def callbacks(self) -> list[str]:
        return self.data_buttons(self.shown())

    def market_calls(self) -> list[str]:
        return [c[1] for c in self.fake.price_calls() if "market=" in c[1]]


class ProbeTests(MarketCase):
    async def test_only_the_admin_may_look_at_or_change_the_market(self):
        await self.say(1, "/market")
        self.assertEqual(self.shown()["text"], texts.ADMIN_ONLY)
        await self.say(1, "/market us")
        self.assertEqual(self.shown()["text"], texts.ADMIN_ONLY)
        await self.tap(1, "mk:us")
        self.assertEqual(self.shown()["text"], texts.ADMIN_ONLY)
        self.assertEqual(self.tp.market, "")
        self.assertEqual(self.fake.price_calls(), [])

    async def test_the_check_compares_the_markets_and_recommends_the_richest(self):
        self.fake.market_days = {"": 2, "us": 20, "ru": 4, "*": 0}
        await self.say(ADMIN, "/market")
        wait, report = [p["text"] for p in self.tg.sent()[-2:]]
        self.assertEqual(wait, texts.MARKET_WAIT)
        self.assertIn("اختبار سوق الأسعار", report)
        self.assertIn("• تلقائي: 6 ← الحالي", report)                          # the fake only has 3 of the 4 routes: 3 x 2 days
        self.assertIn("• us: 60 ⭐", report)
        self.assertIn("• ru: 12", report)
        self.assertIn("• sa: 0", report)
        self.assertIn("الأغنى: <b>us</b> (60 يوم مقابل 6)", report)
        self.assertIn("نوفمبر 2026", report)
        self.assertEqual(html_errors(report), [])
        self.assertIn("mk:us", self.callbacks())
        self.assertNotIn("mk:-", self.callbacks())                           # already on the automatic market
        self.assertTrue(all(len(cb.encode()) <= 64 for cb in self.callbacks()))
        asked = {c[1].split("market=")[1].split("&")[0] for c in self.fake.price_calls() if "market=" in c[1]}
        self.assertEqual(asked, set(MARKETS) - {""})                         # every market was tried ("" is the one without the parameter)
        self.assertEqual(len(self.fake.price_calls()), len(MARKETS) * len(PROBE_ROUTES))

    async def test_nothing_is_recommended_when_no_market_is_clearly_better(self):
        self.fake.market_days = {m: 6 for m in MARKETS}
        await self.say(ADMIN, "/market")
        self.assertIn("كافٍ", self.shown()["text"])
        self.assertNotIn("⭐", self.shown()["text"])                          # a tie has no winner
        self.assertEqual([c for c in self.callbacks() if c.startswith("mk:")], [])
        self.fake.market_days = {"": 6, "us": 8, "*": 6}                     # three days more over three routes is noise
        await self.say(ADMIN, "/market")
        self.assertIn("كافٍ", self.shown()["text"])
        self.assertEqual([c for c in self.callbacks() if c.startswith("mk:")], [])
        self.assertNotIn("us: 24 ⭐", self.shown()["text"])
        self.fake.market_days = {"": 6, "us": 10, "*": 6}                    # twelve days more is not
        await self.say(ADMIN, "/market")
        self.assertIn("mk:us", self.callbacks())

    async def test_the_current_market_is_marked_and_can_be_left(self):
        self.fake.market_days = {"": 2, "us": 20, "*": 0}
        await self.say(ADMIN, "/market us")
        await self.say(ADMIN, "/market")
        report = self.shown()["text"]
        self.assertIn("• us: 60 ⭐ ← الحالي", report)
        self.assertIn("mk:-", self.callbacks())
        self.assertNotIn("mk:us", self.callbacks())
        self.assertIn("🏠 القائمة", [b["text"] for b in self.tg.buttons(self.shown())])

    async def test_a_market_the_provider_refuses_is_shown_as_unavailable(self):
        real = self.fake._prices

        def picky(params):
            if params.get("market") == "ar":
                return 400, b'{"success": false, "error": "market not found"}'
            return real(params)

        self.fake._prices = picky
        await self.say(ADMIN, "/market")
        self.assertIn("• ar: غير متاح", self.shown()["text"])
        self.assertIn("• us:", self.shown()["text"])

    async def test_no_answer_from_the_provider_at_all(self):
        self.fake.status = 500
        await self.say(ADMIN, "/market")
        self.assertEqual(self.shown()["text"], texts.MARKET_NONE)

    async def test_no_check_without_a_price_token(self):
        self.build(tp_enabled=False)
        self.db.add_admin(ADMIN)
        await self.say(ADMIN, "/market")
        self.assertEqual(self.shown()["text"], texts.MARKET_NONE)

    async def test_the_current_market_is_tried_even_when_it_is_not_in_the_list(self):
        self.bot.tp.set_market("zz")
        self.fake.market_days = {"zz": 10, "*": 0}
        await self.say(ADMIN, "/market")
        self.assertIn("• zz: 30 ⭐ ← الحالي", self.shown()["text"])

    async def test_a_slow_provider_gives_up_after_the_limit(self):
        import safrati.market as market
        old = market.PROBE_SECONDS
        market.PROBE_SECONDS = 0.05
        try:
            for route in PROBE_ROUTES:
                self.fake.slow[route] = 0.2
            await self.say(ADMIN, "/market")
            self.assertEqual(self.shown()["text"], texts.MARKET_NONE)
        finally:
            market.PROBE_SECONDS = old
        import asyncio
        await asyncio.sleep(0.6)                                             # let the slow answers end before the loop closes


class SwitchTests(MarketCase):
    async def test_the_button_switches_the_market_and_prices_follow(self):
        self.fake.market_days = {"": 2, "us": 20, "*": 0}
        await self.say(1, "اسطنبول")                                          # fills the caches on the automatic market
        self.assertEqual(self.market_calls(), [])
        await self.say(ADMIN, "/market")
        before = len(self.fake.price_calls())
        await self.tap(ADMIN, "mk:us")
        self.assertEqual(self.tp.market, "us")
        self.assertEqual(self.db.kv_get("market"), "us")
        self.assertEqual(self.shown()["text"], texts.market_changed("us"))
        self.assertEqual(html_errors(self.shown()["text"]), [])
        await self.say(1, "اسطنبول")
        later = self.fake.price_calls()[before:]
        self.assertTrue(later)                                               # nothing from the old market was reused
        self.assertTrue(all("market=us" in c[1] for c in later))

    async def test_typed_commands_switch_directly(self):
        await self.say(ADMIN, "/market US")
        self.assertEqual((self.tp.market, self.db.kv_get("market")), ("us", "us"))
        await self.say(ADMIN, "/market auto")
        self.assertEqual((self.tp.market, self.db.kv_get("market")), ("", ""))
        await self.say(ADMIN, "/market us")
        await self.say(ADMIN, "/market تلقائي")
        self.assertEqual(self.tp.market, "")

    async def test_going_back_to_automatic_returns_to_the_market_in_the_settings_file(self):
        self.build(TP_MARKET="ae")
        self.db.add_admin(ADMIN)
        self.assertEqual(self.tp.market, "ae")
        await self.say(ADMIN, "/market us")
        self.assertEqual(self.tp.market, "us")
        await self.tap(ADMIN, "mk:-")
        self.assertEqual(self.tp.market, "ae")

    async def test_bad_input_changes_nothing(self):
        for text in ("/market xyz", "/market u", "/market 12", "/market us; drop", "/market ../x"):
            await self.say(ADMIN, text)
            self.assertEqual(self.shown()["text"], texts.MARKET_USAGE, text)
        for data_ in ("mk:", "mk:xyz", "mk:U5", "mk:../x"):
            await self.tap(ADMIN, data_)
            self.assertEqual(self.shown()["text"], texts.BAD_BUTTON, data_)
        self.assertEqual((self.tp.market, self.db.kv_get("market")), ("", None))

    async def test_the_chosen_market_survives_a_restart(self):
        await self.say(ADMIN, "/market us")
        again = SafratiBot(
            self.settings, self.api, self.db, self.tp.__class__(
                TP_TOKEN, MARKER, TRS, "sar", transport=self.fake.transport, clock=lambda: 0,
            ), bot_username="SafratiTravel_bot", clock=lambda: 0, rng=random.Random(1),
        )
        self.assertEqual(again.tp.market, "us")

    async def test_a_damaged_saved_value_is_ignored(self):
        self.db.kv_set("market", "../etc")
        again = SafratiBot(
            self.settings, self.api, self.db, self.tp.__class__(
                TP_TOKEN, MARKER, TRS, "sar", transport=self.fake.transport, clock=lambda: 0,
            ), bot_username="SafratiTravel_bot", clock=lambda: 0, rng=random.Random(1),
        )
        self.assertEqual(again.tp.market, "")


class SampleMonthTests(MarketCase):
    def at(self, year: int, month: int, day: int) -> None:
        self.bot.clock = lambda: calendar.timegm((year, month, day, 12, 0, 0))

    async def test_a_month_that_is_nearly_over_is_skipped(self):
        self.at(2026, 10, 10)
        self.assertEqual(self.bot.sample_month(), "2026-10")                  # the 17th onward is still ahead
        self.at(2026, 10, 22)
        self.assertEqual(self.bot.sample_month(), "2026-11")                  # only the last week of October would be left
        self.at(2026, 10, 26)
        self.assertEqual(self.bot.sample_month(), "2026-11")
        self.at(2026, 12, 28)
        self.assertEqual(self.bot.sample_month(), "2027-01")


class DiagTests(MarketCase):
    async def test_the_calendar_line_says_how_many_days_of_the_month_have_prices(self):
        await self.say(ADMIN, "/diag")
        text = self.shown()["text"]
        self.assertRegex(text, r"✅ تقويم الأسعار \(نوفمبر\): 28 يوم من 30")

    async def test_a_thin_calendar_shows_how_thin(self):
        self.fake.market_days = {"": 5}
        await self.say(ADMIN, "/diag")
        self.assertIn("✅ تقويم الأسعار (نوفمبر): 5 يوم من 30", self.shown()["text"])

    async def test_the_market_line(self):
        await self.say(ADMIN, "/diag")
        self.assertIn("⚪ سوق الأسعار: تلقائي", self.shown()["text"])
        self.assertIn("/market", self.shown()["text"])
        await self.say(ADMIN, "/market us")
        await self.say(ADMIN, "/diag")
        self.assertIn("✅ سوق الأسعار: us", self.shown()["text"])

    async def test_weekend_line_has_the_count_and_the_time(self):
        self.fake.crowd = 2500
        self.fake.stays = (7, 10)
        self.fake.weekend_deals.update({("RUH", d) for d in ("DXB", "CAI", "IST", "AMM", "BEY")})
        await self.say(ADMIN, "/diag")
        self.assertRegex(self.shown()["text"], r"✅ رحلات الويكند: 5 وجهة \(\d+\.\d ث\)")

    async def test_weekend_line_says_when_the_rest_is_still_loading(self):
        import asyncio
        import safrati.tp as tp
        self.fake.stays = (7, 10)
        self.fake.crowd = 2500
        self.fake.weekend_deals.update({("RUH", d) for d in ("DXB", "CAI")})
        self.fake.slow[("RUH", "CAI")] = 0.3
        old = tp.WEEKEND_BUDGET
        tp.WEEKEND_BUDGET = 0.1
        try:
            await self.say(ADMIN, "/diag")
        finally:
            tp.WEEKEND_BUDGET = old
        self.assertIn("✅ رحلات الويكند: 1 وجهة", self.shown()["text"])
        self.assertIn(texts.WEEKEND_PARTIAL, self.shown()["text"])
        await asyncio.sleep(0.5)                                             # let the slow answer end before the loop closes

    async def test_partner_links_missing_the_project_id(self):
        self.build(TP_TRS="")
        self.db.add_admin(ADMIN)
        await self.say(ADMIN, "/diag")
        text = self.shown()["text"]
        self.assertIn("❌ روابط الشريك — ناقص: رقم المشروع (TP_TRS)", text)
        self.assertIn("bash install.sh set TP_TRS", text)
        self.assertNotIn("إنشاء رابط شريك", text)
        self.assertEqual(html_errors(text), [])

    async def test_partner_links_missing_both_ids(self):
        self.build(TP_TRS="", TP_MARKER="")
        self.db.add_admin(ADMIN)
        await self.say(ADMIN, "/diag")
        text = self.shown()["text"]
        self.assertIn("ناقص: رقم الشريك (TP_MARKER) ورقم المشروع (TP_TRS)", text)
        self.assertIn("bash install.sh set TP_MARKER ثم bash install.sh set TP_TRS", text)

    async def test_partner_links_working(self):
        await self.say(ADMIN, "/diag")
        text = self.shown()["text"]
        self.assertIn("✅ روابط الشريك\n", text)
        self.assertIn("✅ إنشاء رابط شريك (tp.media)", text)
        self.assertIn("✅ 📶 إنترنت للسفر eSIM — Airalo", text)
        self.assertIn("⚪ 🎟 جولات ومعالم — Tiqets" + texts.SERVICE_OFF, text)       # a program the account has not joined is not an error
        self.assertNotIn("❌ 🎟", text)

    async def test_a_project_that_has_not_joined_the_flight_program_is_explained(self):
        self.fake.link_error = "trs is not subscribed for brand"
        await self.say(ADMIN, "/diag")
        text = self.shown()["text"]
        self.assertIn("❌ إنشاء رابط شريك", text)
        self.assertIn("↳ المشروع غير مشترك في برنامج Aviasales", text)
        self.assertEqual(html_errors(text), [])

    async def test_a_wrong_project_id_is_explained(self):
        self.fake.links_http = (400, {"error": "invalid traffic source"})
        await self.say(ADMIN, "/diag")
        self.assertIn("↳ رقم المشروع غير صحيح", self.shown()["text"])

    async def test_an_unknown_refusal_is_shown_as_the_provider_worded_it(self):
        self.fake.link_error = "something <odd> & new"
        await self.say(ADMIN, "/diag")
        text = self.shown()["text"]
        self.assertIn("↳ something &lt;odd&gt; &amp; new", text)
        self.assertEqual(html_errors(text), [])

    async def test_a_remembered_failure_is_not_reused_by_the_check(self):
        self.fake.link_error = "trs is not subscribed for brand"
        await self.say(1, "اسطنبول")                                          # a card asks for links and remembers the refusal
        self.fake.link_error = None
        await self.say(ADMIN, "/diag")
        self.assertIn("✅ إنشاء رابط شريك", self.shown()["text"])

    async def test_text_helpers(self):
        self.assertEqual(texts.link_issue_text(""), "السبب غير معروف")
        self.assertIn("المشاريع", texts.link_issue_text("Invalid traffic source"))
        self.assertIn("البرامج", texts.link_issue_text("TRS is NOT SUBSCRIBED for brand"))
        self.assertIn("مرفوض", texts.link_issue_text("token rejected by Travelpayouts"))
        report = {"token_set": False, "links_missing": ["token", "marker", "trs"]}
        text = texts.diag_text(report, [("a", True), ("b", False), ("c", None)])
        self.assertIn("❌ رمز مزوّد الأسعار", text)
        self.assertIn("❌ روابط الشريك — ناقص:", text)
        self.assertTrue(text.endswith("✅ a\n❌ b\n⚪ c"))
        only_token = texts.diag_text({"token_set": False, "links_missing": ["token"]}, [])
        self.assertIn("تحتاج رمز مزوّد الأسعار أولًا", only_token)
