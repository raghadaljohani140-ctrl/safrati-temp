import unittest

from safrati import insights as ins


class InsightsTests(unittest.TestCase):
    def test_percentile_and_median(self):
        self.assertEqual(ins.percentile([], 0.5), 0.0)
        self.assertEqual(ins.percentile([7], 0.9), 7.0)
        self.assertEqual(ins.median([1, 2, 3, 4]), 2.5)
        self.assertEqual(ins.median([5, 1, 3]), 3)
        self.assertEqual(ins.percentile([10, 20, 30], 1), 30)
        self.assertEqual(ins.percentile([10, 20, 30], 5), 30)      # out of range is clamped

    def test_tiers_split_the_prices_in_thirds(self):
        prices = list(range(100, 190, 10))                          # nine prices
        cuts = ins.tier_cuts(prices)
        tiers = [ins.tier_of(p, cuts) for p in prices]
        self.assertEqual(tiers[0], "low")
        self.assertEqual(tiers[-1], "high")
        self.assertEqual(sorted(set(tiers)), ["high", "low", "mid"])
        self.assertTrue(tiers.index("mid") > tiers.index("low"))
        self.assertEqual(ins.tier_of(5, ins.tier_cuts([5, 5, 5])), "low")   # a flat list is all cheap

    def test_verdict_levels(self):
        population = [1000.0] * 10
        self.assertEqual(ins.verdict(700, population).level, "great")       # 30% under typical
        self.assertEqual(ins.verdict(850, population).level, "good")
        self.assertEqual(ins.verdict(1000, population).level, "typical")
        self.assertEqual(ins.verdict(1200, population).level, "high")
        v = ins.verdict(700, population)
        self.assertEqual((v.saving, v.typical, v.samples), (30, 1000, 10))

    def test_verdict_needs_enough_data(self):
        self.assertIsNone(ins.verdict(700, [1000.0] * 7))
        self.assertIsNone(ins.verdict(0, [1000.0] * 10))
        self.assertIsNone(ins.verdict(500, [0.0] * 10))

    def test_bar_length(self):
        self.assertEqual(ins.bar_length(1000, 1000, 2000), 1)          # the cheapest is the shortest bar
        self.assertEqual(ins.bar_length(2000, 1000, 2000), 5)          # the dearest is the longest
        self.assertEqual(ins.bar_length(1500, 1000, 2000), 3)
        self.assertEqual(ins.bar_length(1000, 1000, 1000), 3)          # all equal: a middle bar

    def test_alert_decision_with_a_target(self):
        d = lambda price, notified=None: ins.alert_decision(price, target=1500, base=2000, notified=notified)
        self.assertIsNone(d(1600))
        self.assertEqual(d(1500), "target")
        self.assertIsNone(d(1480, notified=1500))                       # a 1% move is not news
        self.assertEqual(d(1440, notified=1500), "target")              # a further 4% fall is

    def test_alert_decision_without_a_target(self):
        d = lambda price, base=2000: ins.alert_decision(price, target=None, base=base, notified=None)
        self.assertIsNone(d(1900))
        self.assertEqual(d(1840), "drop")                               # 8% under the reference price
        self.assertIsNone(d(1850, base=1840))                           # after a notice the reference is the notified price
        self.assertEqual(d(1690, base=1840), "drop")
        self.assertIsNone(ins.alert_decision(0, target=None, base=2000, notified=None))
        self.assertIsNone(ins.alert_decision(100, target=None, base=None, notified=None))

    def test_reference_follows_the_price_up_but_not_down(self):
        self.assertEqual(ins.next_reference(1000, None), 1000)
        self.assertEqual(ins.next_reference(1050, 1000), 1000)          # small moves keep the old reference
        self.assertEqual(ins.next_reference(900, 1000), 1000)           # a drop never lowers it by itself
        self.assertEqual(ins.next_reference(1200, 1000), 1200)         # a real rise moves it, so the way back down counts
        d = lambda price, ref: ins.alert_decision(price, target=None, base=ref, notified=None)
        self.assertEqual(d(1100, ins.next_reference(1200, 1000)), "drop")


if __name__ == "__main__":
    unittest.main()
