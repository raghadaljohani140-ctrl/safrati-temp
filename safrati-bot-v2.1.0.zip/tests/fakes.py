"""Offline stand-ins for Telegram and Travelpayouts, so the whole bot can be tested without a network."""
from __future__ import annotations

import calendar
import email
import email.policy
import json
import time
import urllib.parse
from datetime import date, timedelta

BOT_TOKEN = "123456789:" + "ABCDEFGHIJ" * 3 + "KLMNO"          # obviously fake
TP_TOKEN = "tp" + "0123456789abcdef" * 2                          # obviously fake
MARKER = "123456"
TRS = "654321"
NOW = calendar.timegm((2026, 10, 26, 12, 0, 0))                   # fixed "today"
TODAY = date(2026, 10, 26)

ROUTES = {
    "RUH": {
        "IST": 1100, "TZX": 1500, "AYT": 1300, "DXB": 700, "CAI": 900, "TBS": 1000, "BAK": 1400,
        "SJJ": 1800, "BKK": 2600, "MLE": 2400, "KUL": 2500, "SIN": 3200, "LON": 3000, "PAR": 2900,
        "ZRH": 3500, "TYO": 4800, "NYC": 5200, "AMM": 800, "BEY": 950, "CMN": 2100,
    },
    "JED": {"IST": 1000, "DXB": 800, "CAI": 700, "BKK": 2700},
}


class FakeTelegram:
    def __init__(self):
        self.calls: list[tuple[str, dict]] = []
        self.fail_once: dict[str, tuple[int, str]] = {}
        self.fail_always: dict[str, tuple[int, str]] = {}
        self.updates: list[list[dict]] = []
        self.blocked: set[int] = set()          # chats that blocked the bot: sending to them answers 403
        self.member: dict = {"status": "administrator", "can_post_messages": True}    # the answer of getChatMember
        self._next_id = 100

    def transport(self, url: str, body: bytes, timeout: float):
        assert url.startswith(f"https://api.telegram.org/bot{BOT_TOKEN}/"), "unexpected telegram url"
        method = url.rsplit("/", 1)[1]
        params = self._parse(body)
        self.calls.append((method, params))
        err = self.fail_once.pop(method, None) or self.fail_always.get(method)
        if not err and method in ("sendMessage", "editMessageText", "sendPhoto") and params.get("chat_id") in self.blocked:
            err = (403, "Forbidden: bot was blocked by the user")
        if err:
            code, desc = err
            return code, json.dumps({"ok": False, "error_code": code, "description": desc}).encode()
        if method == "getMe":
            result = {"id": 1, "is_bot": True, "username": "SafratiTravel_bot"}
        elif method == "getUpdates":
            result = self.updates.pop(0) if self.updates else []
            if not result:
                time.sleep(0.02)
        elif method == "getChatMember":
            result = self.member
        elif method in ("sendMessage", "editMessageText", "sendPhoto"):
            self._next_id += 1
            result = {"message_id": self._next_id}
        else:
            result = True
        return 200, json.dumps({"ok": True, "result": result}).encode()

    @staticmethod
    def _parse(body: bytes) -> dict:
        """JSON bodies as they are; an upload (multipart) as its text fields plus photo=(filename, size, first bytes)."""
        if not body.startswith(b"--"):
            return json.loads(body.decode("utf-8"))
        boundary = body.split(b"\r\n", 1)[0][2:].decode()
        message = email.message_from_bytes(
            b"Content-Type: multipart/form-data; boundary=" + boundary.encode() + b"\r\nMIME-Version: 1.0\r\n\r\n" + body,
            policy=email.policy.HTTP,
        )
        out: dict = {}
        for part in message.iter_parts():
            name = part.get_param("name", header="content-disposition")
            filename = part.get_filename()
            payload = part.get_payload(decode=True)
            if filename:
                out[name] = (filename, len(payload), payload[:8])
            else:
                text = payload.decode("utf-8")
                out[name] = json.loads(text) if name == "reply_markup" else text
        return out

    # helpers for assertions
    def of(self, method: str) -> list[dict]:
        return [p for m, p in self.calls if m == method]

    def sent(self) -> list[dict]:
        return self.of("sendMessage")

    def sent_to(self, chat_id) -> list[dict]:
        return [p for p in self.of("sendMessage") if p.get("chat_id") == chat_id]

    def last_text(self) -> str:
        return self.sent()[-1]["text"]

    def buttons(self, params: dict) -> list[dict]:
        rows = (params.get("reply_markup") or {}).get("inline_keyboard", [])
        return [b for row in rows for b in row]

    def reset(self) -> None:
        self.calls.clear()


class FakeTP:
    def __init__(self):
        self.calls: list[tuple[str, str, dict, bytes | None]] = []
        self.routes = {k: dict(v) for k, v in ROUTES.items()}
        self.answer_currency: str | None = None     # None = answer in the requested currency
        self.reject_currencies: set[str] = set()
        self.status = 200
        self.linkable = ("aviasales.com", "airalo.com")
        self.exact_missing: set[str] = set()
        self.hidden: set[tuple[str, str]] = set()      # routes only returned when show_to_affiliates=false
        self.factor: dict[tuple[str, str], float] = {}  # price multiplier per route (simulates a price drop)
        self.short_deals: set[tuple[str, str]] = set()  # routes with an extra cheap 2-day trip on the 20th
        self.weekend_deals: set[tuple[str, str]] = set()  # routes with Thursday-to-Saturday trips
        self.stays = (3, 7, 10)                         # trip lengths the provider knows
        self.exact_extra = 0                            # riyals added to every exact-day answer (makes nearby days look cheaper)
        self.crowd = 0                                  # cheap flights inside the country that fill an "everything from this city" answer
        self.market_days: dict[str, int] = {}           # market -> days a month the provider knows (a missing market knows every day)
        self.slow: dict[tuple, float] = {}              # (origin, destination or None) -> seconds the provider takes to answer
        self.link_error: str | None = None              # the provider refuses every partner link with this message
        self.links_http: tuple[int, dict] | None = None  # ... or answers the whole links request with this status and body

    def transport(self, method: str, url: str, headers: dict, body: bytes | None, timeout: float):
        self.calls.append((method, url, dict(headers), body))
        parts = urllib.parse.urlsplit(url)
        params = dict(urllib.parse.parse_qsl(parts.query))
        if parts.path.endswith("/prices_for_dates"):
            return self._prices(params)
        if parts.path.endswith("/links/v1/create"):
            return self._links(json.loads(body.decode()))
        return 404, b"{}"

    def _prices(self, params: dict):
        if self.status != 200:
            return self.status, json.dumps({"success": False, "error": "boom"}).encode()
        cur = params.get("currency", "rub")
        if cur in self.reject_currencies:
            return 400, json.dumps({"success": False, "error": "Unknown currency"}).encode()
        origin, dest, when = params.get("origin"), params.get("destination"), params.get("departure_at", "2026-11")
        month = when[:7]
        if self.slow.get((origin, dest)):
            time.sleep(self.slow[(origin, dest)])
        cap = self.market_days.get(params.get("market", ""), self.market_days.get("*"))     # "*" = every market not named
        one_way = params.get("one_way") == "true"
        rows = []
        for code, base in self.routes.get(origin, {}).items():
            if dest and code != dest:
                continue
            if (origin, code) in self.hidden and params.get("show_to_affiliates") != "false":
                continue
            factor = self.factor.get((origin, code), 1.0)
            p = base + (int(month[-2:]) % 3) * 50
            specs = []          # (departure day, return day or None, price)
            if len(when) == 10:                       # one exact day: one answer, or none when the cache has nothing
                if when in self.exact_missing:
                    continue
                back = None if one_way else (params.get("return_at") or (date.fromisoformat(when) + timedelta(days=7)).isoformat())
                specs.append((when, back, p + 30 + self.exact_extra))
            else:
                kept = 0
                for d in range(1, 29):
                    dep = date.fromisoformat(f"{month}-{d:02d}")
                    if dep.isoformat() < TODAY.isoformat():
                        continue                      # the provider only knows tickets for today and later
                    if cap is not None:
                        if kept >= cap:
                            break
                        kept += 1
                    if one_way:
                        specs.append((dep.isoformat(), None, p // 2 + 6 * abs(d - 12)))
                        continue
                    for stay in self.stays:
                        price = p if (d == 12 and stay == 7) else p + 25 + 6 * abs(d - 12) + 15 * abs(stay - 7)
                        specs.append((dep.isoformat(), (dep + timedelta(days=stay)).isoformat(), price))
                    if (origin, code) in self.short_deals and d == 20:
                        specs.append((dep.isoformat(), (dep + timedelta(days=2)).isoformat(), p - 100))
                    if (origin, code) in self.weekend_deals and dep.weekday() == 3:
                        specs.append((dep.isoformat(), (dep + timedelta(days=2)).isoformat(), p - 40 + d))
            for dep, ret, value in specs:
                dd = dep[8:10] + dep[5:7]
                back_part = (ret[8:10] + ret[5:7]) if ret else ""
                rows.append({
                    "origin": origin, "destination": code, "price": round(value * factor), "airline": "TK",
                    "departure_at": f"{dep}T10:00:00+03:00", "return_at": f"{ret}T10:00:00+03:00" if ret else "",
                    "transfers": 0, "duration_to": 330, "link": f"/search/{origin}{dd}{code}{back_part}1?t=abc",
                })
        if self.crowd and not dest:
            for i in range(self.crowd):
                dep = f"{month}-{1 + i % 28:02d}"
                back = (date.fromisoformat(dep) + timedelta(days=7)).isoformat()
                rows.append({
                    "origin": origin, "destination": "AHB", "price": 100 + i % 40, "airline": "XY",
                    "departure_at": f"{dep}T08:00:00+03:00", "return_at": f"{back}T08:00:00+03:00",
                    "transfers": 0, "duration_to": 90, "link": f"/search/{origin}{dep[8:10]}{dep[5:7]}AHB1?t=abc",
                })
        rows.sort(key=lambda r: (r["price"], r["departure_at"]))
        if params.get("unique") == "true" and not dest:
            seen, unique_rows = set(), []
            for r in rows:
                if r["destination"] not in seen:
                    seen.add(r["destination"])
                    unique_rows.append(r)
            rows = unique_rows
        rows = rows[: int(params.get("limit", 30))]
        return 200, json.dumps({"success": True, "currency": self.answer_currency or cur, "data": rows}).encode()

    def _links(self, body: dict):
        if self.links_http:
            return self.links_http[0], json.dumps(self.links_http[1]).encode()
        out = []
        for item in body["links"]:
            url = item["url"]
            if self.link_error:
                out.append({"url": url, "code": "error", "message": self.link_error})
            elif any(host in url for host in self.linkable):
                out.append({
                    "url": url, "code": "success",
                    "partner_url": "https://tp.media/r?marker=%s&trs=%s&u=%s" % (body["marker"], body["trs"], urllib.parse.quote(url, safe="")),
                })
            else:
                out.append({"url": url, "code": "error", "message": "unsupported domain"})
        return 200, json.dumps({"result": {"links": out}}).encode()

    def price_calls(self) -> list[tuple[str, str, dict, bytes | None]]:
        return [c for c in self.calls if "prices_for_dates" in c[1]]


def text_update(uid: int, text: str, *, update_id: int = 1, chat_type: str = "private", message_id: int = 7) -> dict:
    return {
        "update_id": update_id,
        "message": {
            "message_id": message_id,
            "from": {"id": uid, "is_bot": False, "first_name": "t"},
            "chat": {"id": uid, "type": chat_type},
            "text": text,
        },
    }


def callback_update(uid: int, data: str, *, update_id: int = 1, markup: dict | None = None, message_id: int = 50) -> dict:
    message = {"message_id": message_id, "chat": {"id": uid, "type": "private"}}
    if markup:
        message["reply_markup"] = markup
    return {
        "update_id": update_id,
        "callback_query": {"id": f"cb{update_id}", "from": {"id": uid, "is_bot": False}, "message": message, "data": data},
    }
