"""The channel's welcome post: a picture with a button that opens the bot, published by an admin."""
import json
import unittest

from safrati import data, telegram, texts
from tests.fakes import BOT_TOKEN, FakeTelegram
from tests.helpers import html_errors
from tests.test_channel import ADMIN, CHANNEL, ChannelCase

PNG = b"\x89PNG\r\n\x1a\n"


class PictureFileTests(unittest.TestCase):
    def test_the_picture_ships_with_the_bot(self):
        image = data.welcome_image()
        self.assertIsNotNone(image)
        self.assertTrue(image.startswith(PNG))
        self.assertLess(len(image), 400_000)                    # Telegram accepts photos up to 10 MB; keep the package small

    def test_the_caption_is_valid_telegram_html(self):
        self.assertEqual(html_errors(texts.WELCOME_POST), [])
        self.assertLess(len(texts.WELCOME_POST), 1024)           # the limit of a photo caption


class MultipartTests(unittest.TestCase):
    def test_body_has_fields_and_the_file(self):
        body = telegram.multipart_body({"chat_id": "@x", "reply_markup": {"a": [1]}}, {"photo": ("p.png", PNG + b"data", "image/png")})
        self.assertTrue(body.startswith(f"--{telegram.BOUNDARY}".encode()))
        self.assertTrue(body.endswith(f"--{telegram.BOUNDARY}--\r\n".encode()))
        self.assertIn(b'name="chat_id"\r\n\r\n@x\r\n', body)
        self.assertIn(b'{"a": [1]}', body)
        self.assertIn(b'name="photo"; filename="p.png"', body)
        self.assertIn(PNG + b"data", body)

    def test_the_fake_reads_it_back(self):
        body = telegram.multipart_body({"chat_id": "5", "caption": "عربي"}, {"photo": ("p.png", PNG + b"xy", "image/png")})
        parsed = FakeTelegram._parse(body)
        self.assertEqual(parsed["caption"], "عربي")
        self.assertEqual(parsed["photo"][0], "p.png")
        self.assertEqual(parsed["photo"][1], len(PNG) + 2)


class WelcomePostTests(ChannelCase):
    async def test_only_an_admin_can_ask_for_it(self):
        await self.say(5, "/welcome")
        self.assertEqual(self.tg.of("sendPhoto"), [])
        self.assertEqual(self.last_text_to(5), texts.ADMIN_ONLY)

    def last_text_to(self, chat_id):
        return self.tg.sent_to(chat_id)[-1]["text"]

    async def test_the_preview_shows_the_picture_the_bot_button_and_a_publish_button(self):
        await self.say(ADMIN, "/welcome")
        photos = self.tg.of("sendPhoto")
        self.assertEqual(len(photos), 1)
        sent = photos[0]
        self.assertEqual(sent["chat_id"], str(ADMIN))
        self.assertEqual(sent["caption"], texts.WELCOME_POST)
        self.assertEqual(sent["parse_mode"], "HTML")
        self.assertTrue(sent["photo"][2].startswith(PNG))
        buttons = self.tg.buttons(sent)
        self.assertEqual(buttons[0]["url"], "https://t.me/SafratiTravel_bot")
        self.assertEqual(buttons[0]["text"], texts.WELCOME_BUTTON)
        self.assertEqual(buttons[-1]["callback_data"], "pub:welcome")
        self.assertEqual(self.channel_posts(), [])               # nothing reaches the channel before the admin agrees

    async def test_publishing_posts_the_picture_with_only_the_bot_button(self):
        await self.say(ADMIN, "/welcome")
        self.tg.reset()
        await self.tap(ADMIN, "pub:welcome")
        photos = self.tg.of("sendPhoto")
        self.assertEqual([p["chat_id"] for p in photos], [CHANNEL])
        buttons = self.tg.buttons(photos[0])
        self.assertEqual([b.get("url") for b in buttons], ["https://t.me/SafratiTravel_bot"])
        self.assertEqual(self.last_text_to(ADMIN), texts.DEALS_POSTED)

    async def test_the_publish_button_is_admin_only(self):
        await self.tap(5, "pub:welcome")
        self.assertEqual(self.tg.of("sendPhoto"), [])
        self.assertEqual(self.last_text_to(5), texts.ADMIN_ONLY)

    async def test_a_telegram_refusal_is_reported_not_raised(self):
        self.tg.fail_always["sendPhoto"] = (403, "Forbidden: bot is not a member of the channel chat")
        await self.tap(ADMIN, "pub:welcome")
        self.assertIn("403", self.last_text_to(ADMIN))

    async def test_without_a_public_channel_there_is_no_publish_button(self):
        self.build(CHANNEL_URL="")
        self.db.add_admin(ADMIN)
        await self.say(ADMIN, "/welcome")
        buttons = self.tg.buttons(self.tg.of("sendPhoto")[0])
        self.assertNotIn("pub:welcome", [b.get("callback_data") for b in buttons])
        await self.tap(ADMIN, "pub:welcome")
        self.assertEqual(self.tg.of("sendPhoto")[-1]["chat_id"] != CHANNEL, True)
        self.assertEqual(self.last_text_to(ADMIN), texts.AUTOPOST_NO_CHANNEL)

    async def test_a_missing_picture_is_explained(self):
        original = data.welcome_image
        data.welcome_image = lambda: None
        self.addCleanup(setattr, data, "welcome_image", original)
        await self.say(ADMIN, "/welcome")
        self.assertEqual(self.tg.of("sendPhoto"), [])
        self.assertEqual(self.last_text_to(ADMIN), texts.WELCOME_NO_IMAGE)

    async def test_the_admin_help_mentions_it(self):
        self.assertIn("/welcome", texts.ADMIN_OK)


if __name__ == "__main__":
    unittest.main()
