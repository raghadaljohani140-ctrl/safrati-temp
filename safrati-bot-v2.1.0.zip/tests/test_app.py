import asyncio
import json
import random
import re
import tempfile
import unittest
from pathlib import Path

from safrati import data, texts
from safrati.app import SafratiBot
from safrati.config import load_settings
from safrati.db import DB
from safrati.telegram import TelegramAPI
from safrati.tp import TravelpayoutsClient
from tests.fakes import (
    BOT_TOKEN, MARKER, NOW, TP_TOKEN, TRS, FakeTP, FakeTelegram, callback_update, text_update,
)
from tests.helpers import html_errors

ADMIN_CODE = "adm1n-code-123"
PRICE = re.compile(r"من حوالي ([\d,]+) ر\.س")


def prices_in(text: str) -> list[int]:
    return [int(m.replace(",", "")) for m in PRICE.findall(text)]


def dest_in(text: str) -> data.Destination | None:
    for d in data.destinations():
        if f"<b>{d.flag} {d.ar}</b>" in text:
            return d
    return None


class AppCase(unittest.IsolatedAsyncioTestCase):
    def build(self, *, tp_enabled: bool = True, **extra) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        env = {
            "BOT_TOKEN": BOT_TOKEN, "TP_TOKEN": TP_TOKEN if tp_enabled else "", "TP_MARKER": MARKER, "TP_TRS": TRS,
            "ADMIN_CODE": ADMIN_CODE, "HEARTBEAT_PATH": str(Path(self.tmp.name) / "hb"),
            "CHANNEL_URL": "https://t.me/safrati_travel",
        }
        env.update(extra)
        self.settings = load_settings(env)
        self.tg, self.fake = FakeTelegram(), FakeTP()
        self.api = TelegramAPI(BOT_TOKEN, transport=self.tg.transport)
        self.db = DB(":memory:")
        self.addCleanup(self.db.close)
        self.tp = TravelpayoutsClient(
            self.settings.tp_token, self.settings.tp_marker, self.settings.tp_trs, self.settings.currency,
            market=self.settings.tp_market, transport=self.fake.transport, clock=lambda: NOW,
        )
        self.bot = SafratiBot(
            self.settings, self.api, self.db, self.tp,
            bot_username="SafratiTravel_bot", clock=lambda: NOW, rng=random.Random(7),
        )

    async def asyncSetUp(self):
        self.build()
        self.bot.rate_max = 10_000      # the rate limit has its own tests

    async def say(self, uid: int, text: str) -> None:
        await self.bot.process(text_update(uid, text))

    async def tap(self, uid: int, payload: str, **kw) -> None:
        await self.bot.process(callback_update(uid, payload, **kw))

    def last(self) -> dict:
        return self.tg.sent()[-1]

    def all_urls(self, params: dict) -> list[str]:
        return [b["url"] for b in self.tg.buttons(params) if "url" in b]

    def url_buttons(self, params: dict) -> list[str]:
        """Booking and service links (share links and the channel link are not counted)."""
        return [u for u in self.all_urls(params) if not u.startswith("https://t.me/")]

    def data_buttons(self, params: dict) -> list[str]:
        return [b["callback_data"] for b in self.tg.buttons(params) if "callback_data" in b]


class ConversationTests(AppCase):
    async def test_start_shows_welcome_and_menu(self):
        self.db.set_onboarded(1)
        await self.say(1, "/start")
        msg = self.last()
        self.assertIn("سفرتي", msg["text"])
        self.assertIn("عمولة", msg["text"])  # affiliate disclosure is visible from the first message
        data_ = self.data_buttons(msg)
        for expected in ("go", "cheap", "we", "sur", "bp", "al", "sl", "st"):
            self.assertIn(expected, data_)
        urls = self.all_urls(msg)
        self.assertTrue(any("t.me/share/url" in u for u in urls))
        self.assertIn("https://t.me/safrati_travel", urls)
        self.assertEqual(msg["parse_mode"], "HTML")

    async def test_budget_list_respects_ticket_share(self):
        await self.say(1, "5000")
        msg = self.last()
        prices = prices_in(msg["text"])
        self.assertTrue(1 <= len(prices) <= 5)
        self.assertTrue(all(p <= 2000 for p in prices), prices)   # 40% of 5000 kept for the ticket
        self.assertIn("ميزانيتك 5,000", msg["text"])
        self.assertIn("من الرياض", msg["text"])
        self.assertEqual(prices, sorted(prices))
        picks = [d for d in self.data_buttons(msg) if d.startswith("d:")]
        self.assertEqual(len(picks), len(prices))

    async def test_ticket_only_budget_allows_higher_prices(self):
        await self.say(1, "ميزانيتي 5000 للتذكرة")
        msg = self.last()
        self.assertIn("(للتذكرة فقط)", msg["text"])
        self.assertTrue(all(p <= 5000 for p in prices_in(msg["text"])))
        await self.say(2, "5000")
        self.assertIn("(للرحلة كلها)", self.last()["text"])

    async def test_when_nothing_fits_the_cheapest_are_shown_honestly(self):
        await self.say(1, "400")
        msg = self.last()
        self.assertIn("ما وجدت تذاكر ضمن هذا الحد", msg["text"])
        self.assertEqual(prices_in(msg["text"]), sorted(prices_in(msg["text"])))
        self.assertGreaterEqual(min(prices_in(msg["text"])), 700)
        self.assertNotIn("bud:400:f:", "".join(self.data_buttons(msg)).replace("bud:400:t:", ""))  # no reroll of an empty match

    async def test_reroll_edits_the_same_message(self):
        await self.say(1, "5000")
        self.tg.reset()
        await self.tap(1, "bud:5000:f:", message_id=50)
        edits = self.tg.of("editMessageText")
        self.assertEqual(len(edits), 1)
        self.assertEqual(edits[0]["message_id"], 50)
        self.assertEqual(self.tg.sent(), [])

    async def test_switching_to_ticket_only_reprices(self):
        await self.say(1, "5000")
        self.tg.reset()
        await self.tap(1, "bud:5000:t:", message_id=50)
        text = self.tg.of("editMessageText")[0]["text"]
        self.assertIn("(للتذكرة فقط)", text)

    async def test_tags_filter_the_budget_list(self):
        await self.say(1, "بحر 6000")
        msg = self.last()
        for d in data.destinations():
            if f"<b>{d.flag} {d.ar}</b>" in msg["text"]:
                self.assertIn("beach", d.tags, d.iata)
        self.assertIn("bud:6000:f:b", self.data_buttons(msg) + ["bud:6000:f:b"])  # code for beach is "b"

    async def test_unmatched_taste_is_relaxed_with_a_note(self):
        self.fake.routes["RUH"] = {"IST": 1100, "DXB": 700}
        await self.say(1, "جبال 6000")
        msg = self.last()
        self.assertIn("ما لقيت ما يطابق ذوقك", msg["text"])
        self.assertTrue(prices_in(msg["text"]))

    async def test_destination_card_has_price_visa_and_partner_link(self):
        await self.say(1, "اسطنبول")
        msg = self.last()
        self.assertIn("1,100 ر.س", msg["text"])
        self.assertIn("بدون تأشيرة", msg["text"])
        self.assertIn("وقت البحث", msg["text"])
        urls = self.url_buttons(msg)
        self.assertTrue(urls[0].startswith("https://tp.media/r?marker=" + MARKER))
        labels = [b["text"] for b in self.tg.buttons(msg)]
        self.assertTrue(any(l.startswith("✈️ ") and "ر.س" in l for l in labels), labels)
        self.assertIn("📅 حدّد التاريخ", labels)
        self.assertEqual(html_errors(msg["text"]), [])

    async def test_card_title_does_not_repeat_when_city_and_country_match(self):
        await self.say(1, "سنغافورة")
        first_line = self.last()["text"].splitlines()[0]
        self.assertEqual(first_line, "🌍 <b>🇸🇬 سنغافورة</b>")

    async def test_card_without_partner_program_uses_marker_link(self):
        self.fake.linkable = ()
        await self.say(1, "دبي")
        urls = self.url_buttons(self.last())
        self.assertTrue(urls[0].startswith("https://www.aviasales.com/search/RUH"))
        self.assertIn(f"marker={MARKER}", urls[0])

    async def test_country_with_several_cities_offers_a_choice(self):
        await self.say(1, "تركيا")
        msg = self.last()
        self.assertEqual(sorted(d for d in self.data_buttons(msg) if d.startswith("d:")), ["d:AYT", "d:IST", "d:TZX"])
        self.assertIn("تركيا", msg["text"])
        self.tg.reset()
        await self.tap(1, "d:TZX")
        self.assertIn("طرابزون", self.last()["text"])
        self.assertIn("1,500 ر.س", self.last()["text"])

    async def test_typing_a_number_picks_from_the_last_list(self):
        await self.say(1, "تركيا")
        order = [d for d in self.data_buttons(self.last()) if d.startswith("d:")]
        self.tg.reset()
        await self.say(1, "2")
        shown = dest_in(self.last()["text"])
        self.assertEqual("d:" + shown.iata, order[1])

    async def test_surprise_never_repeats_until_the_pool_is_used(self):
        seen = []
        for _ in range(12):
            await self.say(1, "فاجئني")
            seen.append(dest_in(self.last()["text"]).iata)
        self.assertEqual(len(set(seen)), 12, seen)

    async def test_mood_surprise_keeps_the_mood(self):
        for _ in range(6):
            await self.tap(1, "mood:c")
            dest = dest_in(self.last()["text"])
            self.assertIn("calm", dest.tags)
        again = [d for d in self.data_buttons(self.last()) if d.startswith("sur")]
        self.assertEqual(again, ["sur:c"])

    async def test_origin_in_the_message_is_used_and_remembered(self):
        await self.say(1, "من جدة 5000")
        self.assertIn("من جدة", self.last()["text"])
        self.assertEqual(self.db.touch_user(1)["origin"], "JED")
        await self.say(1, "دبي")
        self.assertIn("800 ر.س", self.last()["text"])  # the Jeddah fare in the fake data

    async def test_unknown_text_and_small_talk(self):
        await self.say(1, "qwerty zxcv")
        self.assertIn("ما فهمت", self.last()["text"])
        await self.say(1, "شكرا")
        self.assertIn("العفو", self.last()["text"])
        await self.say(1, "السلام عليكم")
        self.assertIn("سفرتي", self.last()["text"])
        await self.say(1, "محفوظاتي")
        self.assertIn("ما حفظت", self.last()["text"])

    async def test_non_text_messages_get_a_hint(self):
        update = text_update(1, "")
        update["message"].pop("text")
        update["message"]["photo"] = [{"file_id": "x"}]
        await self.bot.process(update)
        self.assertIn("أرسل لي نصًا", self.last()["text"])

    async def test_groups_and_bots_are_ignored(self):
        await self.bot.process(text_update(1, "/start", chat_type="group"))
        bot_update = text_update(2, "/start")
        bot_update["message"]["from"]["is_bot"] = True
        await self.bot.process(bot_update)
        self.assertEqual(self.tg.calls, [])
        self.assertEqual(self.db.stats()["users"], 0)

    async def test_long_text_is_truncated_not_rejected(self):
        await self.say(1, "دبي " + "ا" * 5000)
        self.assertIn("دبي", self.last()["text"])

    async def test_visa_button_explains_and_points_to_the_embassy(self):
        await self.tap(1, "visa:LON")
        text = self.last()["text"]
        self.assertIn("آخر تحقق", text)
        self.assertIn("السفارة", text)


class SavedAndSettingsTests(AppCase):
    async def test_save_toggles_the_button_and_lists_the_destination(self):
        await self.say(1, "اسطنبول")
        markup = self.last()["reply_markup"]
        self.tg.reset()
        await self.tap(1, "sv:IST", markup=markup)
        self.assertEqual(self.tg.of("answerCallbackQuery")[0]["text"], texts.SAVED_TOAST)
        edited = self.tg.of("editMessageReplyMarkup")[0]["reply_markup"]
        flat = [b.get("callback_data") for row in edited["inline_keyboard"] for b in row]
        self.assertIn("us:IST", flat)
        self.assertNotIn("sv:IST", flat)
        self.assertTrue(self.db.is_saved(1, "IST"))
        await self.say(1, "/saved")
        self.assertIn("إسطنبول", self.last()["text"])
        self.tg.reset()
        await self.tap(1, "us:IST", markup=edited)
        self.assertFalse(self.db.is_saved(1, "IST"))
        self.assertIn("sv:IST", [b.get("callback_data") for row in self.tg.of("editMessageReplyMarkup")[0]["reply_markup"]["inline_keyboard"] for b in row])

    async def test_saved_list_is_capped(self):
        for d in list(data.destinations())[:30]:
            self.db.save(1, d.iata)
        self.tg.reset()
        await self.tap(1, "sv:PRG")
        self.assertFalse(self.db.is_saved(1, "PRG"))
        self.assertIn("ممتلئة", self.tg.of("answerCallbackQuery")[0]["text"])

    async def test_settings_change_origin_and_visa_filter_in_place(self):
        await self.say(1, "/settings")
        self.assertIn("الرياض", self.last()["text"])
        self.tg.reset()
        await self.tap(1, "og:DMM", message_id=60)
        self.assertEqual(self.db.touch_user(1)["origin"], "DMM")
        edit = self.tg.of("editMessageText")[0]
        self.assertEqual(edit["message_id"], 60)
        self.assertIn("الدمام", edit["text"])
        await self.tap(1, "vo:1", message_id=60)
        self.assertEqual(self.db.touch_user(1)["visa_only"], 1)
        self.assertIn("مفعّل", self.tg.of("editMessageText")[-1]["text"])

    async def test_visa_only_filter_never_shows_a_visa_destination(self):
        await self.tap(1, "vo:1")
        await self.say(1, "ميزانيتي 20000 للتذكرة")
        text = self.last()["text"]
        rows = [line for line in text.splitlines() if re.match(r"^\d+\. ", line)]
        self.assertTrue(rows)
        self.assertTrue(all(line.endswith("✅") for line in rows), rows)
        for _ in range(15):
            await self.say(1, "فاجئني")
            dest = dest_in(self.last()["text"])
            self.assertTrue(texts.visa_ok(dest), dest.iata)

    async def test_visa_only_with_no_match_explains_how_to_relax(self):
        self.fake.routes["RUH"] = {"LON": 3000, "PAR": 2900}
        await self.tap(1, "vo:1")
        await self.say(1, "ميزانيتي 20000")
        self.assertIn("فلتر", self.last()["text"])

    async def test_bad_settings_values_are_ignored(self):
        await self.tap(1, "og:XXX")
        await self.tap(1, "vo:9")
        self.assertEqual(self.db.touch_user(1)["origin"], "RUH")
        self.assertEqual(self.db.touch_user(1)["visa_only"], 0)


class LimitAndAdminTests(AppCase):
    async def test_daily_search_limit(self):
        self.build(DAILY_SEARCH_LIMIT="2")
        for _ in range(2):
            await self.say(1, "دبي")
        self.assertNotEqual(self.last()["text"], texts.LIMIT_REACHED)
        await self.say(1, "دبي")
        self.assertEqual(self.last()["text"], texts.LIMIT_REACHED)
        await self.say(2, "دبي")           # another person is unaffected
        self.assertNotEqual(self.last()["text"], texts.LIMIT_REACHED)
        await self.say(1, "/about")        # non-search commands still work
        self.assertIn("سفرتي", self.last()["text"])

    async def test_admin_code_works_once_and_is_deleted(self):
        await self.say(1, "/admin wrong-code-123")
        self.assertEqual(self.last()["text"], texts.ADMIN_BAD)
        self.assertFalse(self.db.is_admin(1))
        self.tg.reset()
        await self.bot.process(text_update(1, f"/admin {ADMIN_CODE}", message_id=77))
        self.assertTrue(self.db.is_admin(1))
        self.assertEqual(self.tg.of("deleteMessage"), [{"chat_id": 1, "message_id": 77}])
        await self.say(2, f"/admin {ADMIN_CODE}")      # the code is burned after first use
        self.assertFalse(self.db.is_admin(2))
        self.assertEqual(self.last()["text"], texts.ADMIN_OFF)

    async def test_admin_guessing_is_throttled(self):
        for _ in range(6):
            await self.say(1, "/admin guess-guess-1")
        await self.say(1, f"/admin {ADMIN_CODE}")      # even the right code is refused during the lock-out
        self.assertFalse(self.db.is_admin(1))

    async def test_admin_disabled_without_a_configured_code(self):
        self.build(ADMIN_CODE="")
        await self.say(1, "/admin anything-at-all")
        self.assertEqual(self.last()["text"], texts.ADMIN_OFF)

    async def test_stats_and_diag_are_admin_only(self):
        await self.say(5, "/stats")
        self.assertEqual(self.last()["text"], texts.ADMIN_ONLY)
        await self.say(5, "/diag")
        self.assertEqual(self.last()["text"], texts.ADMIN_ONLY)
        self.db.add_admin(5)
        await self.say(5, "/stats")
        self.assertIn("المستخدمون", self.last()["text"])
        await self.say(5, "/diag")
        diag = self.last()["text"]
        self.assertIn("✅ بحث تجريبي", diag)
        self.assertIn("tp.media", diag)
        self.assertIn("Airalo", diag)
        self.assertNotIn(TP_TOKEN, diag)
        self.assertEqual(html_errors(diag), [])

    async def test_admin_is_exempt_from_the_daily_limit(self):
        self.build(DAILY_SEARCH_LIMIT="1")
        self.db.add_admin(9)
        for _ in range(3):
            await self.say(9, "دبي")
        self.assertNotEqual(self.last()["text"], texts.LIMIT_REACHED)


class ServicesTests(AppCase):
    async def test_services_only_for_programs_that_made_a_partner_link(self):
        await self.say(1, "دبي")
        self.assertIn("svc:DXB", self.data_buttons(self.last()))
        self.tg.reset()
        await self.tap(1, "svc:DXB")
        urls = self.url_buttons(self.last())
        self.assertEqual(len(urls), 1)            # only Airalo is "joined" in the fake
        self.assertTrue(urls[0].startswith("https://tp.media/"))
        self.assertIn("عمولة", self.last()["text"])

    async def test_no_services_button_when_nothing_is_joined(self):
        self.fake.linkable = ("aviasales.com",)
        await self.say(1, "دبي")
        self.assertNotIn("svc:DXB", self.data_buttons(self.last()))


class DegradedModeTests(AppCase):
    async def test_without_a_price_token_the_bot_still_suggests(self):
        self.build(tp_enabled=False)
        await self.say(1, "4000")
        text = self.last()["text"]
        self.assertIn("حسب مستوى التكلفة", text)
        self.assertEqual(prices_in(text), [])
        await self.say(1, "دبي")
        card = self.last()
        self.assertIn("غير مفعّل", card["text"])
        self.assertEqual(self.url_buttons(card), [])
        await self.say(1, "فاجئني")
        self.assertIn("🌍", self.last()["text"])
        self.assertEqual(self.fake.calls, [])

    async def test_provider_outage_falls_back_without_errors(self):
        self.fake.status = 500
        await self.say(1, "4000")
        self.assertIn("حسب مستوى التكلفة", self.last()["text"])
        await self.say(1, "دبي")
        self.assertIn("تعذّر جلب السعر", self.last()["text"])
        self.assertEqual(self.url_buttons(self.last()), [])

    async def test_empty_provider_answer_falls_back_too(self):
        self.fake.routes = {}
        await self.say(1, "4000")
        self.assertIn("حسب مستوى التكلفة", self.last()["text"])
        await self.say(1, "دبي")
        self.assertIn("ما عندي سعر محفوظ", self.last()["text"])

    async def test_low_budget_without_prices_suggests_economy_only(self):
        self.build(tp_enabled=False)
        await self.say(1, "1500")
        for d in data.destinations():
            if f"<b>{d.flag} {d.ar}</b>" in self.last()["text"]:
                self.assertEqual(d.cost, "low", d.iata)

    async def test_dollar_prices_are_converted_to_riyals(self):
        self.fake.reject_currencies = {"sar"}
        await self.say(1, "ميزانيتي 20000 للتذكرة")
        prices = prices_in(self.last()["text"])
        self.assertTrue(prices)
        self.assertTrue(all(p % 1 == 0 for p in prices))
        await self.say(1, "اسطنبول")
        self.assertIn("$1,100", self.last()["text"])      # the card shows the provider's own currency

    async def test_unsupported_currency_never_shows_wrong_riyals(self):
        self.fake.answer_currency = "rub"
        await self.say(1, "ميزانيتي 20000 للتذكرة")
        self.assertIn("حسب مستوى التكلفة", self.last()["text"])


class RobustnessTests(AppCase):
    async def test_rejected_button_url_is_dropped_and_message_still_arrives(self):
        self.tg.fail_once["sendMessage"] = (400, "Bad Request: BUTTON_URL_INVALID")
        await self.say(1, "دبي")
        sent = self.tg.sent()
        self.assertEqual(len(sent), 2)
        self.assertTrue(self.url_buttons(sent[0]))
        self.assertEqual(self.url_buttons(sent[1]), [])
        self.assertIn("دبي", sent[1]["text"])

    async def test_rate_limit_silences_floods_but_clears_button_spinners(self):
        self.bot.rate_max = 5
        for i in range(8):
            await self.bot.process(text_update(1, "/about", update_id=i))
        self.assertEqual(len(self.tg.sent()), 5)
        await self.tap(1, "menu")
        self.assertEqual(len(self.tg.sent()), 5)
        self.assertTrue(self.tg.of("answerCallbackQuery"))
        await self.say(2, "/about")          # someone else is not affected
        self.assertEqual(len(self.tg.sent()), 6)

    async def test_unexpected_error_sends_an_apology_and_keeps_going(self):
        async def boom(*a, **k):
            raise RuntimeError("boom")
        original = self.bot.on_text
        self.bot.on_text = boom
        with self.assertLogs("safrati.app", level="ERROR"):
            await self.say(1, "دبي")
        self.assertEqual(self.last()["text"], texts.ERROR)
        self.bot.on_text = original
        await self.say(1, "دبي")
        self.assertIn("دبي", self.last()["text"])

    async def test_blocked_user_does_not_crash_processing(self):
        self.tg.fail_always["sendMessage"] = (403, "Forbidden: bot was blocked by the user")
        await self.say(1, "/start")
        self.tg.fail_always.clear()
        await self.say(2, "/start")
        self.assertIn("سفرتي", self.last()["text"])

    async def test_garbage_callbacks_are_harmless(self):
        for payload in ("", "x", "d:", "d:ZZZ", "bud:abc:f:", "bud:5000:x:", "bud:5:f:", "bud:5000:f:zzz", "sv:ZZZ", "visa:???", "mood:", "sur:zz", "og:", "::::"):
            await self.tap(1, payload)
        await self.bot.process({"update_id": 1, "callback_query": {"id": "x", "from": {"id": 1}, "data": "menu"}})  # no message
        await self.bot.process({"update_id": 2})
        await self.bot.process({"update_id": 3, "message": {"text": "hi"}})
        self.assertTrue(True)

    async def test_two_people_at_once_do_not_interfere(self):
        await asyncio.gather(*(self.bot.process(text_update(uid, "5000", update_id=uid)) for uid in range(1, 9)))
        self.assertEqual(len(self.tg.sent()), 8)
        self.assertLessEqual(len(self.fake.price_calls()), 3)   # one shared lookup for all eight

    async def test_every_message_is_valid_telegram_html_and_short(self):
        for text in ("/start", "/about", "/privacy", "5000", "ميزانيتي 20000 للتذكرة", "اسطنبول", "تركيا", "فاجئني", "بحر 4000", "/settings", "/saved"):
            await self.say(1, text)
        await self.tap(1, "visa:ZRH")
        for dest in data.destinations():
            await self.tap(2, f"d:{dest.iata}")
        for params in self.tg.sent():
            self.assertEqual(html_errors(params["text"]), [], params["text"])
            self.assertLess(len(params["text"]), 4096)
            for row in params["reply_markup"]["inline_keyboard"] if "reply_markup" in params else []:
                for b in row:
                    self.assertLessEqual(len(b.get("callback_data", "")), 64)
                    self.assertTrue(b["text"])

    async def test_no_secret_ever_reaches_a_message_or_a_price_request(self):
        for text in ("/start", "5000", "دبي", "فاجئني", f"/admin {ADMIN_CODE}", "/stats", "/diag"):
            await self.say(1, text)
        blob = json.dumps(self.tg.calls, ensure_ascii=False)
        for secret in (BOT_TOKEN, BOT_TOKEN.split(":")[1], TP_TOKEN):
            self.assertNotIn(secret, blob)
        self.assertNotIn(ADMIN_CODE, json.dumps([p for m, p in self.tg.calls if m in ("sendMessage", "editMessageText")], ensure_ascii=False))
        for _method, url, headers, body in self.fake.calls:
            self.assertNotIn(TP_TOKEN, url)
            self.assertNotIn(BOT_TOKEN, url)


class PollingLoopTests(AppCase):
    async def test_serve_processes_updates_saves_offset_and_beats(self):
        self.tg.updates = [[text_update(1, "/start", update_id=10)], [text_update(1, "5000", update_id=11)]]
        stop = asyncio.Event()
        task = asyncio.create_task(self.bot.serve(stop))
        for _ in range(200):
            if len(self.tg.sent()) >= 2:
                break
            await asyncio.sleep(0.02)
        stop.set()
        await asyncio.wait_for(task, 5)
        self.assertEqual(len(self.tg.sent()), 2)
        self.assertEqual(self.db.kv_get("offset"), "12")
        self.assertTrue(Path(self.settings.heartbeat_path).exists())
        offsets = [p["offset"] for p in self.tg.of("getUpdates")]
        self.assertEqual(offsets[0], 0)
        self.assertIn(11, offsets)
        self.assertIn(12, offsets)

    async def test_serve_resumes_from_the_saved_offset(self):
        self.db.kv_set("offset", "500")
        stop = asyncio.Event()
        task = asyncio.create_task(self.bot.serve(stop))
        await asyncio.sleep(0.1)
        stop.set()
        await asyncio.wait_for(task, 5)
        self.assertEqual(self.tg.of("getUpdates")[0]["offset"], 500)

    async def test_serve_stops_when_telegram_rejects_the_token(self):
        self.tg.fail_always["getUpdates"] = (401, "Unauthorized")
        stop = asyncio.Event()
        await asyncio.wait_for(self.bot.serve(stop), 5)
        self.assertTrue(stop.is_set())

    async def test_serve_retries_after_any_network_level_error(self):
        import http.client
        calls = {"n": 0}
        original = self.tg.transport

        def flaky(url, body, timeout):
            if url.endswith("/getUpdates"):
                calls["n"] += 1
                if calls["n"] == 1:
                    raise http.client.IncompleteRead(b"par")     # not an OSError: must still be survived
            return original(url, body, timeout)

        self.api._transport = flaky
        self.tg.updates = [[text_update(1, "/start", update_id=1)]]
        stop = asyncio.Event()
        task = asyncio.create_task(self.bot.serve(stop))
        for _ in range(300):
            if self.tg.sent():
                break
            await asyncio.sleep(0.02)
        stop.set()
        await asyncio.wait_for(task, 5)
        self.assertTrue(self.tg.sent())


if __name__ == "__main__":
    unittest.main()
