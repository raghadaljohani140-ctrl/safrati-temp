"""Starting the website: its settings, the shared price allowance, and the whole thing running end to end."""
import asyncio
import dataclasses
import io
import json
import logging
import os
import socket
import subprocess
import sys
import threading
import unittest
import urllib.parse
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path
from unittest import mock

from safrati.config import ConfigError
from safrati.tp import TPError
from safrati.web import __main__ as web_main
from safrati.web.budget import Budget
from safrati.web.settings import WebSettings, load_web_settings
from tests.fakes import BOT_TOKEN, MARKER, TP_TOKEN, TRS, FakeTP

ROOT = Path(__file__).resolve().parent.parent

FULL = {
    "TP_TOKEN": TP_TOKEN, "TP_MARKER": MARKER, "TP_TRS": TRS, "CURRENCY": "USD", "TP_MARKET": "SA", "TP_SHOW_ALL": "yes",
    "CACHE_MINUTES": "45", "CHANNEL_URL": "https://t.me/deals_channel", "BOT_USERNAME": "@Another_bot",
    "WEB_SITE_URL": "https://example.com/", "WEB_REAL_IP_HEADER": "CF-Connecting-IP", "WEB_HOST": "127.0.0.1",
    "WEB_PORT": "9000", "WEB_RATE_PER_MINUTE": "30", "WEB_UPSTREAM_PER_MINUTE": "120", "LOG_LEVEL": "debug",
}


def free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


class SettingsTests(unittest.TestCase):
    def test_nothing_set_gives_the_safe_defaults(self):
        s = load_web_settings({})
        self.assertEqual((s.tp_token, s.currency, s.bot_username, s.host, s.port), ("", "sar", "SafratiTravel_bot", "0.0.0.0", 8088))
        self.assertEqual((s.rate_per_minute, s.upstream_per_minute, s.cache_minutes, s.log_level), (60, 240, 30, "INFO"))
        self.assertEqual((s.site_url, s.real_ip_header, s.channel_url, s.tp_show_all), ("", "", "", False))
        self.assertEqual(s.bot_url, "https://t.me/SafratiTravel_bot")

    def test_every_value_is_read_and_tidied(self):
        s = load_web_settings(FULL)
        self.assertEqual((s.tp_token, s.tp_marker, s.tp_trs), (TP_TOKEN, MARKER, TRS))
        self.assertEqual((s.currency, s.tp_market, s.tp_show_all, s.cache_minutes), ("usd", "sa", True, 45))
        self.assertEqual((s.channel_url, s.bot_username, s.bot_url), ("https://t.me/deals_channel", "Another_bot", "https://t.me/Another_bot"))
        self.assertEqual((s.site_url, s.real_ip_header), ("https://example.com", "cf-connecting-ip"))
        self.assertEqual((s.host, s.port, s.rate_per_minute, s.upstream_per_minute, s.log_level), ("127.0.0.1", 9000, 30, 120, "DEBUG"))

    def test_spaces_around_values_are_ignored(self):
        s = load_web_settings({"TP_TOKEN": f"  {TP_TOKEN} \n", "WEB_PORT": " 8090 ", "CURRENCY": " Sar "})
        self.assertEqual((s.tp_token, s.port, s.currency), (TP_TOKEN, 8090, "sar"))

    def test_only_a_few_words_switch_on_every_price(self):
        for word in ("1", "true", "YES", " True "):
            self.assertTrue(load_web_settings({"TP_SHOW_ALL": word}).tp_show_all, word)
        for word in ("", "0", "no", "false", "maybe", "on"):
            self.assertFalse(load_web_settings({"TP_SHOW_ALL": word}).tp_show_all, word)

    def test_wrong_values_stop_the_start_and_name_the_setting(self):
        bad = {
            "TP_MARKER": "12ab", "TP_TRS": "x1", "CURRENCY": "dollars", "TP_MARKET": "SAU", "CHANNEL_URL": "http://t.me/channel",
            "BOT_USERNAME": "x y", "WEB_SITE_URL": "http://example.com", "WEB_REAL_IP_HEADER": "X-Real-IP\r\nSet-Cookie: a=b",
            "CACHE_MINUTES": "0", "WEB_PORT": "0", "WEB_RATE_PER_MINUTE": "2", "WEB_UPSTREAM_PER_MINUTE": "100000",
        }
        for name, value in bad.items():
            with self.assertRaises(ConfigError, msg=name) as caught:
                load_web_settings({name: value})
            self.assertIn(name, str(caught.exception))
        for name in ("WEB_PORT", "CACHE_MINUTES", "WEB_RATE_PER_MINUTE", "WEB_UPSTREAM_PER_MINUTE"):
            with self.assertRaises(ConfigError, msg=name) as caught:
                load_web_settings({name: "banana"})
            self.assertIn(name, str(caught.exception))
        with self.assertRaises(ConfigError):
            load_web_settings({"WEB_PORT": "70000"})

    def test_the_site_address_is_one_plain_https_name(self):
        for bad in ("https://example.com/path", "https://example.com/?a=b", "https://exa mple.com", "https://", "https://a",
                    "https://example.com:8443", "https://evil.com@example.com", "ftp://example.com", "example.com", "//example.com",
                    "https://example.com#x", "https://" + "a" * 120):
            with self.assertRaises(ConfigError, msg=bad):
                load_web_settings({"WEB_SITE_URL": bad})
        self.assertEqual(load_web_settings({"WEB_SITE_URL": "https://www.flights-hunter.co///"}).site_url, "https://www.flights-hunter.co")

    def test_the_website_never_receives_the_telegram_secrets(self):
        env = {**FULL, "BOT_TOKEN": BOT_TOKEN, "ADMIN_CODE": "an-admin-code-123", "DB_PATH": "/data/s.db"}
        s = load_web_settings(env)
        names = {f.name for f in dataclasses.fields(WebSettings)}
        self.assertFalse(names & {"bot_token", "admin_code", "db_path", "heartbeat_path"}, names)
        shown = repr(s)
        for secret in (BOT_TOKEN, BOT_TOKEN.split(":")[1], "an-admin-code-123", "/data/s.db"):
            self.assertNotIn(secret, shown)

    def test_settings_cannot_be_changed_after_loading(self):
        s = load_web_settings({})
        with self.assertRaises(dataclasses.FrozenInstanceError):
            s.port = 1


class Clock:
    def __init__(self):
        self.now = 1000.0

    def __call__(self) -> float:
        return self.now


class BudgetTests(unittest.TestCase):
    def test_a_burst_is_allowed_then_refused_then_refilled(self):
        clock = Clock()
        budget = Budget(60, burst=5, clock=clock)           # one more every second
        self.assertEqual([budget.take() for _ in range(6)], [True] * 5 + [False])
        self.assertEqual(budget.refused, 1)
        clock.now += 2.0
        self.assertEqual([budget.take() for _ in range(3)], [True, True, False])
        self.assertEqual(budget.refused, 2)

    def test_a_long_quiet_time_never_saves_up_more_than_the_burst(self):
        clock = Clock()
        budget = Budget(60, burst=3, clock=clock)
        clock.now += 86400
        self.assertEqual(sum(budget.take() for _ in range(10)), 3)

    def test_slow_rates_refill_a_little_at_a_time(self):
        clock = Clock()
        budget = Budget(30, burst=1, clock=clock)           # one every two seconds
        self.assertTrue(budget.take())
        self.assertFalse(budget.take())
        clock.now += 1.9
        self.assertFalse(budget.take())
        clock.now += 0.2
        self.assertTrue(budget.take())

    def test_default_burst_leaves_room_for_the_bot(self):
        self.assertEqual(Budget(240).burst, 60.0)
        self.assertEqual(Budget(30).burst, 20.0)
        self.assertEqual(Budget(600).burst, 150.0)

    def test_a_refused_call_never_reaches_the_provider(self):
        reached = []

        def transport(method, url, headers, body, timeout):
            reached.append(url)
            return 200, b"{}"

        guarded = Budget(60, burst=2, clock=Clock()).wrap(transport)
        self.assertEqual(guarded("GET", "https://x/1", {}, None, 5), (200, b"{}"))
        guarded("GET", "https://x/2", {}, None, 5)
        with self.assertRaises(TPError):
            guarded("GET", "https://x/3", {}, None, 5)
        self.assertEqual(reached, ["https://x/1", "https://x/2"])

    def test_many_threads_cannot_spend_more_than_there_is(self):
        budget = Budget(60, burst=50, clock=Clock())
        results: list[bool] = []

        def worker():
            for _ in range(40):
                results.append(budget.take())

        threads = [threading.Thread(target=worker) for _ in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        self.assertEqual((len(results), sum(results)), (320, 50))
        self.assertEqual(budget.refused, 270)


async def get(port: int, path: str, *extra_headers: str):
    reader, writer = await asyncio.open_connection("127.0.0.1", port)
    writer.write((f"GET {path} HTTP/1.1\r\nHost: test\r\nConnection: close\r\n" + "".join(h + "\r\n" for h in extra_headers) + "\r\n").encode())
    await writer.drain()
    raw = await asyncio.wait_for(reader.read(), 15)
    writer.close()
    head, _, body = raw.partition(b"\r\n\r\n")
    lines = head.decode("latin-1").split("\r\n")
    headers = {k.lower(): v.strip() for k, v in (line.split(":", 1) for line in lines[1:])}
    return int(lines[0].split()[1]), headers, body


class Running:
    """The website, started the way the container starts it, on a free port of this machine."""

    def __init__(self, fake: FakeTP, **overrides):
        self.fake = fake
        self.settings = WebSettings(tp_token=TP_TOKEN, tp_marker=MARKER, tp_trs=TRS, host="127.0.0.1", port=0, **overrides)
        self.port = 0
        self.code = None

    async def __aenter__(self):
        self.stop = asyncio.Event()
        started = asyncio.get_running_loop().create_future()
        self._patch = mock.patch.object(web_main, "_urllib_transport", self.fake.transport)
        self._patch.start()
        self.task = asyncio.create_task(web_main.serve(self.settings, stop=self.stop, on_start=started.set_result))
        self.port = await asyncio.wait_for(started, 10)
        return self

    async def __aexit__(self, *exc):
        self.stop.set()
        self.code = await asyncio.wait_for(self.task, 10)
        self._patch.stop()


class ServeTests(unittest.IsolatedAsyncioTestCase):
    async def test_it_starts_answers_and_stops_cleanly(self):
        with self.assertLogs("safrati.web", level="INFO") as logs:
            async with Running(FakeTP()) as site:
                self.assertGreater(site.port, 0)
                status, _, body = await get(site.port, "/healthz")
                self.assertEqual((status, body), (200, b"ok"))
                status, headers, body = await get(site.port, "/")
                self.assertEqual(status, 200)
                self.assertTrue(headers["content-type"].startswith("text/html"))
                self.assertIn("default-src 'none'", headers["content-security-policy"])
                self.assertIn(b"</html>", body)
                status, _, _ = await get(site.port, "/no-such-page")
                self.assertEqual(status, 404)
        self.assertEqual(site.code, 0)
        joined = "\n".join(logs.output)
        self.assertIn("website started on port", joined)
        self.assertIn("prices=on partner_links=on", joined)
        self.assertIn("website stopped", joined)
        self.assertNotIn(TP_TOKEN, joined)

    async def test_the_health_check_command_sees_it(self):
        with self.assertLogs("safrati.web", level="INFO"):
            async with Running(FakeTP()) as site:
                settings = dataclasses.replace(site.settings, port=site.port)
                self.assertEqual(await asyncio.to_thread(web_main.check, settings), 0)
        self.assertEqual(await asyncio.to_thread(web_main.check, settings), 1)        # stopped: nothing answers

    async def test_a_visitor_can_search_open_a_destination_and_book(self):
        fake = FakeTP()
        with self.assertLogs("safrati.web", level="INFO"):
            async with Running(fake) as site:
                status, _, body = await get(site.port, "/api/understand?q=" + urllib.parse.quote("دبي"))
                self.assertEqual(status, 200)
                self.assertTrue(json.loads(body)["ok"])
                status, headers, body = await get(site.port, "/api/dest?d=IST&o=RUH")
                self.assertEqual(status, 200)
                self.assertTrue(headers["content-type"].startswith("application/json"))
                dest = json.loads(body)
                self.assertEqual((dest["dest"]["iata"], dest["empty"]), ("IST", False))
                book = dest["top"][0]["book"]
                self.assertTrue(book.startswith("/go?"))
                status, headers, _ = await get(site.port, book)
                self.assertEqual(status, 302)
                self.assertTrue(headers["location"].startswith("https://"))
                for name, value in headers.items():
                    self.assertNotIn(TP_TOKEN, value, name)
                self.assertEqual(headers["referrer-policy"], "no-referrer")

    async def test_the_website_cannot_use_up_more_than_its_share_of_the_provider(self):
        fake = FakeTP()
        clock = Clock()
        with mock.patch.object(web_main, "Budget", lambda per_minute: Budget(per_minute, clock=clock)):
            with self.assertLogs("safrati.web", level="INFO"):
                async with Running(fake, upstream_per_minute=30) as site:         # a burst of 20, and no time passes
                    answers = []
                    for code in ("IST", "DXB", "CAI", "TBS", "BAK", "AYT", "TZX", "SJJ"):
                        answers.append(await get(site.port, f"/api/dest?d={code}&o=RUH"))
        statuses = [a[0] for a in answers]
        self.assertEqual(statuses[0], 200)
        self.assertEqual(statuses[-1], 503)
        _, headers, body = answers[-1]
        self.assertEqual(json.loads(body)["error"], "busy")
        self.assertIn("retry-after", headers)
        self.assertEqual(len(fake.calls), 20)           # prices and partner links together: nothing past the allowance reached the provider
        self.assertNotIn(TP_TOKEN.encode(), body)


class EntryPointTests(unittest.TestCase):
    def run_main(self, env: dict, *argv: str):
        out, err = io.StringIO(), io.StringIO()
        with mock.patch.dict(os.environ, env, clear=True), mock.patch.object(sys, "argv", ["safrati.web", *argv]):
            with redirect_stdout(out), redirect_stderr(err), self.assertRaises(SystemExit) as raised:
                web_main.main()
        return raised.exception.code, out.getvalue(), err.getvalue()

    def test_a_wrong_setting_stops_with_code_2_and_names_it(self):
        code, _, err = self.run_main({"WEB_PORT": "banana"})
        self.assertEqual(code, 2)
        self.assertIn("WEB_PORT", err)
        code, _, _ = self.run_main({"WEB_PORT": "banana"}, "--check")
        self.assertEqual(code, 2)           # a broken setup must not look healthy

    def test_the_check_command_fails_when_nothing_is_listening(self):
        code, _, _ = self.run_main({"WEB_PORT": str(free_port())}, "--check")
        self.assertEqual(code, 1)

    def test_the_check_command_fails_on_any_answer_but_200(self):
        class Answer:
            status = 503

            def __enter__(self):
                return self

            def __exit__(self, *exc):
                return False

        with mock.patch.object(web_main.urllib.request, "urlopen", return_value=Answer()):
            self.assertEqual(web_main.check(WebSettings()), 1)
        Answer.status = 200
        with mock.patch.object(web_main.urllib.request, "urlopen", return_value=Answer()):
            self.assertEqual(web_main.check(WebSettings()), 0)

    def test_a_normal_start_sets_up_logging_and_serves_with_the_loaded_settings(self):
        with mock.patch.object(web_main, "serve", mock.AsyncMock(return_value=0)) as served, mock.patch.object(web_main, "setup_logging") as logging_set:
            code, _, _ = self.run_main({"TP_TOKEN": TP_TOKEN, "WEB_PORT": "9123"})
        self.assertEqual(code, 0)
        logging_set.assert_called_once()
        served.assert_awaited_once()
        settings = served.await_args.args[0]
        self.assertEqual((settings.port, settings.tp_token), (9123, TP_TOKEN))

    def test_the_real_command_line(self):
        base = {"PATH": os.environ.get("PATH", "/usr/bin:/bin")}
        run = lambda env, *argv: subprocess.run(       # noqa: E731
            [sys.executable, "-m", "safrati.web", *argv], cwd=ROOT, env={**base, **env}, capture_output=True, text=True, timeout=60,
        )
        broken = run({"WEB_PORT": "banana"})
        self.assertEqual(broken.returncode, 2)
        self.assertIn("configuration error", broken.stderr)
        self.assertNotIn("Traceback", broken.stderr)
        silent = run({"WEB_PORT": str(free_port())}, "--check")
        self.assertEqual(silent.returncode, 1)
        self.assertNotIn("Traceback", silent.stderr)


class LoggingTests(unittest.TestCase):
    def setUp(self):
        self.root = logging.getLogger()
        self.saved = self.root.handlers[:], self.root.level
        self.addCleanup(self.restore)

    def restore(self):
        self.root.handlers[:] = self.saved[0]
        self.root.setLevel(self.saved[1])

    def test_the_price_token_never_appears_in_the_log(self):
        buffer = io.StringIO()
        with redirect_stdout(buffer):
            web_main.setup_logging(WebSettings(tp_token=TP_TOKEN))
            logging.getLogger("safrati.web.test").warning("oops %s", TP_TOKEN)
            try:
                raise RuntimeError(f"failed with {TP_TOKEN}")
            except RuntimeError:
                logging.getLogger("safrati.web.test").exception("trace")
        out = buffer.getvalue()
        self.assertIn("oops", out)
        self.assertIn("trace", out)
        self.assertNotIn(TP_TOKEN, out)

    def test_the_level_follows_the_setting_and_a_wrong_word_is_harmless(self):
        cases = {"DEBUG": logging.DEBUG, "WARNING": logging.WARNING, "WARN": logging.WARNING, "ERROR": logging.ERROR,
                 "LOUD": logging.INFO, "BASIC_FORMAT": logging.INFO, "": logging.INFO}
        for word, level in cases.items():
            with redirect_stdout(io.StringIO()):
                web_main.setup_logging(WebSettings(log_level=word))
            self.assertEqual(self.root.level, level, word)


if __name__ == "__main__":
    unittest.main()
