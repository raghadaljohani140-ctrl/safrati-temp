"""The version 2 screens: trip card insights, price calendar, month overview, weekend, regions, first run, sharing."""
import re
from datetime import date

from safrati import data, texts
from safrati import dates as dts
from safrati.tp import Offer
from tests.fakes import TP_TOKEN
from tests.helpers import html_errors
from tests.test_app import AppCase

MONTH_NUMBER = {name: i for i, name in enumerate(texts.MONTHS, 1)}
TRIP_LINE = re.compile(r"^\d\. 📅 (\d+) (\S+) ← (\d+) (\S+)", re.M)


def ar_date(day: str, month_name: str) -> date:
    """«12 ديسمبر» as a date (the fake clock is in October 2026, so October to December are 2026)."""
    month = MONTH_NUMBER[month_name]
    return date(2026 if month >= 10 else 2027, month, int(day))


def trips_in(text: str) -> list[tuple[date, date]]:
    """(departure, return) of the numbered trip lines of a card."""
    return [(ar_date(d1, m1), ar_date(d2, m2)) for d1, m1, d2, m2 in TRIP_LINE.findall(text)]


class ScreenCase(AppCase):
    def shown(self) -> dict:
        """The newest message, whether it was sent or edited in place."""
        return [p for m, p in self.tg.calls if m in ("sendMessage", "editMessageText")][-1]

    def callbacks(self, msg=None) -> list[str]:
        return self.data_buttons(msg or self.shown())

    def labels(self, msg=None) -> list[str]:
        return [b["text"] for b in self.tg.buttons(msg or self.shown())]


class TripCardTests(ScreenCase):
    async def test_card_has_a_price_verdict_month_bars_and_trip_details(self):
        await self.say(1, "اسطنبول")
        text = self.shown()["text"]
        self.assertRegex(text, r"(سعر ممتاز|سعر جيد|سعر عادي)")
        self.assertIn("السعر حسب الشهر", text)
        self.assertGreaterEqual(len(re.findall(r"█", text)), 2)
        self.assertEqual(text.count("⭐ الأرخص"), 1)
        self.assertRegex(text, r"\(\+\d+%\)")                                  # the other months say how much dearer they are
        self.assertIn("🛫", text)
        self.assertIn("5س 30د", text)                                          # the flight time from the provider's answer
        self.assertEqual(html_errors(text), [])
        self.assertLessEqual(len(text), 4096)

    async def test_card_buttons(self):
        await self.say(1, "اسطنبول")
        callbacks = self.callbacks()
        for expected in ("cal:IST:202612:0", "ov:IST:0", "wa:IST:-:-:0:0", "dp:IST", "oc:IST", "sv:IST", "visa:IST",
                         "dy:IST:3:-", "dy:IST:5:-", "dy:IST:7:-", "dy:IST:10:-", "dy:IST:14:-", "dw:IST:-"):
            self.assertIn(expected, callbacks)
        self.assertTrue(all(len(cb.encode()) <= 64 for cb in callbacks))
        shares = [u for u in self.all_urls(self.shown()) if u.startswith("https://t.me/share/url")]
        self.assertEqual(len(shares), 1)
        self.assertIn("start%3Dd_IST", shares[0])                              # the link opens this very destination
        self.assertLessEqual(len(self.url_buttons(self.shown())), 3)

    async def test_stay_buttons_filter_by_trip_length(self):
        await self.tap(1, "dy:IST:7:-")
        text = self.shown()["text"]
        self.assertIn("مدة الرحلة حوالي 7 أيام", text)
        self.assertIn("7 أيام ✔", self.labels())
        trips = trips_in(text)
        self.assertTrue(trips)
        for dep, ret in trips:
            self.assertIn((ret - dep).days, (6, 7, 8))
        self.assertIn("dy:IST:3:-", self.callbacks())                          # the other lengths stay available
        await self.tap(1, "dy:IST:7:202612")
        trips = trips_in(self.shown()["text"])
        self.assertTrue(trips)
        self.assertTrue(all((dep.year, dep.month) == (2026, 12) for dep, _ in trips))
        self.assertIn("dy:IST:3:202612", self.callbacks())

    async def test_a_length_the_provider_has_nothing_for_says_so_and_shows_other_lengths(self):
        await self.say(1, "دبي 5 ايام")                                          # the fake only knows 3, 7 and 10 day trips
        text = self.shown()["text"]
        self.assertIn("ما لقيت أسعارًا محفوظة لمدة حوالي 5 أيام", text)
        self.assertIn("1. 📅", text)                                            # ... but the person still gets prices

    async def test_week_and_long_stays_are_understood_in_free_text(self):
        await self.say(1, "دبي اسبوع")
        self.assertIn("حوالي 7 أيام", self.shown()["text"])
        await self.say(1, "دبي 10 ايام")
        self.assertIn("حوالي 10 أيام", self.shown()["text"])
        await self.say(1, "دبي 14 يوم")
        self.assertIn("14 يوم", self.shown()["text"])                           # eleven and over: «يوم», not «أيام»

    async def test_month_phrases(self):
        await self.say(1, "دبي الشهر الجاي")
        self.assertIn("نوفمبر", self.shown()["text"])
        await self.say(1, "دبي هذا الشهر")
        self.assertIn("أكتوبر", self.shown()["text"])
        for month in ("2026-11", "2026-10"):
            self.assertTrue(any(f"departure_at={month}" in c[1] for c in self.fake.price_calls()), month)

    async def test_weekend_for_one_destination(self):
        self.fake.weekend_deals.add(("RUH", "DXB"))
        await self.say(1, "دبي ويكند")
        text = self.shown()["text"]
        self.assertIn("تغادر الخميس أو الجمعة وترجع السبت أو الأحد", text)
        self.assertIn("🌙 ويكند ✔", self.labels())
        trips = trips_in(text)
        self.assertTrue(trips)
        for dep, ret in trips:
            self.assertIn(dep.weekday(), (3, 4))                                # leaves on a Thursday or a Friday
            self.assertIn(ret.weekday(), (5, 6))                                # ... and is back on a Saturday or a Sunday
            self.assertIn((ret - dep).days, (2, 3))

    async def test_weekend_with_nothing_found_falls_back_with_a_note(self):
        self.fake.stays = (7, 10)                                              # no short trips at all
        await self.say(1, "دبي ويكند")
        text = self.shown()["text"]
        self.assertIn(texts.NOTE_WEEKEND_MISS, text)
        self.assertIn("1. 📅", text)

    async def test_a_cheaper_nearby_day_is_suggested_for_exact_dates(self):
        self.fake.exact_extra = 200
        await self.say(1, "دبي 15/12 - 22/12")
        msg = self.shown()
        self.assertIn("توفّر حوالي", msg["text"])
        hint = [b for b in self.tg.buttons(msg) if b["text"].startswith("💡")]
        self.assertEqual(len(hint), 1)
        self.assertIn("وفّر 230", hint[0]["text"])
        self.assertEqual(hint[0]["callback_data"], "cd:DXB:20261212:20261219")
        self.assertEqual(html_errors(msg["text"]), [])

    async def test_no_hint_when_the_saving_is_small(self):
        await self.say(1, "دبي 15/12 - 22/12")                                   # the fake's exact price is only 30 above the best
        self.assertNotIn("💡", " ".join(self.labels()))
        self.assertNotIn("توفّر حوالي", self.shown()["text"])

    async def test_hint_is_dropped_when_the_calendar_is_unavailable(self):
        self.fake.exact_extra = 200
        original = self.tp.calendars

        async def failing(*args, **kwargs):
            raise __import__("safrati.tp", fromlist=["TPError"]).TPError("boom", 500)

        self.tp.calendars = failing
        await self.say(1, "دبي 15/12 - 22/12")
        self.assertIn("22 ديسمبر", self.shown()["text"])
        self.assertNotIn("💡", " ".join(self.labels()))
        self.tp.calendars = original

    async def test_the_hint_button_opens_that_trip_in_place_and_is_not_counted(self):
        self.fake.exact_extra = 200
        await self.say(1, "دبي 15/12 - 22/12")
        before = self.db.stats()["searches_today"]
        self.tg.reset()
        await self.tap(1, "cd:DXB:20261212:20261219", message_id=61)
        edits = self.tg.of("editMessageText")
        self.assertEqual([e["message_id"] for e in edits], [61])
        self.assertIn("12 ديسمبر ← 19 ديسمبر", edits[0]["text"])
        self.assertEqual(self.db.stats()["searches_today"], before)

    async def test_exact_search_buttons(self):
        await self.say(1, "دبي 15/12 - 22/12")
        callbacks = self.callbacks()
        self.assertIn("wa:DXB:20261215:20261222:0:0", callbacks)
        self.assertIn("d:DXB", callbacks)                                      # «أرخص الأيام»
        self.assertIn("📅 غيّر التاريخ", self.labels())
        self.assertNotIn("dy:DXB:7:-", callbacks)                              # stay buttons make no sense for fixed dates

    async def test_one_way_trip_has_no_calendar_or_stay_buttons(self):
        await self.say(1, "دبي 15/12 ذهاب فقط")
        callbacks = self.callbacks()
        self.assertTrue(any(c.startswith("wa:DXB:20261215:-:1:") for c in callbacks))
        self.assertFalse(any(c.startswith(("cal:", "ov:", "dy:")) for c in callbacks))


class CalendarTests(ScreenCase):
    async def test_calendar_marks_every_priced_day(self):
        await self.tap(1, "cal:IST:202612:0")
        msg = self.shown()
        self.assertIn("تقويم أسعار", msg["text"])
        self.assertIn("ديسمبر", msg["text"])
        self.assertIn("أرخص يوم: 12 ديسمبر — 1,100 ر.س", re.sub(r"</?b>", "", msg["text"]))
        self.assertEqual(html_errors(msg["text"]), [])
        rows = msg["reply_markup"]["inline_keyboard"]
        self.assertEqual(len(rows[0]), 7)                                       # weekday names
        self.assertTrue(all(len(r) == 7 for r in rows[:6]))
        labels = self.labels(msg)
        marked = [l for l in labels if l[:1] in "🟢🟡🔴"]
        self.assertEqual(len(marked), 28)                                       # every day the fake has a price for
        self.assertIn("🟢12", labels)                                           # the cheapest day is green
        self.assertIn("🔴28", labels)                                           # the dearest one is red
        for expected in ("cd:IST:20261212:20261219", "cal:IST:202611:0", "cal:IST:202701:0", "ov:IST:0", "d:IST",
                         "wa:IST:202612:-:0:0", "menu"):
            self.assertIn(expected, self.callbacks(msg))

    async def test_tiers_follow_the_price_not_the_date(self):
        await self.tap(1, "cal:IST:202612:0")
        marks = {}
        for b in self.tg.buttons(self.shown()):
            if b["text"][:1] in "🟢🟡🔴" and b["callback_data"].startswith("cd:"):
                marks[int(b["text"][1:])] = b["text"][:1]
        prices = {d: 1100 + 25 + 6 * abs(d - 12) + 15 * 0 for d in range(1, 29)}
        prices[12] = 1100
        cheap = [d for d, m in marks.items() if m == "🟢"]
        dear = [d for d, m in marks.items() if m == "🔴"]
        self.assertTrue(cheap and dear)
        self.assertLess(max(prices[d] for d in cheap), min(prices[d] for d in dear))

    async def test_days_that_are_over_cannot_be_picked(self):
        await self.tap(1, "cal:IST:202610:0")
        labels = self.labels()
        self.assertIn("27", [l[1:] for l in labels if l[:1] in "🟢🟡🔴"])
        self.assertNotIn("20", [l[1:] for l in labels if l[:1] in "🟢🟡🔴"])
        self.assertNotIn("26", [l[1:] for l in labels if l[:1] in "🟢🟡🔴"])
        cds = [c for c in self.callbacks() if c.startswith("cd:")]
        self.assertTrue(all(c.split(":")[2] >= "20261027" for c in cds))

    async def test_calendar_with_a_stay_only_has_matching_trips(self):
        await self.tap(1, "cal:IST:202612:7")
        self.assertIn("حوالي 7 أيام", self.shown()["text"])
        for cb in self.callbacks():
            if cb.startswith("cd:"):
                _kind, _iata, dep, ret = cb.split(":")
                days = (dts.decode_day(ret) - dts.decode_day(dep)).days
                self.assertIn(days, (6, 7, 8), cb)
        self.assertIn("cal:IST:202611:7", self.callbacks())                    # navigation keeps the length
        self.assertIn("ov:IST:7", self.callbacks())

    async def test_tapping_a_day_opens_that_trip_in_place(self):
        await self.tap(1, "cal:IST:202612:0", message_id=70)
        self.tg.reset()
        await self.tap(1, "cd:IST:20261212:20261219", message_id=70)
        edits = self.tg.of("editMessageText")
        self.assertEqual(len(edits), 1)
        self.assertEqual(edits[0]["message_id"], 70)
        self.assertIn("12 ديسمبر ← 19 ديسمبر", edits[0]["text"])
        self.assertTrue(self.url_buttons(edits[0]))                              # a booking link for that exact trip

    async def test_navigating_between_months_edits_the_same_message(self):
        await self.tap(1, "cal:IST:202612:0", message_id=70)
        self.tg.reset()
        await self.tap(1, "cal:IST:202701:0", message_id=70)
        self.assertEqual(self.tg.sent(), [])
        self.assertEqual(len(self.tg.of("editMessageText")), 1)
        self.assertIn("يناير", self.shown()["text"])

    async def test_first_and_last_month_have_one_arrow(self):
        await self.tap(1, "cal:IST:202610:0")
        self.assertFalse(any(c.startswith("cal:IST:202609") for c in self.callbacks()))
        self.assertIn("cal:IST:202611:0", self.callbacks())
        await self.tap(1, "cal:IST:202709:0")
        self.assertIn("cal:IST:202708:0", self.callbacks())
        self.assertFalse(any(c.startswith("cal:IST:202710") for c in self.callbacks()))

    async def test_months_without_prices_say_so(self):
        self.fake.routes["RUH"].pop("IST")
        await self.tap(1, "cal:IST:202612:0")
        self.assertIn("ما لقيت أسعارًا محفوظة في هذا الشهر", self.shown()["text"])
        self.assertFalse(any(c.startswith("cd:") for c in self.callbacks()))

    async def test_two_priced_days_are_marked_without_tiers(self):
        def offer(day, price):
            return Offer("RUH", "IST", price, "sar", "TK", f"{day}T10:00:00+03:00", "2026-12-19T10:00:00+03:00", 0, "")

        async def sparse(*args, **kwargs):
            return {"2026-12-10": offer("2026-12-10", 900), "2026-12-11": offer("2026-12-11", 1200)}

        self.tp.calendar = sparse
        await self.tap(1, "cal:IST:202612:0")
        labels = self.labels()
        self.assertIn("🟢10", labels)
        self.assertIn("🟡11", labels)

    async def test_provider_trouble_is_reported(self):
        self.fake.status = 500
        await self.tap(1, "cal:IST:202612:0")
        self.assertEqual(self.shown()["text"], texts.BUSY)

    async def test_bad_calendar_buttons_are_harmless(self):
        for payload in (
            "cal:IST", "cal:IST:202612", "cal:IST:202612:abc", "cal:IST:209912:0", "cal:IST:202501:0", "cal:IST:202710:0",
            "cal:IST:202612:1", "cal:IST:202612:31", "cal:IST:202612:-1", "cal:ZZZ:202612:0", "cal::", "cal:IST:xxxxxx:0",
            "cd:IST:20261212", "cd:IST:20200101:20200105", "cd:IST:xx:yy", "cd:IST:20261212:xx", "cd:IST:20261212:20261219:5",
            "cd:ZZZ:20261212:20261219", "ov:IST", "ov:IST:abc", "ov:IST:99", "ov:IST:1", "ov:IST:7:7", "ov:ZZZ:0", "x:", "x",
        ):
            await self.tap(1, payload)
        for message in self.tg.sent():
            self.assertNotEqual(message["text"], texts.ERROR)
            self.assertEqual(html_errors(message["text"]), [])

    async def test_the_grid_is_a_real_calendar(self):
        await self.tap(1, "cal:IST:202612:0")
        rows = self.shown()["reply_markup"]["inline_keyboard"][1:6]
        flat = [b["text"] for row in rows for b in row]
        numbers = [int(re.sub(r"\D", "", t)) for t in flat if re.sub(r"\D", "", t)]
        self.assertEqual(numbers, list(range(1, 32)))                            # the 31 days of December, in order
        # 1 December 2026 is a Tuesday and weeks start on Sunday: two blanks before it
        self.assertEqual(rows[0][0]["text"], rows[0][1]["text"])
        self.assertTrue(rows[0][2]["text"].endswith("1"))


class OverviewTests(ScreenCase):
    async def test_overview_lists_every_month_with_its_cheapest_price(self):
        await self.tap(1, "ov:IST:0")
        msg = self.shown()
        self.assertIn("أرخص شهر للسفر إلى", msg["text"])
        self.assertEqual(html_errors(msg["text"]), [])
        self.assertIn("⭐ الأرخص", msg["text"])
        cals = [c for c in self.callbacks(msg) if c.startswith("cal:IST:")]
        self.assertEqual(len(cals), 6)
        self.assertIn("cal:IST:202612:0", cals)
        month_buttons = [b["text"] for b in self.tg.buttons(msg) if b.get("callback_data", "").startswith("cal:")]
        self.assertIn("ديسمبر — 1,100", month_buttons)
        self.assertIn("d:IST", self.callbacks(msg))

    async def test_overview_with_a_stay(self):
        await self.tap(1, "ov:IST:7", message_id=80)
        self.assertIn("حوالي 7 أيام", self.shown()["text"])
        self.assertTrue(all(c.endswith(":7") for c in self.callbacks() if c.startswith("cal:")))

    async def test_overview_is_edited_in_place(self):
        self.tg.reset()
        await self.tap(1, "ov:IST:0", message_id=80)
        self.assertEqual(self.tg.sent(), [])
        self.assertEqual([e["message_id"] for e in self.tg.of("editMessageText")], [80])

    async def test_overview_with_no_prices(self):
        self.fake.routes["RUH"].pop("IST")
        await self.tap(1, "ov:IST:0")
        self.assertIn("ما لقيت أسعارًا", self.shown()["text"])

    async def test_overview_with_one_priced_month_has_no_bar_chart(self):
        def offer():
            return Offer("RUH", "IST", 1234, "sar", "TK", "2026-12-12T10:00:00+03:00", "2026-12-19T10:00:00+03:00", 0, "")

        async def one_month(origin, iata, keys, **kw):
            return {"2026-12": {"2026-12-12": offer()}}

        self.tp.calendars = one_month
        await self.tap(1, "ov:IST:0")
        self.assertIn("1,234 ر.س", self.shown()["text"])
        self.assertNotIn("█", self.shown()["text"])

    async def test_overview_provider_trouble(self):
        self.fake.status = 500
        await self.tap(1, "ov:IST:0")
        self.assertEqual(self.shown()["text"], texts.BUSY)


class WeekendScreenTests(ScreenCase):
    def weekend_routes(self, *iatas):
        self.fake.weekend_deals.update({("RUH", i) for i in iatas})

    async def test_weekend_list(self):
        self.weekend_routes("DXB", "CAI", "IST", "AMM", "TBS")
        await self.say(1, "/weekend")
        msg = self.shown()
        self.assertIn("أرخص رحلات الويكند", msg["text"])
        self.assertIn(texts.WEEKEND_RULE, msg["text"])
        self.assertEqual(html_errors(msg["text"]), [])
        picks = [c for c in self.callbacks(msg) if c.startswith("d:")]
        self.assertGreaterEqual(len(picks), 5)
        for pick in picks:
            _k, _iata, dep, ret = pick.split(":")
            self.assertEqual(dts.decode_day(dep).weekday(), 3)                  # a Thursday
            self.assertIn((dts.decode_day(ret) - dts.decode_day(dep)).days, (2, 3))
        prices = [int(p.replace(",", "")) for p in re.findall(r"من ([\d,]+) ر\.س", msg["text"])]
        self.assertEqual(prices, sorted(prices))

    async def test_a_number_opens_the_trip_for_those_exact_days(self):
        self.weekend_routes("DXB", "CAI", "IST")
        await self.say(1, "ويكند")
        first = next(c for c in self.callbacks() if c.startswith("d:"))
        await self.tap(1, first)
        _k, iata, dep, ret = first.split(":")
        dest = data.by_iata()[iata]
        self.assertIn(dest.ar, self.shown()["text"])
        self.assertIn(texts.fmt_date(dts.decode_day(dep).isoformat()), self.shown()["text"])

    async def test_typing_a_number_picks_from_the_weekend_list_too(self):
        self.weekend_routes("DXB", "CAI", "IST")
        await self.say(1, "ويكند")
        await self.say(1, "1")
        self.assertIn("ذهاب وعودة", self.shown()["text"])

    async def test_past_thursdays_are_never_offered(self):
        self.weekend_routes("DXB", "CAI", "IST")
        await self.say(1, "/weekend")
        for cb in self.callbacks():
            if cb.startswith("d:"):
                self.assertGreaterEqual(dts.decode_day(cb.split(":")[2]).isoformat(), "2026-10-27")

    async def test_nothing_to_show(self):
        self.fake.stays = (7, 10)                                              # the provider has no short trips at all
        await self.say(1, "/weekend")
        self.assertEqual(self.shown()["text"], texts.WEEKEND_EMPTY)

    async def test_regions_narrow_the_weekend_list(self):
        self.weekend_routes("DXB", "CAI", "IST", "LON", "PAR", "ZRH")
        await self.say(1, "ويكند اوروبا")
        europe = {d.iata for d in data.destinations() if data.in_region(d, ("europe",))}
        picks = {c.split(":")[1] for c in self.callbacks() if c.startswith("d:")}
        self.assertTrue(picks)
        self.assertTrue(picks <= europe, picks)

    async def test_visa_filter_applies(self):
        self.weekend_routes("DXB", "CAI", "IST", "LON", "PAR", "ZRH", "TYO", "NYC")
        self.db.set_visa_only(1, True)
        await self.say(1, "/weekend")
        self.assertIn("بدون تأشيرة فقط", self.shown()["text"])
        for cb in self.callbacks():
            if cb.startswith("d:"):
                self.assertTrue(texts.visa_ok(data.by_iata()[cb.split(":")[1]]), cb)

    async def test_button_edits_in_place(self):
        self.weekend_routes("DXB", "CAI", "IST")
        self.tg.reset()
        await self.tap(1, "we", message_id=90)
        self.assertEqual(self.tg.sent(), [])
        self.assertEqual([e["message_id"] for e in self.tg.of("editMessageText")], [90])

    async def test_provider_trouble_and_no_provider(self):
        self.fake.status = 500
        await self.say(1, "/weekend")
        self.assertEqual(self.shown()["text"], texts.BUSY)
        self.build(tp_enabled=False)
        await self.say(1, "/weekend")
        self.assertEqual(self.shown()["text"], texts.BUSY)

    async def test_the_daily_limit_applies(self):
        self.weekend_routes("DXB", "CAI", "IST")
        for _ in range(self.settings.daily_search_limit):
            self.db.use_search(1, self.settings.daily_search_limit)
        await self.say(1, "/weekend")
        self.assertEqual(self.shown()["text"], texts.LIMIT_REACHED)


class CheapAndRegionTests(ScreenCase):
    async def test_cheap_list_has_region_chips(self):
        await self.say(1, "/cheap")
        msg = self.shown()
        self.assertIn("أرخص الرحلات الآن", msg["text"])
        callbacks = self.callbacks(msg)
        for chip in ("ch:all:-", "ch:arab:-", "ch:caucasus:-", "ch:asia:-", "ch:europe:-", "ch:africa:-"):
            self.assertIn(chip, callbacks)
        self.assertIn("✔ 🔥 الكل", self.labels(msg))
        self.assertEqual(html_errors(msg["text"]), [])

    async def test_a_region_chip_filters_and_is_edited_in_place(self):
        await self.say(1, "/cheap")
        self.tg.reset()
        await self.tap(1, "ch:europe:-", message_id=95)
        self.assertEqual(self.tg.sent(), [])
        self.assertEqual([e["message_id"] for e in self.tg.of("editMessageText")], [95])
        msg = self.shown()
        self.assertIn("أوروبا", msg["text"])
        self.assertIn("✔ " + texts.REGION_LABELS["europe"], self.labels(msg))
        europe = {d.iata for d in data.destinations() if data.in_region(d, ("europe",))}
        picks = [c.split(":")[1] for c in self.callbacks(msg) if c.startswith("d:")]
        self.assertTrue(picks)
        self.assertTrue(set(picks) <= europe)
        await self.tap(1, "ch:all:-", message_id=95)
        self.assertNotIn("أوروبا —", self.shown()["text"])

    async def test_region_in_free_text(self):
        await self.say(1, "رحلات اوروبا")
        self.assertIn("أوروبا", self.shown()["text"])
        await self.say(1, "ارخص رحلات القوقاز")
        self.assertIn("القوقاز", self.shown()["text"])
        caucasus = {d.iata for d in data.destinations() if data.in_region(d, ("caucasus",))}
        picks = {c.split(":")[1] for c in self.callbacks() if c.startswith("d:")}
        self.assertTrue(picks and picks <= caucasus)

    async def test_region_with_a_month(self):
        await self.say(1, "ارخص رحلات القوقاز ديسمبر")
        self.assertIn("ديسمبر", self.shown()["text"])
        self.assertTrue(all("2026-12" in c[1] for c in self.fake.price_calls()[-1:]))
        self.assertIn("ch:caucasus:202612", self.callbacks())

    async def test_region_with_a_budget(self):
        await self.say(1, "اوروبا 5000")
        self.assertIn("ميزانيتك 5,000", self.shown()["text"])
        europe = {d.iata for d in data.destinations() if data.in_region(d, ("europe",))}
        picks = [c.split(":")[1] for c in self.callbacks() if c.startswith("d:")]
        self.assertTrue(picks and set(picks) <= europe)

    async def test_bad_chip_buttons_are_harmless(self):
        for payload in ("ch:zzz:-", "ch:europe:bad", "ch:europe:209913", "ch:", "ch", "ch:europe", "ch:europe:-:-"):
            await self.tap(1, payload)
        for message in self.tg.sent():
            self.assertNotEqual(message["text"], texts.ERROR)

    async def test_cheap_in_free_text(self):
        await self.say(1, "ارخص")
        self.assertIn("أرخص الرحلات الآن", self.shown()["text"])


class SuggestionTests(ScreenCase):
    async def test_a_misspelt_place_gets_a_did_you_mean_button(self):
        await self.say(1, "اسطمبول")
        msg = self.shown()
        self.assertIn("تقصد", msg["text"])
        self.assertIn("d:IST", self.callbacks(msg))
        self.assertEqual(html_errors(msg["text"]), [])
        await self.tap(1, "d:IST")
        self.assertIn("إسطنبول", self.shown()["text"])

    async def test_the_dates_typed_with_the_misspelling_are_kept(self):
        await self.say(1, "لندون 15/12")
        self.assertIn("d:LON:20261215:-", self.callbacks())

    async def test_nonsense_is_not_guessed(self):
        await self.say(1, "xqzvbn")
        self.assertEqual(self.shown()["text"], texts.UNKNOWN)


class FirstRunTests(ScreenCase):
    async def test_a_new_person_chooses_a_city_first(self):
        await self.say(1, "/start")
        self.assertEqual(self.shown()["text"], texts.ONBOARD_ASK)
        self.assertEqual(
            [c for c in self.callbacks() if c.startswith("ob:")], [f"ob:{code}" for code in ("RUH", "JED", "DMM", "MED", "AHB", "GIZ", "TIF", "ELQ", "TUU")]
        )
        await self.tap(1, "ob:JED")
        self.assertIn("جدة", self.shown()["text"])
        self.assertEqual(self.db.touch_user(1)["origin"], "JED")
        self.assertTrue(self.db.touch_user(1)["onboarded"])
        await self.say(1, "/start")                                              # asked only once
        self.assertEqual(self.shown()["text"], texts.WELCOME)

    async def test_a_shared_link_survives_the_city_question(self):
        await self.say(1, "/start d_IST_20261215_20261222")
        buttons = [c for c in self.callbacks() if c.startswith("ob:")]
        self.assertEqual(len(buttons), 9)
        self.assertTrue(all(c.endswith(":d_IST_20261215_20261222") for c in buttons))
        self.assertTrue(all(len(c.encode()) <= 64 for c in buttons))
        self.fake.calls.clear()
        await self.tap(1, "ob:JED:d_IST_20261215_20261222")
        text = self.shown()["text"]
        self.assertIn("15 ديسمبر ← 22 ديسمبر", text)
        self.assertIn("من جدة", text)
        self.assertTrue(any("origin=JED" in c[1] for c in self.fake.price_calls()))

    async def test_an_onboarded_person_goes_straight_to_the_shared_trip(self):
        self.db.set_onboarded(1)
        for payload, expect in (
            ("d_IST", "إسطنبول"), ("d_IST_202612", "ديسمبر"), ("d_IST_20261215", "15 ديسمبر"),
            ("d_IST_20261215_20261222", "15 ديسمبر ← 22 ديسمبر"), ("d_IST_20261215_o", "ذهاب فقط"),
        ):
            await self.say(1, "/start " + payload)
            self.assertIn(expect, self.shown()["text"], payload)

    async def test_weekend_and_cheap_links(self):
        self.db.set_onboarded(1)
        self.fake.weekend_deals.update({("RUH", d) for d in ("DXB", "CAI", "IST")})
        await self.say(1, "/start w")
        self.assertIn("أرخص رحلات الويكند", self.shown()["text"])
        await self.say(1, "/start c")
        self.assertIn("أرخص الرحلات الآن", self.shown()["text"])

    async def test_bad_links_fall_back_to_the_menu(self):
        self.db.set_onboarded(1)
        for payload in (
            "d_ZZZ", "d_IST_20200101", "d_IST_2020", "d_IST_20261215_xx", "d_IST_20261215_20261222_9", "x", "d", "d_",
            "d_IST_20991231", "d_IST_" + "9" * 100, "garbage" * 20,
        ):
            before = len(self.fake.price_calls())
            await self.say(1, "/start " + payload)
            self.assertEqual(self.shown()["text"], texts.WELCOME, payload)
            self.assertEqual(len(self.fake.price_calls()), before, payload)

    async def test_bad_first_run_buttons(self):
        await self.tap(1, "ob:XXX")
        self.assertEqual(self.shown()["text"], texts.BAD_BUTTON)
        self.assertFalse(self.db.touch_user(1)["onboarded"])
        await self.tap(1, "ob:RUH:garbage")                                       # a city but a link we cannot read
        self.assertTrue(self.db.touch_user(1)["onboarded"])
        self.assertIn("الرياض", self.shown()["text"])

    async def test_typing_a_city_name_counts_as_choosing_it(self):
        await self.say(1, "جدة")
        self.assertEqual(self.db.touch_user(1)["origin"], "JED")
        self.assertTrue(self.db.touch_user(1)["onboarded"])


class OriginChangeTests(ScreenCase):
    async def test_a_message_that_only_names_the_city_after_from_changes_the_city(self):
        await self.say(1, "من جدة")
        self.assertEqual(self.db.touch_user(1)["origin"], "JED")
        self.assertIn("جدة", self.shown()["text"])
        self.assertNotEqual(self.shown()["text"], texts.UNKNOWN)
        await self.say(1, "من الدمام")
        self.assertEqual(self.db.touch_user(1)["origin"], "DMM")

    async def test_the_city_after_from_still_works_beside_other_requests(self):
        await self.say(1, "ارخص من جدة")
        self.assertEqual(self.db.touch_user(1)["origin"], "JED")
        self.assertIn("من جدة", self.shown()["text"])
        self.assertIn("أرخص الرحلات الآن", self.shown()["text"])
        await self.say(1, "دبي من الدمام")
        self.assertEqual(self.db.touch_user(1)["origin"], "DMM")
        self.assertIn("من الدمام", self.shown()["text"])

    async def test_the_picker_shows_the_current_city_and_changes_it(self):
        await self.say(1, "اسطنبول")
        self.assertIn("oc:IST", self.callbacks())
        await self.tap(1, "oc:IST", message_id=40)
        self.assertIn("من أي مدينة تسافر إلى", self.shown()["text"])
        self.assertIn("✔ الرياض", self.labels())
        self.assertIn("ox:JED:IST", self.callbacks())
        before = self.db.stats()["searches_today"]
        self.tg.reset()
        await self.tap(1, "ox:JED:IST", message_id=40)
        self.assertEqual(self.db.touch_user(1)["origin"], "JED")
        self.assertIn("من جدة", self.shown()["text"])
        self.assertEqual([e["message_id"] for e in self.tg.of("editMessageText")], [40])
        self.assertEqual(self.db.stats()["searches_today"], before)             # changing the city is not a new search

    async def test_bad_origin_buttons(self):
        for payload in ("ox:XXX:IST", "ox:JED:ZZZ", "ox:JED", "ox", "oc:ZZZ", "oc"):
            await self.tap(1, payload)
        self.assertEqual(self.db.touch_user(1)["origin"], "RUH")


class SharingTests(ScreenCase):
    async def test_the_share_link_carries_the_destination_and_dates(self):
        await self.say(1, "دبي 15/12 - 22/12")
        share = next(u for u in self.all_urls(self.shown()) if u.startswith("https://t.me/share/url"))
        self.assertIn("start%3Dd_DXB_20261215_20261222", share)
        self.assertLess(len(share), 2000)

    async def test_the_menu_has_a_share_button_for_the_bot(self):
        self.db.set_onboarded(1)
        await self.say(1, "/start")
        urls = self.all_urls(self.shown())
        self.assertTrue(any(u.startswith("https://t.me/share/url?url=https%3A%2F%2Ft.me%2FSafratiTravel_bot") for u in urls))


class StatsTests(ScreenCase):
    async def test_stats_for_the_admin_cover_alerts_and_newcomers(self):
        self.db.add_admin(9)
        await self.say(1, "اسطنبول")
        await self.tap(1, "wa:IST:-:-:0:0")
        await self.tap(2, "wa:DXB:-:-:0:0")
        await self.say(9, "/stats")
        text = self.shown()["text"]
        self.assertIn("المستخدمون: 3", text)
        self.assertIn("جدد آخر 24 ساعة: 3", text)
        self.assertIn("تنبيهات أسعار: 2 عند 2 مستخدم", text)
        self.assertIn("الأكثر بحثًا", text)
        self.assertEqual(html_errors(text), [])

    async def test_stats_refused_for_others(self):
        await self.say(1, "/stats")
        self.assertEqual(self.shown()["text"], texts.ADMIN_ONLY)

    async def test_diag_checks_the_calendar_and_weekend_lookups(self):
        self.db.add_admin(9)
        await self.say(9, "/diag")
        text = self.shown()["text"]
        self.assertRegex(text, r"✅ تقويم الأسعار \(\S+\): \d+ يوم من \d+")
        self.assertRegex(text, r"✅ رحلات الويكند: \d+ وجهة \(\d+\.\d ث\)")
        self.assertEqual(html_errors(text), [])

    async def test_diag_says_which_lookup_failed(self):
        self.db.add_admin(9)
        self.fake.routes["RUH"] = {}                                           # the provider answers, but with nothing
        await self.say(9, "/diag")
        text = self.shown()["text"]
        self.assertIn("❌ تقويم الأسعار (نوفمبر): 0 يوم من 30", text)
        self.assertIn("❌ رحلات الويكند: 0 وجهة", text)
        self.build()                                                           # ... or does not answer at all
        self.db.add_admin(9)
        self.fake.status = 500
        await self.say(9, "/diag")
        text = self.shown()["text"]
        self.assertIn("❌ تقويم الأسعار: api error 500", text)
        self.assertIn("❌ رحلات الويكند:", text)                                # (the provider's short cool-down may answer instead)
        self.assertNotIn(TP_TOKEN, text)
        self.assertEqual(html_errors(text), [])

    async def test_diag_has_no_price_lines_without_a_provider(self):
        self.build(tp_enabled=False)
        self.db.add_admin(9)
        await self.say(9, "/diag")
        self.assertNotIn("تقويم الأسعار", self.shown()["text"])


class CrawlTests(ScreenCase):
    """Press every button that appears, starting from the menu, and check nothing breaks."""

    async def test_every_reachable_button_works_and_fits_telegram_limits(self):
        self.fake.weekend_deals.update({("RUH", d) for d in ("DXB", "CAI", "IST", "AMM", "TBS")})
        self.fake.exact_extra = 150
        self.db.add_admin(1)                                  # no daily limit, so the walk is not cut short
        self.db.set_onboarded(1)
        await self.say(1, "/start")
        seen: set[str] = set()
        queue: list[str] = []
        cursor = 0
        taps = 0
        skip = ("pub:", "wd:", "sv:", "us:")

        def harvest():
            nonlocal cursor
            for method, params in self.tg.calls[cursor:]:
                if method not in ("sendMessage", "editMessageText"):
                    continue
                self.assertLessEqual(len(params["text"]), 4096)
                self.assertEqual(html_errors(params["text"]), [], params["text"][:80])
                self.assertNotEqual(params["text"], texts.ERROR)
                rows = (params.get("reply_markup") or {}).get("inline_keyboard", [])
                self.assertLessEqual(len(rows), 100)
                for row in rows:
                    self.assertLessEqual(len(row), 8)
                    for b in row:
                        self.assertTrue(b["text"].strip())
                        if "callback_data" in b:
                            self.assertLessEqual(len(b["callback_data"].encode()), 64, b["callback_data"])
                            if b["callback_data"] not in seen and not b["callback_data"].startswith(skip):
                                seen.add(b["callback_data"])
                                queue.append(b["callback_data"])
                        else:
                            self.assertTrue(b["url"].startswith("https://"))
                            self.assertLessEqual(len(b["url"]), 2048)
            cursor = len(self.tg.calls)

        harvest()
        pressed: set[str] = set()
        while queue and taps < 450:
            fresh = next((i for i, p in enumerate(queue) if p.split(":")[0] not in pressed), 0)   # a new kind of button first
            payload = queue.pop(fresh)
            if payload in ("x", "noop"):
                continue
            pressed.add(payload.split(":")[0])
            await self.tap(1, payload, message_id=500 + taps, update_id=taps + 2)
            taps += 1
            harvest()
        self.assertGreater(taps, 150)
        kinds = {p.split(":")[0] for p in seen}
        for kind in ("cal", "cd", "ov", "dy", "dw", "wa", "oc", "ox", "ch", "d", "dp", "dm", "dd", "dr", "we", "al", "visa"):
            self.assertIn(kind, kinds)
