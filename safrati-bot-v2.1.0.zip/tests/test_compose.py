"""The container set-up as a whole: what each part can see, what it can reach, and that nothing is left open."""
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
COMPOSE = (ROOT / "docker-compose.yml").read_text(encoding="utf-8")
SETTINGS = (ROOT / "safrati" / "web" / "settings.py").read_text(encoding="utf-8")


def blocks(text: str) -> dict[str, str]:
    """The text of each service, found by indentation (the project allows only the standard library)."""
    found: dict[str, list[str]] = {}
    current, inside = None, False
    for line in text.splitlines():
        if re.match(r"^services:\s*$", line):
            inside = True
            continue
        if inside and re.match(r"^\S", line):
            inside = False
        if not inside:
            continue
        head = re.match(r"^  ([a-z][a-z0-9-]*):\s*$", line)
        if head:
            current = head.group(1)
            found[current] = []
        elif current:
            found[current].append(line)
    return {name: "\n".join(lines) for name, lines in found.items()}


SERVICES = blocks(COMPOSE)


def environment(block: str) -> dict[str, str]:
    lines = block.splitlines()
    start = lines.index("    environment:")
    out = {}
    for line in lines[start + 1:]:
        if not line.startswith("      "):
            break
        if line.strip().startswith("#"):
            continue
        key, _, value = line.strip().partition(":")
        out[key] = value.strip()
    return out


class ShapeTests(unittest.TestCase):
    def test_the_parts_and_the_switches_that_turn_them_on(self):
        self.assertEqual(list(SERVICES), ["bot", "web", "tunnel", "tunnel-domain"])
        self.assertNotIn("profiles:", SERVICES["bot"])            # the bot is always on
        for name, profile in (("web", "web"), ("tunnel", "quick"), ("tunnel-domain", "domain")):
            self.assertIn(f'profiles: ["{profile}"]', SERVICES[name], name)

    def test_nothing_opens_a_port_or_reaches_into_the_machine(self):
        for name, block in SERVICES.items():
            for bad in ("ports:", "network_mode", "privileged", "docker.sock", "pid:", "ipc:", "devices:", "cap_add", "/etc", "/var", "/home", "/opt", "/root"):
                self.assertNotIn(bad, block, f"{name}: {bad}")
        self.assertNotIn("ports:", COMPOSE)
        self.assertNotRegex(COMPOSE, r"(?m)^\s+- [./~][^\n]*:/")         # no folder of the machine is mounted anywhere

    def test_every_part_is_locked_down_and_limited(self):
        for name, block in SERVICES.items():
            self.assertIn("cap_drop:\n      - ALL", block, name)
            self.assertIn("no-new-privileges:true", block, name)
            self.assertRegex(block, r"mem_limit: \d+m", name)
            self.assertRegex(block, r"pids_limit: \d+", name)
            self.assertIn("max-size", block, name)
            self.assertIn("restart: unless-stopped", block, name)
        for name in ("bot", "web"):
            self.assertIn("read_only: true", SERVICES[name], name)

    def test_names_cannot_collide_with_other_projects(self):
        names = re.findall(r"container_name: (\S+)", COMPOSE)
        self.assertEqual(sorted(names), ["safrati-bot", "safrati-domain", "safrati-tunnel", "safrati-web"])
        self.assertTrue(COMPOSE.startswith("# Safrati") or "name: safrati\n" in COMPOSE)
        self.assertRegex(COMPOSE, r"(?m)^name: safrati$")
        self.assertEqual(re.findall(r"(?m)^  (safrati_data):$", COMPOSE), ["safrati_data"])

    def test_images(self):
        self.assertEqual(re.findall(r"image: (safrati-bot:local)", SERVICES["bot"]), ["safrati-bot:local"])
        self.assertIn("image: safrati-bot:local", SERVICES["web"])
        self.assertIn("build: .", SERVICES["web"])               # an update always builds the website from the same files as the bot
        tunnels = re.findall(r"image: (cloudflare/cloudflared:\S+)", COMPOSE)
        self.assertEqual(len(tunnels), 2)
        self.assertEqual(len(set(tunnels)), 1)
        for image in tunnels:
            self.assertRegex(image, r"^cloudflare/cloudflared:20\d\d\.\d{1,2}\.\d{1,2}$")       # a fixed version, never "latest"

    def test_the_docker_image_carries_only_the_package(self):
        dockerfile = (ROOT / "Dockerfile").read_text(encoding="utf-8")
        self.assertIn("COPY safrati/ /app/safrati/", dockerfile)
        self.assertEqual(re.findall(r"(?m)^COPY .*$", dockerfile), ["COPY safrati/ /app/safrati/"])
        self.assertIn("USER safrati", dockerfile)


class SecretsTests(unittest.TestCase):
    def test_the_website_gets_prices_but_never_the_telegram_token(self):
        web = SERVICES["web"]
        self.assertNotIn("env_file", web)               # it is given a short list instead of the whole settings file
        env = environment(web)
        for secret in ("BOT_TOKEN", "ADMIN_CODE", "TUNNEL_TOKEN", "DB_PATH", "HEARTBEAT_PATH"):
            self.assertNotIn(secret, env)
            self.assertNotIn(secret, web)
        self.assertIn("TP_TOKEN", env)

    def test_the_list_only_names_settings_the_website_reads(self):
        read = set(re.findall(r'env\.get\("([A-Z_]+)"\)', SETTINGS)) | set(re.findall(r'_int\(env, "([A-Z_]+)"', SETTINGS))
        self.assertTrue({"TP_TOKEN", "WEB_SITE_URL", "WEB_REAL_IP_HEADER", "BOT_USERNAME"} <= read)
        for key in environment(SERVICES["web"]):
            if key != "TZ":
                self.assertIn(key, read, f"{key} is passed to the website but nothing reads it")

    def test_the_tunnel_token_reaches_only_the_domain_tunnel(self):
        self.assertEqual(re.findall(r"env_file: (\S+)", COMPOSE), [".env", ".tunnel.env"])
        self.assertIn("env_file: .env\n", SERVICES["bot"])
        self.assertIn("env_file: .tunnel.env", SERVICES["tunnel-domain"])
        self.assertNotIn("env_file", SERVICES["tunnel"])
        for name in ("tunnel", "tunnel-domain"):
            self.assertNotIn("BOT_TOKEN", SERVICES[name])
        for name in (".dockerignore", ".gitignore"):
            self.assertIn(".tunnel.env", (ROOT / name).read_text(encoding="utf-8").splitlines(), name)

    def test_the_tunnels_only_talk_to_the_website(self):
        self.assertIn('"http://web:8088"', SERVICES["tunnel"])
        self.assertIn("depends_on:\n      - web", SERVICES["tunnel"])
        self.assertIn("depends_on:\n      - web", SERVICES["tunnel-domain"])
        self.assertIn('"--no-autoupdate"', SERVICES["tunnel"])
        self.assertIn('"--no-autoupdate"', SERVICES["tunnel-domain"])
        self.assertIn("8088", SETTINGS)

    def test_the_visitor_address_header_is_trusted_only_because_the_tunnel_is_the_only_way_in(self):
        self.assertEqual(environment(SERVICES["web"])["WEB_REAL_IP_HEADER"], "${WEB_REAL_IP_HEADER:-CF-Connecting-IP}")
        self.assertNotIn("ports:", SERVICES["web"])


class HealthAndExampleTests(unittest.TestCase):
    def test_health_checks_exercise_the_real_programs(self):
        self.assertIn('"safrati.healthcheck"', SERVICES["bot"])
        self.assertIn('["CMD", "python", "-m", "safrati.web", "--check"]', SERVICES["web"])
        self.assertIn('command: ["python", "-m", "safrati.web"]', SERVICES["web"])

    def test_the_example_file_documents_every_setting_a_person_may_change(self):
        example = (ROOT / ".env.example").read_text(encoding="utf-8")
        for name in ("SAFRATI_WEB", "WEB_SITE_URL", "BOT_USERNAME", "WEB_RATE_PER_MINUTE", "WEB_UPSTREAM_PER_MINUTE", "WEB_REAL_IP_HEADER"):
            self.assertRegex(example, rf"(?m)^#? ?{name}=", name)
        self.assertNotIn("TUNNEL_TOKEN=", example)            # the tunnel token never lives in the shared settings file
        values = dict(re.findall(r"(?m)^([A-Z_]+)=(.*)$", example))
        self.assertEqual((values["SAFRATI_WEB"], values["WEB_SITE_URL"], values["BOT_USERNAME"]), ("off", "", "SafratiTravel_bot"))
        for secret in ("BOT_TOKEN", "TP_TOKEN", "ADMIN_CODE"):
            self.assertEqual(values[secret], "")


if __name__ == "__main__":
    unittest.main()
