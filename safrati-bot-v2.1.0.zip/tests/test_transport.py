"""The real urllib transports, exercised against a throw-away HTTP server on localhost."""
import json
import socket
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer

from safrati import telegram, tp


class QuietServer(HTTPServer):
    def handle_error(self, request, client_address):  # clients that time out on purpose would otherwise print noise
        pass


class Handler(BaseHTTPRequestHandler):
    seen: list[dict] = []
    plan = {"status": 200, "body": b'{"ok": true}', "delay": 0.0}

    def _record(self):
        length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(length) if length else b""
        Handler.seen.append({"method": self.command, "path": self.path, "headers": dict(self.headers), "body": body})
        if Handler.plan["delay"]:
            import time
            time.sleep(Handler.plan["delay"])
        self.send_response(Handler.plan["status"])
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(Handler.plan["body"])))
        self.end_headers()
        self.wfile.write(Handler.plan["body"])

    do_GET = do_POST = _record

    def log_message(self, *args):
        pass


class TransportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = QuietServer(("127.0.0.1", 0), Handler)
        cls.base = f"http://127.0.0.1:{cls.server.server_address[1]}"
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def setUp(self):
        Handler.seen = []
        Handler.plan = {"status": 200, "body": b'{"ok": true}', "delay": 0.0}

    def test_telegram_post_sends_json_and_returns_status_and_body(self):
        payload = json.dumps({"chat_id": 1, "text": "مرحبا"}, ensure_ascii=False).encode()
        status, raw = telegram._urllib_transport(self.base + "/botX/sendMessage", payload, 5)
        self.assertEqual((status, json.loads(raw)), (200, {"ok": True}))
        seen = Handler.seen[0]
        self.assertEqual((seen["method"], seen["path"]), ("POST", "/botX/sendMessage"))
        self.assertEqual(seen["headers"]["Content-Type"], "application/json")
        self.assertEqual(json.loads(seen["body"].decode("utf-8"))["text"], "مرحبا")

    def test_telegram_error_statuses_are_returned_not_raised(self):
        Handler.plan = {"status": 429, "body": b'{"ok": false, "error_code": 429, "parameters": {"retry_after": 3}}', "delay": 0}
        status, raw = telegram._urllib_transport(self.base + "/botX/sendMessage", b"{}", 5)
        self.assertEqual(status, 429)
        self.assertEqual(json.loads(raw)["parameters"]["retry_after"], 3)

    def test_tp_get_and_post_carry_the_token_header_only(self):
        status, raw = tp._urllib_transport("GET", self.base + "/prices?origin=RUH", {"X-Access-Token": "tok123"}, None, 5)
        self.assertEqual(status, 200)
        status, raw = tp._urllib_transport(
            "POST", self.base + "/links", {"X-Access-Token": "tok123", "Content-Type": "application/json"}, b'{"a": 1}', 5
        )
        get, post = Handler.seen
        self.assertEqual(get["headers"]["X-Access-Token"], "tok123")
        self.assertNotIn("tok123", get["path"])
        self.assertEqual((post["method"], post["body"]), ("POST", b'{"a": 1}'))

    def test_tp_error_status_is_returned(self):
        Handler.plan = {"status": 401, "body": b'{"error": "bad token"}', "delay": 0}
        status, raw = tp._urllib_transport("GET", self.base + "/x", {}, None, 5)
        self.assertEqual(status, 401)

    def test_connection_refused_becomes_a_clean_error(self):
        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            port = s.getsockname()[1]
        with self.assertRaises(telegram.TelegramError) as t1:
            telegram._urllib_transport(f"http://127.0.0.1:{port}/botSECRET/getMe", b"{}", 2)
        with self.assertRaises(tp.TPError) as t2:
            tp._urllib_transport("GET", f"http://127.0.0.1:{port}/secret-path", {}, None, 2)
        for err in (t1.exception, t2.exception):
            self.assertIn("network error", str(err))
            self.assertNotIn("SECRET", str(err))
            self.assertNotIn("127.0.0.1", str(err))

    def test_timeout_becomes_a_clean_error(self):
        Handler.plan = {"status": 200, "body": b"{}", "delay": 1.5}
        with self.assertRaises(telegram.TelegramError) as ctx:
            telegram._urllib_transport(self.base + "/botSECRET/getUpdates", b"{}", 0.3)
        self.assertNotIn("SECRET", str(ctx.exception))


class UploadTests(unittest.IsolatedAsyncioTestCase):
    async def test_a_photo_goes_out_as_a_multipart_upload(self):
        server = QuietServer(("127.0.0.1", 0), Handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        Handler.seen = []
        Handler.plan = {"status": 200, "body": json.dumps({"ok": True, "result": {"message_id": 5}}).encode(), "delay": 0}
        old = telegram.API
        telegram.API = f"http://127.0.0.1:{server.server_address[1]}"
        self.addCleanup(setattr, telegram, "API", old)
        api = telegram.TelegramAPI("123456789:" + "A" * 35)
        await api.send_photo("@chan", b"\x89PNG\r\n\x1a\nBYTES", "عربي", {"inline_keyboard": [[{"text": "x", "url": "https://t.me/b"}]]})
        seen = Handler.seen[0]
        self.assertTrue(seen["path"].endswith("/sendPhoto"))
        self.assertTrue(seen["headers"]["Content-Type"].startswith("multipart/form-data; boundary="))
        self.assertIn(b"BYTES", seen["body"])
        self.assertIn("عربي".encode(), seen["body"])


class EndToEndOverHttpTests(unittest.IsolatedAsyncioTestCase):
    async def test_api_client_against_a_local_server(self):
        server = QuietServer(("127.0.0.1", 0), Handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        Handler.seen = []
        Handler.plan = {"status": 200, "body": json.dumps({"ok": True, "result": {"username": "x"}}).encode(), "delay": 0}
        base = f"http://127.0.0.1:{server.server_address[1]}"
        old = telegram.API
        telegram.API = base
        self.addCleanup(setattr, telegram, "API", old)
        api = telegram.TelegramAPI("123456789:" + "A" * 35)
        me = await api.get_me()
        self.assertEqual(me, {"username": "x"})
        self.assertEqual(Handler.seen[0]["path"], "/bot123456789:" + "A" * 35 + "/getMe")

        Handler.plan = {"status": 400, "body": json.dumps({"ok": False, "error_code": 400, "description": "Bad Request: chat not found"}).encode(), "delay": 0}
        with self.assertRaises(telegram.TelegramError) as ctx:
            await api.send_message(1, "x")
        self.assertEqual(ctx.exception.status, 400)
        self.assertIn("chat not found", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
