"""The website's files: what is served, what the page's security policy allows, and that the pieces fit together."""
import json
import re
import shutil
import struct
import subprocess
import tempfile
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

from safrati import __version__
from safrati.web.api import STATIC_DIR, WebApp, load_static
from safrati.web.server import Request, SECURITY_HEADERS
from safrati.web.settings import WebSettings

SITE = "https://example.com"
HTML = (STATIC_DIR / "index.html").read_text(encoding="utf-8")
JS = (STATIC_DIR / "app.js").read_text(encoding="utf-8")
CSS = (STATIC_DIR / "app.css").read_text(encoding="utf-8")


def png_size(path: Path) -> tuple[int, int]:
    raw = path.read_bytes()
    assert raw[:8] == b"\x89PNG\r\n\x1a\n", f"{path.name} is not a PNG"
    return struct.unpack(">II", raw[16:24])


class ServingTests(unittest.TestCase):
    def test_every_file_of_the_folder_is_served_under_its_own_name(self):
        assets = load_static(WebSettings())
        for name in ("/", "/index.html", "/app.css", "/app.js", "/favicon.svg", "/apple-touch-icon.png", "/icon-192.png",
                     "/icon-512.png", "/icon-maskable-512.png", "/og.png", "/manifest.webmanifest", "/robots.txt"):
            self.assertIn(name, assets)
        self.assertIs(assets["/"], assets["/index.html"])
        self.assertNotIn("/sitemap.xml", assets)             # it only makes sense with the website's own address

    def test_content_types_and_caching(self):
        assets = load_static(WebSettings())
        expected = {
            "/": ("text/html; charset=utf-8", "no-cache"), "/app.css": ("text/css; charset=utf-8", "public, max-age=86400"),
            "/app.js": ("text/javascript; charset=utf-8", "public, max-age=86400"), "/favicon.svg": ("image/svg+xml", "public, max-age=86400"),
            "/og.png": ("image/png", "public, max-age=86400"), "/manifest.webmanifest": ("application/manifest+json", "no-cache"),
            "/robots.txt": ("text/plain; charset=utf-8", "no-cache"),
        }
        for name, (kind, cache) in expected.items():
            self.assertEqual((assets[name].content_type, assets[name].cache), (kind, cache), name)

    def test_placeholders_are_filled_everywhere(self):
        assets = load_static(WebSettings(channel_url="https://t.me/deals_channel"))
        for name, asset in assets.items():
            if asset.content_type.startswith(("text/", "application/")):
                text = asset.body.decode("utf-8")
                self.assertNotIn("{{", text, name)
                self.assertNotIn("<!--", text, name)
        page = assets["/"].body.decode("utf-8")
        self.assertIn(f"/app.css?v={__version__}", page)
        self.assertIn(f"/app.js?v={__version__}", page)
        self.assertIn('href="https://t.me/SafratiTravel_bot"', page)
        self.assertIn('href="https://t.me/deals_channel"', page)

    def test_a_temporary_address_is_not_indexed(self):
        assets = load_static(WebSettings())
        page = assets["/"].body.decode("utf-8")
        self.assertIn('content="noindex, nofollow"', page)
        self.assertNotIn("canonical", page)
        self.assertNotIn("og:image", page)
        self.assertEqual(assets["/robots.txt"].body.decode().split(), ["User-agent:", "*", "Disallow:", "/"])

    def test_the_real_address_is_indexed_with_a_sitemap(self):
        assets = load_static(WebSettings(site_url=SITE))
        page = assets["/"].body.decode("utf-8")
        self.assertNotIn("noindex", page)
        self.assertIn(f'<link rel="canonical" href="{SITE}/">', page)
        self.assertIn(f'<meta property="og:image" content="{SITE}/og.png">', page)
        robots = assets["/robots.txt"].body.decode("utf-8")
        self.assertIn("Allow: /", robots)
        self.assertIn("Disallow: /api/", robots)
        self.assertIn("Disallow: /go", robots)
        self.assertIn(f"Sitemap: {SITE}/sitemap.xml", robots)
        sitemap = ET.fromstring(assets["/sitemap.xml"].body)
        self.assertEqual([e.text for e in sitemap.iter("{http://www.sitemaps.org/schemas/sitemap/0.9}loc")], [f"{SITE}/"])

    def test_the_channel_link_appears_only_when_there_is_a_channel(self):
        without = load_static(WebSettings())["/"].body.decode("utf-8")
        self.assertNotIn("قناة العروض", without)
        with_channel = load_static(WebSettings(channel_url="https://t.me/deals_channel"))["/"].body.decode("utf-8")
        self.assertIn("قناة العروض", with_channel)

    def test_unknown_kinds_of_file_are_never_served(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "index.html").write_text("<p>hi</p>", encoding="utf-8")
            for name in (".env", "secrets.py", "app.js.map", "notes.md", "data.json", "backup.zip", "id_rsa"):
                (folder / name).write_text("secret", encoding="utf-8")
            (folder / "sub").mkdir()
            (folder / "sub" / "x.png").write_bytes(b"\x89PNG")
            assets = load_static(WebSettings(), folder)
            self.assertEqual(sorted(assets), ["/", "/index.html"])

    def test_a_site_without_a_front_page_does_not_start(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(FileNotFoundError):
                load_static(WebSettings(), Path(tmp))

    def test_pages_are_found_by_exact_name_only(self):
        app = WebApp(WebSettings(), None, static=load_static(WebSettings()))      # no price engine is needed for files
        import asyncio

        async def get(path, headers=None):
            return await app.handle(Request("GET", path, {}, headers or {}, "1.1.1.1"))

        res = asyncio.run(get("/app.js"))
        self.assertEqual(res.status, 200)
        for path in ("/app.js/", "/APP.JS", "/static/app.js", "/../safrati/web/api.py", "/%2e%2e/api.py", "/app.js%00.png", "/.env", "//app.js", "/index"):
            self.assertEqual(asyncio.run(get(path)).status, 404, path)
        first = asyncio.run(get("/"))
        again = asyncio.run(get("/", {"if-none-match": first.headers["ETag"]}))
        self.assertEqual((again.status, again.body), (304, b""))
        other = asyncio.run(get("/", {"if-none-match": 'W/"something-else"'}))
        self.assertEqual(other.status, 200)


class PageRulesTests(unittest.TestCase):
    """The page's security policy forbids inline code and styles; these rules keep the files inside it."""

    def test_the_policy_is_strict(self):
        csp = SECURITY_HEADERS["Content-Security-Policy"]
        self.assertTrue(csp.startswith("default-src 'none'"))
        self.assertIn("script-src 'self'", csp)
        for bad in ("unsafe-inline", "unsafe-eval", "http:", "*"):
            self.assertNotIn(bad, csp)
        for directive in ("base-uri 'none'", "frame-ancestors 'none'", "form-action 'self'", "connect-src 'self'"):
            self.assertIn(directive, csp)

    def test_html_has_no_inline_script_style_or_handler(self):
        for attrs, body in re.findall(r"<script\b([^>]*)>(.*?)</script>", HTML, re.S):
            self.assertIn("src=", attrs)
            self.assertEqual(body.strip(), "")
        self.assertNotRegex(HTML, r"<style\b")
        self.assertNotRegex(HTML, r"\sstyle\s*=")
        self.assertNotRegex(HTML, r"\son[a-z]+\s*=")
        self.assertNotRegex(HTML, r"javascript:")

    def test_html_basics(self):
        self.assertIn('<html lang="ar" dir="rtl">', HTML)
        self.assertIn("viewport-fit=cover", HTML)
        self.assertIn('<main id="app"', HTML)
        self.assertIn("<noscript>", HTML)
        self.assertEqual(HTML.count("<h1"), 0)           # the page's one heading is drawn by the script; the title tag names the page
        self.assertRegex(HTML, r"<title>[^<]+</title>")

    def test_local_files_the_page_names_exist_and_outside_hosts_are_only_fonts(self):
        names = re.findall(r'(?:href|src)="(/[^"#?]*)(?:\?[^"]*)?"', HTML)
        self.assertTrue(names)
        for name in names:
            self.assertTrue((STATIC_DIR / name.lstrip("/")).is_file(), name)
        hosts = set(re.findall(r"https?://([^/\"'{}\s]+)", HTML)) - {"www.w3.org"}
        self.assertEqual(hosts, {"fonts.googleapis.com", "fonts.gstatic.com"})

    def test_script_never_builds_markup_from_text_or_runs_text_as_code(self):
        forbidden = {
            "innerHTML": r"\binnerHTML\b", "outerHTML": r"\bouterHTML\b", "insertAdjacentHTML": r"insertAdjacentHTML",
            "document.write": r"document\s*\.\s*write", "eval": r"\beval\s*\(", "Function constructor": r"\bnew\s+Function\b|(?<![\w.])Function\s*\(",
            "timer with a string": r"set(?:Timeout|Interval)\s*\(\s*['\"`]", "javascript: address": r"javascript:",
            "style attribute": r"setAttribute\(\s*['\"]style['\"]", "cssText": r"\bcssText\b", "cookie": r"document\s*\.\s*cookie",
            "dynamic script": r"createElement\(\s*['\"]script['\"]", "iframe": r"createElement\(\s*['\"]iframe['\"]",
            "XMLHttpRequest": r"XMLHttpRequest", "WebSocket": r"WebSocket", "sendBeacon": r"sendBeacon",
        }
        for label, pattern in forbidden.items():
            self.assertNotRegex(JS, pattern, label)

    def test_script_talks_only_to_its_own_server_and_to_google_fonts(self):
        hosts = set(re.findall(r"https?://([^/'\"`\s]+)", JS))
        self.assertEqual(hosts, {"www.w3.org", "fonts.googleapis.com"})
        calls = re.findall(r"\bapi\(\s*(['\"`])([^'\"`]*)\1", JS)
        self.assertTrue(calls)
        for _, path in calls:
            self.assertTrue(path.startswith("/api/"), path)
        self.assertEqual(len(re.findall(r"\bfetch\(", JS)), 1)

    def test_every_server_call_the_script_makes_exists(self):
        routes = set(WebApp(WebSettings(), None, static={})._routes)
        used = set(re.findall(r"['\"`](/api/[a-z]+)['\"`]", JS))
        self.assertTrue(used)
        self.assertTrue(used <= routes, used - routes)
        for name in routes - {"/go"}:
            self.assertIn(name, used, f"{name} is never used by the page")

    def test_browser_storage_is_always_guarded(self):
        lines = [line for line in JS.splitlines() if "localStorage" in line]
        self.assertTrue(lines)
        for line in lines:
            self.assertIn("try", line)
        self.assertNotIn("sessionStorage", JS)
        self.assertNotIn("indexedDB", JS)

    def test_script_has_valid_syntax(self):
        node = shutil.which("node")
        if not node:
            self.skipTest("node is not installed")
        result = subprocess.run([node, "--check", str(STATIC_DIR / "app.js")], capture_output=True, text=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_stylesheet_is_self_contained(self):
        self.assertNotRegex(CSS, r"@import")
        self.assertNotRegex(CSS, r"url\(")
        self.assertNotRegex(CSS, r"expression\(|(?<![\w-])behavior\s*:|-moz-binding")        # old script-in-style tricks; scroll-behavior is fine
        root = re.search(r":root\s*\{(.*?)\n\}", CSS, re.S).group(1)
        defined = set(re.findall(r"--([a-z0-9-]+)\s*:", root))
        used = set(re.findall(r"var\(--([a-z0-9-]+)", CSS))
        self.assertTrue(used <= defined | {"vc", "vbg", "stub"}, used - defined)         # the last three are set on single components
        self.assertIn("prefers-reduced-motion", CSS)
        self.assertIn("prefers-color-scheme: dark", CSS)
        self.assertNotRegex(CSS, r"(?<![a-z-])(?:margin|padding)-(?:left|right)\s*:")       # right-to-left first: logical properties only


def _tokens(body: str) -> dict[str, str]:
    return {m.group(1): m.group(2).strip() for m in re.finditer(r"--([a-z0-9-]+):\s*([^;]+);", body)}


def _block(text: str, start: str) -> str:
    i = text.index(start)
    j = text.index("{", i)
    depth = 0
    for k in range(j, len(text)):
        depth += text[k] == "{"
        depth -= text[k] == "}"
        if depth == 0:
            return text[j + 1:k]
    raise ValueError(start)


def _rgba(value: str) -> tuple[float, float, float, float]:
    value = value.strip()
    if value.startswith("#"):
        value = value[1:]
        if len(value) == 3:
            value = "".join(c * 2 for c in value)
        return tuple(int(value[i:i + 2], 16) for i in (0, 2, 4)) + (1.0,)
    parts = [x.strip() for x in re.match(r"rgba?\(([^)]+)\)", value).group(1).split(",")]
    return int(parts[0]), int(parts[1]), int(parts[2]), float(parts[3]) if len(parts) > 3 else 1.0


def _resolve(tokens: dict[str, str], name: str):
    value = tokens[name]
    alias = re.match(r"var\(--([a-z0-9-]+)\)$", value)
    return _resolve(tokens, alias.group(1)) if alias else _rgba(value)


def _flat(fg, bg):
    a = fg[3]
    return tuple(round(fg[i] * a + bg[i] * (1 - a)) for i in range(3))


def _luminance(c) -> float:
    def f(x):
        x /= 255
        return x / 12.92 if x <= 0.03928 else ((x + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2])


def contrast(fg: str, bg: str, tokens: dict[str, str]) -> float:
    page = _flat(_resolve(tokens, "bg"), (255, 255, 255))
    back = _resolve(tokens, bg)
    back = _flat(back, page) if back[3] < 1 else back[:3]
    front = _resolve(tokens, fg)
    front = _flat(front, back) if front[3] < 1 else front[:3]
    hi, lo = sorted((_luminance(front), _luminance(back)), reverse=True)
    return (hi + 0.05) / (lo + 0.05)


class ColourTests(unittest.TestCase):
    TEXT = [("ink", "bg"), ("ink", "card"), ("ink-2", "bg"), ("ink-2", "card"), ("ink-2", "bg-2"), ("muted", "bg"), ("muted", "card"),
            ("muted", "bg-2"), ("low", "low-bg"), ("mid", "mid-bg"), ("high", "high-bg"), ("low", "card"), ("mid", "card"),
            ("high", "card"), ("ink", "low-bg"), ("ink", "mid-bg"), ("ink", "high-bg"), ("ink", "tab-on"), ("bg", "ink")]
    GRAPHIC = [("mark", "card"), ("mark", "bg")]

    def themes(self):
        light = _tokens(_block(CSS, ":root {"))
        dark = {**light, **_tokens(_block(_block(CSS, "@media (prefers-color-scheme: dark)"), ":root {"))}
        return {"light": light, "dark": dark}

    def test_text_is_readable_in_both_themes(self):
        for theme, tokens in self.themes().items():
            for fg, bg in self.TEXT:
                self.assertGreaterEqual(contrast(fg, bg, tokens), 4.5, f"{theme}: {fg} on {bg}")

    def test_the_orange_mark_and_focus_ring_can_be_seen_in_both_themes(self):
        for theme, tokens in self.themes().items():
            for fg, bg in self.GRAPHIC:
                self.assertGreaterEqual(contrast(fg, bg, tokens), 3.0, f"{theme}: {fg} on {bg}")

    def test_the_button_text_is_readable_on_the_whole_orange_gradient(self):
        navy = (11, 21, 48)
        for end in ((255, 179, 71), (255, 106, 36)):          # #ffb347 and #ff6a24, the ends of the gradient
            hi, lo = sorted((_luminance(navy), _luminance(end)), reverse=True)
            self.assertGreaterEqual((hi + 0.05) / (lo + 0.05), 4.5)
        self.assertIn("#ffb347", CSS)
        self.assertIn("#ff6a24", CSS)


class IconTests(unittest.TestCase):
    def test_manifest(self):
        manifest = json.loads((STATIC_DIR / "manifest.webmanifest").read_text(encoding="utf-8"))
        self.assertEqual((manifest["lang"], manifest["dir"], manifest["display"], manifest["start_url"]), ("ar", "rtl", "standalone", "/"))
        self.assertEqual(manifest["name"], "صائد العروض")
        purposes = set()
        for icon in manifest["icons"]:
            path = STATIC_DIR / icon["src"].lstrip("/")
            self.assertTrue(path.is_file(), icon["src"])
            side = int(icon["sizes"].split("x")[0])
            self.assertEqual(png_size(path), (side, side))
            purposes.add(icon["purpose"])
        self.assertEqual(purposes, {"any", "maskable"})
        dark_bg = _tokens(_block(_block(CSS, "@media (prefers-color-scheme: dark)"), ":root {"))["bg"]
        self.assertEqual(manifest["theme_color"].lower(), dark_bg.lower())
        self.assertEqual(manifest["background_color"].lower(), dark_bg.lower())

    def test_icon_sizes(self):
        self.assertEqual(png_size(STATIC_DIR / "apple-touch-icon.png"), (180, 180))
        self.assertEqual(png_size(STATIC_DIR / "og.png"), (1200, 630))
        self.assertLess((STATIC_DIR / "og.png").stat().st_size, 300_000)     # chat apps skip very heavy preview images

    def test_the_favicon_is_a_plain_picture(self):
        text = (STATIC_DIR / "favicon.svg").read_text(encoding="utf-8")
        root = ET.fromstring(text)
        self.assertTrue(root.tag.endswith("svg"))
        self.assertIn("viewBox", root.attrib)
        self.assertNotRegex(text, r"<script|\son[a-z]+=|href=|<foreignObject|<image")

    def test_every_file_is_small_enough_to_keep_in_memory(self):
        total = sum(p.stat().st_size for p in STATIC_DIR.iterdir() if p.is_file())
        self.assertLess(total, 1_000_000)


if __name__ == "__main__":
    unittest.main()
