"""The website's HTTP server: strict parsing, limits, security headers, and what it never writes to the log."""
import asyncio
import gzip
import unittest
from unittest import mock

from safrati.web import server as srv
from safrati.web.server import (
    RateLimiter, Request, Response, WebServer, client_key, error_response, json_response, parse_request,
)


def head(*lines: str) -> bytes:
    return ("\r\n".join(lines) + "\r\n\r\n").encode("latin-1")


class ParseTests(unittest.TestCase):
    def test_get_with_arabic_query(self):
        req = parse_request(head("GET /api/understand?q=%D8%AF%D8%A8%D9%8A&o=RUH HTTP/1.1", "Host: x"), "9.9.9.9")
        self.assertIsInstance(req, Request)
        self.assertEqual((req.method, req.path, req.query), ("GET", "/api/understand", {"q": "دبي", "o": "RUH"}))
        self.assertEqual(req.ip, "9.9.9.9")

    def test_head_is_allowed(self):
        self.assertIsInstance(parse_request(head("HEAD / HTTP/1.1"), "1.1.1.1"), Request)
        self.assertIsInstance(parse_request(head("GET / HTTP/1.0"), "1.1.1.1"), Request)

    def test_every_other_method_is_refused_with_405(self):
        for method in ("POST", "PUT", "DELETE", "PATCH", "OPTIONS", "TRACE", "CONNECT"):
            res = parse_request(head(f"{method} / HTTP/1.1"), "1.1.1.1")
            self.assertIsInstance(res, Response, method)
            self.assertEqual(res.status, 405, method)
            self.assertEqual(res.headers["Allow"], "GET, HEAD")

    def test_garbage_is_400(self):
        for line in ("GET /", "get / HTTP/1.1", "GET / HTTP/2.0", "GET /a b HTTP/1.1", "GET / HTTP/1.1 extra", "", "\x00\x01"):
            res = parse_request(head(line), "1.1.1.1")
            self.assertIsInstance(res, Response, repr(line))
            self.assertEqual(res.status, 400, repr(line))

    def test_target_must_be_one_absolute_path(self):
        for target in ("//evil.com/x", "http://evil.com/", "*", "x", "?a=b"):
            res = parse_request(head(f"GET {target} HTTP/1.1"), "1.1.1.1")
            self.assertIsInstance(res, Response, target)
            self.assertEqual(res.status, 400, target)

    def test_bad_header_lines_are_400(self):
        for bad in ("NoColon", "Bad Name: x", "X Y: z", ": empty"):
            res = parse_request(head("GET / HTTP/1.1", bad), "1.1.1.1")
            self.assertIsInstance(res, Response, bad)
            self.assertEqual(res.status, 400, bad)

    def test_too_many_headers_is_400(self):
        lines = ["GET / HTTP/1.1"] + [f"X-{i}: 1" for i in range(srv.MAX_HEADERS + 1)]
        res = parse_request(head(*lines), "1.1.1.1")
        self.assertIsInstance(res, Response)
        self.assertEqual(res.status, 400)

    def test_query_limits(self):
        many = "&".join(f"k{i}=1" for i in range(srv.MAX_QUERY_FIELDS + 1))
        self.assertEqual(parse_request(head(f"GET /?{many} HTTP/1.1"), "1.1.1.1").status, 400)
        req = parse_request(head(f"GET /?{'k' * 100}={'v' * 1000} HTTP/1.1"), "1.1.1.1")
        (key, value), = req.query.items()
        self.assertEqual((len(key), len(value)), (40, srv.MAX_VALUE))

    def test_invalid_utf8_in_query_never_crashes(self):
        req = parse_request(head("GET /?q=%FF%FE%80 HTTP/1.1"), "1.1.1.1")
        self.assertIsInstance(req, Request)
        self.assertIn("�", req.query["q"])

    def test_header_names_are_lowercased(self):
        req = parse_request(head("GET / HTTP/1.1", "Accept-Encoding: gzip", "X-Dup: first", "X-Dup: second"), "1.1.1.1")
        self.assertEqual(req.headers["accept-encoding"], "gzip")
        self.assertEqual(req.headers["x-dup"], "first")

    def test_visitor_address_comes_from_the_proxy_header_only_when_configured(self):
        raw = head("GET / HTTP/1.1", "CF-Connecting-IP: 5.6.7.8, 10.0.0.1", "X-Forwarded-For: 1.2.3.4")
        self.assertEqual(parse_request(raw, "172.18.0.2").ip, "172.18.0.2")
        self.assertEqual(parse_request(raw, "172.18.0.2", "cf-connecting-ip").ip, "5.6.7.8")
        self.assertEqual(parse_request(head("GET / HTTP/1.1"), "172.18.0.2", "cf-connecting-ip").ip, "172.18.0.2")
        self.assertEqual(parse_request(head("GET / HTTP/1.1", "CF-Connecting-IP: "), "172.18.0.2", "cf-connecting-ip").ip, "172.18.0.2")


class ClientKeyTests(unittest.TestCase):
    def test_ipv4_is_itself(self):
        self.assertEqual(client_key("5.6.7.8"), "5.6.7.8")

    def test_one_ipv6_block_is_one_visitor(self):
        self.assertEqual(client_key("2001:db8:1:2:aaaa:bbbb:cccc:dddd"), client_key("2001:db8:1:2:1111:2222:3333:4444"))
        self.assertNotEqual(client_key("2001:db8:1:2::1"), client_key("2001:db8:1:3::1"))

    def test_mapped_ipv4_and_garbage(self):
        self.assertEqual(client_key("::ffff:5.6.7.8"), "5.6.7.8")
        self.assertEqual(client_key("not an address" * 20), ("not an address" * 20)[:64])


class RateLimiterTests(unittest.TestCase):
    def test_burst_then_wait_then_refill(self):
        now = [0.0]
        limiter = RateLimiter(60, burst=3, clock=lambda: now[0])          # one token a second
        self.assertEqual([limiter.take("a") for _ in range(3)], [0.0, 0.0, 0.0])
        wait = limiter.take("a")
        self.assertAlmostEqual(wait, 1.0, places=3)
        self.assertEqual(limiter.take("b"), 0.0)                           # another visitor has a full bucket
        now[0] += 2.0
        self.assertEqual(limiter.take("a"), 0.0)
        self.assertEqual(limiter.take("a"), 0.0)
        self.assertGreater(limiter.take("a"), 0.0)

    def test_memory_is_bounded_and_forgets_the_oldest(self):
        limiter = RateLimiter(60, burst=1, clock=lambda: 0.0)
        with mock.patch.object(srv, "MAX_TRACKED_CLIENTS", 50):
            for i in range(200):
                limiter.take(f"visitor-{i}")
        self.assertLessEqual(len(limiter._buckets), 50)
        self.assertIn("visitor-199", limiter._buckets)
        self.assertNotIn("visitor-0", limiter._buckets)

    def test_a_refused_request_does_not_make_the_visitor_wait_longer(self):
        limiter = RateLimiter(60, burst=1, clock=lambda: 0.0)
        limiter.take("a")
        first = limiter.take("a")
        for _ in range(20):
            limiter.take("a")
        self.assertAlmostEqual(limiter.take("a"), first, places=3)


async def talk(port: int, data: bytes, *, timeout: float = 5.0) -> tuple[int, dict, bytes]:
    """Send raw bytes, read until the server closes the connection."""
    reader, writer = await asyncio.open_connection("127.0.0.1", port)
    writer.write(data)
    await writer.drain()
    raw = await asyncio.wait_for(reader.read(), timeout)
    writer.close()
    top, _, body = raw.partition(b"\r\n\r\n")
    lines = top.decode("latin-1").split("\r\n")
    headers = {}
    for line in lines[1:]:
        k, v = line.split(": ", 1)
        headers[k.lower()] = v
    return int(lines[0].split()[1]), headers, body


def get(path: str, *extra: str) -> bytes:
    return head(f"GET {path} HTTP/1.1", "Host: x", *extra)


async def hello(request: Request) -> Response:
    if request.path == "/big":
        return Response(200, ("x" * 5000).encode(), "text/plain; charset=utf-8")
    if request.path == "/boom":
        raise RuntimeError("secret internals at /srv/app.py line 12")
    if request.path == "/slow":
        await asyncio.sleep(5)
    if request.path == "/inject":
        return Response(200, b"ok", "text/plain", {"X-Bad": "a\r\nSet-Cookie: x=1", "X-Good": "fine"})
    if request.path == "/echo":
        return json_response({"ok": True, "q": request.query.get("q", "")})
    if request.path.startswith("/api/"):
        return json_response({"ok": True})
    return Response(200, b"hello", "text/plain; charset=utf-8")


class LiveServerTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.server = WebServer(hello, real_ip_header="x-test-ip", api_per_minute=60, static_per_minute=6000, clock=lambda: 0.0)
        self.port = await self.server.start("127.0.0.1", 0)
        self.addAsyncCleanup(self.server.close)

    async def test_plain_answer_has_every_security_header_and_closes(self):
        status, headers, body = await talk(self.port, get("/"))
        self.assertEqual((status, body), (200, b"hello"))
        for name in srv.SECURITY_HEADERS:
            self.assertEqual(headers[name.lower()], srv.SECURITY_HEADERS[name], name)
        self.assertEqual(headers["connection"], "close")
        self.assertEqual(headers["content-length"], "5")
        self.assertIn("default-src 'none'", headers["content-security-policy"])
        self.assertNotIn("'unsafe-inline'", headers["content-security-policy"])
        self.assertNotIn("'unsafe-eval'", headers["content-security-policy"])

    async def test_security_headers_are_on_errors_too(self):
        cases = [
            (b"POST / HTTP/1.1\r\n\r\n", 405),
            (b"garbage\r\n\r\n", 400),
            (get("/boom"), 500),
        ]
        for raw, expected in cases:
            if expected == 500:
                with self.assertLogs("safrati.web", level="ERROR"):
                    status, headers, _ = await talk(self.port, raw)
            else:
                status, headers, _ = await talk(self.port, raw)
            self.assertEqual(status, expected)
            self.assertIn("content-security-policy", headers)
            self.assertEqual(headers["x-content-type-options"], "nosniff")

    async def test_head_has_length_but_no_body(self):
        status, headers, body = await talk(self.port, head("HEAD /big HTTP/1.1"))
        self.assertEqual((status, body), (200, b""))
        self.assertEqual(headers["content-length"], "5000")

    async def test_gzip_only_for_big_text_when_asked(self):
        _, headers, body = await talk(self.port, get("/big", "Accept-Encoding: gzip, br"))
        self.assertEqual(headers["content-encoding"], "gzip")
        self.assertEqual(gzip.decompress(body), b"x" * 5000)
        self.assertEqual(int(headers["content-length"]), len(body))
        _, headers, body = await talk(self.port, get("/big"))
        self.assertNotIn("content-encoding", headers)
        self.assertEqual(len(body), 5000)
        _, headers, body = await talk(self.port, get("/", "Accept-Encoding: gzip"))
        self.assertNotIn("content-encoding", headers)
        self.assertEqual(headers["vary"], "Accept-Encoding")

    async def test_a_header_value_with_a_line_break_is_dropped_not_sent(self):
        status, headers, body = await talk(self.port, get("/inject"))
        self.assertEqual((status, body), (200, b"ok"))
        self.assertNotIn("x-bad", headers)
        self.assertNotIn("set-cookie", headers)
        self.assertEqual(headers["x-good"], "fine")

    async def test_handler_crash_gives_500_without_internals(self):
        with self.assertLogs("safrati.web", level="ERROR"):
            status, _, body = await talk(self.port, get("/boom"))
        self.assertEqual(status, 500)
        self.assertNotIn(b"secret", body)
        self.assertNotIn(b"Traceback", body)
        self.assertEqual(self.server.stats["errors"], 1)
        self.assertEqual((await talk(self.port, get("/")))[0], 200)         # and the server carries on

    async def test_slow_handler_gives_504(self):
        with mock.patch.object(srv, "HANDLER_TIMEOUT", 0.2):
            status, _, _ = await talk(self.port, get("/slow"))
        self.assertEqual(status, 504)

    async def test_oversize_head_is_431(self):
        status, _, _ = await talk(self.port, b"GET / HTTP/1.1\r\nX-A: " + b"a" * (srv.MAX_HEAD + 500) + b"\r\n\r\n")
        self.assertEqual(status, 431)

    async def test_client_that_says_nothing_is_let_go(self):
        with mock.patch.object(srv, "READ_TIMEOUT", 0.2):
            reader, writer = await asyncio.open_connection("127.0.0.1", self.port)
            self.assertEqual(await asyncio.wait_for(reader.read(), 3), b"")        # closed without an answer
            writer.close()
        self.assertEqual((await talk(self.port, get("/")))[0], 200)

    async def test_half_a_request_then_hang_up_changes_nothing(self):
        reader, writer = await asyncio.open_connection("127.0.0.1", self.port)
        writer.write(b"GET / HTTP/1.1\r\nHost: x")
        await writer.drain()
        writer.close()
        await asyncio.sleep(0.05)
        self.assertEqual((await talk(self.port, get("/")))[0], 200)
        self.assertEqual(self.server.stats["errors"], 0)

    async def test_connections_are_capped(self):
        with mock.patch.object(srv, "MAX_CONNECTIONS", 1), mock.patch.object(srv, "READ_TIMEOUT", 1.0):
            r1, w1 = await asyncio.open_connection("127.0.0.1", self.port)      # holds the only place, says nothing
            await asyncio.sleep(0.05)
            r2, w2 = await asyncio.open_connection("127.0.0.1", self.port)
            self.assertEqual(await asyncio.wait_for(r2.read(), 2), b"")           # turned away at once
            w1.close()
            w2.close()

    async def test_api_calls_are_limited_per_visitor_and_pages_are_not(self):
        statuses = [(await talk(self.port, get("/api/x", "X-Test-Ip: 8.8.8.8")))[0] for _ in range(32)]
        self.assertEqual(statuses[:30], [200] * 30)          # burst = half of 60 a minute
        self.assertIn(429, statuses)
        status, headers, body = await talk(self.port, get("/api/x", "X-Test-Ip: 8.8.8.8"))
        self.assertEqual(status, 429)
        self.assertGreaterEqual(int(headers["retry-after"]), 1)
        self.assertIn(b"rate_limited", body)
        self.assertEqual((await talk(self.port, get("/api/x", "X-Test-Ip: 9.9.9.9")))[0], 200)      # someone else is fine
        for _ in range(40):                                                                         # pages use a bigger allowance
            self.assertEqual((await talk(self.port, get("/", "X-Test-Ip: 8.8.8.8")))[0], 200)
        self.assertGreater(self.server.stats["limited"], 0)

    async def test_go_counts_as_an_api_call(self):
        statuses = [(await talk(self.port, get("/go?x=1", "X-Test-Ip: 7.7.7.7")))[0] for _ in range(40)]
        self.assertIn(429, statuses)

    async def test_the_log_has_no_visitor_address_and_no_query(self):
        with self.assertLogs("safrati.web", level="INFO") as logs:
            await talk(self.port, get("/api/echo?q=very-private-words", "X-Test-Ip: 203.0.113.77"))
        text = "\n".join(logs.output)
        self.assertIn("/api/echo", text)
        self.assertNotIn("very-private-words", text)
        self.assertNotIn("203.0.113.77", text)
        self.assertNotIn("127.0.0.1", text)

    async def test_a_visitor_cannot_write_into_the_log_through_the_address(self):
        hostile = ["/api/\x1b[2Jscreen-wiped", "/api/%0d%0aFORGED%20LINE", "/api/" + "a" * 500, "/api/é", "/api/\x9bevil"]
        with self.assertLogs("safrati.web", level="INFO") as logs:
            for path in hostile:
                await talk(self.port, get(path))
            await talk(self.port, get("/api/echo"))
        self.assertEqual(len(logs.output), 6)
        for line in logs.output:
            self.assertRegex(line.split(":", 2)[2], r"^(GET|HEAD) [A-Za-z0-9._/()-]{1,60} \d{3} \d+ms$", line)
        self.assertEqual(sum("(other)" in line for line in logs.output), 5)
        self.assertNotIn("FORGED", "\n".join(logs.output))

    async def test_helpers_build_json_and_errors(self):
        res = error_response(429, "rate_limited", "x", {"Retry-After": "3"})
        self.assertEqual((res.status, res.headers["Retry-After"], res.headers["Cache-Control"]), (429, "3", "no-store"))
        self.assertIn("application/json", res.content_type)
        self.assertIn("دبي".encode("utf-8"), json_response({"a": "دبي"}).body)        # Arabic stays readable, not \u escapes


if __name__ == "__main__":
    unittest.main()
