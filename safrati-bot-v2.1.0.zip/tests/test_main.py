import asyncio
import io
import logging
import os
import signal
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest import mock

from safrati import __main__ as entry
from safrati.config import load_settings
from safrati.telegram import TelegramAPI
from safrati.tp import TravelpayoutsClient
from tests.fakes import BOT_TOKEN, MARKER, TP_TOKEN, TRS, FakeTP, FakeTelegram, text_update


class EntryPointTests(unittest.IsolatedAsyncioTestCase):
    async def test_start_serve_and_stop_on_sigterm(self):
        with tempfile.TemporaryDirectory() as tmp:
            settings = load_settings({
                "BOT_TOKEN": BOT_TOKEN, "TP_TOKEN": TP_TOKEN, "TP_MARKER": MARKER, "TP_TRS": TRS,
                "DB_PATH": str(Path(tmp) / "s.db"), "HEARTBEAT_PATH": str(Path(tmp) / "hb"),
            })
            tg, fake = FakeTelegram(), FakeTP()
            tg.updates = [[text_update(5, "/start", update_id=1)]]
            api_factory = lambda token: TelegramAPI(token, transport=tg.transport)  # noqa: E731
            tp_factory = lambda *a, **kw: TravelpayoutsClient(*a, transport=fake.transport, **kw)  # noqa: E731
            with mock.patch.object(entry, "TelegramAPI", api_factory), mock.patch.object(entry, "TravelpayoutsClient", tp_factory):
                with self.assertLogs("safrati", level="INFO") as logs:
                    task = asyncio.create_task(entry.run(settings))
                    for _ in range(300):
                        if tg.sent():
                            break
                        await asyncio.sleep(0.02)
                    self.assertTrue(tg.sent(), "the bot should answer /start")
                    os.kill(os.getpid(), signal.SIGTERM)
                    code = await asyncio.wait_for(task, 15)
            self.assertEqual(code, 0)
            methods = [m for m, _ in tg.calls]
            for needed in ("getMe", "deleteWebhook", "setMyCommands", "setMyDescription", "setMyShortDescription", "getUpdates", "sendMessage"):
                self.assertIn(needed, methods)
            self.assertLessEqual(len(tg.of("setMyDescription")[0]["description"]), 512)
            self.assertLessEqual(len(tg.of("setMyShortDescription")[0]["short_description"]), 120)
            commands = tg.of("setMyCommands")[0]["commands"]
            self.assertEqual([c["command"] for c in commands], ["start", "search", "cheap", "weekend", "alerts", "surprise", "saved", "settings", "about", "privacy"])
            joined = "\n".join(logs.output)
            self.assertIn("started as @SafratiTravel_bot", joined)
            self.assertIn("prices=on partner_links=on", joined)
            self.assertIn("stopped", joined)
            self.assertNotIn(BOT_TOKEN, joined)
            self.assertTrue((Path(tmp) / "s.db").exists())
            self.assertTrue((Path(tmp) / "hb").exists())

    async def test_rejected_token_stops_cleanly(self):
        with tempfile.TemporaryDirectory() as tmp:
            settings = load_settings({"BOT_TOKEN": BOT_TOKEN, "DB_PATH": str(Path(tmp) / "s.db"), "HEARTBEAT_PATH": str(Path(tmp) / "hb")})
            tg = FakeTelegram()
            tg.fail_always["getMe"] = (401, "Unauthorized")
            with mock.patch.object(entry, "TelegramAPI", lambda token: TelegramAPI(token, transport=tg.transport)):
                with self.assertLogs("safrati", level="ERROR"):
                    code = await asyncio.wait_for(entry.run(settings), 10)
            self.assertEqual(code, 1)

    def test_setup_logging_scrubs_secrets(self):
        settings = load_settings({"BOT_TOKEN": BOT_TOKEN, "TP_TOKEN": TP_TOKEN})
        root = logging.getLogger()
        saved, level = root.handlers[:], root.level
        buffer = io.StringIO()
        try:
            with redirect_stdout(buffer):
                entry.setup_logging(settings)
                logging.getLogger("safrati.test").warning("oops %s and %s", BOT_TOKEN, TP_TOKEN)
        finally:
            root.handlers[:] = saved
            root.setLevel(level)
        out = buffer.getvalue()
        self.assertIn("oops", out)
        self.assertNotIn(BOT_TOKEN, out)
        self.assertNotIn(TP_TOKEN, out)


if __name__ == "__main__":
    unittest.main()
