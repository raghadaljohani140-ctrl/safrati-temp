import asyncio
import json
import unittest
import urllib.parse

from safrati import tp
from tests.fakes import FakeTP, MARKER, NOW, TP_TOKEN, TRS


def make(fake: FakeTP, **kw) -> tp.TravelpayoutsClient:
    kw.setdefault("clock", lambda: NOW)
    return tp.TravelpayoutsClient(TP_TOKEN, MARKER, TRS, "sar", transport=fake.transport, **kw)


class PriceTests(unittest.IsolatedAsyncioTestCase):
    async def test_token_only_in_header_never_in_url(self):
        fake = FakeTP()
        client = make(fake)
        await client.cheapest_from("RUH", ["2026-11"])
        await client.partner_links(["https://www.aviasales.com/search/x"])
        self.assertTrue(fake.calls)
        for _method, url, headers, body in fake.calls:
            self.assertNotIn(TP_TOKEN, url)
            self.assertNotIn(TP_TOKEN, (body or b"").decode())
            self.assertEqual(headers["X-Access-Token"], TP_TOKEN)

    async def test_optional_market_and_show_all_parameters(self):
        fake = FakeTP()
        client = make(fake, market="sa", show_all=True)
        await client.prices(origin="RUH", month="2026-11")
        query = dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(fake.calls[0][1]).query))
        self.assertEqual((query["market"], query["show_to_affiliates"]), ("sa", "false"))
        fake2 = FakeTP()
        await make(fake2).prices(origin="RUH", month="2026-11")
        query = dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(fake2.calls[0][1]).query))
        self.assertNotIn("market", query)
        self.assertEqual(query["show_to_affiliates"], "true")

    async def test_cheapest_from_takes_best_month_per_destination(self):
        fake = FakeTP()
        client = make(fake)
        best = await client.cheapest_from("RUH", ["2026-11", "2026-12", "2027-01"])
        # fake adds (month % 3) * 50, so December (12 % 3 = 0) is cheapest
        self.assertEqual(best["IST"].price, 1100)
        self.assertTrue(best["IST"].departure_at.startswith("2026-12"))
        self.assertEqual(best["IST"].currency, "sar")
        self.assertGreater(len(best), 10)

    async def test_same_day_return_is_bad_data_and_skipped(self):
        fake = FakeTP()
        orig = fake._prices

        def patched(params):
            status, body = orig(params)
            payload = json.loads(body)
            payload["data"][0]["return_at"] = payload["data"][0]["departure_at"]
            return status, json.dumps(payload).encode()

        fake._prices = patched
        offers = await make(fake).prices(origin="RUH", month="2026-11", unique=True)
        self.assertTrue(offers)
        self.assertTrue(all(o.return_at[:10] > o.departure_at[:10] for o in offers))
        one_way = await make(fake).prices(origin="RUH", month="2026-11", one_way=True)
        self.assertTrue(one_way)

    async def test_short_trips_are_skipped_in_open_searches_but_not_exact_ones(self):
        fake = FakeTP()
        orig = fake._prices

        def short(params):
            status, body = orig(params)
            payload = json.loads(body)
            for row in payload["data"]:
                row["return_at"] = row["departure_at"][:8] + f"{int(row['departure_at'][8:10]) + 2:02d}T10:00:00+03:00"
            return status, json.dumps(payload).encode()

        fake._prices = short
        client = make(fake)
        self.assertEqual(await client.cheapest_dates("RUH", "IST", ["2026-12"]), [])
        self.assertTrue(await client.exact("RUH", "IST", "2026-12-15", "2026-12-17"))

    async def test_stay_filter_keeps_about_n_days(self):
        client = make(FakeTP())          # the fake's trips are all 7 days long
        self.assertTrue(await client.cheapest_dates("RUH", "IST", ["2026-12"], stay=7))
        self.assertTrue(await client.cheapest_dates("RUH", "IST", ["2026-12"], stay=5) == [])
        self.assertTrue(await client.cheapest_dates("RUH", "IST", ["2026-12"], stay=14) == [])

    async def test_cheapest_to_single_route(self):
        fake = FakeTP()
        client = make(fake)
        offer = await client.cheapest_to("RUH", "IST", ["2026-11", "2026-12"])
        self.assertEqual((offer.origin, offer.destination, offer.price), ("RUH", "IST", 1100))
        self.assertIsNone(await client.cheapest_to("RUH", "XXX", ["2026-11"]))

    async def test_cache_and_expiry(self):
        fake = FakeTP()
        now = [NOW]
        client = make(fake, clock=lambda: now[0], cache_seconds=60)
        await client.prices(origin="RUH", month="2026-11")
        await client.prices(origin="RUH", month="2026-11")
        self.assertEqual(len(fake.price_calls()), 1)
        now[0] += 61
        await client.prices(origin="RUH", month="2026-11")
        self.assertEqual(len(fake.price_calls()), 2)

    async def test_concurrent_identical_requests_share_one_call(self):
        fake = FakeTP()
        client = make(fake)
        results = await asyncio.gather(*(client.prices(origin="RUH", month="2026-11") for _ in range(5)))
        self.assertEqual(len(fake.price_calls()), 1)
        self.assertTrue(all(r == results[0] for r in results))

    async def test_currency_falls_back_to_usd_when_rejected(self):
        fake = FakeTP()
        fake.reject_currencies = {"sar"}
        client = make(fake)
        offers = await client.prices(origin="RUH", month="2026-11")
        self.assertTrue(client.currency_fallback_used)
        self.assertEqual(client.currency, "usd")
        self.assertEqual({o.currency for o in offers}, {"usd"})
        self.assertAlmostEqual(tp.to_sar(100, "usd"), 375.0)

    async def test_provider_answering_in_another_currency_triggers_usd_retry(self):
        fake = FakeTP()
        fake.answer_currency = "rub"
        client = make(fake)
        # the fake keeps answering rub, so after the retry the bot still sees rub: it must not pretend it is riyals
        offers = await client.prices(origin="RUH", month="2026-11")
        self.assertEqual({o.currency for o in offers}, {"rub"})
        self.assertIsNone(tp.to_sar(offers[0].price, offers[0].currency))
        currencies = [dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(c[1]).query))["currency"] for c in fake.price_calls()]
        self.assertEqual(currencies, ["sar", "usd"])

    async def test_auth_error_is_reported_and_circuit_breaks(self):
        fake = FakeTP()
        fake.status = 401
        now = [NOW]
        client = make(fake, clock=lambda: now[0])
        with self.assertRaises(tp.TPError) as ctx:
            await client.prices(origin="RUH", month="2026-11")
        self.assertEqual(ctx.exception.status, 401)
        calls = len(fake.calls)
        with self.assertRaises(tp.TPError):
            await client.prices(origin="RUH", month="2026-12")
        self.assertEqual(len(fake.calls), calls, "no new request while the breaker is open")
        now[0] += 61
        fake.status = 200
        self.assertTrue(await client.prices(origin="RUH", month="2026-12"))

    async def test_server_error_is_reported(self):
        fake = FakeTP()
        fake.status = 500
        client = make(fake)
        with self.assertRaises(tp.TPError):
            await client.cheapest_from("RUH", ["2026-11"])
        self.assertEqual(len(fake.calls), 1)

    async def test_two_failures_in_a_row_open_a_short_breaker(self):
        fake = FakeTP()
        fake.status = 500
        now = [NOW]
        client = make(fake, clock=lambda: now[0])
        for month in ("2026-11", "2026-12"):
            with self.assertRaises(tp.TPError):
                await client.prices(origin="RUH", month=month)
        calls = len(fake.calls)
        with self.assertRaises(tp.TPError):
            await client.prices(origin="RUH", month="2027-01")
        self.assertEqual(len(fake.calls), calls)
        now[0] += 16
        fake.status = 200
        self.assertTrue(await client.prices(origin="RUH", month="2027-01"))

    async def test_partial_failure_still_returns_other_months(self):
        fake = FakeTP()
        client = make(fake)
        original = fake.transport

        def flaky(method, url, headers, body, timeout):
            if "departure_at=2026-11" in url:
                raise tp.TPError("network error: TimeoutError")
            return original(method, url, headers, body, timeout)

        client._transport = flaky
        best = await client.cheapest_from("RUH", ["2026-11", "2026-12"])
        self.assertIn("IST", best)
        self.assertTrue(best["IST"].departure_at.startswith("2026-12"))

    async def test_bad_rows_are_skipped(self):
        fake = FakeTP()
        client = make(fake)

        def odd(method, url, headers, body, timeout):
            rows = [{"destination": "IST"}, {"destination": "DXB", "price": "abc"}, {"destination": "CAI", "price": 500, "link": "/x"}]
            return 200, json.dumps({"success": True, "currency": "sar", "data": rows}).encode()

        client._transport = odd
        offers = await client.prices(origin="RUH", month="2026-11")
        self.assertEqual([o.destination for o in offers], ["CAI"])


class LinkTests(unittest.IsolatedAsyncioTestCase):
    async def test_partner_links_batch_and_partial_support(self):
        fake = FakeTP()
        client = make(fake)
        urls = ["https://www.aviasales.com/search/a", "https://www.airalo.com/", "https://www.tiqets.com/en/"]
        got = await client.partner_links(urls)
        self.assertTrue(got[urls[0]].startswith("https://tp.media/"))
        self.assertTrue(got[urls[1]].startswith("https://tp.media/"))
        self.assertIsNone(got[urls[2]])
        self.assertEqual(len([c for c in fake.calls if c[0] == "POST"]), 1)
        body = json.loads(fake.calls[0][3].decode())
        self.assertEqual((body["trs"], body["marker"], body["shorten"]), (int(TRS), int(MARKER), False))

    async def test_partner_links_are_cached_including_failures(self):
        fake = FakeTP()
        client = make(fake)
        urls = ["https://www.aviasales.com/search/a", "https://www.tiqets.com/en/"]
        await client.partner_links(urls)
        await client.partner_links(urls)
        self.assertEqual(len([c for c in fake.calls if c[0] == "POST"]), 1)

    async def test_failed_links_are_retried_after_the_short_ttl(self):
        fake = FakeTP()
        now = [NOW]
        client = make(fake, clock=lambda: now[0])
        await client.partner_links(["https://www.tiqets.com/en/"])
        now[0] += tp.LINK_FAIL_TTL + 1
        await client.partner_links(["https://www.tiqets.com/en/"])
        self.assertEqual(len([c for c in fake.calls if c[0] == "POST"]), 2)

    async def test_more_than_ten_links_are_split(self):
        fake = FakeTP()
        client = make(fake)
        urls = [f"https://www.aviasales.com/search/{i}" for i in range(23)]
        got = await client.partner_links(urls)
        self.assertEqual(len([c for c in fake.calls if c[0] == "POST"]), 3)
        self.assertTrue(all(got[u] for u in urls))

    async def test_marker_fallback_when_links_api_is_not_configured(self):
        fake = FakeTP()
        client = tp.TravelpayoutsClient(TP_TOKEN, MARKER, "", "sar", transport=fake.transport, clock=lambda: NOW)
        self.assertFalse(client.links_api)
        url = "https://www.aviasales.com/search/RUH1212IST1?t=abc"
        got = await client.partner_links([url], marker_fallback=True)
        self.assertIn(f"marker={MARKER}", got[url])
        self.assertIn("t=abc", got[url])
        self.assertEqual(fake.calls, [])

    async def test_no_marker_no_fallback(self):
        client = tp.TravelpayoutsClient(TP_TOKEN, "", "", "sar", transport=FakeTP().transport)
        url = "https://www.aviasales.com/search/x"
        self.assertIsNone((await client.partner_links([url], marker_fallback=True))[url])
        offer = tp.Offer("RUH", "IST", 1, "sar", "TK", "", "", 0, "/search/x")
        self.assertEqual(await client.booking_url(offer), url)

    async def test_booking_url_prefers_partner_link(self):
        fake = FakeTP()
        client = make(fake)
        offer = await client.cheapest_to("RUH", "IST", ["2026-11"])
        url = await client.booking_url(offer)
        self.assertTrue(url.startswith("https://tp.media/"))
        self.assertIn("aviasales.com", urllib.parse.unquote(url))

    async def test_links_api_error_falls_back_quietly(self):
        fake = FakeTP()
        client = make(fake)

        def broken(method, url, headers, body, timeout):
            if "links" in url:
                return 500, b"{}"
            return fake.transport(method, url, headers, body, timeout)

        client._transport = broken
        offer = await client.cheapest_to("RUH", "IST", ["2026-11"])
        url = await client.booking_url(offer)
        self.assertTrue(url.startswith("https://www.aviasales.com/search/"))
        self.assertIn(f"marker={MARKER}", url)


class HelperTests(unittest.TestCase):
    def test_with_marker(self):
        self.assertEqual(tp.with_marker("https://x.test/a?b=1", "9"), "https://x.test/a?b=1&marker=9")
        self.assertEqual(tp.with_marker("https://x.test/a?marker=5", "9"), "https://x.test/a?marker=5")
        self.assertEqual(tp.with_marker("https://x.test/a", ""), "https://x.test/a")

    def test_month_keys_wrap_the_year(self):
        import calendar
        self.assertEqual(tp.month_keys(calendar.timegm((2026, 11, 20, 0, 0, 0)), 3), ["2026-11", "2026-12", "2027-01"])
        self.assertEqual(tp.month_keys(calendar.timegm((2026, 12, 31, 23, 0, 0)), 2), ["2026-12", "2027-01"])

    def test_site_url(self):
        self.assertEqual(tp.TravelpayoutsClient.site_url("/search/x"), "https://www.aviasales.com/search/x")
        self.assertEqual(tp.TravelpayoutsClient.site_url("search/x"), "https://www.aviasales.com/search/x")
        self.assertEqual(tp.TravelpayoutsClient.site_url("https://a.test/x"), "https://a.test/x")
        # the cached ticket token is dropped so the page shows what is on sale now
        self.assertEqual(
            tp.TravelpayoutsClient.site_url("/search/RUH1212IST1?t=abc&x=1"),
            "https://www.aviasales.com/search/RUH1212IST1?x=1",
        )
        self.assertEqual(tp.TravelpayoutsClient.site_url("/search/RUH1212IST1?t=abc"), "https://www.aviasales.com/search/RUH1212IST1")

    def test_to_sar(self):
        self.assertEqual(tp.to_sar(10, "SAR"), 10)
        self.assertEqual(tp.to_sar(1, "usd"), 3.75)
        self.assertIsNone(tp.to_sar(1, "rub"))


class DiagnoseTests(unittest.IsolatedAsyncioTestCase):
    async def test_diagnose_reports_without_secrets(self):
        fake = FakeTP()
        client = make(fake)
        report = await client.diagnose("RUH", "IST", "2026-11")
        self.assertGreater(report["offers"], 0)
        self.assertTrue(report["partner_link"])
        self.assertEqual(report["partner_host"], "tp.media")
        self.assertNotIn(TP_TOKEN, json.dumps(report))

    async def test_diagnose_without_token(self):
        client = tp.TravelpayoutsClient("", "", "", "sar", transport=FakeTP().transport)
        report = await client.diagnose("RUH", "IST", "2026-11")
        self.assertEqual(report["token_set"], False)
        self.assertEqual(report["links_missing"], ["token", "marker", "trs"])

    async def test_diagnose_names_what_is_missing_for_partner_links(self):
        for marker, trs, missing in (("", "", ["marker", "trs"]), (MARKER, "", ["trs"]), ("", TRS, ["marker"]), (MARKER, TRS, [])):
            client = tp.TravelpayoutsClient(TP_TOKEN, marker, trs, "sar", transport=FakeTP().transport, clock=lambda: NOW)
            self.assertEqual((await client.diagnose("RUH", "IST", "2026-11"))["links_missing"], missing)

    async def test_diagnose_says_why_the_provider_refused_a_partner_link(self):
        fake = FakeTP()
        fake.link_error = "trs is not subscribed for brand"
        report = await make(fake).diagnose("RUH", "IST", "2026-11")
        self.assertFalse(report["partner_link"])
        self.assertEqual(report["partner_issue"], "trs is not subscribed for brand")
        fake = FakeTP()
        fake.links_http = (400, {"error": "invalid traffic source"})
        report = await make(fake).diagnose("RUH", "IST", "2026-11")
        self.assertEqual(report["partner_issue"], "invalid traffic source")
        fake = FakeTP()
        fake.links_http = (500, {})
        self.assertEqual((await make(fake).diagnose("RUH", "IST", "2026-11"))["partner_issue"], "http 500")

    async def test_diagnose_asks_the_provider_again_instead_of_using_a_remembered_failure(self):
        fake = FakeTP()
        fake.link_error = "trs is not subscribed for brand"
        client = make(fake)
        self.assertFalse((await client.diagnose("RUH", "IST", "2026-11"))["partner_link"])
        fake.link_error = None                                   # the admin fixed the account
        self.assertTrue((await client.diagnose("RUH", "IST", "2026-11"))["partner_link"])


class MarketTests(unittest.IsolatedAsyncioTestCase):
    async def test_probe_counts_the_departure_days_of_one_market(self):
        fake = FakeTP()
        fake.market_days = {"us": 9, "": 3}
        client = make(fake)
        self.assertEqual(await client.probe_days("RUH", "IST", "2026-11", "us"), 9)
        self.assertEqual(await client.probe_days("RUH", "IST", "2026-11", ""), 3)
        self.assertGreater(await client.probe_days("RUH", "IST", "2026-11", "sa"), 20)       # a market with no limit knows every day
        urls = [c[1] for c in fake.price_calls()]
        self.assertIn("market=us", urls[0])
        self.assertNotIn("market", urls[1])

    async def test_probe_ignores_the_market_the_client_is_set_to(self):
        fake = FakeTP()
        fake.market_days = {"us": 4}
        client = make(fake, market="ru")
        self.assertEqual(await client.probe_days("RUH", "IST", "2026-11", "us"), 4)
        self.assertEqual(sum("market=ru" in c[1] for c in fake.price_calls()), 0)

    async def test_probe_reports_a_refusal_and_does_not_open_the_cool_down(self):
        fake = FakeTP()
        fake.status = 400
        client = make(fake)
        for _ in range(3):
            with self.assertRaises(tp.TPError):
                await client.probe_days("RUH", "IST", "2026-11", "zz")
        fake.status = 200
        self.assertTrue(await client.calendar("RUH", "IST", "2026-12"))

    async def test_changing_the_market_forgets_old_answers(self):
        fake = FakeTP()
        client = make(fake)
        await client.calendar("RUH", "IST", "2026-12")
        await client.prices(origin="RUH", destination="IST", month="2026-12")
        client.set_market("US")
        self.assertEqual(client.market, "us")
        self.assertEqual((len(client._cache), len(client._cal), client._rows), (0, 0, 0))
        fake.calls.clear()
        await client.calendar("RUH", "IST", "2026-12")
        self.assertIn("market=us", fake.price_calls()[0][1])
        client.set_market("")
        fake.calls.clear()
        await client.prices(origin="RUH", destination="BAH", month="2026-12")
        self.assertNotIn("market", fake.price_calls()[0][1])


if __name__ == "__main__":
    unittest.main()
