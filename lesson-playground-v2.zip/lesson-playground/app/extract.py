"""Reading a lesson file into plain text: PDF, PowerPoint (.pptx) and page pictures (JPG / PNG). All free and local: nothing leaves the server."""
import io
import re
import unicodedata

KINDS = {"pdf": "pdf", "pptx": "pptx", "jpg": "image", "jpeg": "image", "png": "image"}
MIN_CHARS = 40          # less than this and the file has no readable text


class ExtractError(Exception):
    pass


def detect(filename: str, head: bytes) -> str:
    """The kind of file by its extension AND its first bytes (a renamed file is refused)."""
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    kind = KINDS.get(ext)
    if kind == "pdf" and head[:5] == b"%PDF-":
        return "pdf"
    if kind == "pptx" and head[:4] == b"PK\x03\x04":
        return "pptx"
    if kind == "image" and (head[:3] == b"\xff\xd8\xff" or head[:8] == b"\x89PNG\r\n\x1a\n"):
        return "image"
    raise ExtractError("نوع الملف غير مدعوم. ارفعي PDF أو PowerPoint (pptx) أو صورة JPG/PNG")


_COMMON = ["في", "من", "على", "التي", "الذي", "هو", "هي", "إلى", "عن", "أن", "هذا", "هذه", "كل", "ما", "مع", "لا", "أو", "ثم", "تحتوي", "الخلية"]


def _reversed_arabic(text: str) -> bool:
    """Some PDFs hand the letters over in visual order (every Arabic line comes out backwards): spot it by the common words appearing reversed."""
    words = text.split()
    fwd = sum(1 for w in words if w.strip(".,،:؛؟!") in _COMMON)
    rev = sum(1 for w in words if w.strip(".,،:؛؟!")[::-1] in _COMMON and w.strip(".,،:؛؟!") not in _COMMON)
    return rev >= 3 and rev > fwd * 1.3


def _fix_visual_order(text: str) -> str:
    """Turn shaped letters back into normal ones, and a backwards line the right way round (numbers and Latin words keep their own order)."""
    text = unicodedata.normalize("NFKC", text)
    letters = [c for c in text if "\u0600" <= c <= "\u06ff"]
    if len(letters) < 20:
        return text
    shaped = sum(1 for c in text if "\ufb50" <= c <= "\ufdff" or "\ufe70" <= c <= "\ufeff")
    if shaped or _reversed_arabic(text):
        fixed = []
        for line in text.splitlines():
            line = line[::-1]
            fixed.append(re.sub(r"[A-Za-z0-9][A-Za-z0-9.,%/:-]*", lambda m: m.group(0)[::-1], line))
        text = "\n".join(fixed)
    return text


def _reflow(text: str) -> str:
    """A PDF breaks every paragraph into lines: join a full-width line that does not end a sentence with the one after it (short lines are titles)."""
    out = []
    for line in text.splitlines():
        line = line.strip()
        if out and line and len(out[-1]) >= 45 and not re.search(r"[.!؟?:؛]$", out[-1]) and not re.match(r"^[•\-–—*·●▪◦\d]+[\).]?\s", line):
            out[-1] += " " + line
        else:
            out.append(line)
    return "\n".join(out)


def clean(text: str) -> str:
    text = text.replace("\x00", "").replace("‏", "").replace("‎", "").replace(" ", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def from_pdf(data: bytes) -> str:
    from pypdf import PdfReader
    try:
        reader = PdfReader(io.BytesIO(data))
        if reader.is_encrypted:
            raise ExtractError("ملف PDF محمي بكلمة مرور")
        pages = [(p.extract_text() or "") for p in reader.pages[:200]]
    except ExtractError:
        raise
    except Exception:
        raise ExtractError("تعذرت قراءة ملف PDF، قد يكون تالفًا")
    return "\n\n".join(_reflow(_fix_visual_order(p)) for p in pages)


def from_pptx(data: bytes) -> str:
    from pptx import Presentation
    try:
        prs = Presentation(io.BytesIO(data))
    except Exception:
        raise ExtractError("تعذرت قراءة ملف PowerPoint، تأكدي أنه بصيغة pptx وليس ppt القديمة")
    out = []
    for slide in list(prs.slides)[:200]:
        parts = []
        for shape in slide.shapes:
            if shape.has_text_frame:
                parts.append("\n".join(p.text for p in shape.text_frame.paragraphs if p.text.strip()))
            if getattr(shape, "has_table", False) and shape.has_table:
                for row in shape.table.rows:
                    parts.append(" — ".join(c.text.strip() for c in row.cells if c.text.strip()))
        if slide.has_notes_slide:
            parts.append(slide.notes_slide.notes_text_frame.text)
        out.append("\n".join(x for x in parts if x.strip()))
    return "\n\n".join(out)


def from_image(data: bytes) -> str:
    """Free OCR with Tesseract. Arabic needs its language pack on the server (tesseract-ocr-ara, installed by the Dockerfile)."""
    try:
        import pytesseract
        from PIL import Image
        img = Image.open(io.BytesIO(data))
        img.load()
        if img.width * img.height > 40_000_000:
            raise ExtractError("الصورة كبيرة جدًا")
        langs = pytesseract.get_languages()
        use = "+".join(x for x in ("ara", "eng") if x in langs)
        if not use:
            raise ExtractError("قراءة الصور غير متاحة على هذا الخادم")
        text = pytesseract.image_to_string(img.convert("L"), lang=use)
    except ExtractError:
        raise
    except Exception:
        raise ExtractError("تعذرت قراءة الصورة")
    if len(text.strip()) < MIN_CHARS and "ara" not in langs:
        raise ExtractError("لم نستطع قراءة الصورة: قراءة العربية من الصور تحتاج حزمة اللغة العربية على الخادم. ارفعي الدرس PDF أو PowerPoint أو صورة أوضح")
    return text


def extract(kind: str, data: bytes) -> str:
    text = clean({"pdf": from_pdf, "pptx": from_pptx, "image": from_image}[kind](data))
    if len(text) < MIN_CHARS:
        raise ExtractError("لم نجد نصًا كافيًا في الملف. إن كان صفحات ممسوحة ضوئيًا فجرّبي صورًا أوضح أو ملفًا فيه نص")
    return text
