import time
import os
import threading
import uuid
from pathlib import Path

from flask import Blueprint, abort, current_app, g, redirect, render_template, request, url_for

from . import aiq, billing, db as dbm, extract
from .db import jload, now
from .security import Limiter, login_required

upload_limit = Limiter(20, 3600)

bp = Blueprint("lessons", __name__)
GAMES = {
    "wheel": ("عجلة الحظ", "🎡", "تدور العجلة وتختار سؤالًا"),
    "qa": ("سؤال وجواب", "💬", "اكشفي الإجابة عند الضغط"),
    "tf": ("صح أو خطأ", "✅", "الطالبات يقررن، ثم تظهر الإجابة"),
    "mcq": ("اختاري الصحيحة", "🎯", "عدة خيارات وإجابة واحدة"),
    "cloze": ("أكملي الفراغ", "✏️", "كلمة ناقصة في الجملة"),
    "teams": ("تحدي الفريقين", "🏆", "فريقان ونقاط وأدوار"),
    "random": ("سؤال عشوائي", "🎲", "يختار التطبيق سؤالًا لكِ"),
}
GAME_KINDS = {"qa": ("qa", "short", "review"), "tf": ("tf",), "mcq": ("mcq",), "cloze": ("cloze",), "wheel": aiq.KINDS, "teams": aiq.KINDS, "random": aiq.KINDS}


def mine(table, row_id):
    row = current_app.db.execute(f"SELECT * FROM {table} WHERE id = ? AND user_id = ?", (row_id, g.user["id"])).fetchone()
    if not row:
        abort(404)                     # another teacher's file looks exactly like a file that does not exist
    return row


def q_dict(r):
    return {"id": r["id"], "kind": r["kind"], "question": r["question"], "answer": r["answer"], "options": jload(r["options"], []),
            "evidence": r["evidence"], "clear": bool(r["clear"]), "manual": bool(r["manual"])}


def process(app, lesson_id: int):
    """Read the file and make the questions (runs in a worker thread with its own database connection)."""
    conn = dbm.connect(app.cfg.db_path)
    try:
        lesson = conn.execute("SELECT * FROM lessons WHERE id = ?", (lesson_id,)).fetchone()
        if not lesson:
            return
        user = conn.execute("SELECT * FROM users WHERE id = ?", (lesson["user_id"],)).fetchone()
        try:
            data = (app.cfg.upload_dir / lesson["stored_name"]).read_bytes()
            text = extract.extract(lesson["kind"], data)
            allowed = bool(user["ai_consent"]) and billing.ai_allowed(conn, user)          # her consent + her plan's allowance + the site's monthly cost cap
            engine, items, used = aiq.make_questions(app.cfg, text, allowed)
            if used:
                billing.log_ai(conn, user["id"], lesson_id, used["model"], used["input"], used["output"])
            conn.execute("DELETE FROM questions WHERE lesson_id = ? AND manual = 0", (lesson_id,))
            for i, q in enumerate(items):
                conn.execute("INSERT INTO questions(lesson_id, user_id, kind, question, answer, options, evidence, clear, position, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                             (lesson_id, user["id"], q["kind"], q["question"], q["answer"], __import__("json").dumps(q["options"], ensure_ascii=False),
                              q["evidence"], q["clear"], i, now()))
            note = "" if items else "قرأنا الملف لكن لم نستطع صياغة أسئلة واضحة منه. أضيفي أسئلتك يدويًا أو جرّبي ملفًا فيه جمل كاملة"
            conn.execute("UPDATE lessons SET text = ?, status = 'ready', error = ?, engine = ?, updated_at = ? WHERE id = ?", (text, note, engine, now(), lesson_id))
        except extract.ExtractError as exc:
            conn.execute("UPDATE lessons SET status = 'failed', error = ?, updated_at = ? WHERE id = ?", (str(exc), now(), lesson_id))
        except Exception:
            conn.execute("UPDATE lessons SET status = 'failed', error = ?, updated_at = ? WHERE id = ?", ("حدث خطأ أثناء المعالجة، أعيدي رفع الملف", now(), lesson_id))
        conn.commit()
    finally:
        conn.close()


def start(app, lesson_id):
    if app.cfg.background:
        threading.Thread(target=process, args=(app, lesson_id), daemon=True).start()
    else:
        process(app, lesson_id)


def _renew(user):
    left = billing.days_left(user)
    return left if left is not None and 0 <= left <= billing.RENEW_WARN_DAYS and user["plan_code"] != "free" else None


@bp.get("/dashboard")
@login_required
def dashboard():
    db = current_app.db
    uid = g.user["id"]
    lessons = db.execute("SELECT * FROM lessons WHERE user_id = ? ORDER BY id DESC", (uid,)).fetchall()
    decks = db.execute("SELECT d.*, l.title AS lesson_title FROM decks d JOIN lessons l ON l.id = d.lesson_id WHERE d.user_id = ? ORDER BY d.updated_at DESC", (uid,)).fetchall()
    counts = {r["lesson_id"]: r["n"] for r in db.execute("SELECT lesson_id, COUNT(*) AS n FROM questions WHERE user_id = ? GROUP BY lesson_id", (uid,))}
    plan = billing.plan_of(db, g.user)
    used_l, used_d = billing.usage(db, uid)
    return render_template("dashboard.html", lessons=lessons, decks=decks, counts=counts, plan=plan, used_l=used_l, used_d=used_d, games=GAMES,
                           ai_used=billing.ai_used(db, uid), renew=_renew(g.user), lapsed=g.user["plan_code"] != "free" and g.user["plan_expires"] and g.user["plan_expires"] < time.time(),
                           msg=request.args.get("msg", ""), max_mb=current_app.cfg.max_upload_mb)


@bp.post("/lessons/upload")
@login_required
def upload():
    db = current_app.db
    f = request.files.get("lesson")
    if not f or not f.filename:
        return redirect(url_for("lessons.dashboard", msg="اختاري ملف الدرس أولًا"))
    if not upload_limit.allow(g.user["id"]):
        return redirect(url_for("lessons.dashboard", msg="رفعتِ ملفات كثيرة خلال ساعة، جرّبي بعد قليل"))
    if not billing.can_add_lesson(db, g.user):
        return redirect(url_for("lessons.dashboard", msg="وصلتِ إلى حد الدروس في باقتك. احذفي درسًا قديمًا لإضافة جديد"))
    data = f.read()
    try:
        kind = extract.detect(f.filename, data[:16])
    except extract.ExtractError as exc:
        return redirect(url_for("lessons.dashboard", msg=str(exc)))
    if not data:
        return redirect(url_for("lessons.dashboard", msg="الملف فارغ"))
    ext = f.filename.rsplit(".", 1)[-1].lower()
    stored = uuid.uuid4().hex + "." + ext
    (current_app.cfg.upload_dir / stored).write_bytes(data)
    title = (request.form.get("title", "").strip() or Path(f.filename).stem)[:100]
    cur = db.execute("INSERT INTO lessons(user_id, title, original_name, stored_name, kind, created_at, updated_at) VALUES (?,?,?,?,?,?,?)",
                     (g.user["id"], title, f.filename[:200], stored, kind, now(), now()))
    db.commit()
    start(current_app._get_current_object(), cur.lastrowid)
    return redirect(url_for("lessons.lesson", lid=cur.lastrowid))


@bp.get("/lessons/<int:lid>")
@login_required
def lesson(lid):
    row = mine("lessons", lid)
    return render_template("lesson.html", lesson=row, games=GAMES, game_kinds=GAME_KINDS, kind_names=aiq.KIND_NAMES, unclear=aiq.G.UNCLEAR)


@bp.get("/present/<int:did>")
@login_required
def present(did):
    deck = mine("decks", did)
    return render_template("present.html", deck=deck, games=GAMES)


def remove_lesson_files(app, rows):
    for r in rows:
        try:
            (app.cfg.upload_dir / r["stored_name"]).unlink()
        except OSError:
            pass
