(function () {
  const stage = document.getElementById('stage');
  const deckId = stage.dataset.deck;
  const view = document.getElementById('view');
  const board = document.getElementById('scoreboard');
  const KEY = 'lp-deck-' + deckId;
  const KIND = {qa: 'سؤال وجواب', mcq: 'اختاري الإجابة الصحيحة', tf: 'صح أم خطأ؟', cloze: 'أكملي الفراغ', short: 'سؤال قصير', review: 'سؤال مراجعة'};
  const COLORS = ['#ffb400', '#ff5d6c', '#7a6cf0', '#2f8cff', '#2fb36b', '#ff7ab8', '#0e7c86', '#f26b21'];
  let deck, S;

  function fresh() { return {teams: [{name: 'الفريق الأول', pts: 0}, {name: 'الفريق الثاني', pts: 0}], turn: 0, used: {}, screen: null, board: false}; }
  function load() { try { return Object.assign(fresh(), JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (e) { return fresh(); } }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }
  const byId = id => deck.questions.find(q => q.id === id);
  const poolOf = game => deck.questions.filter(q => deck.game_info[game].kinds.includes(q.kind));
  const rnd = n => Math.floor(Math.random() * n);
  const usedOf = game => (S.used[game] = S.used[game] || []);
  const unused = game => poolOf(game).filter(q => !usedOf(game).includes(q.id));

  // ----- a question card with its own reveal behaviour -----
  function questionCard(q, game, onRevealed) {
    const card = el('div', {class: 'qcard'});
    const out = el('div'); const ctrl = el('div', {class: 'ctrl'});
    let revealed = false;
    const text = el('p', {class: 'qtext'});
    const blank = () => el('span', {class: 'blank' + (revealed ? ' filled' : ''), text: revealed ? q.answer : '      '});
    function paint() {
      text.replaceChildren();
      if (q.kind === 'cloze') { const parts = q.question.split('_____'); parts.forEach((p, i) => { text.append(p); if (i < parts.length - 1) text.append(blank()); }); }
      else text.textContent = q.question;
    }
    paint();
    card.append(el('span', {class: 'kindtag', text: KIND[q.kind]}), text);
    const optBtns = [];
    if (q.kind === 'mcq') {
      const box = el('div', {class: 'opts'});
      q.options.forEach(o => { const b = el('button', {class: 'opt', type: 'button', text: o}); b.addEventListener('click', () => { if (!revealed) { b.classList.add(o === q.answer ? 'right' : 'wrong'); reveal(); } }); optBtns.push(b); box.append(b); });
      card.append(box);
    }
    if (q.kind === 'tf') {
      const box = el('div', {class: 'tfbtns'});
      ['صح', 'خطأ'].forEach(o => { const b = el('button', {class: 'opt', type: 'button', text: o === 'صح' ? '✔ صح' : '✘ خطأ'}); b.dataset.v = o; b.addEventListener('click', () => { if (!revealed) { b.classList.add(o === q.answer ? 'right' : 'wrong'); reveal(); } }); optBtns.push(b); box.append(b); });
      card.append(box);
    }
    card.append(out, ctrl);
    const revealBtn = el('button', {class: 'btn big sun', type: 'button', text: 'اكشفي الإجابة'});
    function reveal() {
      if (revealed) return; revealed = true; S.screen && (S.screen.revealed = true); save();
      optBtns.forEach(b => { if ((q.kind === 'mcq' && b.textContent === q.answer) || (q.kind === 'tf' && b.dataset.v === q.answer)) b.classList.add('right'); b.disabled = true; });
      paint(); revealBtn.hidden = true;
      if (q.kind !== 'tf' && q.kind !== 'mcq') {
        const a = el('div', {class: 'answer' + (q.clear ? '' : ' no-clear')}, q.answer);
        out.append(a);
        if (!q.clear) a.append(el('small', {text: '⚠️ لا توجد إجابة واضحة في الملف — راجعيها'}));
      } else if (!q.clear) out.append(el('div', {class: 'answer no-clear'}, '⚠️ لا توجد إجابة واضحة في الملف — راجعيها'));
      if (q.evidence && q.kind === 'tf' && q.answer === 'خطأ') out.append(el('div', {class: 'answer'}, 'الجملة الصحيحة: ' + q.evidence));
      if (onRevealed) onRevealed(ctrl);
    }
    revealBtn.addEventListener('click', reveal);
    ctrl.append(revealBtn);
    if (S.screen && S.screen.revealed) reveal();
    return card;
  }

  // ----- scoreboard (two teams) -----
  function drawBoard() {
    board.hidden = !S.board; board.replaceChildren();
    S.teams.forEach((t, i) => {
      const name = el('input', {class: 'tname', value: t.name, 'aria-label': 'اسم الفريق'});
      name.addEventListener('input', () => { t.name = name.value; save(); });
      const plus = el('button', {type: 'button', text: '+', 'aria-label': 'زيادة نقطة'}); const minus = el('button', {type: 'button', text: '−', 'aria-label': 'إنقاص نقطة'});
      const pts = el('span', {class: 'pts', text: t.pts});
      plus.addEventListener('click', () => { t.pts++; pts.textContent = t.pts; save(); });
      minus.addEventListener('click', () => { t.pts = Math.max(0, t.pts - 1); pts.textContent = t.pts; save(); });
      board.append(el('div', {class: 'team ' + (i ? 'b' : 'a') + (S.screen && S.screen.game === 'teams' && S.turn === i ? ' turn' : '')}, name, minus, pts, plus));
    });
  }
  function awardRow(next) {
    const row = el('div', {class: 'award'});
    S.teams.forEach((t, i) => { const b = el('button', {class: 'btn' + (i ? ' b' : ''), type: 'button', text: '+1 ' + t.name}); b.addEventListener('click', () => { t.pts++; row.querySelectorAll('button').forEach(x => x.disabled = true); drawBoard(); save(); }); row.append(b); });
    return row;
  }

  // ----- screens -----
  function menu() {
    S.screen = null; save(); drawBoard();
    const m = el('div', {class: 'menu'});
    deck.games.forEach(g => {
      const info = deck.game_info[g]; const n = poolOf(g).length;
      const b = el('button', {class: 'tile-btn g-' + g, type: 'button'}, el('span', {class: 'ico', text: info.icon}), info.name, el('small', {text: n + ' سؤالًا · ' + info.hint}));
      b.addEventListener('click', () => start(g)); m.append(b);
    });
    view.replaceChildren(el('h2', {text: 'اختاري لعبة'}), m);
  }
  function start(game) { S.screen = {game, qid: null, revealed: false}; if (game === 'teams' && !S.board) S.board = true; save(); drawBoard(); next(true); }

  function finished(game) {
    const box = el('div', {class: 'qcard center'}, el('h2', {text: 'انتهت أسئلة هذه اللعبة 🎉'}));
    if (game === 'teams') {
      const [a, b] = S.teams; box.append(el('p', {class: 'qtext', text: a.pts === b.pts ? 'تعادل! ' + a.pts + ' لكل فريق' : (a.pts > b.pts ? a : b).name + ' يفوز! 🏆'}));
    }
    const again = el('button', {class: 'btn big sun', type: 'button', text: 'إعادة الأسئلة'});
    again.addEventListener('click', () => { S.used[game] = []; save(); next(true); });
    const home = el('button', {class: 'btn big ghost', type: 'button', text: 'الألعاب'}); home.addEventListener('click', menu);
    box.append(el('div', {class: 'ctrl'}, again, home)); view.replaceChildren(box);
  }

  function showQ(game, q, extra) {
    S.screen = {game, qid: q.id, revealed: S.screen && S.screen.qid === q.id ? S.screen.revealed : false}; save();
    const parts = [];
    const total = poolOf(game).length;
    parts.push(el('p', {class: 'progress', text: (game === 'teams' ? 'دور ' + S.teams[S.turn].name + ' · ' : '') + 'السؤال ' + Math.min(usedOf(game).length, total) + ' من ' + total}));
    parts.push(questionCard(q, game, ctrl => {
      if (S.board) ctrl.before(awardRow());
      ctrl.append(nextBtn(game));
    }));
    if (extra) parts.push(extra);
    view.replaceChildren(...parts); drawBoard();
  }
  function nextBtn(game) {
    const label = game === 'wheel' ? 'ادوري العجلة 🎡' : game === 'random' ? 'سؤال عشوائي آخر 🎲' : 'السؤال التالي ➜';
    const b = el('button', {class: 'btn big', type: 'button', text: label}); b.addEventListener('click', () => { if (game === 'teams') S.turn = 1 - S.turn; next(false); }); return b;
  }

  function next(first) {
    const game = S.screen && S.screen.game; if (!game) return menu();
    if (!first || !S.screen.qid) S.screen.revealed = false;
    if (first && S.screen.qid && byId(S.screen.qid)) { const q = byId(S.screen.qid); return game === 'wheel' ? wheel(game, q) : showQ(game, q); }
    const left = unused(game); if (!left.length) return finished(game);
    if (game === 'wheel') return wheel(game, null);
    let q;
    if (game === 'random' || game === 'teams') q = left[rnd(left.length)]; else q = left[0];
    usedOf(game).push(q.id); S.screen.qid = q.id; save(); showQ(game, q);
  }

  // ----- the wheel -----
  let rot = 0;
  function wheel(game, shown) {
    const left = unused(game); const pickable = shown ? left.concat([shown]) : left;
    if (!pickable.length) return finished(game);
    const segs = pickable.slice().sort(() => Math.random() - .5).slice(0, 12);
    if (shown && !segs.includes(shown)) segs[0] = shown;
    const size = 560, c = el('canvas', {width: size, height: size, 'aria-label': 'عجلة الحظ'}); const g = c.getContext('2d'); const n = segs.length, arc = 2 * Math.PI / n;
    segs.forEach((q, i) => {
      g.beginPath(); g.moveTo(size / 2, size / 2); g.arc(size / 2, size / 2, size / 2 - 6, -Math.PI / 2 + i * arc, -Math.PI / 2 + (i + 1) * arc); g.closePath();
      g.fillStyle = COLORS[i % COLORS.length]; g.fill(); g.lineWidth = 4; g.strokeStyle = '#fff'; g.stroke();
      g.save(); g.translate(size / 2, size / 2); g.rotate(-Math.PI / 2 + (i + .5) * arc); g.textAlign = 'right'; g.fillStyle = '#fff'; g.font = '800 44px Tajawal, Tahoma, sans-serif'; g.fillText(String(i + 1), size / 2 - 40, 15); g.restore();
    });
    g.beginPath(); g.arc(size / 2, size / 2, 44, 0, 2 * Math.PI); g.fillStyle = '#fff'; g.fill();
    const box = el('div', {class: 'wheel-wrap'}); const w = el('div', {class: 'wheel'}, c, el('span', {class: 'pointer', text: '▼'}));
    const spin = el('button', {class: 'btn big sun', type: 'button', text: 'ادوري العجلة 🎡'});
    box.append(el('p', {class: 'progress', text: 'المتبقي ' + left.length + ' سؤالًا'}), w, spin);
    const result = el('div'); box.append(result); view.replaceChildren(box);
    c.style.transform = 'rotate(' + rot + 'deg)';
    function land(k) {
      const q = segs[k]; if (!usedOf(game).includes(q.id)) usedOf(game).push(q.id); S.screen = {game, qid: q.id, revealed: false}; save();
      result.replaceChildren(el('p', {class: 'progress', text: 'استقرت العجلة على السؤال رقم ' + (k + 1)}), questionCard(q, game, ctl => { if (S.board) ctl.before(awardRow()); const again = el('button', {class: 'btn big', type: 'button', text: 'ادوري مرة أخرى 🎡'}); again.addEventListener('click', () => { S.screen.qid = null; next(false); }); ctl.append(again); }));
      spin.hidden = true; w.hidden = true; box.firstChild.hidden = true;
    }
    if (shown) { land(segs.indexOf(shown)); return; }
    spin.addEventListener('click', () => {
      spin.disabled = true; const k = rnd(n); const offset = (Math.random() * .7 - .35) * (360 / n);
      rot += 360 * 5 + ((-(k + .5) * (360 / n) + offset) % 360 + 360) % 360 - (rot % 360);
      c.style.transform = 'rotate(' + rot + 'deg)';
      let done = false; const fin = () => { if (!done) { done = true; land(k); } };
      c.addEventListener('transitionend', fin, {once: true}); setTimeout(fin, 4600);
    });
  }

  // ----- bar buttons -----
  document.getElementById('b-menu').addEventListener('click', menu);
  document.getElementById('b-exit').addEventListener('click', () => { if (document.fullscreenElement) document.exitFullscreen(); location.href = '/dashboard'; });
  document.getElementById('b-score').addEventListener('click', () => { S.board = !S.board; save(); drawBoard(); });
  const pause = document.getElementById('pause');
  document.getElementById('b-pause').addEventListener('click', () => { pause.hidden = false; document.getElementById('b-resume').focus(); });
  document.getElementById('b-resume').addEventListener('click', () => { pause.hidden = true; });
  const fsBtn = document.getElementById('b-full');
  const root = document.documentElement;
  if (!(root.requestFullscreen || root.webkitRequestFullscreen)) fsBtn.hidden = true;
  fsBtn.addEventListener('click', () => {
    if (document.fullscreenElement || document.webkitFullscreenElement) (document.exitFullscreen || document.webkitExitFullscreen).call(document);
    else (root.requestFullscreen || root.webkitRequestFullscreen).call(root);
  });
  document.addEventListener('fullscreenchange', () => { fsBtn.textContent = document.fullscreenElement ? '⛶ خروج من ملء الشاشة' : '⛶ ملء الشاشة'; });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && !pause.hidden) pause.hidden = true; });

  api('GET', '/api/decks/' + deckId + '/data').then(d => {
    deck = d; S = load();
    S.used = S.used || {};
    if (S.screen && S.screen.game && deck.games.includes(S.screen.game)) next(true); else menu();
    drawBoard();
  }).catch(e => { view.textContent = e.message; });
})();
