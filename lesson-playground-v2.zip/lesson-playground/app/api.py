import json

from flask import Blueprint, current_app, g, jsonify, request, session
from werkzeug.security import check_password_hash

from . import aiq, billing
from .db import jload, now
from .lessons import GAME_KINDS, GAMES, mine, q_dict, remove_lesson_files, start
from .security import Limiter, login_required

bp = Blueprint("api", __name__, url_prefix="/api")
delete_limit = Limiter(5, 600)


def body() -> dict:
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}


@bp.get("/lessons/<int:lid>")
@login_required
def lesson_status(lid):
    row = mine("lessons", lid)
    n = current_app.db.execute("SELECT COUNT(*) FROM questions WHERE lesson_id = ?", (lid,)).fetchone()[0]
    return jsonify(status=row["status"], error=row["error"], title=row["title"], engine=row["engine"], count=n)


@bp.get("/lessons/<int:lid>/questions")
@login_required
def questions(lid):
    mine("lessons", lid)
    rows = current_app.db.execute("SELECT * FROM questions WHERE lesson_id = ? ORDER BY position, id", (lid,)).fetchall()
    return jsonify(questions=[q_dict(r) for r in rows])


def _clean_question(d: dict, text_norm: str, existing=None):
    kind = d.get("kind", existing["kind"] if existing else "")
    if kind not in aiq.KINDS:
        return None, "نوع السؤال غير صحيح"
    question = str(d.get("question", existing["question"] if existing else "")).strip()[:600]
    answer = str(d.get("answer", existing["answer"] if existing else "")).strip()[:600]
    options = d.get("options", jload(existing["options"], []) if existing else [])
    options = [str(o).strip()[:200] for o in options if str(o).strip()][:6] if isinstance(options, list) else []
    evidence = str(d.get("evidence", existing["evidence"] if existing else "")).strip()[:800]
    if len(question) < 3:
        return None, "اكتبي نص السؤال"
    if kind == "tf" and answer not in ("صح", "خطأ"):
        return None, "إجابة صح أو خطأ يجب أن تكون «صح» أو «خطأ»"
    if kind == "mcq":
        if len(options) < 2 or answer not in options:
            return None, "اختاري خيارين على الأقل، ولازم تكون الإجابة أحدها"
    if kind != "tf" and not answer:
        return None, "اكتبي الإجابة"
    q = {"kind": kind, "question": question, "answer": answer, "options": options, "evidence": evidence}
    # a teacher's own edit is her decision, but we still tell her when the file does not back the answer
    q["clear"] = int(aiq.G.verify(q, text_norm, strict=False)) if evidence else int(aiq.G.norm(answer) in text_norm if kind != "tf" else 1)
    return q, ""


@bp.post("/lessons/<int:lid>/questions")
@login_required
def add_question(lid):
    lesson = mine("lessons", lid)
    q, err = _clean_question(body(), aiq.G.norm(lesson["text"]))
    if not q:
        return jsonify(error=err), 400
    db = current_app.db
    pos = (db.execute("SELECT COALESCE(MAX(position), 0) + 1 FROM questions WHERE lesson_id = ?", (lid,)).fetchone()[0])
    cur = db.execute("INSERT INTO questions(lesson_id, user_id, kind, question, answer, options, evidence, clear, manual, position, created_at) VALUES (?,?,?,?,?,?,?,?,1,?,?)",
                     (lid, g.user["id"], q["kind"], q["question"], q["answer"], json.dumps(q["options"], ensure_ascii=False), q["evidence"], q["clear"], pos, now()))
    db.commit()
    return jsonify(question=q_dict(db.execute("SELECT * FROM questions WHERE id = ?", (cur.lastrowid,)).fetchone())), 201


@bp.patch("/questions/<int:qid>")
@login_required
def edit_question(qid):
    row = mine("questions", qid)
    lesson = mine("lessons", row["lesson_id"])
    q, err = _clean_question(body(), aiq.G.norm(lesson["text"]), existing=row)
    if not q:
        return jsonify(error=err), 400
    db = current_app.db
    db.execute("UPDATE questions SET kind=?, question=?, answer=?, options=?, evidence=?, clear=?, manual=1 WHERE id = ?",
               (q["kind"], q["question"], q["answer"], json.dumps(q["options"], ensure_ascii=False), q["evidence"], q["clear"], qid))
    db.execute("UPDATE lessons SET updated_at = ? WHERE id = ?", (now(), row["lesson_id"]))
    db.commit()
    return jsonify(question=q_dict(db.execute("SELECT * FROM questions WHERE id = ?", (qid,)).fetchone()), saved=True)


@bp.delete("/questions/<int:qid>")
@login_required
def delete_question(qid):
    mine("questions", qid)
    current_app.db.execute("DELETE FROM questions WHERE id = ?", (qid,))
    current_app.db.commit()
    return jsonify(ok=True)


@bp.post("/lessons/<int:lid>/regenerate")
@login_required
def regenerate(lid):
    row = mine("lessons", lid)
    if row["status"] == "processing":
        return jsonify(error="ما زال الملف قيد القراءة"), 409
    current_app.db.execute("UPDATE lessons SET status = 'processing', error = '' WHERE id = ?", (lid,))
    current_app.db.commit()
    start(current_app._get_current_object(), lid)
    return jsonify(ok=True)


@bp.patch("/lessons/<int:lid>")
@login_required
def rename_lesson(lid):
    mine("lessons", lid)
    title = str(body().get("title", "")).strip()[:100]
    if len(title) < 2:
        return jsonify(error="اكتبي عنوانًا"), 400
    current_app.db.execute("UPDATE lessons SET title = ?, updated_at = ? WHERE id = ?", (title, now(), lid))
    current_app.db.commit()
    return jsonify(saved=True)


@bp.delete("/lessons/<int:lid>")
@login_required
def delete_lesson(lid):
    row = mine("lessons", lid)
    current_app.db.execute("DELETE FROM lessons WHERE id = ?", (lid,))          # its questions and decks go with it
    current_app.db.commit()
    remove_lesson_files(current_app, [row])
    return jsonify(ok=True)


@bp.post("/lessons/<int:lid>/decks")
@login_required
def create_deck(lid):
    mine("lessons", lid)
    d = body()
    db = current_app.db
    if not billing.can_add_deck(db, g.user):
        return jsonify(error="وصلتِ إلى حد العروض في باقتك. احذفي عرضًا قديمًا لإنشاء جديد"), 403
    games = [x for x in d.get("games", []) if x in GAMES]
    ids = [int(i) for i in d.get("question_ids", []) if isinstance(i, int)]
    valid = {r["id"]: r["kind"] for r in db.execute("SELECT id, kind FROM questions WHERE lesson_id = ? AND user_id = ?", (lid, g.user["id"]))}
    ids = [i for i in dict.fromkeys(ids) if i in valid]
    if not games:
        return jsonify(error="اختاري لعبة واحدة على الأقل"), 400
    if not ids:
        return jsonify(error="اختاري سؤالًا واحدًا على الأقل"), 400
    for gm in games:
        if not any(valid[i] in GAME_KINDS[gm] for i in ids):
            return jsonify(error=f"لعبة «{GAMES[gm][0]}» لا تجد أسئلة مناسبة بين ما اخترتِ"), 400
    title = str(d.get("title", "")).strip()[:100] or mine("lessons", lid)["title"]
    cur = db.execute("INSERT INTO decks(user_id, lesson_id, title, games, question_ids, created_at, updated_at) VALUES (?,?,?,?,?,?,?)",
                     (g.user["id"], lid, title, json.dumps(games), json.dumps(ids), now(), now()))
    db.commit()
    return jsonify(id=cur.lastrowid, url=f"/present/{cur.lastrowid}"), 201


@bp.get("/decks/<int:did>/data")
@login_required
def deck_data(did):
    deck = mine("decks", did)
    ids = jload(deck["question_ids"], [])
    rows = {r["id"]: r for r in current_app.db.execute("SELECT * FROM questions WHERE lesson_id = ? AND user_id = ?", (deck["lesson_id"], g.user["id"]))}
    qs = [q_dict(rows[i]) for i in ids if i in rows]
    for q in qs:
        q.pop("manual", None)
    return jsonify(id=deck["id"], title=deck["title"], games=jload(deck["games"], []), questions=qs,
                   game_info={k: {"name": v[0], "icon": v[1], "hint": v[2], "kinds": list(GAME_KINDS[k])} for k, v in GAMES.items()})


@bp.patch("/decks/<int:did>")
@login_required
def rename_deck(did):
    mine("decks", did)
    title = str(body().get("title", "")).strip()[:100]
    if len(title) < 2:
        return jsonify(error="اكتبي عنوانًا"), 400
    current_app.db.execute("UPDATE decks SET title = ?, updated_at = ? WHERE id = ?", (title, now(), did))
    current_app.db.commit()
    return jsonify(saved=True)


@bp.delete("/decks/<int:did>")
@login_required
def delete_deck(did):
    mine("decks", did)
    current_app.db.execute("DELETE FROM decks WHERE id = ?", (did,))
    current_app.db.commit()
    return jsonify(ok=True)


@bp.post("/me/consent")
@login_required
def consent():
    agreed = 1 if body().get("ai_consent") is True else 0
    current_app.db.execute("UPDATE users SET ai_consent = ? WHERE id = ?", (agreed, g.user["id"]))
    current_app.db.commit()
    return jsonify(ai_consent=bool(agreed))


@bp.post("/me/delete")
@login_required
def delete_account():
    if not delete_limit.allow(g.user["id"]):
        return jsonify(error="محاولات كثيرة، انتظري قليلًا"), 429
    if not check_password_hash(g.user["pass_hash"], str(body().get("password", ""))):
        return jsonify(error="كلمة المرور غير صحيحة"), 400
    db = current_app.db
    files = db.execute("SELECT stored_name FROM lessons WHERE user_id = ? UNION ALL SELECT receipt FROM subscription_requests WHERE user_id = ? AND receipt != ''",
                       (g.user["id"], g.user["id"])).fetchall()
    db.execute("DELETE FROM users WHERE id = ?", (g.user["id"],))          # lessons, questions and decks cascade
    db.commit()
    remove_lesson_files(current_app, files)
    session.clear()
    return jsonify(ok=True)
