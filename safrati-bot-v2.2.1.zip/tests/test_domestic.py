"""Trips inside the kingdom: found when asked for, kept out of the lists of places abroad."""
import unittest

from safrati import data, texts
from tests.test_app import AppCase


class DataTests(unittest.TestCase):
    def test_the_places_are_known_and_need_no_visa(self):
        by = data.by_iata()
        for code in ("AHB", "ULH", "TIF", "JED", "RUH", "TUU", "GIZ", "MED"):
            self.assertEqual(by[code].cc, "SA", code)
            self.assertEqual(data.visa_for(by[code].cc).status, "domestic", code)
            self.assertEqual(texts.visa_mark(by[code]), "✅", code)

    def test_a_city_after_from_is_the_origin_and_otherwise_the_destination(self):
        self.assertEqual([d.iata for d in data.understand("ابها").destinations], ["AHB"])
        self.assertEqual([d.iata for d in data.understand("العلا").destinations], ["ULH"])
        intent = data.understand("من الرياض الى ابها")
        self.assertEqual((intent.origin, [d.iata for d in intent.destinations]), ("RUH", ["AHB"]))

    def test_region_words_and_the_default_list(self):
        self.assertEqual(data.understand("سفر داخلي").regions, ("saudi",))
        self.assertEqual(data.understand("ويكند داخل السعودية").regions, ("saudi",))
        by = data.by_iata()
        self.assertFalse(data.region_ok(by["AHB"], ()))
        self.assertTrue(data.region_ok(by["AHB"], ("saudi",)))
        self.assertTrue(data.region_ok(by["DXB"], ()))
        self.assertFalse(data.region_ok(by["DXB"], ("saudi",)))

    def test_the_weekend_asks_about_the_domestic_places_only_when_wanted(self):
        self.assertNotIn("AHB", data.weekend_destinations())
        self.assertIn("AHB", data.weekend_destinations(True))
        self.assertNotIn("DXB", data.weekend_destinations(True))


class BotTests(AppCase):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.fake.routes["RUH"].update({"AHB": 250, "ULH": 400, "TIF": 220})

    def last(self):
        shown = [p for m, p in self.tg.calls if m in ("sendMessage", "editMessageText")]
        return shown[-1]

    async def test_a_domestic_trip_from_the_default_city(self):
        self.db.set_origin(1, "RUH")
        await self.say(1, "ابها")
        text = self.last()["text"]
        self.assertIn("أبها", text)
        self.assertIn("داخل المملكة", text)
        self.assertTrue(any("destination=AHB" in c[1] for c in self.fake.price_calls()))

    async def test_the_same_city_is_refused_without_a_search(self):
        self.db.set_origin(1, "RUH")
        before = len(self.fake.price_calls())
        await self.say(1, "الرياض")
        self.assertIn("نفسها", self.last()["text"])
        self.assertEqual(len(self.fake.price_calls()), before)

    async def test_the_cheapest_list_hides_domestic_unless_asked(self):
        self.db.set_origin(1, "RUH")
        await self.say(1, "ارخص الرحلات")
        self.assertNotIn("أبها", self.last()["text"])
        await self.say(1, "ارخص رحلة داخل السعودية")
        self.assertNotIn("دبي", self.last()["text"])
        self.assertIn("داخل السعودية", self.last()["text"])


if __name__ == "__main__":
    unittest.main()


class WebTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        from tests.test_web_api import make
        self.app, self.fake = make()
        self.fake.routes["RUH"].update({"AHB": 250, "ULH": 400, "TIF": 220})

    async def get(self, path, **query):
        from tests.test_web_api import call
        return await call(self.app, path, **query)

    async def test_domestic_places_come_only_when_asked_for(self):
        _, body = await self.get("/api/cheap", o="RUH")
        self.assertFalse({i["iata"] for i in body["items"]} & {"AHB", "ULH", "TIF"})
        _, body = await self.get("/api/cheap", o="RUH", region="saudi")
        self.assertEqual([i["iata"] for i in body["items"]], ["TIF", "AHB", "ULH"])
        self.assertEqual(body["items"][0]["visa"]["short"], "رحلة داخلية")

    async def test_the_same_city_is_refused(self):
        res, body = await self.get("/api/dest", o="RUH", d="RUH")
        self.assertEqual(res.status, 400)

    async def test_the_site_offers_the_region(self):
        _, body = await self.get("/api/meta")
        self.assertIn("saudi", [r["key"] for r in body["regions"]])
        _, body = await self.get("/api/understand", q="ويكند داخلي")
        self.assertEqual((body["kind"], body["regions"]), ("weekend", ["saudi"]))
