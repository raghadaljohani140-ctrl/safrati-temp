/* صائد العروض: the website's script. No framework, no inline code (the page's security policy forbids it).
   Everything shown comes from the server's JSON; text is always inserted as text, never as markup. */
'use strict';
(() => {
  // The fonts load after the first paint, so a slow connection never delays the page.
  const FONTS = 'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600&family=Readex+Pro:wght@500;700&display=swap';
  const fontLink = document.createElement('link');
  fontLink.rel = 'stylesheet';
  fontLink.href = FONTS;
  document.head.appendChild(fontLink);

  const app = document.getElementById('app');
  const originSelect = document.getElementById('origin');

  // ---------------------------------------------------------------- small helpers
  const WEEKDAYS = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const WEEKDAYS_SHORT = ['ح', 'ن', 'ث', 'ر', 'خ', 'ج', 'س'];
  const MONTHS = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
  const ISO_DAY = /^\d{4}-\d{2}-\d{2}$/;
  const ISO_MONTH = /^\d{4}-\d{2}$/;
  const money = new Intl.NumberFormat('en-US');
  const fmt = (n) => money.format(Math.round(n));

  const store = {
    get(key) { try { return window.localStorage.getItem(key); } catch (e) { return null; } },
    set(key, value) { try { window.localStorage.setItem(key, value); } catch (e) { /* private mode: nothing to keep */ } },
  };

  function el(tag, props, ...kids) {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(props || {})) {
      if (value === null || value === undefined || value === false) continue;
      if (key === 'class') node.className = value;
      else if (key === 'text') node.textContent = value;
      else if (key.startsWith('on')) node.addEventListener(key.slice(2), value);
      else node.setAttribute(key, value === true ? '' : value);
    }
    append(node, kids);
    return node;
  }
  function append(node, kids) {
    for (const kid of kids) {
      if (kid === null || kid === undefined || kid === false) continue;
      if (Array.isArray(kid)) append(node, kid);
      else node.appendChild(typeof kid === 'object' ? kid : document.createTextNode(String(kid)));
    }
  }

  const SVG_NS = 'http://www.w3.org/2000/svg';
  const ICONS = {
    plane: { d: 'M21 16v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5z' },
    next: { d: 'M15 5l-7 7 7 7', s: 1 },          // points left: the next page in a right-to-left layout
    prev: { d: 'M9 5l7 7-7 7', s: 1 },
    back: { d: 'M9 5l7 7-7 7', s: 1 },
    out: { d: 'M7 17L17 7M9 7h8v8', s: 1 },
    check: { d: 'M5 12.5l4.5 4.5L19 7.5', s: 1 },
    alert: { d: 'M12 8v5M12 16.5v.5M10.3 3.9L2.6 17.5A2 2 0 0 0 4.3 20.5h15.4a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z', s: 1 },
    info: { d: 'M12 11v6M12 7.5v.5M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z', s: 1 },
    search: { d: 'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM20 20l-4-4', s: 1 },
    share: { d: 'M12 15V4M8 8l4-4 4 4M5 12v7a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-7', s: 1 },
    bolt: { d: 'M13 3L5 13h6l-1 8 8-10h-6z' },
    send: { d: 'M21.5 3.5 2.8 10.7c-.9.3-.9 1.6 0 1.9l4.6 1.5 1.8 5.5c.2.7 1.1.9 1.6.4l2.6-2.5 4.7 3.5c.6.4 1.4.1 1.6-.6l3.4-16c.2-.9-.7-1.6-1.6-1.4z' },
  };
  function icon(name, size = 20) {
    const def = ICONS[name];
    const svg = document.createElementNS(SVG_NS, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('width', size);
    svg.setAttribute('height', size);
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('focusable', 'false');
    const path = document.createElementNS(SVG_NS, 'path');
    path.setAttribute('d', def.d);
    if (def.s) {
      path.setAttribute('fill', 'none');
      path.setAttribute('stroke', 'currentColor');
      path.setAttribute('stroke-width', '2.2');
      path.setAttribute('stroke-linecap', 'round');
      path.setAttribute('stroke-linejoin', 'round');
    } else {
      path.setAttribute('fill', 'currentColor');
    }
    svg.appendChild(path);
    return svg;
  }
  // the crosshair of the logo: it marks the cheapest day, and turns while the prices are being fetched
  function reticle(cls) {
    const svg = document.createElementNS(SVG_NS, 'svg');
    svg.setAttribute('viewBox', '0 0 48 48');
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('focusable', 'false');
    if (cls) svg.setAttribute('class', cls);
    const ring = document.createElementNS(SVG_NS, 'circle');
    for (const [k, v] of Object.entries({ cx: 24, cy: 24, r: 16.5, fill: 'none', stroke: 'currentColor', 'stroke-width': 3 })) ring.setAttribute(k, v);
    const ticks = document.createElementNS(SVG_NS, 'path');
    for (const [k, v] of Object.entries({ d: 'M24 3v9M24 36v9M3 24h9M36 24h9', fill: 'none', stroke: 'currentColor', 'stroke-width': 3, 'stroke-linecap': 'round' })) ticks.setAttribute(k, v);
    svg.append(ring, ticks);
    return svg;
  }

  // flags are emoji; some systems (Windows) cannot draw them, and then the country code is shown instead
  const flagsWork = (() => {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = canvas.height = 28;
      const ctx = canvas.getContext('2d');
      ctx.textBaseline = 'top';
      ctx.font = '20px sans-serif';
      ctx.fillText('\u{1F1F8}\u{1F1E6}', 0, 0);
      const px = ctx.getImageData(0, 0, 28, 28).data;
      for (let i = 0; i < px.length; i += 4) {
        if (px[i + 3] > 0 && (Math.abs(px[i] - px[i + 1]) > 30 || Math.abs(px[i + 1] - px[i + 2]) > 30)) return true;
      }
    } catch (e) { /* no canvas: use codes */ }
    return false;
  })();
  const flagBadge = (d) => (flagsWork ? el('span', { class: 'flag', 'aria-hidden': 'true', text: d.flag }) : el('span', { class: 'flag code', 'aria-hidden': 'true', text: d.cc }));

  const parseISO = (s) => new Date(Date.UTC(+s.slice(0, 4), +s.slice(5, 7) - 1, +s.slice(8, 10)));
  const weekday = (s) => WEEKDAYS[parseISO(s).getUTCDay()];
  const dayMonth = (s) => `${+s.slice(8, 10)} ${MONTHS[+s.slice(5, 7) - 1]}`;
  const longDate = (s) => `${weekday(s)} ${dayMonth(s)}`;
  const daysText = (n) => (n === 2 ? 'يومين' : n >= 3 && n <= 10 ? `${n} أيام` : `${n} يوم`);
  function rangeText(from, to) {
    if (!to) return dayMonth(from);
    if (from.slice(0, 7) === to.slice(0, 7)) return `${+from.slice(8, 10)} – ${dayMonth(to)}`;
    return `${dayMonth(from)} – ${dayMonth(to)}`;
  }
  const norm = (s) => s.toLowerCase()
    .replace(/[ً-ٰٟـ]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/\s+/g, ' ').trim();

  // ---------------------------------------------------------------- server calls
  async function api(path, params) {
    const q = new URLSearchParams();
    for (const [key, value] of Object.entries(params || {})) {
      if (value === '' || value === null || value === undefined || value === false || value === 0) continue;
      q.set(key, value === true ? '1' : String(value));
    }
    const qs = q.toString();
    let res;
    try {
      res = await fetch(qs ? `${path}?${qs}` : path, { headers: { Accept: 'application/json' } });
    } catch (e) {
      throw Object.assign(new Error('تعذّر الاتصال بالإنترنت، تأكد من الشبكة وجرّب مرة ثانية.'), { status: 0 });
    }
    let body = null;
    try { body = await res.json(); } catch (e) { /* not json */ }
    if (!res.ok || !body || body.ok === false) {
      throw Object.assign(new Error((body && body.message) || 'حصل خطأ غير متوقع، جرّب مرة ثانية.'), { status: res.status, code: body && body.error });
    }
    return body;
  }

  // ---------------------------------------------------------------- state
  let META = null;
  let BY = {};
  let origin = 'RUH';
  let gen = 0;          // grows with every page drawn; an answer that arrives for an older page is dropped
  let steps = 0;        // pages opened inside this visit, to know whether "back" stays on the website
  let toastTimer = 0;

  const originName = () => (META.origins.find((o) => o.code === origin) || { name: '' }).name;
  function setOrigin(code, remember) {
    if (!META.origins.some((o) => o.code === code)) return;
    origin = code;
    originSelect.value = code;
    if (remember) store.set('safrati.origin', code);
  }

  // ---------------------------------------------------------------- pieces
  function page(cls, ...kids) {
    app.replaceChildren(el('div', { class: `wrap ${cls || ''}`.trim() }, ...kids));
  }
  function setTitle(text) {
    document.title = text ? `${text} | صائد العروض` : 'صائد العروض — أرخص تذاكر الطيران من السعودية';
  }
  function toast(text) {
    const old = document.querySelector('.toast');
    if (old) old.remove();
    const node = el('div', { class: 'toast', role: 'status', text });
    document.body.appendChild(node);
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => node.remove(), 2400);
  }
  const loader = (text) => el('div', { class: 'loader', role: 'status' }, reticle(), el('p', { text }));
  const skeletons = (n) => Array.from({ length: n }, () => el('div', { class: 'sk ticket-sk' }));
  const notice = (kind, ...kids) => el('div', { class: `notice ${kind || ''}`.trim() }, icon(kind === 'warn' || kind === 'bad' ? 'alert' : 'info', 20), el('div', {}, ...kids));
  function errorBox(err, retry) {
    const busy = [429, 503, 504].includes(err.status);
    return el('div', { class: 'panel center', role: 'alert' },
      el('h3', { text: err.status === 0 ? 'ما في اتصال بالإنترنت' : busy ? 'الخدمة مشغولة الآن' : 'ما قدرنا نجيب الأسعار' }),
      el('p', { text: err.message }),
      retry && el('button', { class: 'btn quiet sm', type: 'button', onclick: retry, text: 'أعد المحاولة' }));
  }
  function visaBadge(visa) {
    const level = visa.level === 'ok' ? '' : visa.level;
    return el('span', { class: `visa ${level}`.trim() }, icon(visa.level === 'ok' ? 'check' : 'alert', 14), visa.short);
  }
  function chip(label, pressed, props) {
    return el('button', Object.assign({ class: 'chip', type: 'button', 'aria-pressed': pressed ? 'true' : 'false' }, props), label);
  }
  // bring the chosen chip into view inside a row that scrolls sideways
  function reveal(row) {
    const on = row.querySelector('[aria-pressed="true"], .on');
    if (!on || row.scrollWidth <= row.clientWidth + 1) return;
    const box = row.getBoundingClientRect();
    const at = on.getBoundingClientRect();
    row.scrollLeft += (at.left - box.left) - (row.clientWidth - at.width) / 2;
  }
  const revealAll = () => app.querySelectorAll('.chips').forEach(reveal);

  function ticket(item, href) {
    return el('a', { class: 'ticket', href: `#${href}` },
      el('div', { class: 't-main' }, flagBadge(item),
        el('div', { class: 't-text' }, el('b', { class: 't-name', text: item.name }), el('span', { class: 't-sub', text: item.country }), visaBadge(item.visa))),
      el('div', { class: 't-stub' }, el('span', { class: 't-from', text: 'من' }), el('b', { class: 't-price', text: fmt(item.price) }),
        el('span', { class: 't-cur', text: 'ر.س' }), el('span', { class: 't-dates', text: rangeText(item.date, item.ret) })));
  }

  const bookLink = (o, label) => el('a', { class: 'btn primary', href: o.book, target: '_blank', rel: 'noopener noreferrer' },
    label || 'احجز', icon('out', 18), el('span', { class: 'sr', text: ' (يفتح موقع الحجز)' }));

  /* A boarding pass: route, dates and details above the tear line; price and booking below it.
     `full` draws the route; the short form is for a day picked in the calendar. */
  function pass(o, ctx) {
    const oneWay = !o.ret;
    const meta = [o.airline, o.stops_text, o.duration, !oneWay && o.stay ? daysText(o.stay) : ''].filter(Boolean);
    const top = [];
    if (ctx.tag) top.push(el('p', { class: 'pass-tag' }, ctx.tag));
    if (ctx.full) {
      top.push(el('div', { class: 'route' },
        el('div', { class: 'stop' }, el('span', { class: 'code', text: ctx.origin }), el('span', { class: 'city', text: ctx.originName })),
        el('div', { class: 'path', 'aria-hidden': 'true' }, icon('plane', 22)),
        el('div', { class: 'stop' }, el('span', { class: 'code', text: ctx.dest.iata }), el('span', { class: 'city', text: ctx.dest.name }))));
    }
    top.push(el('div', { class: 'dates' },
      el('div', {}, el('small', { text: 'الذهاب' }), el('b', { text: longDate(o.date) })),
      el('div', {}, el('small', { text: oneWay ? 'الرحلة' : 'العودة' }), el('b', { text: oneWay ? 'ذهاب فقط' : longDate(o.ret) }))));
    top.push(el('div', { class: 'meta' }, meta.map((m) => el('span', { text: m }))));
    return el('article', { class: 'pass' },
      el('div', { class: 'pass-top' }, top),
      el('div', { class: 'cut', 'aria-hidden': 'true' }),
      el('div', { class: 'pass-bot' },
        el('div', { class: 'price' }, el('b', { text: fmt(o.price) }), el('small', { text: `ر.س · ${oneWay ? 'ذهاب فقط' : 'ذهاب وعودة'}` })),
        bookLink(o)));
  }

  // ---------------------------------------------------------------- routing
  function parseRoute() {
    const raw = window.location.hash.slice(1) || '/';
    const cut = raw.indexOf('?');
    const path = cut < 0 ? raw : raw.slice(0, cut);
    const params = new URLSearchParams(cut < 0 ? '' : raw.slice(cut + 1));
    const seg = path.split('/').filter(Boolean);
    if (seg[0] === 'd' && /^[A-Z]{3}$/.test(seg[1] || '') && BY[seg[1]]) {
      if (ISO_DAY.test(seg[2] || '')) {
        return { name: 'day', iata: seg[1], date: seg[2], ret: ISO_DAY.test(seg[3] || '') ? seg[3] : '', oneWay: seg[3] === 'o', params };
      }
      return { name: 'dest', iata: seg[1], params };
    }
    return { name: 'home', params };
  }
  function go(path) { window.location.hash = path; }
  function setParams(patch) {          // change the address without adding a step to the browser history
    const raw = window.location.hash.slice(1) || '/';
    const cut = raw.indexOf('?');
    const params = new URLSearchParams(cut < 0 ? '' : raw.slice(cut + 1));
    for (const [k, v] of Object.entries(patch)) {
      if (v === '' || v === false || v === 0 || v === null || v === undefined) params.delete(k);
      else params.set(k, v === true ? '1' : String(v));
    }
    const qs = params.toString();
    window.history.replaceState(null, '', `#${cut < 0 ? raw : raw.slice(0, cut)}${qs ? `?${qs}` : ''}`);
  }
  function render() {
    const route = parseRoute();
    const wanted = route.params.get('o');
    if (wanted && META.origins.some((o) => o.code === wanted)) setOrigin(wanted, true);
    if (route.name === 'dest') renderDest(route);
    else if (route.name === 'day') renderDay(route);
    else renderHome(route);
  }
  function onRoute() {
    steps += 1;
    window.scrollTo(0, 0);
    render();
    app.focus({ preventScroll: true });
  }
  function goBack(fallback) {
    if (steps > 1) window.history.back();
    else go(fallback);
  }

  // ---------------------------------------------------------------- home
  const BUDGETS = [500, 1000, 1500, 2000, 3000, 5000];
  const EXAMPLES = ['دبي', 'إسطنبول ديسمبر', 'القاهرة 5 أيام', 'أرخص رحلة', 'ويكند'];

  function renderHome(route) {
    const g = ++gen;
    setTitle('');
    const params = route.params;
    let tab = params.get('tab') === 'weekend' ? 'weekend' : 'cheap';
    const f = {
      region: META.regions.some((r) => r.key === params.get('region')) ? params.get('region') : '',
      tag: META.tags.some((t) => t.key === params.get('tag')) ? params.get('tag') : '',
      visa: params.get('visa') === '1',
      max: Math.min(1000000, Math.max(0, +params.get('max') || 0)),
    };
    if (f.max && f.max < 100) f.max = 0;
    let loadId = 0;

    // ---- search
    const input = el('input', {
      type: 'search', id: 'q', name: 'q', autocomplete: 'off', autocapitalize: 'off', autocorrect: 'off', spellcheck: 'false',
      enterkeyhint: 'search', maxlength: '120', placeholder: 'وين تبغى تسافر؟', 'aria-label': 'وجهتك أو طلبك',
    });
    const answer = el('div', { class: 'stack', 'aria-live': 'polite' });
    const sug = el('ul', { class: 'sug', role: 'listbox', hidden: true });
    let sugItems = [];
    let sugAt = -1;
    const hideSug = () => { sug.hidden = true; sugAt = -1; input.removeAttribute('aria-activedescendant'); };
    const form = el('form', { class: 'search', role: 'search', onsubmit: (e) => { e.preventDefault(); hideSug(); runSearch(input.value); } },
      icon('search', 22), input, el('button', { class: 'btn primary', type: 'submit', text: 'ابحث' }));

    function showSuggestions() {
      const text = norm(input.value);
      sug.replaceChildren();
      sugItems = [];
      sugAt = -1;
      if (text.length >= 1) {
        const hits = META.destinations.filter((d) => [d.name, d.country, d.en].some((w) => norm(w).split(' ').some((part) => part.startsWith(text)) || norm(w).startsWith(text))).slice(0, 6);
        for (const d of hits) {
          const row = el('button', { type: 'button', role: 'option', 'aria-selected': 'false', onclick: () => { hideSug(); go(`/d/${d.iata}`); } },
            flagBadge(d), el('span', {}, el('b', { text: d.name })), el('small', { text: d.country }));
          sugItems.push(row);
          sug.appendChild(el('li', { role: 'none' }, row));
        }
      }
      sug.hidden = sugItems.length === 0;
    }
    input.addEventListener('input', showSuggestions);
    input.addEventListener('keydown', (e) => {
      if (sug.hidden || !sugItems.length) return;
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        sugAt = (sugAt + (e.key === 'ArrowDown' ? 1 : -1) + sugItems.length) % sugItems.length;
        sugItems.forEach((b, i) => b.setAttribute('aria-selected', i === sugAt ? 'true' : 'false'));
      } else if (e.key === 'Enter' && sugAt >= 0) {
        e.preventDefault();
        sugItems[sugAt].click();
      } else if (e.key === 'Escape') hideSug();
    });
    input.addEventListener('blur', () => setTimeout(hideSug, 160));

    async function runSearch(text) {
      const q = text.trim();
      if (!q) { input.focus(); return; }
      answer.replaceChildren(loader('نقرأ طلبك…'));
      let r;
      try { r = await api('/api/understand', { q }); } catch (e) {
        if (g === gen) answer.replaceChildren(errorBox(e, () => runSearch(text)));
        return;
      }
      if (g !== gen) return;
      if (r.origin) setOrigin(r.origin, true);
      answer.replaceChildren();
      if (r.problem) { answer.replaceChildren(notice('warn', r.problem)); return; }
      if (r.kind === 'dest') { go(destPath(r.dests[0], r)); return; }
      if (r.kind === 'choices') {
        answer.replaceChildren(el('div', { class: 'panel' }, el('h3', { text: 'أي وجهة تقصد؟' }),
          el('div', { class: 'list' }, r.dests.map((c) => destRow(BY[c], destPath(c, r))))));
        return;
      }
      if (r.kind === 'weekend') { showList('weekend', { max: r.cap }); return; }
      if (r.kind === 'cheap') { showList('cheap', { region: r.regions[0] || '', tag: r.tags[0] || '', max: r.cap }); return; }
      if (r.kind === 'origin') { answer.replaceChildren(notice('', `تمام، الأسعار الحين من ${originName()}.`)); sync(); load(); return; }
      if (r.kind === 'suggest' && r.suggest.length) {
        answer.replaceChildren(el('div', { class: 'panel' }, el('h3', { text: 'هل تقصد:' }),
          el('div', { class: 'list' }, r.suggest.map((c) => destRow(BY[c], `/d/${c}`)))));
        return;
      }
      answer.replaceChildren(notice('', 'ما عرفت وجهتك. اكتب اسم مدينة أو دولة مثل «دبي» أو «تركيا»، أو اضغط على أحد الأمثلة.'));
    }
    const examples = el('div', { class: 'try' }, 'جرّب:',
      EXAMPLES.map((text) => el('button', { type: 'button', onclick: () => { input.value = text; hideSug(); runSearch(text); }, text })));

    // ---- deals
    const title = el('h2', {});
    const rule = el('p', { class: 'rule' });
    const box = el('div', { class: 'deals', 'aria-live': 'polite' });
    const tabButtons = {};
    const tabs = el('div', { class: 'tabs', role: 'tablist', 'aria-label': 'نوع الرحلات' },
      [['cheap', 'أرخص الرحلات'], ['weekend', 'ويكند']].map(([key, label]) => (tabButtons[key] = el('button', {
        class: 'tab', type: 'button', role: 'tab', onclick: () => { tab = key; setParams({ tab: key === 'cheap' ? '' : key }); sync(); load(); }, text: label,
      }))));

    const filterEls = [];
    const addFilter = (kind, value, label) => {
      const b = chip(label, false, { 'data-kind': kind, 'data-value': value });
      filterEls.push(b);
      return b;
    };
    const budget = el('select', { class: 'chip', 'aria-label': 'الحد الأعلى لسعر التذكرة', onchange: (e) => change({ max: +e.target.value }) });
    function fillBudget() {          // the usual choices, plus the figure read from the visitor's own words
      const sizes = [...new Set([...BUDGETS, ...(f.max ? [f.max] : [])])].sort((a, b) => a - b);
      budget.replaceChildren(el('option', { value: '0', text: 'أي سعر' }), ...sizes.map((n) => el('option', { value: String(n), text: `حتى ${fmt(n)} ر.س` })));
      budget.value = String(f.max || 0);
    }
    const filters = el('div', { class: 'filters', onclick: (e) => {
      const b = e.target.closest('button[data-kind]');
      if (!b) return;
      const { kind, value } = b.dataset;
      if (kind === 'visa') change({ visa: !f.visa });
      else change({ [kind]: f[kind] === value ? '' : value });
    } },
      el('div', { class: 'chips', role: 'group', 'aria-label': 'المنطقة' }, [addFilter('region', '', 'الكل'), ...META.regions.map((r) => addFilter('region', r.key, r.label))]),
      el('div', { class: 'chips', role: 'group', 'aria-label': 'التصفية' }, [addFilter('visa', '1', 'بدون تأشيرة فقط'), ...META.tags.map((t) => addFilter('tag', t.key, t.label)), budget]));

    function change(patch) {
      Object.assign(f, patch);
      setParams({ region: f.region, tag: f.tag, visa: f.visa, max: f.max });
      sync();
      load();
    }
    function sync() {
      title.textContent = tab === 'weekend' ? `رحلات الويكند من ${originName()}` : `أرخص الرحلات الآن من ${originName()}`;
      rule.textContent = tab === 'weekend' ? 'تغادر الخميس أو الجمعة وترجع السبت أو الأحد، ذهاب وعودة.' : 'أرخص تذكرة ذهاب وعودة لكل وجهة خلال الأشهر القادمة.';
      for (const [key, b] of Object.entries(tabButtons)) b.setAttribute('aria-selected', key === tab ? 'true' : 'false');
      for (const b of filterEls) {
        const { kind, value } = b.dataset;
        const on = kind === 'visa' ? f.visa : kind === 'region' ? f.region === value : f.tag === value;
        b.setAttribute('aria-pressed', on ? 'true' : 'false');
      }
      fillBudget();
      budget.classList.toggle('on', !!f.max);
    }
    // a search such as "weekend" or "cheapest in Europe under 3000" fills the list in place, without leaving the page
    function showList(next, patch) {
      tab = next;
      Object.assign(f, { region: '', tag: '', visa: false, max: 0 }, patch);
      f.max = f.max ? Math.min(1000000, Math.max(100, f.max)) : 0;
      setParams({ tab: tab === 'cheap' ? '' : tab, region: f.region, tag: f.tag, visa: f.visa, max: f.max });
      answer.replaceChildren();
      sync();
      load();
      revealAll();
      title.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    async function load(attempt = 0) {
      const mine = ++loadId;
      if (!META.prices) {
        box.replaceChildren(el('div', { class: 'panel center' }, el('h3', { text: 'الأسعار غير متاحة الآن' }), el('p', { text: 'نجهّز خدمة الأسعار، ارجع بعد قليل.' })));
        return;
      }
      box.replaceChildren(...skeletons(6));
      let r;
      try {
        r = await api(tab === 'weekend' ? '/api/weekend' : '/api/cheap', { o: origin, region: f.region, tag: f.tag, visa: f.visa, max: f.max });
      } catch (e) {
        if (mine === loadId && g === gen) box.replaceChildren(errorBox(e, () => load()));
        return;
      }
      if (mine !== loadId || g !== gen) return;
      const out = [];
      if (r.cap && r.over) out.push(notice('warn span', `ما لقينا تذاكر ضمن ${fmt(r.cap)} ر.س، وهذي أرخص المتوفر.`));
      if (r.pending) out.push(notice('span', 'لسا نجمع باقي الوجهات، والقائمة تتحدّث تلقائيًا.'));
      if (!r.items.length) {
        out.push(el('div', { class: 'panel center span' }, el('h3', { text: 'ما لقينا رحلات بهالفلاتر الآن' }),
          el('p', { text: 'خفّف الفلاتر أو غيّر مدينة الانطلاق.' }),
          el('button', { class: 'btn quiet sm', type: 'button', text: 'امسح الفلاتر', onclick: () => change({ region: '', tag: '', visa: false, max: 0 }) })));
      } else {
        out.push(...r.items.map((item) => ticket(item, `/d/${item.iata}${tab === 'weekend' ? '?weekend=1' : ''}`)));
      }
      box.replaceChildren(...out);
      if (r.pending && attempt < 3) {
        setTimeout(() => { if (mine === loadId && g === gen) load(attempt + 1); }, 7000);
      }
    }

    const cta = botCard('تبغى تنبيه لما ينزل السعر؟', 'بوت تيليجرام يراقب الوجهة اللي تختارها ويرسل لك فورًا لما ينزل سعرها. وفي القناة عروض يومية.', META.links.bot);

    page('',
      el('section', { class: 'hero' },
        el('h1', { text: 'متى أرخص يوم تسافر فيه؟' }),
        el('p', { text: 'اكتب وجهتك وشوف سعر كل يوم في تقويم واضح، من أي مدينة سعودية.' }),
        el('div', { class: 'search-box' }, form, sug),
        examples, answer),
      el('section', {},
        el('div', { class: 'section-head' }, title),
        tabs, rule, filters, box),
      cta);
    sync();
    load();
    requestAnimationFrame(revealAll);
  }

  function botCard(heading, text, url) {
    return el('section', { class: 'cta' }, el('h3', { text: heading }), el('p', { text }),
      el('div', { class: 'cta-row' },
        el('a', { class: 'btn primary', href: url, target: '_blank', rel: 'noopener' }, icon('send', 18), 'افتح البوت'),
        META.links.channel && el('a', { class: 'btn quiet', href: META.links.channel, target: '_blank', rel: 'noopener', text: 'قناة العروض' })));
  }
  function destPath(iata, r) {
    if (r.depart) return `/d/${iata}/${r.depart}${r.one_way ? '/o' : r.ret ? `/${r.ret}` : ''}`;
    const p = new URLSearchParams();
    if (r.month && META.months.some((m) => m.key === r.month)) p.set('m', r.month);
    if (r.stay) p.set('stay', r.stay);
    if (r.weekend) p.set('weekend', '1');
    const qs = p.toString();
    return `/d/${iata}${qs ? `?${qs}` : ''}`;
  }
  function destRow(d, href) {
    return el('a', { class: 'row', href: `#${href}` }, flagBadge(d),
      el('span', { class: 'grow' }, el('b', { text: d.name }), el('small', { text: d.country })), visaBadge(d.visa), icon('next', 18));
  }

  // ---------------------------------------------------------------- destination
  function destHead(d, backTo) {
    const share = navigator.share || (navigator.clipboard && navigator.clipboard.writeText)
      ? el('button', { class: 'back share', type: 'button', 'aria-label': 'شارك الصفحة', onclick: () => shareThis(`${d.name} — أرخص أيام السفر`) }, icon('share', 20))
      : null;
    return el('div', { class: 'dhead' },
      el('a', { class: 'back', href: '#/', 'aria-label': 'رجوع', onclick: (e) => { e.preventDefault(); goBack(backTo); } }, icon('back', 20)),
      flagBadge(d),
      el('div', {}, el('h1', { text: d.name }), el('p', { class: 'sub', text: `${d.country} · من ${originName()}` })),
      share);
  }
  async function shareThis(title) {
    const url = window.location.href;
    try {
      if (navigator.share) { await navigator.share({ title, url }); return; }
      await navigator.clipboard.writeText(url);
      toast('نسخنا الرابط');
    } catch (e) {
      if (!e || e.name !== 'AbortError') toast('ما قدرنا ننسخ الرابط');
    }
  }
  function visaLine(d, r) {
    const checked = r && r.visa_checked ? r.visa_checked.split('-') : null;
    return el('div', { class: 'dtags' }, visaBadge(d.visa),
      el('span', { class: 'fine', text: d.visa.label }),
      r && r.visa_official && el('a', { href: r.visa_official, target: '_blank', rel: 'noopener noreferrer', text: 'موقع التقديم الرسمي' }),
      checked && el('span', { class: 'fine', text: `آخر تحقق: ${+checked[2]}/${+checked[1]}/${checked[0]}` }));
  }
  function staysRow(stay, weekend, onChange) {
    const row = el('div', { class: 'chips', role: 'group', 'aria-label': 'مدة الرحلة' });
    const choices = [['ذهاب فقط', 0, false], ...META.stays.map((n) => [daysText(n), n, false]), ['ويكند', 0, true]];
    for (const [label, n, w] of choices) {
      const on = w ? weekend : (!weekend && stay === n);
      row.appendChild(chip(label, on, { onclick: () => onChange(n, w) }));
    }
    return row;
  }

  async function renderDest(route) {
    const g = ++gen;
    const d = BY[route.iata];
    const stayParam = +route.params.get('stay') || 0;
    const stay = META.stays.includes(stayParam) ? stayParam : 0;
    const weekend = route.params.get('weekend') === '1';
    const askedMonth = route.params.get('m') || '';
    setTitle(`${d.name}: أرخص أيام السفر من ${originName()}`);
    const body = el('div', { class: 'dest', 'aria-live': 'polite' }, loader(`نصطاد أسعار ${d.name}…`));
    page('narrow',
      destHead(d, '/'),
      visaLine(d, null),
      staysRow(stay, weekend, (n, w) => { setParams({ stay: n, weekend: w }); render(); }),
      body);
    requestAnimationFrame(revealAll);
    let r;
    try {
      r = await api('/api/dest', { d: route.iata, o: origin, stay, weekend });
    } catch (e) {
      if (g === gen) body.replaceChildren(errorBox(e, () => renderDest(route)));
      return;
    }
    if (g !== gen) return;
    const dtags = app.querySelector('.dtags');
    if (dtags) dtags.replaceWith(visaLine(d, r));
    const ctx = { origin: r.origin, originName: r.origin_name, dest: d };
    const out = [];
    if (r.note) out.push(notice('', r.note));
    if (r.empty) {
      out.push(el('div', { class: 'panel center' }, el('h3', { text: 'ما لقينا أسعار محفوظة لهذا المسار' }),
        el('p', { text: 'جرّب مدينة انطلاق ثانية أو مدة مختلفة. وفي البوت تقدر تضيف تنبيهًا ويرسل لك أول ما يظهر سعر.' }),
        el('a', { class: 'btn quiet sm', href: r.bot, target: '_blank', rel: 'noopener', text: 'افتح البوت' })));
      body.replaceChildren(...out);
      return;
    }
    if (r.verdict) {
      out.push(el('div', { class: `verdict ${r.verdict.level}` }, icon(r.verdict.level === 'high' ? 'alert' : 'bolt', 20),
        el('div', {}, r.verdict.text, el('small', { text: `مقارنة بـ ${r.verdict.samples} يوم من الأسعار المحفوظة، والمعتاد حوالي ${fmt(r.verdict.typical)} ر.س` }))));
    }
    out.push(pass(r.top[0], Object.assign({ full: true, tag: el('span', {}, 'أرخص سعر وجدناه: ', el('b', { text: longDate(r.top[0].date) })) }, ctx)));
    out.push(el('p', { class: 'fine', text: 'السعر وقت البحث وقد يتغير أو ينتهي. الرابط يفتح البحث بأسعار اليوم.' }));

    if (r.top.length > 1) {
      out.push(el('h2', { class: 'h2', text: 'أرخص الأيام' }),
        el('div', { class: 'list' }, r.top.map((o) => el('a', { class: 'row', href: o.book, target: '_blank', rel: 'noopener noreferrer' },
          el('i', { class: `dot ${o.tier || ''}`.trim(), 'aria-hidden': 'true' }),
          el('span', { class: 'grow' }, el('b', { text: longDate(o.date) }),
            el('small', { class: 'bits' }, [o.ret ? `عودة ${dayMonth(o.ret)}` : 'ذهاب فقط', o.stay ? daysText(o.stay) : '', o.stops > 0 ? o.stops_text : '']
              .filter(Boolean).map((t) => el('span', { text: t })))),
          el('span', { class: 'pr' }, fmt(o.price), el('small', { text: 'ر.س' })), icon('out', 18)))));
    }

    // calendar, with the month list above it
    const views = Object.assign({}, r.calendars);
    const keys = META.months.map((m) => m.key);
    let month = [askedMonth, r.default_month].find((m) => keys.includes(m)) || keys[0];
    let picked = '';
    const sel = el('div', { class: 'sel', 'aria-live': 'polite' });
    const calBox = el('div', { class: 'calbox' });
    const barButtons = [];
    if (r.months.length > 1) {
      out.push(el('h2', { class: 'h2', text: 'أرخص الأشهر' }),
        el('div', { class: 'panel' }, el('div', { class: 'bars' }, r.months.map((m) => {
          const fill = el('span', { class: 'fill' });
          fill.style.inlineSize = `${Math.max(8, m.bar * 20)}%`;
          const b = el('button', { class: `bar ${m.best ? 'best' : ''}`.trim(), type: 'button', 'data-month': m.key, 'aria-pressed': 'false',
            onclick: () => { showMonth(m.key); calBox.scrollIntoView({ behavior: 'smooth', block: 'start' }); } },
          el('span', { class: 'm' }, m.name, m.best && reticle(), m.best && el('span', { class: 'sr', text: '، الأرخص' })),
          el('span', { class: 'track', 'aria-hidden': 'true' }, fill),
          el('span', { class: 'p', text: fmt(m.price) }));
          barButtons.push(b);
          return b;
        }))));
    }
    out.push(el('h2', { class: 'h2', text: 'تقويم الأسعار' }), calBox, sel);

    function pick(rec, iso, scroll) {
      picked = iso;
      calBox.querySelectorAll('.day[aria-pressed]').forEach((b) => b.setAttribute('aria-pressed', b.dataset.iso === iso ? 'true' : 'false'));
      const offer = {
        date: iso, ret: rec.r, price: rec.p, stay: rec.n, airline: rec.a, stops_text: rec.s, duration: rec.u,
        book: `/go?o=${r.origin}&d=${route.iata}&date=${iso}${rec.r ? `&ret=${rec.r}` : ''}`,
      };
      sel.replaceChildren(pass(offer, { tag: el('span', {}, 'اخترت: ', el('b', { text: longDate(iso) })) }),
        el('a', { class: 'btn quiet sm', href: `#/d/${route.iata}/${iso}${rec.r ? `/${rec.r}` : '/o'}`, text: 'تفاصيل هذا اليوم' }));
      if (scroll) sel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    async function showMonth(key) {
      month = key;
      barButtons.forEach((b) => b.setAttribute('aria-pressed', b.dataset.month === key ? 'true' : 'false'));
      if (!views[key]) {
        calBox.replaceChildren(loader('نجيب أسعار الشهر…'));
        try {
          views[key] = await api('/api/calendar', { d: route.iata, o: origin, m: key, stay, weekend });
        } catch (e) {
          if (g === gen && month === key) calBox.replaceChildren(errorBox(e, () => showMonth(key)));
          return;
        }
        if (g !== gen || month !== key) return;
      }
      drawCalendar(views[key], key);
    }
    function drawCalendar(view, key) {
      const at = keys.indexOf(key);
      const byDay = new Map(view.days.map((x) => [x.d, x]));
      const lowest = view.days.length ? Math.min(...view.days.map((x) => x.p)) : 0;
      let locked = false;
      const rows = view.weeks.map((week) => el('tr', {}, week.map(([num, ok]) => {
        if (!num) return el('td');
        const rec = byDay.get(num);
        const iso = `${key}-${String(num).padStart(2, '0')}`;
        if (!ok) return el('td', {}, el('span', { class: 'day off' }, el('span', { class: 'n', text: num })));
        if (!rec) return el('td', {}, el('span', { class: 'day none', title: 'ما فيه سعر محفوظ' }, el('span', { class: 'n', text: num })));
        const isBest = !locked && rec.p === lowest;
        if (isBest) locked = true;
        return el('td', {}, el('button', {
          class: `day ${rec.t}`, type: 'button', 'data-iso': iso, 'aria-pressed': picked === iso ? 'true' : 'false',
          'aria-label': `${longDate(iso)}، ${fmt(rec.p)} ريال${rec.n ? `، ${daysText(rec.n)}` : ''}${isBest ? '، أرخص يوم في الشهر' : ''}`,
          title: [rec.a, rec.s, rec.u].filter(Boolean).join(' · '),
          onclick: () => pick(rec, iso, true),
        }, el('span', { class: 'n', text: num }), el('span', { class: 'p', text: rec.p }),
        isBest && el('span', { class: 'lock', 'aria-hidden': 'true' }, el('i'), el('i'), el('i'), el('i'))));
      })));
      calBox.replaceChildren(
        el('div', { class: 'cal-head' },
          el('button', { type: 'button', 'aria-label': 'الشهر السابق', disabled: at <= 0, onclick: () => showMonth(keys[at - 1]) }, icon('back', 20)),
          el('h3', { text: view.label }),
          el('button', { type: 'button', 'aria-label': 'الشهر التالي', disabled: at >= keys.length - 1, onclick: () => showMonth(keys[at + 1]) }, icon('next', 20))),
        view.days.length
          ? el('table', { class: 'cal' },
            el('thead', {}, el('tr', {}, WEEKDAYS_SHORT.map((w, i) => el('th', { scope: 'col', title: WEEKDAYS[i], text: w })))),
            el('tbody', {}, rows))
          : el('div', { class: 'panel center' }, el('p', { text: 'ما فيه أسعار محفوظة لهذا الشهر. جرّب شهر ثاني.' })),
        view.days.length ? el('div', { class: 'legend' },
          el('span', {}, el('i', { class: 'low' }), 'أرخص'), el('span', {}, el('i', { class: 'mid' }), 'عادي'), el('span', {}, el('i', { class: 'high' }), 'أغلى'),
          el('span', {}, el('i', { class: 'ring' }), 'أرخص يوم في الشهر')) : null);
      if (picked && picked.startsWith(key)) {
        const rec = byDay.get(+picked.slice(8));
        if (rec) pick(rec, picked, false); else sel.replaceChildren();
      } else {
        sel.replaceChildren();
      }
    }

    if (r.services.length) {
      out.push(el('h2', { class: 'h2', text: 'يفيدك في رحلتك' }),
        el('div', { class: 'services' }, r.services.map((s) => el('a', { href: s.go, target: '_blank', rel: 'noopener noreferrer' }, el('span', { text: s.label }), icon('out', 18)))));
    }
    out.push(botCard(`تابع سعر ${d.name} في تيليجرام`, 'أضف تنبيهًا في البوت وراح يرسل لك أول ما ينزل السعر أو يوصل للرقم اللي تبغاه.', r.bot));
    body.replaceChildren(...out);
    showMonth(month);
  }

  // ---------------------------------------------------------------- one exact day
  async function renderDay(route) {
    const g = ++gen;
    const d = BY[route.iata];
    setTitle(`${d.name} ${dayMonth(route.date)}`);
    const body = el('div', { class: 'dest', 'aria-live': 'polite' }, loader('نبحث عن سعر هذا اليوم…'));
    page('narrow', destHead(d, `/d/${route.iata}`), visaLine(d, null), body);
    let r;
    try {
      r = await api('/api/day', { d: route.iata, o: origin, date: route.date, ret: route.ret, one_way: route.oneWay });
    } catch (e) {
      if (g !== gen) return;
      const fix = e.status === 400
        ? el('div', { class: 'panel center', role: 'alert' }, el('h3', { text: 'التاريخ غير مناسب' }), el('p', { text: e.message }),
          el('a', { class: 'btn quiet sm', href: `#/d/${route.iata}`, text: 'ارجع للتقويم' }))
        : errorBox(e, () => renderDay(route));
      body.replaceChildren(fix);
      return;
    }
    if (g !== gen) return;
    const ctx = { full: true, origin: r.origin, originName: r.origin_name, dest: d };
    const out = [];
    if (r.note) out.push(notice('warn', r.note));
    r.offers.forEach((o, i) => out.push(pass(o, Object.assign({ tag: i === 0 ? (r.exact ? 'سعر هذا اليوم' : 'أقرب سعر لطلبك') : 'خيار آخر' }, ctx))));
    if (!r.offers.length) {
      out.push(el('div', { class: 'panel center' }, el('h3', { text: 'ما لقينا سعرًا محفوظًا لهذا اليوم' }),
        el('p', { text: 'الأسعار المحفوظة تأتي من عمليات بحث حديثة. افتح البحث المباشر لتشوف أسعار اليوم.' })));
    } else {
      out.push(el('p', { class: 'fine', text: 'السعر وقت البحث وقد يتغير أو ينتهي. الرابط يفتح البحث بأسعار اليوم.' }));
    }
    if (r.hint) {
      out.push(notice('', 'يوم أرخص قريب: ', el('b', { text: longDate(r.hint.date) }), ` بسعر ${fmt(r.hint.price)} ر.س، توفّر ${fmt(r.hint.saving)} ر.س. `,
        el('a', { href: `#/d/${route.iata}/${r.hint.date}${r.hint.ret ? `/${r.hint.ret}` : '/o'}`, text: 'افتحه' })));
    }
    out.push(el('div', { class: 'stack' },
      el('a', { class: 'btn quiet', href: r.live, target: '_blank', rel: 'noopener noreferrer' }, 'افتح البحث المباشر لهذا اليوم', icon('out', 18)),
      el('a', { class: 'btn quiet', href: `#/d/${route.iata}` }, 'شوف تقويم الأسعار كامل')));
    out.push(botCard(`تابع سعر ${d.name} في تيليجرام`, 'أضف تنبيهًا في البوت وراح يرسل لك أول ما ينزل السعر.', r.bot));
    body.replaceChildren(...out);
  }

  // ---------------------------------------------------------------- start
  async function boot() {
    try {
      META = await api('/api/meta');
    } catch (e) {
      page('', errorBox(e, boot));
      return;
    }
    BY = Object.fromEntries(META.destinations.map((d) => [d.iata, d]));
    originSelect.replaceChildren(...META.origins.map((o) => el('option', { value: o.code, text: o.name })));
    const saved = store.get('safrati.origin');
    setOrigin(META.origins.some((o) => o.code === saved) ? saved : 'RUH', false);
    originSelect.addEventListener('change', () => {
      setOrigin(originSelect.value, true);
      const route = parseRoute();
      if (route.params.has('o')) setParams({ o: origin });
      render();
    });
    window.addEventListener('hashchange', onRoute);
    steps = 1;
    render();
  }
  boot();
})();
