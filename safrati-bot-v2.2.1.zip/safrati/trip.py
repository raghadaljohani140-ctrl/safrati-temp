"""The trip screens: cheapest days, exact dates, price calendar, month overview and the date pickers."""
from __future__ import annotations

import logging
import urllib.parse
from datetime import date, timedelta
from html import escape as html_escape

from . import data, texts
from . import dates as dts
from . import insights as ins
from .db import ORIGINS
from .insights import TripView
from .telegram import button, keyboard
from .tp import Offer, TPError, month_keys, with_marker
from .ui import BOOKING_BUTTONS, DATE_ROWS, PAD, STAYS, TRIP_LENGTHS, chunk, footer, sar

log = logging.getLogger("safrati.trip")

HINT_MIN_SAVING = 60        # riyals; a smaller saving is not worth a hint
HINT_MIN_SHARE = 0.06       # ... and neither is one under 6% of the price
CALENDAR_MONTHS = 12
OVERVIEW_MONTHS = 6
WEEKDAYS = ("أحد", "إثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت")


def trip_payload(dest: data.Destination, wish: dts.DateWish) -> str:
    """The text after /start in a shared link: d_IST, d_IST_202612, d_IST_20261215, d_IST_20261215_20261222."""
    base = "d_" + dest.iata
    if wish.depart:
        back = "_o" if wish.one_way else (f"_{dts.encode_day(wish.ret)}" if wish.ret else "")
        return f"{base}_{dts.encode_day(wish.depart)}{back}"
    if wish.month:
        return f"{base}_{dts.encode_month(wish.month)}"
    return base


def parse_trip_payload(payload: str) -> tuple[data.Destination, dts.DateWish] | None:
    parts = payload.split("_")
    if parts[0] != "d" or len(parts) not in (2, 3, 4):
        return None
    dest = data.by_iata().get(parts[1])
    if dest is None:
        return None
    if len(parts) == 2:
        return dest, dts.DateWish()
    if len(parts) == 3:
        day = dts.decode_day(parts[2])
        if day:
            return dest, dts.DateWish(depart=day)
        month = dts.decode_month(parts[2])
        return (dest, dts.DateWish(month=month)) if month else None
    day = dts.decode_day(parts[2])
    if day is None:
        return None
    if parts[3] == "o":
        return dest, dts.DateWish(depart=day, one_way=True)
    back = dts.decode_day(parts[3])
    return (dest, dts.DateWish(depart=day, ret=back)) if back else None


def watch_scope(wish: dts.DateWish) -> str:
    """How a price alert names what it watches: any | w | m:YYYY-MM | e:DAY:DAY | o:DAY."""
    if wish.depart:
        if wish.one_way or not wish.ret:
            return "o:" + wish.depart.isoformat()
        return f"e:{wish.depart.isoformat()}:{wish.ret.isoformat()}"
    if wish.weekend:
        return "w"
    if wish.month:
        return "m:" + wish.month
    return "any"


def wish_of_scope(scope: str) -> dts.DateWish | None:
    """The search a price alert stands for (the opposite of watch_scope); None for a scope we do not know."""
    kind, _, rest = scope.partition(":")
    if scope == "any":
        return dts.DateWish()
    if scope == "w":
        return dts.DateWish(weekend=True)
    if kind == "m" and dts.decode_month(rest.replace("-", "")):
        return dts.DateWish(month=rest)
    if kind == "e" and rest.count(":") == 1:
        dep, ret = (dts.decode_day(x.replace("-", "")) for x in rest.split(":"))
        return dts.DateWish(depart=dep, ret=ret) if dep and ret else None
    if kind == "o":
        dep = dts.decode_day(rest.replace("-", ""))
        return dts.DateWish(depart=dep, one_way=True) if dep else None
    return None


class TripMixin:
    """Mixed into SafratiBot. Uses its tp, db, api, clock, say(), show() and the quota helper."""

    # ------------------------------------------------------------------
    # searching
    # ------------------------------------------------------------------
    def _earliest(self) -> str:
        return (self._today() + timedelta(days=dts.MIN_AHEAD_DAYS)).isoformat()

    def _future_days(self, cals: dict[str, dict[str, Offer]]) -> list[Offer]:
        """Every priced day from tomorrow on, cheapest first."""
        earliest = self._earliest()
        days = [o for cal in cals.values() for day, o in cal.items() if day >= earliest and sar(o) > 0]
        return sorted(days, key=sar)

    def _month_bars(self, cals: dict[str, dict[str, Offer]]) -> list[tuple[str, Offer]]:
        earliest = self._earliest()
        bars = []
        for key in sorted(cals):
            priced = [o for day, o in cals[key].items() if day >= earliest and sar(o) > 0]
            if priced:
                bars.append((key, min(priced, key=sar)))
        return bars

    async def search_trip(
        self, origin: str, dest: data.Destination, wish: dts.DateWish, stay: int | None = None
    ) -> TripView:
        if not self.tp.enabled:
            return TripView(state="off")
        try:
            if wish.depart:
                return await self._search_exact(origin, dest, wish)
            return await self._search_open(origin, dest, wish, stay)
        except TPError as exc:
            log.warning("price lookup failed: %s", exc)
            return TripView(state="error")

    async def _search_open(
        self, origin: str, dest: data.Destination, wish: dts.DateWish, stay: int | None
    ) -> TripView:
        months = [wish.month] if wish.month else month_keys(self.clock() + 86400, 3)
        weekend = wish.weekend
        view = TripView()

        async def fetch(period: list[str], length: int | None, only_weekends: bool):
            cals = await self.tp.calendars(
                origin, dest.iata, period, one_way=wish.one_way, stay=length, weekend=only_weekends
            )
            return cals, self._future_days(cals)

        cals, days = await fetch(months, stay, weekend)
        if not days and wish.month and not stay and not weekend:
            cals, days = await fetch(month_keys(self.clock() + 86400, 3), None, False)
            if days:
                view.note = texts.NOTE_MONTH_MISS
        if not days and stay:
            cals, days = await fetch(months, None, weekend)
            if days:
                view.note = texts.note_stay_miss(stay)
        if not days and weekend:
            cals, days = await fetch(months, stay, False)
            if days:
                view.note = texts.NOTE_WEEKEND_MISS
        view.offers = days[:DATE_ROWS]
        view.state = "ok" if view.offers else "none"
        if view.offers:
            view.verdict = ins.verdict(sar(days[0]), [sar(o) for o in days])
            view.months = self._month_bars(cals)
        return view

    async def _search_exact(self, origin: str, dest: data.Destination, wish: dts.DateWish) -> TripView:
        depart, back = wish.depart, (wish.ret if not wish.one_way else None)
        month = depart.strftime("%Y-%m")
        offers = await self.tp.exact(
            origin, dest.iata, depart.isoformat(), back.isoformat() if back else None, one_way=wish.one_way
        )
        offers = [o for o in offers if sar(o) > 0]
        view = TripView(offers=offers)
        if not offers:
            cals = await self.tp.calendars(origin, dest.iata, [month], one_way=wish.one_way)
            near = self._future_days(cals)
            near.sort(key=lambda o: abs((date.fromisoformat(o.departure_at[:10]) - depart).days))
            view.offers = sorted(near[:DATE_ROWS], key=lambda o: o.departure_at)
            view.note = texts.NOTE_ROUND_MISS if back else texts.NOTE_EXACT_MISS
        else:
            view.hint = await self._cheaper_nearby(origin, dest, wish, month, offers[0])
        view.state = "ok" if view.offers else "none"
        return view

    async def _cheaper_nearby(
        self, origin: str, dest: data.Destination, wish: dts.DateWish, month: str, best: Offer
    ) -> tuple[Offer, int] | None:
        """A cheaper departure in the same month for a trip of the same length (None when there is none)."""
        length = (wish.ret - wish.depart).days if wish.ret and not wish.one_way else None
        try:
            cals = await self.tp.calendars(
                origin, dest.iata, [month], one_way=wish.one_way, stay=length if length and length >= 2 else None
            )
        except TPError:
            return None
        earliest, here = self._earliest(), wish.depart.isoformat()
        others = [o for day, o in cals.get(month, {}).items() if day >= earliest and day != here and sar(o) > 0]
        if not others:
            return None
        cheapest = min(others, key=sar)
        saving = round(sar(best) - sar(cheapest))
        if saving >= max(HINT_MIN_SAVING, sar(best) * HINT_MIN_SHARE):
            return cheapest, saving
        return None

    # ------------------------------------------------------------------
    # links
    # ------------------------------------------------------------------
    async def _partner_urls(self, urls: list[str]) -> dict[str, str | None]:
        if not urls or not self.tp.enabled:
            return {}
        try:
            return await self.tp.partner_links(urls, marker_fallback=False)
        except Exception:  # noqa: BLE001 - links are a bonus, never break the answer
            log.warning("partner links unavailable", exc_info=False)
            return {}

    def _wrap(self, plain: str, found: dict[str, str | None]) -> str:
        return found.get(plain) or (with_marker(plain, self.tp.marker) if self.tp.marker else plain)

    def deep_link(self, payload: str) -> str:
        return f"https://t.me/{self.bot_username}?start={payload}"

    def share_button(self, dest: data.Destination, wish: dts.DateWish) -> dict | None:
        if not self.bot_username:
            return None
        text = f"✈️ {dest.ar} — شوف أرخص الأسعار في سفرتي"
        url = (
            "https://t.me/share/url?url=" + urllib.parse.quote(self.deep_link(trip_payload(dest, wish)), safe="")
            + "&text=" + urllib.parse.quote(text, safe="")
        )
        return button("📤 شارك", url=url)

    # ------------------------------------------------------------------
    # the trip screen
    # ------------------------------------------------------------------
    @staticmethod
    def _enc(dest: data.Destination, wish: dts.DateWish) -> str:
        """Button data that carries a destination and (optionally) the dates: d:IST:20261215:20261222[:1]"""
        if not wish.has_dates:
            return "d:" + dest.iata
        dep, ret = dts.encode_when(wish)
        return f"d:{dest.iata}:{dep}:{ret}" + (":1" if wish.one_way else "")

    @staticmethod
    def _wish_from(arg: str) -> dts.DateWish | None:
        """Dates carried by a d: button; an empty DateWish for a plain d:IST; None when malformed."""
        parts = arg.split(":")
        if len(parts) == 1:
            return dts.DateWish()
        if len(parts) not in (3, 4) or (len(parts) == 4 and parts[3] != "1"):
            return None
        return dts.decode_when(parts[1], parts[2], len(parts) == 4)

    def _calendar_month(self, view: TripView, wish: dts.DateWish) -> str:
        if wish.month_key:
            return wish.month_key
        if view.offers:
            return view.offers[0].departure_at[:7]
        return dts.month_choices(self._today(), 1)[0]

    async def _trip_rows(
        self, uid: int, dest: data.Destination, origin: str, view: TripView, wish: dts.DateWish, stay: int | None
    ) -> list[list[dict]]:
        iata = dest.iata
        partners = data.partners()
        shown = [o for o in view.offers if o.link][:BOOKING_BUTTONS]
        flight_urls = [self.tp.site_url(o.link) for o in shown]
        live_url = ""
        if view.state == "none" and wish.depart:
            live_url = self.tp.search_url(origin, iata, wish.depart, None if wish.one_way else wish.ret)
        found = await self._partner_urls(flight_urls + ([live_url] if live_url else []) + [pt.url for pt in partners])

        rows: list[list[dict]] = []
        if live_url:
            rows.append([button("🔎 بحث مباشر (يشمل التوقف)", url=self._wrap(live_url, found))])
        for o, plain in zip(shown, flight_urls):
            when = texts.when_text(o, wish.one_way)
            rows.append([button(f"✈️ {when} — {round(sar(o)):,} ر.س", url=self._wrap(plain, found))])
        if view.hint:
            offer, saving = view.hint
            rows.append([button(
                f"💡 {texts.when_text(offer)} — {round(sar(offer)):,} ر.س (وفّر {saving:,})", data=self._cal_day(iata, offer)
            )])

        month_token = dts.encode_month(self._calendar_month(view, wish))
        stay_token = stay or 0
        info = []
        if not wish.one_way:
            info.append(button("📆 التقويم", data=f"cal:{iata}:{month_token}:{stay_token}"))
            info.append(button("📊 أرخص شهر", data=f"ov:{iata}:{stay_token}"))
        if info:
            rows.append(info)
        alert_dep, alert_ret = dts.encode_when(wish)
        if wish.weekend and not wish.depart:
            alert_dep = "w"
        second = [
            button("🔔 نبهني", data=f"wa:{iata}:{alert_dep}:{alert_ret}:{1 if wish.one_way else 0}:{stay_token}"),
            button("📅 غيّر التاريخ" if wish.depart else "📅 حدّد التاريخ", data="dp:" + iata),
        ]
        if wish.depart:
            second.append(button("🔎 أرخص الأيام", data="d:" + iata))
        elif stay or wish.weekend or wish.month:
            second.append(button("🔎 أي مدة", data="d:" + iata))
        rows.append(second)
        if not wish.depart and not wish.one_way:
            month = dts.encode_month(wish.month) if wish.month else "-"
            stays = [
                button(texts.days_text(n) + (" ✔" if n == stay and not wish.weekend else ""), data=f"dy:{iata}:{n}:{month}")
                for n in STAYS
            ]
            rows.append(stays[:3])
            rows.append(stays[3:] + [button("🌙 ويكند" + (" ✔" if wish.weekend else ""), data=f"dw:{iata}:{month}")])

        saved = self.db.is_saved(uid, iata)
        last = [
            button("💔 إزالة" if saved else "❤️ احفظ", data=("us:" if saved else "sv:") + iata),
            button("🛂 التأشيرة", data="visa:" + iata),
        ]
        share = self.share_button(dest, wish)
        if share:
            last.append(share)
        rows.append(last)
        extra = [button(f"📍 من {texts.ORIGIN_NAMES.get(origin, origin)}", data="oc:" + iata)]
        if any(found.get(pt.url) for pt in partners):
            extra.append(button("🧳 خدمات الرحلة", data="svc:" + iata))
        rows.append(extra)
        rows.append(footer())
        return rows

    @staticmethod
    def _cal_day(iata: str, offer: Offer) -> str:
        """Button data that opens one exact trip: cd:IST:20261212:20261219"""
        dep = dts.decode_day(offer.departure_at[:10].replace("-", ""))
        back = dts.decode_day(offer.return_at[:10].replace("-", "")) if offer.return_at else None
        return f"cd:{iata}:{dts.encode_day(dep)}:{dts.encode_day(back)}"

    async def show_trip(
        self,
        chat_id: int,
        uid: int,
        dest: data.Destination,
        origin: str,
        wish: dts.DateWish | None = None,
        stay: int | None = None,
        *,
        edit_mid: int | None = None,
        count: bool = True,
    ) -> None:
        if dest.iata == origin:
            await self.say(chat_id, texts.same_city(dest.ar), self.menu_markup())
            return
        wish = wish or dts.DateWish()
        stay = stay or wish.stay
        if count and not self._quota(uid):
            await self.say(chat_id, texts.LIMIT_REACHED, self.menu_markup())
            return
        await self.api.send_action(chat_id)
        view = await self.search_trip(origin, dest, wish, stay)
        self.db.mark_seen(uid, dest.iata)
        self.db.bump_popular(dest.iata)
        self._last_dest[uid] = dest.iata
        self._last_wish.pop(uid, None)
        text = texts.trip_text(dest, origin, view, wish, stay)
        rows = await self._trip_rows(uid, dest, origin, view, wish, stay)
        await self.show(chat_id, text, keyboard(rows), edit_mid)

    # ------------------------------------------------------------------
    # price calendar
    # ------------------------------------------------------------------
    async def show_calendar(
        self, chat_id: int, dest: data.Destination, origin: str, month: str, stay: int, edit_mid: int | None
    ) -> None:
        today = self._today()
        keys = dts.month_choices(today, CALENDAR_MONTHS)
        if month not in keys:
            await self.say(chat_id, texts.BAD_BUTTON, self.menu_markup())
            return
        await self.api.send_action(chat_id)
        iata = dest.iata
        try:
            cal = await self.tp.calendar(origin, iata, month, stay=stay or None)
        except TPError as exc:
            log.warning("calendar lookup failed: %s", exc)
            await self.show(chat_id, texts.BUSY, keyboard([footer()]), edit_mid)
            return
        earliest = self._earliest()
        days = {d: o for d, o in cal.items() if d >= earliest and sar(o) > 0}
        prices = [sar(o) for o in days.values()]
        cuts = ins.tier_cuts(prices) if len(prices) >= 3 else None
        cheapest = min(prices) if prices else 0
        best = None
        if days:
            top = min(days.values(), key=sar)
            best = (top.departure_at[:10], round(sar(top)))

        rows = [[button(w, data="x") for w in WEEKDAYS]]
        for week in dts.month_grid(month, today):
            row = []
            for number, selectable in week:
                if not number:
                    row.append(button(PAD, data="x"))
                    continue
                iso = f"{month}-{number:02d}"
                offer = days.get(iso)
                if offer and selectable:
                    if cuts:
                        mark = ins.TIER_EMOJI[ins.tier_of(sar(offer), cuts)]
                    else:
                        mark = ins.TIER_EMOJI["low"] if sar(offer) <= cheapest else ins.TIER_EMOJI["mid"]
                    row.append(button(f"{mark}{number}", data=self._cal_day(iata, offer)))
                elif selectable:
                    row.append(button(str(number), data="x"))
                else:
                    row.append(button(PAD, data="x"))
            rows.append(row)

        i = keys.index(month)
        nav = []
        if i > 0:
            nav.append(button(f"⬅️ {texts.MONTHS[int(keys[i - 1][5:]) - 1]}", data=f"cal:{iata}:{dts.encode_month(keys[i - 1])}:{stay}"))
        if i + 1 < len(keys):
            nav.append(button(f"{texts.MONTHS[int(keys[i + 1][5:]) - 1]} ➡️", data=f"cal:{iata}:{dts.encode_month(keys[i + 1])}:{stay}"))
        if nav:
            rows.append(nav)
        rows.append([
            button("📊 أرخص شهر", data=f"ov:{iata}:{stay}"),
            button("🔎 أرخص الأيام", data=f"d:{iata}"),
        ])
        rows.append([button("🔔 نبهني", data=f"wa:{iata}:{dts.encode_month(month)}:-:0:{stay}"), button("🏠 القائمة", data="menu")])
        await self.show(chat_id, texts.calendar_text(dest, origin, month, best, stay or None), keyboard(rows), edit_mid)

    async def show_overview(
        self, chat_id: int, dest: data.Destination, origin: str, stay: int, edit_mid: int | None
    ) -> None:
        keys = dts.month_choices(self._today(), OVERVIEW_MONTHS)
        await self.api.send_action(chat_id)
        iata = dest.iata
        try:
            cals = await self.tp.calendars(origin, iata, keys, stay=stay or None)
        except TPError as exc:
            log.warning("overview lookup failed: %s", exc)
            await self.show(chat_id, texts.BUSY, keyboard([footer()]), edit_mid)
            return
        months = self._month_bars(cals)
        buttons = [
            button(f"{texts.MONTHS[int(key[5:]) - 1]} — {round(sar(o)):,}", data=f"cal:{iata}:{dts.encode_month(key)}:{stay}")
            for key, o in months
        ]
        rows = chunk(buttons, 2)
        rows.append([button("🔎 أرخص الأيام", data=f"d:{iata}"), button("🏠 القائمة", data="menu")])
        await self.show(chat_id, texts.overview_text(dest, origin, months, stay or None), keyboard(rows), edit_mid)

    # ------------------------------------------------------------------
    # origin change from a trip
    # ------------------------------------------------------------------
    async def show_origin_picker(self, chat_id: int, uid: int, dest: data.Destination, edit_mid: int | None) -> None:
        current = self.db.touch_user(uid)["origin"]
        buttons = [
            button(("✔ " if code == current else "") + texts.ORIGIN_NAMES[code], data=f"ox:{code}:{dest.iata}")
            for code in ORIGINS
        ]
        rows = chunk(buttons, 3)
        rows.append([button("⬅️ رجوع", data="d:" + dest.iata)])
        text = f"📍 <b>من أي مدينة تسافر إلى {dest.flag} {html_escape(dest.ar)}؟</b>"
        await self.show(chat_id, text, keyboard(rows), edit_mid)

    # ------------------------------------------------------------------
    # the date picker: month -> day -> trip length
    # ------------------------------------------------------------------
    async def show_month_picker(self, chat_id: int, dest: data.Destination, edit_mid: int | None) -> None:
        keys = dts.month_choices(self._today(), 6)
        buttons = [button(texts.month_label(k), data=f"dm:{dest.iata}:{dts.encode_month(k)}") for k in keys]
        rows = chunk(buttons, 2)
        rows.append([button("🔎 أرخص وقت", data="d:" + dest.iata)])
        rows.append(footer())
        text = texts.PICK_MONTH.format(dest=f"{dest.flag} {html_escape(dest.ar)}")
        await self.show(chat_id, text, keyboard(rows), edit_mid)

    async def show_day_picker(self, chat_id: int, dest: data.Destination, month: str, edit_mid: int | None) -> None:
        today = self._today()
        rows = [[button(w, data="x") for w in WEEKDAYS]]
        for week in dts.month_grid(month, today):
            row = []
            for day, ok in week:
                if day and ok:
                    token = dts.encode_day(date(int(month[:4]), int(month[5:]), day))
                    row.append(button(str(day), data=f"dd:{dest.iata}:{token}"))
                else:
                    row.append(button(PAD, data="x"))
            rows.append(row)
        rows.append([button("🔎 كل الشهر (أرخص يوم)", data=f"d:{dest.iata}:{dts.encode_month(month)}:-")])
        rows.append([button("⬅️ الأشهر", data="dp:" + dest.iata), button("🏠 القائمة", data="menu")])
        text = texts.PICK_DEPART.format(dest=f"{dest.flag} {html_escape(dest.ar)}", month=texts.month_label(month))
        await self.show(chat_id, text, keyboard(rows), edit_mid)

    async def show_return_picker(self, chat_id: int, dest: data.Destination, day: date, edit_mid: int | None) -> None:
        token = dts.encode_day(day)
        buttons = [
            button("ذهاب فقط" if n == 0 else texts.days_text(n), data=f"dr:{dest.iata}:{token}:{n}") for n in TRIP_LENGTHS
        ]
        rows = chunk(buttons, 3)
        rows.append([button("⬅️ غيّر اليوم", data=f"dm:{dest.iata}:{dts.encode_month(day.strftime('%Y-%m'))}")])
        rows.append(footer())
        text = texts.PICK_RETURN.format(
            dest=f"{dest.flag} {html_escape(dest.ar)}", dep=texts.fmt_date(day.isoformat())
        ) + "\n(أو اكتب التواريخ مثل <b>15/12 - 22/12</b>)"
        await self.show(chat_id, text, keyboard(rows), edit_mid)
