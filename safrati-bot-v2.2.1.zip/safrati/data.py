"""Destinations, visa table, and understanding of the user's free text (no AI service needed)."""
from __future__ import annotations

import difflib
import json
import re
from dataclasses import dataclass
from functools import lru_cache
from datetime import date
from pathlib import Path

from .dates import DateWish, parse_dates

DATA_DIR = Path(__file__).parent / "data"


def welcome_image() -> bytes | None:
    """The picture of the channel's welcome post (None when the file is missing)."""
    try:
        return (DATA_DIR / "welcome.png").read_bytes()
    except OSError:
        return None

_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
_MARKS = re.compile("[ً-ٰٟـ]")


def norm_keep(text: str) -> str:
    """Normalize Arabic letters and digits but keep punctuation (needed to read numbers)."""
    t = text.translate(_DIGITS)
    t = _MARKS.sub("", t)
    for a, b in (("أ", "ا"), ("إ", "ا"), ("آ", "ا"), ("ٱ", "ا"), ("ى", "ي"), ("ة", "ه")):
        t = t.replace(a, b)
    t = t.lower()
    t = re.sub(r"(?<=\d)[,،٬](?=\d{3}\b)", "", t)  # 5,000 -> 5000
    return t


def norm(text: str) -> str:
    t = norm_keep(text)
    t = re.sub(r"[^\w\s]", " ", t)
    return re.sub(r"\s+", " ", t).strip()


_PREFIXES = ("وبال", "وال", "بال", "فال", "كال", "لل", "ال", "و", "ب", "ل", "ف")


def _variants(token: str):
    yield token
    for p in _PREFIXES:
        if token.startswith(p) and len(token) - len(p) >= 3:
            yield token[len(p):]


def _strip_al(s: str) -> str:
    return s[2:] if s.startswith("ال") and len(s) > 4 else s


@dataclass(frozen=True)
class Destination:
    iata: str
    ar: str
    en: str
    cc: str
    country_ar: str
    tags: tuple[str, ...]
    cost: str
    aliases: tuple[str, ...]

    @property
    def flag(self) -> str:
        return "".join(chr(0x1F1E6 + ord(c) - 65) for c in self.cc.upper())


@dataclass(frozen=True)
class VisaInfo:
    status: str  # free | gcc | arrival | evisa | required | check
    agreed: bool


@dataclass(frozen=True)
class Intent:
    budget: int | None
    destinations: tuple[Destination, ...]
    origin: str | None
    tags: tuple[str, ...]
    ticket_only: bool = False
    dates: DateWish = DateWish()
    regions: tuple[str, ...] = ()
    cheapest: bool = False
    rest: str = ""                  # the text left once the dates were taken out (what a misspelt place would be in)


ORIGIN_WORDS = {
    "RUH": ["الرياض", "riyadh"],
    "JED": ["جده", "jeddah", "jedda"],
    "DMM": ["الدمام", "dammam", "الخبر", "الشرقيه"],
    "MED": ["المدينه المنوره", "المدينه", "medina", "madinah"],
    "AHB": ["ابها", "abha"],
    "GIZ": ["جازان", "jazan"],
    "TIF": ["الطايف", "taif"],
    "ELQ": ["القصيم", "بريده", "buraydah"],
    "TUU": ["تبوك", "tabuk"],
}

TAG_WORDS = {
    "beach": ["بحر", "شاطي", "شواطي", "ساحل", "سواحل", "beach", "جزر", "جزيره"],
    "mountains": ["جبال", "جبل", "ثلج", "ثلوج", "mountain", "mountains"],
    "nature": ["طبيعه", "غابات", "شلالات", "خضره", "nature"],
    "shopping": ["تسوق", "شوبنج", "shopping", "اسواق"],
    "calm": ["هدوء", "هادي", "هاديه", "استرخاء", "راحه", "relax", "calm"],
    "adventure": ["مغامره", "مغامرات", "adventure"],
    "food": ["اكل", "مطاعم", "طعام", "food"],
    "family": ["عايله", "عائله", "اطفال", "عيال", "family"],
    "culture": ["تاريخ", "ثقافه", "اثار", "متاحف", "culture"],
}

# Country codes per region. A country may sit in several regions ("عربية" and "خليجية" overlap on purpose).
REGION_CC: dict[str, frozenset[str]] = {
    "gulf": frozenset({"AE", "BH", "QA", "OM", "KW"}),
    "arab": frozenset({"AE", "BH", "QA", "OM", "KW", "EG", "JO", "LB", "MA", "TN"}),
    "caucasus": frozenset({"GE", "AZ", "AM"}),
    "central_asia": frozenset({"KZ", "UZ", "KG"}),
    "asia": frozenset({"MY", "TH", "SG", "ID", "JP", "KR", "VN", "KH", "PH", "LK", "MV"}),
    "europe": frozenset({"AT", "CH", "CZ", "FR", "ES", "IT", "GR", "DE", "NL", "GB", "AL", "BA", "ME"}),
    "africa": frozenset({"KE", "TZ", "MU", "SC", "EG", "MA", "TN"}),
    "america": frozenset({"US"}),
    "saudi": frozenset({"SA"}),            # trips inside the kingdom: shown only when asked for
}
REGION_WORDS = {
    "gulf": ["الخليج", "خليجي", "خليجيه", "gulf"],
    "arab": ["دول عربيه", "الدول العربيه", "عربيه", "arab"],
    "caucasus": ["القوقاز", "قوقاز", "caucasus"],
    "central_asia": ["وسط اسيا", "اسيا الوسطي", "اسيا الوسطى", "central asia"],
    "asia": ["اسيا", "asia"],
    "europe": ["اوروبا", "اوربا", "ارووبا", "europe", "شنغن", "شنقن", "شينغن", "schengen"],
    "africa": ["افريقيا", "africa"],
    "america": ["امريكا", "america", "usa"],
    "saudi": ["داخل السعوديه", "داخل المملكه", "داخلي", "داخليه", "محلي", "محليه", "سياحه داخليه", "سياحه محليه", "في السعوديه",
              "ربوع البلاد", "ربوع بلادي", "saudi", "domestic"],
}
_CHEAP_WORDS = ("ارخص", "اوفر", "رخيص", "رخيصه", "ارخصها")

_NUMBER_WORDS = {
    "واحد": 1, "اثنين": 2, "اثنان": 2, "ثلاثه": 3, "اربعه": 4, "خمسه": 5, "سته": 6, "سبعه": 7,
    "ثمانيه": 8, "تسعه": 9, "عشره": 10, "عشرين": 20, "ثلاثين": 30, "اربعين": 40, "خمسين": 50,
}
_THOUSAND = ("الف", "الاف", "k", "ك")
_NOT_MONEY_AFTER = ("ايام", "يوم", "ليال", "ليله", "اسابيع", "اسبوع", "اشخاص", "شخص", "افراد", "فرد", "اطفال", "كيلو")
_NUM_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(الف|الاف|k|ك)?(?![\d])")


@lru_cache(maxsize=1)
def destinations() -> tuple[Destination, ...]:
    raw = json.loads((DATA_DIR / "destinations.json").read_text(encoding="utf-8"))
    return tuple(
        Destination(
            iata=d["iata"], ar=d["ar"], en=d["en"], cc=d["cc"], country_ar=d["country_ar"],
            tags=tuple(d["tags"]), cost=d["cost"], aliases=tuple(d["aliases"]),
        )
        for d in raw
    )


@dataclass(frozen=True)
class Partner:
    id: str
    label: str
    url: str


@lru_cache(maxsize=1)
def partners() -> tuple[Partner, ...]:
    raw = json.loads((DATA_DIR / "partners.json").read_text(encoding="utf-8"))
    return tuple(Partner(p["id"], p["label"], p["url"]) for p in raw["items"])


@lru_cache(maxsize=1)
def by_iata() -> dict[str, Destination]:
    return {d.iata: d for d in destinations()}


# Places Saudis really fly to for a Thursday-to-weekend break, most popular first. The weekend list asks about
# these one by one, because the provider's big "everything from this city" answer is full of short flights inside the country.
WEEKEND_PLACES = (
    "DXB", "BAH", "DOH", "AUH", "KWI", "MCT", "CAI", "AMM", "BEY", "SSH", "HRG", "SLL",
    "IST", "TZX", "AYT", "TBS", "BUS", "BAK", "EVN",
)


# The same for a break inside the kingdom (asked for with "ويكند داخلي"), looked up only then.
WEEKEND_DOMESTIC = ("ULH", "AHB", "TIF", "JED", "RUH", "MED", "DMM", "TUU", "GIZ", "YNB", "ABT", "ELQ")


def weekend_destinations(domestic: bool = False) -> tuple[str, ...]:
    known = by_iata()
    return tuple(code for code in (WEEKEND_DOMESTIC if domestic else WEEKEND_PLACES) if code in known)


@lru_cache(maxsize=1)
def visa_table() -> tuple[dict[str, VisaInfo], str, tuple[str, ...]]:
    raw = json.loads((DATA_DIR / "visa_sa.json").read_text(encoding="utf-8"))
    table = {cc: VisaInfo(v["status"], bool(v["agreed"])) for cc, v in raw["countries"].items()}
    return table, raw["verified_on"], tuple(raw["sources"])


def visa_official(cc: str) -> str | None:
    """Official government page for applying, when we have one."""
    raw = json.loads((DATA_DIR / "visa_sa.json").read_text(encoding="utf-8"))
    url = (raw.get("official") or {}).get(cc)
    return url if isinstance(url, str) and url.startswith("https://") else None


def visa_for(cc: str) -> VisaInfo | None:
    return visa_table()[0].get(cc)


@lru_cache(maxsize=1)
def _alias_index() -> dict[str, tuple[Destination, ...]]:
    index: dict[str, list[Destination]] = {}
    for d in destinations():
        keys = {d.ar, d.en, *d.aliases}
        for alias in keys:
            toks = norm(alias).split(" ")
            if not toks or not toks[0]:
                continue
            toks[0] = _strip_al(toks[0])
            key = " ".join(toks)
            bucket = index.setdefault(key, [])
            if d not in bucket:
                bucket.append(d)
    return {k: tuple(v) for k, v in index.items()}


def _find_phrases(tokens: list[str], index: dict[str, object], max_len: int = 3):
    """Yield (key, start, end) for every n-gram of the tokens that matches the index."""
    for i in range(len(tokens)):
        for n in range(1, max_len + 1):
            if i + n > len(tokens):
                break
            rest = tokens[i + 1:i + n]
            for v in _variants(tokens[i]):
                key = " ".join([_strip_al(v), *rest])
                if key in index:
                    yield key, i, i + n


def find_destinations(text: str) -> tuple[Destination, ...]:
    tokens = norm(text).split(" ")
    index = _alias_index()
    found: dict[str, Destination] = {}
    for key, start, _ in _find_phrases(tokens, index):
        if start and tokens[start - 1] in ("من", "from") and key in _origin_index():
            continue                    # "من جدة": the city of departure, not a place to go to
        for d in index[key]:
            found.setdefault(d.iata, d)
    return tuple(found.values())


@lru_cache(maxsize=1)
def _origin_index() -> dict[str, str]:
    index: dict[str, str] = {}
    for code, words in ORIGIN_WORDS.items():
        for w in words:
            toks = norm(w).split(" ")
            toks[0] = _strip_al(toks[0])
            index[" ".join(toks)] = code
    return index


def bare_origin(text: str) -> str | None:
    """A message that is only a departure city ("المدينة المنورة") -> its airport code."""
    tokens = [t for t in norm(text).split(" ") if t]
    if not tokens or len(tokens) > 3:
        return None
    for v in _variants(tokens[0]):
        key = " ".join([_strip_al(v), *tokens[1:]])
        if key in _origin_index():
            return _origin_index()[key]
    return None


def find_origin(text: str) -> str | None:
    tokens = norm(text).split(" ")
    index = _origin_index()
    # an origin is only recognised after the word "من" / "from"
    for i, tok in enumerate(tokens):
        if tok in ("من", "from") and i + 1 < len(tokens):
            for n in (3, 2, 1):
                chunk = tokens[i + 1:i + 1 + n]
                if len(chunk) != n:
                    continue
                for v in _variants(chunk[0]):
                    key = " ".join([_strip_al(v), *chunk[1:]])
                    if key in index:
                        return index[key]
    return None


def find_tags(text: str) -> tuple[str, ...]:
    padded = f" {norm(text)} "
    found = []
    for tag, words in TAG_WORDS.items():
        for w in words:
            w = norm(w)
            if f" {w} " in padded or any(f" {p}{w} " in padded for p in ("ل", "ب", "و", "ال", "بال")):
                found.append(tag)
                break
    return tuple(found)


def find_budget(text: str) -> int | None:
    t = norm_keep(text)
    best: int | None = None
    for m in _NUM_RE.finditer(t):
        value = float(m.group(1))
        unit = m.group(2)
        tail = t[m.end():].strip().split(" ")[0] if t[m.end():].strip() else ""
        if unit in _THOUSAND:
            value *= 1000
        elif tail in _NOT_MONEY_AFTER:
            continue
        amount = int(value)
        if 300 <= amount <= 1_000_000:
            best = amount if best is None else max(best, amount)
    if best is not None:
        return best
    words = re.sub(r"[^\w\s]", " ", t).split()
    for i, w in enumerate(words[:-1]):
        base = _NUMBER_WORDS.get(w)
        if base and words[i + 1] in _THOUSAND:
            return base * 1000
    return None


_TICKET_WORDS = ("تذكره", "تذاكر", "تذكرتي", "طيران", "طيرانات")

# Short, closed lists: words that mean something when the message has no destination or budget.
_SMALL_TALK = {
    "surprise": ("اقترح", "اقتراح", "اقتراحات", "رشح", "رشحلي", "مدري", "مادري", "اسافر", "سفر", "رحله", "رحلات", "وين", "اروح"),
    "greeting": ("مرحبا", "مرحبتين", "هلا", "اهلا", "اهلين", "السلام", "سلام", "هاي", "hi", "hello", "hey", "صباح", "مساء"),
    "thanks": ("شكرا", "مشكور", "مشكوره", "يعطيك", "تسلم", "يسلمو", "thanks", "thx", "thank"),
    "settings": ("اعدادات", "اعداد", "مدينتي"),
    "saved": ("محفوظاتي", "محفوظات", "محفوظه", "مفضله", "مفضلتي", "مفضلات"),
    "help": ("مساعده", "help", "start", "ابدا", "بدايه"),
    "alerts": ("تنبيهاتي", "تنبيهات", "تنبيه", "نبهني", "نبهيني", "تنبيهي", "منبهات"),
}


def _token_matches(tokens: list[str], words: tuple[str, ...]) -> bool:
    wanted = {norm(w) for w in words}
    return any(v in wanted for tok in tokens for v in _variants(tok))


def wants_ticket_only(text: str) -> bool:
    return _token_matches(norm(text).split(" "), _TICKET_WORDS)


def small_talk(text: str) -> str | None:
    """Return surprise | greeting | thanks | settings | saved | alerts | help when the text is only that."""
    tokens = [t for t in norm(text).split(" ") if t]
    if not tokens or len(tokens) > 8:
        return None
    if any(t.startswith(("فاج", "فجئ", "فجا")) for t in tokens):
        return "surprise"
    for kind in ("help", "settings", "saved", "alerts", "thanks", "greeting", "surprise"):
        if _token_matches(tokens, _SMALL_TALK[kind]):
            return kind
    return None


def find_regions(text: str) -> tuple[str, ...]:
    padded = f" {norm(text)} "
    found = []
    for region in ("saudi", "central_asia", "gulf", "arab", "caucasus", "asia", "europe", "africa", "america"):
        for word in REGION_WORDS[region]:
            w = norm(word)
            if f" {w} " in padded or any(f" {p}{w} " in padded for p in ("ل", "ب", "و", "ال", "بال")):
                found.append(region)
                if region == "central_asia":          # do not read "وسط اسيا" again as plain "اسيا"
                    padded = padded.replace(f" {w} ", "  ")
                break
    return tuple(found)


def in_region(dest: Destination, regions: tuple[str, ...]) -> bool:
    return any(dest.cc in REGION_CC[r] for r in regions)


def region_ok(dest: Destination, regions: tuple[str, ...]) -> bool:
    """Lists of places to fly to: with a region, that region; without one, abroad only (cheap flights inside the kingdom would fill them)."""
    return in_region(dest, regions) if regions else dest.cc != "SA"


def wants_cheapest(text: str) -> bool:
    return _token_matches(norm(text).split(" "), _CHEAP_WORDS)


@lru_cache(maxsize=1)
def _suggest_keys() -> tuple[str, ...]:
    return tuple(k for k in _alias_index() if len(k) >= 3 and " " not in k)


_NOT_TYPOS = frozenset({"قطار", "قطارات"})      # real words that merely look like a place name


def suggest(text: str) -> tuple[Destination, ...]:
    """A destination the person probably meant by a misspelt word ("اسطمبول"); empty when nothing is close."""
    tokens = [t for t in norm(text).split(" ") if t]
    if not tokens or len(tokens) > 3 or any(t in _NOT_TYPOS for t in tokens):
        return ()
    best_ratio, best_key = 0.0, None
    keys = _suggest_keys()
    for token in tokens:
        for variant in _variants(token):
            query = _strip_al(variant)
            if len(query) < 4:
                continue
            for key in difflib.get_close_matches(query, keys, n=1, cutoff=0.8):
                ratio = difflib.SequenceMatcher(None, query, key).ratio()
                if ratio > best_ratio:
                    best_ratio, best_key = ratio, key
    if best_key is None:
        return ()
    return _alias_index()[best_key]


def understand(text: str, today: date | None = None) -> Intent:
    wish, rest = parse_dates(norm_keep(text), today or date.today())
    return Intent(
        budget=find_budget(rest),
        destinations=find_destinations(rest),
        origin=find_origin(rest),
        tags=find_tags(rest),
        ticket_only=wants_ticket_only(rest),
        dates=wish,
        regions=find_regions(rest),
        cheapest=wants_cheapest(rest),
        rest=rest,
    )
