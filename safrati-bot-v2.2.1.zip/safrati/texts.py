"""All user-facing Arabic text. Dynamic values are always HTML-escaped."""
from __future__ import annotations

from html import escape

from . import data
from .insights import TripView, Verdict, bar_length
from .tp import MIN_STAY_DAYS, Offer, to_sar  # noqa: F401  (to_sar is re-exported for callers)

MONTHS = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]

ORIGIN_NAMES = {
    "RUH": "الرياض", "JED": "جدة", "DMM": "الدمام", "MED": "المدينة المنورة", "AHB": "أبها",
    "GIZ": "جازان", "TIF": "الطائف", "ELQ": "القصيم", "TUU": "تبوك",
}
COST_TEXT = {"low": "اقتصادية", "mid": "متوسطة", "high": "مرتفعة"}
CURRENCY_SYMBOL = {"sar": "ر.س", "usd": "$"}

TAG_NAMES = {
    "beach": "بحر", "mountains": "جبال", "nature": "طبيعة", "shopping": "تسوق", "calm": "هدوء",
    "adventure": "مغامرة", "food": "أكل", "family": "عائلة", "culture": "ثقافة",
}
TAG_LABELS = {
    "beach": "🏖 بحر", "mountains": "⛰ جبال", "nature": "🌿 طبيعة", "shopping": "🛍 تسوق", "calm": "😌 هدوء",
    "adventure": "🧗 مغامرة", "food": "🍽 أكل", "family": "👨‍👩‍👧 عائلة", "culture": "🏛 ثقافة",
}

VISA_SHORT = {
    "domestic": "🇸🇦 رحلة داخل المملكة، ما تحتاج تأشيرة",
    "free": "✅ بدون تأشيرة مسبقة",
    "gcc": "✅ بدون تأشيرة (دول الخليج، بالهوية الوطنية)",
    "arrival": "🟡 تأشيرة عند الوصول (وقد تتوفر إلكترونيًا)",
    "evisa": "🟡 تأشيرة إلكترونية تُستخرج قبل السفر",
    "required": "🔴 تأشيرة مسبقة من السفارة أو مركز التقديم",
    "check": "⚠️ المصادر مختلفة، تأكد من السفارة قبل الحجز",
}
NO_VISA_ISSUE = ("free", "gcc", "domestic")

AIRLINES = {
    "SV": "السعودية", "XY": "طيران ناس", "F3": "طيران أديل", "TK": "التركية", "EK": "طيران الإمارات",
    "QR": "القطرية", "EY": "الاتحاد", "MS": "مصر للطيران", "RJ": "الملكية الأردنية", "G9": "العربية للطيران",
    "PC": "بيغاسوس", "J9": "طيران الجزيرة", "KU": "الكويتية", "WY": "الطيران العُماني", "GF": "طيران الخليج",
    "ME": "طيران الشرق الأوسط", "AT": "الخطوط المغربية", "TU": "التونسية", "MH": "الماليزية", "TG": "التايلاندية",
    "SQ": "السنغافورية", "BA": "البريطانية", "AF": "الفرنسية", "LH": "لوفتهانزا", "IB": "إيبيريا",
    "AZ": "إيتا", "A3": "إيجيان", "FZ": "فلاي دبي", "PK": "الباكستانية", "J2": "أذربيجان",
}

DISCLOSURE = "🔗 روابط الحجز قد تحمل عمولة للبوت دون أي زيادة عليك."

WELCOME = (
    "أهلًا بك في <b>سفرتي</b> ✈️\n"
    "أرخص رحلات الطيران بتقويم أسعار ملوّن، وأنبهك لما ينزل السعر.\n\n"
    "اكتب لي مباشرة، مثلًا:\n"
    "• <b>دبي</b> ← أرخص الأيام وتقويم الأسعار\n"
    "• <b>اسطنبول 15/12 - 22/12</b> ← رحلة بتاريخ محدد\n"
    "• <b>لندن الشهر الجاي 7 ايام</b> ← شهر ومدة\n"
    "• <b>ويكند</b> ← أرخص رحلات نهاية الأسبوع\n"
    "• <b>اوروبا</b> أو <b>ارخص</b> ← أرخص الوجهات\n"
    "• <b>ابها</b> أو <b>ويكند داخلي</b> ← السفر داخل السعودية\n"
    "• <b>من جدة</b> ← تغيير مدينة انطلاقك\n"
    "أو اضغط الأزرار 👇\n\n" + DISCLOSURE
)
ONBOARD_ASK = (
    "أهلًا بك في <b>سفرتي</b> ✈️\n"
    "أبحث لك عن أرخص رحلات الطيران، وأنبهك لما ينزل السعر.\n\n"
    "📍 <b>من أي مدينة تسافر؟</b>\n"
    "اختر مدينتك لتظهر لك الأسعار منها (تقدر تغيّرها في أي وقت):"
)
ONBOARD_DONE = "تمام 📍 الأسعار الحين من <b>{city}</b>.\nاكتب وجهتك مثل <b>دبي</b> أو <b>اسطنبول ديسمبر</b>، أو اختر من الأزرار 👇"
MENU_PROMPT = "وش تبغى اليوم؟ 👇"
WHERE_PROMPT = (
    "✈️ <b>إلى أين تبغى تسافر؟</b>\n"
    "اكتب اسم المدينة أو الدولة، أو اختر من الأسفل.\n\n"
    "📅 التاريخ اختياري: أضفه بالكتابة مثل <b>دبي 15/12 - 22/12</b> أو <b>دبي ديسمبر</b>،\n"
    "أو اضغط «حدّد التاريخ» بعد اختيار الوجهة. وبدونه أعرض لك أرخص الأيام."
)
PICK_MONTH = "📅 <b>{dest}</b> — اختر شهر السفر:"
PICK_DEPART = "📅 <b>{dest}</b> — {month}\nاختر <b>يوم الذهاب</b>:"
PICK_RETURN = "📅 <b>{dest}</b> — الذهاب {dep}\nاختر <b>يوم العودة</b> (أو «ذهاب فقط»):"
DATE_PROBLEM = {
    "past": "هذا التاريخ فات أو قريب جدًا 🙈 اختر تاريخًا من بكرة فما فوق.",
    "far": "هذا التاريخ بعيد، الأسعار متوفرة تقريبًا لحد 11 شهرًا قدّام. اختر تاريخًا أقرب.",
}
BAD_BUTTON = "هذا الزر قديم، ابدأ من القائمة 👇"
NOTE_EXACT_MISS = "ℹ️ ما لقيت سعرًا محفوظًا لهذا اليوم بالضبط، فهذه أقرب الأسعار في نفس الشهر."
NOTE_MONTH_MISS = "ℹ️ ما لقيت أسعارًا محفوظة لهذا الشهر، فهذه أرخص الأيام في الأشهر القادمة."
NOTE_ROUND_MISS = "ℹ️ ما لقيت سعرًا لهذه الأيام بالضبط، فهذه أقرب الأسعار حولها."
NOTE_CHEAP_DAYS = "💡 هذه أرخص الأيام الموجودة، اضغط على اليوم لفتح الحجز، أو افتح «التقويم» لتشوف كل الأيام."
NOTE_WEEKEND_MISS = "ℹ️ ما لقيت رحلات ويكند بأسعار محفوظة لهذا المسار، فهذه أرخص الأيام بأي مدة."
def note_stay_miss(stay: int) -> str:
    return f"ℹ️ ما لقيت أسعارًا محفوظة لمدة حوالي {days_text(stay)}، فهذه أرخص الأيام بأي مدة. جرّب مدة ثانية من الأزرار."


STAY_PROMPT = "⏱ كم يوم تبغى تقعد؟ اختر المدة وأعرض لك أرخص الأيام لها:"


def origin_set(origin: str) -> str:
    return f"تمام 📍 ضبطت مدينة انطلاقك: <b>{escape(ORIGIN_NAMES.get(origin, origin))}</b>\nالحين اكتب وجهتك، مثل <b>دبي</b> أو <b>لندن ديسمبر</b>."


def wish_line(wish) -> str:
    if wish.depart:
        dep = fmt_date(wish.depart.isoformat())
        if wish.ret and not wish.one_way:
            return f"📅 {dep} ← {fmt_date(wish.ret.isoformat())}"
        return f"📅 {dep} • ذهاب فقط" if wish.one_way else f"📅 الذهاب {dep}"
    if wish.month:
        return f"📅 شهر {MONTHS[int(wish.month[5:]) - 1]} {wish.month[:4]}" + (" • ويكند" if wish.weekend else "")
    if wish.weekend:
        return "📅 ويكند في الأشهر القادمة"
    return "📅 أرخص الأيام في الأشهر القادمة"


def month_label(key: str) -> str:
    return f"{MONTHS[int(key[5:]) - 1]} {key[:4]}"


def days_text(n: int) -> str:
    """2 -> يومين, 3..10 -> N أيام, 11+ -> N يوم (Arabic number grammar)."""
    if n == 2:
        return "يومين"
    return f"{n} أيام" if 3 <= n <= 10 else f"{n} يوم"


def fmt_duration(minutes: int) -> str:
    """330 -> '5س 30د' (flight time including connections)."""
    if minutes <= 0 or minutes > 60 * 60:
        return ""
    hours, rest = divmod(minutes, 60)
    if hours and rest:
        return f"{hours}س {rest}د"
    return f"{hours}س" if hours else f"{rest}د"


def flight_meta(offer: Offer) -> str:
    airline = AIRLINES.get(offer.airline.upper(), offer.airline)
    parts = (escape(airline), stops_text(offer.transfers), fmt_duration(offer.duration))
    return " • ".join(x for x in parts if x)


def when_text(offer: Offer, one_way: bool = False) -> str:
    dep, ret = fmt_date(offer.departure_at), fmt_date(offer.return_at)
    return f"{dep} ← {ret}" if dep and ret and not one_way else dep


VERDICT_LINES = {
    "great": "🟢 <b>سعر ممتاز!</b> أرخص بحوالي {pct}% من المعتاد لهذا المسار",
    "good": "🟢 <b>سعر جيد</b>، أقل من المعتاد بحوالي {pct}%",
    "typical": "🟡 <b>سعر عادي</b> لهذا المسار",
    "high": "🔴 <b>السعر مرتفع شوي</b> مقارنة بباقي الأيام، جرّب تواريخ ثانية أو فعّل تنبيه",
}


def verdict_text(v: Verdict) -> str:
    line = VERDICT_LINES[v.level].format(pct=abs(v.saving))
    return f"{line}\n    (المعتاد حوالي {v.typical:,} ر.س)"


def months_block(months: list[tuple[str, Offer]]) -> str:
    """One line per month with its cheapest price and a bar (a shorter bar is a cheaper month)."""
    priced = [(key, round(to_sar(o.price, o.currency) or 0)) for key, o in months]
    priced = [(k, v) for k, v in priced if v > 0]
    if len(priced) < 2:
        return ""
    highest = max(v for _, v in priced)
    cheapest = min(v for _, v in priced)
    lines = ["📊 <b>السعر حسب الشهر</b>"]
    for key, value in priced:
        n = bar_length(value, cheapest, highest)
        if value == cheapest:
            extra = " ⭐ الأرخص"
        elif value >= cheapest * 1.03:
            extra = f" (+{round((value / cheapest - 1) * 100)}%)"
        else:
            extra = ""
        lines.append(f"{MONTHS[int(key[5:]) - 1]} — {value:,} ر.س " + "█" * n + "░" * (5 - n) + extra)
    return "\n".join(lines)


def hint_text(offer: Offer, saving: int, one_way: bool = False) -> str:
    sar = round(to_sar(offer.price, offer.currency) or 0)
    return f"💡 لو سافرت <b>{when_text(offer, one_way)}</b> توفّر حوالي <b>{saving:,} ر.س</b> (السعر {sar:,} ر.س)"


def trip_text(dest: data.Destination, origin: str, view: TripView, wish, stay: int | None = None) -> str:
    country = "" if dest.ar == dest.country_ar else f" — {escape(dest.country_ar)}"
    lines = [f"🌍 <b>{dest.flag} {escape(dest.ar)}</b>{country}"]
    fit = fit_line(dest)
    if fit:
        lines.append(fit)
    trip = "ذهاب فقط" if wish.one_way else "ذهاب وعودة"
    lines.append(f"📍 من {escape(ORIGIN_NAMES.get(origin, origin))} • {trip}")
    lines.append(wish_line(wish))
    if stay:
        lines.append(f"⏱ مدة الرحلة حوالي {days_text(stay)}")
    if wish.weekend and not wish.depart:
        lines.append("🌙 تغادر الخميس أو الجمعة وترجع السبت أو الأحد")
    lines.append("")
    if view.verdict:
        lines += [verdict_text(view.verdict), ""]
    if view.offers:
        for i, o in enumerate(view.offers, 1):
            meta = flight_meta(o)
            lines.append(f"{i}. 📅 {when_text(o, wish.one_way)} — <b>{money(o.price, o.currency)}</b>" + (f"\n    🛫 {meta}" if meta else ""))
        lines.append("")
    else:
        lines.append(NOTE_NO_PRICE.get(view.state, NOTE_NO_PRICE["none"]))
    if view.hint:
        lines += [hint_text(view.hint[0], view.hint[1], wish.one_way), ""]
    block = months_block(view.months) if len(view.months) >= 2 else ""
    if block:
        lines += [block, ""]
    lines.append(f"🛂 {visa_line(dest)}")
    if view.note:
        lines.append(view.note)
    if view.offers:
        if len(view.offers) > 1:
            lines.append(NOTE_CHEAP_DAYS)
        lines.append("⚠️ السعر وقت البحث وقد يتغير أو ينتهي. الرابط يفتح البحث بأسعار اليوم.")
    return "\n".join(x for x in lines if x is not None).replace("\n\n\n", "\n\n").strip()


REGION_LABELS = {
    "saudi": "🇸🇦 داخل السعودية", "arab": "🕌 عربية", "gulf": "🏜 الخليج", "caucasus": "🏔 القوقاز", "central_asia": "🐪 وسط آسيا",
    "asia": "🌏 آسيا", "europe": "🏰 أوروبا", "africa": "🦁 أفريقيا", "america": "🗽 أمريكا",
}
REGION_TITLES = {
    "saudi": "داخل السعودية", "arab": "الدول العربية", "gulf": "دول الخليج", "caucasus": "القوقاز", "central_asia": "وسط آسيا",
    "asia": "آسيا", "europe": "أوروبا", "africa": "أفريقيا", "america": "أمريكا",
}


def cheap_list(origin: str, rows: list[tuple[data.Destination, Offer, float]], visa_only: bool,
               region: str | None = None, month: str | None = None) -> str:
    title = "🔥 <b>أرخص الرحلات الآن</b>" + (f" — {REGION_TITLES[region]}" if region in REGION_TITLES else "")
    sub = [f"من {escape(ORIGIN_NAMES.get(origin, origin))} • ذهاب وعودة"]
    if month:
        sub.append(month_label(month))
    if visa_only:
        sub.append("بدون تأشيرة فقط")
    head = [title, " • ".join(sub), ""]
    body = []
    for i, (dest, offer, sar) in enumerate(rows, 1):
        line = f"{i}. {dest.flag} <b>{escape(dest.ar)}</b> — من {round(sar):,} ر.س {visa_mark(dest)}"
        when = when_text(offer)
        if when:
            line += f"\n    📅 {when}"
        body.append(line)
    return "\n".join(head + body) + f"\n\n{LEGEND}\nاضغط رقم الوجهة لتشوف الأيام الأرخص وتقويم الأسعار."


# ---- calendar and month overview ----------------------------------------------------------------------
def calendar_text(dest: data.Destination, origin: str, month: str, best, stay: int | None) -> str:
    """`best` is (departure day as ISO text, riyals) of the cheapest day in the month, or None."""
    length = f"حوالي {days_text(stay)}" if stay else f"{days_text(MIN_STAY_DAYS)} فأكثر"
    lines = [
        f"📆 <b>تقويم أسعار {dest.flag} {escape(dest.ar)}</b> — {month_label(month)}",
        f"📍 من {escape(ORIGIN_NAMES.get(origin, origin))} • ذهاب وعودة • {length}",
        "",
    ]
    if best:
        lines.append(f"⭐ أرخص يوم: <b>{fmt_date(best[0])}</b> — <b>{best[1]:,} ر.س</b>")
        lines.append("🟢 رخيص • 🟡 عادي • 🔴 غالي (نسبةً لأيام هذا الشهر)")
        lines.append("اضغط على اليوم لتشوف سعره ورابط الحجز 👇")
    else:
        lines.append("ما لقيت أسعارًا محفوظة في هذا الشهر 🤷 جرّب شهرًا ثانيًا من الأسفل.")
    return "\n".join(lines)


def overview_text(dest: data.Destination, origin: str, months: list[tuple[str, Offer]], stay: int | None) -> str:
    lines = [
        f"📊 <b>أرخص شهر للسفر إلى {dest.flag} {escape(dest.ar)}</b>",
        f"من {escape(ORIGIN_NAMES.get(origin, origin))} • ذهاب وعودة" + (f" • حوالي {days_text(stay)}" if stay else ""),
        "",
    ]
    block = months_block(months)
    if block:
        lines.append(block.split("\n", 1)[1])
    elif months:
        key, offer = months[0]
        lines.append(f"{MONTHS[int(key[5:]) - 1]} — {round(to_sar(offer.price, offer.currency) or 0):,} ر.س")
    else:
        lines.append("ما لقيت أسعارًا محفوظة للأشهر القادمة 🤷")
    if months:
        lines.append("\nاضغط على الشهر لتفتح تقويمه 👇")
    return "\n".join(lines)


# ---- weekend ---------------------------------------------------------------------------------------------
WEEKEND_RULE = "تغادر الخميس أو الجمعة وترجع السبت أو الأحد"


def weekend_list(origin: str, rows: list[tuple[data.Destination, Offer, float]], visa_only: bool) -> str:
    sub = f"من {escape(ORIGIN_NAMES.get(origin, origin))} • {WEEKEND_RULE}" + (" • بدون تأشيرة فقط" if visa_only else "")
    head = ["🌙 <b>أرخص رحلات الويكند</b>", sub, ""]
    body = []
    for i, (dest, offer, sar) in enumerate(rows, 1):
        body.append(
            f"{i}. {dest.flag} <b>{escape(dest.ar)}</b> — من {round(sar):,} ر.س {visa_mark(dest)}\n    📅 {when_text(offer)}"
        )
    return "\n".join(head + body) + f"\n\n{LEGEND}\nاضغط الرقم لفتح الرحلة ورابط الحجز."


WEEKEND_EMPTY = (
    "🌙 ما لقيت رحلات ويكند بأسعار محفوظة الآن.\n"
    "الأسعار تتحدث كل يوم، جرّب بعد قليل أو اضغط «أرخص الرحلات»."
)


# ---- price alerts -----------------------------------------------------------------------------------------
def scope_label(scope: str, stay: int = 0) -> str:
    kind, _, rest = scope.partition(":")
    if scope == "any":
        text = "أرخص يوم في الأشهر القادمة"
    elif scope == "w":
        text = "أرخص ويكند قادم"
    elif kind == "m" and len(rest) == 7:
        text = f"شهر {month_label(rest)}"
    elif kind == "e" and rest.count(":") == 1:
        dep, ret = rest.split(":")
        text = f"{fmt_date(dep)} ← {fmt_date(ret)}"
    elif kind == "o":
        text = f"{fmt_date(rest)} • ذهاب فقط"
    else:
        text = "رحلتك"
    return text + (f" • حوالي {days_text(stay)}" if stay else "")


def watch_created(dest: data.Destination, origin: str, scope: str, stay: int, price: int | None, created: bool) -> str:
    head = "🔔 <b>تمام! بنبهك لما ينزل السعر</b>" if created else "🔔 <b>هذا التنبيه موجود عندي من قبل</b>"
    lines = [
        head,
        f"{dest.flag} <b>{escape(dest.ar)}</b> من {escape(ORIGIN_NAMES.get(origin, origin))}",
        f"📅 {scope_label(scope, stay)}",
    ]
    if price:
        lines.append(f"💵 السعر الحين: <b>{price:,} ر.س</b>")
    else:
        lines.append("💵 ما عندي سعر محفوظ الحين، وأنبهك أول ما يظهر سعر.")
    lines.append("")
    lines.append(
        f"أفحص السعر عدة مرات في اليوم وأرسل لك رسالة لما ينزل {ALERT_DROP_PERCENT}% أو أكثر، أو يوصل لسعر تحدده بنفسك."
    )
    return "\n".join(lines)


ALERT_DROP_PERCENT = 8
WATCH_LIMIT = "وصلت للحد الأقصى من التنبيهات ({n}). احذف تنبيهًا من «تنبيهاتي» ثم أضف الجديد."
ALERTS_EMPTY = (
    "🔔 <b>تنبيهات الأسعار</b>\n"
    "ما عندك تنبيهات الحين.\n\n"
    "افتح أي وجهة واضغط «🔔 نبهني» وأنا أراقب السعر وأرسل لك رسالة لما ينزل."
)


def alerts_list(rows: list[tuple[data.Destination, object]], limit: int) -> str:
    lines = [f"🔔 <b>تنبيهاتي</b> ({len(rows)}/{limit})", "أراقب الأسعار وأرسل لك رسالة لما ينزل السعر.", ""]
    for i, (dest, w) in enumerate(rows, 1):
        lines.append(f"{i}. {dest.flag} <b>{escape(dest.ar)}</b> — {scope_label(w['scope'], w['stay'])}")
        bits = []
        if w["last_price"]:
            bits.append(f"💵 الحين {w['last_price']:,} ر.س")
        else:
            bits.append("💵 ما فيه سعر محفوظ بعد")
        if w["target"]:
            bits.append(f"🎯 الهدف {w['target']:,} ر.س")
        lines.append("    " + " • ".join(bits))
    lines.append("\n🎯 لتحديد سعر معين اضغط رقم التنبيه.")
    return "\n".join(lines)


def watch_detail(dest: data.Destination, w) -> str:
    lines = [
        f"🔔 <b>تنبيه {dest.flag} {escape(dest.ar)}</b>",
        f"📍 من {escape(ORIGIN_NAMES.get(w['origin'], w['origin']))}",
        f"📅 {scope_label(w['scope'], w['stay'])}",
    ]
    if w["last_price"]:
        lines.append(f"💵 آخر سعر: <b>{w['last_price']:,} ر.س</b>")
    lines.append(f"🎯 الهدف: <b>{w['target']:,} ر.س</b>" if w["target"] else f"🎯 بنبهك لما ينزل السعر {ALERT_DROP_PERCENT}% أو أكثر")
    return "\n".join(lines)


TARGET_PROMPT = "🎯 اكتب السعر اللي تبغاه بالريال (مثال: <b>900</b>) وأنبهك لما يوصل له أو ينزل عنه."
TARGET_TOO_HIGH = "السعر الحالي ({now:,} ر.س) أقل من هذا الرقم أصلًا 😉 اكتب سعرًا أقل من الحالي، مثل <b>{hint:,}</b>."
TARGET_BAD = "ما فهمت الرقم. اكتب السعر بالأرقام فقط، مثل <b>900</b>."


def target_set(dest: data.Destination, target: int) -> str:
    return f"🎯 تمام! بنبهك لما ينزل سعر {dest.flag} <b>{escape(dest.ar)}</b> إلى <b>{target:,} ر.س</b> أو أقل."


ALERT_HEADS = {
    "target": "🎯 <b>وصل لهدفك!</b>",
    "drop": "🔔 <b>نزل السعر!</b>",
    "first": "🆕 <b>ظهر سعر لرحلتك!</b>",
}


def alert_message(dest: data.Destination, w, offer: Offer, price: int, kind: str, before: int | None) -> str:
    lines = [
        ALERT_HEADS[kind],
        f"{dest.flag} <b>{escape(dest.ar)}</b> من {escape(ORIGIN_NAMES.get(w['origin'], w['origin']))}",
        f"📅 {when_text(offer, w['scope'].startswith('o:'))}",
    ]
    cheaper = f"💵 <b>{price:,} ر.س</b>"
    if before and before > price:
        cheaper += f" (كان {before:,} ر.س، نزل {round((1 - price / before) * 100)}%)"
    lines.append(cheaper)
    meta = flight_meta(offer)
    if meta:
        lines.append(f"🛫 {meta}")
    lines.append("")
    lines.append("⚠️ السعر وقت الفحص وقد يتغير بسرعة. الرابط يفتح البحث بأسعار اليوم.")
    return "\n".join(lines)


# ---- suggestions for misspelt words -------------------------------------------------------------------------
def suggest_text(options: list[data.Destination]) -> str:
    if len(options) == 1:
        return f"تقصد {options[0].flag} <b>{escape(options[0].ar)}</b>؟"
    return "تقصد أحد هذي الوجهات؟"


BUDGET_PROMPT = "اكتب ميزانيتك بالريال، مثل <b>4000</b>.\nوتقدر تضيف ذوقك: <b>بحر 4000</b> أو <b>هدوء 3000</b>."

ABOUT = (
    "<b>سفرتي</b> يساعدك تكتشف وجهات وتجد أسعار الطيران بسرعة.\n\n"
    "• أسعار الطيران تأتي من عمليات بحث حديثة لدى مزوّد الأسعار، وهي <b>وقت البحث</b> وقد تتغير عند الحجز.\n"
    "• تقييم السعر (ممتاز، عادي، مرتفع) مقارنة بأسعار الأيام القادمة لنفس المسار، وليس توقعًا للمستقبل.\n"
    "• التنبيهات تفحص الأسعار المحفوظة عدة مرات في اليوم، وقد لا تتوفر نفس التذكرة لحظة الحجز.\n"
    "• معلومات التأشيرة من مصادر عامة وتتغير، فتأكد دائمًا من السفارة أو الموقع الرسمي قبل الحجز.\n"
    "• تكلفة المعيشة تقدير عام للتصنيف فقط.\n\n" + DISCLOSURE
)

PRIVACY = (
    "<b>الخصوصية</b>\n"
    "نحفظ فقط: معرّف تيليجرام، ومدينة الانطلاق وإعداداتك، ووجهاتك المحفوظة، وتنبيهات الأسعار التي أنشأتها "
    "(المسار والتاريخ والسعر المستهدف)، وما عرضناه عليك من وجهات حتى لا نكررها، وعدّاد عمليات البحث اليومي.\n"
    "لا نطلب اسمك ولا رقم جوالك ولا أي بيانات دفع، ولا نشارك بياناتك مع أحد، ولا نحفظ نص رسائلك.\n"
    "الحجز يتم في موقع الشريك وليس داخل البوت."
)

PROFILE_DESCRIPTION = (
    "سفرتي ✈️ أرخص رحلات الطيران من مدينتك\n"
    "📆 تقويم أسعار يوضح لك أرخص يوم للسفر\n"
    "🔔 تنبيه لما ينزل سعر رحلتك\n"
    "🌙 رحلات الويكند وأرخص الوجهات الآن\n"
    "🛂 حالة التأشيرة للمواطن السعودي\n\n"
    "اكتب وجهتك مثل «دبي» أو «اسطنبول ديسمبر» وابدأ."
)
PROFILE_SHORT = "أرخص رحلات الطيران: تقويم أسعار وتنبيهات وويكند ✈️"

def same_city(name: str) -> str:
    return f"أنت تنطلق من {escape(name)} نفسها 🙂\nغيّر مدينة الانطلاق من الإعدادات، أو اكتب «من الرياض الى أبها» مثلًا."


UNKNOWN = (
    "ما فهمت قصدك 🤔\n"
    "اكتب وجهتك مثل <b>دبي</b> أو <b>دبي 15/12</b> أو <b>لندن ديسمبر</b>، أو اضغط «ابحث عن رحلة»."
)
THANKS_REPLY = "العفو 🌿 وش الوجهة الجاية؟"
LIMIT_REACHED = "وصلت للحد اليومي من عمليات البحث. عد غدًا وأكمل الاكتشاف 🌙"
BUSY = "تعذّر جلب الأسعار الآن. جرّب بعد قليل."
NOT_MESSAGE = "أرسل لي نصًا مثل اسم وجهة أو ميزانية، أو اضغط «فاجئني»."
ERROR = "حصل خطأ غير متوقع. جرّب مرة ثانية 🙏"
SAVED_EMPTY = "ما حفظت وجهات بعد. اضغط ❤️ تحت أي وجهة تعجبك."
SAVED_TOAST = "تم الحفظ ❤️"
UNSAVED_TOAST = "تمت الإزالة"
NO_RESULT = "ما لقيت وجهات مناسبة الآن. جرّب ميزانية أو ذوقًا آخر، أو اضغط «فاجئني»."
NO_RESULT_VISA = (
    "ما لقيت وجهات بدون تأشيرة تناسب طلبك الآن.\n"
    "يمكنك إيقاف فلتر «بدون تأشيرة فقط» من الإعدادات."
)
NOTE_RELAXED = "ℹ️ ما لقيت ما يطابق ذوقك تمامًا، فعرضت أقرب الخيارات."
NOTE_NO_LIVE = "⚠️ ما قدرت أجيب الأسعار الحية الآن، فهذه اقتراحات حسب مستوى التكلفة فقط."
NOTE_NO_PRICE = {
    "none": "✈️ ما عندي سعر محفوظ لهذا المسار. اضغط «حدّد التاريخ» وأعطيك رابط بحث مباشر يشمل الرحلات بتوقف.",
    "error": "✈️ تعذّر جلب السعر الآن، جرّب بعد قليل.",
    "off": "✈️ البحث عن الأسعار غير مفعّل بعد.",
}
ADMIN_OK = (
    "تم تفعيلك كمسؤول ✅\n"
    "الأوامر: /stats إحصائيات • /diag تشخيص • /market سوق الأسعار • /deals معاينة ونشر عروض القناة • /welcome منشور ترحيب القناة • /autopost النشر التلقائي • /backup نسخة احتياطية"
)
ADMIN_BAD = "الكود غير صحيح."
ADMIN_OFF = "هذا الأمر غير متاح."
ADMIN_ONLY = "هذا الأمر للمسؤول فقط."


def money(value: float, currency: str) -> str:
    amount = f"{round(value):,}"
    sym = CURRENCY_SYMBOL.get(currency, currency.upper())
    return f"${amount}" if currency == "usd" else f"{amount} {sym}"


def fmt_date(iso: str) -> str:
    try:
        day = int(iso[8:10])
        month = int(iso[5:7])
        return f"{day} {MONTHS[month - 1]}"
    except (ValueError, IndexError):
        return ""


def stops_text(n: int) -> str:
    if n <= 0:
        return "مباشرة"
    if n == 1:
        return "توقف واحد"
    if n == 2:
        return "توقفان"
    return f"{n} توقفات"


def visa_line(dest: data.Destination) -> str:
    info = data.visa_for(dest.cc)
    if info is None:
        return "⚠️ لا تتوفر لدي معلومة موثوقة، تأكد من السفارة"
    return VISA_SHORT[info.status]


def visa_ok(dest: data.Destination) -> bool:
    info = data.visa_for(dest.cc)
    return bool(info and info.status in NO_VISA_ISSUE)


def visa_mark(dest: data.Destination) -> str:
    info = data.visa_for(dest.cc)
    if info and info.status in NO_VISA_ISSUE:
        return "✅"
    if info and info.status == "required":
        return "🔴"
    return "🟡"


def visa_detail(dest: data.Destination) -> str:
    _, verified, _ = data.visa_table()
    y, m, d = verified.split("-")
    return (
        f"🛂 <b>التأشيرة إلى {escape(dest.country_ar)}</b> (للمواطن السعودي)\n"
        f"{visa_line(dest)}\n\n"
        f"آخر تحقق من المصادر: {int(d)}/{int(m)}/{y}\n"
        "المعلومة من مصادر عامة وقد تتغير، فتأكد من سفارة الدولة أو موقعها الرسمي قبل الحجز."
    )


def fit_line(dest: data.Destination) -> str:
    names = [TAG_NAMES[t] for t in dest.tags[:3] if t in TAG_NAMES]
    return ("✨ يناسب: " + " • ".join(names)) if names else ""


def offer_card(dest: data.Destination, offer: Offer | None, origin: str, state: str = "ok") -> str:
    country = "" if dest.ar == dest.country_ar else f" — {escape(dest.country_ar)}"
    lines = [f"🌍 <b>{dest.flag} {escape(dest.ar)}</b>{country}"]
    fit = fit_line(dest)
    if fit:
        lines.append(fit)
    origin_name = ORIGIN_NAMES.get(origin, origin)
    if offer:
        lines.append(f"✈️ ذهاب وعودة من {escape(origin_name)}: <b>من حوالي {money(offer.price, offer.currency)}</b>")
        dep, ret = fmt_date(offer.departure_at), fmt_date(offer.return_at)
        if dep and ret:
            lines.append(f"📅 {dep} ← {ret}")
        elif dep:
            lines.append(f"📅 {dep}")
        airline = AIRLINES.get(offer.airline.upper(), offer.airline)
        meta = " • ".join(x for x in (escape(airline), stops_text(offer.transfers)) if x)
        if meta:
            lines.append(f"🛫 {meta}")
    else:
        lines.append(NOTE_NO_PRICE.get(state, NOTE_NO_PRICE["none"]))
    lines.append(f"🛂 {visa_line(dest)}")
    lines.append(f"🏷 تكلفة المعيشة: {COST_TEXT.get(dest.cost, '')}")
    if offer:
        lines.append("⚠️ السعر وقت البحث وقد يتغير عند الحجز.")
    return "\n".join(lines)


LEGEND = "✅ بدون تأشيرة • 🟡 إلكترونية أو تحقق • 🔴 تأشيرة مسبقة"


def budget_list(
    budget: int,
    cap: float,
    ticket_only: bool,
    rows: list[tuple[data.Destination, Offer, float]],
    within: bool,
    origin: str,
) -> str:
    origin_name = ORIGIN_NAMES.get(origin, origin)
    head = [f"💰 <b>ميزانيتك {budget:,} ر.س</b> " + ("(للتذكرة فقط)" if ticket_only else "(للرحلة كلها)")]
    if within:
        if not ticket_only:
            head.append(f"اخترت تذاكر لا تتجاوز {round(cap):,} ر.س ليبقى لك ما يكفي للإقامة والمصاريف.")
    else:
        head.append("ما وجدت تذاكر ضمن هذا الحد الآن، وهذه أرخص ما وجدت:")
    head.append(f"من {escape(origin_name)} • ذهاب وعودة\n")
    body = [
        f"{i}. {dest.flag} <b>{escape(dest.ar)}</b> — من حوالي {round(sar):,} ر.س {visa_mark(dest)}"
        for i, (dest, _offer, sar) in enumerate(rows, 1)
    ]
    tail = f"\n\n{LEGEND}\nاضغط رقم الوجهة للتفاصيل ورابط الحجز."
    return "\n".join(head + body) + tail


def budget_tiers(budget: int, rows: list[data.Destination]) -> str:
    head = [f"💰 <b>ميزانيتك {budget:,} ر.س</b>", NOTE_NO_LIVE, ""]
    body = [
        f"{i}. {dest.flag} <b>{escape(dest.ar)}</b> — تكلفة {COST_TEXT.get(dest.cost, '')} {visa_mark(dest)}"
        for i, dest in enumerate(rows, 1)
    ]
    tail = f"\n\n{LEGEND}\nاضغط رقم الوجهة لمحاولة جلب السعر."
    return "\n".join(head + body) + tail


def choices(rows: list[tuple[data.Destination, float | None]], origin: str) -> str:
    countries = {d.country_ar for d, _ in rows}
    title = f"<b>{escape(next(iter(countries)))}</b>" if len(countries) == 1 else "<b>أكثر من وجهة</b>"
    origin_name = ORIGIN_NAMES.get(origin, origin)
    lines = [f"🌍 {title} — أي وجهة تقصد؟", f"الأسعار من {escape(origin_name)} • ذهاب وعودة\n"]
    for i, (dest, sar) in enumerate(rows, 1):
        price = f"من حوالي {round(sar):,} ر.س" if sar is not None else "السعر غير متوفر الآن"
        lines.append(f"{i}. {dest.flag} <b>{escape(dest.ar)}</b> — {price} {visa_mark(dest)}")
    lines.append(f"\n{LEGEND}")
    return "\n".join(lines)


def saved_list(rows: list[data.Destination]) -> str:
    lines = ["⭐ <b>وجهاتك المحفوظة</b>\n"]
    lines += [f"{i}. {d.flag} <b>{escape(d.ar)}</b> — {escape(d.country_ar)} {visa_mark(d)}" for i, d in enumerate(rows, 1)]
    lines.append("\nاضغط الرقم لرؤية السعر الحالي.")
    return "\n".join(lines)


def settings_text(origin: str, visa_only: bool) -> str:
    return (
        "⚙️ <b>الإعدادات</b>\n\n"
        f"📍 مدينة الانطلاق: <b>{escape(ORIGIN_NAMES.get(origin, origin))}</b>\n"
        f"🛂 بدون تأشيرة فقط: <b>{'مفعّل ✅' if visa_only else 'متوقف'}</b>\n\n"
        "غيّر مدينتك لتظهر لك أسعار الرحلات منها."
    )


def services_text(dest: data.Destination) -> str:
    return f"🧳 <b>خدمات تساعدك في رحلتك إلى {escape(dest.ar)}</b>\nاختر ما تحتاجه:\n\n{DISCLOSURE}"


def stats_text(stats: dict[str, int], popular: list[tuple[str, int]] | None = None, alerts_sent: str | None = "0") -> str:
    lines = [
        "📊 <b>إحصائيات سفرتي</b>",
        f"👥 المستخدمون: {stats['users']} (جدد آخر 24 ساعة: {stats.get('new_24h', 0)})",
        f"🟢 نشطون آخر 24 ساعة: {stats['active_24h']}",
        f"🔎 عمليات بحث اليوم: {stats['searches_today']}",
        f"⭐ وجهات محفوظة: {stats['saved']}",
        f"🔔 تنبيهات أسعار: {stats.get('watches', 0)} عند {stats.get('watchers', 0)} مستخدم • أُرسل {escape(str(alerts_sent or 0))} تنبيه",
    ]
    if popular:
        lines.append("")
        lines.append("🔥 الأكثر بحثًا:")
        lines += [f"{i}. {escape(label)} — {n}" for i, (label, n) in enumerate(popular, 1)]
    return "\n".join(lines)


# ---- channel and housekeeping -------------------------------------------------------------------------------
def channel_post(origin: str, rows: list[tuple[data.Destination, Offer, float]], edition: str) -> str:
    title = "🌙 <b>أرخص رحلات الويكند</b>" if edition == "weekend" else "🔥 <b>أرخص رحلات اليوم</b>"
    sub = f"من {escape(ORIGIN_NAMES.get(origin, origin))} • ذهاب وعودة"
    if edition == "weekend":
        sub += f"\n{WEEKEND_RULE}"
    lines = [title, sub, ""]
    for i, (dest, offer, price) in enumerate(rows, 1):
        lines.append(f"{i}. {dest.flag} <b>{escape(dest.ar)}</b> — من {round(price):,} ر.س {visa_mark(dest)}")
        when = when_text(offer)
        if when:
            lines.append(f"    📅 {when}")
    lines += [
        "",
        LEGEND,
        "ℹ️ الأسعار من عمليات بحث حديثة وقد تتغير عند الحجز. اضغط الوجهة لتفتح التفاصيل وتقويم الأسعار في البوت.",
        DISCLOSURE,
    ]
    return "\n".join(lines)


DEALS_NONE = "ما لقيت أسعارًا كافية لإعداد منشور الآن (أقل من 3 وجهات). جرّب بعد قليل."
DEALS_NO_DRAFT = "ما عندي منشور جاهز. أرسل /deals أولًا."
DEALS_POSTED = "✅ تم النشر في القناة."
WELCOME_POST = (
    "أهلًا بكم في <b>صائد العروض</b> ✈️🔥\n"
    "أرخص رحلات الطيران كل يوم، وزر حجز مباشر مع كل رحلة.\n\n"
    "⚠️ الأسعار تتغير بسرعة، والحجز يتم عبر المواقع الشريكة."
)
WELCOME_BUTTON = "✈️ ابحث عن رحلتك الآن"
WELCOME_NO_IMAGE = "ما قدرت أقرأ صورة الترحيب من ملفات البوت."
WELCOME_PREVIEW = "👆 هذي معاينة منشور الترحيب. اضغط الزر الأخير لنشره في القناة."
AUTOPOST_NO_CHANNEL = (
    "ما أقدر أنشر تلقائيًا لأن رابط القناة غير عام.\n"
    "اضبط CHANNEL_URL على رابط مثل https://t.me/اسم_القناة (بدون +) وشغّل البوت من جديد."
)
BACKUP_FAILED = "تعذّر إنشاء النسخة الاحتياطية."


def channel_failed(code: str) -> str:
    return (
        f"⚠️ تعذّر النشر في القناة (خطأ {escape(code)}).\n"
        "تأكد أن البوت مشرف في القناة وعنده صلاحية «نشر الرسائل». أوقفت النشر التلقائي إن كان مفعّلًا؛ "
        "فعّله بـ /autopost on بعد الإصلاح."
    )


def autopost_status(on: bool, channel: str | None, hour: int) -> str:
    where = escape(channel) if channel else "غير محددة"
    state = "مفعّل ✅" if on else "متوقف"
    return (
        f"📢 النشر التلقائي: <b>{state}</b>\n"
        f"القناة: {where}\n"
        f"ينشر مرة يوميًا بعد الساعة {hour}:00 بتوقيت السعودية (الخميس: رحلات الويكند).\n\n"
        "الأوامر: /autopost on • /autopost off • /deals (معاينة ونشر يدوي)"
    )


def backup_done(name: str, size: int) -> str:
    return f"✅ نسخة احتياطية: <code>{escape(name)}</code> ({max(1, size // 1024)} KB) داخل مجلد البيانات."


LINK_MISSING = {"marker": "رقم الشريك (TP_MARKER)", "trs": "رقم المشروع (TP_TRS)"}


def link_issue_text(issue: str) -> str:
    """The provider's short refusal of a partner link, put in words the admin can act on."""
    low = issue.lower()
    if "traffic source" in low:
        return "رقم المشروع غير صحيح. انسخه من قسم المشاريع في Travelpayouts"
    if "subscribed" in low:
        return "المشروع غير مشترك في برنامج Aviasales. فعّله من قسم البرامج في Travelpayouts"
    if "token" in low or "401" in low or "403" in low:
        return "رمز المزوّد مرفوض"
    return escape(issue) if issue else "السبب غير معروف"


def diag_text(report: dict, extras: list[tuple[str, bool | None]]) -> str:
    """The admin check. A line is ✅ working, ❌ broken, or ⚪ not set up (optional)."""

    def mark(ok: bool | None) -> str:
        return "⚪" if ok is None else ("✅" if ok else "❌")

    lines = ["🩺 <b>تشخيص</b>"]
    lines.append(f"{mark(report.get('token_set', False))} رمز مزوّد الأسعار")
    if report.get("links_api"):
        lines.append("✅ روابط الشريك")
    else:
        missing = [LINK_MISSING[k] for k in report.get("links_missing", []) if k in LINK_MISSING]
        if missing:
            lines.append("❌ روابط الشريك — ناقص: " + " و".join(missing))
            commands = [f"bash install.sh set {name}" for key, name in (("marker", "TP_MARKER"), ("trs", "TP_TRS")) if key in report["links_missing"]]
            lines.append("   ↳ على السيرفر: " + " ثم ".join(commands))
        else:
            lines.append("❌ روابط الشريك — تحتاج رمز مزوّد الأسعار أولًا")
    if report.get("token_set"):
        if "error" in report:
            lines.append(f"❌ البحث التجريبي: {escape(str(report['error']))}")
        else:
            count = report.get("offers", 0)
            lines.append(f"{mark(count > 0)} بحث تجريبي: {count} نتيجة")
            if report.get("cheapest"):
                lines.append(f"💵 أرخص نتيجة: {escape(str(report['cheapest']))}")
            lines.append(
                f"💱 العملة: {escape(str(report.get('currency', '')).upper())}"
                + (" (تحويل تلقائي)" if report.get("fallback") else "")
            )
            if "partner_link" in report:
                host = f" ({escape(str(report['partner_host']))})" if report.get("partner_host") else ""
                lines.append(f"{mark(report['partner_link'])} إنشاء رابط شريك{host}")
                if not report["partner_link"]:
                    lines.append("   ↳ " + link_issue_text(str(report.get("partner_issue") or "")))
    for label, ok in extras:
        lines.append(f"{mark(ok)} {escape(label)}")
    return "\n".join(lines)


# ---- the price market check (admin) ----------------------------------------------------------------
MARKET_WAIT = "⏳ أجرّب أسواق الأسعار على مسارات سعودية، قد يأخذ نصف دقيقة…"
MARKET_NONE = "ما قدرت أقرأ بيانات من المزوّد الآن. جرّب بعد قليل."
MARKET_USAGE = "الاستخدام: /market لاختبار الأسواق • /market us لاختيار سوق • /market auto للرجوع للتلقائي"


def market_name(code: str) -> str:
    return "تلقائي" if not code else escape(code)


def market_report(month: str, scores: dict[str, int | None], current: str, routes: int, recommend: str | None) -> str:
    known = {m: n for m, n in scores.items() if n is not None}
    top = max(known, key=lambda m: (known[m], m == current)) if known else None
    ranked = sorted(known.values(), reverse=True)
    clear_top = top is not None and (len(ranked) == 1 or ranked[0] > ranked[1])      # a tie has no winner
    lines = [
        "📊 <b>اختبار سوق الأسعار</b>",
        f"أيام السفر اللي يعرفها المزوّد لـ {routes} مسارات سعودية في {month_label(month)}:",
        "",
    ]
    for code, n in scores.items():
        value = "غير متاح" if n is None else str(n)
        star = " ⭐" if clear_top and code == top and known[code] > 0 and (code == recommend or code == current) else ""
        here = " ← الحالي" if code == current else ""
        lines.append(f"• {market_name(code)}: {value}{star}{here}")
    lines.append("")
    if top is None or known[top] == 0:
        lines.append("ما لقيت بيانات في أي سوق الآن.")
    elif recommend is not None:
        lines.append(
            f"الأغنى: <b>{market_name(recommend)}</b> ({known[recommend]} يوم مقابل {known.get(current, 0)}). "
            "اضغط الزر لتفعيله، وترجع للتلقائي متى شئت."
        )
    else:
        lines.append(f"السوق الحالي ({market_name(current)}) كافٍ، ما فيه سوق أغنى بشكل واضح.")
    return "\n".join(lines)


def market_changed(code: str) -> str:
    return f"✅ سوق الأسعار الآن: <b>{market_name(code)}</b>. الأسعار الجديدة تظهر مباشرة."


SERVICE_OFF = " — غير مفعّل في حسابك (اختياري)"
WEEKEND_PARTIAL = " — يكتمل الباقي في الخلفية"


def diag_market(code: str) -> str:
    return "سوق الأسعار: " + (code if code else "تلقائي — لو كانت الأسعار قليلة جرّب /market")
