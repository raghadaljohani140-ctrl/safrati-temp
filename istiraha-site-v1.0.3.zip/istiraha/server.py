"""A small, strict HTTP/1.1 server on asyncio (standard library only).

It faces the internet: it answers GET, HEAD and POST, closes every connection after one answer, and limits the size
and the time of everything. It never logs addresses, query strings or form contents."""
from __future__ import annotations

import asyncio
import contextlib
import email.utils
import gzip
import ipaddress
import logging
import re
import time
from dataclasses import dataclass, field
from typing import Awaitable, Callable
from urllib.parse import parse_qsl, quote, unquote_to_bytes, urlsplit

log = logging.getLogger("istiraha")

MAX_HEAD = 16 * 1024
MAX_HEADERS = 64
MAX_QUERY_FIELDS = 40
MAX_VALUE = 400
READ_TIMEOUT = 10.0
BODY_TIMEOUT = 60.0
WRITE_TIMEOUT = 20.0
HANDLER_TIMEOUT = 30.0
MAX_CONNECTIONS = 256
MAX_TRACKED_CLIENTS = 20000
GZIP_MIN = 1024
GZIP_TYPES = ("text/", "application/json", "application/xml", "image/svg+xml")
MAX_PARTS = 40

REASONS = {
    200: "OK", 204: "No Content", 302: "Found", 303: "See Other", 304: "Not Modified", 400: "Bad Request", 403: "Forbidden",
    404: "Not Found", 405: "Method Not Allowed", 408: "Request Timeout", 411: "Length Required", 413: "Payload Too Large",
    415: "Unsupported Media Type", 429: "Too Many Requests", 431: "Request Header Fields Too Large",
    500: "Internal Server Error", 504: "Gateway Timeout",
}

SECURITY_HEADERS = {
    "Content-Security-Policy": (
        "default-src 'none'; script-src 'self'; style-src 'self'; "
        "font-src 'self'; img-src 'self' data: blob:; connect-src 'self'; manifest-src 'self'; "
        "base-uri 'none'; form-action 'self'; frame-ancestors 'none'"
    ),
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "same-origin",
    "Permissions-Policy": "geolocation=(), camera=(self), microphone=(), payment=(), usb=()",      # the camera stays reachable for the phone's own "Take photo" choice when adding pictures
    "Cross-Origin-Opener-Policy": "same-origin",
    "Strict-Transport-Security": "max-age=15552000",
}

_REQUEST_LINE = re.compile(r"^([A-Z]{3,10}) (\S{1,2048}) HTTP/1\.[01]$")
_LOGGABLE_PATH = re.compile(r"^[A-Za-z0-9._/-]{1,60}$")
_HEADER_LINE = re.compile(r"^([!#$%&'*+.^_`|~0-9A-Za-z-]{1,60}):[ \t]*(.{0,4000}?)[ \t]*$")
_COOKIE_NAME = re.compile(r"^[A-Za-z0-9_]{1,40}$")


@dataclass
class Request:
    method: str
    path: str
    query: dict[str, str]
    headers: dict[str, str]
    ip: str = ""
    body: bytes = b""
    cookies: dict[str, str] = field(default_factory=dict)
    _form: tuple | None = field(default=None, repr=False)

    def query_list(self, name: str) -> list[str]:
        return self._query_pairs.get(name, [])

    _query_pairs: dict[str, list[str]] = field(default_factory=dict, repr=False)

    def form(self) -> tuple[dict[str, list[str]], list[tuple[str, str, bytes]]]:
        """(fields, files). Fields can repeat (checkboxes). Raises ValueError when the body cannot be read."""
        if self._form is None:
            ctype = self.headers.get("content-type", "")
            if ctype.startswith("application/x-www-form-urlencoded"):
                fields: dict[str, list[str]] = {}
                for k, v in parse_qsl(self.body.decode("utf-8", "replace"), keep_blank_values=True, max_num_fields=200):
                    fields.setdefault(k[:60], []).append(v[:20000])
                self._form = (fields, [])
            elif ctype.startswith("multipart/form-data"):
                self._form = parse_multipart(self.body, ctype)
            else:
                raise ValueError("unsupported content type")
        return self._form

    def field(self, name: str, default: str = "") -> str:
        values = self.form()[0].get(name)
        return values[0] if values else default


@dataclass
class Response:
    status: int = 200
    body: bytes = b""
    content_type: str = "text/html; charset=utf-8"
    headers: dict[str, str] = field(default_factory=dict)
    cookies: list[str] = field(default_factory=list)


Handler = Callable[[Request], Awaitable[Response]]


def text_response(status: int, message: str) -> Response:
    return Response(status, message.encode(), "text/plain; charset=utf-8", {"Cache-Control": "no-store"})


def redirect(location: str, cookies: list[str] | None = None) -> Response:
    safe = quote(location, safe="/?&=:%#+@;,-._~")           # a message in Arabic must travel as %XX in the header
    return Response(303, b"", headers={"Location": safe, "Cache-Control": "no-store"}, cookies=cookies or [])


def parse_multipart(body: bytes, content_type: str) -> tuple[dict[str, list[str]], list[tuple[str, str, bytes]]]:
    match = re.search(r'boundary="?([^";]{1,200})"?', content_type)
    if not match:
        raise ValueError("no boundary")
    delimiter = b"--" + match.group(1).encode()
    fields: dict[str, list[str]] = {}
    files: list[tuple[str, str, bytes]] = []
    pieces = body.split(delimiter)
    if len(pieces) > MAX_PARTS + 2:
        raise ValueError("too many parts")
    for piece in pieces[1:]:
        if piece.startswith(b"--"):
            break
        piece = piece[2:] if piece.startswith(b"\r\n") else piece
        head, sep, content = piece.partition(b"\r\n\r\n")
        if not sep:
            continue
        content = content[:-2] if content.endswith(b"\r\n") else content
        name = filename = None
        for line in head.decode("utf-8", "replace").split("\r\n"):
            if line.lower().startswith("content-disposition:"):
                m = re.search(r'\bname="([^"]{0,80})"', line)
                name = m.group(1) if m else None
                f = re.search(r'\bfilename="([^"]{0,300})"', line)
                filename = f.group(1) if f else None
        if name is None:
            continue
        if filename is not None:
            if content:
                files.append((name, filename, content))
        else:
            fields.setdefault(name, []).append(content.decode("utf-8", "replace")[:20000])
    return fields, files


def parse_cookies(header: str) -> dict[str, str]:
    jar: dict[str, str] = {}
    for part in header.split(";")[:30]:
        name, sep, value = part.strip().partition("=")
        if sep and _COOKIE_NAME.match(name) and name not in jar:
            jar[name] = value.strip()[:200]
    return jar


def cookie(name: str, value: str, *, max_age: int | None = None, secure: bool = False, path: str = "/") -> str:
    parts = [f"{name}={value}", f"Path={path}", "HttpOnly", "SameSite=Lax"]
    if max_age is not None:
        parts.append(f"Max-Age={max_age}")
    if secure:
        parts.append("Secure")
    return "; ".join(parts)


class RateLimiter:
    """A token bucket for each visitor, in memory, bounded."""

    def __init__(self, per_minute: float, burst: float, clock: Callable[[], float] = time.monotonic):
        self.rate, self.burst, self._clock = per_minute / 60.0, float(burst), clock
        self._buckets: dict[str, tuple[float, float]] = {}

    def take(self, key: str, cost: float = 1.0) -> float:
        now = self._clock()
        tokens, last = self._buckets.pop(key, (self.burst, now))
        tokens = min(self.burst, tokens + (now - last) * self.rate)
        if tokens >= cost:
            self._buckets[key] = (tokens - cost, now)
            wait = 0.0
        else:
            self._buckets[key] = (tokens, now)
            wait = (cost - tokens) / self.rate
        while len(self._buckets) > MAX_TRACKED_CLIENTS:
            self._buckets.pop(next(iter(self._buckets)))
        return wait


def client_key(ip: str) -> str:
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return ip[:64]
    if isinstance(addr, ipaddress.IPv6Address):
        if addr.ipv4_mapped:
            return str(addr.ipv4_mapped)
        return str(ipaddress.ip_network((addr, 64), strict=False))
    return str(addr)


def parse_head(head: bytes, peer: str, real_ip_header: str = "") -> Request | Response:
    lines = head.decode("latin-1").split("\r\n")
    match = _REQUEST_LINE.match(lines[0])
    if not match:
        return text_response(400, "طلب غير صحيح")
    method, target = match.group(1), match.group(2)
    headers: dict[str, str] = {}
    for line in lines[1:]:
        if not line:
            continue
        found = _HEADER_LINE.match(line)
        if not found or len(headers) >= MAX_HEADERS:
            return text_response(400, "طلب غير صحيح")
        headers.setdefault(found.group(1).lower(), found.group(2))
    if method not in ("GET", "HEAD", "POST"):
        return Response(405, b"method", "text/plain", {"Allow": "GET, HEAD, POST"})
    if not target.startswith("/") or target.startswith("//"):
        return text_response(400, "طلب غير صحيح")
    try:
        parts = urlsplit(target)
        pairs = parse_qsl(parts.query, keep_blank_values=True, max_num_fields=MAX_QUERY_FIELDS, encoding="utf-8", errors="replace")
        path = unquote_to_bytes(parts.path).decode("utf-8")
    except (ValueError, UnicodeDecodeError):
        return text_response(400, "طلب غير صحيح")
    if "\x00" in path or ".." in path.split("/"):
        return text_response(400, "طلب غير صحيح")
    multi: dict[str, list[str]] = {}
    for k, v in pairs:
        multi.setdefault(k[:40], []).append(v[:MAX_VALUE])
    query = {k: v[0] for k, v in multi.items()}
    ip = peer
    if real_ip_header and headers.get(real_ip_header):
        ip = headers[real_ip_header].split(",")[0].strip()[:64] or peer
    request = Request(method, path, query, headers, ip, cookies=parse_cookies(headers.get("cookie", "")))
    request._query_pairs = multi
    return request


class BodyTooLarge(Exception):
    pass


async def read_chunked(reader: asyncio.StreamReader, limit: int) -> bytes:
    """A request body sent in pieces ("Transfer-Encoding: chunked"), refused as soon as it passes the limit."""
    body = bytearray()
    while True:
        line = await reader.readuntil(b"\r\n")
        size_text = line[:-2].split(b";", 1)[0].strip()
        if not 1 <= len(size_text) <= 8 or not re.fullmatch(rb"[0-9A-Fa-f]+", size_text):
            raise ValueError("bad chunk size")
        size = int(size_text, 16)
        if size == 0:
            for _ in range(20):                                   # the optional trailer lines end with an empty line
                if await reader.readuntil(b"\r\n") == b"\r\n":
                    return bytes(body)
            raise ValueError("too many trailer lines")
        if len(body) + size > limit:
            raise BodyTooLarge()
        body += await reader.readexactly(size)
        if await reader.readexactly(2) != b"\r\n":
            raise ValueError("bad chunk end")


class WebServer:
    def __init__(
        self, handler: Handler, *, real_ip_header: str = "", per_minute: int = 240, post_per_minute: int = 60,
        body_limit: Callable[[str], int] = lambda path: 64 * 1024, clock: Callable[[], float] = time.monotonic,
    ):
        self._handler = handler
        self._real_ip_header = real_ip_header.lower()
        self._get_limit = RateLimiter(per_minute, burst=80, clock=clock)
        self._post_limit = RateLimiter(post_per_minute, burst=30, clock=clock)      # room for a dozen pictures sent one by one, then a few clicks
        self._body_limit = body_limit
        self._open = 0
        self._server: asyncio.AbstractServer | None = None
        self.stats = {"served": 0, "limited": 0, "errors": 0}

    async def start(self, host: str, port: int) -> int:
        self._server = await asyncio.start_server(self._client, host, port, limit=MAX_HEAD, backlog=128)
        return self.port

    @property
    def port(self) -> int:
        return self._server.sockets[0].getsockname()[1] if self._server and self._server.sockets else 0

    async def close(self) -> None:
        if self._server:
            self._server.close()
            await self._server.wait_closed()

    async def _client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        if self._open >= MAX_CONNECTIONS:
            writer.close()
            return
        self._open += 1
        try:
            await asyncio.wait_for(self._exchange(reader, writer), READ_TIMEOUT + BODY_TIMEOUT + HANDLER_TIMEOUT + WRITE_TIMEOUT)
        except (asyncio.TimeoutError, ConnectionError, asyncio.IncompleteReadError, OSError):
            pass
        except Exception:      # noqa: BLE001
            self.stats["errors"] += 1
            log.exception("unexpected error")
        finally:
            self._open -= 1
            writer.close()
            with contextlib.suppress(Exception):
                await asyncio.wait_for(writer.wait_closed(), 2)

    async def _exchange(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        started = time.monotonic()
        peer = (writer.get_extra_info("peername") or ("",))[0]
        try:
            head = await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), READ_TIMEOUT)
        except asyncio.LimitOverrunError:
            await self._send(writer, text_response(431, "الطلب كبير"), False)
            return
        parsed = parse_head(head, peer, self._real_ip_header)
        if isinstance(parsed, Response):
            await self._send(writer, parsed, False)
            return
        request = parsed
        limiter = self._post_limit if request.method == "POST" else self._get_limit
        wait = limiter.take(client_key(request.ip))
        if wait > 0:
            self.stats["limited"] += 1
            await self._send(writer, Response(429, "طلبات كثيرة، انتظر قليلًا ثم جرّب".encode(), "text/plain; charset=utf-8",
                                              {"Retry-After": str(int(wait) + 1)}), False)
            return
        if request.method == "POST":
            failure = await self._read_body(reader, request)
            if failure is not None:
                await self._send(writer, failure, False)
                return
        try:
            response = await asyncio.wait_for(self._handler(request), HANDLER_TIMEOUT)
        except asyncio.TimeoutError:
            response = text_response(504, "الخدمة بطيئة الآن، جرّب بعد قليل")
        except Exception:      # noqa: BLE001
            self.stats["errors"] += 1
            log.exception("handler failed")
            response = text_response(500, "حدث خطأ، جرّب بعد قليل")
        self.stats["served"] += 1
        await self._send(writer, response, request.method == "HEAD", "gzip" in request.headers.get("accept-encoding", "").lower())
        shown = request.path if _LOGGABLE_PATH.match(request.path) else "(other)"
        log.debug("%s %s %d %dms", request.method, shown, response.status, (time.monotonic() - started) * 1000)

    async def _read_body(self, reader: asyncio.StreamReader, request: Request) -> Response | None:
        limit = self._body_limit(request.path)
        coding = request.headers.get("transfer-encoding", "").strip().lower()
        if coding:
            # a tunnel or proxy may hand a large upload over in pieces; both a length and pieces together is never accepted
            if coding != "chunked" or "content-length" in request.headers:
                return text_response(400, "طلب غير صحيح")
            try:
                request.body = await asyncio.wait_for(read_chunked(reader, limit), BODY_TIMEOUT)
            except BodyTooLarge:
                return text_response(413, "الطلب أكبر من المسموح")
            except (asyncio.IncompleteReadError, asyncio.TimeoutError):
                return text_response(408, "انقطع الإرسال")
            except (ValueError, asyncio.LimitOverrunError):
                return text_response(400, "طلب غير صحيح")
            return None
        raw = request.headers.get("content-length", "")
        if not raw.isdigit() or len(raw) > 9:
            return text_response(411, "أرسل طول الطلب")
        length = int(raw)
        if length > limit:
            return text_response(413, "الطلب أكبر من المسموح")
        try:
            request.body = await asyncio.wait_for(reader.readexactly(length), BODY_TIMEOUT) if length else b""
        except (asyncio.IncompleteReadError, asyncio.TimeoutError):
            return text_response(408, "انقطع الإرسال")
        return None

    async def _send(self, writer: asyncio.StreamWriter, response: Response, head_only: bool, gzip_ok: bool = False) -> None:
        body, extra = response.body, {}
        if gzip_ok and response.status == 200 and len(body) >= GZIP_MIN and response.content_type.startswith(GZIP_TYPES):
            body, extra = gzip.compress(body, 5, mtime=0), {"Content-Encoding": "gzip"}
        headers = {
            **SECURITY_HEADERS, "Content-Type": response.content_type, "Content-Length": str(len(body)), "Connection": "close",
            "Date": email.utils.formatdate(usegmt=True), "Vary": "Accept-Encoding", **extra, **response.headers,
        }
        lines = [f"HTTP/1.1 {response.status} {REASONS.get(response.status, 'OK')}"]
        lines += [f"{k}: {v}" for k, v in headers.items() if "\r" not in v and "\n" not in v]
        lines += [f"Set-Cookie: {c}" for c in response.cookies if "\r" not in c and "\n" not in c]
        raw = ("\r\n".join(lines) + "\r\n\r\n").encode("latin-1", "replace")
        writer.write(raw if head_only or response.status == 304 else raw + body)
        await asyncio.wait_for(writer.drain(), WRITE_TIMEOUT)
