"""The container set-up as a whole: what each part can see, what it can reach, and that nothing is left open or shared."""
import json
import os
import re
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
COMPOSE = (ROOT / "docker-compose.yml").read_text(encoding="utf-8")
SETTINGS = (ROOT / "istiraha" / "settings.py").read_text(encoding="utf-8")
DOCKERFILE = (ROOT / "Dockerfile").read_text(encoding="utf-8")


def blocks(text: str) -> dict[str, str]:
    """The text of each service, found by indentation (the project allows only the standard library)."""
    found: dict[str, list[str]] = {}
    current, inside = None, False
    for line in text.splitlines():
        if re.match(r"^services:\s*$", line):
            inside = True
            continue
        if inside and re.match(r"^\S", line):
            inside = False
        if not inside:
            continue
        head = re.match(r"^  ([a-z][a-z0-9-]*):\s*$", line)
        if head:
            current = head.group(1)
            found[current] = []
        elif current:
            found[current].append(line)
    return {name: "\n".join(lines) for name, lines in found.items()}


SERVICES = blocks(COMPOSE)


def environment(block: str) -> dict[str, str]:
    lines = block.splitlines()
    start = lines.index("    environment:")
    out = {}
    for line in lines[start + 1:]:
        if not line.startswith("      "):
            break
        if line.strip().startswith("#"):
            continue
        key, _, value = line.strip().partition(":")
        out[key] = value.strip().strip('"')
    return out


class ShapeTests(unittest.TestCase):
    def test_the_parts_and_the_switches_that_turn_them_on(self):
        self.assertEqual(list(SERVICES), ["web", "tunnel", "tunnel-domain"])
        self.assertNotIn("profiles:", SERVICES["web"])              # the website is always on
        for name, profile in (("tunnel", "quick"), ("tunnel-domain", "domain")):
            self.assertIn(f'profiles: ["{profile}"]', SERVICES[name], name)

    def test_nothing_opens_a_port_or_reaches_into_the_machine(self):
        for name, block in SERVICES.items():
            for bad in ("ports:", "network_mode", "privileged", "docker.sock", "pid:", "ipc:", "devices:", "cap_add", "/etc", "/var", "/home", "/opt", "/root", "extra_hosts", "external"):
                self.assertNotIn(bad, block, f"{name}: {bad}")
        self.assertNotIn("ports:", COMPOSE)
        self.assertNotRegex(COMPOSE, r"(?m)^\s+- [./~][^\n]*:/")         # no folder of the machine is mounted anywhere
        self.assertNotIn("networks:", COMPOSE)                            # only the project's own default network

    def test_every_part_is_locked_down_and_limited(self):
        for name, block in SERVICES.items():
            self.assertIn("cap_drop:\n      - ALL", block, name)
            self.assertIn("no-new-privileges:true", block, name)
            self.assertRegex(block, r"mem_limit: \d+m", name)
            self.assertRegex(block, r"cpus: 0?\.\d+", name)
            self.assertRegex(block, r"pids_limit: \d+", name)
            self.assertIn("max-size", block, name)
            self.assertIn("restart: unless-stopped", block, name)
        self.assertIn("read_only: true", SERVICES["web"])
        self.assertIn("tmpfs:\n      - /tmp", SERVICES["web"])

    def test_the_website_cannot_starve_the_other_projects(self):
        self.assertRegex(SERVICES["web"], r"mem_limit: (128|192|256)m")
        self.assertRegex(SERVICES["web"], r"cpus: 0\.5")
        total = sum(int(m) for m in re.findall(r"mem_limit: (\d+)m", COMPOSE))
        self.assertLessEqual(total, 512)                                  # website + both tunnels, even if all ran

    def test_names_cannot_collide_with_other_projects(self):
        names = re.findall(r"container_name: (\S+)", COMPOSE)
        self.assertEqual(sorted(names), ["istiraha-domain", "istiraha-tunnel", "istiraha-web"])
        self.assertRegex(COMPOSE, r"(?m)^name: istiraha$")
        self.assertEqual(re.findall(r"(?m)^  (istiraha_data):$", COMPOSE), ["istiraha_data"])
        self.assertEqual(re.findall(r"- (\S+):/data", COMPOSE), ["istiraha_data"])
        for known in ("safrati", "aqar", "mazad", "auction", "property", "ticket"):
            self.assertNotIn(known, COMPOSE.lower(), known)

    def test_images(self):
        self.assertEqual(re.findall(r"image: (istiraha-site:local)", COMPOSE), ["istiraha-site:local"])
        tunnels = re.findall(r"image: (cloudflare/cloudflared:\S+)", COMPOSE)
        self.assertEqual(len(tunnels), 2)
        self.assertEqual(len(set(tunnels)), 1)
        self.assertRegex(tunnels[0], r"^cloudflare/cloudflared:20\d\d\.\d{1,2}\.\d{1,2}$")       # a fixed version, never "latest"

    def test_the_docker_image_carries_only_the_package(self):
        self.assertEqual(re.findall(r"(?m)^COPY .*$", DOCKERFILE), ["COPY istiraha/ /app/istiraha/"])
        self.assertIn("USER istiraha", DOCKERFILE)
        self.assertNotRegex(DOCKERFILE, r"(?m)^(RUN pip|RUN apt|ADD )")
        self.assertIn("FROM python:3.12-slim", DOCKERFILE)

    def test_the_website_runs_with_the_standard_library_only(self):
        imports = set()
        for path in (ROOT / "istiraha").glob("*.py"):
            imports |= set(re.findall(r"(?m)^\s*(?:import|from)\s+([A-Za-z_][A-Za-z0-9_]*)", path.read_text(encoding="utf-8")))
        import sys
        stdlib = set(sys.stdlib_module_names) | {"istiraha"}
        self.assertEqual(sorted(imports - stdlib - {"tests"}), [])


class SecretsAndPortsTests(unittest.TestCase):
    def test_the_website_holds_no_secret(self):
        example = (ROOT / ".env.example").read_text(encoding="utf-8")
        keys = re.findall(r"(?m)^([A-Z_]+)=", example)
        self.assertTrue(keys)
        for key in keys:
            self.assertNotRegex(key, r"TOKEN|KEY|SECRET|PASS|CODE", key)
        self.assertNotIn("TUNNEL_TOKEN=", example)            # the tunnel token never lives in the website's settings file

    def test_the_settings_file_is_read_by_the_website_only(self):
        self.assertEqual(re.findall(r"env_file: (\S+)", COMPOSE), [".env", ".tunnel.env"])
        self.assertIn("env_file: .env\n", SERVICES["web"])
        self.assertIn("env_file: .tunnel.env", SERVICES["tunnel-domain"])
        self.assertNotIn("env_file", SERVICES["tunnel"])
        for name in (".dockerignore", ".gitignore"):
            lines = (ROOT / name).read_text(encoding="utf-8").splitlines()
            for private in (".env", ".tunnel.env", ".state", "backups" if name == ".dockerignore" else "backups/"):
                self.assertIn(private, lines, f"{name}: {private}")

    def test_every_setting_that_is_passed_in_is_one_the_website_reads(self):
        read = set(re.findall(r'env\.get\("([A-Z_]+)"\)', SETTINGS)) | set(re.findall(r'_int\(env, "([A-Z_]+)"', SETTINGS))
        passed = set(environment(SERVICES["web"])) - {"TZ"}
        example = set(re.findall(r"(?m)^([A-Z_]+)=", (ROOT / ".env.example").read_text(encoding="utf-8")))
        self.assertEqual(sorted(passed - read), [])
        self.assertEqual(sorted(example - read), [])

    def test_the_tunnels_only_talk_to_the_website_on_its_port(self):
        port = environment(SERVICES["web"])["PORT"]
        self.assertEqual(port, "8090")
        self.assertIn("8090", SETTINGS)
        self.assertIn(f'"http://web:{port}"', SERVICES["tunnel"])
        for name in ("tunnel", "tunnel-domain"):
            self.assertIn("depends_on:\n      - web", SERVICES[name], name)
            self.assertIn('"--no-autoupdate"', SERVICES[name], name)
        self.assertIn(f"web:{port}", (ROOT / "web.sh").read_text(encoding="utf-8"))

    def test_the_visitor_address_header_is_trusted_only_because_the_tunnel_is_the_only_way_in(self):
        self.assertEqual(environment(SERVICES["web"])["REAL_IP_HEADER"], "CF-Connecting-IP")
        self.assertNotIn("ports:", COMPOSE)

    def test_the_health_check_runs_the_real_program(self):
        self.assertIn('["CMD", "python", "-m", "istiraha", "check"]', SERVICES["web"])
        self.assertIn('"check"', (ROOT / "istiraha" / "__main__.py").read_text(encoding="utf-8"))


@unittest.skipUnless(shutil.which("docker"), "docker is not installed here")
class DockerReadsItTests(unittest.TestCase):
    """If a docker program is on this machine (no running engine needed), let it read the file the way the server will."""

    def config(self, *profiles):
        with tempfile.TemporaryDirectory() as tmp:
            shutil.copy(ROOT / "docker-compose.yml", tmp)
            for name in (".env", ".tunnel.env"):
                Path(tmp, name).write_text("")
            args = ["docker", "compose", "-p", "istiraha"]
            for p in profiles:
                args += ["--profile", p]
            run = subprocess.run(args + ["config", "--format", "json"], cwd=tmp, capture_output=True, text=True, timeout=60)
        if run.returncode != 0:
            self.skipTest(f"docker compose cannot read the file here: {run.stderr[:200]}")
        return json.loads(run.stdout)

    def test_the_project_has_its_own_name_network_and_volume(self):
        cfg = self.config("quick", "domain")
        self.assertEqual(cfg["name"], "istiraha")
        self.assertEqual(sorted(cfg["services"]), ["tunnel", "tunnel-domain", "web"])
        self.assertEqual(list(cfg["volumes"]), ["istiraha_data"])
        self.assertEqual(cfg["volumes"]["istiraha_data"]["name"], "istiraha_istiraha_data")
        for name, service in cfg["services"].items():
            self.assertNotIn("ports", service, name)
            self.assertNotIn("network_mode", service, name)
            self.assertTrue(service["container_name"].startswith("istiraha-"), name)
        self.assertEqual(list(cfg.get("networks", {"default": {}})), ["default"])
        self.assertEqual(cfg["networks"]["default"]["name"], "istiraha_default")

    def test_without_a_profile_only_the_website_starts(self):
        self.assertEqual(sorted(self.config()["services"]), ["web"])
        self.assertEqual(sorted(self.config("quick")["services"]), ["tunnel", "web"])
        self.assertEqual(sorted(self.config("domain")["services"]), ["tunnel-domain", "web"])


if __name__ == "__main__":
    unittest.main()
