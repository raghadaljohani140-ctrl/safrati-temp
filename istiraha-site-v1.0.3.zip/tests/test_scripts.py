"""Runs install.sh / admin.sh / web.sh / status.sh / backup.sh / restore.sh / uninstall.sh against fake docker and curl programs.

The real scripts only work inside /opt/istiraha-site, so the tests copy them to a temporary folder and change only the
folder name. The guard itself is tested on the untouched copy. The fake docker refuses any call that is not about the
project "istiraha", so a script that reached for anything else would fail here.
"""
import os
import re
import shutil
import stat
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = ("install.sh", "admin.sh", "web.sh", "status.sh", "backup.sh", "restore.sh", "uninstall.sh")

FAKE_DOCKER = r"""#!/usr/bin/env bash
echo "docker $*" >> "$FAKE_LOG"
state="$FAKE_STATE"
if [ "$1" = info ]; then [ "${FAKE_NO_DOCKER:-0}" = 1 ] && exit 1; exit 0; fi
if [ "$1 $2" = "compose version" ]; then echo "Docker Compose version v2.0.0"; exit 0; fi

# name lookups: a file in the state folder says "this container/volume/network exists and belongs to project X"
label_of() { # kind name -> prints the project, exit 1 if it does not exist
  [ -f "$state/exists_$1_$2" ] || return 1
  cat "$state/exists_$1_$2"
}
if [ "$1" = inspect ]; then
  if [ "$2" = "-f" ]; then
    case "$3" in
      *State.Running*) if [ "${FAKE_WEB_RUNNING:-1}" = 1 ]; then echo true; else echo false; fi; exit 0 ;;
      *Health.Status*) echo healthy; exit 0 ;;
      *Labels*) label_of container "$4"; exit $? ;;
    esac
  fi
  label_of container "$2" >/dev/null; exit $?
fi
if [ "$1" = volume ] && [ "$2" = inspect ]; then
  if [ "$3" = "-f" ]; then label_of volume "$5"; exit $?; fi
  label_of volume "$3" >/dev/null; exit $?
fi
if [ "$1" = network ] && [ "$2" = inspect ]; then
  if [ "$3" = "-f" ]; then label_of network "$5"; exit $?; fi
  label_of network "$3" >/dev/null; exit $?
fi
if [ "$1" = ps ]; then
  echo "    aqar-app  (Up 3 days)"; echo "    safrati-bot  (Up 2 days)"
  [ -f "$state/web_listed" ] && echo "    istiraha-web  (Up 1 minute)"
  exit 0
fi
if [ "$1" = logs ]; then
  target="${@: -1}"
  case "$target" in
    istiraha-web)
      [ "${FAKE_NO_START:-0}" = 1 ] || echo "2026-10-27 INFO istiraha: website started on port 8090 (version 1.0.0)"
      [ "${FAKE_BIG_LOGS:-0}" = 1 ] && for i in $(seq 1 20000); do echo "filler log line number $i to make the output large"; done ;;
    istiraha-tunnel)
      echo "INF Requesting new quick Tunnel on trycloudflare.com..."
      echo "ERR failed to request quick Tunnel: Post \"https://api.trycloudflare.com/tunnel\": EOF"
      [ "${FAKE_NO_URL:-0}" = 1 ] || echo "INF |  https://quiet-river-1234.trycloudflare.com  |" ;;
    istiraha-domain)
      if [ "${FAKE_BAD_TUNNEL:-0}" = 1 ]; then echo "ERR Provided Tunnel token is not valid."; else echo "INF Registered tunnel connection connIndex=0"; fi ;;
    *) echo "WRONG CONTAINER $target" >&2; exit 9 ;;
  esac
  exit 0
fi
if [ "$1" = compose ] && [ "$2" = "-p" ]; then
  [ "$3" = "istiraha" ] || { echo "WRONG PROJECT $3" >&2; exit 9; }
  shift 3
  while [ "$1" = "--profile" ]; do
    case "$2" in quick|domain) ;; *) echo "UNKNOWN PROFILE $2" >&2; exit 9 ;; esac
    shift 2
  done
  case "$1" in
    ps) echo "NAME  STATUS"; echo "istiraha-web  running" ;;
    up)
      if [ "${FAKE_BUILD_FAIL:-0}" = 1 ]; then echo "build failed" >&2; exit 1; fi
      touch "$state/web_listed" ;;
    down|rm|stop) ;;
    run) cat > "$state/restored.tar.gz"; [ "${FAKE_IMPORT_FAIL:-0}" = 1 ] && exit 1 ;;
    *) echo "UNEXPECTED compose command: $*" >&2; exit 9 ;;
  esac
  exit 0
fi
if [ "$1" = exec ]; then
  shift
  while [[ "$1" == -* ]]; do shift; done
  [ "$1" = istiraha-web ] || { echo "WRONG CONTAINER $1" >&2; exit 9; }
  shift
  case "$*" in
    "python -m istiraha create-admin") echo "(admin created)"; exit 0 ;;
    "python -m istiraha export")
      [ "${FAKE_EXPORT_FAIL:-0}" = 1 ] && exit 1
      if [ "${FAKE_EXPORT_BAD:-0}" = 1 ]; then echo "this is not an archive"; exit 0; fi
      d="$(mktemp -d)"; echo "database" > "$d/istiraha.db"; tar -czf - -C "$d" istiraha.db; rm -rf "$d"; exit 0 ;;
    sh*) printf '1.2M\t/data\n'; exit 0 ;;
    *) echo "UNEXPECTED exec: $*" >&2; exit 9 ;;
  esac
fi
if [ "$1" = rmi ]; then
  [ "$2" = "istiraha-site:local" ] || { echo "WRONG IMAGE $2" >&2; exit 9; }
  exit 0
fi
echo "UNEXPECTED docker call: $*" >&2
exit 9
"""

FAKE_CURL = r"""#!/usr/bin/env bash
cfg="$(cat)"
echo "curl $*" >> "$FAKE_LOG"
case "$cfg" in
  *trycloudflare.com/healthz*|*istirahati.example/healthz*) [ "${FAKE_PUBLIC:-1}" = 0 ] || printf ok ;;
esac
"""

FAKE_DF = r"""#!/usr/bin/env bash
echo "Filesystem 1048576-blocks Used Available Capacity Mounted on"
echo "/dev/vda1 100000 1000 ${FAKE_DISK_MB:-50000} 1% /"
"""

QUICK_URL = "https://quiet-river-1234.trycloudflare.com"
TOKEN = "eyJhIjoi" + "QWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo" * 4 + "=="           # shaped like a tunnel token, obviously fake
EVERYTHING = "docker compose -p istiraha --profile quick --profile domain"


class ScriptCase(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.app = self.tmp / "app"
        self.app.mkdir()
        self.bin = self.tmp / "bin"
        self.bin.mkdir()
        self.state = self.tmp / "state"
        self.state.mkdir()
        self.log = self.tmp / "calls.log"
        self.log.write_text("")
        self.meminfo = self.tmp / "meminfo"
        self.set_memory(2_000_000)
        for name, body in (("docker", FAKE_DOCKER), ("curl", FAKE_CURL), ("df", FAKE_DF), ("sleep", "#!/bin/sh\nexit 0\n")):
            path = self.bin / name
            path.write_text(body)
            path.chmod(path.stat().st_mode | stat.S_IEXEC)
        shutil.copy(ROOT / ".env.example", self.app / ".env.example")
        for name in SCRIPTS:
            text = (ROOT / name).read_text()
            text = text.replace('APP_DIR="/opt/istiraha-site"', f'APP_DIR="{self.app}"')
            text = text.replace('= "/opt/istiraha-site" ]', f'= "{self.app}" ]').replace("cd /opt/istiraha-site", f"cd {self.app}")
            text = text.replace("/opt/istiraha-site/", f"{self.app}/")
            (self.app / name).write_text(text)

    def run_script(self, args, stdin="", env_extra=None, cwd=None):
        env = dict(os.environ)
        env.update({"PATH": f"{self.bin}:{env['PATH']}", "FAKE_LOG": str(self.log), "FAKE_STATE": str(self.state),
                    "ISTIRAHA_MEMINFO": str(self.meminfo)})
        env.update(env_extra or {})
        return subprocess.run(["bash", *args], input=stdin, capture_output=True, text=True, env=env, cwd=cwd or self.app, timeout=60)

    def set_memory(self, kb: int) -> None:
        self.meminfo.write_text(f"MemTotal:        4000000 kB\nMemFree:          100000 kB\nMemAvailable:   {kb:>8} kB\n")

    def calls(self) -> list[str]:
        return self.log.read_text().splitlines()

    def docker_calls(self) -> list[str]:
        return [c for c in self.calls() if c.startswith("docker")]

    def mark_existing(self, kind: str, name: str, project: str) -> None:
        (self.state / f"exists_{kind}_{name}").write_text(project + "\n")

    def env(self) -> dict:
        return dict(line.split("=", 1) for line in (self.app / ".env").read_text().splitlines() if "=" in line)

    def install(self, **kw):
        return self.run_script(["install.sh"], stdin=kw.pop("stdin", "y\n"), **kw)


class PinnedToThisProjectTests(unittest.TestCase):
    def test_the_real_scripts_are_pinned_to_the_site_folder_and_project(self):
        for name in SCRIPTS:
            text = (ROOT / name).read_text()
            self.assertIn("/opt/istiraha-site", text, name)
            for call in re.findall(r"docker compose[^\n]*", text):
                if call.startswith("docker compose version"):
                    continue
                self.assertTrue("-p istiraha" in call or '-p "$PROJECT"' in call, f"{name}: {call}")
        self.assertIn('PROJECT="istiraha"', (ROOT / "install.sh").read_text())
        self.assertIn('PROJECT="istiraha"', (ROOT / "web.sh").read_text())

    def test_no_script_can_touch_anything_that_is_not_this_project(self):
        for name in SCRIPTS:
            text = (ROOT / name).read_text()
            for bad in ("prune", "docker system", "docker kill", "docker restart", "docker network rm", "docker volume rm", "--rmi", "docker rm ", "docker stop", "docker start", "pkill", "killall", "systemctl", "ufw", "iptables", "crontab", "/etc/", "chmod -R", "chown", "sudo", "rm -rf"):
                self.assertNotIn(bad, text, f"{name}: {bad}")
            for container in re.findall(r"docker (?:exec|logs|inspect)[^\n]*", text):
                for word in re.findall(r"\b([a-z]+-[a-z]+)\b", container):
                    if word.startswith(("istiraha", "docker-")):
                        continue
                    self.assertNotRegex(word, r"^(aqar|mazad|safrati|auction|property)", f"{name}: {container}")
            for rmi in re.findall(r"docker rmi \S+", text):
                self.assertEqual(rmi, "docker rmi istiraha-site:local", name)

    def test_every_script_refuses_to_run_outside_the_site_folder_and_changes_nothing(self):
        tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, tmp, True)
        for name in SCRIPTS:
            other = tmp / name.replace(".", "_")
            other.mkdir()
            shutil.copy(ROOT / name, other / name)
            result = subprocess.run(["bash", str(other / name)], input="", capture_output=True, text=True, cwd=other, timeout=30,
                                    env={**os.environ, "PATH": "/nonexistent:" + os.environ["PATH"]})
            self.assertNotEqual(result.returncode, 0, name)
            self.assertIn("/opt/istiraha-site", result.stderr, name)
            self.assertEqual(sorted(p.name for p in other.iterdir()), [name], name)


class InstallTests(ScriptCase):
    def test_first_install_creates_a_private_env_and_starts_only_this_project(self):
        result = self.install()
        out = result.stdout + result.stderr
        self.assertEqual(result.returncode, 0, out)
        env_file = self.app / ".env"
        self.assertEqual(stat.S_IMODE(env_file.stat().st_mode), 0o600)
        values = self.env()
        self.assertEqual((values["SITE_NAME"], values["SITE_URL"], values["COOKIE_SECURE"]), ("استراحتي", "", "1"))
        self.assertEqual(stat.S_IMODE((self.app / "backups").stat().st_mode), 0o700)
        self.assertIn("website started on port 8090", out)
        self.assertIn("bash admin.sh", out)
        self.assertIn("bash web.sh quick", out)
        calls = self.docker_calls()
        self.assertIn("docker compose -p istiraha up -d --build web", calls)
        for call in calls:
            self.assertTrue(call.startswith(("docker compose version", "docker compose -p istiraha ", "docker logs istiraha-web", "docker info", "docker inspect", "docker volume inspect", "docker network inspect", "docker ps -a")), call)
            self.assertNotIn("--profile", call)             # the public link is off until web.sh switches it on
        self.assertFalse((self.app / ".state").exists())
        self.assertEqual([p.name for p in self.app.iterdir() if p.name.startswith(".env.") and p.name != ".env.example"], [])

    def test_it_lists_the_other_projects_without_touching_them(self):
        result = self.install()
        self.assertIn("aqar-app", result.stdout)
        self.assertIn("safrati-bot", result.stdout)
        self.assertIn("they will not be touched", result.stdout)
        for call in self.docker_calls():
            if call.startswith("docker compose -p"):
                self.assertIn("-p istiraha", call)

    def test_the_wrong_server_answer_cancels_before_anything_is_saved_or_started(self):
        for reply in ("n\n", "\n", "no\n"):
            result = self.run_script(["install.sh"], stdin=reply)
            self.assertNotEqual(result.returncode, 0, reply)
            self.assertIn("This server is:", result.stdout)
            self.assertIn("cancelled", result.stderr)
            self.assertFalse((self.app / ".env").exists())
            self.assertEqual([c for c in self.docker_calls() if not c.startswith(("docker compose version", "docker info"))], [], reply)
        closed = self.run_script(["install.sh"], stdin="")
        self.assertNotEqual(closed.returncode, 0)
        self.assertFalse((self.app / ".env").exists())

    def test_a_second_run_updates_and_keeps_everything(self):
        self.install()
        (self.app / "backups" / "istiraha-20261027-101500.tar.gz").write_bytes(b"keep me")
        (self.app / ".env").write_text((self.app / ".env").read_text().replace("SITE_NAME=استراحتي", "SITE_NAME=ركن الاستراحات"))
        before = (self.app / ".env").read_text()
        result = self.run_script(["install.sh"], stdin="")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual((self.app / ".env").read_text(), before)
        self.assertEqual((self.app / "backups" / "istiraha-20261027-101500.tar.gz").read_bytes(), b"keep me")
        self.assertIn("Keeping your existing settings", result.stdout)
        self.assertIn("Updated. Your data, settings and backups were kept.", result.stdout)
        self.assertNotIn("Next steps", result.stdout)

    def test_it_stops_before_anything_if_a_name_belongs_to_another_project(self):
        for kind, name in (("container", "istiraha-web"), ("container", "istiraha-tunnel"), ("container", "istiraha-domain"),
                           ("volume", "istiraha_istiraha_data"), ("network", "istiraha_default")):
            with self.subTest(kind=kind, name=name):
                for f in self.state.iterdir():
                    f.unlink()
                self.log.write_text("")
                self.mark_existing(kind, name, "aqar")
                result = self.run_script(["install.sh"], stdin="y\n")
                self.assertNotEqual(result.returncode, 0)
                self.assertIn(f"'{name}' already exists and does not belong to this project", result.stderr)
                self.assertIn("aqar", result.stderr)
                self.assertFalse((self.app / ".env").exists())
                self.assertEqual([c for c in self.docker_calls() if " up " in c or " build" in c], [])

    def test_a_name_that_belongs_to_this_project_is_fine(self):
        self.mark_existing("container", "istiraha-web", "istiraha")
        self.mark_existing("volume", "istiraha_istiraha_data", "istiraha")
        result = self.run_script(["install.sh"], stdin="y\n")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_it_does_not_start_on_a_server_that_is_short_of_memory_or_disk(self):
        self.set_memory(250 * 1024)
        result = self.run_script(["install.sh"], stdin="y\n")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("only 250 MB of memory is free", result.stderr)
        self.assertIn("Nothing was changed", result.stderr)
        self.assertFalse((self.app / ".env").exists())
        self.assertEqual([c for c in self.docker_calls() if " up " in c], [])
        self.set_memory(2_000_000)
        result = self.run_script(["install.sh"], stdin="y\n", env_extra={"FAKE_DISK_MB": "500"})
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("only 500 MB of disk is free", result.stderr)
        self.assertEqual([c for c in self.docker_calls() if " up " in c], [])

    def test_a_running_website_is_never_blocked_by_low_memory_when_it_is_updated(self):
        self.install()
        self.mark_existing("container", "istiraha-web", "istiraha")
        self.set_memory(100 * 1024)                 # low, but the website is what is using it
        result = self.run_script(["install.sh"], stdin="")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_it_needs_docker_to_be_usable(self):
        result = self.run_script(["install.sh"], stdin="y\n", env_extra={"FAKE_NO_DOCKER": "1"})
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("docker is not running", result.stderr)
        self.assertFalse((self.app / ".env").exists())

    def test_start_detection_survives_very_long_logs(self):
        result = self.install(env_extra={"FAKE_BIG_LOGS": "1"})
        self.assertEqual(result.returncode, 0, result.stdout[-500:] + result.stderr[-500:])
        self.assertIn("The website is running", result.stdout)

    def test_a_website_that_does_not_start_is_reported(self):
        result = self.install(env_extra={"FAKE_NO_START": "1"})
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("did not report that it started", result.stdout)

    def test_set_site_name(self):
        self.install()
        self.log.write_text("")
        result = self.run_script(["install.sh", "set", "SITE_NAME"], stdin="  ركن الاستراحات  \n")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        text = (self.app / ".env").read_text()
        self.assertIn("SITE_NAME=ركن الاستراحات\n", text)
        self.assertEqual(text.count("SITE_NAME="), 1)
        self.assertIn("COOKIE_SECURE=1", text)
        self.assertIn("docker compose -p istiraha up -d --force-recreate web", self.calls())
        self.assertEqual(stat.S_IMODE((self.app / ".env").stat().st_mode), 0o600)

    def test_set_refuses_other_names_and_unsafe_values(self):
        self.install()
        before = (self.app / ".env").read_text()
        for args, stdin in ((["set", "SITE_URL"], "https://x.example\n"), (["set", "COOKIE_SECURE"], "0\n"), (["set"], ""),
                            (["set", "SITE_NAME"], "a\n"), (["set", "SITE_NAME"], "<script>x</script>\n"), (["set", "SITE_NAME"], 'say "hi"\n'),
                            (["set", "SITE_NAME"], "x" * 200 + "\n"), (["bogus"], "")):
            result = self.run_script(["install.sh", *args], stdin=stdin)
            self.assertNotEqual(result.returncode, 0, args)
            self.assertEqual((self.app / ".env").read_text(), before, args)


class DailyScriptsTests(ScriptCase):
    def setUp(self):
        super().setUp()
        self.assertEqual(self.install().returncode, 0)
        self.log.write_text("")

    def test_admin_runs_the_command_inside_the_website_container_only(self):
        result = self.run_script(["admin.sh"])
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(self.docker_calls()[-1], "docker exec -it istiraha-web python -m istiraha create-admin")
        self.assertNotIn("TOKEN", result.stdout)

    def test_admin_needs_a_running_website(self):
        result = self.run_script(["admin.sh"], env_extra={"FAKE_WEB_RUNNING": "0"})
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("bash install.sh", result.stderr)
        self.assertFalse([c for c in self.docker_calls() if c.startswith("docker exec")])

    def test_status_is_read_only_and_only_about_this_project(self):
        result = self.run_script(["status.sh"])
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("healthy", result.stdout)
        self.assertIn("website started on port", result.stdout)
        self.assertIn("/data", result.stdout)
        for call in self.docker_calls():
            self.assertRegex(call, r"^docker (compose version|compose -p istiraha|inspect|logs --tail \d+ istiraha-web|exec istiraha-web sh -c)")
            self.assertNotRegex(call, r" (up|down|rm|stop|run) ")

    def test_uninstall_removes_only_this_project_and_keeps_the_data_by_default(self):
        self.assertEqual(self.run_script(["uninstall.sh"]).returncode, 0)
        self.assertIn(f"{EVERYTHING} down", self.calls())
        self.assertNotIn("--volumes", " ".join(self.calls()))
        self.assertNotEqual(self.run_script(["uninstall.sh", "--everything"]).returncode, 0)
        for call in self.calls():
            self.assertNotIn("prune", call)
            self.assertNotIn("--rmi", call)             # the public cloudflared image may belong to other projects

    def test_purge_asks_for_the_word_DELETE_first(self):
        for answer in ("", "no\n", "delete\n", "YES\n"):
            self.log.write_text("")
            result = self.run_script(["uninstall.sh", "--purge"], stdin=answer)
            self.assertNotEqual(result.returncode, 0, repr(answer))
            self.assertNotIn("--volumes", " ".join(self.calls()), repr(answer))
        self.log.write_text("")
        result = self.run_script(["uninstall.sh", "--purge"], stdin="DELETE\n")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn(f"{EVERYTHING} down --volumes", self.calls())
        self.assertIn("docker rmi istiraha-site:local", self.calls())


class BackupScriptsTests(ScriptCase):
    def setUp(self):
        super().setUp()
        self.assertEqual(self.install().returncode, 0)
        self.log.write_text("")

    def backups(self):
        return sorted(p.name for p in (self.app / "backups").iterdir())

    def test_backup_saves_one_private_file_and_leaves_no_leftovers(self):
        result = self.run_script(["backup.sh"])
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        files = self.backups()
        self.assertEqual(len(files), 1)
        self.assertRegex(files[0], r"^istiraha-\d{8}-\d{6}\.tar\.gz$")
        self.assertEqual(stat.S_IMODE((self.app / "backups" / files[0]).stat().st_mode), 0o600)
        self.assertIn("Saved:", result.stdout)
        self.assertEqual(self.docker_calls()[-1], "docker exec istiraha-web python -m istiraha export")

    def test_a_failed_or_unreadable_copy_saves_nothing(self):
        for extra in ({"FAKE_EXPORT_FAIL": "1"}, {"FAKE_EXPORT_BAD": "1"}):
            result = self.run_script(["backup.sh"], env_extra=extra)
            self.assertNotEqual(result.returncode, 0, extra)
            self.assertIn("Nothing was saved", result.stderr)
            self.assertEqual(self.backups(), [], extra)

    def test_backup_needs_a_running_website(self):
        result = self.run_script(["backup.sh"], env_extra={"FAKE_WEB_RUNNING": "0"})
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.backups(), [])

    def test_old_copies_are_rotated_but_nothing_else_is_ever_removed(self):
        folder = self.app / "backups"
        old = [f"istiraha-2026{m:02d}{d:02d}-120000.tar.gz" for m in (1, 2, 3) for d in range(1, 13)]      # 36 older copies
        for name in old:
            (folder / name).write_bytes(b"x")
        strangers = ["notes.txt", "istiraha-latest.tar.gz", "istiraha-20260101-1200.tar.gz", "other-20260101-120000.tar.gz"]
        for name in strangers:
            (folder / name).write_bytes(b"mine")
        result = self.run_script(["backup.sh"])
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        ours = [n for n in self.backups() if re.fullmatch(r"istiraha-\d{8}-\d{6}\.tar\.gz", n)]
        self.assertEqual(len(ours), 30)
        self.assertEqual(ours[-1][:11], "istiraha-20")                       # the new copy is the newest and was kept
        self.assertNotIn(old[0], self.backups())                             # the oldest went
        self.assertIn(old[-1], self.backups())
        for name in strangers:
            self.assertEqual((folder / name).read_bytes(), b"mine", name)
        self.assertEqual(result.stdout.count("Removed an old copy"), 7)

    def archive(self):
        path = self.tmp / "copy.tar.gz"
        self.assertEqual(subprocess.run(["bash", "-c", f'd=$(mktemp -d); echo db > "$d/istiraha.db"; tar -czf {path} -C "$d" istiraha.db'], capture_output=True).returncode, 0)
        return path

    def test_restore_needs_the_word_YES_and_a_real_copy(self):
        path = self.archive()
        for answer in ("", "yes\n", "no\n"):
            result = self.run_script(["restore.sh", str(path)], stdin=answer)
            self.assertNotEqual(result.returncode, 0, repr(answer))
            self.assertEqual([c for c in self.docker_calls() if " stop " in c or " run " in c], [], repr(answer))
        junk = self.tmp / "junk.tar.gz"
        junk.write_bytes(b"not an archive")
        for args in ([], ["/nonexistent"], [str(junk)]):
            result = self.run_script(["restore.sh", *args], stdin="YES\n")
            self.assertNotEqual(result.returncode, 0, args)
        self.assertEqual([c for c in self.docker_calls() if " stop " in c or " run " in c], [])

    def test_restore_stops_only_the_website_feeds_the_copy_in_and_starts_it_again(self):
        path = self.archive()
        result = self.run_script(["restore.sh", str(path)], stdin="YES\n")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        calls = [c for c in self.docker_calls() if c.startswith("docker compose -p istiraha")]
        self.assertEqual(calls, ["docker compose -p istiraha stop web",
                                 "docker compose -p istiraha run --rm --no-deps -T web python -m istiraha import --force",
                                 "docker compose -p istiraha up -d web"])
        self.assertEqual((self.state / "restored.tar.gz").read_bytes(), path.read_bytes())       # the copy really reached the importer

    def test_a_failed_restore_starts_the_website_again_with_the_data_it_had(self):
        path = self.archive()
        result = self.run_script(["restore.sh", str(path)], stdin="YES\n", env_extra={"FAKE_IMPORT_FAIL": "1"})
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Nothing was lost", result.stderr)
        self.assertEqual(self.docker_calls()[-1], "docker compose -p istiraha up -d web")


class WebScriptTests(ScriptCase):
    def setUp(self):
        super().setUp()
        self.assertEqual(self.install().returncode, 0)
        self.log.write_text("")

    def quick(self, **env_extra):
        return self.run_script(["web.sh", "quick"], env_extra=env_extra)

    def domain(self, domain="Istirahati.Example", token=TOKEN, **env_extra):
        return self.run_script(["web.sh", "domain"], stdin=f"{domain}\n{token}\n", env_extra=env_extra)

    def test_it_needs_the_website_installed_first(self):
        (self.app / ".env").unlink()
        for command in ("quick", "domain", "stop"):
            result = self.run_script(["web.sh", command], stdin="x\n")
            self.assertNotEqual(result.returncode, 0, command)
            self.assertIn("bash install.sh", result.stderr)
        self.assertEqual([c for c in self.docker_calls() if " up " in c], [])

    def test_unknown_commands_show_the_usage(self):
        for args in ([], ["start"], ["quick-now"]):
            result = self.run_script(["web.sh", *args])
            self.assertNotEqual(result.returncode, 0, args)
            self.assertIn("usage: bash web.sh", result.stderr)

    # ---- the free temporary link
    def test_quick_starts_the_link_and_prints_it(self):
        result = self.quick()
        out = result.stdout + result.stderr
        self.assertEqual(result.returncode, 0, out)
        self.assertIn(QUICK_URL, out)
        self.assertNotIn("api.trycloudflare.com", out)
        self.assertIn("It answers from the internet", out)
        self.assertIn("only for trying the site", out)
        self.assertEqual(self.env()["SITE_URL"], "")
        self.assertEqual((self.app / ".state").read_text(), "ACCESS=quick\n")
        self.assertEqual(stat.S_IMODE((self.app / ".state").stat().st_mode), 0o600)
        tunnel_file = self.app / ".tunnel.env"
        self.assertEqual((tunnel_file.read_text(), stat.S_IMODE(tunnel_file.stat().st_mode)), ("", 0o600))
        calls = self.docker_calls()
        self.assertIn("docker compose -p istiraha --profile quick up -d --build web tunnel", calls)
        self.assertIn(f"{EVERYTHING} rm -sf tunnel-domain", calls)
        for call in calls:
            self.assertTrue(call.startswith(("docker compose -p istiraha ", "docker compose version", "docker logs istiraha-web", "docker logs istiraha-tunnel")), call)

    def test_it_will_not_squeeze_the_other_projects_when_memory_is_short(self):
        self.set_memory(120 * 1024)
        before = (self.app / ".env").read_text()
        for command, stdin in (("quick", ""), ("domain", f"istirahati.example\n{TOKEN}\n")):
            result = self.run_script(["web.sh", command], stdin=stdin)
            self.assertNotEqual(result.returncode, 0, command)
            self.assertIn("only 120 MB of memory is free", result.stderr)
            self.assertIn("Nothing was changed", result.stderr)
        self.assertEqual((self.app / ".env").read_text(), before)
        self.assertEqual((self.app / ".tunnel.env").read_text(), "")            # no token was stored either
        self.assertEqual([c for c in self.docker_calls() if " up " in c], [])
        self.set_memory(210 * 1024)
        self.assertEqual(self.quick().returncode, 0)

    def test_the_memory_check_never_blocks_when_it_cannot_tell_or_when_the_link_already_runs(self):
        self.meminfo.write_text("garbage\n")
        self.assertEqual(self.quick().returncode, 0)
        self.meminfo.unlink()
        self.assertEqual(self.quick().returncode, 0)
        self.set_memory(50 * 1024)
        again = self.quick()
        self.assertEqual(again.returncode, 0, again.stdout + again.stderr)

    def test_quick_says_so_when_the_link_does_not_answer_yet(self):
        result = self.quick(FAKE_PUBLIC="0")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn(QUICK_URL, result.stdout)
        self.assertIn("does not answer yet", result.stdout)

    def test_quick_shows_the_tunnel_log_when_no_link_appears(self):
        result = self.quick(FAKE_NO_URL="1")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("did not show a link", result.stdout)
        self.assertIn("docker logs --tail 20 istiraha-tunnel", self.calls())

    def test_quick_stops_there_when_the_website_does_not_start(self):
        result = self.quick(FAKE_NO_START="1")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("did not report that it started", result.stdout)
        self.assertNotIn("docker logs istiraha-tunnel", self.calls())

    def test_link_and_status(self):
        off = self.run_script(["web.sh", "link"])
        self.assertEqual(off.returncode, 0)
        self.assertIn("The public link is off", off.stdout)
        self.assertIn("Public link: off", self.run_script(["web.sh", "status"]).stdout)
        self.quick()
        self.log.write_text("")
        self.assertEqual(self.run_script(["web.sh", "link"]).stdout.strip(), QUICK_URL)
        status = self.run_script(["web.sh", "status"])
        self.assertEqual(status.returncode, 0, status.stderr)
        self.assertIn("Public link: quick", status.stdout)
        self.assertIn(QUICK_URL, status.stdout)
        self.assertIn("docker compose -p istiraha --profile quick ps", self.calls())
        overall = self.run_script(["status.sh"])
        self.assertEqual(overall.returncode, 0, overall.stderr)
        self.assertIn(QUICK_URL, overall.stdout)

    def test_updating_keeps_the_public_link_running(self):
        self.quick()
        self.log.write_text("")
        result = self.run_script(["install.sh"])
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("docker compose -p istiraha --profile quick up -d --build web", self.calls())      # only the website is rebuilt; the tunnel (and its link) is left alone
        self.assertNotIn("tunnel", " ".join(c for c in self.calls() if " up " in c))

    def test_stop_switches_the_link_off_but_not_the_website(self):
        self.quick()
        self.log.write_text("")
        result = self.run_script(["web.sh", "stop"])
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn(f"{EVERYTHING} rm -sf tunnel tunnel-domain", self.calls())
        self.assertNotIn("web ", " ".join(c.split("rm -sf")[-1] for c in self.calls() if "rm -sf" in c))
        self.assertEqual((self.app / ".state").read_text(), "ACCESS=off\n")
        self.assertIn("The website keeps running", result.stdout)
        self.log.write_text("")
        self.assertEqual(self.run_script(["install.sh"]).returncode, 0)
        self.assertFalse([c for c in self.calls() if "--profile" in c])          # no tunnel parts any more

    # ---- your own domain
    def test_domain_connects_the_tunnel_and_keeps_the_token_private(self):
        result = self.domain(domain="https://Istirahati.Example/")
        out = result.stdout + result.stderr
        self.assertEqual(result.returncode, 0, out)
        self.assertIn("Website address:  https://istirahati.example", out)
        self.assertIn("The tunnel is connected", out)
        self.assertIn("It answers from the internet", out)
        self.assertIn("web:8090", out)
        self.assertNotIn(TOKEN, out)
        tunnel_file = self.app / ".tunnel.env"
        self.assertEqual((tunnel_file.read_text(), stat.S_IMODE(tunnel_file.stat().st_mode)), (f"TUNNEL_TOKEN={TOKEN}\n", 0o600))
        self.assertEqual(self.env()["SITE_URL"], "https://istirahati.example")
        self.assertNotIn(TOKEN, (self.app / ".env").read_text())            # the website's own settings file never holds it
        self.assertEqual((self.app / ".state").read_text(), "ACCESS=domain\n")
        calls = self.docker_calls()
        self.assertIn("docker compose -p istiraha --profile domain up -d --build web tunnel-domain", calls)
        self.assertIn(f"{EVERYTHING} rm -sf tunnel", calls)
        for call in calls:
            self.assertNotIn(TOKEN, call)
        self.assertEqual(self.run_script(["web.sh", "link"]).stdout.strip(), "https://istirahati.example")

    def test_domain_asks_again_for_a_wrong_name_or_token_and_gives_up_after_five(self):
        result = self.run_script(["web.sh", "domain"], stdin=f"not a domain\nexample\nistirahati.example\nshort\n{TOKEN}\n")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("does not look right", result.stdout)
        self.assertEqual(self.env()["SITE_URL"], "https://istirahati.example")
        before = (self.app / ".env").read_text()
        self.log.write_text("")
        gave_up = self.run_script(["web.sh", "domain"], stdin="x\n" * 6)
        self.assertNotEqual(gave_up.returncode, 0)
        self.assertIn("5 times", gave_up.stderr)
        self.assertEqual((self.app / ".env").read_text(), before)
        self.assertEqual([c for c in self.docker_calls() if " up " in c], [])

    def test_domain_reports_a_tunnel_that_does_not_connect(self):
        result = self.domain(FAKE_BAD_TUNNEL="1")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("did not connect", result.stdout)
        self.assertIn("Provided Tunnel token is not valid", result.stdout)
        self.assertNotIn(TOKEN, result.stdout + result.stderr)

    def test_domain_may_need_a_few_minutes_before_it_answers(self):
        result = self.domain(FAKE_PUBLIC="0")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("does not answer yet", result.stdout)

    def test_going_back_and_forth_between_the_two_modes(self):
        self.assertEqual(self.domain().returncode, 0)
        self.log.write_text("")
        result = self.quick()
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(self.env()["SITE_URL"], "")           # a temporary link is never presented as the real address
        self.assertIn(f"{EVERYTHING} rm -sf tunnel-domain", self.calls())
        self.assertEqual(self.run_script(["web.sh", "link"]).stdout.strip(), QUICK_URL)


if __name__ == "__main__":
    unittest.main()
