#!/usr/bin/env bash
# Rest-house website: installer / updater.
#
#   bash install.sh              first install, or update to the files in this folder (keeps .env, data and backups)
#   bash install.sh set NAME     change one setting later (SITE_NAME)
#
# Safety: runs only inside /opt/istiraha-site and only touches the Docker project "istiraha"
# (container istiraha-web, network istiraha_default, volume istiraha_istiraha_data, image istiraha-site:local;
# and, once you switch the public link on with web.sh, the containers istiraha-tunnel / istiraha-domain).
# It never stops, restarts, rebuilds, removes or edits anything that belongs to another project, and it stops
# before doing anything if one of these names is already used by something that is not this project.
# The website has no secret to type here: its settings (.env) hold no key and no password.
set -euo pipefail

APP_DIR="/opt/istiraha-site"
PROJECT="istiraha"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$APP_DIR/.env"

die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
say() { printf '%s\n' "$*"; }

[ "$HERE" = "$APP_DIR" ] || die "this script must live in $APP_DIR (it is in $HERE). Nothing was changed."
cd "$APP_DIR"
umask 077

command -v docker >/dev/null 2>&1 || die "docker is not installed on this server."
docker compose version >/dev/null 2>&1 || die "the 'docker compose' plugin is missing."
docker info >/dev/null 2>&1 || die "docker is not running, or this user may not use it."

# ---------------------------------------------------------------- helpers
env_get() { [ -f "$ENV_FILE" ] && grep -m1 "^$1=" "$ENV_FILE" | cut -d= -f2- || true; }

env_set() { # NAME VALUE  (values are validated before they get here, so they never contain newlines)
  local tmp
  tmp="$(mktemp "$APP_DIR/.env.XXXXXX")"
  if [ -f "$ENV_FILE" ]; then grep -v "^$1=" "$ENV_FILE" > "$tmp" || true; fi
  printf '%s=%s\n' "$1" "$2" >> "$tmp"
  chmod 600 "$tmp"
  mv "$tmp" "$ENV_FILE"
}

state_get() { [ -f "$APP_DIR/.state" ] && grep -m1 "^$1=" "$APP_DIR/.state" | cut -d= -f2- || true; }

access_mode() { # off | quick | domain  (switched with web.sh)
  case "$(state_get ACCESS)" in
    quick)  echo quick ;;
    domain) echo domain ;;
    *)      echo off ;;
  esac
}

compose() { # the website, plus its tunnel when the public link is switched on
  case "$(access_mode)" in
    quick)  docker compose -p "$PROJECT" --profile quick "$@" ;;
    domain) docker compose -p "$PROJECT" --profile domain "$@" ;;
    *)      docker compose -p "$PROJECT" "$@" ;;
  esac
}

prepare_files() { # compose reads this file for the domain tunnel; it must exist (empty is fine)
  [ -f "$APP_DIR/.tunnel.env" ] || : > "$APP_DIR/.tunnel.env"
  chmod 600 "$APP_DIR/.tunnel.env"
}

owner_of() { # KIND NAME -> the compose project that created it ("" when it does not exist or has no label)
  case "$1" in
    container) docker inspect -f '{{ index .Config.Labels "com.docker.compose.project" }}' "$2" 2>/dev/null || true ;;
    volume)    docker volume inspect -f '{{ index .Labels "com.docker.compose.project" }}' "$2" 2>/dev/null || true ;;
    network)   docker network inspect -f '{{ index .Labels "com.docker.compose.project" }}' "$2" 2>/dev/null || true ;;
  esac
}

exists() { # KIND NAME
  case "$1" in
    container) docker inspect "$2" >/dev/null 2>&1 ;;
    volume)    docker volume inspect "$2" >/dev/null 2>&1 ;;
    network)   docker network inspect "$2" >/dev/null 2>&1 ;;
  esac
}

preflight() { # read-only: look at the server, and stop if any name we need belongs to someone else
  local kind name owner
  say "Checking this server (nothing is changed yet)..."
  for item in container:istiraha-web container:istiraha-tunnel container:istiraha-domain \
              volume:istiraha_istiraha_data network:istiraha_default; do
    kind="${item%%:*}"; name="${item#*:}"
    if exists "$kind" "$name"; then
      owner="$(owner_of "$kind" "$name")"
      [ "$owner" = "$PROJECT" ] || die "the $kind '$name' already exists and does not belong to this project (it belongs to '${owner:-no project}'). Nothing was changed."
    fi
  done
  local free_mb kb mem_mb="?"
  free_mb="$(df -Pm "$APP_DIR" 2>/dev/null | awk 'NR==2 {print $4}')"
  if [[ "$free_mb" =~ ^[0-9]+$ ]] && [ "$free_mb" -lt 1024 ]; then
    die "only $free_mb MB of disk is free here; the build needs about 1 GB. Nothing was changed."
  fi
  kb="$(awk '/^MemAvailable:/ {print $2}' "${ISTIRAHA_MEMINFO:-/proc/meminfo}" 2>/dev/null || true)"
  if [[ "$kb" =~ ^[0-9]+$ ]]; then
    mem_mb=$((kb / 1024))
    # a website that is already running counts in the server's memory, so only a first start is held back
    if ! exists container istiraha-web && [ "$mem_mb" -lt 300 ]; then
      die "only $mem_mb MB of memory is free on this server. The website needs about 150 MB and starting it could slow down the other projects here. Nothing was changed."
    fi
  fi
  say "  disk free: ${free_mb:-?} MB, memory free: $mem_mb MB"
  say "  other containers on this server (they will not be touched):"
  docker ps -a --format '    {{.Names}}  ({{.Status}})' | grep -v '^    istiraha-' || say "    none"
}

start_web() {
  say "Building and starting the website (the first build takes 1 to 3 minutes)..."
  prepare_files
  compose up -d --build web
  local i logs line
  for i in $(seq 1 30); do
    logs="$(docker logs istiraha-web 2>&1 || true)"
    line="$(printf '%s\n' "$logs" | grep "website started on port" | tail -n 1 || true)"
    if [ -n "$line" ]; then
      say "The website is running:"
      say "$line"
      return 0
    fi
    sleep 2
  done
  say "The website did not report that it started within 60 seconds. Last log lines:"
  docker logs --tail 20 istiraha-web 2>&1 || true
  return 1
}

# ---------------------------------------------------------------- set one value
if [ "${1:-}" = "set" ]; then
  [ "${2:-}" = "SITE_NAME" ] || die "usage: bash install.sh set SITE_NAME"
  [ -f "$ENV_FILE" ] || die "no .env yet. Run: bash install.sh"
  read -r -p "New site name (2 to 40 letters, shown in the header and the page titles): " value || die "input was closed."
  value="${value#"${value%%[![:space:]]*}"}"; value="${value%"${value##*[![:space:]]}"}"
  [ "${#value}" -ge 2 ] && [ "${#value}" -le 120 ] || die "the name must be 2 to 40 characters. Nothing was changed."
  case "$value" in *[$'\n\r\t\\"<>&']*) die "the name has a character that is not allowed. Nothing was changed." ;; esac
  env_set SITE_NAME "$value"
  say "SITE_NAME updated. Restarting the website..."
  prepare_files
  compose up -d --force-recreate web
  sleep 5
  docker logs --tail 3 istiraha-web 2>&1 || true
  exit 0
fi

[ -z "${1:-}" ] || die "unknown option. Use: bash install.sh   or   bash install.sh set SITE_NAME"

# ---------------------------------------------------------------- install or update
FIRST=0
if [ -f "$ENV_FILE" ]; then
  say "Keeping your existing settings in .env."
else
  FIRST=1
  say "This server is: $(hostname 2>/dev/null || echo unknown)"
  say "The website will be installed here, in $APP_DIR, on its own and separate from every other project."
  read -r -p "Is this the right server? Type y then Enter to continue (anything else cancels): " reply || die "input was closed."
  case "$reply" in
    y|Y|yes|YES|Yes) ;;
    *) die "cancelled. No container was started and no setting was saved." ;;
  esac
fi

preflight

if [ "$FIRST" = 1 ]; then
  [ -f "$APP_DIR/.env.example" ] || die ".env.example is missing from this folder."
  cp "$APP_DIR/.env.example" "$ENV_FILE"
  say ""
  say "Settings saved in $ENV_FILE (readable by root only). The default site name is a placeholder;"
  say "change it any time with:  bash install.sh set SITE_NAME"
fi
chmod 600 "$ENV_FILE"
mkdir -p "$APP_DIR/backups"
chmod 700 "$APP_DIR/backups"

say ""
start_web || exit 1
say ""
say "Containers of this project:"
compose ps
say ""
if [ "$FIRST" = 1 ]; then
  say "Next steps:"
  say "  1) bash admin.sh        create the manager account (you choose the name and password; typing is hidden)"
  say "  2) bash web.sh quick    get a free temporary link to try the site on your phone"
else
  say "Updated. Your data, settings and backups were kept."
fi
say "Done."
