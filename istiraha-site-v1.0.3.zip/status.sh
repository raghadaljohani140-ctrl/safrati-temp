#!/usr/bin/env bash
# Shows only the rest-house website: container state, the last log lines, the data size and the backups.
# Read-only. The log never contains passwords or the text of a query.
set -euo pipefail
[ "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" = "/opt/istiraha-site" ] || { echo "ERROR: run from /opt/istiraha-site" >&2; exit 1; }
cd /opt/istiraha-site
mode="$( (grep -m1 '^ACCESS=' .state 2>/dev/null || true) | cut -d= -f2-)"
case "$mode" in
  quick|domain) docker compose -p istiraha --profile "$mode" ps ;;
  *)            mode="off"; docker compose -p istiraha ps ;;
esac
echo "--- health ---"
docker inspect -f '{{.State.Health.Status}}' istiraha-web 2>/dev/null || echo "not running"
echo "--- last log lines ---"
docker logs --tail 15 istiraha-web 2>&1 || true
echo "--- data ---"
docker exec istiraha-web sh -c 'du -sh /data 2>/dev/null' 2>/dev/null || true
echo "--- backups ---"
ls -1t backups 2>/dev/null | head -5 || true
echo "--- public link ($mode) ---"
bash web.sh link || true
